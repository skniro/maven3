package com.skniro.chunk_loader;


import com.skniro.chunk_loader.block.GrowableOresBlocks;
import com.skniro.chunk_loader.block.entity.AlchemyBlockEntityType;
import com.skniro.chunk_loader.item.*;
import com.skniro.chunk_loader.screen.AlchemyScreenHandlerType;


public class  ModContent {


    public static void registerItem() {
        GrowableOresItems.shield_item();
    }

    public static void registerBlock() {
        GrowableOresBlocks.registerGrowableOresBlocks();
        AlchemyBlockEntityType.registerMapleBlockEntityType();
        AlchemyScreenHandlerType.registeralchemyscreenhandlertype();
    }

    public static void registerFluids() {
    }

    public static void CreativeTab() {
        ModCreativeTab.CreativeTab();
        ModCreativeTab.CreativeTabItem();
    }

    public static void registerEntity() {
    }

    public static void WorldGen() {
    }

    public static void registerCommand() {

    }

    public static void registerOthers() {
    }

    public static void Compat() {

    }
}
