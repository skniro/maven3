package com.skniro.growable_ores_extension.recipe;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.recipe.machine.*;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;

public interface AlchemyRecipeType<T extends Recipe<?>> {
    public static final RecipeRegistration<AlchemyCraftingRecipe> CANE_CONVERTER =
            register("cane_converter", AlchemyCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<MaceratorCraftingRecipe> MACERATOR =
            register("macerator", MaceratorCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<CompressorCraftingRecipe> COMPRESSOR =
            register("compressor", CompressorCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<MetalFormerRollingCraftingRecipe> METALFORMER_ROLLING =
            register("metal_former_rolling", MetalFormerRollingCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<MetalFormerCuttingCraftingRecipe> METALFORMER_CUTTING =
            register("metal_former_cutting", MetalFormerCuttingCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<MetalFormerExtrudingCraftingRecipe> METALFORMER_EXTRUDING =
            register("metal_former_extruding", MetalFormerExtrudingCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<MolecularTransformerCraftingRecipe> MOLECULAR_TRANSFORMER =
            register("molecular_transformer", MolecularTransformerCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<ExtractorCraftingRecipe> EXTRACTOR =
            register("extractor", ExtractorCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<CuttingCraftingRecipe> CUTTING =
            register("cuttingr", CuttingCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<RecyclerCraftingRecipe> RECYCLER =
            register("recycler", RecyclerCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<BrewReactorCraftingRecipe> BREW_REACTOR =
            register("brew_reactor", BrewReactorCraftingRecipe.SERIALIZER);


    public static <R extends Recipe<?>> RecipeRegistration<R> register(String idName, RecipeSerializer<R> serializer) {
        Identifier id = Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, idName);

        RecipeType<R> type = Registry.register(BuiltInRegistries.RECIPE_TYPE, id, new RecipeType<R>() {
            @Override
            public String toString() {
                return idName;
            }
        });
        RecipeSerializer<R> ser = Registry.register(BuiltInRegistries.RECIPE_SERIALIZER, id, serializer);

        return new RecipeRegistration<>(type, ser);
    }

    public static class RecipeRegistration<R extends Recipe<?>> {
        public final RecipeType<R> type;
        public final RecipeSerializer<R> serializer;

        public RecipeRegistration(RecipeType<R> type, RecipeSerializer<R> serializer) {
            this.type = type;
            this.serializer = serializer;
        }
    }

    public static void registerRecipes() {
        GrowableOresExtension.LOGGER.info("Registering Custom Recipes for " + GrowableOresExtension.MOD_ID);
    }
}

