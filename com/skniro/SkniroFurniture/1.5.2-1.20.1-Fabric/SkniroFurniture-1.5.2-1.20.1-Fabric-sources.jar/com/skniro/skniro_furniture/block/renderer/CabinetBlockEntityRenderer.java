package com.skniro.skniro_furniture.block.renderer;

import com.skniro.skniro_furniture.block.entity.CabinetBlockEntity;
import com.skniro.skniro_furniture.block.init.FourGridCabinetBlock;
import com.skniro.skniro_furniture.block.init.TripleCabinetBlock;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_918;

public class CabinetBlockEntityRenderer implements class_827<CabinetBlockEntity> {
    public CabinetBlockEntityRenderer(class_5614.class_5615 context) {
    }

    @Override
    public void render(CabinetBlockEntity entity, float tickDelta, class_4587 matrices,
                       class_4597 vertexConsumers, int light, int overlay) {
        class_918 itemRenderer = class_310.method_1551().method_1480();
        class_2350 direction = entity.method_11010().method_11654(class_2741.field_12481);
        matrices.method_22903();

        switch (direction) {
            case field_11043 -> {}
            case field_11035 -> {
                matrices.method_46416(1, 0, 1);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(180));
            }
            case field_11039 -> {
                matrices.method_46416(0, 0, 1);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(90));
            }
            case field_11034 -> {
                matrices.method_46416(1, 0, 0);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(270));
            }
        }

        if (entity.method_11010().method_26204() instanceof TripleCabinetBlock) {
            float spacing = 1.2f;
            float spacing2 = 1.19f;
            matrices.method_46416(0.46f, 0.80f, 0.7f);
            matrices.method_22905(0.26f, 0.26f, 0.26f);

            for (int i = 0; i < 9; i++) {
                class_1799 stack = entity.method_5438(i);
                if (!stack.method_7960()) {
                    matrices.method_22903();
                    int row = i / 3;
                    float col = (i % 3) * 1.1f;
                    matrices.method_46416((col - 1) * spacing2, -(row * spacing), 0);
                    itemRenderer.method_23178(stack, class_811.field_4317, getLightLevel(entity.method_10997(), entity.method_11016()), class_4608.field_21444, matrices, vertexConsumers, entity.method_10997(), 1);
                    matrices.method_22909();
                }
            }
        }

        if (entity.method_11010().method_26204() instanceof FourGridCabinetBlock) {
            float spacing = 1.2f;
            float spacing2 = 1.05f;
            matrices.method_46416(0.68f, 0.70f, 0.7f);
            matrices.method_22905(0.4f, 0.4f, 0.4f);

            for (int i = 0; i < 4; i++) {
                class_1799 stack = entity.method_5438(i);
                if (!stack.method_7960()) {
                    matrices.method_22903();
                    int row = i / 2;
                    float col = (i % 2) * 1.1f;
                    matrices.method_46416((col - 1) * spacing2, -(row * spacing), 0);
                    itemRenderer.method_23178(stack, class_811.field_4317, getLightLevel(entity.method_10997(), entity.method_11016()), class_4608.field_21444, matrices, vertexConsumers, entity.method_10997(), 1);
                    matrices.method_22909();
                }
            }
        }

        matrices.method_22909();
    }

    private int getLightLevel(class_1937 world, class_2338 pos) {
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, Math.max(sLight, 15));
    }
}
