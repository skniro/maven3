package torcherino;

import com.google.common.collect.ImmutableMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import torcherino.api.Tier;
import torcherino.api.TorcherinoAPI;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class TorcherinoImpl implements TorcherinoAPI {
    public static final String MOD_ID = "torcherino";

    public static final Logger LOGGER = LogManager.getLogger("torcherino-api");
    private final Map<class_2960, Tier> localTiers = new HashMap<>();
    private final Set<class_2248> blacklistedBlocks = new HashSet<>();
    private final Set<class_2591<?>> blacklistedTiles = new HashSet<>();
    private Map<class_2960, Tier> remoteTiers = new HashMap<>();

    public void registerTier(class_2960 name, int maxSpeed, int xzRange, int yRange) {
        if (localTiers.containsKey(name)) {
            LOGGER.warn("Tier with id {} has already been registered.", name);
            return;
        }
        Tier tier = new Tier(maxSpeed, xzRange, yRange);
        localTiers.put(name, tier);
    }

    public boolean blacklistBlock(class_2960 blockId) {
        Optional<class_2248> block = class_7923.field_41175.method_17966(blockId);
        if (block.isPresent()) {
            if (blacklistedBlocks.contains(block.get())) {
                LOGGER.warn("Block with id {} is already blacklisted.", block);
                return false;
            }
            blacklistedBlocks.add(block.get());
            return true;
        }
        LOGGER.warn("Block with id {} does not exist.", block);
        return false;
    }

    @Override
    public boolean blacklistBlock(class_2248 block) {
        if (blacklistedBlocks.contains(block)) {
            LOGGER.warn("Block with id {} is already blacklisted.", class_7923.field_41175.method_10221(block));
            return false;
        }
        blacklistedBlocks.add(block);
        return true;
    }

    @Override
    public boolean isBlockBlacklisted(class_2248 block) {
        return blacklistedBlocks.contains(block);
    }

    @Override
    public boolean blacklistBlockEntity(class_2960 blockEntityTypeId) {
        Optional<class_2591<?>> blockEntityType = class_7923.field_41181.method_17966(blockEntityTypeId);
        if (blockEntityType.isPresent()) {
            if (blacklistedTiles.contains(blockEntityType.get())) {
                LOGGER.warn("BlockEntityType with id {} is already blacklisted.", blockEntityTypeId);
                return false;
            }
            blacklistedTiles.add(blockEntityType.get());
            return true;
        }
        LOGGER.warn("BlockEntityType with id {} does not exist.", blockEntityTypeId);
        return false;
    }

    @Override
    public boolean blacklistBlockEntity(class_2591<?> blockEntityType) {
        if (blacklistedTiles.contains(blockEntityType)) {
            LOGGER.warn("BlockEntityType with id {} is already blacklisted.", class_7923.field_41181.method_10221(blockEntityType));
            return false;
        }
        blacklistedTiles.add(blockEntityType);
        return true;
    }

    @Override
    public boolean isBlockEntityBlacklisted(class_2591<?> blockEntityType) {
        return blacklistedTiles.contains(blockEntityType);
    }

    // Do not use
    public void setRemoteTiers(Map<class_2960, Tier> tiers) {
        remoteTiers = tiers;
    }

    public ImmutableMap<class_2960, Tier> getTiers() {
        return ImmutableMap.copyOf(localTiers);
    }

    @Override
    public Tier getTier(class_2960 name) {
        return remoteTiers.getOrDefault(name, null);
    }
}
