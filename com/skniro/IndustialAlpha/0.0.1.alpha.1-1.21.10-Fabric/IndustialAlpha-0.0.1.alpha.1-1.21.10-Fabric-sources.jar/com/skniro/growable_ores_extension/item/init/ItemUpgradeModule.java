package com.skniro.growable_ores_extension.item.init;

import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

public class ItemUpgradeModule extends class_1792 {

    public final UpgradeType type;

    public ItemUpgradeModule(class_1793 settings, UpgradeType type) {
        super(settings);
        this.type = type;
    }


    @Override
    public void method_67187(class_1799 stack, class_9635 context, class_10712 displayComponent, Consumer<class_2561> textConsumer, class_1836 type) {

        switch (this.type) {

            case OVERCLOCKER -> {
                textConsumer.accept(class_2561.method_43470("Speed: -30%")
                        .method_27692(class_124.field_1080));
                textConsumer.accept(class_2561.method_43470("Power: +60%")
                        .method_27692(class_124.field_1080));
            }

            case TRANSFORMER -> {
                textConsumer.accept(class_2561.method_43470("Energy Tier +1 per item")
                        .method_27692(class_124.field_1080));
            }

            case ENERGY_STORAGE -> {
                textConsumer.accept(class_2561.method_43470("Extra Storage: +10000 EU")
                        .method_27692(class_124.field_1080));
            }

            case REDSTONE_INVERTER -> {
                textConsumer.accept(class_2561.method_43470("Inverts Redstone Signal")
                        .method_27692(class_124.field_1080));
            }
        }
    }


    /**
     *  Transformer 升级数量
     */
    public int getTierIncrease(class_1799 stack) {
        if (this.type == UpgradeType.TRANSFORMER) {
            return stack.method_7947(); // 支持叠加
        }
        return 0;
    }

    /**
     *  处理速度倍率
     */
    public double getProcessTimeMultiplier(class_1799 stack) {
        if (this.type == UpgradeType.OVERCLOCKER) {
            return 1.3 * stack.method_7947();
        }
        return 1.0;
    }

    /**
     *  能耗倍率
     */
    public double getEnergyDemandMultiplier(class_1799 stack) {
        if (this.type == UpgradeType.OVERCLOCKER) {
            return 1.6 * stack.method_7947();
        }
        return 1.0;
    }

    /**
     *  额外储能
     */
    public int getExtraEnergyStorage(class_1799 stack) {
        if (this.type == UpgradeType.ENERGY_STORAGE) {
            return 10000 * stack.method_7947();
        }
        return 0;
    }

    public boolean modifiesRedstoneInput(class_1799 stack) {
        return this.type == UpgradeType.REDSTONE_INVERTER;
    }

    public int getRedstoneInput(class_1799 stack, int externalInput) {
        return 15 - externalInput;
    }



    public boolean isSuitableFor(class_1799 stack, Set<UpgradableProperty> properties) {

        return switch (this.type) {

            case OVERCLOCKER ->
                    properties.contains(UpgradableProperty.Processing);

            case TRANSFORMER ->
                    properties.contains(UpgradableProperty.Transformer);

            case ENERGY_STORAGE ->
                    properties.contains(UpgradableProperty.EnergyStorage);

            case REDSTONE_INVERTER ->
                    properties.contains(UpgradableProperty.RedstoneSensitive);

        };
    }


    public enum UpgradeType {
        OVERCLOCKER,
        TRANSFORMER,
        ENERGY_STORAGE,
        REDSTONE_INVERTER
    }
}