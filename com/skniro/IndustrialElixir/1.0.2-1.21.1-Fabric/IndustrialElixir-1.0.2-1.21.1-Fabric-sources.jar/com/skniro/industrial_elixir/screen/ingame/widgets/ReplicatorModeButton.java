package com.skniro.industrial_elixir.screen.ingame.widgets;

import com.skniro.industrial_elixir.block.entity.machine.fluid.ReplicatorBlockEntity;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_7919;
import net.minecraft.class_8666;

public class ReplicatorModeButton extends class_4185 {
    private static final class_8666 SPRITES = new class_8666(
            class_2960.method_60656("widget/button"),
            class_2960.method_60656("widget/button_disabled"),
            class_2960.method_60656("widget/button_highlighted"));

    private final ReplicatorBlockEntity.Mode mode;
    private final boolean active;
    private final class_1799 icon;

    public ReplicatorModeButton(int x, int y, int width, int height, ReplicatorBlockEntity.Mode mode, boolean active, class_1799 icon, class_2561 tooltip, class_4241 onPress) {
        super(x, y, width, height, class_2561.method_43473(), onPress, class_4185.field_40754);
        this.mode = mode;
        this.field_22763 = active;
        this.icon = icon;
        this.method_47400(class_7919.method_47407(tooltip));
    }

    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float partialTicks) {
        if (field_22764) {
            context.method_51422(1.0F, 1.0F, 1.0F, this.field_22765);
            context.method_52706(SPRITES.method_52729(this.method_37303(), this.method_25367()), this.method_46426(), this.method_46427(), this.method_25368(), this.method_25364());
            context.method_51422(1.0F, 1.0F, 1.0F, 1.0F);

            // Render icon in the center of the button
            if (!icon.method_7960()) {
                context.method_51427(icon, method_46426() + 1, method_46427() + 1);
            }
        }
    }

    @Override
    public void method_25306() {
        super.method_25306();
    }
}
