package com.skniro.growable_ores_extension.util;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.api.item.ModFuelRegistry;
import com.skniro.growable_ores_extension.item.GrowableOresItems;

public class ModFuel {
    public static void registerFuel() {
        ModFuelRegistry.registerFuel(GrowableOresItems.Scrap, 900);
    }
}
