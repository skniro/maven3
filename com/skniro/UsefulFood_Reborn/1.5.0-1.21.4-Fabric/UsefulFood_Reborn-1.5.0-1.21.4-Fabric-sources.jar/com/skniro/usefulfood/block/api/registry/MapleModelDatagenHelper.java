package com.skniro.usefulfood.block.api.registry;

import com.skniro.usefulfood.block.init.JamJarBlock;
import net.minecraft.class_2248;
import net.minecraft.class_4910;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4935;
import net.minecraft.class_4936;
import net.minecraft.class_4941;
import net.minecraft.client.data.*;

import static net.minecraft.class_4910.method_25565;
import static net.minecraft.class_4910.method_25644;

public record MapleModelDatagenHelper(class_4910 generator) {

    public void registerJamJarBlock(class_2248 jamJarBlock) {
        generator.field_22830.accept(class_4925.method_25769(jamJarBlock)
                .method_25775(class_4926.method_25783(JamJarBlock.JAM_STAGE)
                        .method_25793(1, class_4935.method_25824()
                                .method_25828(class_4936.field_22887, class_4941.method_25843(jamJarBlock, "_stage1")))
                        .method_25793(2, class_4935.method_25824()
                                .method_25828(class_4936.field_22887, class_4941.method_25843(jamJarBlock, "_stage2")))
                        .method_25793(3, class_4935.method_25824()
                                .method_25828(class_4936.field_22887, class_4941.method_25843(jamJarBlock, "_stage3")))
                ));
    }
}