package com.skniro.nether_ores_reborn.world;

import com.skniro.nether_ores_reborn.NetherOres;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5843;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.placementmodifier.*;

import java.util.List;

public class ModPlacedFeatures {
    public static final class_5321<class_6796> Coal_ORE_PLACED_KEY = registerKey("coal_ore_placed");
    public static final class_5321<class_6796> Nether_Copper_PLACED_KEY = registerKey("copper_ore_placed");
    public static final class_5321<class_6796> Nether_Diamond_PLACED_KEY = registerKey("diamond_ore_placed");
    public static final class_5321<class_6796> Nether_Emerald_PLACED_KEY = registerKey("emerald_ore_placed");
    public static final class_5321<class_6796> Nether_Gold_PLACED_KEY = registerKey("gold_ore_placed");
    public static final class_5321<class_6796> Nether_Iron_PLACED_KEY = registerKey("iron_ore_placed");
    public static final class_5321<class_6796> Nether_Lapis_PLACED_KEY = registerKey("lapis_ore_placed");
    public static final class_5321<class_6796> Nether_Redstone_PLACED_KEY = registerKey("redstone_ore_placed");
    public static final class_5321<class_6796> End_Coal_ORE_PLACED_KEY = registerKey("end_coal_ore_placed");
    public static final class_5321<class_6796> End_Copper_PLACED_KEY = registerKey("end_copper_ore_placed");
    public static final class_5321<class_6796> End_Diamond_PLACED_KEY = registerKey("end_diamond_ore_placed");
    public static final class_5321<class_6796> End_Emerald_PLACED_KEY = registerKey("end_emerald_ore_placed");
    public static final class_5321<class_6796> End_Gold_PLACED_KEY = registerKey("end_gold_ore_placed");
    public static final class_5321<class_6796> End_Iron_PLACED_KEY = registerKey("end_iron_ore_placed");
    public static final class_5321<class_6796> End_Lapis_PLACED_KEY = registerKey("end_lapis_ore_placed");
    public static final class_5321<class_6796> End_Redstone_PLACED_KEY = registerKey("end_redstone_ore_placed");

    public static void bootstrap(class_7891<class_6796> context) {
        var configuredFeatureRegistryEntryLookup = context.method_46799(class_7924.field_41239);

        register(context, Coal_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Nether_Coal_ORE_KEY),
                modifiersWithCount(20, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context,Nether_Copper_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Nether_Copper_KEY),
                modifiersWithCount(16, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Nether_Diamond_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Nether_Diamond_KEY),
                modifiersWithCount(8, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Nether_Emerald_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Nether_Emerald_KEY),
                modifiersWithCount(6, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Nether_Gold_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Nether_Gold_KEY),
                modifiersWithCount(10, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Nether_Iron_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures. Nether_Iron_KEY),
                modifiersWithCount(16, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Nether_Lapis_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Nether_Lapis_KEY),
                modifiersWithCount(10, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Nether_Redstone_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Nether_Redstone_ORE_KEY),
                modifiersWithCount(10, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, End_Coal_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.End_Coal_ORE_KEY),
                modifiersWithCount(20, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, End_Copper_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.End_Copper_KEY),
                modifiersWithCount(16, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, End_Diamond_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.End_Diamond_KEY),
                modifiersWithCount(8, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, End_Emerald_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.End_Emerald_KEY),
                modifiersWithCount(6, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, End_Gold_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.End_Gold_KEY),
                modifiersWithCount(10, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, End_Iron_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures. End_Iron_KEY),
                modifiersWithCount(16, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, End_Lapis_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.End_Lapis_KEY),
                modifiersWithCount(10, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, End_Redstone_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.End_Redstone_ORE_KEY),
                modifiersWithCount(10, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));
    }

    public static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(NetherOres.MOD_ID, name));
    }
    private static void register(class_7891<class_6796> context, class_5321<class_6796> key, class_6880<class_2975<?, ?>> configuration,
                                 List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(configuration, List.copyOf(modifiers)));
    }
    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_6796> context, class_5321<class_6796> key,
                                                                                   class_6880<class_2975<?, ?>> configuration,
                                                                                   class_6797... modifiers) {
        register(context, key, configuration, List.of(modifiers));
    }

    // Used here because the vanilla ones are private
    private static List<class_6797> modifiers(class_6797 countModifier, class_6797 heightModifier) {
        return List.of(countModifier, class_5450.method_39639(), heightModifier, class_6792.method_39614());
    }

    private static List<class_6797> modifiersWithCount(int count, class_6797 heightModifier) {
        return modifiers(class_6793.method_39623(count), heightModifier);
    }

    private static List<class_6797> modifiersWithRarity(int chance, class_6797 heightModifier) {
        return modifiers(class_6799.method_39659(chance), heightModifier);
    }
}
