package com.skniro.growable_ores_extension.block.renderer.pipe;

import com.skniro.growable_ores_extension.block.entity.pipe.PipeBlockEntity;
import com.skniro.growable_ores_extension.block.entity.pipe.PipeBlockEntity.PipeItem;
import com.skniro.growable_ores_extension.block.entity.pipe.WoodPipeBlockEntity;
import com.skniro.growable_ores_extension.block.renderer.state.PipeBlockEntityRenderState;
import net.minecraft.class_10442;
import net.minecraft.class_11566;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_12075;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_811;
import net.minecraft.class_827;
import org.jetbrains.annotations.Nullable;

public class WoodenPipeRenderer implements class_827<PipeBlockEntity, PipeBlockEntityRenderState> {

    public WoodenPipeRenderer(class_5614.class_5615 context) {

    }
    @Override
    public PipeBlockEntityRenderState method_74335() {
        return new PipeBlockEntityRenderState();
    }

    @Override
    public void render(PipeBlockEntityRenderState state, class_4587 matrices, class_11659 queue, class_12075 cameraState) {
        for (PipeBlockEntityRenderState.PipeItemRender item : state.items) {
            matrices.method_22903();
            matrices.method_22904(0.5 + item.offset.field_1352, 0.5 + item.offset.field_1351, 0.5 + item.offset.field_1350);
            matrices.method_22905(0.35f, 0.35f, 0.35f);
            item.item.method_65604(matrices, queue, item.lightmapCoordinates, class_4608.field_21444, 0);
            matrices.method_22909();
        }
    }

    @Override
    public void updateRenderState(PipeBlockEntity entity, PipeBlockEntityRenderState state, float tickProgress, class_243 cameraPos, @Nullable class_11683.class_11792 crumblingOverlay) {
        class_827.super.method_74331(entity, state, tickProgress, cameraPos, crumblingOverlay);
        class_10442 itemModelResolver = class_310.method_1551().method_65386();

        state.items.clear();
        for (PipeItem item : entity.getItems()) {
            if (item.variant.isBlank() || item.amount <= 0) {
                continue;
            }

            PipeBlockEntityRenderState.PipeItemRender renderItem = new PipeBlockEntityRenderState.PipeItemRender();
            renderItem.offset = new class_243(
                    item.direction.method_10148() * item.progress,
                    item.direction.method_10164() * item.progress,
                    item.direction.method_10165() * item.progress
            );
            itemModelResolver.method_65598(renderItem.item, item.variant.toStack(), class_811.field_4318, entity.method_10997(), (class_11566) entity, 1);
            renderItem.lightmapCoordinates = getLightLevel(entity.method_73183(), entity.method_11016());
            state.items.add(renderItem);
        }
    }

    private int getLightLevel(class_1937 world, class_2338 pos) {
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, Math.max(sLight, 15));
    }
}
