package com.skniro.industrial_elixir.fluid;

import com.skniro.industrial_elixir.IndustrialElixir;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.material.FlowingFluid;

    public class IndustrialElixirFluids {
        public static FlowingFluid STILL_Fluid_UU;
        public static FlowingFluid FLOWING_Fluid_UU;

        public static void registerFluids() {
            STILL_Fluid_UU = Registry.register(BuiltInRegistries.FLUID,
                    Identifier.fromNamespaceAndPath(IndustrialElixir.MOD_ID, "fluid_uu"), new IndustrialElixirFluidUUFluid.Still());

            FLOWING_Fluid_UU = Registry.register(BuiltInRegistries.FLUID,
                    Identifier.fromNamespaceAndPath(IndustrialElixir.MOD_ID, "flowing_fluid_uu"), new IndustrialElixirFluidUUFluid.Flowing());
        }
    }

