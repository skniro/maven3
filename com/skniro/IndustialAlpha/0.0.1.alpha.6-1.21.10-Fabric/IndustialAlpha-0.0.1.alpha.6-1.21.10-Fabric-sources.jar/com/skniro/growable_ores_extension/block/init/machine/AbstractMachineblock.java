package com.skniro.growable_ores_extension.block.init.machine;


import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.block.entity.machine.AbstractMachineEntity;
import net.minecraft.block.*;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.util.*;
import org.jetbrains.annotations.Nullable;

public abstract class AbstractMachineblock extends class_2237 {
    protected final EnergyTier energyTier;

    public AbstractMachineblock(class_2251 settings, EnergyTier energyTier) {
        super(settings);
        this.energyTier = energyTier;
    }

    public static final class_2754<class_2350> FACING = class_2741.field_12481;
    public static final class_2746 LIT = class_2741.field_12548;

    private static class_265 SHAPE = class_2248.method_9541(0, 0, 0, 16, 16, 16);

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }
    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }
    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }
    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{FACING, LIT});
    }


    /* BLOCK ENTITY */

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public void method_66388(class_2680 state, class_3218 world, class_2338 pos, boolean moved) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof AbstractMachineEntity) {
            class_1264.method_5451(world, pos, (class_1263) blockEntity);
            world.method_8455(pos,this);
        }
        super.method_66388(state, world, pos, moved);
    }

    @Override
    protected class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.method_8608()) {
            class_3908 screenHandlerFactory = state.method_26196(world, pos);

            if (screenHandlerFactory != null) {
                player.method_17355(screenHandlerFactory);
            }
        }

        return class_1269.field_5812;
    }

    public EnergyTier getEnergyTier(){
        return energyTier;
    }
}
