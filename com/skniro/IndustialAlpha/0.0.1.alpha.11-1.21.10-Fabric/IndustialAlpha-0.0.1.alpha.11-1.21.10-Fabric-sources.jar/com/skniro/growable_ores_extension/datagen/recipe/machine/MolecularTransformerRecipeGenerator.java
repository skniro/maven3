package com.skniro.growable_ores_extension.datagen.recipe.machine;

import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.item.AdvancedItems;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class MolecularTransformerRecipeGenerator extends FabricRecipeProvider {
    public MolecularTransformerRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {
                // Bronze
                createMolecularTransformer(GrowableOresItems.TIN_INGOT, GrowableOresItems.SILVER_INGOT, 500000).method_10431(field_53721);
                createMolecularTransformer(class_1802.field_8791, class_1802.field_8137,250000000).method_10431(field_53721);
                createMolecularTransformer(class_1802.field_8328, class_1802.field_8054, 2,70000).method_10431(field_53721);
                createMolecularTransformer(class_1802.field_8601, AdvancedItems.SUNNARIUM_Part,1000000).method_10431(field_53721);
                createMolecularTransformer(class_1802.field_8620, GrowableOresItems.IRIDIUM_ORE,9000000).method_10431(field_53721);
                createMolecularTransformer(class_1802.field_19058, class_1802.field_8793,500000).method_10431(field_53721);
                createMolecularTransformer(class_1802.field_19055, class_1802.field_8055,500000).method_10431(field_53721);
                createMolecularTransformer(GrowableOresItems.INDUSTRIAL_DIAMOND, class_1802.field_8477,1000000).method_10431(field_53721);
                createMolecularTransformer(class_1802.field_8665, class_1802.field_8713,60000).method_10431(field_53721);
                createMolecularTransformer(class_1802.field_8713, GrowableOresItems.INDUSTRIAL_DIAMOND,9000000).method_10431(field_53721);
                createMolecularTransformer(GrowableOresItems.SILVER_INGOT, class_1802.field_8695,500000).method_10431(field_53721);
                createMolecularTransformer(class_1802.field_8831, class_1802.field_19060,50000).method_10431(field_53721);
                createMolecularTransformer(class_1802.field_8858, class_1802.field_8110,50000).method_10431(field_53721);
                createMolecularTransformer(class_1802.field_19048, class_1802.field_8801,500000).method_10431(field_53721);
            }
        };
    }

    @Override
    public String method_10321() {
        return "MolecularTransformer";
    }
}
