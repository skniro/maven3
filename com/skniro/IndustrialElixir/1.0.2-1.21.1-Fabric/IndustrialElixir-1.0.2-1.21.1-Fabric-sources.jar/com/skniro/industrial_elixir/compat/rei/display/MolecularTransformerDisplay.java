package com.skniro.industrial_elixir.compat.rei.display;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.recipe.machine.MolecularTransformerCraftingRecipe;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2960;
import net.minecraft.class_8786;
import java.util.List;
import java.util.Optional;

public class MolecularTransformerDisplay extends BasicDisplay {
    private int count;
    private long energy;

    public static final CategoryIdentifier<MolecularTransformerDisplay> MolecularTransformer =
            CategoryIdentifier.of(IndustrialElixir.MOD_ID, "molecular_transformer");

    public static final DisplaySerializer<MolecularTransformerDisplay> SERIALIZER = BasicDisplay.Serializer.<MolecularTransformerDisplay>of(
            (inputs, outputs, location, tag) -> new MolecularTransformerDisplay(inputs, outputs, location,
                    tag.method_10550("count"), tag.method_10537("energy")),
            (display, tag) -> {
                tag.method_10569("count", display.getCount());
                tag.method_10544("energy", display.getEnergy());
            }
    );

    public MolecularTransformerDisplay(MolecularTransformerCraftingRecipe recipe) {
        this(List.of(EntryIngredients.ofIngredient(recipe.ingredient())),
                List.of(EntryIngredients.of(recipe.output())), Optional.empty(), recipe.requiredCount(), recipe.getEnergyRequired());
        this.count = recipe.requiredCount();
        this.energy = recipe.getEnergyRequired();
    }

    public MolecularTransformerDisplay(List<EntryIngredient> inputs, List<EntryIngredient> outputs, Optional<class_2960> location, int count, long energy) {
        super(inputs, outputs, location);
        this.count = count;
        this.energy = energy;
    }

    public MolecularTransformerDisplay(class_8786<MolecularTransformerCraftingRecipe> recipe){
        super(List.of(EntryIngredients.ofIngredient(recipe.comp_1933().ingredient())),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.comp_1933().output()))));
        this.count = recipe.comp_1933().requiredCount();
        this.energy = recipe.comp_1933().getEnergyRequired();
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return MolecularTransformer;
    }


    public int getCount() {
        return count;
    }

    public long getEnergy() {
        return energy;
    }
}