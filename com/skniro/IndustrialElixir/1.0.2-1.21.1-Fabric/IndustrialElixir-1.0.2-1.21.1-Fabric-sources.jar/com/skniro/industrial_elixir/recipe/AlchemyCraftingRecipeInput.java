package com.skniro.industrial_elixir.recipe;

import net.minecraft.class_1799;
import net.minecraft.class_9695;

public class AlchemyCraftingRecipeInput implements class_9695 {
    private final class_1799[] inputs;

    public AlchemyCraftingRecipeInput(class_1799 input) {
        this.inputs = new class_1799[]{input};
    }

    public AlchemyCraftingRecipeInput(class_1799... inputs) {
        this.inputs = inputs != null ? inputs : new class_1799[0];
    }

    @Override
    public class_1799 method_59984(int slot) {
        if (slot < 0 || slot >= inputs.length) return class_1799.field_8037;
        return inputs[slot];
    }

    @Override
    public int method_59983() {
        return inputs.length;
    }
}