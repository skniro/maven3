package com.skniro.growable_ores_extension.block.entity.generator;

import com.skniro.growable_ores_extension.api.ImplementedInventory;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.EnergyStorageUtil;
import com.skniro.growable_ores_extension.energy.api.base.SimpleSidedEnergyContainer;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;


public abstract class BaseGeneratorBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory {

    private static final int Battery_SLOT = 1;
    private long capacity;
    protected final EnergyTier energyTier;
    public SimpleSidedEnergyContainer energyContainer;

    public BaseGeneratorBlockEntity(class_2591<?> blockEntityType, class_2338 pos, class_2680 state, long capacity, EnergyTier energyTier) {
        super(blockEntityType, pos, state);
        this.capacity = capacity;
        this.energyTier = energyTier;
        energyContainer = new SimpleSidedEnergyContainer() {

            @Override
            public long getCapacity() {
                return capacity;
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                if (side == null) return energyTier.getMaxInput();
                return 0;
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                return energyTier.getMaxOutput();
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(pos, method_11010(), method_11010(), 3);
            }
        };
    }

    public EnergyStorage getSideEnergyStorage(@Nullable class_2350 side) {
        return this.energyContainer.getSideStorage(side);
    }

    private void pushEnergyToNeighbours() {
        for (class_2350 dir : class_2350.values()) {
            EnergyStorage target = EnergyStorage.SIDED.find(field_11863, field_11867.method_10093(dir), dir.method_10153());
            if (target == null) continue;
            EnergyStorageUtil.move(energyContainer.getSideStorage(dir), target, energyTier.getMaxOutput(), null);
        }
    }
}