package com.skniro.chunk_loader.screen;

import com.skniro.chunk_loader.SkniroChunkLoader;
import com.skniro.chunk_loader.screen.handler.machine.ChunkLoaderScreenHandler;
import net.fabricmc.fabric.api.menu.v1.ExtendedMenuType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;

public class AlchemyScreenHandlerType <T extends AbstractContainerMenu>{

    public static final MenuType<ChunkLoaderScreenHandler> ChunkLoader =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(SkniroChunkLoader.MOD_ID, "chunk_loader_screen_handler"),
                    new ExtendedMenuType<>(ChunkLoaderScreenHandler::new, BlockPos.STREAM_CODEC));

    public static void registeralchemyscreenhandlertype() {

    }
}
