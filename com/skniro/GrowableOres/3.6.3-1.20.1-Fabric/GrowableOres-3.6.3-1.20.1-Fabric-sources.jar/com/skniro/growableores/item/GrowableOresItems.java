package com.skniro.growableores.item;

import com.skniro.growableores.GrowableOres;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class GrowableOresItems {
    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(GrowableOres.MOD_ID, name), item);
    }

    public static void shield_item(){
      GrowableOres.LOGGER.debug("register shield item.");
    }
}
