package com.skniro.industrial_elixir.block.entity.machine.heat;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.energy.heat.api.HeatStorage;
import com.skniro.industrial_elixir.energy.heat.api.base.SimpleSidedHeatContainer;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.item.init.FluidCellItem;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.machine.AbstractMachineCraftingRecipe;
import com.skniro.industrial_elixir.recipe.machine.ModBlastFurnaceCraftingRecipe;
import com.skniro.industrial_elixir.screen.handler.machine.heat.ModBlastFurnaceScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.FullItemFluidStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.CombinedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1262;
import net.minecraft.class_1264;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3611;
import net.minecraft.class_3913;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class ModBlastFurnaceBlockEntity extends AbstractHeatMachineEntity {
    public int maxProgress = 6000;
    public SingleVariantStorage<FluidVariant> fluidContainer = new SingleVariantStorage<FluidVariant>() {
        @Override
        protected FluidVariant getBlankVariant() {
            return FluidVariant.blank();
        }

        @Override
        protected long getCapacity(FluidVariant variant) {
            return (FluidConstants.BUCKET / 81) * 8; // 1 Bucket = 81000 Droplets = 1000mB || * 16 ==> 16,000mB = 16 Buckets
        }

        @Override
        protected void onFinalCommit() {
            method_31663(field_11863, method_11016(), method_11010());
            method_10997().method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    };

    protected final class_3913 propertyDelegate;
    public ModBlastFurnaceBlockEntity(class_2338 pos, class_2680 blockState) {
        super(AlchemyBlockEntityType.BLAST_FURNACE_BLOCK_ENTITY_BLOCK_ENTITY_TYPE, pos, blockState);;
        heatContainer = new SimpleSidedHeatContainer() {
            @Override
            public long getCapacity() {
                return 50000;
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                if (side == null) return 300;
                return side == method_11010().method_11654(AbstractMachineblock.FACING) ? 300 : 0;
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                return 300;
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(pos, method_11010(), method_11010(), 3);
            }
        };
        this.inventory = class_2371.method_10213(12, class_1799.field_8037);
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> ModBlastFurnaceBlockEntity.this.progress;
                    case 1 -> ModBlastFurnaceBlockEntity.this.maxProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: ModBlastFurnaceBlockEntity.this.progress = value;
                    case 1: ModBlastFurnaceBlockEntity.this.maxProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };
    }

    @Override
    public void updateHeatInput() {
        receivingHeat = false;

        class_2350 direction = method_11010().method_11654(AbstractMachineblock.FACING);
        HeatStorage input = HeatStorage.SIDED.find(field_11863, field_11867.method_10093(direction), direction.method_10153());
        if (input == null) return;

        try (Transaction tx = Transaction.openOuter()) {
            long moved = input.extract(1, tx);

            if (moved > 0) {
                heatContainer.getSideStorage(null).insert(moved, tx);
                receivingHeat = true;
                tx.commit();
            }
        }
    }

    public void drops() {
        class_1264.method_17349(this.field_11863, this.field_11867, inventory);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) return;

        if (hasFluidStackInFluidSlot()) {
            fillUpFluidTank();
        }

        updateHeatInput();

        long cap = heatContainer.getSideStorage(null).getCapacity();
        long stored = heatContainer.getSideStorage(null).getAmount();
        boolean heated = stored >= cap;

        if (!receivingHeat && stored > 0) {
            try (Transaction tx = Transaction.openOuter()) {
                heatContainer.getSideStorage(null).extract(Math.min(20, stored), tx);
                tx.commit();
            }
        }

        if (heated && hasRecipe() && canInsertIntoOutputSlot()) {
            increaseCraftingProgress();
            method_31663(world, pos, state);

            if (hasCraftingFinished()) {
                craftItem();
                resetProgress();
            }
        } else {
            resetProgress();
        }

        boolean isWorking = heated && hasRecipe();

        if (state.method_11654(AbstractMachineblock.LIT) != isWorking) {
            world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, isWorking), 3);
        }
    }

    public boolean hasFluidStackInFluidSlot() {
        return FluidStorage.ITEM.find(inventory.get(FLUID_ITEM_SLOT), ContainerItemContext.withConstant(inventory.get(FLUID_ITEM_SLOT))) != null
                && FluidStorage.ITEM.find(inventory.get(FLUID_ITEM_SLOT), ContainerItemContext.withConstant(inventory.get(FLUID_ITEM_SLOT))).supportsExtraction()
                && FluidStorage.ITEM.find(inventory.get(FLUID_ITEM_SLOT), ContainerItemContext.withConstant(inventory.get(FLUID_ITEM_SLOT))) instanceof CombinedStorage<?, ?> combinedStorage
                && combinedStorage.parts.get(0) instanceof FullItemFluidStorage;
    }

    @Override
    public boolean hasCraftingFinished() {
        return this.progress >= this.maxProgress;
    }

    @Override
    public void resetProgress() {
        this.progress = 0;
    }

    public void fillUpFluidTank() {
        class_1799 inputStack = inventory.get(FLUID_ITEM_SLOT);
        var itemStorage = FluidStorage.ITEM.find(inputStack, ContainerItemContext.withConstant(inputStack));
        if (itemStorage == null || !itemStorage.supportsExtraction()
                || !(itemStorage instanceof CombinedStorage<?, ?> combinedStorage)
                || !(combinedStorage.parts.get(0) instanceof FullItemFluidStorage fluidStorage)) {
            return;
        }

        class_1799 craftRemainder = inputStack.method_7909() instanceof FluidCellItem
                ? new class_1799(GrowableOresItems.EMPTY_CELL)
                : (inputStack.method_7909().method_7857()
                   ? new class_1799(inputStack.method_7909().method_7858())
                   : new class_1799(class_1802.field_8550));

        if (!canAcceptFluid(fluidStorage) || !canStoreCraftRemainder(inputStack, craftRemainder)) {
            return;
        }

        try (Transaction transaction = Transaction.openOuter()) {
            long inserted = this.fluidContainer.insert(fluidStorage.getResource(), 1000, transaction);
            if (inserted != 1000) {
                return;
            }

            if (inputStack.method_7909() instanceof FluidCellItem) {
                inputStack.method_7934(1);
                storeCraftRemainder(craftRemainder);
            } else {
                inventory.set(FLUID_ITEM_SLOT, craftRemainder);
            }
            transaction.commit();
        }
    }

    private boolean canAcceptFluid(FullItemFluidStorage fluidStorage) {
        return (fluidContainer.getResource() == fluidStorage.getResource() || fluidContainer.isResourceBlank())
                && fluidContainer.getAmount() + 1000 <= fluidContainer.getCapacity();
    }

    private boolean canStoreCraftRemainder(class_1799 inputStack, class_1799 craftRemainder) {
        if (!(inputStack.method_7909() instanceof FluidCellItem)) {
            return true;
        }

        class_1799 remainderSlot = inventory.get(EMPTY_FLUID_ITEM_SLOT);
        return remainderSlot.method_7960()
                || (class_1799.method_31577(remainderSlot, craftRemainder)
                && remainderSlot.method_7947() + craftRemainder.method_7947() <= remainderSlot.method_7914());
    }

    private void storeCraftRemainder(class_1799 craftRemainder) {
        class_1799 remainderSlot = inventory.get(EMPTY_FLUID_ITEM_SLOT);
        if (remainderSlot.method_7960()) {
            inventory.set(EMPTY_FLUID_ITEM_SLOT, craftRemainder.method_7972());
        } else {
            remainderSlot.method_7933(craftRemainder.method_7947());
        }
    }

    @Override
    protected void craftItem() {
        ModBlastFurnaceCraftingRecipe recipe = (ModBlastFurnaceCraftingRecipe) getCurrentRecipe().get().comp_1933();
        this.method_5434(INPUT_SLOT, recipe.requiredCount());
        insertOutput(OUTPUT_SLOT, recipe.output().method_7972());
        recipe.output2().ifPresent(output -> insertOutput(OUTPUT_SLOT_2, output.method_7972()));
        try (Transaction tx = Transaction.openOuter()) {
            fluidContainer.extract(fluidContainer.getResource(), recipe.requiredFluidAmount(), tx);
            tx.commit();
        }
    }

    private void insertOutput(int slot, class_1799 output) {
        if (output.method_7960()) {
            return;
        }
        if (this.method_5438(slot).method_7960()) {
            this.method_5447(slot, output.method_7972());
        } else {
            this.method_5438(slot).method_7933(output.method_7947());
        }
    }

    /* SIDED INVENTORY */
    @Override
    public boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 side) {
        if (side == null || side == class_2350.field_11033) return false;
        if (side == class_2350.field_11036) return slot == INPUT_SLOT;

        if (slot != INPUT_SLOT && slot != FLUID_ITEM_SLOT) {
            return false;
        }

        class_2350 localDir = this.field_11863.method_8320(this.method_11016()).method_11654(AbstractMachineblock.FACING);
        return switch (slot) {
            case INPUT_SLOT, SECOND_INPUT_SLOT -> side != localDir.method_10153(); // If not Up/Down/Back, it must be Front/Left/Right
            case FLUID_ITEM_SLOT -> side == localDir.method_10170(); // Left
            default -> false; // Fallback
        };
    }

    @Override
    public boolean method_5493(int slot, class_1799 stack, class_2350 side) {
        if ((slot != OUTPUT_SLOT && slot != OUTPUT_SLOT_2) || side == class_2350.field_11036) {
            return false;
        }

        if (side == class_2350.field_11033) {
            return true;
        }

        class_2350 localDir = this.field_11863.method_8320(this.method_11016()).method_11654(AbstractMachineblock.FACING);
        return side == localDir.method_10153() || side == localDir.method_10170();
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return slot != OUTPUT_SLOT && slot != OUTPUT_SLOT_2;
    }

    @Override
    public int[] method_5494(class_2350 direction) {
        if (direction != class_2350.field_11033) {
            return new int[]{INPUT_SLOT, FLUID_ITEM_SLOT};
        } else {
            return new int[]{OUTPUT_SLOT, OUTPUT_SLOT_2};
        }
    }

    @Override
    public boolean hasRecipe() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> opt = getCurrentRecipe();
        if (opt.isEmpty()) return false;

        var recipeHolder = opt.get();
        var recipe = recipeHolder.comp_1933();
        ModBlastFurnaceCraftingRecipe washingRecipe = (ModBlastFurnaceCraftingRecipe) recipe;

        if (!canInsertIntoSlot(OUTPUT_SLOT, washingRecipe.output().method_7972())) return false;
        if (washingRecipe.output2().isPresent() && !canInsertIntoSlot(OUTPUT_SLOT_2, washingRecipe.output2().get().method_7972())) return false;

        class_3611 currentFluid = this.fluidContainer.getResource().getFluid();
        Optional<class_3611> requiredFluid = class_7923.field_41173.method_17966(washingRecipe.requiredFluid());
        return requiredFluid.isPresent()
                && requiredFluid.get().method_15780(currentFluid)
                && this.fluidContainer.getAmount() >= washingRecipe.requiredFluidAmount();
    }

    private boolean canInsertIntoSlot(int slot, class_1799 output) {
        if (output.method_7960()) {
            return true;
        }
        class_1799 stack = this.method_5438(slot);
        int maxCount = stack.method_7960() ? output.method_7914() : stack.method_7914();
        return (stack.method_7960() || class_1799.method_31577(stack, output))
                && maxCount >= stack.method_7947() + output.method_7947();
    }


    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Blast_Furnace);
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return AlchemyRecipeType.MOD_BLAST_FURNACE.type;
    }


    @org.jetbrains.annotations.Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new ModBlastFurnaceScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        class_1262.method_5426(nbt, inventory, registries);
        nbt.method_10569("blast_furnace_machine.progress", progress);
        nbt.method_10569("blast_furnace_machine.max_progress", maxProgress);
        nbt.method_10544("blast_furnace_machine.heat", heatContainer.amount);
        SingleVariantStorage.writeNbt(fluidContainer, FluidVariant.CODEC, nbt, registries);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        class_1262.method_5429(nbt, inventory, registries);
        progress = (nbt.method_10545("blast_furnace_machine.progress") ? nbt.method_10550("blast_furnace_machine.progress") : 0);
        maxProgress = (nbt.method_10545("blast_furnace_machine.max_progress") ? nbt.method_10550("blast_furnace_machine.max_progress") : maxProgress);
        heatContainer.amount = (nbt.method_10545("blast_furnace_machine.heat") ? nbt.method_10537("blast_furnace_machine.heat") : 0);
        SingleVariantStorage.readNbt(fluidContainer, FluidVariant.CODEC, FluidVariant::blank, nbt, registries);
        super.method_11014(nbt, registries);
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_58692(registryLookup);
    }

}
