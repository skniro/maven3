package com.skniro.industrial_elixir.screen.handler.machine;

import com.skniro.industrial_elixir.block.entity.machine.AbstractMachineEntity;
import com.skniro.industrial_elixir.block.entity.machine.ChunkLoaderEntity;
import com.skniro.industrial_elixir.block.entity.machine.VendorMachineBlockEntity;
import com.skniro.industrial_elixir.screen.AlchemyScreenHandlerType;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1645;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1725;
import net.minecraft.class_1727;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1914;
import net.minecraft.class_1915;
import net.minecraft.class_1916;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_9306;

public class VendorMachineScreenHandler extends class_1703 {
    protected static final int PAYMENT1_SLOT = 0;
    protected static final int PAYMENT2_SLOT = 1;
    protected static final int RESULT_SLOT = 2;
    private static final int INV_SLOT_START = 3;
    private static final int INV_SLOT_END = 30;
    private static final int USE_ROW_SLOT_START = 30;
    private static final int USE_ROW_SLOT_END = 39;
    private static final int SELLSLOT1_X = 136;
    private static final int SELLSLOT2_X = 162;
    private static final int BUYSLOT_X = 220;
    private static final int ROW_Y = 37;
    private final class_1915 trader;
    public final VendorMachineBlockEntity blockEntity;
    private final class_1725 tradeContainer;
    private int merchantLevel;
    private boolean showProgressBar;
    private boolean canRestock;

    public VendorMachineScreenHandler(final int containerId, final class_1661 playerInventory, class_2338 pos) {
        this(containerId, playerInventory, playerInventory.field_7546.method_37908().method_8321(pos), new class_1645(playerInventory.field_7546));
    }

    public VendorMachineScreenHandler(final int containerId, final class_1661 inventory, class_2586 blockEntity, final class_1915 merchant) {
        super(AlchemyScreenHandlerType.VendorMachine, containerId);
        this.trader = merchant;
        this.tradeContainer = new class_1725(merchant);
        this.blockEntity = (VendorMachineBlockEntity) blockEntity;
        this.method_7621(new class_1735(this.tradeContainer, 0, 136, 37));
        this.method_7621(new class_1735(this.tradeContainer, 1, 162, 37));
        this.method_7621(new class_1727(inventory.field_7546, merchant, this.tradeContainer, 2, 220, 37));
        this.addStandardInventorySlots(inventory, 108, 84);
    }

    /**
     * 1.21.1 replacement for {@code AbstractContainerMenu#addStandardInventorySlots}
     * (which only exists from 1.21.2 onwards).
     */
    private void addStandardInventorySlots(final class_1263 container, final int x, final int y) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new class_1735(container, col + (row + 1) * 9, x + col * 18, y + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.method_7621(new class_1735(container, col, x + col * 18, y + 58));
        }
    }

    public void setShowProgressBar(final boolean show) {
        this.showProgressBar = show;
    }

    public void method_7609(final class_1263 container) {
        this.tradeContainer.method_7645();
        super.method_7609(container);
    }

    public void setSelectionHint(final int hint) {
        this.tradeContainer.method_7643(hint);
    }

    public boolean method_7597(final class_1657 player) {
        if (this.blockEntity.method_10997() == null) {
            return false;
        }
        return class_1703.method_17695(
                net.minecraft.class_3914.method_17392(this.blockEntity.method_10997(), this.blockEntity.method_11016()),
                player,
                this.blockEntity.method_11010().method_26204());
    }

    public int getTraderXp() {
        return this.trader.method_19269();
    }

    public int getFutureTraderXp() {
        return this.tradeContainer.method_19252();
    }

    public void setXp(final int xp) {
        this.trader.method_19271(xp);
    }

    public int getTraderLevel() {
        return this.merchantLevel;
    }

    public void setMerchantLevel(final int level) {
        this.merchantLevel = level;
    }

    public void setCanRestock(final boolean canRestock) {
        this.canRestock = canRestock;
    }

    public boolean canRestock() {
        return this.canRestock;
    }

    public boolean method_7613(final class_1799 carried, final class_1735 target) {
        return false;
    }

    public class_1799 method_7601(final class_1657 player, final int slotIndex) {
        class_1799 clicked = class_1799.field_8037;
        class_1735 slot = (class_1735)this.field_7761.get(slotIndex);
        if (slot != null && slot.method_7681()) {
            class_1799 stack = slot.method_7677();
            clicked = stack.method_7972();
            if (slotIndex == 2) {
                if (!this.method_7616(stack, 3, 39, true)) {
                    return class_1799.field_8037;
                }

                slot.method_7670(stack, clicked);
                this.playTradeSound();
            } else if (slotIndex != 0 && slotIndex != 1) {
                if (slotIndex >= 3 && slotIndex < 30) {
                    if (!this.method_7616(stack, 30, 39, false)) {
                        return class_1799.field_8037;
                    }
                } else if (slotIndex >= 30 && slotIndex < 39 && !this.method_7616(stack, 3, 30, false)) {
                    return class_1799.field_8037;
                }
            } else if (!this.method_7616(stack, 3, 39, false)) {
                return class_1799.field_8037;
            }

            if (stack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            if (stack.method_7947() == clicked.method_7947()) {
                return class_1799.field_8037;
            }

            slot.method_7667(player, stack);
        }

        return clicked;
    }

    private void playTradeSound() {
        if (!this.trader.method_38069()) {
            class_1297 entity = (class_1297)this.trader;
            entity.method_37908().method_8486(entity.method_23317(), entity.method_23318(), entity.method_23321(), this.trader.method_18010(), class_3419.field_15254, 1.0F, 1.0F, false);
        }

    }

    public void method_7595(final class_1657 player) {
        super.method_7595(player);
        this.trader.method_8259((class_1657)null);
        if (!this.trader.method_38069()) {
            if (!player.method_5805() || player instanceof class_3222 && ((class_3222)player).method_14239()) {
                class_1799 itemStack = this.tradeContainer.method_5441(0);
                if (!itemStack.method_7960()) {
                    player.method_7328(itemStack, false);
                }

                itemStack = this.tradeContainer.method_5441(1);
                if (!itemStack.method_7960()) {
                    player.method_7328(itemStack, false);
                }
            } else if (player instanceof class_3222) {
                player.method_31548().method_7398(this.tradeContainer.method_5441(0));
                player.method_31548().method_7398(this.tradeContainer.method_5441(1));
            }

        }
    }

    public void tryMoveItems(final int newTradeIndex) {
        if (newTradeIndex >= 0 && this.getOffers().size() > newTradeIndex) {
            class_1799 oldCostA = this.tradeContainer.method_5438(0);
            if (!oldCostA.method_7960()) {
                if (!this.method_7616(oldCostA, 3, 39, true)) {
                    return;
                }

                this.tradeContainer.method_5447(0, oldCostA);
            }

            class_1799 oldCostB = this.tradeContainer.method_5438(1);
            if (!oldCostB.method_7960()) {
                if (!this.method_7616(oldCostB, 3, 39, true)) {
                    return;
                }

                this.tradeContainer.method_5447(1, oldCostB);
            }

            if (this.tradeContainer.method_5438(0).method_7960() && this.tradeContainer.method_5438(1).method_7960()) {
                class_1914 merchantOffer = (class_1914)this.getOffers().get(newTradeIndex);
                this.moveFromInventoryToPaymentSlot(0, merchantOffer.method_57556());
                merchantOffer.method_57557().ifPresent((costB) -> this.moveFromInventoryToPaymentSlot(1, costB));
            }

        }
    }

    private void moveFromInventoryToPaymentSlot(final int paymentSlot, final class_9306 cost) {
        for(int i = 3; i < 39; ++i) {
            class_1799 inventoryItem = ((class_1735)this.field_7761.get(i)).method_7677();
            if (!inventoryItem.method_7960() && cost.method_57552(inventoryItem)) {
                class_1799 currentPaymentItem = this.tradeContainer.method_5438(paymentSlot);
                if (currentPaymentItem.method_7960() || class_1799.method_31577(inventoryItem, currentPaymentItem)) {
                    int maxStackSize = inventoryItem.method_7914();
                    int moveCount = Math.min(maxStackSize - currentPaymentItem.method_7947(), inventoryItem.method_7947());
                    class_1799 newPaymentItem = inventoryItem.method_46651(currentPaymentItem.method_7947() + moveCount);
                    inventoryItem.method_7934(moveCount);
                    this.tradeContainer.method_5447(paymentSlot, newPaymentItem);
                    if (newPaymentItem.method_7947() >= maxStackSize) {
                        break;
                    }
                }
            }
        }

    }

    public void setOffers(final class_1916 offers) {
        this.trader.method_8261(offers);
    }

    public class_1916 getOffers() {
        return this.blockEntity.method_8264();
    }

    public boolean showProgressBar() {
        return this.showProgressBar;
    }
}