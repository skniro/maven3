package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import com.skniro.skniro_furniture.block.entity.BedsideCabinetBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3468;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import com.skniro.skniro_furniture.block.entity.BedsideCabinetBlockEntity;
import org.jetbrains.annotations.Nullable;


public class BedsideCabinetBlock extends AbstractFurnitureContainerBlock {
    public static final MapCodec<BedsideCabinetBlock> CODEC = method_54094(BedsideCabinetBlock::new);

    public MapCodec<BedsideCabinetBlock> method_53969() {
        return field_46280;
    }

    public BedsideCabinetBlock(class_2251 settings) {
        super(settings);
        this.method_9590((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043)));
    }

    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (world instanceof class_3218 serverWorld) {
            class_2586 var8 = world.method_8321(pos);
            if (var8 instanceof BedsideCabinetBlockEntity BedsideCabinetBlockEntity) {
                player.method_17355(BedsideCabinetBlockEntity);
                player.method_7281(class_3468.field_17271);
            }
        }

        return class_1269.field_5812;
    }

    public void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof BedsideCabinetBlockEntity) {
            ((BedsideCabinetBlockEntity)blockEntity).tick();
        }

    }

    @Nullable
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new BedsideCabinetBlockEntity(pos, state);
    }
}
