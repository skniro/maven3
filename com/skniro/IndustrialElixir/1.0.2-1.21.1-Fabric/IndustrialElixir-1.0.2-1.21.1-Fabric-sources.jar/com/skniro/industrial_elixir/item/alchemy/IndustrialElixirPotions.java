package com.skniro.industrial_elixir.item.alchemy;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.Helper;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1842;
import net.minecraft.class_2378;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class IndustrialElixirPotions {
    public static final class_6880.class_6883<class_1842> SUPER_LEAPING = register("super_leaping", new class_1842("leaping", new class_1293[]{new class_1293(class_1294.field_5913, 1800, 3)}));
    public static final class_6880.class_6883<class_1842> SUPER_SWIFTNESS = register("super_swiftness", new class_1842("swiftness", new class_1293[]{new class_1293(class_1294.field_5904, 1800, 3)}));
    public static final class_6880.class_6883<class_1842> SUPER_SLOWNESS = register("super_slowness", new class_1842("slowness", new class_1293[]{new class_1293(class_1294.field_5909, 400, 5)}));
    public static final class_6880.class_6883<class_1842> SUPER_TURTLE_MASTER = register("super_turtle_master", new class_1842("turtle_master", new class_1293[]{new class_1293(class_1294.field_5909, 400, 7), new class_1293(class_1294.field_5907, 400, 5)}));
    public static final class_6880.class_6883<class_1842> SUPER_HEALING = register("super_healing", new class_1842("healing", new class_1293[]{new class_1293(class_1294.field_5915, 1, 3)}));
    public static final class_6880.class_6883<class_1842> SUPER_HARMING = register("super_harming", new class_1842("harming", new class_1293[]{new class_1293(class_1294.field_5921, 1, 3)}));
    public static final class_6880.class_6883<class_1842> SUPER_POISON = register("super_poison", new class_1842("poison", new class_1293[]{new class_1293(class_1294.field_5899, 432, 3)}));
    public static final class_6880.class_6883<class_1842> SUPER_REGENERATION = register("super_regeneration", new class_1842("regeneration", new class_1293[]{new class_1293(class_1294.field_5924, 450, 3)}));
    public static final class_6880.class_6883<class_1842> SUPER_STRENGTH = register("super_strength", new class_1842("strength", new class_1293[]{new class_1293(class_1294.field_5910, 1800, 3)}));

    private static class_6880.class_6883<class_1842> register(final String name, final class_1842 potion) {
        return class_2378.method_47985(class_7923.field_41179, Helper.id(name), potion);
    }

    public static void registerPotions(){
        IndustrialElixir.LOGGER.debug("register Advanced Item.");
    }
}