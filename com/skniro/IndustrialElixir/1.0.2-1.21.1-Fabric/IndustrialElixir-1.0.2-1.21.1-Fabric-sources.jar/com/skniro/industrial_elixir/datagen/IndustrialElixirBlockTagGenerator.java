package com.skniro.industrial_elixir.datagen;

import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3481;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

import static net.minecraft.class_3481.*;

public class IndustrialElixirBlockTagGenerator extends FabricTagProvider.BlockTagProvider {
   public IndustrialElixirBlockTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
   }
   @Override
   protected void method_10514(class_7225.class_7874 arg) {
      getOrCreateTagBuilder(field_33715)
              .add(GeneralBlocks.Deepslate_Lead_Ore)
              .add(GeneralBlocks.Deepslate_Tin_Ore)
              .add(GeneralBlocks.Deepslate_SACRED_Ore)
              .add(GeneralBlocks.Lead_Ore)
              .add(GeneralBlocks.Tin_Ore)
              .add(GeneralBlocks.SACRED_Ore)
              .add(GrowableOresBlocks.GrowableOres_Block)
              .add(GrowableOresBlocks.Macerator_Block,
                      GrowableOresBlocks.Compressor_Block,
                      GrowableOresBlocks.MetalFormerBlock,

                      GrowableOresBlocks.COPPER_CABLE,
                      GrowableOresBlocks.TIN_CABLE,
                      GrowableOresBlocks.GOLD_CABLE,
                      GrowableOresBlocks.HV_CABLE,
                      GrowableOresBlocks.GLASSFIBER_CABLE,

                      GrowableOresBlocks.INSULATED_TIN_CABLE,
                      GrowableOresBlocks.INSULATED_COPPER_CABLE,
                      GrowableOresBlocks.INSULATED_GOLD_CABLE,
                      GrowableOresBlocks.INSULATED_HV_CABLE,

                      GrowableOresBlocks.COAL_GENERATOR,
                      GrowableOresBlocks.GENERATOR_Wind_Mill,

                      GrowableOresBlocks.EnergyBox,
                      GrowableOresBlocks.ChargePad,
                      GrowableOresBlocks.CESU,
                      GrowableOresBlocks.MFE,
                      GrowableOresBlocks.MFSU,

                      GrowableOresBlocks.CESU_CHARGE_PAD,
                      GrowableOresBlocks.MFE_CHARGE_PAD,
                      GrowableOresBlocks.MFSU_CHARGE_PAD,

                      GrowableOresBlocks.MolecularTransformerBlock,

                      GrowableOresBlocks.GENERATOR_SolarPanel,
                      GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL,
                      GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL,
                      GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL,
                      GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL,

                      GrowableOresBlocks.Extractor_Block,

                      GrowableOresBlocks.EV_TRANSFORMER,
                      GrowableOresBlocks.HV_TRANSFORMER,
                      GrowableOresBlocks.MV_TRANSFORMER,
                      GrowableOresBlocks.LV_TRANSFORMER,

                      GrowableOresBlocks.Iron_Furnace_Block,
                      GeneralBlocks.Raw_Lead_Block,
                      GeneralBlocks.Raw_Tin_Block,
                      GeneralBlocks.Raw_SACRED_Block,

                      GeneralBlocks.Lead_Block,
                      GeneralBlocks.Tin_Block,
                      GeneralBlocks.SACRED_Block,
                      GeneralBlocks.Silver_Block,
                      GeneralBlocks.Bronze_Block,
                      GeneralBlocks.Steel_Block,

                      GeneralBlocks.Advanced_Machine,
                      GeneralBlocks.Machine,
                      GrowableOresBlocks.ElectricFurnace_Block,
                      GrowableOresBlocks.RECYCLER_Block,
                      GrowableOresBlocks.CUTTING_Block,

                      GrowableOresBlocks.MATTER_GENERATOR,
                      GrowableOresBlocks.FLUID_GENERATOR,
                      GrowableOresBlocks.NUCLEAR_REACTOR,
                      GrowableOresBlocks.SACRED_GENERATOR,
                      GrowableOresBlocks.INDUCTION_FURNACE,
                      GrowableOresBlocks.HEAT_CENTRIFUGE,
                      GrowableOresBlocks.PATTERN_STORAGE,

                      GrowableOresBlocks.Pipe_Wooden_Iten_Block,
                      GrowableOresBlocks.Pipe_Stone_Item_Block,
                      GrowableOresBlocks.Pipe_Wooden_Fluid_Block,
                      GrowableOresBlocks.Pipe_Stone_Fluid_Block,

                      GrowableOresBlocks.FLUID_TANK_BLOCK,
                      GrowableOresBlocks.Brew_Reactor_BLOCK,
                      GrowableOresBlocks.Ore_Washing_Block,
                      GrowableOresBlocks.Replicator,

                      GrowableOresBlocks.CHUNK_LOADER,
                      GrowableOresBlocks.Electric_Heater_Block,
                      GrowableOresBlocks.SOLID_FUEL_HEATER_GENERATOR,
                      GrowableOresBlocks.BLAST_FURNACE_BLOCK,
                      GrowableOresBlocks.VENDOR_MACHINE_Block,
                      GrowableOresBlocks.CROP_FARM_Block,
                      GrowableOresBlocks.COFFEE_MACHINE_Block)
              .setReplace(false);
      getOrCreateTagBuilder(field_33718)
              .add(GeneralBlocks.Deepslate_Lead_Ore)
              .add(GeneralBlocks.Deepslate_SACRED_Ore)
              .add(GeneralBlocks.Lead_Ore)
              .add(GeneralBlocks.SACRED_Ore)
              .add(GrowableOresBlocks.Macerator_Block,
                      GrowableOresBlocks.Compressor_Block,
                      GrowableOresBlocks.MetalFormerBlock,

                      GrowableOresBlocks.GOLD_CABLE,
                      GrowableOresBlocks.HV_CABLE,
                      GrowableOresBlocks.GLASSFIBER_CABLE,

                      GrowableOresBlocks.INSULATED_TIN_CABLE,
                      GrowableOresBlocks.INSULATED_COPPER_CABLE,
                      GrowableOresBlocks.INSULATED_GOLD_CABLE,
                      GrowableOresBlocks.INSULATED_HV_CABLE,

                      GrowableOresBlocks.COAL_GENERATOR,
                      GrowableOresBlocks.GENERATOR_Wind_Mill,

                      GrowableOresBlocks.CESU,
                      GrowableOresBlocks.MFE,
                      GrowableOresBlocks.MFSU,

                      GrowableOresBlocks.CESU_CHARGE_PAD,
                      GrowableOresBlocks.MFE_CHARGE_PAD,
                      GrowableOresBlocks.MFSU_CHARGE_PAD,

                      GrowableOresBlocks.MolecularTransformerBlock,

                      GrowableOresBlocks.GENERATOR_SolarPanel,
                      GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL,
                      GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL,
                      GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL,
                      GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL,

                      GrowableOresBlocks.Extractor_Block,

                      GrowableOresBlocks.HV_TRANSFORMER,
                      GrowableOresBlocks.MV_TRANSFORMER,
                      GrowableOresBlocks.LV_TRANSFORMER,

                      GrowableOresBlocks.Iron_Furnace_Block,
                      GeneralBlocks.Raw_Lead_Block,
                      GeneralBlocks.Raw_SACRED_Block,

                      GeneralBlocks.Lead_Block,
                      GeneralBlocks.SACRED_Block,
                      GeneralBlocks.Silver_Block,
                      GeneralBlocks.Bronze_Block,
                      GeneralBlocks.Steel_Block,

                      GrowableOresBlocks.ElectricFurnace_Block,
                      GrowableOresBlocks.RECYCLER_Block,
                      GrowableOresBlocks.CUTTING_Block,

                      GrowableOresBlocks.MATTER_GENERATOR,
                      GrowableOresBlocks.FLUID_GENERATOR,
                      GrowableOresBlocks.NUCLEAR_REACTOR,
                      GrowableOresBlocks.SACRED_GENERATOR,
                      GrowableOresBlocks.INDUCTION_FURNACE,
                      GrowableOresBlocks.HEAT_CENTRIFUGE,
                      GrowableOresBlocks.PATTERN_STORAGE,

                      GrowableOresBlocks.Pipe_Wooden_Iten_Block,
                      GrowableOresBlocks.Pipe_Stone_Item_Block,
                      GrowableOresBlocks.Pipe_Wooden_Fluid_Block,
                      GrowableOresBlocks.Pipe_Stone_Fluid_Block,

                      GrowableOresBlocks.FLUID_TANK_BLOCK,
                      GrowableOresBlocks.Brew_Reactor_BLOCK,
                      GrowableOresBlocks.Ore_Washing_Block,
                      GrowableOresBlocks.Replicator,

                      GrowableOresBlocks.CHUNK_LOADER,
                      GrowableOresBlocks.Electric_Heater_Block,
                      GrowableOresBlocks.SOLID_FUEL_HEATER_GENERATOR,
                      GrowableOresBlocks.BLAST_FURNACE_BLOCK,
                      GrowableOresBlocks.VENDOR_MACHINE_Block,
                      GrowableOresBlocks.CROP_FARM_Block,
                      GrowableOresBlocks.COFFEE_MACHINE_Block)
              .setReplace(false);
      getOrCreateTagBuilder(field_33719)
              .add(GeneralBlocks.Deepslate_Tin_Ore)
              .add(GeneralBlocks.Tin_Ore)
              .add(GeneralBlocks.Advanced_Machine,
                      GeneralBlocks.Machine,
                      GeneralBlocks.Tin_Block,
                      GeneralBlocks.Raw_Tin_Block,
                      GrowableOresBlocks.TIN_CABLE,
                      GrowableOresBlocks.COPPER_CABLE,
                      GrowableOresBlocks.EV_TRANSFORMER,
                      GrowableOresBlocks.EnergyBox,
                      GrowableOresBlocks.ChargePad)
              .setReplace(false);
      getOrCreateTagBuilder(class_3481.field_15503)
              .add(GeneralBlocks.Rubber_LEAVES)
              .setReplace(false);
      getOrCreateTagBuilder(class_3481.field_15462)
              .add(GeneralBlocks.Rubber_SAPLING)
              .setReplace(false);
      getOrCreateTagBuilder(field_23210)
              .add(GeneralBlocks.Rubber_LOG)
              .add(GeneralBlocks.Rubber_Rubber_LOG)
              .add(GeneralBlocks.Rubber_WOOD)
              .add(GeneralBlocks.STRIPPED_Rubber_LOG)
              .add(GeneralBlocks.STRIPPED_Rubber_WOOD)
              .setReplace(false);
      getOrCreateTagBuilder(field_15499)
              .add(GeneralBlocks.Rubber_BUTTON)
              .setReplace(false);
      getOrCreateTagBuilder(field_15494)
              .add(GeneralBlocks.Rubber_DOOR)
              .setReplace(false);
      getOrCreateTagBuilder(field_15491)
              .add(GeneralBlocks.Rubber_TRAPDOOR)
              .setReplace(false);
      getOrCreateTagBuilder(field_15477)
              .add(GeneralBlocks.Rubber_PRESSURE_PLATE)
              .setReplace(false);
      getOrCreateTagBuilder(field_15468)
              .add(GeneralBlocks.Rubber_SLAB)
              .setReplace(false);
      getOrCreateTagBuilder(field_15502)
              .add(GeneralBlocks.Rubber_STAIRS)
              .setReplace(false);
      getOrCreateTagBuilder(field_15471)
              .add(GeneralBlocks.Rubber_PLANKS)
              .setReplace(false);
      getOrCreateTagBuilder(field_16584)
              .add(GeneralBlocks.Rubber_FENCE)
              .setReplace(false);
      getOrCreateTagBuilder(field_15495)
              .add(GeneralBlocks.Reinforced_DOOR)
              .setReplace(false);
      getOrCreateTagBuilder(field_15459)
              .add(GeneralBlocks.COBBLESTONE_STAIRS)
              .setReplace(false);

   }
}