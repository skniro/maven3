package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.growableoresir.GrowableOres;
import com.skniro.industrial_elixir.api.data.recipe.CraftingDataHelper;
import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.item.alchemy.IndustrialElixirPotions;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_1802;
import net.minecraft.class_1847;
import net.minecraft.class_3612;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class BrewReactorRecipeGenerator extends CraftingDataHelper {
    public BrewReactorRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                createBrewReactor(potionTemplate(registriesFuture.join(), IndustrialElixirPotions.SUPER_LEAPING)).fluid(class_3612.field_15910, 1000).input(class_1802.field_8073, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_8073)).method_36443(output, "rabbit_foot_to_super_leaping");
                createBrewReactor(potionTemplate(registriesFuture.join(), IndustrialElixirPotions.SUPER_SWIFTNESS)).fluid(class_3612.field_15910, 1000).input(class_1802.field_8479, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_8479)).method_36443(output, "sugar_to_super_swiftness");
                createBrewReactor(potionTemplate(registriesFuture.join(), IndustrialElixirPotions.SUPER_SLOWNESS)).fluid(class_3612.field_15910, 1000).input(class_1802.field_8073, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_8073)).method_36443(output, "rabbit_foot_to_super_slowness");
                createBrewReactor(potionTemplate(registriesFuture.join(), IndustrialElixirPotions.SUPER_TURTLE_MASTER)).fluid(class_3612.field_15910, 1000).input(class_1802.field_8090, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_8090)).method_36443(output, "turtle_helmet_to_super_turtle_master");
                createBrewReactor(potionTemplate(registriesFuture.join(), IndustrialElixirPotions.SUPER_HEALING)).fluid(class_3612.field_15910, 1000).input(class_1802.field_8711, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_8597)).method_36443(output, "fermented_spider_eye_to_super_healing");
                createBrewReactor(potionTemplate(registriesFuture.join(), IndustrialElixirPotions.SUPER_HARMING)).fluid(class_3612.field_15910, 1000).input(class_1802.field_8597, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_8597)).method_36443(output, "glistering_melon_slice_to_super_harming");
                createBrewReactor(potionTemplate(registriesFuture.join(), IndustrialElixirPotions.SUPER_POISON)).fluid(class_3612.field_15910, 1000).input(class_1802.field_8680, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_8680)).method_36443(output, "spider_eye_to_super_poison");
                createBrewReactor(potionTemplate(registriesFuture.join(), IndustrialElixirPotions.SUPER_REGENERATION)).fluid(class_3612.field_15910, 1000).input(class_1802.field_8070, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_8070)).method_36443(output, "ghast_tear_to_super_regeneration");
                createBrewReactor(potionTemplate(registriesFuture.join(), IndustrialElixirPotions.SUPER_STRENGTH)).fluid(class_3612.field_15910, 1000).input(class_1802.field_8183, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_8183)).method_36443(output, "blaze_powder_to_super_strength");
                createBrewReactor(potionTemplate(registriesFuture.join(), class_1847.field_50153)).fluid(class_3612.field_15910, 1000).input(class_1802.field_49821, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_49821)).method_36443(output, "breeze_rod_to_wind_charged");
                createBrewReactor(potionTemplate(registriesFuture.join(), class_1847.field_50154)).fluid(class_3612.field_15910, 1000).input(class_1802.field_8786, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_8786)).method_36443(output, "cobweb_to_weaving");
                createBrewReactor(potionTemplate(registriesFuture.join(), class_1847.field_50155)).fluid(class_3612.field_15910, 1000).input(class_1802.field_8828, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_8828)).method_36443(output, "slime_block_to_oozing");
                createBrewReactor(potionTemplate(registriesFuture.join(), class_1847.field_50156)).fluid(class_3612.field_15910, 1000).input(class_1802.field_20391, 1).input2(class_1802.field_8469).method_33530("has_base_item", has(class_1802.field_20391)).method_36443(output, "stone_to_infested");
                createBrewReactor(GrowableOresItems.SACRED_ESSENCE).input(GrowableOresItems.IMPURE_SACRED_STONE, 1).input2(GrowableOresItems.EMPTY_VESSEL).method_33530("has_base_item", has(GrowableOresItems.EMPTY_VESSEL)).method_36443(output, "sacred_essence");
            }
        };
    }

    @Override
    public String method_10321() {
        return "BrewReactor";
    }
}
