package com.skniro.skniro_furniture.block.init;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.skniro_furniture.block.entity.FurnitureBedBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_10821;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_156;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_1941;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2742;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.minecraft.class_3532;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_4732;
import net.minecraft.class_4970;
import net.minecraft.class_4990;
import net.minecraft.class_5275;
import net.minecraft.class_5819;
import net.minecraft.util.math.*;
import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public class FurnitureBedBlock extends class_2244 implements class_2343 {
    public static final MapCodec<FurnitureBedBlock> CODEC = RecordCodecBuilder.mapCodec((instance) -> instance.group(class_1767.field_41600.fieldOf("color").forGetter(FurnitureBedBlock::method_9487), method_54096()).apply(instance, FurnitureBedBlock::new));
    public static final class_2754<class_2742> field_9967;
    public static final class_2746 field_9968;
    private static final Map SHAPES_BY_DIRECTION;
    private final class_1767 color;

    public FurnitureBedBlock(class_1767 color, class_4970.class_2251 settings) {
        super(color, settings);
        this.color = color;
        this.method_9590((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_9967, class_2742.field_12557)).method_11657(field_9968, false));
    }

    public boolean method_9538(class_2680 state) {
        return true;
    }

    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new FurnitureBedBlockEntity(pos, state, this.color);
    }

/*    protected ItemStack getPickStack(WorldView world, BlockPos pos, BlockState state, boolean includeData) {
        BlockEntity var6 = world.getBlockEntity(pos);
        if (var6 instanceof FurnitureBedBlockEntity CustomBedBlockEntity) {
            return CustomBedBlockEntity.getPickStack();
        } else {
            return super.getPickStack(world, pos, state, includeData);
        }
    }*/

    public class_1767 method_9487() {
        return this.color;
    }

    @Nullable
    public static class_2350 method_18476(class_1922 world, class_2338 pos) {
        class_2680 blockState = world.method_8320(pos);
        return blockState.method_26204() instanceof FurnitureBedBlock ? (class_2350)blockState.method_11654(field_11177) : null;
    }

    @Nullable
    public boolean method_9522(class_2680 state, class_2680 neighborState, class_2350 offset) {
        return neighborState.method_26204() instanceof FurnitureBedBlock;
    }

    public static boolean method_27352(class_1937 world) {
        return world.method_8597().comp_648();
    }

    private boolean method_22357(class_1937 world, class_2338 pos) {
        List<class_1646> list = world.method_8390(class_1646.class, new class_238(pos), class_1309::method_6113);
        if (list.isEmpty()) {
            return false;
        } else {
            ((class_1646)list.get(0)).method_18400();
            return true;
        }
    }

    public void method_9554(class_1937 world, class_2680 state, class_2338 pos, class_1297 entity, double fallDistance) {
        super.method_9554(world, state, pos, entity, fallDistance * (double)0.5F);
    }

    public void method_9502(class_1922 world, class_1297 entity) {
        if (entity.method_21750()) {
            super.method_9502(world, entity);
        } else {
            this.method_21838(entity);
        }

    }

    private void method_21838(class_1297 entity) {
        class_243 vec3d = entity.method_18798();
        if (vec3d.field_1351 < (double)0.0F) {
            double d = entity instanceof class_1309 ? (double)1.0F : 0.8;
            entity.method_18800(vec3d.field_1352, -vec3d.field_1351 * (double)0.66F * d, vec3d.field_1350);
        }

    }

    protected class_2680 method_9559(class_2680 state, class_4538 world, class_10225 tickView, class_2338 pos, class_2350 direction, class_2338 neighborPos, class_2680 neighborState, class_5819 random) {
        if (direction == method_9488((class_2742)state.method_11654(field_9967), (class_2350)state.method_11654(field_11177))) {
            return neighborState.method_27852(this) && neighborState.method_11654(field_9967) != state.method_11654(field_9967) ? (class_2680)state.method_11657(field_9968, (Boolean)neighborState.method_11654(field_9968)) : class_2246.field_10124.method_9564();
        } else {
            return super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
        }
    }

    private static class_2350 method_9488(class_2742 part, class_2350 direction) {
        return part == class_2742.field_12557 ? direction : direction.method_10153();
    }

    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        if (!world.method_8608() && player.method_66324()) {
            class_2742 bedPart = (class_2742)state.method_11654(field_9967);
            if (bedPart == class_2742.field_12557) {
                class_2338 blockPos = pos.method_10093(method_9488(bedPart, (class_2350)state.method_11654(field_11177)));
                class_2680 blockState = world.method_8320(blockPos);
                if (blockState.method_27852(this) && blockState.method_11654(field_9967) == class_2742.field_12560) {
                    world.method_8652(blockPos, class_2246.field_10124.method_9564(), 35);
                    world.method_8444(player, 2001, blockPos, class_2248.method_9507(blockState));
                }
            }
        }

        return super.method_9576(world, pos, state, player);
    }

    @Nullable
    public class_2680 method_9605(class_1750 ctx) {
        class_2350 direction = ctx.method_8042();
        class_2338 blockPos = ctx.method_8037();
        class_2338 blockPos2 = blockPos.method_10093(direction);
        class_1937 world = ctx.method_8045();
        return world.method_8320(blockPos2).method_26166(ctx) && world.method_8621().method_11952(blockPos2) ? (class_2680)this.method_9564().method_11657(field_11177, direction) : null;
    }

    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return (class_265)SHAPES_BY_DIRECTION.get(method_24163(state).method_10153());
    }

    public static class_2350 method_24163(class_2680 state) {
        class_2350 direction = (class_2350)state.method_11654(field_11177);
        return state.method_11654(field_9967) == class_2742.field_12560 ? direction.method_10153() : direction;
    }

    public static class_4732.class_4733 method_24164(class_2680 state) {
        class_2742 bedPart = (class_2742)state.method_11654(field_9967);
        return bedPart == class_2742.field_12560 ? class_4732.class_4733.field_21784 : class_4732.class_4733.field_21785;
    }

    private static boolean method_30839(class_1922 world, class_2338 pos) {
        return world.method_8320(pos.method_10074()).method_26204() instanceof FurnitureBedBlock;
    }

    public static Optional<class_243> method_9484(class_1299<?> type, class_1941 world, class_2338 pos, class_2350 bedDirection, float spawnAngle) {
        class_2350 direction = bedDirection.method_10170();
        class_2350 direction2 = direction.method_30928(spawnAngle) ? direction.method_10153() : direction;
        if (method_30839(world, pos)) {
            return method_30835(type, world, pos, bedDirection, direction2);
        } else {
            int[][] is = method_30838(bedDirection, direction2);
            Optional<class_243> optional = method_30836(type, world, pos, is, true);
            return optional.isPresent() ? optional : method_30836(type, world, pos, is, false);
        }
    }

    private static Optional<class_243> method_30835(class_1299<?> type, class_1941 world, class_2338 pos, class_2350 bedDirection, class_2350 respawnDirection) {
        int[][] is = method_30840(bedDirection, respawnDirection);
        Optional<class_243> optional = method_30836(type, world, pos, is, true);
        if (optional.isPresent()) {
            return optional;
        } else {
            class_2338 blockPos = pos.method_10074();
            Optional<class_243> optional2 = method_30836(type, world, blockPos, is, true);
            if (optional2.isPresent()) {
                return optional2;
            } else {
                int[][] js = method_30837(bedDirection);
                Optional<class_243> optional3 = method_30836(type, world, pos, js, true);
                if (optional3.isPresent()) {
                    return optional3;
                } else {
                    Optional<class_243> optional4 = method_30836(type, world, pos, is, false);
                    if (optional4.isPresent()) {
                        return optional4;
                    } else {
                        Optional<class_243> optional5 = method_30836(type, world, blockPos, is, false);
                        return optional5.isPresent() ? optional5 : method_30836(type, world, pos, js, false);
                    }
                }
            }
        }
    }

    private static Optional<class_243> method_30836(class_1299<?> type, class_1941 world, class_2338 pos, int[][] possibleOffsets, boolean ignoreInvalidPos) {
        class_2338.class_2339 mutable = new class_2338.class_2339();

        for(int[] is : possibleOffsets) {
            mutable.method_10103(pos.method_10263() + is[0], pos.method_10264(), pos.method_10260() + is[1]);
            class_243 vec3d = class_5275.method_30769(type, world, mutable, ignoreInvalidPos);
            if (vec3d != null) {
                return Optional.of(vec3d);
            }
        }

        return Optional.empty();
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{field_11177, field_9967, field_9968});
    }

    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        super.method_9567(world, pos, state, placer, itemStack);
        if (!world.method_8608()) {
            class_2338 blockPos = pos.method_10093((class_2350)state.method_11654(field_11177));
            world.method_8652(blockPos, (class_2680)state.method_11657(field_9967, class_2742.field_12560), 3);
            world.method_8408(pos, class_2246.field_10124);
            state.method_30101(world, pos, 3);
        }

    }

    protected long method_9535(class_2680 state, class_2338 pos) {
        class_2338 blockPos = pos.method_10079((class_2350)state.method_11654(field_11177), state.method_11654(field_9967) == class_2742.field_12560 ? 0 : 1);
        return class_3532.method_15371(blockPos.method_10263(), pos.method_10264(), blockPos.method_10260());
    }

    protected boolean method_9516(class_2680 state, class_10 type) {
        return false;
    }

    private static int[][] method_30838(class_2350 bedDirection, class_2350 respawnDirection) {
        return (int[][]) ArrayUtils.addAll(method_30840(bedDirection, respawnDirection), method_30837(bedDirection));
    }

    private static int[][] method_30840(class_2350 bedDirection, class_2350 respawnDirection) {
        return new int[][]{{respawnDirection.method_10148(), respawnDirection.method_10165()}, {respawnDirection.method_10148() - bedDirection.method_10148(), respawnDirection.method_10165() - bedDirection.method_10165()}, {respawnDirection.method_10148() - bedDirection.method_10148() * 2, respawnDirection.method_10165() - bedDirection.method_10165() * 2}, {-bedDirection.method_10148() * 2, -bedDirection.method_10165() * 2}, {-respawnDirection.method_10148() - bedDirection.method_10148() * 2, -respawnDirection.method_10165() - bedDirection.method_10165() * 2}, {-respawnDirection.method_10148() - bedDirection.method_10148(), -respawnDirection.method_10165() - bedDirection.method_10165()}, {-respawnDirection.method_10148(), -respawnDirection.method_10165()}, {-respawnDirection.method_10148() + bedDirection.method_10148(), -respawnDirection.method_10165() + bedDirection.method_10165()}, {bedDirection.method_10148(), bedDirection.method_10165()}, {respawnDirection.method_10148() + bedDirection.method_10148(), respawnDirection.method_10165() + bedDirection.method_10165()}};
    }

    private static int[][] method_30837(class_2350 bedDirection) {
        return new int[][]{{0, 0}, {-bedDirection.method_10148(), -bedDirection.method_10165()}};
    }

    static {
        field_9967 = class_2741.field_12483;
        field_9968 = class_2741.field_12528;
        SHAPES_BY_DIRECTION = (Map)class_156.method_656(() -> {
            class_265 voxelShape = class_2248.method_9541((double)0.0F, (double)0.0F, (double)0.0F, (double)2.0F, (double)2.0F, (double)2.0F);
            class_265 voxelShape2 = class_259.method_66496(voxelShape, class_4990.method_67986(class_10821.field_57029, class_10821.field_57030));
            return class_259.method_66501(class_259.method_17786(class_2248.method_66404((double)16.0F, (double)2.0F, (double)7.5F), new class_265[]{voxelShape, voxelShape2}));
        });
    }
}
