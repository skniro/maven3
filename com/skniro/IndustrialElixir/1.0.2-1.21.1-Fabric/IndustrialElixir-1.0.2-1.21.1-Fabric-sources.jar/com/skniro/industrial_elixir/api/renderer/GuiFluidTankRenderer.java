package com.skniro.industrial_elixir.api.renderer;

import com.google.common.base.Preconditions;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluids;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3612;
import net.minecraft.class_5250;
import net.minecraft.class_7923;
import net.minecraft.class_8012;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

// CREDIT: https://github.com/mezz/JustEnoughItems by mezz
//         https://github.com/Tutorials-By-Kaupenjoe by Kaupenjoe
// Under MIT-License: https://github.com/mezz/JustEnoughItems/blob/1.19/LICENSE.txt
//                    https://github.com/Tutorials-By-Kaupenjoe/Fabric-Course-26.X/blob/main/LICENSE
// Includes major rewrites and methods from:
// https://github.com/mezz/JustEnoughItems/blob/1.19/Forge/src/main/java/mezz/jei/forge/platform/FluidHelper.java
// Major rewrites from Kaupenjoe
public class GuiFluidTankRenderer {
    private static final NumberFormat nf = NumberFormat.getIntegerInstance();
    private static final int MIN_FLUID_HEIGHT = 1;
    public final long capacityMb;
    private final TooltipMode tooltipMode;
    private final int width;
    private final int height;

    private static final class_2960 STILL_FLUID_TEXTURE = class_2960.method_60655(IndustrialElixir.MOD_ID,
            "textures/gui/still_fluid.png");

    /** 1.21.1 {@link class_8012} has no dark variants; keep the 26.1 values. */
    private static final int DARK_GRAY = 0xFF404040;
    private static final int DARK_PURPLE = 0xFF501E50;

    enum TooltipMode {
        SHOW_AMOUNT,
        SHOW_AMOUNT_AND_CAPACITY,
        ITEM_LIST
    }

    public GuiFluidTankRenderer(long capacity, boolean showCapacity, int width, int height) {
        this(capacity, showCapacity ? TooltipMode.SHOW_AMOUNT_AND_CAPACITY : TooltipMode.SHOW_AMOUNT, width, height);
    }

    private GuiFluidTankRenderer(long capacity, TooltipMode tooltipMode, int width, int height) {
        Preconditions.checkArgument(capacity > 0, "capacity must be > 0");
        Preconditions.checkArgument(width > 0, "width must be > 0");
        Preconditions.checkArgument(height > 0, "height must be > 0");

        this.capacityMb = capacity;
        this.tooltipMode = tooltipMode;
        this.width = width;
        this.height = height;
    }

    public void render(class_332 guiGraphics, int x, int y, SingleVariantStorage<FluidVariant> fluidStorage) {
        int scaledAmount = getScaledAmount(fluidStorage);
        int tint = getColorTint(fluidStorage);
        guiGraphics.method_51422(
                ((tint >> 16) & 0xFF) / 255f,
                ((tint >> 8) & 0xFF) / 255f,
                (tint & 0xFF) / 255f,
                ((tint >> 24) & 0xFF) / 255f);
        guiGraphics.method_25290(STILL_FLUID_TEXTURE,
                x, y + height - scaledAmount, 0f, 0f, width, scaledAmount, 16, 16);
        guiGraphics.method_51422(1f, 1f, 1f, 1f);
    }

    private int getScaledAmount(SingleVariantStorage<FluidVariant> fluidStorage) {
        int amount = Math.toIntExact(fluidStorage.getAmount());
        int scaledAmount = (amount * height) / (int)capacityMb;

        if (amount > 0 && scaledAmount < MIN_FLUID_HEIGHT) {
            scaledAmount = MIN_FLUID_HEIGHT;
        }
        if (scaledAmount > height) {
            scaledAmount = height;
        }
        return scaledAmount;
    }

    private int getColorTint(SingleVariantStorage<FluidVariant> fluidStorage) {
        return fluidStorage.variant.getFluid() == class_3612.field_15910 ? class_8012.field_52313 :
                fluidStorage.variant.getFluid() == class_3612.field_15908 ? class_8012.field_41758 :
                fluidStorage.variant.getFluid() == IndustrialElixirFluids.STILL_Hot_Spring ? class_8012.field_49788 :
                fluidStorage.variant.getFluid() == IndustrialElixirFluids.STILL_Fluid_UU ? DARK_PURPLE :
                fluidStorage.variant.getFluid() == IndustrialElixirFluids.STILL_Fluid_AIR ? class_8012.field_45073 :
                class_8012.field_42973;
    }

    public List<class_2561> getTooltip(SingleVariantStorage<FluidVariant> fluidStorage) {
        List<class_2561> tooltip = new ArrayList<>();
        FluidVariant fluidType = fluidStorage.variant;
        if (fluidType.isBlank()) {
            return List.of(class_2561.method_43470("Empty"));
        }

        tooltip.add(class_2561.method_43471("block."+ class_7923.field_41173.method_10221(fluidStorage.variant.getFluid()).method_12836()
                + "." +class_7923.field_41173.method_10221(fluidStorage.variant.getFluid()).method_12832()));

        long amount = fluidStorage.getAmount();
        if (tooltipMode == TooltipMode.SHOW_AMOUNT_AND_CAPACITY) {
            class_5250 amountString = class_2561.method_43469("industrial_elixir.tooltip.liquid.amount.with.capacity",   nf.format(amount)+ "Mb" + " / " + nf.format(capacityMb) + "Mb");
            tooltip.add(amountString.method_27696(class_2583.field_24360.method_36139(DARK_GRAY)));
        } else if (tooltipMode == TooltipMode.SHOW_AMOUNT) {
            class_5250 amountString = class_2561.method_43469("industrial_elixir.tooltip.liquid.amount",  nf.format(amount) + "Mb");
            tooltip.add(amountString.method_27696(class_2583.field_24360.method_36139(DARK_GRAY)));
        }

        return tooltip;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}