package com.skniro.skniro_furniture.block.entity;

import com.skniro.skniro_furniture.init.FurnitureStrings;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1716;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;

public class CabinetBlockEntity extends AbstractFurnitureContainerBlockEntity {

    public CabinetBlockEntity(class_2338 pos, class_2680 state) {
        super(FurnitureBlockEntityType.Cabinet_BLOCK_ENTITY, pos, state, 9);
    }

    @Override
    protected class_2561 method_17823() {
        return class_2561.method_43471(FurnitureStrings.Cabinet);
    }

    @Override
    protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return new class_1716(syncId, playerInventory, this);
    }
}