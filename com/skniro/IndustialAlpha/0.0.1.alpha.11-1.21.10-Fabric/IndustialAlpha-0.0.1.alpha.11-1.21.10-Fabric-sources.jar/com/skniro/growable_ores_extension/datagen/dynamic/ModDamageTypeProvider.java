package com.skniro.growable_ores_extension.datagen.dynamic;

import com.skniro.growable_ores_extension.init.ModDamageTypes;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_7891;
import net.minecraft.class_8107;
import net.minecraft.class_8110;
import java.util.concurrent.CompletableFuture;

public class ModDamageTypeProvider{

    public static void damageTypes(class_7891<class_8110> context) {
        context.method_46838(ModDamageTypes.ELECTRIC_SHOCK, new class_8110("electric_shock", 0.1F, class_8107.field_42278));
        context.method_46838(ModDamageTypes.FUSION, new class_8110("fusion", 0.1F, class_8107.field_42278));
    }
}