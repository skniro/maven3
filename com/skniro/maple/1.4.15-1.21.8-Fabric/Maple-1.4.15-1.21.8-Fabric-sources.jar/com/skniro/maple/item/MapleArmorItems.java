package com.skniro.maple.item;

import com.skniro.maple.Maple;
import com.skniro.maple.item.init.equipment.MapleArmorMaterials;
import com.skniro.maple.item.init.tool.MapleToolMaterials;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1821;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8051;
import net.minecraft.item.*;
import java.util.function.Function;

public class MapleArmorItems {
    //Ingot
    public static final class_1792 Cherry_INGOT = registerItem("cherry_ingot", class_1792::new, (new class_1792.class_1793()));
    public static final class_1792 Cherry_NUGGET = registerItem("cherry_nugget", class_1792::new, (new class_1792.class_1793()));


    //Tool
    public static final class_1792 Cherry_SWORD = registerItem("cherry_sword", class_1792::new, new class_1792.class_1793().method_61649(25).method_66333(MapleToolMaterials.Cherry,  3, -2.4F));
    public static final class_1792 Cherry_SHOVEL = registerItem("cherry_shovel", (settings)->  new class_1821(MapleToolMaterials.Cherry,2, -3.0F, settings), new class_1792.class_1793());
    public static final class_1792 Cherry_PICKAXE = registerItem("cherry_pickaxe", class_1792::new, new class_1792.class_1793().method_61649(25).method_66330(MapleToolMaterials.Cherry,1, -2.8F));
    public static final class_1792 Cherry_AXE = registerItem("cherry_axe", (settings)->  new class_1743(MapleToolMaterials.Cherry,5, -3.0F, settings), new class_1792.class_1793());
    public static final class_1792 Cherry_HOE = registerItem("cherry_hoe", (settings)->  new class_1794(MapleToolMaterials.Cherry,-3, 0.0F, settings), new class_1792.class_1793());

    //Armor
    public static final class_1792 Cherry_HELMET = registerItem("cherry_helmet", class_1792::new, new class_1792.class_1793().method_61649(25).method_66332(MapleArmorMaterials.Cherry, class_8051.field_41934).method_7895(class_8051.field_41934.method_56690(MapleArmorMaterials.Cherry_DURABILITY_MULTIPLIER)));
    public static final class_1792 Cherry_CHESTPLATE = registerItem("cherry_chestplate", class_1792::new, new class_1792.class_1793().method_61649(25).method_66332(MapleArmorMaterials.Cherry, class_8051.field_41935).method_7895(class_8051.field_41935.method_56690(MapleArmorMaterials.Cherry_DURABILITY_MULTIPLIER)));
    public static final class_1792 Cherry_LEGGINGS = registerItem("cherry_leggings", class_1792::new, new class_1792.class_1793().method_61649(25).method_66332(MapleArmorMaterials.Cherry, class_8051.field_41936).method_7895(class_8051.field_41936.method_56690(MapleArmorMaterials.Cherry_DURABILITY_MULTIPLIER)));
    public static final class_1792 Cherry_BOOTS = registerItem("cherry_boots", class_1792::new, new class_1792.class_1793().method_61649(25).method_66332(MapleArmorMaterials.Cherry, class_8051.field_41937).method_7895(class_8051.field_41937.method_56690(MapleArmorMaterials.Cherry_DURABILITY_MULTIPLIER)));

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings.method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Maple.MOD_ID, name))));
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Maple.MOD_ID, name)), item);
    }

    public static void registerMapleArmorItems() {
        Maple.LOGGER.info("Registering Maple armor items for " + Maple.MOD_ID);
    }

}
