package com.skniro.industrial_elixir.recipe.machine;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.crafting.*;

public class BrewReactorCraftingRecipe extends AbstractMachineCraftingRecipe {

    private final Ingredient ingredient2;

    public BrewReactorCraftingRecipe(Ingredient ingredients, Ingredient ingredient2, int requiredCount, ItemStackTemplate output) {
        super(ingredients, requiredCount, output);
        this.ingredient2 = ingredient2;
    }

    public BrewReactorCraftingRecipe(Ingredient ingredients, Ingredient ingredient2, ItemStackTemplate output) {
        super(ingredients, output);
        this.ingredient2 = ingredient2;
    }

    @Override
    public RecipeSerializer<? extends Recipe<AlchemyCraftingRecipeInput>> getSerializer() {
        return AlchemyRecipeType.BREW_REACTOR.serializer;
    }

    @Override
    public RecipeType<? extends Recipe<AlchemyCraftingRecipeInput>> getType() {
        return AlchemyRecipeType.BREW_REACTOR.type;
    }

    @Override
    public RecipeBookCategory recipeBookCategory() {
        return null;
    }

    public static final MapCodec<BrewReactorCraftingRecipe> CODEC =
            RecordCodecBuilder.mapCodec(inst -> inst.group(
                    Ingredient.CODEC.fieldOf("ingredient")
                            .forGetter(recipe -> recipe.ingredient),

                    Ingredient.CODEC.optionalFieldOf("ingredient2")
                            .forGetter(recipe -> Optional.ofNullable(recipe.ingredient2)),

                    Codec.INT.fieldOf("count")
                            .forGetter(recipe -> recipe.requiredCount),

                    ItemStackTemplate.CODEC.fieldOf("result")
                            .forGetter(recipe -> recipe.output)

            ).apply(inst, (ing, ing2Opt, count, out) -> new BrewReactorCraftingRecipe(ing, ing2Opt.orElse(null), count, out)));

    public static final StreamCodec<RegistryFriendlyByteBuf, BrewReactorCraftingRecipe> STREAM_CODEC =
            StreamCodec.composite(Ingredient.CONTENTS_STREAM_CODEC, AbstractMachineCraftingRecipe::ingredient,
                    Ingredient.CONTENTS_STREAM_CODEC, recipe -> recipe.ingredient2 == null ? Ingredient.of() : recipe.ingredient2,
                    ByteBufCodecs.INT, AbstractMachineCraftingRecipe::requiredCount,
                    ItemStackTemplate.STREAM_CODEC,AbstractMachineCraftingRecipe::output,
                    (ing, ing2, count, out) -> new BrewReactorCraftingRecipe(ing, ing2, count, out));

    public static final RecipeSerializer<BrewReactorCraftingRecipe> SERIALIZER =
            new RecipeSerializer<>(CODEC, STREAM_CODEC);

    public MapCodec<BrewReactorCraftingRecipe> codec() {
        return CODEC;
    }

    public StreamCodec<RegistryFriendlyByteBuf, BrewReactorCraftingRecipe> streamCodec() {
        return STREAM_CODEC;
    }

    @Override
    public boolean matches(AlchemyCraftingRecipeInput input, net.minecraft.world.level.Level world) {
        if (world.isClientSide()) {
            return false;
        }

        net.minecraft.world.item.ItemStack stackA = input.getItem(0);
        net.minecraft.world.item.ItemStack stackB = input.getItem(1);
        // 如果 ingredient2 标记为 AIR（datagen 没有设置第二输入）或为 null，则不需要第二输入即可匹配
        boolean firstMatches = ingredient.test(stackA) && stackA.getCount() >= requiredCount;
        if (!firstMatches) return false;

        if (this.ingredient2 == null) return true;

        return ingredient2.test(stackB);
    }

}
