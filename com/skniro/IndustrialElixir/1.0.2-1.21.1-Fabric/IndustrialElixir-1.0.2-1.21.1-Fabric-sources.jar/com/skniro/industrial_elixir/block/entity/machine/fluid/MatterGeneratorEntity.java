package com.skniro.industrial_elixir.block.entity.machine.fluid;

import com.skniro.industrial_elixir.api.fluid.ContainerInfo;
import com.skniro.industrial_elixir.api.fluid.FluidOutputMap;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluids;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.MatterGeneratorScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3611;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

/**
 * BlockEntity for the Matter Generator (UU matter producer).
 * Basic skeleton: extends AbstractMachineEntity so energy storage and inventory helpers are available.
 * The user will implement the detailed UU-production logic and fluid output.
 */
public class MatterGeneratorEntity extends AbstractFluidMachineEntity {
	private static final long BUCKET_VOLUME_MB = FluidConstants.BUCKET / 81;
	private static final long MB_UNIT = 1L; // 1 mB unit for insertion
	private long progressEU = 0;
	private static final long EU_PER_MB = 1_000_000;
	private long scrapAmplifier = 0;
	private static final long SCRAP_VALUE = 5000;
	private static final int SCRAP_BOOST = 5;
	private static final int SCRAP_CONSUME_INTERVAL = 600;
	private int scrapConsumeTimer = 0;
	protected static final int OUTPUT_EMPTY_FLUID_ITEM_SLOT = 9;
	protected static final int FLUID_ITEM_OUTPUT_SLOT = 10;

	public MatterGeneratorEntity(class_2338 pos, class_2680 state) {
		super(AlchemyBlockEntityType.MATTER_GENERATOR_BE, pos, state);
	}

	@Override
	public class_2561 method_5476() {
		return class_2561.method_43471(FurnitureStrings.Matter_Generator);
	}

	@Nullable
	@Override
	public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
		// No menu by default - implement if you want a GUI
		return new MatterGeneratorScreenHandler(syncId, playerInventory, field_11867);
	}

	@Override
	public class_3956<?> getCurrentRecipeType() {
		return null;
	}

	public int getProgressPercent() {
		return (int) Math.min(100L, progressEU * 100L / EU_PER_MB);
	}

	private boolean generateMatter() {
		FluidVariant variant = FluidVariant.of(IndustrialElixirFluids.STILL_Fluid_UU);
		try (Transaction tx = Transaction.openOuter()) {
			long inserted = fluidContainer.insert(variant, MB_UNIT, tx);
			if (inserted == MB_UNIT) {
				tx.commit();
				return true;
			}
			return false;
		}
	}

	private void updateScrapAmplifier() {
		class_1799 stack = inventory.get(INPUT_SLOT);
		if (++scrapConsumeTimer < SCRAP_CONSUME_INTERVAL) {
			return;
		}
		scrapConsumeTimer = 0;
		if (!stack.method_31574(GrowableOresItems.Scrap))
			return;
		if (scrapAmplifier >= 5000)
			return;
		stack.method_7934(1);
		scrapAmplifier += SCRAP_VALUE;

		method_5431();
	}

	@Override
	public void tick(net.minecraft.class_1937 world, class_2338 pos, class_2680 state) {
		if (world == null || world.method_8608()) return;
		boolean working = false;

		charge(ENERGY_ITEM_SLOT);
		fillFluidContainer();

		if (hasFluidStackInFluidSlot()) {
			fillUpFluidTank();
		}

		updateScrapAmplifier();

		if (this.fluidContainer.getAmount() >= this.fluidContainer.getCapacity()) {
			return;
		}

		try (Transaction tx = Transaction.openOuter()) {

			long extracted = energyContainer.getSideStorage(null).extract(getEffectiveTier().getMaxInput(), tx);
			if (extracted > 0) {
				long gained = extracted;
				if (scrapAmplifier > 0) {
					long used = Math.min(scrapAmplifier, extracted);
					gained += used * SCRAP_BOOST;
					scrapAmplifier -= used;
				}

				progressEU += gained;
				tx.commit();
				working = true;
			} else {
				working = false;

			}
		}

		// When we have accumulated enough energy for 1 mB, attempt to insert 1 mB into tank
		while (progressEU >= EU_PER_MB) {
			if (!generateMatter())
				break;
			progressEU -= EU_PER_MB;
		}

		if(state.method_11654(AbstractMachineblock.LIT)!=working){
			field_11863.method_8652(field_11867, state.method_11657(AbstractMachineblock.LIT,working), 3);
		}

		method_31663(world, pos, state);
	}

	public void fillFluidContainer() {
		if (fluidContainer.isResourceBlank() || fluidContainer.getAmount() < BUCKET_VOLUME_MB) {
			return;
		}

		class_3611 fluid = fluidContainer.getResource().getFluid();
		class_1799 emptyContainerStack = inventory.get(OUTPUT_EMPTY_FLUID_ITEM_SLOT);
		if (emptyContainerStack.method_7960()) {
			return;
		}

		ContainerInfo containerInfo = FluidOutputMap.getContainerInfo(fluid, emptyContainerStack.method_7909());

		if (containerInfo == null) {
			return;
		}

		class_1799 fullContainer = new class_1799(containerInfo.fullItem());

		if (!canStoreFilledContainer(fullContainer)) {
			return;
		}

		try (Transaction transaction = Transaction.openOuter()) {

			long extracted = fluidContainer.extract(
					FluidVariant.of(fluid),
					BUCKET_VOLUME_MB,
					transaction
			);

			if (extracted != BUCKET_VOLUME_MB) {
				return;
			}

			emptyContainerStack.method_7934(1);
			storeFilledContainer(fullContainer);

			transaction.commit();
		}
	}

	private boolean canStoreFilledContainer(class_1799 stack) {
		class_1799 output = inventory.get(FLUID_ITEM_OUTPUT_SLOT);

		return output.method_7960()
				|| (class_1799.method_31577(output, stack)
				&& output.method_7947() + stack.method_7947() <= output.method_7914());
	}

	private void storeFilledContainer(class_1799 stack) {
		class_1799 output = inventory.get(FLUID_ITEM_OUTPUT_SLOT);

		if (output.method_7960()) {
			inventory.set(FLUID_ITEM_OUTPUT_SLOT, stack.method_7972());
		} else {
			output.method_7933(stack.method_7947());
		}
	}

	@Override
	protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
		super.method_11007(output, registries);
		output.method_10544("matter_generator.ProgressEU", progressEU);
		output.method_10544("matter_generator.scrapConsumeTimer", scrapConsumeTimer);
		output.method_10544("matter_generator.scrap_amplifier", scrapAmplifier);
		SingleVariantStorage.writeNbt(fluidContainer, FluidVariant.CODEC, output, registries);
	}

	@Override
	protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
		super.method_11014(input, registries);
		progressEU = (input.method_10545("matter_generator.ProgressEU") ? input.method_10537("matter_generator.ProgressEU") : 0);
		scrapConsumeTimer = (input.method_10545("matter_generator.scrapConsumeTimer") ? input.method_10550("matter_generator.scrapConsumeTimer") : 0);
		scrapAmplifier = (input.method_10545("matter_generator.scrap_amplifier") ? input.method_10537("matter_generator.scrap_amplifier") : 0L);
		SingleVariantStorage.readNbt(fluidContainer, FluidVariant.CODEC, FluidVariant::blank, input, registries);
	}
}



