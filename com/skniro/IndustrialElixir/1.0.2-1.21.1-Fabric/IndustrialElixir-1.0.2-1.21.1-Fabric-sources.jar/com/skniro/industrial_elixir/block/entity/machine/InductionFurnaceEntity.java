package com.skniro.industrial_elixir.block.entity.machine;

import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.EnergyStorageUtil;
import com.skniro.industrial_elixir.energy.api.base.SimpleSidedEnergyContainer;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.init.ItemUpgradeModule;
import com.skniro.industrial_elixir.registry.tag.ModItemTags;
import com.skniro.industrial_elixir.screen.handler.machine.InductionFurnaceScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3861;
import net.minecraft.class_3913;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_8786;
import net.minecraft.class_9696;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class InductionFurnaceEntity extends AbstractMachineEntity {
    public static final int INPUT_SLOT_A = 1;
    public static final int INPUT_SLOT_B = 9;
    public static final int OUTPUT_SLOT = 2;
    public static final int ENERGY_SLOT = 3;
    private static final int HEAT_KEEP_COST = 1;
    private static final int MAX_HEAT = 100;
    private static final int MIN_RECIPE_EU = 195;
    private static final int MAX_RECIPE_EU = 6000;
    private static final int MAX_EU_PER_TICK_PER_SLOT = 16;
    private static final int HEAT_UP_INTERVAL = 20;
    private static final int COOL_DOWN_INTERVAL = 40;

    private int heat;
    private int heatTick;

    private final class_3913 inductionData = new class_3913() {
        @Override
        public int method_17390(int index) {
            return switch (index) {
                case 0 -> InductionFurnaceEntity.this.progress;
                case 1 -> InductionFurnaceEntity.this.maxProgress;
                case 2 -> InductionFurnaceEntity.this.heat;
                default -> 0;
            };
        }

        @Override
        public void method_17391(int index, int value) {
            switch (index) {
                case 0 -> InductionFurnaceEntity.this.progress = value;
                case 1 -> InductionFurnaceEntity.this.maxProgress = value;
                case 2 -> InductionFurnaceEntity.this.heat = value;
            }
        }

        @Override
        public int method_17389() {
            return 3;
        }
    };

    public InductionFurnaceEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.INDUCTION_FURNACE_BLOCK_ENTITY, pos, state);
        this.maxProgress = getProgressTicksForHeat();
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.InductionFurnace);
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return class_3956.field_17546;
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) {
            return;
        }

        charge(ENERGY_SLOT);
        boolean hasRecipe = getActiveRecipeCount() > 0;
        boolean shouldKeepHeat = shouldKeepHeat(world, pos);

        if ((hasRecipe || shouldKeepHeat) && heat < MAX_HEAT) {
            heatTick++;
            if (heatTick >= HEAT_UP_INTERVAL) {
                heat++;
                heatTick = 0;
            }
        } else if (!hasRecipe && !shouldKeepHeat && heat > 0) {
            heatTick++;
            if (heatTick >= COOL_DOWN_INTERVAL) {
                heat--;
                heatTick = 0;
            }
        } else {
            heatTick = 0;
        }

        if (shouldKeepHeat && energyContainer.amount >= HEAT_KEEP_COST) {
            extractEnergy(HEAT_KEEP_COST);
        }

        maxProgress = getProgressTicksForHeat();
        if (hasRecipe && hasEnoughEnergyForActiveSlots()) {
            progress++;
            extractEnergy(getProcessingEnergyPerTick());
            if (progress >= maxProgress) {
                smelt(INPUT_SLOT_A);
                smelt(INPUT_SLOT_B);
                progress = 0;
            }
        } else {
            progress = 0;
        }

        boolean isWorking = hasRecipe && hasEnoughEnergyForActiveSlots();
        if (state.method_11654(AbstractMachineblock.LIT) != isWorking) {
            world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, isWorking), 3);
        }
        method_31663(world, pos, state);
    }

    private boolean shouldKeepHeat(class_1937 world, class_2338 pos) {
        boolean powered = world.method_49803(pos);
        if (hasRedstoneInverterUpgrade()) {
            powered = !powered;
        }
        return powered && energyContainer.amount >= HEAT_KEEP_COST;
    }

    private boolean hasRedstoneInverterUpgrade() {
        for (int slot = UPGRADE_START; slot <= UPGRADE_END; slot++) {
            class_1799 stack = inventory.get(slot);
            if (stack.method_7909() instanceof ItemUpgradeModule upgrade && upgrade.modifiesRedstoneInput(stack)) {
                return true;
            }
        }
        return false;
    }

    private int getProgressTicksForHeat() {
        return Math.max(1, (int) Math.ceil((double) getEnergyPerItem() / MAX_EU_PER_TICK_PER_SLOT));
    }

    private int getEnergyPerItem() {
        int effectiveHeat = Math.max(1, heat);
        return MIN_RECIPE_EU + (MAX_HEAT - effectiveHeat) * (MAX_RECIPE_EU - MIN_RECIPE_EU) / (MAX_HEAT - 1);
    }

    private int getActiveRecipeCount() {
        int count = 0;
        class_1799 projectedOutput = this.method_5438(OUTPUT_SLOT).method_7972();
        Optional<class_8786<class_3861>> firstRecipe = getSmeltingRecipe(INPUT_SLOT_A);
        if (firstRecipe.isPresent()) {
            class_1799 output = firstRecipe.get().comp_1933().method_59982(new class_9696(this.method_5438(INPUT_SLOT_A)), this.method_10997().method_30349()).method_7972();
            if (canMergeOutput(projectedOutput, output)) {
                projectedOutput = mergedOutput(projectedOutput, output);
                count++;
            }
        }
        Optional<class_8786<class_3861>> secondRecipe = getSmeltingRecipe(INPUT_SLOT_B);
        if (secondRecipe.isPresent()) {
            class_1799 output = secondRecipe.get().comp_1933().method_59982(new class_9696(this.method_5438(INPUT_SLOT_B)), this.method_10997().method_30349()).method_7972();
            if (canMergeOutput(projectedOutput, output)) {
                count++;
            }
        }
        return count;
    }

    private int getProcessingEnergyPerTick() {
        return MAX_EU_PER_TICK_PER_SLOT * getActiveRecipeCount();
    }

    private boolean hasEnoughEnergyForActiveSlots() {
        return getActiveRecipeCount() > 0 && energyContainer.amount >= getProcessingEnergyPerTick();
    }

    private void extractEnergy(long amount) {
        try (Transaction transaction = Transaction.openOuter()) {
            energyContainer.getSideStorage(null).extract(amount, transaction);
            transaction.commit();
        }
    }

    private boolean hasSmeltingRecipe(int inputSlot) {
        Optional<class_8786<class_3861>> recipe = getSmeltingRecipe(inputSlot);
        if (recipe.isEmpty()) {
            return false;
        }
        class_1799 output = recipe.get().comp_1933().method_59982(new class_9696(this.method_5438(inputSlot)), this.method_10997().method_30349()).method_7972();
        return canMergeOutput(this.method_5438(OUTPUT_SLOT), output);
    }

    private boolean canMergeOutput(class_1799 currentOutput, class_1799 output) {
        return currentOutput.method_7960() || (class_1799.method_31577(currentOutput, output) && currentOutput.method_7947() + output.method_7947() <= currentOutput.method_7914());
    }

    private class_1799 mergedOutput(class_1799 currentOutput, class_1799 output) {
        if (currentOutput.method_7960()) {
            return output.method_7972();
        }
        class_1799 merged = currentOutput.method_7972();
        merged.method_7933(output.method_7947());
        return merged;
    }

    private Optional<class_8786<class_3861>> getSmeltingRecipe(int inputSlot) {
        if (this.method_10997() == null || this.method_10997().method_8503() == null || this.method_5438(inputSlot).method_7960()) {
            return Optional.empty();
        }
        return this.method_10997().method_8503().method_3772().method_8132(class_3956.field_17546, new class_9696(this.method_5438(inputSlot)), this.method_10997());
    }

    private void smelt(int inputSlot) {
        Optional<class_8786<class_3861>> recipe = getSmeltingRecipe(inputSlot);
        if (recipe.isEmpty()) {
            return;
        }
        class_1799 output = recipe.get().comp_1933().method_59982(new class_9696(this.method_5438(inputSlot)), this.method_10997().method_30349()).method_7972();
        if (!hasSmeltingRecipe(inputSlot)) {
            return;
        }
        this.method_5434(inputSlot, 1);
        if (this.method_5438(OUTPUT_SLOT).method_7960()) {
            this.method_5447(OUTPUT_SLOT, output);
        } else {
            this.method_5438(OUTPUT_SLOT).method_7933(output.method_7947());
        }
    }

    @Override
    public void charge(int slot) {
        if (this.field_11863 != null && !this.field_11863.method_8608() && getFreeSpace() > 0) {
            class_1263 inventory = this;
            EnergyStorageUtil.move(
                    ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(slot)).find(EnergyStorage.ITEM),
                    this.getSideEnergyStorage(null),
                    Long.MAX_VALUE,
                    null
            );
        }
    }

    @Override
    public int[] method_5494(class_2350 direction) {
        if (direction == class_2350.field_11033) {
            return new int[]{OUTPUT_SLOT};
        }
        return new int[]{INPUT_SLOT_A, INPUT_SLOT_B, ENERGY_SLOT};
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        if (slot == INPUT_SLOT_A || slot == INPUT_SLOT_B) {
            return true;
        }
        if (slot == ENERGY_SLOT) {
            return stack.method_31573(ModItemTags.BATTERY);
        }
        return slot >= UPGRADE_START && slot <= UPGRADE_END;
    }

    @Override
    public boolean method_5493(int slot, class_1799 stack, class_2350 side) {
        return side == class_2350.field_11033 && slot == OUTPUT_SLOT;
    }

    @Override
    protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        output.method_10569("induction_furnace.heat", heat);
        output.method_10569("induction_furnace.heat_tick", heatTick);
    }

    @Override
    protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        super.method_11014(input, registries);
        heat = (input.method_10545("induction_furnace.heat") ? input.method_10550("induction_furnace.heat") : 0);
        heatTick = (input.method_10545("induction_furnace.heat_tick") ? input.method_10550("induction_furnace.heat_tick") : 0);
        maxProgress = getProgressTicksForHeat();
    }

    public int getHeat() {
        return heat;
    }

    public int getScaledHeatWidth() {
        return heat * 54 / MAX_HEAT;
    }

    public int getScaledEnergyHeight() {
        long energy = energyContainer.amount;
        long capacity = energyContainer.getCapacity();
        return capacity != 0 && energy != 0 ? (int) (energy * 16 / capacity) : 0;
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new InductionFurnaceScreenHandler(syncId, playerInventory, this, inductionData);
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}
