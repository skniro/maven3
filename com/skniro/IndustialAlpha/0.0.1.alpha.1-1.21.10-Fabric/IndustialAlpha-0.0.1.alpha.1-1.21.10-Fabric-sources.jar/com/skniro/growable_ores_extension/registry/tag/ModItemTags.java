package com.skniro.growable_ores_extension.registry.tag;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public final class ModItemTags {
    public static final class_6862<class_1792> BATTERY = of("battery");
    public static final class_6862<class_1792> Upgrade = of("upgrade");

    private ModItemTags() {
    }

    private static class_6862<class_1792> of(String id) {
        return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, id));
    }
}