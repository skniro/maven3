package com.skniro.maple.item;

import com.skniro.maple.Maple;
import com.skniro.maple.item.init.armor.MapleArmorMaterials;
import com.skniro.maple.item.init.tool.MapleToolMaterials;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.item.*;

public class MapleArmorItems {
    //Ingot
    public static final class_1792 Cherry_INGOT = registerItem("cherry_ingot",new class_1792(new class_1792.class_1793()));
    public static final class_1792 Cherry_NUGGET = registerItem("cherry_nugget",new class_1792(new class_1792.class_1793()));


    //Tool
    public static final class_1792 Cherry_SWORD = registerItem("cherry_sword", (new class_1829(MapleToolMaterials.Cherry,  new class_1792.class_1793().method_57348(class_1829.method_57394(MapleToolMaterials.Cherry, 3, -2.4F)))));
    public static final class_1792 Cherry_SHOVEL = registerItem("cherry_shovel", (new class_1821(MapleToolMaterials.Cherry, new class_1792.class_1793().method_57348(class_1821.method_57346(MapleToolMaterials.Cherry, 2, -3.0F)))));
    public static final class_1792 Cherry_PICKAXE = registerItem("cherry_pickaxe", (new class_1810(MapleToolMaterials.Cherry, new class_1792.class_1793().method_57348(class_1810.method_57346(MapleToolMaterials.Cherry, 1, -2.8F)))));
    public static final class_1792 Cherry_AXE = registerItem("cherry_axe", (new class_1743(MapleToolMaterials.Cherry, new class_1792.class_1793().method_57348(class_1743.method_57346(MapleToolMaterials.Cherry, 5, -3.0F)))));
    public static final class_1792 Cherry_HOE = registerItem("cherry_hoe", (new class_1794(MapleToolMaterials.Cherry, new class_1792.class_1793().method_57348(class_1794.method_57346(MapleToolMaterials.Cherry, 3, 0F)))));

    //Armor
    public static final class_1792 Cherry_HELMET = registerItem("cherry_helmet", (new class_1738(MapleArmorMaterials.Cherry, class_1738.class_8051.field_41934, new class_1792.class_1793())));
    public static final class_1792 Cherry_CHESTPLATE = registerItem("cherry_chestplate", (new class_1738(MapleArmorMaterials.Cherry, class_1738.class_8051.field_41935, new class_1792.class_1793())));
    public static final class_1792 Cherry_LEGGINGS = registerItem("cherry_leggings", (new class_1738(MapleArmorMaterials.Cherry, class_1738.class_8051.field_41936, new class_1792.class_1793())));
    public static final class_1792 Cherry_BOOTS = registerItem("cherry_boots", (new class_1738(MapleArmorMaterials.Cherry, class_1738.class_8051.field_41937, new class_1792.class_1793())));

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(Maple.MOD_ID, name),item);
    }

    public static void registerMapleArmorItems() {
        Maple.LOGGER.info("Registering Maple armor items for " + Maple.MOD_ID);
    }

}
