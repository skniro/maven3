package com.skniro.growable_ores_extension.block.entity.pipe;

import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.block.init.machine.Alchemyblock;
import com.skniro.growable_ores_extension.block.init.pipe.PipeBlock;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_11566;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PipeBlockEntity extends class_2586 implements class_11566 {

    private final List<PipeItem> items = new ArrayList<>();

    public PipeBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }


    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        updateConnections();
    }

    public List<PipeItem> getItems() {
        return new ArrayList<>(items);
    }

    public void neighborUpdate() {
        updateConnections();
    }

    private void updateConnections() {
        if (field_11863 == null || field_11863.method_8608()) {
            return;
        }

        class_2680 state = method_11010();
        class_2680 newState = state;

        for (class_2350 dir : class_2350.values()) {
            boolean connected = isConnectable(dir);
            newState = newState.method_11657(PipeBlock.PROPERTY_MAP.get(dir), connected);
        }

        if (newState != state) {
            field_11863.method_8501(field_11867, newState);
        }
    }

    private boolean isConnectable(class_2350 dir) {
        class_2338 target = field_11867.method_10093(dir);
        class_2680 neighborState = field_11863.method_8320(target);
        class_2248 neighborBlock = neighborState.method_26204();

        if (neighborBlock instanceof PipeBlock) {
            return true;
        }

        Storage<ItemVariant> storage =
                ItemStorage.SIDED.find(field_11863, target, dir.method_10153());

        return storage != null;
    }

    void moveItems(class_1937 world, class_2338 pos, class_2680 state) {
        Iterator<PipeItem> it = items.iterator();

        while (it.hasNext()) {
            PipeItem item = it.next();

            // ❗ 清理无效数据（关键）
            if (item.variant.isBlank() || item.amount <= 0) {
                it.remove();
                continue;
            }

            item.progress += 0.1;

            if (item.progress >= 1.0) {
                class_2338 target = pos.method_10093(item.direction);

                if (!tryMoveToNext(world, target, item)
                        && !tryInsert(world, target, item)) {

                    item.progress = 1.0;
                    continue;
                }

                it.remove();
            }
        }
    }

    private boolean tryMoveToNext(class_1937 world, class_2338 pos, PipeItem item) {
        class_2586 be = world.method_8321(pos);

        if (be instanceof PipeBlockEntity pipe) {

            class_2350 newDir = getNextDirection(world, pos, item);

            PipeItem newItem = new PipeItem(item.variant, item.amount, newDir);

            // ❗ 关键：记录来源
            newItem.lastDirection = item.direction;

            pipe.items.add(newItem);

            return true;
        }

        return false;
    }

    private class_2350 getNextDirection(class_1937 world, class_2338 pos, class_2350 from) {
        List<class_2350> possible = new ArrayList<>();

        for (class_2350 dir : class_2350.values()) {
            if (dir == from.method_10153()) continue;

            class_2680 state = world.method_8320(pos);
            if (state.method_11654(PipeBlock.PROPERTY_MAP.get(dir))) {
                possible.add(dir);
            }
        }

        if (possible.isEmpty()) return from;

        return possible.get(world.field_9229.method_43048(possible.size()));
    }

    private boolean tryInsert(class_1937 world, class_2338 pos, PipeItem item) {
        if (item.variant.isBlank() || item.amount <= 0) {
            return false;
        }

        Storage<ItemVariant> storage =
                ItemStorage.SIDED.find(world, pos, item.direction.method_10153());

        if (storage == null) return false;

        try (Transaction tx = Transaction.openOuter()) {
            long inserted = storage.insert(item.variant, item.amount, tx);

            if (inserted > 0) {
                item.amount -= inserted;

                if (item.amount <= 0) {
                    item.variant = ItemVariant.blank();
                }

                tx.commit();
                return true;
            }
        }

        return false;
    }

    private class_2350 getNextDirection(class_1937 world, class_2338 pos, PipeItem item) {

        List<class_2350> possible = new ArrayList<>();

        for (class_2350 dir : class_2350.values()) {

            // ❌ 禁止回头
            if (dir == item.lastDirection.method_10153()) continue;

            class_2680 state = world.method_8320(pos);
            if (state.method_11654(PipeBlock.PROPERTY_MAP.get(dir))) {
                possible.add(dir);
            }
        }

        // ❗ 如果没有路，只能回头（避免卡死）
        if (possible.isEmpty()) {
            return item.lastDirection.method_10153();
        }

        return possible.get(world.field_9229.method_43048(possible.size()));
    }

    void extractItems(class_1937 world, class_2338 pos, class_2680 state) {

        if (!items.isEmpty()) return; // 一次只抽一个（简化）

        for (class_2350 dir : class_2350.values()) {
            class_2338 target = pos.method_10093(dir);

            Storage<ItemVariant> storage =
                    ItemStorage.SIDED.find(world, target, dir.method_10153());

            if (storage == null) continue;

            try (Transaction tx = Transaction.openOuter()) {
                Iterator<StorageView<ItemVariant>> it = storage.iterator();
                StorageView<ItemVariant> view = null;

                while (it.hasNext()) {
                    StorageView<ItemVariant> next = it.next();
                    if (!next.isResourceBlank()) {
                        view = next;
                        break;
                    }
                }

                if (view == null) continue;

                long extracted = storage.extract(view.getResource(), 1, tx);

                if (extracted > 0) {
                    class_2350 outDir = dir.method_10153();
                    items.add(new PipeItem(view.getResource(), extracted, outDir));

                    tx.commit();
                    return;
                }
            }
        }
    }

    @Override
    public class_1937 method_73183() {
        return this.field_11863;
    }

    @Override
    public class_243 method_73189() {
        return this.method_11016().method_46558();
    }

    @Override
    public float method_73188() {
        return 0;
    }


    public class PipeItem {
        public ItemVariant variant;
        public long amount;

        public class_2350 direction;      // 当前移动方向
        public class_2350 lastDirection;  // ❗ 上一个方向（防回流）

        public double progress;

        public PipeItem(ItemVariant variant, long amount, class_2350 dir) {
            this.variant = variant;
            this.amount = amount;
            this.direction = dir;
            this.lastDirection = dir; // 初始
            this.progress = 0.0;
        }
    }
}
