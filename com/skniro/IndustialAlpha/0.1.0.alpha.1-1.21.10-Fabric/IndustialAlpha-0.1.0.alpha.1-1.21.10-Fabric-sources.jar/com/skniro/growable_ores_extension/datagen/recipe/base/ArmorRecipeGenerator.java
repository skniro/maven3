package com.skniro.growable_ores_extension.datagen.recipe.base;

import com.skniro.growable_ores_extension.api.data.family.GrowableOresBlockFamilies;
import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.MapleSignBlocks;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.item.MapleArmorItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2454;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class ArmorRecipeGenerator extends FabricRecipeProvider {
    public ArmorRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {
                method_62746(class_7800.field_40638, MapleArmorItems.BRONZE_PICKAXE)
                        .method_10439("###")
                        .method_10439(" I ")
                        .method_10439(" I ")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10434('I', class_1802.field_8600)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                method_10426(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40639, MapleArmorItems.BRONZE_SWORD)
                        .method_10439("#")
                        .method_10439("#")
                        .method_10439("|")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10434('|', class_1802.field_8600)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                method_10426(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40638, MapleArmorItems.BRONZE_AXE)
                        .method_10439("##")
                        .method_10439("#|")
                        .method_10439(" |")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10434('|', class_1802.field_8600)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                method_10426(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40638, MapleArmorItems.BRONZE_SHOVEL)
                        .method_10439("#")
                        .method_10439("|")
                        .method_10439("|")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10434('|', class_1802.field_8600)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                method_10426(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40638, MapleArmorItems.BRONZE_HOE)
                        .method_10439("##")
                        .method_10439(" |")
                        .method_10439(" |")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10434('|', class_1802.field_8600)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                method_10426(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40639, MapleArmorItems.BRONZE_HELMET)
                        .method_10439("###")
                        .method_10439("# #")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                method_10426(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40639, MapleArmorItems.BRONZE_CHESTPLATE)
                        .method_10439("# #")
                        .method_10439("###")
                        .method_10439("###")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                method_10426(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40639, MapleArmorItems.BRONZE_LEGGINGS)
                        .method_10439("###")
                        .method_10439("# #")
                        .method_10439("# #")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                method_10426(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(field_53721);

                method_62746(class_7800.field_40639, MapleArmorItems.BRONZE_BOOTS)
                        .method_10439("# #")
                        .method_10439("# #")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                method_10426(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(field_53721);

                class_2454.method_17802(
                                class_1856.method_8091(
                                        MapleArmorItems.BRONZE_PICKAXE,
                                        MapleArmorItems.BRONZE_AXE,
                                        MapleArmorItems.BRONZE_SHOVEL,
                                        MapleArmorItems.BRONZE_SWORD,
                                        MapleArmorItems.BRONZE_HOE,
                                        MapleArmorItems.BRONZE_HELMET,
                                        MapleArmorItems.BRONZE_CHESTPLATE,
                                        MapleArmorItems.BRONZE_LEGGINGS,
                                        MapleArmorItems.BRONZE_BOOTS
                                ),
                                class_7800.field_40642, GrowableOresItems.BRONZE_INGOT, 0.1F, 200)
                        .method_10469("has_bronze_pickaxe", this.method_10426(MapleArmorItems.BRONZE_PICKAXE))
                        .method_10469("has_bronze_axe", this.method_10426(MapleArmorItems.BRONZE_AXE))
                        .method_10469("has_bronze_shovel", this.method_10426(MapleArmorItems.BRONZE_SHOVEL))
                        .method_10469("has_bronze_sword", this.method_10426(MapleArmorItems.BRONZE_SWORD))
                        .method_10469("has_bronze_hoe", this.method_10426(MapleArmorItems.BRONZE_HOE))
                        .method_10469("has_bronze_helmet", this.method_10426(MapleArmorItems.BRONZE_HELMET))
                        .method_10469("has_bronze_chestplate", this.method_10426(MapleArmorItems.BRONZE_CHESTPLATE))
                        .method_10469("has_bronze_leggings", this.method_10426(MapleArmorItems.BRONZE_LEGGINGS))
                        .method_10469("has_bronze_boots", this.method_10426(MapleArmorItems.BRONZE_BOOTS))
                        .method_36443(this.field_53721, method_36451(GrowableOresItems.BRONZE_INGOT));
            }
        };
    }


    @Override
    public String method_10321() {
        return "Armor";
    }
}