package com.skniro.industrial_elixir.compat.jei.category;

import com.skniro.industrial_elixir.api.Helper;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.machine.MetalFormerCuttingCraftingRecipe;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableAnimated;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_8786;
import mezz.jei.api.recipe.RecipeType;

public class MetalFormerCuttingCategory implements IRecipeCategory<class_8786<MetalFormerCuttingCraftingRecipe>> {

    public static final RecipeType<class_8786<MetalFormerCuttingCraftingRecipe>> TYPE =
            RecipeType.createFromVanilla(AlchemyRecipeType.METALFORMER_CUTTING.type);

    private final IDrawable background;
    private final IDrawable icon;
    private final IDrawable energyBar;
    private final IDrawableAnimated arrow;

    public MetalFormerCuttingCategory(IGuiHelper helper) {
        class_2960 texture = Helper.id( "textures/gui/container/machine/metal_former.png");

        background = helper.createDrawable(texture, 0, 0, 175, 82);

        icon = helper.createDrawableIngredient(VanillaTypes.ITEM_STACK,
                new class_1799(GrowableOresBlocks.MetalFormerBlock));

        energyBar = helper.createDrawable(texture, 176, 0, 13, 16);
        this.arrow = helper.drawableBuilder(Helper.id("textures/gui/container/machine/metal_former.png"), 190, 0, 48, 15).buildAnimated(72, IDrawableAnimated.StartDirection.LEFT, false);
    }

    @Override
    public RecipeType<class_8786<MetalFormerCuttingCraftingRecipe>> getRecipeType() {
        return TYPE;
    }

    @Override
    public class_2561 getTitle() {
        return class_2561.method_43471(FurnitureStrings.CUTTING);
    }

    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public int getWidth() {
        return background.getWidth();
    }

    @Override
    public int getHeight() {
        return background.getHeight();
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, class_8786<MetalFormerCuttingCraftingRecipe> recipe, IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 21, 13)
                .addIngredients(recipe.comp_1933().ingredient());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 118, 34)
                .addItemStack(recipe.comp_1933().output());
    }

    @Override
    public void draw(class_8786<MetalFormerCuttingCraftingRecipe> recipe, IRecipeSlotsView slots, class_332 guiGraphics, double mouseX, double mouseY) {
        background.draw(guiGraphics);

        energyBar.draw(guiGraphics, 21, 30);

        arrow.draw(guiGraphics, 70, 34);

        int count = recipe.comp_1933().requiredCount();

        if (count > 1) {
            class_327 font = class_310.method_1551().field_1772;
            String text = String.valueOf(count);

            int x = 52 + 16 - font.method_1727(text) - 1;
            int y = 13 + 16 - 8 - 1;

            guiGraphics.method_51433(font, text, x, y, 0xFFFFFFFF, true);
        }
    }
}