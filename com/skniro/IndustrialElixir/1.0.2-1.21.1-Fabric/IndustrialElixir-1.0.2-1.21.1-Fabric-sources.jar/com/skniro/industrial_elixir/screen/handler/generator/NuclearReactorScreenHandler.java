package com.skniro.industrial_elixir.screen.handler.generator;

import com.skniro.industrial_elixir.block.entity.generator.NuclearReactorBlockEntity;
import com.skniro.industrial_elixir.item.init.ReactorComponentItem;
import com.skniro.industrial_elixir.registry.tag.ModItemTags;
import com.skniro.industrial_elixir.screen.AlchemyScreenHandlerType;
import com.skniro.industrial_elixir.screen.slot.BatteryChargeSlot;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3913;
import net.minecraft.class_3919;

public class NuclearReactorScreenHandler extends class_1703 {
    private static final int REACTOR_GRID_X = 26;
    private static final int REACTOR_GRID_Y = 25;
    private static final int REACTOR_SLOT_SPACING = 18;
    private final class_1263 inventory;
    private final class_3913 propertyDelegate;
    public final NuclearReactorBlockEntity blockEntity;

    public NuclearReactorScreenHandler(int syncId, class_1661 playerInventory, class_2338 pos) {
        this(syncId, playerInventory, playerInventory.field_7546.method_37908().method_8321(pos), new class_3919(4));
    }

    public NuclearReactorScreenHandler(int syncId, class_1661 playerInventory, class_2586 blockEntity, class_3913 propertyDelegate) {
        super(AlchemyScreenHandlerType.NuclearReactor, syncId);
        method_17359((class_1263) blockEntity, NuclearReactorBlockEntity.REACTOR_SLOT_COUNT + 1);
        this.inventory = (class_1263) blockEntity;
        this.blockEntity = (NuclearReactorBlockEntity) blockEntity;
        this.propertyDelegate = propertyDelegate;

        for (int row = 0; row < NuclearReactorBlockEntity.GRID_HEIGHT; row++) {
            for (int column = 0; column < NuclearReactorBlockEntity.GRID_WIDTH; column++) {
                int slot = row * NuclearReactorBlockEntity.GRID_WIDTH + column;
                this.method_7621(new ReactorSlot(inventory, slot, REACTOR_GRID_X + column * REACTOR_SLOT_SPACING, REACTOR_GRID_Y + row * REACTOR_SLOT_SPACING));
            }
        }

        this.method_7621(new BatteryChargeSlot(inventory, NuclearReactorBlockEntity.BATTERY_SLOT, 152, 96, com.skniro.industrial_elixir.api.energytier.EnergyTier.TIER4));
        addPlayerInventory(playerInventory);
        addPlayerHotbar(playerInventory);
        method_17360(propertyDelegate);
    }

    public int getHeat() {
        return propertyDelegate.method_17390(0);
    }

    public int getMaxHeat() {
        return propertyDelegate.method_17390(1);
    }

    public int getGeneration() {
        return propertyDelegate.method_17390(2);
    }

    public int getScaledHeatWidth() {
        int maxHeat = getMaxHeat();
        return maxHeat > 0 && getHeat() > 0 ? Math.min(54, getHeat() * 54 / maxHeat) : 0;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int invSlot) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(invSlot);
        if (slot != null && slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();
            int machineSlots = NuclearReactorBlockEntity.REACTOR_SLOT_COUNT + 1;
            if (invSlot < machineSlots) {
                if (!this.method_7616(originalStack, machineSlots, this.field_7761.size(), true)) {
                    return class_1799.field_8037;
                }
            } else if (originalStack.method_31573(ModItemTags.BATTERY)) {
                if (!this.method_7616(originalStack, NuclearReactorBlockEntity.BATTERY_SLOT, NuclearReactorBlockEntity.BATTERY_SLOT + 1, false)) {
                    return class_1799.field_8037;
                }
            } else if (originalStack.method_7909() instanceof ReactorComponentItem) {
                if (!this.method_7616(originalStack, 0, NuclearReactorBlockEntity.REACTOR_SLOT_COUNT, false)) {
                    return class_1799.field_8037;
                }
            } else {
                return class_1799.field_8037;
            }

            if (originalStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }
        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return inventory.method_5443(player);
    }

    private void addPlayerInventory(class_1661 playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.method_7621(new class_1735(playerInventory, l + i * 9 + 9, 26 + l * 18, 161 + i * 18));
            }
        }
    }

    private void addPlayerHotbar(class_1661 playerInventory) {
        for (int i = 0; i < 9; ++i) {
            this.method_7621(new class_1735(playerInventory, i, 26 + i * 18, 219));
        }
    }

    private static class ReactorSlot extends class_1735 {
        public ReactorSlot(class_1263 container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean method_7680(class_1799 stack) {
            return stack.method_7909() instanceof ReactorComponentItem;
        }
    }
}