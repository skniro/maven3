package com.skniro.growable_ores_extension.api.registry;

import static net.minecraft.class_4944.method_25876;

import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4944;
import net.minecraft.class_4945;

public class ModTextureMap {

    public static class_4944 allSides(class_2248 block) {
        class_2960 id = method_25860(block);
        class_4944 map = new class_4944();
        map.method_25868(class_4945.field_23019, id);
        map.method_25868(class_4945.field_23020, id);
        map.method_25868(class_4945.field_23021, id);
        map.method_25868(class_4945.field_23022, id);
        map.method_25868(class_4945.field_23023, id);
        map.method_25868(class_4945.field_23024, id);
        return map;
    }

}