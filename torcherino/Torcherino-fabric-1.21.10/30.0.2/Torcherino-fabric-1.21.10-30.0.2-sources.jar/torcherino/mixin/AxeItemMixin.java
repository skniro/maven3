package torcherino.mixin;

import com.google.common.collect.BiMap;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5953;
import net.minecraft.class_5955;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import torcherino.block.CopperLanterinoBlock;
import torcherino.block.WeatheringLanterinoBlock;

import static torcherino.block.WeatheringLanterinoBlock.swapPreserveTorcherinoBE;

@Mixin(class_1743.class)
public abstract class AxeItemMixin {

    @Inject(method = "useOn", at = @At("HEAD"), cancellable = true)
    public void useOn(class_1838 useOnContext, CallbackInfoReturnable<class_1269> cir) {
        class_1937 level = useOnContext.method_8045();
        class_2338 pos = useOnContext.method_8037();
        class_2680 state = useOnContext.method_8045().method_8320(pos);
        class_1657 player = useOnContext.method_8036();
        class_1799 stack = useOnContext.method_8041();
        if (state.method_26204() instanceof CopperLanterinoBlock) {
            if (!level.method_8608()) {
                BiMap<class_2248, class_2248> waxOffMap = (BiMap<class_2248, class_2248>) class_5953.field_29561.get();
                class_2248 unwaxed = waxOffMap.get(state.method_26204());
                if (unwaxed != null) {
                    swapPreserveTorcherinoBE((class_3218) level, pos, state, unwaxed.method_9564());
                    stack.method_7956(1, (class_3218) level, null, (p) -> {
                    });
                    level.method_8444(player, 3005, pos, 0);
                    cir.setReturnValue(class_1269.field_5812);
                }
            }
            if (state.method_26204() instanceof WeatheringLanterinoBlock) {
                if (!level.method_8608()) {
                    BiMap<class_2248, class_2248> prevMap = (BiMap<class_2248, class_2248>) class_5955.field_29565.get();
                    class_2248 prev = prevMap.get(state.method_26204());
                    if (prev != null) {
                        swapPreserveTorcherinoBE((class_3218) level, pos, state, prev.method_9564());
                        stack.method_7956(1, (class_3218) level, null, (p) -> {
                        });
                        level.method_8444(player, 3004, pos, 0);
                        cir.setReturnValue(class_1269.field_5812);
                    }
                }
            }
        }
    }
}
