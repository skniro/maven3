package com.skniro.maple.recipe;

import net.minecraft.class_1799;
import net.minecraft.class_9695;

public record MapleCraftingRecipeInput(class_1799 input,class_1799 glass) implements class_9695 {
    @Override
    public class_1799 method_59984(int slot) {
        class_1799 input;
        switch (slot) {
            case 0 -> input = this.input;
            case 1 -> input = this.glass;
            default -> throw new IllegalArgumentException("Recipe does not contain slot " + slot);
        }

        return input;
    }

    @Override
    public int method_59983() {
        return 2;
    }
}