package com.skniro.growable_ores_extension.client.gui.screen.ingame.widgets;

import net.minecraft.class_10799;
import net.minecraft.class_11907;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_8666;
import net.minecraft.class_918;
import net.minecraft.class_9848;

public abstract class StateButtonWidget extends class_4185 {
    private static final class_918 itemRenderer = class_310.method_1551().method_1480();
    private static final class_8666 SPRITES = new class_8666(class_2960.method_60656("widget/button"), class_2960.method_60656("widget/button_disabled"), class_2960.method_60656("widget/button_highlighted"));
    private final class_437 screen;
    private net.minecraft.class_2561 narrationMessage;
    private class_327 font;

    public StateButtonWidget(class_437 screen, int x, int y, class_327 font) {
        super(x, y, 20, 20, net.minecraft.class_2561.method_43473(), (b) -> {}, class_4185.field_40754);
        this.screen = screen;
        this.font = font;
        this.initialize();
    }

    public class_327 getFont() {
        return this.font;
    }

    protected abstract void initialize();

    protected abstract void nextState();

    protected abstract class_1799 getButtonIcon();

    @Override
    protected final void method_48579(class_332 context, int mouseX, int mouseY, float partialTicks){
        if (field_22764) {
            context.method_52707(class_10799.field_56883, SPRITES.method_52729(this.field_22763, this.method_25367()), this.method_46426(), this.method_46427(), this.method_25368(), this.method_25364(), class_9848.method_61317(this.field_22765));
            context.method_51427(this.getButtonIcon(),method_46426() + 2, method_46427() + 2);
            if (this.field_22762) {
                context.method_51438(this.getFont(), narrationMessage,method_46426() + 14, method_46427() + 18);
            }
        }
    }

    @Override
    public void method_25306(class_11907 inputWithModifiers) {
        this.nextState();
    }

    @Override
    public class_5250 method_25360() {
        return net.minecraft.class_2561.method_43469("gui.narrate.button", narrationMessage);
    }

    protected void setNarrationMessage(net.minecraft.class_2561 narrationMessage) {
        this.narrationMessage = narrationMessage;
    }
}
