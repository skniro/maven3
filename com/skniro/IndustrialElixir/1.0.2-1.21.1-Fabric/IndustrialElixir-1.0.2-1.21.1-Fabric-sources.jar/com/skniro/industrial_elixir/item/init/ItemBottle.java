package com.skniro.industrial_elixir.item.init;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_3468;

public class ItemBottle
        extends class_1792 {
    private static final int MAX_USE_TIME = 32;

    public ItemBottle(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        class_1657 playerEntity;
        super.method_7861(stack, world, user);

        // Advancement check + stat
        if (user instanceof class_3222 serverPlayerEntity) {
            class_174.field_1198.method_8821(serverPlayerEntity, stack);
            serverPlayerEntity.method_7259(class_3468.field_15372.method_14956(this));
        }

        if (user instanceof class_1657 && !(playerEntity = (class_1657)user).method_56992()) {
            class_1799 itemStack = new class_1799(class_1802.field_8469);
            if (!playerEntity.method_31548().method_7394(itemStack)) {
                playerEntity.method_7328(itemStack, false);
            }
        }
        return stack;
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 user) {
        return MAX_USE_TIME;
    }
}
