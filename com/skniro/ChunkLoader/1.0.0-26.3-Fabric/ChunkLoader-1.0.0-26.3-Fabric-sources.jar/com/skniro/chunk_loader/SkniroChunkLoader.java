package com.skniro.chunk_loader;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class SkniroChunkLoader implements ModInitializer {
    public static final String MOD_ID = "chunk_loader";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        //checkExpiration();
        
        ModContent.registerCommand();
        ModContent.registerFluids();
        ModContent.registerItem();
        ModContent.registerBlock();
        ModContent.registerEntity();
        ModContent.CreativeTab();
        ModContent.WorldGen();
        ModContent.registerOthers();
        ModContent.Compat();
    }
}
