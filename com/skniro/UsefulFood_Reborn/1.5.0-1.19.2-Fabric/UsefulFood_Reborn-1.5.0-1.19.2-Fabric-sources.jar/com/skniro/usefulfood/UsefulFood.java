package com.skniro.usefulfood;

import com.skniro.usefulfood.block.init.jam.UsefulfoodJamConversions;
import com.skniro.usefulfood.item.UsefulFoodItems;
import com.skniro.usefulfood.util.ModLootTableModifiers;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class UsefulFood implements ModInitializer {
    public static final String MOD_ID = "usefulfood";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);




     public static final class_1761 UsefulFood_Group = FabricItemGroupBuilder.build(
             new class_2960(MOD_ID, "test_group"),()-> new class_1799(UsefulFoodItems.Cheese));

    @Override
    public void onInitialize() {
        ModContent.registerItem();
        ModContent.registerBlock();
        ModContent.CreativeTab();
        ModLootTableModifiers.modifyLootTables();
        UsefulfoodJamConversions.registerJamConversions();
    }
}
