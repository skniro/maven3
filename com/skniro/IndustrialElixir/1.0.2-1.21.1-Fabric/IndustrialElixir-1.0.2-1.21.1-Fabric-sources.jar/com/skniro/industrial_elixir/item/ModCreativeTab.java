package com.skniro.industrial_elixir.item;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.energy.api.base.SimpleEnergyItem;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluidItems;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroupEntries;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModCreativeTab {
    public static final class_5321<class_1761> General = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(IndustrialElixir.MOD_ID, "general"));
    public static final class_5321<class_1761> Generators_And_Wiring = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(IndustrialElixir.MOD_ID, "generators_and_wiring"));
    public static final class_5321<class_1761> Reactor = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(IndustrialElixir.MOD_ID, "reactor"));
    public static final class_5321<class_1761> Machine = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(IndustrialElixir.MOD_ID, "machine"));
    public static final class_5321<class_1761> Tool_And_Utilities = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(IndustrialElixir.MOD_ID, "tool_and_utilities"));
    public static final class_5321<class_1761> Combat = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(IndustrialElixir.MOD_ID, "combat"));
    public static final class_5321<class_1761> Materials = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(IndustrialElixir.MOD_ID, "materials"));
    public static final class_5321<class_1761> AGRICULTURE = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(IndustrialElixir.MOD_ID, "agriculture"));

    public static void CreativeTab() {
        class_2378.method_39197(class_7923.field_44687, General, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GeneralBlocks.Machine.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.industrial_elixir.general"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Generators_And_Wiring, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.COAL_GENERATOR.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.industrial_elixir.generators_and_wiring"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Reactor, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.SACRED_GENERATOR.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.industrial_elixir.reactor"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Machine, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.Macerator_Block.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.industrial_elixir.machine"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Tool_And_Utilities, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresItems.ENERGY_STORAGE.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.industrial_elixir.tool_and_utilities"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Combat, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(MapleArmorItems.Quantum_HELMET.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.industrial_elixir.combat"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Materials, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresItems.Rubber.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.industrial_elixir.materials"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, AGRICULTURE, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(MapleFoodComponents.Coffee_Black.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.industrial_elixir.agriculture"))
                .method_47324()); // build() no longer registers by itself
    }

    public static void CreativeTabItem() {
        ItemGroupEvents.modifyEntriesEvent(General).register(content -> {
            content.method_45421(GeneralBlocks.Lead_Ore);
            content.method_45421(GeneralBlocks.Tin_Ore);
            content.method_45421(GeneralBlocks.SACRED_Ore);
            content.method_45421(GeneralBlocks.Deepslate_Lead_Ore);
            content.method_45421(GeneralBlocks.Deepslate_Tin_Ore);
            content.method_45421(GeneralBlocks.Deepslate_SACRED_Ore);
            content.method_45421(GeneralBlocks.Raw_Lead_Block);
            content.method_45421(GeneralBlocks.Raw_Tin_Block);
            content.method_45421(GeneralBlocks.Raw_SACRED_Block);
            content.method_45421(GeneralBlocks.Lead_Block);
            content.method_45421(GeneralBlocks.Tin_Block);
            content.method_45421(GeneralBlocks.SACRED_Block);
            content.method_45421(GeneralBlocks.Silver_Block);
            content.method_45421(GeneralBlocks.Bronze_Block);
            content.method_45421(GeneralBlocks.Steel_Block);

            content.method_45421(GeneralBlocks.Rubber_PLANKS);
            content.method_45421(GeneralBlocks.Rubber_STAIRS);
            content.method_45421(GeneralBlocks.Rubber_SLAB);
            content.method_45421(GeneralBlocks.Rubber_BUTTON);
            content.method_45421(GeneralBlocks.Rubber_PRESSURE_PLATE);
            content.method_45421(GeneralBlocks.Rubber_FENCE);
            content.method_45421(GeneralBlocks.Rubber_FENCE_GATE);
            content.method_45421(GeneralBlocks.Rubber_LOG);
            content.method_45421(GeneralBlocks.Rubber_WOOD);
            content.method_45421(GeneralBlocks.STRIPPED_Rubber_LOG);
            content.method_45421(GeneralBlocks.STRIPPED_Rubber_WOOD);
            content.method_45421(GeneralBlocks.Rubber_DOOR);
            content.method_45421(GeneralBlocks.Rubber_TRAPDOOR);
            content.method_45421(GeneralBlocks.Rubber_SAPLING);
            content.method_45421(GeneralBlocks.Rubber_LEAVES);
            content.method_45421(GeneralBlocks.Rubber_Rubber_LOG);
            content.method_45421(GeneralBlocks.COBBLESTONE_STAIRS);
            content.method_45421(GrowableOresItems.Sticky_Resin);
            content.method_45421(MapleArmorItems.Rubber_SIGN);
            content.method_45421(MapleArmorItems.Rubber_HANGING_SIGN);
            content.method_45421(GrowableOresItems.RUBBER_BOAT);
            content.method_45421(GrowableOresItems.RUBBER_CHEST_BOAT);
            content.method_45421(GeneralBlocks.Machine);
            content.method_45421(GeneralBlocks.Advanced_Machine);
            content.method_45421(GeneralBlocks.Super_Machine);
            content.method_45421(GrowableOresBlocks.FLUID_TANK_BLOCK);
            content.method_45421(GeneralBlocks.Reinforced_Stone);
            content.method_45421(GeneralBlocks.Reinforced_Glass);
            content.method_45421(GeneralBlocks.Reinforced_DOOR);

            //PLASTER
            content.method_45421(GeneralBlocks.GREEN_PLASTER);
            content.method_45421(GeneralBlocks.PLASTER);
            content.method_45421(GeneralBlocks.ORANGE_PLASTER);
            content.method_45421(GeneralBlocks.MAGENTA_PLASTER);
            content.method_45421(GeneralBlocks.LIGHT_BLUE_PLASTER);
            content.method_45421(GeneralBlocks.YELLOW_PLASTER);
            content.method_45421(GeneralBlocks.LIME_PLASTER);
            content.method_45421(GeneralBlocks.PINK_PLASTER);
            content.method_45421(GeneralBlocks.GRAY_PLASTER);
            content.method_45421(GeneralBlocks.LIGHT_GRAY_PLASTER);
            content.method_45421(GeneralBlocks.CYAN_PLASTER);
            content.method_45421(GeneralBlocks.PURPLE_PLASTER);
            content.method_45421(GeneralBlocks.BLUE_PLASTER);
            content.method_45421(GeneralBlocks.BROWN_PLASTER);
            content.method_45421(GeneralBlocks.RED_PLASTER);
        });

        ItemGroupEvents.modifyEntriesEvent(Generators_And_Wiring).register(content -> {
            content.method_45421(GrowableOresBlocks.COPPER_CABLE);
            content.method_45421(GrowableOresBlocks.TIN_CABLE);
            content.method_45421(GrowableOresBlocks.GOLD_CABLE);
            content.method_45421(GrowableOresBlocks.HV_CABLE);
            content.method_45421(GrowableOresBlocks.GLASSFIBER_CABLE);
            content.method_45421(GrowableOresBlocks.INSULATED_COPPER_CABLE);
            content.method_45421(GrowableOresBlocks.INSULATED_GOLD_CABLE);
            content.method_45421(GrowableOresBlocks.INSULATED_HV_CABLE);

            content.method_45421(GrowableOresBlocks.EnergyBox);
            content.method_45421(GrowableOresBlocks.ChargePad);
            content.method_45421(GrowableOresBlocks.CESU);
            content.method_45421(GrowableOresBlocks.MFE);
            content.method_45421(GrowableOresBlocks.MFSU);
            content.method_45421(GrowableOresBlocks.ChargePad);
            content.method_45421(GrowableOresBlocks.CESU_CHARGE_PAD);
            content.method_45421(GrowableOresBlocks.MFE_CHARGE_PAD);
            content.method_45421(GrowableOresBlocks.MFSU_CHARGE_PAD);
            content.method_45421(GrowableOresBlocks.LV_TRANSFORMER);
            content.method_45421(GrowableOresBlocks.MV_TRANSFORMER);
            content.method_45421(GrowableOresBlocks.HV_TRANSFORMER);
            content.method_45421(GrowableOresBlocks.EV_TRANSFORMER);
            content.method_45421(GrowableOresBlocks.Pipe_Wooden_Fluid_Block);
            content.method_45421(GrowableOresBlocks.Pipe_Stone_Fluid_Block);
            content.method_45421(GrowableOresBlocks.COAL_GENERATOR);
            content.method_45421(GrowableOresBlocks.FLUID_GENERATOR);
            content.method_45421(GrowableOresBlocks.GENERATOR_Wind_Mill);
            content.method_45421(GrowableOresBlocks.GENERATOR_SolarPanel);
            content.method_45421(GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL);
            content.method_45421(GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL);
            content.method_45421(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL);
            content.method_45421(GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL);
            content.method_45421(GrowableOresBlocks.Electric_Heater_Block);
            content.method_45421(GrowableOresBlocks.SOLID_FUEL_HEATER_GENERATOR);
        });

        ItemGroupEvents.modifyEntriesEvent(Reactor).register(content -> {
            content.method_45421(GrowableOresItems.SACRED_ESSENCE);
            content.method_45421(GrowableOresItems.SACRED_SHARD);
            content.method_45421(GrowableOresItems.SACRED_CORE);
            content.method_45421(GrowableOresItems.COOLANT_CELL_10K);
            content.method_45421(GrowableOresItems.COOLANT_CELL_30K);
            content.method_45421(GrowableOresItems.COOLANT_CELL_60K);
            content.method_45421(GrowableOresItems.HEAT_VENT);
            content.method_45421(GrowableOresItems.ADVANCED_HEAT_VENT);
            content.method_45421(GrowableOresItems.OVERCLOCKED_HEAT_VENT);
            content.method_45421(GrowableOresItems.EMPTY_VESSEL);
            //content.accept(GrowableOresItems.REACTOR_PLATING);
            //content.accept(GrowableOresItems.NEUTRON_REFLECTOR);
            //content.accept(GrowableOresItems.HEAT_EXCHANGER);
            content.method_45421(GrowableOresBlocks.SACRED_GENERATOR);

        });

        ItemGroupEvents.modifyEntriesEvent(Machine).register(content -> {
            content.method_45421(GrowableOresBlocks.Macerator_Block);
            content.method_45421(GrowableOresBlocks.Compressor_Block);
            content.method_45421(GrowableOresBlocks.MetalFormerBlock);
            content.method_45421(GrowableOresBlocks.Extractor_Block);

            content.method_45421(GrowableOresBlocks.MolecularTransformerBlock);

            content.method_45421(GrowableOresBlocks.Iron_Furnace_Block);
            content.method_45421(GrowableOresBlocks.ElectricFurnace_Block);
            content.method_45421(GrowableOresBlocks.INDUCTION_FURNACE);
            content.method_45421(GrowableOresBlocks.CUTTING_Block);
            content.method_45421(GrowableOresBlocks.RECYCLER_Block);
            content.method_45421(GrowableOresBlocks.Ore_Washing_Block);
            content.method_45421(GrowableOresBlocks.GrowableOres_Block);
            content.method_45421(GrowableOresBlocks.Brew_Reactor_BLOCK);
            content.method_45421(GrowableOresBlocks.Ore_Washing_Block);
            content.method_45421(GrowableOresBlocks.BLAST_FURNACE_BLOCK);
            content.method_45421(GrowableOresBlocks.HEAT_CENTRIFUGE);
            content.method_45421(GrowableOresBlocks.MATTER_GENERATOR);
            content.method_45421(GrowableOresBlocks.Replicator);
            content.method_45421(GrowableOresBlocks.PATTERN_STORAGE);
            content.method_45421(GrowableOresBlocks.CHUNK_LOADER);
            content.method_45421(GrowableOresBlocks.VENDOR_MACHINE_Block);
        });

        ItemGroupEvents.modifyEntriesEvent(Tool_And_Utilities).register(content -> {
            content.method_45421(IndustrialElixirFluidItems.Fluid_UU_BUCKET);
            content.method_45421(IndustrialElixirFluidItems.Fluid_AIR_BUCKET);
            content.method_45421(IndustrialElixirFluidItems.Hot_Spring_BUCKET);
            content.method_45421(GrowableOresItems.ENERGY_STORAGE);
            content.method_45421(GrowableOresItems.OVERCLOCKER);
            content.method_45421(GrowableOresItems.TRANSFORMER);
            content.method_45421(GrowableOresItems.REDSTONE_INVERTER);

            content.method_45421(MapleArmorItems.ROLLING);
            content.method_45421(MapleArmorItems.CUTTING);

            content.method_45421(GrowableOresItems.RE_BATTERY);
            addFullEnergyItem(content, GrowableOresItems.RE_BATTERY);
            content.method_45421(GrowableOresItems.ADVANCED_RE_BATTERY);
            addFullEnergyItem(content, GrowableOresItems.ADVANCED_RE_BATTERY);
            content.method_45421(GrowableOresItems.ENERGY_CRYSTAL);
            addFullEnergyItem(content, GrowableOresItems.ENERGY_CRYSTAL);
            content.method_45421(GrowableOresItems.LAPOTRON_CRYSTAL);
            addFullEnergyItem(content, GrowableOresItems.LAPOTRON_CRYSTAL);

            content.method_45421(GrowableOresItems.EMPTY_CELL);
            content.method_45421(GrowableOresItems.WATER_CELL);
            content.method_45421(GrowableOresItems.LAVA_CELL);
            content.method_45421(IndustrialElixirFluidItems.UU_CELL);
            content.method_45421(IndustrialElixirFluidItems.AIR_CELL);
            content.method_45421(IndustrialElixirFluidItems.Hot_Spring_CELL);
        });

        ItemGroupEvents.modifyEntriesEvent(Combat).register(content -> {
            content.method_45421(MapleArmorItems.Quantum_HELMET);
            addFullEnergyItem(content, MapleArmorItems.Quantum_HELMET);
            content.method_45421(MapleArmorItems.Quantum_CHESTPLATE);
            addFullEnergyItem(content, MapleArmorItems.Quantum_CHESTPLATE);
            content.method_45421(MapleArmorItems.Quantum_LEGGINGS);
            addFullEnergyItem(content, MapleArmorItems.Quantum_LEGGINGS);
            content.method_45421(MapleArmorItems.Quantum_BOOTS);
            addFullEnergyItem(content, MapleArmorItems.Quantum_BOOTS);
            content.method_45421(MapleArmorItems.Electric_Jetpack);
            addFullEnergyItem(content, MapleArmorItems.Electric_Jetpack);
            content.method_45421(MapleArmorItems.BRONZE_BOOTS);
            content.method_45421(MapleArmorItems.BRONZE_CHESTPLATE);
            content.method_45421(MapleArmorItems.BRONZE_HELMET);
            content.method_45421(MapleArmorItems.BRONZE_LEGGINGS);

            content.method_45421(MapleArmorItems.BRONZE_PICKAXE);
            content.method_45421(MapleArmorItems.BRONZE_AXE);
            content.method_45421(MapleArmorItems.BRONZE_SHOVEL);
            content.method_45421(MapleArmorItems.BRONZE_SWORD);
            content.method_45421(MapleArmorItems.BRONZE_HOE);

            content.method_45421(MapleArmorItems.Electric_Jetpack);
        });

        ItemGroupEvents.modifyEntriesEvent(Materials).register(content -> {
            content.method_45421(GrowableOresItems.Raw_Lead);
            content.method_45421(GrowableOresItems.Raw_Tin);
            content.method_45421(GrowableOresItems.Raw_SACRED);

            content.method_45421(GrowableOresItems.CRUSHED_COPPER);
            content.method_45421(GrowableOresItems.CRUSHED_GOLD);
            content.method_45421(GrowableOresItems.CRUSHED_IRON);
            content.method_45421(GrowableOresItems.CRUSHED_LEAD);
            content.method_45421(GrowableOresItems.CRUSHED_SILVER);
            content.method_45421(GrowableOresItems.CRUSHED_TIN);
            content.method_45421(GrowableOresItems.CRUSHED_SACRED);

            content.method_45421(GrowableOresItems.PURIFIED_COPPER);
            content.method_45421(GrowableOresItems.PURIFIED_GOLD);
            content.method_45421(GrowableOresItems.PURIFIED_IRON);
            content.method_45421(GrowableOresItems.PURIFIED_LEAD);
            content.method_45421(GrowableOresItems.PURIFIED_SILVER);
            content.method_45421(GrowableOresItems.PURIFIED_TIN);
            content.method_45421(GrowableOresItems.PURIFIED_SACRED);

            content.method_45421(GrowableOresItems.BRONZE_DUST);
            content.method_45421(GrowableOresItems.CLAY_DUST);
            content.method_45421(GrowableOresItems.COAL_DUST);
            content.method_45421(GrowableOresItems.COPPER_DUST);
            content.method_45421(GrowableOresItems.DIAMOND_DUST);
            content.method_45421(GrowableOresItems.ENERGIUM_DUST);
            content.method_45421(GrowableOresItems.GOLD_DUST);
            content.method_45421(GrowableOresItems.IRON_DUST);
            content.method_45421(GrowableOresItems.LAPIS_DUST);
            content.method_45421(GrowableOresItems.LEAD_DUST);
            content.method_45421(GrowableOresItems.LITHIUM_DUST);
            content.method_45421(GrowableOresItems.OBSIDIAN_DUST);
            content.method_45421(GrowableOresItems.SILICON_DIOXIDE_DUST);
            content.method_45421(GrowableOresItems.SILVER_DUST);
            content.method_45421(GrowableOresItems.STONE_DUST);
            content.method_45421(GrowableOresItems.SULFUR_DUST);
            content.method_45421(GrowableOresItems.TIN_DUST);

            content.method_45421(GrowableOresItems.SMALL_BRONZE_DUST);
            content.method_45421(GrowableOresItems.SMALL_COPPER_DUST);
            content.method_45421(GrowableOresItems.SMALL_GOLD_DUST);
            content.method_45421(GrowableOresItems.SMALL_IRON_DUST);
            content.method_45421(GrowableOresItems.SMALL_LAPIS_DUST);
            content.method_45421(GrowableOresItems.SMALL_LEAD_DUST);
            content.method_45421(GrowableOresItems.SMALL_LITHIUM_DUST);
            content.method_45421(GrowableOresItems.SMALL_OBSIDIAN_DUST);
            content.method_45421(GrowableOresItems.SMALL_SILVER_DUST);
            content.method_45421(GrowableOresItems.SMALL_SULFUR_DUST);
            content.method_45421(GrowableOresItems.SMALL_TIN_DUST);

            content.method_45421(GrowableOresItems.BRONZE_INGOT);
            content.method_45421(GrowableOresItems.LEAD_INGOT);
            content.method_45421(GrowableOresItems.SILVER_INGOT);
            content.method_45421(GrowableOresItems.STEEL_INGOT);
            content.method_45421(GrowableOresItems.TIN_INGOT);
            content.method_45421(GrowableOresItems.SACRED_INGOT);
            content.method_45421(GrowableOresItems.IMPURE_SACRED_STONE);

            content.method_45421(GrowableOresItems.BRONZE_PLATE);
            content.method_45421(GrowableOresItems.COPPER_PLATE);
            content.method_45421(GrowableOresItems.GOLD_PLATE);
            content.method_45421(GrowableOresItems.IRON_PLATE);
            content.method_45421(GrowableOresItems.LAPIS_PLATE);
            content.method_45421(GrowableOresItems.LEAD_PLATE);
            content.method_45421(GrowableOresItems.OBSIDIAN_PLATE);
            content.method_45421(GrowableOresItems.STEEL_PLATE);
            content.method_45421(GrowableOresItems.TIN_PLATE);

            content.method_45421(GrowableOresItems.DENSE_BRONZE_PLATE);
            content.method_45421(GrowableOresItems.DENSE_COPPER_PLATE);
            content.method_45421(GrowableOresItems.DENSE_GOLD_PLATE);
            content.method_45421(GrowableOresItems.DENSE_IRON_PLATE);
            content.method_45421(GrowableOresItems.DENSE_LAPIS_PLATE);
            content.method_45421(GrowableOresItems.DENSE_LEAD_PLATE);
            content.method_45421(GrowableOresItems.DENSE_OBSIDIAN_PLATE);
            content.method_45421(GrowableOresItems.DENSE_STEEL_PLATE);
            content.method_45421(GrowableOresItems.DENSE_TIN_PLATE);

            content.method_45421(GrowableOresItems.BRONZE_CASING);
            content.method_45421(GrowableOresItems.COPPER_CASING);
            content.method_45421(GrowableOresItems.GOLD_CASING);
            content.method_45421(GrowableOresItems.IRON_CASING);
            content.method_45421(GrowableOresItems.LEAD_CASING);
            content.method_45421(GrowableOresItems.STEEL_CASING);
            content.method_45421(GrowableOresItems.TIN_CASING);

            content.method_45421(GrowableOresItems.Rubber);
            content.method_45421(GrowableOresItems.CARBON_FIBRE);
            content.method_45421(GrowableOresItems.CARBON_MESH);
            content.method_45421(GrowableOresItems.CARBON_PLATE);
            content.method_45421(GrowableOresItems.COAL_BALL);
            content.method_45421(GrowableOresItems.COAL_BLOCK);
            content.method_45421(GrowableOresItems.COAL_CHUNK);
            content.method_45421(GrowableOresItems.INDUSTRIAL_DIAMOND);
            content.method_45421(GrowableOresItems.IRIDIUM_SHARD);
            content.method_45421(GrowableOresItems.IRIDIUM_ORE);
            content.method_45421(GrowableOresItems.IRIDIUM_PLATE);
            content.method_45421(GrowableOresItems.ALLOY_INGOT);
            content.method_45421(GrowableOresItems.ALLOY_PLATE);
            content.method_45421(GrowableOresItems.Circuit);
            content.method_45421(GrowableOresItems.Advanced_Circuit);
            content.method_45421(GrowableOresItems.Electric_Motor);
            content.method_45421(GrowableOresItems.Scrap);
            content.method_45421(GrowableOresItems.Scrap_box);
            content.method_45421(GrowableOresItems.Coil);
            content.method_45421(GrowableOresItems.SLAG);
            content.method_45421(GrowableOresItems.ASHES);
            content.method_45421(GrowableOresItems.PATTERN_STORAGE_CRYSTAL);
            content.method_45421(GrowableOresItems.RAW_PATTERN_STORAGE_CRYSTAL);
            content.method_45421(GrowableOresItems.HEAT_CONDUCTOR);

            content.method_45421(AdvancedItems.IRRADIANT_SACRED_INGOT);
            content.method_45421(AdvancedItems.IRRADIANT_GLASS_PANE);
            content.method_45421(AdvancedItems.LUMINITE);
            content.method_45421(AdvancedItems.ENRICHED_LUMINITE);
            content.method_45421(AdvancedItems.LUMINITE_ALLOY);
            content.method_45421(AdvancedItems.ENRICHED_LUMINITE_ALLOY);
            content.method_45421(AdvancedItems.IRIDIUM_AMETHYST_PLATE);
            content.method_45421(AdvancedItems.REINFORCED_IRIDIUM_AMETHYST_PLATE);
            content.method_45421(AdvancedItems.IRRADIANT_REINFORCED_PLATE);
            content.method_45421(AdvancedItems.LUMINITE_Part);
            content.method_45421(AdvancedItems.Iridium_INGOT);
            content.method_45421(AdvancedItems.Quantum_Core);
            content.method_45421(AdvancedItems.MT_Core);
        });

        ItemGroupEvents.modifyEntriesEvent(AGRICULTURE).register(content -> {
            content.method_45421(GrowableOresBlocks.COFFEE_MACHINE_Block);
            content.method_45421(GrowableOresBlocks.CROP_FARM_Block);
            content.method_45421(MapleFoodComponents.Coffee_Beans);
            content.method_45421(MapleFoodComponents.Coffee_Black);
            content.method_45421(MapleFoodComponents.Cappuccino);
            content.method_45421(MapleFoodComponents.Latte);
            content.method_45421(MapleFoodComponents.Mocha);
            content.method_45421(MapleFoodComponents.Hot_Cocoa);
        });
    }

    public static void addFullEnergyItem(FabricItemGroupEntries content, class_1792 item) {
        class_1799 stack = new class_1799(item);
        stack.method_7974(0);
        if (stack.method_7909() instanceof SimpleEnergyItem battery) {
            battery.setStoredEnergy(stack, battery.getEnergyCapacity(stack));
        }
        content.method_45420(stack);
    }

}
