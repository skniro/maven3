package com.skniro.industrial_elixir.screen.handler.container.fluid;

import com.skniro.industrial_elixir.block.entity.container.fluid.FluidTankBlockEntity;
import com.skniro.industrial_elixir.screen.AlchemyScreenHandlerType;
import com.skniro.industrial_elixir.screen.slot.UpgradeSlot;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3913;
import net.minecraft.class_3919;

public class FluidTankScreenHandler extends class_1703 {
    private final class_1263 inventory;
    public final FluidTankBlockEntity blockEntity;
    private final class_3913 propertyDelegate;

    public FluidTankScreenHandler(int pContainerId, class_1661 inv, class_2338 blockPos) {
        this(pContainerId, inv, inv.field_7546.method_37908().method_8321(blockPos), new class_3919(2));
    }

    public FluidTankScreenHandler(int pContainerId, class_1661 playerInventory, class_2586 entity, class_3913 delegate) {
        super(AlchemyScreenHandlerType.FluidTank, pContainerId);
        blockEntity = ((FluidTankBlockEntity) entity);
        this.propertyDelegate = delegate;
        this.inventory = blockEntity;
        this.method_7621(new class_1735(inventory,0, 52, 13));
        this.method_7621(new class_1735(inventory, 8, 52, 49));
        this.method_7621(new class_1735(inventory,9, 106, 13));
        this.method_7621(new class_1735(inventory, 10, 106, 49));
        addBasic(inventory, playerInventory, delegate);
    }

    private void addBasic(class_1263 inventory, class_1661 playerInventory, class_3913 propertyDelegate){
        addUpgradeSlot(inventory);
        addPlayerInventory(playerInventory);
        addPlayerHotbar(playerInventory);
        method_17360(propertyDelegate);
    }

    private void addUpgradeSlot(class_1263 inventory) {
        this.method_7621(new UpgradeSlot(inventory, 4, 151, 9));
        this.method_7621(new UpgradeSlot(inventory, 5, 151, 27));
        this.method_7621(new UpgradeSlot(inventory, 6, 151, 45));
        this.method_7621(new UpgradeSlot(inventory, 7, 151, 63));
    }

    @Override
    public class_1799 method_7601(class_1657 player, int invSlot) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(invSlot);
        if (slot != null && slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();
            if (invSlot < this.inventory.method_5439()) {
                if (!this.method_7616(originalStack, this.inventory.method_5439(), this.field_7761.size(), true)) {
                    return class_1799.field_8037;
                }
            } else if (!this.method_7616(originalStack, 0, this.inventory.method_5439(), false)) {
                return class_1799.field_8037;
            }

            if (originalStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }
        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 pPlayer) {
        return this.inventory.method_5443(pPlayer);
    }

    private void addPlayerInventory(class_1661 playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.method_7621(new class_1735(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }
    }

    private void addPlayerHotbar(class_1661 playerInventory) {
        for (int i = 0; i < 9; ++i) {
            this.method_7621(new class_1735(playerInventory, i, 8 + i * 18, 142));
        }
    }
}