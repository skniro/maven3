package com.skniro.nether_ores_reborn.item;

import com.skniro.nether_ores_reborn.NetherOres;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.item.*;

public class NetherOresItems {
    //Tool

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(NetherOres.MOD_ID, name),item);
    }

    public static void registerModItems() {
        NetherOres.LOGGER.info("Registering Ruby Items for " + NetherOres.MOD_ID);
    }

}
