package torcherino.block;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2276;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_9904;
import torcherino.api.TierSupplier;
import torcherino.block.entity.TorcherinoBlockEntity;

@SuppressWarnings({"deprecation"})
public final class JackoLanterinoBlock extends class_2276 implements class_2343, TierSupplier {
    private final class_2960 tierID;

    public JackoLanterinoBlock(class_2251 properties, class_2960 tier) {
        super(properties);
        this.tierID = tier;
    }

    @Override
    public class_2960 getTier() {
        return tierID;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new TorcherinoBlockEntity(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
        return TorcherinoLogic.getTicker(level, state, type);
    }
    @Deprecated
    public class_3619 getPistonPushReaction() {
        return class_3619.field_15975;
    }


    @Override
    public void method_9615(class_2680 newState, class_1937 level, class_2338 pos, class_2680 state, boolean boolean_1) {
        this.method_9612(null, level, pos, null, null, false);
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        class_1268 hand = class_1268.field_5808;
        return TorcherinoLogic.useWithoutItem(state, level, pos, player, hand, hit);
    }

    @Override
    public void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 neighborBlock, class_9904 orientation, boolean boolean_1) {
        TorcherinoLogic.neighborUpdate(state, level, pos, neighborBlock, orientation, boolean_1, (be) ->
                be.setPoweredByRedstone(level.method_49803(pos)));
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, class_1309 placer, class_1799 stack) {
        TorcherinoLogic.onPlaced(level, pos, state, placer, stack, this);
    }
}
