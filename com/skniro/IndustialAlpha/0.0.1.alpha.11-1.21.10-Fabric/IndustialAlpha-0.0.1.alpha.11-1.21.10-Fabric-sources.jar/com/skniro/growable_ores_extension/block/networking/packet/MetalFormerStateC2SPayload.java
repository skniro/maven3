package com.skniro.growable_ores_extension.block.networking.packet;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record MetalFormerStateC2SPayload(class_2338 pos, int state) implements class_8710 {

    public static final class_2960 ID = class_2960.method_60655(GrowableOresExtension.MOD_ID, "metal_former_state");

    public static final class_8710.class_9154<MetalFormerStateC2SPayload> TYPE =
            new class_8710.class_9154<>(ID);

    public static final class_9139<class_9129, MetalFormerStateC2SPayload> CODEC =
            class_9139.method_56435(
                    class_2338.field_48404, MetalFormerStateC2SPayload::pos,
                    class_9135.field_49675, MetalFormerStateC2SPayload::state,
                    MetalFormerStateC2SPayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}