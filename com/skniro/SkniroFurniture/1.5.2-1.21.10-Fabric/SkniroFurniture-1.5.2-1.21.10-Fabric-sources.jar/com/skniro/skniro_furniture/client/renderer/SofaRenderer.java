package com.skniro.skniro_furniture.client.renderer;

import com.skniro.skniro_furniture.entity.furniture.CushionEntity;
import com.skniro.skniro_furniture.entity.furniture.SofaEntity;
import net.minecraft.class_10017;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class SofaRenderer extends class_897<SofaEntity, class_10017> {

    public SofaRenderer(class_5617.class_5618 ctx) {
        super(ctx);
    }

    @Override
    public boolean shouldRender(SofaEntity livingEntity, class_4604 camera, double camX, double camY, double camZ) {
        return true;
    }

    @Override
    public class_10017 method_55269() {
        return new class_10017();
    }
}