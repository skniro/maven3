package com.skniro.chunk_loader.datagen.recipe;

import com.skniro.chunk_loader.block.GrowableOresBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.advancements.Advancement;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.data.recipes.RecipeProvider;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Recipe;

import java.util.concurrent.CompletableFuture;

import static net.minecraft.data.recipes.ShapedRecipeBuilder.shaped;

public class BaseMachineRecipeGenerator extends FabricRecipeProvider {
    public BaseMachineRecipeGenerator(FabricPackOutput output, CompletableFuture<HolderLookup.Provider> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected RecipeProvider createRecipeProvider(HolderLookup.Provider registries, BootstrapContext<Recipe<?>> recipes, BootstrapContext<Advancement> advancements) {
        return new RecipeProvider(recipes, advancements) {
            @Override
            public void buildRecipes() {
                shaped(RecipeCategory.MISC, GrowableOresBlocks.CHUNK_LOADER)
                        .define('E', Items.ENDER_PEARL)
                        .define('T', Items.IRON_INGOT)
                        .define('M', Items.IRON_BLOCK)
                        .define('L', Items.LAPIS_LAZULI)
                        .define('C', Items.COPPER_INGOT)
                        .pattern("TET").pattern("LML").pattern("TCT")
                        .unlockedBy("has_item", this.has(Items.IRON_BLOCK))
                        .save(this.output);
            }
        };
    }

    @Override
    public String getName() {
        return "BaseMachine";
    }
}
