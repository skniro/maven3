package com.skniro.industrial_elixir.datagen;


import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.block.MapleSignBlocks;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.growableoresir.block.GrowableICOresBlocks;
import com.skniro.industrial_elixir.item.MapleFoodComponents;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_141;
import net.minecraft.class_212;
import net.minecraft.class_4559;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import com.skniro.industrial_elixir.block.init.CoffeeBlock;
import java.util.concurrent.CompletableFuture;


public class IndustrialElixirLootTableGenerator extends FabricBlockLootTableProvider {
    protected IndustrialElixirLootTableGenerator(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }
    public static final float[] field_40605 = new float[]{0.048F, 0.0425F, 0.062333336F, 0.1F};


    @Override
    public void method_10379() {
        //MAPLE
        method_46025(MapleSignBlocks.Rubber_SIGN);
        method_46025(MapleSignBlocks.Rubber_WALL_SIGN);
        method_46025(MapleSignBlocks.Rubber_HANGING_SIGN);
        method_46025(MapleSignBlocks.Rubber_WALL_HANGING_SIGN);
        method_46025(GeneralBlocks.Rubber_LOG);
        method_46025(GeneralBlocks.Rubber_Rubber_LOG);
        method_46025(GeneralBlocks.Rubber_WOOD);
        method_45988(GeneralBlocks.Rubber_DOOR, method_46022(GeneralBlocks.Rubber_DOOR));
        method_46025(GeneralBlocks.Rubber_SAPLING);
        method_46023(GeneralBlocks.POTTED_Rubber_SAPLING);
        method_45988(GeneralBlocks.Rubber_LEAVES, method_45986(GeneralBlocks.Rubber_LEAVES, GeneralBlocks.Rubber_SAPLING, field_40605));
        method_46025(GeneralBlocks.Rubber_BUTTON);
        method_46025(GeneralBlocks.Rubber_FENCE);
        method_46025(GeneralBlocks.Rubber_FENCE_GATE);
        method_46025(GeneralBlocks.Rubber_PLANKS);
        method_46025(GeneralBlocks.Rubber_PRESSURE_PLATE);
        method_46025(GeneralBlocks.Rubber_SLAB);
        method_46025(GeneralBlocks.Rubber_STAIRS);
        method_46025(GeneralBlocks.Rubber_TRAPDOOR);
        method_46025(GeneralBlocks.STRIPPED_Rubber_LOG);
        method_46025(GeneralBlocks.STRIPPED_Rubber_WOOD);

        method_46025(GeneralBlocks.Raw_Lead_Block);
        method_46025(GeneralBlocks.Raw_Tin_Block);
        method_46025(GeneralBlocks.Raw_SACRED_Block);

        method_46025(GeneralBlocks.Lead_Block);
        method_46025(GeneralBlocks.Tin_Block);
        method_46025(GeneralBlocks.SACRED_Block);

        method_46025(GeneralBlocks.Silver_Block);
        method_46025(GeneralBlocks.Bronze_Block);
        method_46025(GeneralBlocks.Steel_Block);

        method_46025(GeneralBlocks.Advanced_Machine);
        method_46025(GeneralBlocks.Machine);
        method_46025(GeneralBlocks.Super_Machine);
        method_46025(GeneralBlocks.Reinforced_Stone);
        method_46025(GeneralBlocks.Reinforced_Glass);
        method_45988(GeneralBlocks.Reinforced_DOOR, method_46022(GeneralBlocks.Reinforced_DOOR));

        method_46025(GrowableOresBlocks.GrowableOres_Block);

        method_46025(GrowableOresBlocks.Macerator_Block);
        method_46025(GrowableOresBlocks.Compressor_Block);
        method_46025(GrowableOresBlocks.MATTER_GENERATOR);
        method_46025(GrowableOresBlocks.FLUID_GENERATOR);
        method_46025(GrowableOresBlocks.MetalFormerBlock);
        method_46025(GrowableOresBlocks.ElectricFurnace_Block);
        method_46025(GrowableOresBlocks.INDUCTION_FURNACE);
        method_46025(GrowableOresBlocks.HEAT_CENTRIFUGE);
        method_46025(GrowableOresBlocks.PATTERN_STORAGE);
        method_46025(GrowableOresBlocks.RECYCLER_Block);
        method_46025(GrowableOresBlocks.CUTTING_Block);

        method_46025(GrowableOresBlocks.COPPER_CABLE);
        method_46025(GrowableOresBlocks.TIN_CABLE);
        method_46025(GrowableOresBlocks.GOLD_CABLE);
        method_46025(GrowableOresBlocks.HV_CABLE);
        method_46025(GrowableOresBlocks.GLASSFIBER_CABLE);

        method_46025(GrowableOresBlocks.INSULATED_TIN_CABLE);
        method_46025(GrowableOresBlocks.INSULATED_COPPER_CABLE);
        method_46025(GrowableOresBlocks.INSULATED_GOLD_CABLE);
        method_46025(GrowableOresBlocks.INSULATED_HV_CABLE);

        method_46025(GrowableOresBlocks.COAL_GENERATOR);
        method_46025(GrowableOresBlocks.NUCLEAR_REACTOR);
        method_46025(GrowableOresBlocks.SACRED_GENERATOR);
        method_46025(GrowableOresBlocks.GENERATOR_Wind_Mill);

        method_46025(GrowableOresBlocks.EnergyBox);
        method_46025(GrowableOresBlocks.ChargePad);

        method_46025(GrowableOresBlocks.CESU);
        method_46025(GrowableOresBlocks.MFE);
        method_46025(GrowableOresBlocks.MFSU);

        method_46025(GrowableOresBlocks.CESU_CHARGE_PAD);
        method_46025(GrowableOresBlocks.MFE_CHARGE_PAD);
        method_46025(GrowableOresBlocks.MFSU_CHARGE_PAD);

        method_46025(GrowableOresBlocks.MolecularTransformerBlock);

        method_46025(GrowableOresBlocks.GENERATOR_SolarPanel);
        method_46025(GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL);
        method_46025(GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL);
        method_46025(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL);
        method_46025(GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL);

        method_46025(GrowableOresBlocks.Extractor_Block);

        method_46025(GrowableOresBlocks.EV_TRANSFORMER);
        method_46025(GrowableOresBlocks.HV_TRANSFORMER);
        method_46025(GrowableOresBlocks.MV_TRANSFORMER);
        method_46025(GrowableOresBlocks.LV_TRANSFORMER);

        method_46025(GrowableOresBlocks.Iron_Furnace_Block);

        method_46025(GrowableOresBlocks.Pipe_Wooden_Iten_Block);
        method_46025(GrowableOresBlocks.Pipe_Stone_Item_Block);
        method_46025(GrowableOresBlocks.Pipe_Wooden_Fluid_Block);
        method_46025(GrowableOresBlocks.Pipe_Stone_Fluid_Block);
        method_46025(GrowableOresBlocks.FLUID_TANK_BLOCK);
        method_46025(GrowableOresBlocks.Brew_Reactor_BLOCK);
        method_46025(GrowableOresBlocks.Ore_Washing_Block);
        method_46025(GrowableOresBlocks.Replicator);

        method_46025(GrowableOresBlocks.CHUNK_LOADER);

        method_46025(GrowableOresBlocks.Electric_Heater_Block);
        method_46025(GrowableOresBlocks.SOLID_FUEL_HEATER_GENERATOR);
        method_46025(GrowableOresBlocks.BLAST_FURNACE_BLOCK);

        method_45988(GeneralBlocks.Lead_Ore,
                method_45981(GeneralBlocks.Lead_Ore, GrowableOresItems.Raw_Lead));
        method_45988(GeneralBlocks.Tin_Ore,
                method_45981(GeneralBlocks.Tin_Ore, GrowableOresItems.Raw_Tin));
        method_45988(GeneralBlocks.SACRED_Ore,
                method_45981(GeneralBlocks.SACRED_Ore, GrowableOresItems.Raw_SACRED));
        method_45988(GeneralBlocks.Deepslate_Lead_Ore,
                method_45981(GeneralBlocks.Deepslate_Lead_Ore, GrowableOresItems.Raw_Lead));
        method_45988(GeneralBlocks.Deepslate_Tin_Ore,
                method_45981(GeneralBlocks.Deepslate_Tin_Ore, GrowableOresItems.Raw_Tin));
        method_45988(GeneralBlocks.Deepslate_SACRED_Ore,
                method_45981(GeneralBlocks.Deepslate_SACRED_Ore, GrowableOresItems.Raw_SACRED));

        //PLASTER
        method_46025(GeneralBlocks.GREEN_PLASTER);
        method_46025(GeneralBlocks.PLASTER);
        method_46025(GeneralBlocks.ORANGE_PLASTER);
        method_46025(GeneralBlocks.MAGENTA_PLASTER);
        method_46025(GeneralBlocks.LIGHT_BLUE_PLASTER);
        method_46025(GeneralBlocks.YELLOW_PLASTER);
        method_46025(GeneralBlocks.LIME_PLASTER);
        method_46025(GeneralBlocks.PINK_PLASTER);
        method_46025(GeneralBlocks.GRAY_PLASTER);
        method_46025(GeneralBlocks.LIGHT_GRAY_PLASTER);
        method_46025(GeneralBlocks.CYAN_PLASTER);
        method_46025(GeneralBlocks.PURPLE_PLASTER);
        method_46025(GeneralBlocks.BLUE_PLASTER);
        method_46025(GeneralBlocks.BROWN_PLASTER);
        method_46025(GeneralBlocks.RED_PLASTER);

        method_46025(GrowableOresBlocks.VENDOR_MACHINE_Block);
        method_46025(GrowableOresBlocks.CROP_FARM_Block);
        method_46025(GrowableOresBlocks.COFFEE_MACHINE_Block);
        method_45994(GeneralBlocks.Coffee_Block,
                (block) -> this.method_45977(block, class_52.method_324().method_336(
                        class_55.method_347()
                                .method_356(class_212.method_900(GeneralBlocks.Coffee_Block).method_22584(class_4559.class_4560.method_22523().method_22524(CoffeeBlock.AGE, 3)))
                                .method_351(class_77.method_411(MapleFoodComponents.Coffee_Beans)).method_353(class_141.method_621(class_5662.method_32462(2.0F, 3.0F)))).method_336(class_55.method_347()
                        .method_356(class_212.method_900(GeneralBlocks.Coffee_Block).method_22584(class_4559.class_4560.method_22523().method_22524(CoffeeBlock.AGE, 2)))
                        .method_351(class_77.method_411(MapleFoodComponents.Coffee_Beans))
                        .method_353(class_141.method_621(class_5662.method_32462(1.0F, 2.0F))))));

        method_46025(GeneralBlocks.COFFEE_BLACK);
        method_46025(GeneralBlocks.CAPPUCCINO);
        method_46025(GeneralBlocks.MOCHA);
        method_46025(GeneralBlocks.LATTE);
        method_46025(GeneralBlocks.HOT_COCOA);



        method_46025(GrowableICOresBlocks.IER_Bronze_Cane);
        method_46025(GrowableICOresBlocks.IER_silver_Cane);
        method_46025(GrowableICOresBlocks.IER_Tin_Cane);
        method_46025(GrowableICOresBlocks.IER_SACRED_Cane);
        method_46025(GrowableICOresBlocks.IER_steel_Cane);
        method_46025(GrowableICOresBlocks.IER_LEAD_Cane);

        method_46025(GeneralBlocks.COBBLESTONE_STAIRS);

    }
}
