package com.skniro.maple.particle;

import com.skniro.maple.Maple;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;


public class MapleParticleTypes {
    public static final class_2400 CHERRY_LEAVES = FabricParticleTypes.simple();
    public static final class_2400 SAKURA_LEAVES = FabricParticleTypes.simple();
    public static final class_2400 HOT_SPRING = FabricParticleTypes.simple();

    static {
        class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(Maple.MOD_ID,"cherry_leaves"), CHERRY_LEAVES);
        class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(Maple.MOD_ID,"sakura_leaves"), SAKURA_LEAVES);
        class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(Maple.MOD_ID,"hot_spring"), HOT_SPRING);
    }

    public static void registerParticleTypes() {
        Maple.LOGGER.info("register Maple Particle Types for"+ Maple.MOD_ID );
    }
}
