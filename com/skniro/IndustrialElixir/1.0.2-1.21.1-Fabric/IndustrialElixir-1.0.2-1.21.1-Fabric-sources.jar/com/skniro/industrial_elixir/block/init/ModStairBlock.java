package com.skniro.industrial_elixir.block.init;

import com.skniro.industrial_elixir.api.block.SimpleHotsSpringLoggedBlock;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluidItems;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluids;
import com.skniro.industrial_elixir.util.ModBooleanPropertys;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2510;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2760;
import net.minecraft.class_2778;
import net.minecraft.class_3414;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.state.properties.*;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class ModStairBlock extends class_2510 implements SimpleHotsSpringLoggedBlock {

    public static final class_2746 HOT_SPRING_LOGGED = ModBooleanPropertys.HOT_SPRING_LOGGED;

    public ModStairBlock(class_2680 baseState, class_2251 properties) {
        super(baseState, properties);
        this.method_9590(this.method_9595().method_11664().method_11657(ModBooleanPropertys.HOT_SPRING_LOGGED, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(ModBooleanPropertys.HOT_SPRING_LOGGED);
    }

    public class_2680 method_9605(final class_1750 context) {
        class_2350 clickedFace = context.method_8038();
        class_2338 pos = context.method_8037();
        class_3610 replacedFluidState = context.method_8045().method_8316(pos);
        class_2680 state = (class_2680)((class_2680)((class_2680)this.method_9564().method_11657(field_11571, context.method_8042())).method_11657(field_11572, clickedFace != class_2350.field_11033 && (clickedFace == class_2350.field_11036 || !(context.method_17698().field_1351 - (double)pos.method_10264() > (double)0.5F)) ? class_2760.field_12617 : class_2760.field_12619)).method_11657(field_11573, replacedFluidState.method_39360(class_3612.field_15910)).method_11657(HOT_SPRING_LOGGED, replacedFluidState.method_39360(IndustrialElixirFluids.STILL_Hot_Spring));
        return (class_2680)state.method_11657(field_11565, method_10675(state, context.method_8045(), pos));
    }

    private static class_2778 method_10675(final class_2680 state, final class_1922 level, final class_2338 pos) {
        class_2350 facing = (class_2350)state.method_11654(field_11571);
        class_2680 behindState = level.method_8320(pos.method_10093(facing));
        if (method_10676(behindState) && state.method_11654(field_11572) == behindState.method_11654(field_11572)) {
            class_2350 behindFacing = (class_2350)behindState.method_11654(field_11571);
            if (behindFacing.method_10166() != ((class_2350)state.method_11654(field_11571)).method_10166() && method_10678(state, level, pos, behindFacing.method_10153())) {
                if (behindFacing == facing.method_10160()) {
                    return class_2778.field_12708;
                }

                return class_2778.field_12709;
            }
        }

        class_2680 frontState = level.method_8320(pos.method_10093(facing.method_10153()));
        if (method_10676(frontState) && state.method_11654(field_11572) == frontState.method_11654(field_11572)) {
            class_2350 frontFacing = (class_2350)frontState.method_11654(field_11571);
            if (frontFacing.method_10166() != ((class_2350)state.method_11654(field_11571)).method_10166() && method_10678(state, level, pos, frontFacing)) {
                if (frontFacing == facing.method_10160()) {
                    return class_2778.field_12712;
                }

                return class_2778.field_12713;
            }
        }

        return class_2778.field_12710;
    }

    private static boolean method_10678(final class_2680 state, final class_1922 level, final class_2338 pos, final class_2350 neighbour) {
        class_2680 neighborState = level.method_8320(pos.method_10093(neighbour));
        return !method_10676(neighborState) || neighborState.method_11654(field_11571) != state.method_11654(field_11571) || neighborState.method_11654(field_11572) != state.method_11654(field_11572);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_2350 directionToNeighbour, class_2680 neighbourState, class_1936 level, class_2338 pos, class_2338 neighbourPos) {
        if (state.method_11654(class_2741.field_12508)) {
            level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
        }

        if (state.method_11654(ModBooleanPropertys.HOT_SPRING_LOGGED)) {
            level.method_39281(pos, IndustrialElixirFluids.STILL_Hot_Spring, IndustrialElixirFluids.STILL_Hot_Spring.method_15789(level));
        }

        return directionToNeighbour.method_10166().method_10179() ? state.method_11657(field_11565, method_10675(state, level, pos)) : super.method_9559(state, directionToNeighbour, neighbourState, level, pos, neighbourPos);
    }

    @Override
    public class_3610 method_9545(class_2680 state) {
        if (state.method_11654(ModBooleanPropertys.HOT_SPRING_LOGGED)) {
            return IndustrialElixirFluids.STILL_Hot_Spring.method_15729(false);
        }
        return state.method_11654(class_2741.field_12508) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    public boolean method_10310(@Nullable class_1657 user, class_1922 level, class_2338 pos, class_2680 state, class_3611 type) {
        if (type == class_3612.field_15910 || type == IndustrialElixirFluids.STILL_Hot_Spring) {
            return !state.method_11654(class_2741.field_12508) && !state.method_11654(ModBooleanPropertys.HOT_SPRING_LOGGED);
        }
        return false;
    }

    @Override
    public boolean method_10311(class_1936 level, class_2338 pos, class_2680 state, class_3610 fluidState) {
        if (state.method_11654(class_2741.field_12508) || state.method_11654(ModBooleanPropertys.HOT_SPRING_LOGGED)) {
            return false;
        }

        class_3611 fluid = fluidState.method_15772();

        if (fluid == class_3612.field_15910) {
            if (!level.method_8608()) {
                level.method_8652(pos, state.method_11657(class_2741.field_12508, true), 3);
                level.method_39281(pos, fluid, fluid.method_15789(level));
            }
            return true;
        }

        if (fluid == IndustrialElixirFluids.STILL_Hot_Spring) {
            if (!level.method_8608()) {
                level.method_8652(pos, state.method_11657(ModBooleanPropertys.HOT_SPRING_LOGGED, true), 3);
                level.method_39281(pos, fluid, fluid.method_15789(level));
            }
            return true;
        }

        return false;
    }

    @Override
    public class_1799 method_9700(@Nullable class_1657 user, class_1936 level, class_2338 pos, class_2680 state) {
        if (state.method_11654(ModBooleanPropertys.HOT_SPRING_LOGGED)) {
            level.method_8652(pos, state.method_11657(ModBooleanPropertys.HOT_SPRING_LOGGED, false), 3);
            if (!state.method_26184(level, pos)) {
                level.method_22352(pos, true);
            }
            return new class_1799(IndustrialElixirFluidItems.Hot_Spring_BUCKET);
        }

        if (state.method_11654(class_2741.field_12508)) {
            level.method_8652(pos, state.method_11657(class_2741.field_12508, false), 3);
            if (!state.method_26184(level, pos)) {
                level.method_22352(pos, true);
            }
            return new class_1799(class_1802.field_8705);
        }

        return class_1799.field_8037;
    }

    @Override
    public Optional<class_3414> method_32351() {
        return IndustrialElixirFluids.STILL_Hot_Spring.method_32359();
    }


}
