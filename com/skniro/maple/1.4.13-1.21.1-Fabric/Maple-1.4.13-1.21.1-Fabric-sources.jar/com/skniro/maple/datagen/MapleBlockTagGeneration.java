package com.skniro.maple.datagen;

import com.skniro.maple.block.MapleBlocks;
import com.skniro.maple.block.MapleNetherOresBlocks;
import com.skniro.maple.block.MapleOreBlocks;
import com.skniro.maple.block.MapleSignBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

import static com.skniro.maple.datagen.MapleBlockTagGeneration.ModBlockTags.*;
import static net.minecraft.class_3481.*;


public class MapleBlockTagGeneration extends FabricTagProvider.BlockTagProvider {
    public MapleBlockTagGeneration(FabricDataOutput dataGenerator,CompletableFuture<class_7225.class_7874> completableFuture) {
        super(dataGenerator, completableFuture);
    }


    public static class ModBlockTags {
        public static final class_6862<class_2248> C_SAPLING = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "saplings"));
        public static final class_6862<class_2248> C_MAPLE_LOGS = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "maple_logs"));
        public static final class_6862<class_2248> C_CHERRY_LOGS = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "cherry_logs"));
        public static final class_6862<class_2248> C_PLASTER = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "plaster"));

    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        method_10512(field_15462)
                .add(MapleBlocks.MAPLE_SAPLING)
                .add(MapleBlocks.CHERRY_SAPLING);
        method_10512(C_SAPLING)
                .add(MapleBlocks.MAPLE_SAPLING)
                .add(MapleBlocks.CHERRY_SAPLING);
        method_10512(C_MAPLE_LOGS)
                .add(MapleBlocks.MAPLE_LOG);
        method_10512(C_CHERRY_LOGS)
                .add(MapleBlocks.CHERRY_LOG);
        method_10512(field_16584)
                .add(MapleBlocks.MAPLE_FENCE)
                .add(MapleBlocks.CHERRY_FENCE)
                .add(MapleBlocks.BAMBOO_FENCE);
        method_10512(C_PLASTER)
                .add(MapleBlocks.GREEN_PLASTER)
                .add(MapleBlocks.PLASTER)
                .add(MapleBlocks.ORANGE_PLASTER)
                .add(MapleBlocks.MAGENTA_PLASTER)
                .add(MapleBlocks.LIGHT_BLUE_PLASTER)
                .add(MapleBlocks.YELLOW_PLASTER)
                .add(MapleBlocks.LIME_PLASTER)
                .add(MapleBlocks.PINK_PLASTER)
                .add(MapleBlocks.GRAY_PLASTER)
                .add(MapleBlocks.LIGHT_GRAY_PLASTER)
                .add(MapleBlocks.CYAN_PLASTER)
                .add(MapleBlocks.PURPLE_PLASTER)
                .add(MapleBlocks.BLUE_PLASTER)
                .add(MapleBlocks.BROWN_PLASTER)
                .add(MapleBlocks.RED_PLASTER);
        method_10512(field_33715)
                .add(MapleBlocks.GREEN_PLASTER)
                .add(MapleBlocks.PLASTER)
                .add(MapleBlocks.ORANGE_PLASTER)
                .add(MapleBlocks.MAGENTA_PLASTER)
                .add(MapleBlocks.LIGHT_BLUE_PLASTER)
                .add(MapleBlocks.YELLOW_PLASTER)
                .add(MapleBlocks.LIME_PLASTER)
                .add(MapleBlocks.PINK_PLASTER)
                .add(MapleBlocks.GRAY_PLASTER)
                .add(MapleBlocks.LIGHT_GRAY_PLASTER)
                .add(MapleBlocks.CYAN_PLASTER)
                .add(MapleBlocks.PURPLE_PLASTER)
                .add(MapleBlocks.BLUE_PLASTER)
                .add(MapleBlocks.BROWN_PLASTER)
                .add(MapleBlocks.RED_PLASTER)
                .add(MapleOreBlocks.Salt_Ore)
                .add(MapleOreBlocks.DEEPSLATE_Salt_Ore)
                .add(MapleNetherOresBlocks.Nether_Coal_Ore)
                .add(MapleNetherOresBlocks.Nether_Diamond_Ore)
                .add(MapleNetherOresBlocks.Nether_Copper_Ore)
                .add(MapleNetherOresBlocks.Nether_Emerald_Ore)
                .add(MapleNetherOresBlocks.Nether_Iron_Ore)
                .add(MapleNetherOresBlocks.Nether_Gold_Ore)
                .add(MapleNetherOresBlocks.Nether_Lapis_Ore)
                .add(MapleNetherOresBlocks.Nether_Redstone_Ore)
                .setReplace(false);
        method_10512(field_40103)
                .add(MapleSignBlocks.Maple_HANGING_SIGN)
                .add(MapleSignBlocks.GINKGO_HANGING_SIGN);
        method_10512(field_40104)
                .add(MapleSignBlocks.Maple_WALL_HANGING_SIGN)
                .add(MapleSignBlocks.GINKGO_WALL_HANGING_SIGN);
    }
}
