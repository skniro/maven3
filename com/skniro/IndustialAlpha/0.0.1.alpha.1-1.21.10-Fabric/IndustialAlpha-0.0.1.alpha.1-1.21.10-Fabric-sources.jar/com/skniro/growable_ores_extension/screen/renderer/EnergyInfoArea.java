package com.skniro.growable_ores_extension.screen.renderer;

import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_768;

/*
 *  BluSunrize
 *  Copyright (c) 2021
 *
 *  This code is licensed under "Blu's License of Common Sense" (FORGE VERSION)
 *  Modified for Fabric by: Kaupenjoe
 */
public class EnergyInfoArea {
    private final class_768 area;
    private final EnergyStorage energy;

    public EnergyInfoArea(int xMin, int yMin)  {
        this(xMin, yMin, null,8,64);
    }

    public EnergyInfoArea(int xMin, int yMin, EnergyStorage energy)  {
        this(xMin, yMin, energy,8,64);
    }

    public EnergyInfoArea(int xMin, int yMin, EnergyStorage energy, int width, int height)  {
        area = new class_768(xMin, yMin, width, height);
        this.energy = energy;
    }

    public List<class_2561> getTooltips() {
        return List.of(class_2561.method_43470(energy.getAmount()+" / "+energy.getCapacity()+" E"));
    }

    public void draw(class_332 context) {
        final int height = area.method_3320();
        int stored = (int)(height*(energy.getAmount()/(float)energy.getCapacity()));
        context.method_25296(
                area.method_3321(), area.method_3322()+(height-stored),
                area.method_3321() + area.method_3319(), area.method_3322() +area.method_3320(),
                0xffb51500, 0xff600b00
        );
    }
}