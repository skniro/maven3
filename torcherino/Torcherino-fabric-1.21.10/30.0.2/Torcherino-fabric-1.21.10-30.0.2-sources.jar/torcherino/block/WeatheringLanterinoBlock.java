package torcherino.block;

import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import torcherino.api.TierSupplier;
import torcherino.block.api.LanterinoOxidizableRegistry;
import torcherino.block.entity.TorcherinoBlockEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import net.minecraft.class_5953;
import net.minecraft.class_5955;

public class WeatheringLanterinoBlock extends CopperLanterinoBlock implements class_5955, class_2343, TierSupplier {
    private final class_5955.class_5811 weatherState;

    public WeatheringLanterinoBlock(class_5955.class_5811 weatherState, class_4970.class_2251 properties, class_2960 tier) {
        super(properties, tier);
        this.weatherState = weatherState;
    }

    @Override
    protected void method_9514(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        class_2586 be = level.method_8321(pos);
        Optional<class_2248> nextOpt = class_5955.method_34737(state.method_26204());
        TorcherinoBlockEntity.Data saved = null;
        if (be instanceof TorcherinoBlockEntity oldBE) {
            saved = TorcherinoBlockEntity.Data.from(oldBE);
        }

        class_2680 newState = nextOpt.get().method_9564();

        level.method_8652(pos, newState, class_2248.field_31036);

        if (saved != null) {
            class_2586 newBE = level.method_8321(pos);
            if (newBE instanceof TorcherinoBlockEntity torcherinoBE) {
                torcherinoBE.restore(saved);
            }
        }
    }

    @Override
    protected @NotNull class_1269 method_55765(class_1799 itemStack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {

        class_1799 stack = player.method_5998(hand);
        class_1792 item = stack.method_7909();

        boolean handled = false;

        if (item == class_1802.field_20414) {
            if (!level.method_8608()) {
                BiMap<class_2248, class_2248> waxables = (BiMap<class_2248, class_2248>) class_5953.field_29560.get();
                class_2248 waxed = waxables.get(state.method_26204());
                if (waxed != null) {
                    swapPreserveTorcherinoBE((class_3218) level, pos, state, waxed.method_9564());
                    if (!player.method_31549().field_7477) stack.method_7934(1);
                    level.method_8444(player, 3003, pos, 0);
                    handled = true;
                }
            }
        }


        if (item instanceof class_1743) {
            if (!level.method_8608()) {
                BiMap<class_2248, class_2248> waxOffMap = (BiMap<class_2248, class_2248>) class_5953.field_29561.get();
                class_2248 unwaxed = waxOffMap.get(state.method_26204());
                if (unwaxed != null) {
                    swapPreserveTorcherinoBE((class_3218) level, pos, state, unwaxed.method_9564());
                    stack.method_7956(1, (class_3218) level, null, (p) -> {
                    });
                    level.method_8444(player, 3005, pos, 0);
                    handled = true;
                }

                BiMap<class_2248, class_2248> prevMap = (BiMap<class_2248, class_2248>) class_5955.field_29565.get();
                class_2248 prev = prevMap.get(state.method_26204());
                if (prev != null) {
                    swapPreserveTorcherinoBE((class_3218) level, pos, state, prev.method_9564());
                    stack.method_7956(1, (class_3218) level, null, (p) -> {
                    });
                    level.method_8444(player, 3004, pos, 0);
                    handled = true;
                }
            }
        }

        return handled ? class_1269.field_5812 : super.method_55765(itemStack, state, level, pos, player, hand, hit);
    }


    public static void swapPreserveTorcherinoBE(class_3218 level, class_2338 pos,
                                                class_2680 oldState, class_2680 newState) {
        class_2586 oldBE = level.method_8321(pos);
        TorcherinoBlockEntity.Data data = null;

        if (oldBE instanceof TorcherinoBlockEntity torcherino) {
            data = TorcherinoBlockEntity.Data.from(torcherino);
        }

        level.method_8652(pos, newState, class_2248.field_31036);
        class_2586 newBE = level.method_8321(pos);

        if (data != null && newBE instanceof TorcherinoBlockEntity torcherino) {
            torcherino.restore(data);
            torcherino.method_5431();
        }
    }

    protected boolean method_9542(class_2680 blockState) {
        return class_5955.method_34737(blockState.method_26204()).isPresent();
    }

    public class_5955.class_5811 method_33622() {
        return this.weatherState;
    }
}
