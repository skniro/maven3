package com.skniro.industrial_elixir.block.entity.pipe;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.pipe.WoodPipeBlock;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import org.jetbrains.annotations.Nullable;

public class WoodPipeBlockEntity extends PipeBlockEntity {

    public WoodPipeBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.PIPE_Wooden_BLOCK_ENTITY,pos, state);
    }


    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) return;
        super.tick(world, pos, state);
        moveItems(world, pos, state);
        extractItems(world, pos, state);
    }

    @Override
    protected void onExtractDirectionChanged(@Nullable class_2350 direction) {
        if (field_11863 == null || field_11863.method_8608()) {
            return;
        }

        class_2680 state = method_11010();
        if (!(state.method_26204() instanceof WoodPipeBlock)) {
            return;
        }

        class_2680 newState = state;
        for (class_2350 dir : class_2350.values()) {
            class_2746 property = WoodPipeBlock.PULL_PROPERTY_MAP.get(dir);
            boolean active = dir == direction;
            if (newState.method_11654(property) != active) {
                newState = newState.method_11657(property, active);
            }
        }

        if (newState != state) {
            field_11863.method_8652(field_11867, newState, class_2248.field_31028);
        }
    }
}
