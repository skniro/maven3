package com.skniro.growable_ores_extension.item.init.equipment;

import com.google.common.collect.Maps;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_156;
import net.minecraft.class_1741;
import net.minecraft.class_3417;
import net.minecraft.class_8051;

public interface MapleArmorMaterials
{
    public static final class_1741 QUANTUM = new class_1741(
            37, class_156.method_654(new EnumMap<>(class_8051.class), map -> {
                map.put(class_8051.field_41937, 4);
                map.put(class_8051.field_41936, 7);
                map.put(class_8051.field_41935, 10);
                map.put(class_8051.field_41934, 4);
                map.put(class_8051.field_48838, 15);
            }), 25, class_3417.field_21866, 5.0F, 0.1F,null, MapleEquipmentAssetKeys.QUANTUM
    );

    class_1741 BRONZE = new class_1741(15, createDefenseMap(2, 5, 6, 2, 5), 9, class_3417.field_14862, 0.0F, 0.0F, ModItemTags.REPAIRS_BRONZE_ARMOR, MapleEquipmentAssetKeys.BRONZE);

    private static Map<class_8051, Integer> createDefenseMap(int bootsDefense, int leggingsDefense, int chestplateDefense, int helmetDefense, int bodyDefense) {
        return Maps.newEnumMap(Map.of(class_8051.field_41937, bootsDefense, class_8051.field_41936, leggingsDefense, class_8051.field_41935, chestplateDefense, class_8051.field_41934, helmetDefense, class_8051.field_48838, bodyDefense));
    }
}
