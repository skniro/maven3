package com.skniro.growable_ores_extension.datagen.recipe.machine;

import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.item.AdvancedItems;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class CuttingRecipeGenerator extends FabricRecipeProvider {
    public CuttingRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {
                createCutting(class_1802.field_8773, GrowableOresItems.IRON_PLATE,9).method_10431(field_53721);
                createCutting(class_1802.field_8281, GrowableOresItems.OBSIDIAN_PLATE,4).method_10431(field_53721);
                createCutting(class_1802.field_8494, GrowableOresItems.GOLD_PLATE,9).method_10431(field_53721);
                createCutting(class_1802.field_8055, GrowableOresItems.LAPIS_PLATE,9).method_10431(field_53721);
                createCutting(class_1802.field_27071, GrowableOresItems.COPPER_PLATE,9).method_10431(field_53721);
                createCutting(GeneralBlocks.Bronze_Block, GrowableOresItems.BRONZE_PLATE,9).method_10431(field_53721);
                createCutting(GeneralBlocks.Lead_Block, GrowableOresItems.LEAD_PLATE,9).method_10431(field_53721);
                createCutting(GeneralBlocks.Tin_Block, GrowableOresItems.TIN_PLATE,9).method_10431(field_53721);
                createCutting(GeneralBlocks.Steel_Block, GrowableOresItems.STEEL_PLATE,9).method_10431(field_53721);

                addWoodSet(field_53721, class_1802.field_8583, class_1802.field_8415, class_1802.field_8888, class_1802.field_8248, class_1802.field_8118, "oak");
                addWoodSet(field_53721, class_1802.field_8684, class_1802.field_8624, class_1802.field_8210, class_1802.field_8362, class_1802.field_8113, "spruce");
                addWoodSet(field_53721, class_1802.field_8170, class_1802.field_8767, class_1802.field_8201, class_1802.field_8472, class_1802.field_8191, "birch");
                addWoodSet(field_53721, class_1802.field_8125, class_1802.field_8334, class_1802.field_8439, class_1802.field_8785, class_1802.field_8842, "jungle");
                addWoodSet(field_53721, class_1802.field_8820, class_1802.field_8072, class_1802.field_8587, class_1802.field_8284, class_1802.field_8651, "acacia");
                addWoodSet(field_53721, class_1802.field_8652, class_1802.field_8808, class_1802.field_8458, class_1802.field_8219, class_1802.field_8404, "dark_oak");
                addWoodSet(field_53721, class_1802.field_37512, class_1802.field_37515, class_1802.field_37510, class_1802.field_37509, class_1802.field_37507, "mangrove");
                addWoodSet(field_53721, class_1802.field_42692, class_1802.field_42693, class_1802.field_42691, class_1802.field_42690, class_1802.field_42687, "cherry");
                addWoodSet(field_53721, class_1802.field_41066, class_1802.field_41065, class_1802.field_41066, class_1802.field_41065, class_1802.field_40213, "bamboo");
                addWoodSet(field_53721, class_1802.field_21981, class_1802.field_21983, class_1802.field_22489, class_1802.field_22487, class_1802.field_22031, "crimson");
                addWoodSet(field_53721, class_1802.field_21982, class_1802.field_21984, class_1802.field_22490, class_1802.field_22488, class_1802.field_22032, "warped");
                addWoodSet(field_53721, class_1802.field_54603, class_1802.field_54604, class_1802.field_54607, class_1802.field_54606, class_1802.field_54601, "pale_oak");
                addWoodSet(field_53721, GeneralBlocks.Rubber_LOG, GeneralBlocks.STRIPPED_Rubber_LOG, GeneralBlocks.Rubber_WOOD, GeneralBlocks.STRIPPED_Rubber_WOOD, GeneralBlocks.Rubber_PLANKS, "rubber");
                createCutting(GeneralBlocks.Rubber_Rubber_LOG, GeneralBlocks.Rubber_PLANKS,6).method_36443(field_53721, "rubber_rubber_log_to_planks");
            }
        };
    }

    @Override
    public String method_10321() {
        return "Cutting";
    }
}
