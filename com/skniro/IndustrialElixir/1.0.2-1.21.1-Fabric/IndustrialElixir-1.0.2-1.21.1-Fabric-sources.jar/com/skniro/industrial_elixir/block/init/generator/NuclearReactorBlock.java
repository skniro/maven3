package com.skniro.industrial_elixir.block.init.generator;

import com.mojang.serialization.MapCodec;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.entity.generator.NuclearReactorBlockEntity;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import net.minecraft.class_9062;
import org.jetbrains.annotations.Nullable;

public class NuclearReactorBlock extends class_2237 {
    public static final MapCodec<NuclearReactorBlock> CODEC = method_54094(NuclearReactorBlock::new);
    public static final class_2754<class_2350> FACING = class_2383.field_11177;
    public static final class_2746 LIT = class_2741.field_12548;

    public NuclearReactorBlock(class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043).method_11657(LIT, false));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(FACING, context.method_8042().method_10153()).method_11657(LIT, false);
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, LIT);
    }

    @Override
    public void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204()) && level.method_8321(pos) instanceof NuclearReactorBlockEntity reactor) {
            class_1264.method_5451(level, pos, reactor);
            level.method_8455(pos, this);
        }
        super.method_9536(state, level, pos, newState, moved);
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!level.method_8608()) {
            class_3908 menuProvider = (NuclearReactorBlockEntity) level.method_8321(pos);
            if (menuProvider != null) {
                player.method_17355(menuProvider);
            }
        }
        return class_9062.field_47728;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new NuclearReactorBlockEntity(pos, state);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        if (state.method_11654(LIT) && random.method_43058() < 0.25) {
            level.method_8486(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, class_3417.field_15045, class_3419.field_15245, 0.35F, 0.8F, false);
        }
    }

    @Override
    public @Nullable <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
        if (level.method_8608()) {
            return null;
        }
        return method_31618(type, AlchemyBlockEntityType.NUCLEAR_REACTOR_BE, (level1, pos, state1, blockEntity) -> blockEntity.tick(level1, pos, state1));
    }
}
