package com.skniro.industrial_elixir.recipe.machine;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.world.item.crafting.*;
import com.skniro.industrial_elixir.recipe.ModRecipeSerializers;

public class BrewReactorCraftingRecipe extends AbstractMachineCraftingRecipe {

    private final Optional<class_1856> ingredient2;
    private final Optional<class_2960> requiredFluid;
    private final Optional<Integer> requiredFluidAmount;

    public BrewReactorCraftingRecipe(class_1856 ingredients, Optional<class_1856> ingredient2, int requiredCount, class_1799 output) {
        super(ingredients, requiredCount, output);
        this.ingredient2 = ingredient2;
        this.requiredFluid = Optional.empty();
        this.requiredFluidAmount = Optional.empty();
    }

    public BrewReactorCraftingRecipe(class_1856 ingredients, Optional<class_1856> ingredient2, int requiredCount, class_1799 output, Optional<class_2960> requiredFluid, Optional<Integer> requiredFluidAmount) {
        super(ingredients, requiredCount, output);
        this.ingredient2 = ingredient2;
        this.requiredFluid = requiredFluid != null ? requiredFluid : Optional.empty();
        this.requiredFluidAmount = requiredFluidAmount != null ? requiredFluidAmount : Optional.empty();
    }

    public BrewReactorCraftingRecipe(class_1856 ingredients, Optional<class_1856> ingredient2, class_1799 output) {
        super(ingredients, output);
        this.ingredient2 = ingredient2;
        this.requiredFluid = Optional.empty();
        this.requiredFluidAmount = Optional.empty();
    }

    @Override
    public class_1865<? extends class_1860<AlchemyCraftingRecipeInput>> method_8119() {
        return AlchemyRecipeType.BREW_REACTOR.serializer;
    }

    @Override
    public class_3956<? extends class_1860<AlchemyCraftingRecipeInput>> method_17716() {
        return AlchemyRecipeType.BREW_REACTOR.type;
    }


    public static final MapCodec<BrewReactorCraftingRecipe> CODEC =
            RecordCodecBuilder.mapCodec(inst -> inst.group(
                    class_1856.field_46095.fieldOf("ingredient")
                            .forGetter(recipe -> recipe.ingredient),

                    class_1856.field_46095.optionalFieldOf("ingredient2")
                            .forGetter(recipe -> recipe.ingredient2),

                    Codec.INT.fieldOf("count")
                            .forGetter(recipe -> recipe.requiredCount),

                    class_1799.field_24671.fieldOf("result")
                            .forGetter(recipe -> recipe.output),

                    class_2960.field_25139.optionalFieldOf("fluid")
                            .forGetter(recipe -> recipe.requiredFluid),

                    Codec.INT.optionalFieldOf("fluid_amount")
                            .forGetter(recipe -> recipe.requiredFluidAmount)

            ).apply(inst, (ing, ing2Opt, count, out, fluidOpt, fluidAmtOpt) -> new BrewReactorCraftingRecipe(ing, ing2Opt, count, out, fluidOpt, fluidAmtOpt)));

    public static final class_9139<class_9129, BrewReactorCraftingRecipe> field_48356 =
            class_9139.method_58025(class_1856.field_48355, AbstractMachineCraftingRecipe::ingredient,
                    class_9135.method_56382(class_1856.field_48355), recipe -> recipe.ingredient2,
                    class_9135.field_49675, AbstractMachineCraftingRecipe::requiredCount,
                    class_1799.field_48349,AbstractMachineCraftingRecipe::output,
                    class_9135.method_56382(class_2960.field_48267), recipe -> recipe.requiredFluid,
                    class_9135.method_56382(class_9135.field_49675), recipe -> recipe.requiredFluidAmount,
                    (ing, ing2, count, out, fluidOpt, fluidAmtOpt) -> new BrewReactorCraftingRecipe(ing, ing2, count, out, fluidOpt, fluidAmtOpt));

    public static final class_1865<BrewReactorCraftingRecipe> SERIALIZER =
            ModRecipeSerializers.of(CODEC, field_48356);

    public MapCodec<BrewReactorCraftingRecipe> codec() {
        return CODEC;
    }

    public class_9139<class_9129, BrewReactorCraftingRecipe> streamCodec() {
        return field_48356;
    }

    @Override
    public boolean matches(AlchemyCraftingRecipeInput input, net.minecraft.class_1937 world) {
        if (world.method_8608()) {
            return false;
        }

        net.minecraft.class_1799 stackA = input.method_59984(0);
        net.minecraft.class_1799 stackB = input.method_59984(1);
        boolean firstMatches = ingredient.method_8093(stackA) && stackA.method_7947() >= requiredCount;
        if (!firstMatches) return false;

        if (this.ingredient2 == null) return true; // safety: but ingredient2 is Optional, keep for legacy

        if (!this.ingredient2.isPresent()) return true;

        return ingredient2.get().method_8093(stackB);
    }

    /**
     * Returns the second ingredient for JEI/GUI consumers. May be null if the recipe does not require a second input.
     */
    public class_1856 ingredient2() {
        return this.ingredient2 != null && this.ingredient2.isPresent() ? this.ingredient2.get() : null;
    }

    public Optional<class_2960> requiredFluid() {
        return this.requiredFluid;
    }

    public Optional<Integer> requiredFluidAmount() {
        return this.requiredFluidAmount;
    }

}
