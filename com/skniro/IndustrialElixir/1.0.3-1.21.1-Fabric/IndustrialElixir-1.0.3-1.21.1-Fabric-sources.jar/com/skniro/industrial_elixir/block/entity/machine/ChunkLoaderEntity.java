package com.skniro.industrial_elixir.block.entity.machine;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.screen.handler.machine.ChunkLoaderScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public class ChunkLoaderEntity extends AbstractMachineEntity {
    // 5x5 grid, 25 chunks, center chunk (index 12) always loaded
    // Bit i represents chunk i in row-major order
    private int selectedChunks = 0;
    // Optional chunks this loader currently has force-loaded.
    private int appliedChunks = 0;
    private boolean chunksApplied = false;

    public ChunkLoaderEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.CHUNK_LOADER_BE, pos, state);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.ChunkLoader);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new ChunkLoaderScreenHandler(syncId, playerInventory, field_11867);
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return null;
    }

    public int getSelectedChunks() {
        return selectedChunks;
    }

    public void toggleChunk(int index) {
        if (index < 0 || index >= 25 || index == 12) return;
        selectedChunks ^= (1 << index);
        method_5431();
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) return;

        // Charge from battery
        charge(ENERGY_ITEM_SLOT);

        // Center chunk (index 12) always counts as loaded
        int loadedCount = Integer.bitCount(selectedChunks) + 1;
        long energyNeeded = loadedCount; // 1 EU per tick per loaded chunk

        if (energyContainer.amount >= energyNeeded) {
            try (Transaction tx = Transaction.openOuter()) {
                energyContainer.getSideStorage(null).extract(energyNeeded, tx);
                tx.commit();
            }

            forceChunksFromMask(world, pos);

            if (!state.method_11654(AbstractMachineblock.LIT)) {
                world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, true), 3);
            }
        } else {
            // Not enough energy — un-force optional chunks
            unforceAllChunks(world, pos);

            if (state.method_11654(AbstractMachineblock.LIT)) {
                world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, false), 3);
            }
        }

        method_31663(world, pos, state);
    }

    private void forceChunksFromMask(class_1937 world, class_2338 pos) {
        if (!(world instanceof class_3218 serverLevel)) return;
        int chunkX = pos.method_10263() >> 4;
        int chunkZ = pos.method_10260() >> 4;

        if (!chunksApplied) {
            for (int i = 0; i < 25; i++) {
                if (i == 12 || (selectedChunks & (1 << i)) != 0) {
                    serverLevel.method_17988(chunkX + (i % 5) - 2, chunkZ + (i / 5) - 2, true);
                }
            }
            appliedChunks = selectedChunks;
            chunksApplied = true;
        } else {
            int changed = appliedChunks ^ selectedChunks;
            if (changed != 0) {
                for (int i = 0; i < 25; i++) {
                    if (i == 12) continue;
                    if ((changed & (1 << i)) != 0) {
                        boolean force = (selectedChunks & (1 << i)) != 0;
                        serverLevel.method_17988(chunkX + (i % 5) - 2, chunkZ + (i / 5) - 2, force);
                    }
                }
                appliedChunks = selectedChunks;
            }
        }

        // The chunk containing the loader is always force-loaded while working.
        serverLevel.method_17988(chunkX, chunkZ, true);
    }

    private void unforceAllChunks(class_1937 world, class_2338 pos) {
        if (!(world instanceof class_3218 serverLevel)) return;
        int chunkX = pos.method_10263() >> 4;
        int chunkZ = pos.method_10260() >> 4;

        // Not working (no energy): release every chunk this loader forced, including its own chunk.
        for (int i = 0; i < 25; i++) {
            if (i == 12 || (appliedChunks & (1 << i)) != 0) {
                serverLevel.method_17988(chunkX + (i % 5) - 2, chunkZ + (i / 5) - 2, false);
            }
        }
        appliedChunks = 0;
        chunksApplied = false;
    }

    @Override
    public void method_11012() {
        if (field_11863 instanceof class_3218 serverLevel) {
            int chunkX = field_11867.method_10263() >> 4;
            int chunkZ = field_11867.method_10260() >> 4;
            for (int i = 0; i < 25; i++) {
                serverLevel.method_17988(chunkX + (i % 5) - 2, chunkZ + (i / 5) - 2, false);
            }
        }
        appliedChunks = 0;
        chunksApplied = false;
        super.method_11012();
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10569("chunkLoader.selectedChunks", selectedChunks);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        selectedChunks = (nbt.method_10545("chunkLoader.selectedChunks") ? nbt.method_10550("chunkLoader.selectedChunks") : 0);
    }
}
