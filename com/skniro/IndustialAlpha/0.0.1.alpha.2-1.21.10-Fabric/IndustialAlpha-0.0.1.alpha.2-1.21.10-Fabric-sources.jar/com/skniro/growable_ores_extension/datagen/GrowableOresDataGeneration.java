package com.skniro.growable_ores_extension.datagen;

import com.skniro.growable_ores_extension.world.AgreeTreeConfiguredFeatures;
import com.skniro.growable_ores_extension.world.AgreeTreePlacedFeatures;
import com.skniro.growable_ores_extension.world.ModConfiguredFeatures;
import com.skniro.growable_ores_extension.world.ModPlacedFeatures;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.class_7877;
import net.minecraft.class_7924;

public class GrowableOresDataGeneration implements DataGeneratorEntrypoint {
    @Override
    public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {
        fabricDataGenerator.createPack().addProvider(GrowableModelProvider::new);
        fabricDataGenerator.createPack().addProvider(GrowableLootTableGenerator::new);
        fabricDataGenerator.createPack().addProvider(GrowableEnglishLanguageProvider::new);
        //fabricDataGenerator.createPack().addProvider(GrowableSimplifiedChineseLanguageProvider::new);
        fabricDataGenerator.createPack().addProvider(GrowableBlockTagGenerator::new);
        fabricDataGenerator.createPack().addProvider(GrowableItemTagGenerator::new);
        fabricDataGenerator.createPack().addProvider(ModWorldGenerator::new);
        fabricDataGenerator.createPack().addProvider(UsefulFoodRecipeGenerator::new);
    }

    @Override
    public void buildRegistry(class_7877 registryBuilder) {
        registryBuilder.method_46777(class_7924.field_41239, ModConfiguredFeatures::bootstrap);
        registryBuilder.method_46777(class_7924.field_41245, ModPlacedFeatures::bootstrap);
        registryBuilder.method_46777(class_7924.field_41239, AgreeTreeConfiguredFeatures::bootstrap);
        registryBuilder.method_46777(class_7924.field_41245, AgreeTreePlacedFeatures::bootstrap);
    }
}
