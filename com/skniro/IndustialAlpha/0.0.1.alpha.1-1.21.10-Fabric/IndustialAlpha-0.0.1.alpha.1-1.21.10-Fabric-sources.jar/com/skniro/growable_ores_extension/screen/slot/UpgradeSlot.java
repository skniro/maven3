package com.skniro.growable_ores_extension.screen.slot;

import com.skniro.growable_ores_extension.item.init.ItemUpgradeModule;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class UpgradeSlot extends class_1735 {

    public UpgradeSlot(class_1263 inventory, int index, int x, int y) {
        super(inventory, index, x, y);
    }

    public boolean method_7680(class_1799 stack) {
        return stack.method_7909() instanceof ItemUpgradeModule;
        //return stack.isIn(ModItemTags.Upgrade);
    }

    public int method_7676(class_1799 stack) {
        return super.method_7676(stack);
    }

}
