package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Map;
import java.util.function.BiConsumer;

import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2750;
import net.minecraft.class_2756;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import net.minecraft.class_8177;
import org.jetbrains.annotations.Nullable;

public class SlidingDoorBlock extends AbstractSlidingDoorBlock {
    public static final MapCodec<SlidingDoorBlock> CODEC = RecordCodecBuilder.mapCodec((instance) -> instance.group(class_8177.field_46534.fieldOf("block_set_type").forGetter(SlidingDoorBlock::getBlockSetType), method_54096()).apply(instance, SlidingDoorBlock::new));

    protected static final class_265 CLOSEB_SOUTH = class_2248.method_9541(0.0D, 0.0D, 7.5D, 16.0D, 16.0D, 8.5D);
    protected static final class_265 CLOSEB_WEST =  class_2248.method_9541(7.5D, 0.0D, 0.0D, 8.5D, 16.0D, 16.0D);
    protected static final class_265 CLOSEB_NORTH = class_2248.method_9541(0.0D, 0.0D, 7.5D, 16.0D, 16.0D, 8.5D);
    protected static final class_265 CLOSEB_EAST =  class_2248.method_9541(7.5D, 0.0D, 0.0D, 8.5D, 16.0D, 16.0D);

    protected static final class_265 OPENBR_SOUTH = class_2248.method_9541(14.0D, 0.0D, 7.5D, 30.0D, 16.0D, 8.5D);
    protected static final class_265 OPENBR_WEST =  class_2248.method_9541(7.5D, 0.0D, 14.0D, 8.5D, 16.0D, 30.0D);
    protected static final class_265 OPENBR_NORTH = class_2248.method_9541(-14.0D, 0.0D, 7.5D, 2.0D, 16.0D, 8.5D);
    protected static final class_265 OPENBR_EAST =  class_2248.method_9541(7.5D, 0.0D, -14.0D, 8.5D, 16.0D, 2.0D);

    protected static final class_265 OPENBL_SOUTH = class_2248.method_9541(-14.0D, 0.0D, 7.5D, 2.0D, 16.0D, 8.5D);
    protected static final class_265 OPENBL_WEST =  class_2248.method_9541(7.5D, 0.0D, -14.0D, 8.5D, 16.0D, 2.0D);
    protected static final class_265 OPENBL_NORTH = class_2248.method_9541(14.0D, 0.0D, 7.5D, 30.0D, 16.0D, 8.5D);
    protected static final class_265 OPENBL_EAST =  class_2248.method_9541(7.5D, 0.0D, 14.0D, 8.5D, 16.0D, 30.0D);

    protected static final class_265 CLOSET_SOUTH = class_2248.method_9541(0.0D, 0.0D, 7.5D, 16.0D, 16.0D, 8.5D);
    protected static final class_265 CLOSET_WEST =  class_2248.method_9541(7.5D, 0.0D, 0.0D, 8.5D, 16.0D, 16.0D);
    protected static final class_265 CLOSET_NORTH = class_2248.method_9541(0.0D, 0.0D, 7.5D, 16.0D, 16.0D, 8.5D);
    protected static final class_265 CLOSET_EAST =  class_2248.method_9541(7.5D, 0.0D, 0.0D, 8.5D, 16.0D, 16.0D);

    protected static final class_265 OPENTR_SOUTH = class_2248.method_9541(14.0D, 0.0D, 7.5D, 30.0D, 16.0D, 8.5D);
    protected static final class_265 OPENTR_WEST =  class_2248.method_9541(7.5D, 0.0D, 14.0D, 8.5D, 16.0D, 30.0D);
    protected static final class_265 OPENTR_NORTH = class_2248.method_9541(-14.0D, 0.0D, 7.5D, 2.0D, 16.0D, 8.5D);
    protected static final class_265 OPENTR_EAST =  class_2248.method_9541(7.5D, 0.0D, -14.0D, 8.5D, 16.0D, 2.0D);

    protected static final class_265 OPENTL_SOUTH = class_2248.method_9541(-14.0D, 0.0D, 7.5D, 2.0D, 16.0D, 8.5D);
    protected static final class_265 OPENTL_WEST = class_2248.method_9541(7.5D, 0.0D, -14.0D, 8.5D, 16.0D, 2.0D);
    protected static final class_265 OPENTL_NORTH = class_2248.method_9541(14.0D, 0.0D, 7.5D, 30.0D, 16.0D, 8.5D);
    protected static final class_265 OPENTL_EAST = class_2248.method_9541(7.5D, 0.0D, 14.0D, 8.5D, 16.0D, 30.0D);

    public MapCodec<? extends SlidingDoorBlock> method_53969() {
        return field_46280;
    }

    public SlidingDoorBlock(class_8177 type, class_4970.class_2251 settings) {
        super( type, settings);
        this.method_9590((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043)).method_11657(OPEN, false)).method_11657(HINGE, class_2750.field_12588)).method_11657(POWERED, false)).method_11657(HALF, class_2756.field_12607));
    }


    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2350 direction = state.method_11654(FACING);
        class_2756 half = state.method_11654(HALF);
        boolean open = !state.method_11654(OPEN);
        boolean right = (state.method_11654(HINGE) == class_2750.field_12586);

        switch (half) {
            case field_12607:
            default:
                switch (direction) {
                    case field_11043:
                    default:
                        return open? CLOSEB_NORTH : (right? OPENBL_NORTH : OPENBR_NORTH);
                    case field_11035:
                        return open? CLOSEB_SOUTH : (right? OPENBL_SOUTH : OPENBR_SOUTH);
                    case field_11039:
                        return open? CLOSEB_WEST : (right? OPENBL_WEST : OPENBR_WEST);
                    case field_11034:
                        return open? CLOSEB_EAST : (right? OPENBL_EAST : OPENBR_EAST);
                }

            case field_12609:
                switch (direction) {
                    case field_11043:
                    default:
                        return open? CLOSET_NORTH : (right? OPENTL_NORTH : OPENTR_NORTH);
                    case field_11035:
                        return open? CLOSET_SOUTH : (right? OPENTL_SOUTH : OPENTR_SOUTH);
                    case field_11039:
                        return open? CLOSET_WEST : (right? OPENTL_WEST : OPENTR_WEST);
                    case field_11034:
                        return open? CLOSET_EAST : (right? OPENTL_EAST : OPENTR_EAST);
                }
        }
    }
}
