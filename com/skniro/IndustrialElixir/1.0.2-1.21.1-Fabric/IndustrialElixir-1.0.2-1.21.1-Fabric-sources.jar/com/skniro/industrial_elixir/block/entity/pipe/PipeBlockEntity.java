package com.skniro.industrial_elixir.block.entity.pipe;

import com.skniro.industrial_elixir.block.init.pipe.PipeBlock;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;

public class PipeBlockEntity extends class_2586 implements PipeExtractDirectionController {

    private final List<PipeItem> items = new ArrayList<>();
    private final EnumSet<class_2350> blocked = EnumSet.noneOf(class_2350.class);
    private @Nullable class_2350 preferredExtractDirection;
    private @Nullable class_2350 currentExtractingFrom;

    public PipeBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public boolean isBlocked(class_2350 dir) {
        return blocked.contains(dir);
    }

    public void setBlocked(class_2350 dir, boolean value) {
        if (value) {
            blocked.add(dir);
        } else {
            blocked.remove(dir);
        }
        method_5431();
    }

    @Override
    public @Nullable class_2350 getPreferredExtractDirection() {
        return preferredExtractDirection;
    }

    @Override
    public boolean setPreferredExtractDirection(@Nullable class_2350 direction) {
        if (preferredExtractDirection == direction) {
            return false;
        }

        preferredExtractDirection = direction;
        method_5431();

        if (field_11863 != null && !field_11863.method_8608()) {
            onExtractDirectionChanged(getDisplayExtractDirection(field_11863, field_11867));
        }

        return true;
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        updateConnections();
    }

    public List<PipeItem> getItems() {
        return new ArrayList<>(items);
    }

    public void neighborUpdate() {
        updateConnections();
        if (field_11863 != null && !field_11863.method_8608()) {
            onExtractDirectionChanged(getDisplayExtractDirection(field_11863, field_11867));
        }
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        preferredExtractDirection = readDirection((nbt.method_10545("pipe.preferred_extract_side") ? nbt.method_10550("pipe.preferred_extract_side") : -1));
        blocked.clear();
        for (class_2350 dir : class_2350.values()) {
            if ((nbt.method_10545("pipe.blocked_" + dir.name()) ? nbt.method_10550("pipe.blocked_" + dir.name()) : 0) == 1) {
                blocked.add(dir);
            }
        }
        super.method_11014(nbt, registries);
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10569("pipe.preferred_extract_side",
                preferredExtractDirection == null ? -1 : preferredExtractDirection.method_10146());
        for (class_2350 dir : class_2350.values()) {
            nbt.method_10569("pipe.blocked_" + dir.name(), blocked.contains(dir) ? 1 : 0);
        }
    }

    protected void updateConnections() {
        if (field_11863 == null || field_11863.method_8608()) {
            return;
        }

        class_2680 state = method_11010();
        class_2680 newState = state;

        for (class_2350 dir : class_2350.values()) {
            boolean connected = isConnectable(dir);
            newState = newState.method_11657(PipeBlock.PROPERTY_MAP.get(dir), connected);
        }

        if (newState != state) {
            field_11863.method_8501(field_11867, newState);
        }
    }

    protected boolean isConnectable(class_2350 dir) {
        if (isBlocked(dir)) {
            return false;
        }
        class_2338 target = field_11867.method_10093(dir);
        class_2680 neighborState = field_11863.method_8320(target);
        class_2248 neighborBlock = neighborState.method_26204();

        if (neighborBlock instanceof PipeBlock) {
            return true;
        }

        Storage<ItemVariant> storage =
                ItemStorage.SIDED.find(field_11863, target, dir.method_10153());

        return storage != null;
    }

    void moveItems(class_1937 world, class_2338 pos, class_2680 state) {
        Iterator<PipeItem> it = items.iterator();

        while (it.hasNext()) {
            PipeItem item = it.next();

            if (isBlocked(item.direction)) {
                continue;
            }

            if (item.variant.isBlank() || item.amount <= 0) {
                it.remove();
                continue;
            }

            item.progress += 0.1;

            if (item.progress >= 1.0) {
                class_2338 target = pos.method_10093(item.direction);

                if (!tryMoveToNext(world, target, item)
                        && !tryInsert(world, target, item)) {

                    item.progress = 1.0;
                    continue;
                }

                it.remove();
            }
        }
        
        if (items.isEmpty()) {
            currentExtractingFrom = null;
        }
    }

    private boolean tryMoveToNext(class_1937 world, class_2338 pos, PipeItem item) {
        class_2586 be = world.method_8321(pos);

        if (be instanceof WoodPipeBlockEntity) {
            // 木头管道不接受其他管道的物品
            return false;
        }
        if (be instanceof PipeBlockEntity pipe) {
            if (isBlocked(item.direction)) {
                return false;
            }
            
            class_2350 fromDir = item.direction.method_10153();
            if (pipe.getCurrentExtractingFrom() == fromDir) {
                return false;
            }
            
            class_2350 newDir = getNextDirection(world, pos, item);

            PipeItem newItem = new PipeItem(item.variant, item.amount, newDir);
            newItem.lastDirection = item.direction;
            // 只有目标管道items容量未超限时才转移，否则不转移
            if (pipe.items.size() < 64) { // 假定最大堆叠数64，可根据实际调整
                pipe.items.add(newItem);
                return true;
            } else {
                // 目标管道已满，转移失败，物品保留在当前管道
                return false;
            }
        }

        return false;
    }

    private class_2350 getNextDirection(class_1937 world, class_2338 pos, class_2350 from) {
        List<class_2350> possible = new ArrayList<>();

        for (class_2350 dir : class_2350.values()) {
            if (dir == from.method_10153()) {
                continue;
            }
            if (isBlocked(dir)) {
                continue;
            }
            class_2680 state = world.method_8320(pos);
            if (state.method_11654(PipeBlock.PROPERTY_MAP.get(dir))) {
                possible.add(dir);
            }
        }

        if (possible.isEmpty()) {
            return from;
        }

        return possible.get(world.method_8409().method_43048(possible.size()));
    }

    private boolean tryInsert(class_1937 world, class_2338 pos, PipeItem item) {
        if (item.variant.isBlank() || item.amount <= 0) {
            return false;
        }

        if (isBlocked(item.direction)) {
            return false;
        }
        Storage<ItemVariant> storage =
                ItemStorage.SIDED.find(world, pos, item.direction.method_10153());

        if (storage == null) {
            return false;
        }

        // 禁止向木头管道的pull面插入物品
        class_2586 be = world.method_8321(pos);
        if (be instanceof WoodPipeBlockEntity) {
            class_2680 state = world.method_8320(pos);
            class_2350 insertDir = item.direction.method_10153();
            class_2746 pullProp = com.skniro.industrial_elixir.block.init.pipe.WoodPipeBlock.PULL_PROPERTY_MAP.get(insertDir);
            if (pullProp != null && state.method_11654(pullProp)) {
                return false;
            }
        }
        try (Transaction tx = Transaction.openOuter()) {
            long inserted = storage.insert(item.variant, item.amount, tx);

            if (inserted > 0) {
                item.amount -= inserted;
                if (item.amount <= 0) {
                    item.variant = ItemVariant.blank();
                }
                tx.commit();
                return true;
            } else {
                // 插入失败，物品保留在当前管道，等待下次tick
                return false;
            }
        }

    }

    private class_2350 getNextDirection(class_1937 world, class_2338 pos, PipeItem item) {
        List<class_2350> possible = new ArrayList<>();

        for (class_2350 dir : class_2350.values()) {
            if (isBlocked(dir)) {
                continue;
            }
            if (dir == item.lastDirection.method_10153()) {
                continue;
            }

            class_2680 state = world.method_8320(pos);
            if (state.method_11654(PipeBlock.PROPERTY_MAP.get(dir))) {
                possible.add(dir);
            }
        }

        if (possible.isEmpty()) {
            return item.lastDirection.method_10153();
        }

        return possible.get(world.method_8409().method_43048(possible.size()));
    }

    void extractItems(class_1937 world, class_2338 pos, class_2680 state) {
        if (!items.isEmpty()) {
            onExtractDirectionChanged(getDisplayExtractDirection(world, pos));
            return;
        }

        class_2350 preferredDir = getActivePreferredExtractDirection(world, pos);
        if (preferredDir != null) {
            onExtractDirectionChanged(preferredDir);
            tryExtractFromSide(world, pos, preferredDir);
            return;
        }

        class_2350 extractedDir = tryExtractFromAuto(world, pos);
        if (extractedDir != null) {
            onExtractDirectionChanged(extractedDir);
            return;
        }

        onExtractDirectionChanged(findFirstConnectedStorageSide(world, pos));
    }

    protected void onExtractDirectionChanged(@Nullable class_2350 direction) {
    }

    private @Nullable class_2350 getDisplayExtractDirection(class_1937 world, class_2338 pos) {
        class_2350 preferredDir = getActivePreferredExtractDirection(world, pos);
        if (preferredDir != null) {
            return preferredDir;
        }
        return findFirstConnectedStorageSide(world, pos);
    }

    private @Nullable class_2350 getActivePreferredExtractDirection(class_1937 world, class_2338 pos) {
        if (preferredExtractDirection == null) {
            return null;
        }

        if (isBlocked(preferredExtractDirection)) {
            return null;
        }

        return findStorage(world, pos, preferredExtractDirection) == null ? null : preferredExtractDirection;
    }

    private @Nullable class_2350 findFirstConnectedStorageSide(class_1937 world, class_2338 pos) {
        for (class_2350 dir : class_2350.values()) {
            if (isBlocked(dir)) {
                continue;
            }
            if (findStorage(world, pos, dir) != null) {
                return dir;
            }
        }
        return null;
    }

    private @Nullable class_2350 tryExtractFromAuto(class_1937 world, class_2338 pos) {
        for (class_2350 dir : class_2350.values()) {
            if (tryExtractFromSide(world, pos, dir)) {
                return dir;
            }
        }
        return null;
    }

    private boolean tryExtractFromSide(class_1937 world, class_2338 pos, class_2350 dir) {
        if (isBlocked(dir)) {
            return false;
        }

        Storage<ItemVariant> storage = findStorage(world, pos, dir);
        if (storage == null) {
            return false;
        }

        try (Transaction tx = Transaction.openOuter()) {
            StorageView<ItemVariant> view = null;

            for (StorageView<ItemVariant> next : storage) {
                if (!next.isResourceBlank()) {
                    view = next;
                    break;
                }
            }

            if (view == null) {
                return false;
            }

            long extracted = storage.extract(view.getResource(), 1, tx);
            if (extracted <= 0) {
                return false;
            }

            currentExtractingFrom = dir;
            class_2350 outDir = dir.method_10153();
            items.add(new PipeItem(view.getResource(), extracted, outDir));
            tx.commit();
            return true;
        }
    }
    
    public @Nullable class_2350 getCurrentExtractingFrom() {
        return currentExtractingFrom;
    }

    private @Nullable Storage<ItemVariant> findStorage(class_1937 world, class_2338 pos, class_2350 dir) {
        class_2338 target = pos.method_10093(dir);
        return ItemStorage.SIDED.find(world, target, dir.method_10153());
    }

    private static @Nullable class_2350 readDirection(int value) {
        if (value < 0 || value >= class_2350.values().length) {
            return null;
        }
        return class_2350.method_10143(value);
    }

    public class_1937 level() {
        return this.field_11863;
    }

    public class_243 position() {
        return this.method_11016().method_46558();
    }

    public float getVisualRotationYInDegrees() {
        return 0;
    }

    public class PipeItem {
        public ItemVariant variant;
        public long amount;

        public class_2350 direction;
        public class_2350 lastDirection;

        public double progress;

        public PipeItem(ItemVariant variant, long amount, class_2350 dir) {
            this.variant = variant;
            this.amount = amount;
            this.direction = dir;
            this.lastDirection = dir;
            this.progress = 0.0;
        }
    }
}
