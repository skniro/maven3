package com.skniro.growable_ores_extension.init;

public class FurnitureStrings {
    public static final String Macerator = "gui.growable_ores_extension.macerator";
}
