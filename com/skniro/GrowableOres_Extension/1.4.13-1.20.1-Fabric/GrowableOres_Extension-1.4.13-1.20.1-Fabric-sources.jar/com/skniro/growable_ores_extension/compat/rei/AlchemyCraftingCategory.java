package com.skniro.growable_ores_extension.compat.rei;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import me.shedaniel.math.Point;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.gui.Renderer;
import me.shedaniel.rei.api.client.gui.widgets.Widget;
import me.shedaniel.rei.api.client.gui.widgets.Widgets;
import me.shedaniel.rei.api.client.registry.display.DisplayCategory;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import java.util.LinkedList;
import java.util.List;

// Done with the help:
// https://github.com/TeamGalacticraft/Galacticraft/tree/main (MIT License)
public class AlchemyCraftingCategory implements DisplayCategory<BasicDisplay> {
    public static final CategoryIdentifier<AlchemyCraftingDisplay> UID = CategoryIdentifier.of(GrowableOresExtension.MOD_ID, "cane_converter");
    public static final class_2960 TEXTURE = class_2960.method_43902(GrowableOresExtension.MOD_ID,
            "textures/gui/container/cane_converter.png");

    @Override
    public CategoryIdentifier<? extends BasicDisplay> getCategoryIdentifier() {
        return UID;
    }

    @Override
    public class_2561 getTitle() {
        return class_2561.method_43471("gui.growableores.cane_converter");
    }


    @Override
    public Renderer getIcon() {
        return EntryStacks.of(GrowableOresBlocks.GrowableOres_Block.method_8389().method_7854());
    }

    @Override
    public List<Widget> setupDisplay(BasicDisplay display, Rectangle bounds) {
        final Point startPoint = new Point(bounds.getCenterX() - 87, bounds.getCenterY() - 35);
        List<Widget> widgets = new LinkedList<>();
        widgets.add(Widgets.createTexturedWidget(TEXTURE, new Rectangle(startPoint.x, startPoint.y, 175, 82)));
        widgets.add(Widgets.createSlot(new Point(startPoint.x + 52, startPoint.y + 34))
                .entries(display.getInputEntries().get(0)));
        widgets.add(Widgets.createSlot(new Point(startPoint.x + 100, startPoint.y + 34))
                .markOutput().entries(display.getOutputEntries().get(0)));
        return widgets;
    }

    @Override
    public int getDisplayHeight() {
        return 90;
    }
}