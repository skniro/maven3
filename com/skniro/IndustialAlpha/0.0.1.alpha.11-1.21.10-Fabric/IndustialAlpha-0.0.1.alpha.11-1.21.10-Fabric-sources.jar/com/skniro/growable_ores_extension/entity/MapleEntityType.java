package com.skniro.growable_ores_extension.entity;

import com.mojang.datafixers.types.Type;
import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import java.util.function.Supplier;
import net.minecraft.class_1208;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_156;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7264;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class MapleEntityType {
    public static final class_1299<class_1690> RUBBER_BOAT = register("rubber_boat", class_1299.class_1300.method_5903(getBoatFactory(() -> {
        return GrowableOresItems.RUBBER_BOAT;
    }), class_1311.field_17715).method_63006().method_17687(1.375F, 0.5625F).method_55687(0.5625F).method_27299(10));

    public static final class_1299<class_7264> RUBBER_CHEST_BOAT = register("rubber_chest_boat", class_1299.class_1300.method_5903(getChestBoatFactory(() -> {
        return GrowableOresItems.RUBBER_CHEST_BOAT;
    }), class_1311.field_17715).method_63006().method_17687(1.375F, 0.5625F).method_55687(0.5625F).method_27299(10));

    private static <T extends class_1297> class_1299<T> register(String name, class_1299.class_1300<T> builder) {
        Type<?> type = class_156.method_29187(class_1208.field_5729, name);
        return (class_1299) class_2378.method_10230(class_7923.field_41177, class_2960.method_60655(GrowableOresExtension.MOD_ID, name), builder.method_5905(keyOf(name)));
    }
    private static class_5321<class_1299<?>> keyOf(String name) {
        return class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(GrowableOresExtension.MOD_ID, name));
    }

    private static class_1299.class_4049<class_1690> getBoatFactory(Supplier<class_1792> itemSupplier) {
        return (type, world) -> {
            return new class_1690(type, world, itemSupplier);
        };
    }

    private static class_1299.class_4049<class_7264> getChestBoatFactory(Supplier<class_1792> itemSupplier) {
        return (type, world) -> {
            return new class_7264(type, world, itemSupplier);
        };
    }

    public static void registerMapleEntityType() {
        GrowableOresExtension.LOGGER.debug("Registering MapleEntityType for " + GrowableOresExtension.MOD_ID);
    }
}