package com.skniro.skniro_furniture.block;

import com.skniro.skniro_furniture.Furniture;
import com.skniro.skniro_furniture.block.init.TVBlock;
import com.skniro.skniro_furniture.block.init.TvStandBlock;
import com.skniro.skniro_furniture.block.init.SofaBlock;
import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

import static net.minecraft.class_2246.method_26107;

public class FurnitureLivingroomBlocks {
    //Sofa Blocks
    public static final class_2248 Sofa_WHITE = registerBlock("white_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10446).method_22488()));
    public static final class_2248 Sofa_ORANGE = registerBlock("orange_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10095).method_22488()));
    public static final class_2248 Sofa_MAGENTA = registerBlock("magenta_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10215).method_22488()));
    public static final class_2248 Sofa_LIGHT_BLUE = registerBlock("light_blue_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10294).method_22488()));
    public static final class_2248 Sofa_YELLOW = registerBlock("yellow_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10490).method_22488()));
    public static final class_2248 Sofa_LIME = registerBlock("lime_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10028).method_22488()));
    public static final class_2248 Sofa_PINK = registerBlock("pink_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10459).method_22488()));
    public static final class_2248 Sofa_GRAY = registerBlock("gray_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10423).method_22488()));
    public static final class_2248 Sofa_LIGHT_GRAY = registerBlock("light_gray_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10222).method_22488()));
    public static final class_2248 Sofa_CYAN = registerBlock("cyan_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10619).method_22488()));
    public static final class_2248 Sofa_PURPLE = registerBlock("purple_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10259).method_22488()));
    public static final class_2248 Sofa_BLUE = registerBlock("blue_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10514).method_22488()));
    public static final class_2248 Sofa_BROWN = registerBlock("brown_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10113).method_22488()));
    public static final class_2248 Sofa_GREEN = registerBlock("green_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10170).method_22488()));
    public static final class_2248 Sofa_RED = registerBlock("red_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10314).method_22488()));
    public static final class_2248 Sofa_BLACK = registerBlock("black_sofa", SofaBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10146).method_22488()));

    public static final class_2248 OAK_PLANKS_TV_STAND = registerBlock("oak_planks_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_10161).method_22488());
    public static final class_2248 OAK_WOOD_TV_STAND = registerBlock("oak_wood_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_10161).method_22488());
    public static final class_2248 PALE_OAK_PLANKS_TV_STAND = registerBlock("pale_oak_planks_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_54735).method_22488());
    public static final class_2248 PALE_OAK_WOOD_TV_STAND = registerBlock("pale_oak_wood_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_54735).method_22488());
    public static final class_2248 SPRUCE_PLANKS_TV_STAND = registerBlock("spruce_planks_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_9975).method_22488());
    public static final class_2248 SPRUCE_WOOD_TV_STAND = registerBlock("spruce_wood_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_9975).method_22488());
    public static final class_2248 BIRCH_PLANKS_TV_STAND = registerBlock("birch_planks_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_10148).method_22488());
    public static final class_2248 BIRCH_WOOD_TV_STAND = registerBlock("birch_wood_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_10148).method_22488());
    public static final class_2248 JUNGLE_PLANKS_TV_STAND = registerBlock("jungle_planks_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_10334).method_22488());
    public static final class_2248 JUNGLE_WOOD_TV_STAND = registerBlock("jungle_wood_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_10334).method_22488());
    public static final class_2248 ACACIA_PLANKS_TV_STAND = registerBlock("acacia_planks_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_10218).method_22488());
    public static final class_2248 ACACIA_WOOD_TV_STAND = registerBlock("acacia_wood_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_10218).method_22488());
    public static final class_2248 DARK_OAK_PLANKS_TV_STAND = registerBlock("dark_oak_planks_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_10075).method_22488());
    public static final class_2248 DARK_OAK_WOOD_TV_STAND = registerBlock("dark_oak_wood_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_10075).method_22488());
    public static final class_2248 MANGROVE_PLANKS_TV_STAND = registerBlock("mangrove_planks_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_37577).method_22488());
    public static final class_2248 MANGROVE_WOOD_TV_STAND = registerBlock("mangrove_wood_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_37577).method_22488());
    public static final class_2248 CHERRY_PLANKS_TV_STAND = registerBlock("cherry_planks_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_42751).method_22488());
    public static final class_2248 CHERRY_WOOD_TV_STAND = registerBlock("cherry_wood_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_42751).method_22488());
    public static final class_2248 CRIMSON_PLANKS_TV_STAND = registerBlock("crimson_planks_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_22126).method_22488());
    public static final class_2248 CRIMSON_HYPHAE_TV_STAND = registerBlock("crimson_wood_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_22126).method_22488());
    public static final class_2248 WARPED_PLANKS_TV_STAND = registerBlock("warped_planks_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_22127).method_22488());
    public static final class_2248 WARPED_HYPHAE_TV_STAND = registerBlock("warped_wood_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_22127).method_22488());
    public static final class_2248 BAMBOO_PLANKS_TV_STAND = registerBlock("bamboo_planks_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_40294).method_22488());
    public static final class_2248 BAMBOO_BLOCK_TV_STAND = registerBlock("bamboo_wood_tv_stand", TvStandBlock::new, class_4970.class_2251.method_9630(class_2246.field_40294).method_22488());

    public static final class_2248 OAK_PLANKS_TV = registerBlock("oak_planks_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_10161).method_9631(method_26107(15)).method_22488());
    public static final class_2248 OAK_WOOD_TV = registerBlock("oak_wood_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_10161).method_9631(method_26107(15)).method_22488());
    public static final class_2248 PALE_OAK_PLANKS_TV = registerBlock("pale_oak_planks_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_54735).method_9631(method_26107(15)).method_22488());
    public static final class_2248 PALE_OAK_WOOD_TV = registerBlock("pale_oak_wood_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_54735).method_9631(method_26107(15)).method_22488());
    public static final class_2248 SPRUCE_PLANKS_TV = registerBlock("spruce_planks_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_9975).method_9631(method_26107(15)).method_22488());
    public static final class_2248 SPRUCE_WOOD_TV = registerBlock("spruce_wood_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_9975).method_9631(method_26107(15)).method_22488());
    public static final class_2248 BIRCH_PLANKS_TV = registerBlock("birch_planks_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_10148).method_9631(method_26107(15)).method_22488());
    public static final class_2248 BIRCH_WOOD_TV = registerBlock("birch_wood_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_10148).method_9631(method_26107(15)).method_22488());
    public static final class_2248 JUNGLE_PLANKS_TV = registerBlock("jungle_planks_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_10334).method_9631(method_26107(15)).method_22488());
    public static final class_2248 JUNGLE_WOOD_TV = registerBlock("jungle_wood_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_10334).method_9631(method_26107(15)).method_22488());
    public static final class_2248 ACACIA_PLANKS_TV = registerBlock("acacia_planks_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_10218).method_9631(method_26107(15)).method_22488());
    public static final class_2248 ACACIA_WOOD_TV = registerBlock("acacia_wood_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_10218).method_9631(method_26107(15)).method_22488());
    public static final class_2248 DARK_OAK_PLANKS_TV = registerBlock("dark_oak_planks_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_10075).method_9631(method_26107(15)).method_22488());
    public static final class_2248 DARK_OAK_WOOD_TV = registerBlock("dark_oak_wood_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_10075).method_9631(method_26107(15)).method_22488());
    public static final class_2248 MANGROVE_PLANKS_TV = registerBlock("mangrove_planks_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_37577).method_9631(method_26107(15)).method_22488());
    public static final class_2248 MANGROVE_WOOD_TV = registerBlock("mangrove_wood_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_37577).method_9631(method_26107(15)).method_22488());
    public static final class_2248 CHERRY_PLANKS_TV = registerBlock("cherry_planks_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_42751).method_9631(method_26107(15)).method_22488());
    public static final class_2248 CHERRY_WOOD_TV = registerBlock("cherry_wood_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_42751).method_9631(method_26107(15)).method_22488());
    public static final class_2248 CRIMSON_PLANKS_TV = registerBlock("crimson_planks_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_22126).method_9631(method_26107(15)).method_22488());
    public static final class_2248 CRIMSON_HYPHAE_TV = registerBlock("crimson_wood_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_22126).method_9631(method_26107(15)).method_22488());
    public static final class_2248 WARPED_PLANKS_TV = registerBlock("warped_planks_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_22127).method_9631(method_26107(15)).method_22488());
    public static final class_2248 WARPED_HYPHAE_TV = registerBlock("warped_wood_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_22127).method_9631(method_26107(15)).method_22488());
    public static final class_2248 BAMBOO_PLANKS_TV = registerBlock("bamboo_planks_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_40294).method_9631(method_26107(15)).method_22488());
    public static final class_2248 BAMBOO_BLOCK_TV = registerBlock("bamboo_wood_tv", TVBlock::new, class_4970.class_2251.method_9630(class_2246.field_40294).method_9631(method_26107(15)).method_22488());

    public static final class_2248 TV_WHITE = registerBlock("white_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10446).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_ORANGE = registerBlock("orange_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10095).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_MAGENTA = registerBlock("magenta_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10215).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_LIGHT_BLUE = registerBlock("light_blue_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10294).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_YELLOW = registerBlock("yellow_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10490).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_LIME = registerBlock("lime_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10028).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_PINK = registerBlock("pink_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10459).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_GRAY = registerBlock("gray_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10423).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_LIGHT_GRAY = registerBlock("light_gray_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10222).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_CYAN = registerBlock("cyan_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10619).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_PURPLE = registerBlock("purple_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10259).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_BLUE = registerBlock("blue_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10514).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_BROWN = registerBlock("brown_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10113).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_GREEN = registerBlock("green_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10170).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_RED = registerBlock("red_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10314).method_9631(method_26107(15)).method_22488()));
    public static final class_2248 TV_BLACK = registerBlock("black_tv", TVBlock::new, (class_4970.class_2251.method_9630(class_2246.field_10146).method_9631(method_26107(15)).method_22488()));


    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(keyOf(name)));
        registerBlockItem(name, block);
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }


    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Furniture.MOD_ID, name)),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Furniture.MOD_ID, name)))));
    }

    private static class_2248 registerBlockWithoutItem(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(keyOf(name)));
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }

    private static class_5321<class_2248> keyOf(String name) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(Furniture.MOD_ID, name));
    }

    public static void registerLivingroomBlocks() {
        Furniture.LOGGER.debug("Registering Livingroom Blocks for " + Furniture.MOD_ID);
    }
}
