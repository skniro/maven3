package com.skniro.industrial_elixir.block.init.container.fluid;

import com.mojang.serialization.MapCodec;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.entity.container.fluid.FluidTankBlockEntity;
import com.skniro.industrial_elixir.block.entity.machine.AbstractMachineEntity;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_9062;
import net.minecraft.world.*;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

public class FluidTankBlock extends class_2237 {
    public static final MapCodec<FluidTankBlock> CODEC = method_54094(FluidTankBlock::new);
    public static final class_2754<class_2350> FACING = class_2383.field_11177;

    public FluidTankBlock(class_2251 settings) {
        super(settings);
    }

    public class_2680 method_9605(class_1750 ctx) {
        return (class_2680)this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return (class_2680)state.method_11657(FACING, rotation.method_10503((class_2350)state.method_11654(FACING)));
    }

    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345((class_2350)state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new FluidTankBlockEntity(pos, state);
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            class_2586 blockEntity = world.method_8321(pos);
            if (blockEntity instanceof AbstractMachineEntity) {
                class_1264.method_5451(world, pos, (class_1263) blockEntity);
                world.method_8455(pos,this);
            }
        }
        super.method_9536(state, world, pos, newState, moved);
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_2586 blockEntity = world.method_8321(pos);
        if (!(blockEntity instanceof FluidTankBlockEntity fluidTank)) {
            return class_9062.field_47731;
        }

        if (isFluidBucket(stack)) {
            if (world.method_8608()) {
                return class_9062.field_47728;
            }

            class_1269 bucketResult = fluidTank.interactBucket(player, hand);
            if (bucketResult != class_1269.field_5811) {
                return bucketResult.method_23665() ? class_9062.method_55644(world.method_8608()) : class_9062.field_47733;
            }
        }

        if (!world.method_8608()) {
            player.method_17355(fluidTank);
        }

        return class_9062.field_47728;
    }

    private static boolean isFluidBucket(class_1799 stack) {
        return stack.method_31574(class_1802.field_8705) || stack.method_31574(class_1802.field_8187) || stack.method_31574(class_1802.field_8550);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, AlchemyBlockEntityType.FLUID_TANK_BLOCK_ENTITY, (level, pos, blockState, blockEntity) -> blockEntity.tick(level, pos, blockState));
    }
}
