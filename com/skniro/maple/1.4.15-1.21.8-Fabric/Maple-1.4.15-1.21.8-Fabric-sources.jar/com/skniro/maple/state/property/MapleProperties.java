package com.skniro.maple.state.property;

import net.minecraft.class_2746;
import net.minecraft.class_2758;

public class MapleProperties {
    public static final class_2758 FLOWER_AMOUNT;
    public static final class_2746 SLOT_0_OCCUPIED;
    public static final class_2746 SLOT_1_OCCUPIED;
    public static final class_2746 SLOT_2_OCCUPIED;
    public static final class_2746 SLOT_3_OCCUPIED;
    public static final class_2746 SLOT_4_OCCUPIED;
    public static final class_2746 SLOT_5_OCCUPIED;


    static {
        FLOWER_AMOUNT = class_2758.method_11867("flower_amount", 1, 4);
        SLOT_0_OCCUPIED = class_2746.method_11825("slot_0_occupied");
        SLOT_1_OCCUPIED = class_2746.method_11825("slot_1_occupied");
        SLOT_2_OCCUPIED = class_2746.method_11825("slot_2_occupied");
        SLOT_3_OCCUPIED = class_2746.method_11825("slot_3_occupied");
        SLOT_4_OCCUPIED = class_2746.method_11825("slot_4_occupied");
        SLOT_5_OCCUPIED = class_2746.method_11825("slot_5_occupied");
    }
}
