package com.skniro.maple.block.init;

import com.skniro.maple.item.MapleItems;
import net.minecraft.class_1922;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;

public class RiceBlock extends class_2302 {
    private static final class_265[] AGE_TO_SHAPE = new class_265[]{class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D), class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 3.0D, 16.0D), class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 4.0D, 16.0D), class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 5.0D, 16.0D), class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 6.0D, 16.0D), class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 7.0D, 16.0D), class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D), class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 9.0D, 16.0D)};

    public RiceBlock(class_2251 settings) {
        super(settings);
    }

    protected class_1935 method_9832() {
        return MapleItems.Rice;
    }

    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return AGE_TO_SHAPE[(Integer)state.method_11654(this.method_9824())];
    }
}
