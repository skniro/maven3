package com.skniro.skniro_furniture.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.registry.*;
import java.util.concurrent.CompletableFuture;


public class MapleItemTagGeneration extends FabricTagProvider<class_1792> {
    public MapleItemTagGeneration(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(dataGenerator, class_7924.field_41197, completableFuture);
    }

    public static class ModItemTags {
        public static final class_6862<class_1792> C_SAPLING = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "saplings"));
        public static final class_6862<class_1792> C_MAPLE_LOGS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "maple_logs"));
        public static final class_6862<class_1792> C_CHERRY_LOGS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "cherry_logs"));
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {

    }


}
