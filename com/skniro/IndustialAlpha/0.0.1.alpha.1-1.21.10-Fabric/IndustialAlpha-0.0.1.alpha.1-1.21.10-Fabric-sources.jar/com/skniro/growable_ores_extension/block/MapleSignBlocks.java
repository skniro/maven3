package com.skniro.growable_ores_extension.block;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.block.entity.MapleSignTypes;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2508;
import net.minecraft.class_2551;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7713;
import net.minecraft.class_7715;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.function.Function;

public class MapleSignBlocks {

    public static final class_2248 Rubber_SIGN = registerBlock("rubber_sign",(settings)-> new class_2508(MapleSignTypes.Rubber, settings),class_4970.class_2251.method_9637().method_31710(NetherOresBlocks.Rubber_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013());
    public static final class_2248 Rubber_WALL_SIGN = registerBlock("rubber_wall_sign",(settings)-> new class_2551(MapleSignTypes.Rubber, settings),class_4970.class_2251.method_9637().method_31710(NetherOresBlocks.Rubber_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_63502((Rubber_SIGN.method_26162())));
    public static final class_2248 Rubber_HANGING_SIGN = registerBlock("rubber_hanging_sign",(settings)-> new class_7713(MapleSignTypes.Rubber, settings),class_4970.class_2251.method_9637().method_31710(NetherOresBlocks.Rubber_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013());
    public static final class_2248 Rubber_WALL_HANGING_SIGN = registerBlock("rubber_wall_hanging_sign",(settings)->  new class_7715(MapleSignTypes.Rubber, settings),class_4970.class_2251.method_9637().method_31710(NetherOresBlocks.Rubber_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_63502((Rubber_HANGING_SIGN.method_26162())));


    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(keyOf(name)));
        registerBlockItem(name, block);
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }


    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)),
                new class_1747(block, new class_1792.class_1793().method_7889(16).method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)))));
    }

    private static class_2248 registerBlockWithoutItem(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(keyOf(name)));
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }

    private static class_5321<class_2248> keyOf(String name) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GrowableOresExtension.MOD_ID, name));
    }

    public static void registerMapleSignBlocks() {
        GrowableOresExtension.LOGGER.debug("Registering MapleSignBlocks for " + GrowableOresExtension.MOD_ID);
    }
}
