package com.skniro.growable_ores_extension.item.init;

public enum UpgradableProperty {
    Processing,
    Augmentable,
    RedstoneSensitive,
    Transformer,
    EnergyStorage,
    ItemConsuming,
    ItemProducing,
    FluidConsuming,
    FluidProducing,
    RemotelyAccessible;
}