package torcherino.block;

import torcherino.TorcherinoImpl;
import torcherino.api.TierSupplier;
import torcherino.block.entity.TorcherinoBlockEntity;
import torcherino.config.Config;

import java.util.function.Consumer;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import net.minecraft.class_9904;

public final class TorcherinoLogic {
    public static class_1269 useWithoutItem(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (world.method_8608() || hand == class_1268.field_5810) {
            return class_1269.field_5812;
        }
        if (world.method_8321(pos) instanceof TorcherinoBlockEntity blockEntity) {
            blockEntity.openTorcherinoScreen((class_3222) player);
        }
        return class_1269.field_5812;
    }

    public static void neighborUpdate(class_2680 state, class_1937 world, class_2338 pos, class_2248 neighborBlock, class_9904 orientation, boolean isMoving,
                                      Consumer<TorcherinoBlockEntity> func) {
        if (world.method_8608()) {
            return;
        }
        if (world.method_8321(pos) instanceof TorcherinoBlockEntity blockEntity) {
            func.accept(blockEntity);
        }
    }

    public static void onPlaced(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 stack, class_2248 block) {
        if (world.method_8608()) {
            return;
        }
        if (world.method_8321(pos) instanceof TorcherinoBlockEntity blockEntity) {
            if (stack.method_57826(class_9334.field_49631)) {
                blockEntity.setCustomName(stack.method_7964());
            }
            if (!Config.INSTANCE.online_mode.equals("")) {
                blockEntity.setOwner(placer == null ? "" : placer.method_5845());
            }
        }
        if (Config.INSTANCE.log_placement) {
            String prefix = placer == null ? "Something" : placer.method_5476().getString() + "(" + placer.method_5845() + ")";
            TorcherinoImpl.LOGGER.info("[Torcherino] {} placed a {} at {}, {}, {}.", prefix, class_7923.field_41175.method_10221(block), pos.method_10263(), pos.method_10264(), pos.method_10260());
        }
    }

    public static <T extends class_2586> class_5558<T> getTicker(class_1937 level, class_2680 state, class_2591<T> type) {
        if (state.method_26204() instanceof TierSupplier) {
            try {
                return (level1, pos, state1, entity) -> TorcherinoBlockEntity.tick(level1, pos, state1, (TorcherinoBlockEntity) entity);
            } catch (ClassCastException e){
                return null;
            }
        }
        return null;
    }
}
