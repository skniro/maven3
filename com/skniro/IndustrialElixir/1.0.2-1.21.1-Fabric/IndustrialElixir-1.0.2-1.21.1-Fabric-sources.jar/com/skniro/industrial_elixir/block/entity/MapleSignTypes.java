package com.skniro.industrial_elixir.block.entity;


import com.skniro.industrial_elixir.block.init.MapleBlockSetType;
import com.skniro.industrial_elixir.mixin.SignTypeAccessor;
import net.minecraft.class_4719;

public class MapleSignTypes {
    public static final class_4719 Rubber =
            SignTypeAccessor.registerNew(SignTypeAccessor.newSignType("maple_rubber", MapleBlockSetType.Rubber));
}