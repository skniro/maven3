package com.skniro.maple.world.Tree;

import com.skniro.maple.world.feature.MapleConfiguredFeatures;
import java.util.Optional;
import net.minecraft.class_8813;

public class MapleSaplingGenerator {
    public static final class_8813 MapleSapling =
            new class_8813("mapletreesapling", 0f, Optional.empty(),
                    Optional.empty(),
                    Optional.of(MapleConfiguredFeatures.Maple_TREE),
                    Optional.empty(),
                    Optional.empty(),
                    Optional.empty());
}