package com.skniro.maple.client.renderer;

import com.skniro.maple.entity.furniture.ChairEntity;
import net.minecraft.class_2960;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class ChairRenderer extends class_897<ChairEntity> {

    public ChairRenderer(class_5617.class_5618 ctx) {
        super(ctx);
    }

    @Override
    public class_2960 getTexture(ChairEntity entity) {
        return null;
    }
    @Override
    public boolean shouldRender(ChairEntity livingEntity, class_4604 camera, double camX, double camY, double camZ) {
        return true;
    }


}