package com.skniro.maple.entity.projectile.thrown;

import com.google.common.collect.Sets;
import java.util.Set;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1545;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3966;

public class MapleConfusionSnowballEntity extends MapleSnowballEntity {
    private final Set<class_1293> effects = Sets.newHashSet();
    public MapleConfusionSnowballEntity(class_1937 world, class_1309 owner, class_1799 stack) {
        super(world, owner, stack);
    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {
        super.method_7454(entityHitResult);
        class_1297 entity = entityHitResult.method_17782();
        int i = entity instanceof class_1545 ? 4 : 0;
        entity.method_64419(this.method_48923().method_48811(this, this.method_24921()), i);
        if(entity instanceof class_1309) {
            class_1309 playerEntity = (class_1309) entityHitResult.method_17782();;
            playerEntity.method_6092(new class_1293(class_1294.field_5916, 150, 1));
        }
    }
}
