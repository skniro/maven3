package com.skniro.growableoresir.client;


import com.skniro.growableoresir.block.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.class_1921;

@Environment(EnvType.CLIENT)
public class GrowableOresClienttwo {
    public static void register() {
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableICOresBlocks.IER_Bronze_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableICOresBlocks.IER_silver_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableICOresBlocks.IER_Tin_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableICOresBlocks.IER_SACRED_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableICOresBlocks.IER_steel_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableICOresBlocks.IER_LEAD_Cane, class_1921.method_23581());
    }
}
