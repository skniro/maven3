package com.skniro.maple.fluid;

import com.skniro.maple.Maple;
import com.skniro.maple.fluid.init.MapleHotSpringFluidBlock;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class MapleFluidBlockOrItem {
    public static class_2248 Hot_Spring_BLOCK;
    public static class_1792 Hot_Spring_BUCKET;

    public static void registerFluidBlocks() {
        Hot_Spring_BLOCK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(Maple.MOD_ID, "hot_spring_block"),
                new MapleHotSpringFluidBlock(MapleFluids.STILL_Hot_Spring, FabricBlockSettings.copyOf(class_2246.field_10382).luminance(7)) {
        });
    }
    public static void registerFluidItems() {
        Hot_Spring_BUCKET = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(Maple.MOD_ID, "hot_spring_bucket"),
                new class_1755(MapleFluids.STILL_Hot_Spring, new class_1792.class_1793().method_7896(class_1802.field_8550).method_7889(1)));
    }
}
