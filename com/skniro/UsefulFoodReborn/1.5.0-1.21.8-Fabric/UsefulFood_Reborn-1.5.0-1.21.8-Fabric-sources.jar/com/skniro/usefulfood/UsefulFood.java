package com.skniro.usefulfood;

import com.skniro.usefulfood.block.init.jam.UsefulfoodJamConversions;
import com.skniro.usefulfood.item.UsefulFoodItems;
import com.skniro.usefulfood.util.ModLootTableModifiers;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class UsefulFood implements ModInitializer {
    public static final String MOD_ID = "usefulfood";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final class_5321<class_1761> UsefulFood_Group = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(MOD_ID, "test_group"));

    @Override
    public void onInitialize() {
        class_2378.method_39197(class_7923.field_44687, UsefulFood_Group, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(UsefulFoodItems.Cheese))
                .method_47321(class_2561.method_43471("itemGroup.usefulfood.test_group"))
                .method_47324()); // build() no longer registers by itself
        ModContent.registerItem();
        ModContent.registerBlock();
        ModContent.CreativeTab();
        ModLootTableModifiers.modifyLootTables();
        UsefulfoodJamConversions.registerJamConversions();
    }
}
