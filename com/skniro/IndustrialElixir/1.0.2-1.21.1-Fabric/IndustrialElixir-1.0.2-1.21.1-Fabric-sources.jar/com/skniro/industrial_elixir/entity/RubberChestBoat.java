package com.skniro.industrial_elixir.entity;

import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_7264;

/**
 * 26.1 lets a boat's drop item be supplied through the constructor; in 1.21.1 the drop is decided by
 * {@link class_1690#method_7557()}, so the rubber chest boat carries its own item instead.
 */
public class RubberChestBoat extends class_7264 {
    private final Supplier<class_1792> dropItem;

    public RubberChestBoat(class_1299<? extends class_1690> type, class_1937 level, Supplier<class_1792> dropItem) {
        super(type, level);
        this.dropItem = dropItem;
    }

    @Override
    public class_1792 method_7557() {
        return this.dropItem.get();
    }
}
