package com.skniro.maple.item.init.armor;

import com.skniro.maple.Maple;
import com.skniro.maple.item.MapleArmorItems;
import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class MapleArmorMaterials {
    public static final class_6880<class_1741> Cherry = register("cherry",
            (EnumMap) class_156.method_654(new EnumMap(class_1738.class_8051.class), (map) -> {
                map.put(class_1738.class_8051.field_41937, 3);
                map.put(class_1738.class_8051.field_41936, 6);
                map.put(class_1738.class_8051.field_41935, 8);
                map.put(class_1738.class_8051.field_41934, 3);
                map.put(class_1738.class_8051.field_48838, 11);
            }), 25, class_3417.field_21866, 3.0F, 0.1F, () -> {
                return class_1856.method_8091(new class_1935[]{MapleArmorItems.Cherry_INGOT});
            });
    public static final int Cherry_DURABILITY_MULTIPLIER = 37;

    private static class_6880<class_1741> register(String id, EnumMap<class_1738.class_8051, Integer> defense, int enchantability, class_6880<class_3414> equipSound, float toughness, float knockbackResistance, Supplier<class_1856> repairIngredient) {
        List<class_1741.class_9196> list = List.of(new class_1741.class_9196(class_2960.method_60655(Maple.MOD_ID, id)));
        return register(id, defense, enchantability, equipSound, toughness, knockbackResistance, repairIngredient, list);
    }

    private static class_6880<class_1741> register(String id, EnumMap<class_1738.class_8051, Integer> defense, int enchantability, class_6880<class_3414> equipSound, float toughness, float knockbackResistance, Supplier<class_1856> repairIngredient, List<class_1741.class_9196> layers) {
        EnumMap<class_1738.class_8051, Integer> enumMap = new EnumMap(class_1738.class_8051.class);
        class_1738.class_8051[] var9 = class_1738.class_8051.values();
        int var10 = var9.length;

        for (class_1738.class_8051 type : var9) {
            enumMap.put(type, (Integer) defense.get(type));
        }

        return class_2378.method_47985(class_7923.field_48976, class_2960.method_60655(Maple.MOD_ID, id), new class_1741(enumMap, enchantability, equipSound, repairIngredient, layers, toughness, knockbackResistance));
    }
}
