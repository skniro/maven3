package com.skniro.skniro_furniture.block.entity;

import com.mojang.logging.LogUtils;
import net.minecraft.class_1767;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import net.minecraft.class_9307;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class FurnitureBedBlockEntity extends class_2586 {
    private static final Logger LOGGER = LogUtils.getLogger();
    private class_9307 patterns = class_9307.field_49404;
    @Nullable
    private class_2561 customName;
    private final class_1767 baseColor;

    public FurnitureBedBlockEntity(class_2338 pos, class_2680 state) {
        this(pos, state, class_1767.field_7952);
    }


    public FurnitureBedBlockEntity(class_2338 pos, class_2680 state, class_1767 baseColor) {
        super(FurnitureBlockEntityType.Bed_BLOCK_ENTITY, pos, state);
        this.baseColor = baseColor;
    }

    public class_9307 getPatterns() {
        return patterns;
    }

    public void setPatterns(class_9307 patterns) {
        this.patterns = patterns;
        method_5431();
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        if (!this.patterns.equals(class_9307.field_49404)) {
            nbt.method_10566("patterns", (class_2520)class_9307.field_49405.encodeStart(registries.method_57093(class_2509.field_11560), this.patterns).getOrThrow());
        }

        if (this.customName != null) {
            nbt.method_10582("CustomName", class_2561.class_2562.method_10867(this.customName, registries));
        }
    }

    public class_2622 method_38235() {
        return class_2622.method_38585(this);
    }


    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        if (nbt.method_10573("CustomName", 8)) {
            this.customName = method_59894(nbt.method_10558("CustomName"), registries);
        }

        if (nbt.method_10545("patterns")) {
            class_9307.field_49405.parse(registries.method_57093(class_2509.field_11560), nbt.method_10580("patterns")).resultOrPartial((patterns) -> LOGGER.error("Failed to parse banner patterns: '{}'", patterns)).ifPresent((patterns) -> this.patterns = patterns);
        }
    }
}

