package com.skniro.growable_ores_extension.datagen.recipe.material;

import com.skniro.growable_ores_extension.api.data.family.GrowableOresBlockFamilies;
import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.MapleSignBlocks;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1935;
import net.minecraft.class_7225;
import net.minecraft.class_7701;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class TreeBlockRecipeGenerator extends FabricRecipeProvider {
    public TreeBlockRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {
                this.offerPlanksRecipe(GeneralBlocks.Rubber_PLANKS, GeneralBlocks.Rubber_LOG, 4);
                this.method_24476(GeneralBlocks.Rubber_WOOD, GeneralBlocks.Rubber_LOG);
                this.method_24476(GeneralBlocks.STRIPPED_Rubber_WOOD, GeneralBlocks.STRIPPED_Rubber_LOG);
                this.method_24478(GrowableOresItems.RUBBER_BOAT, GeneralBlocks.Rubber_PLANKS);
                this.method_73067(GeneralBlocks.Rubber_SHELF, GeneralBlocks.STRIPPED_Rubber_LOG);
                this.method_42754(GrowableOresItems.RUBBER_CHEST_BOAT, GrowableOresItems.RUBBER_BOAT);
                this.method_46208(MapleSignBlocks.Rubber_HANGING_SIGN, GeneralBlocks.STRIPPED_Rubber_LOG);
                method_33535(GrowableOresBlockFamilies.RUBBER_PLANKS, class_7701.field_40182);

            }

            public void offerPlanksRecipe(class_1935 output, class_1935 logTag, int count) {
                this.method_62750(class_7800.field_40634, output, count).method_10454(logTag).method_10452("planks").method_10442("has_logs", this.method_10426(logTag)).method_10431(this.field_53721);
            }
        };
    }


    @Override
    public String method_10321() {
        return "TreeBlock";
    }
}