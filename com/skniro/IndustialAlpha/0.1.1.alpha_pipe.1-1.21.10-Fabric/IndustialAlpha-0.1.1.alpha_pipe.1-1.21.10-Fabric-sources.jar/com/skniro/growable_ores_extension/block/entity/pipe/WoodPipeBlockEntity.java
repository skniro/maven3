package com.skniro.growable_ores_extension.block.entity.pipe;

import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class WoodPipeBlockEntity extends PipeBlockEntity {

    public WoodPipeBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.PIPE_Wooden_BLOCK_ENTITY,pos, state);
    }


    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) return;
        super.tick(world, pos, state);
        moveItems(world, pos, state);
        extractItems(world, pos, state);
    }
}
