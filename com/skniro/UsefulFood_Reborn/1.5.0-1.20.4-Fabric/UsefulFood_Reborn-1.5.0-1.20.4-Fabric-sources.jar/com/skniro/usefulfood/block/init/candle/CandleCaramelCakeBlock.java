package com.skniro.usefulfood.block.init.candle;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Maps;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.usefulfood.block.UsefulFoodCakeBlocks;
import com.skniro.usefulfood.block.init.SpecialCakeBlockState;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3481;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5540;
import net.minecraft.class_5545;
import net.minecraft.class_7923;
import java.util.Map;

public class CandleCaramelCakeBlock extends class_5540 {
    private static final Map<class_2248, CandleCaramelCakeBlock> CAKES_TRANSFORM = Maps.newHashMap();
    public static final class_2746 LIT;
    protected static final float field_31052 = 1.0F;
    protected static final class_265 CAKE_SHAPE;
    protected static final class_265 CANDLE_SHAPE;
    protected static final class_265 SHAPE;
    private static final Map<class_2248, class_5545> CANDLES_TO_CANDLE_CAKES;
    private static final Iterable<class_243> PARTICLE_OFFSETS;
    private final class_2248 candle;

    public static final MapCodec<CandleCaramelCakeBlock> CODEC = RecordCodecBuilder.mapCodec((instance) -> {
        return instance.group(class_7923.field_41175.method_39673().fieldOf("candle").forGetter((block) -> {
            return block.candle;
        }), method_54096()).apply(instance, CandleCaramelCakeBlock::new);
    });

    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    public CandleCaramelCakeBlock(class_2248 candle, class_4970.class_2251 settings) {
        super(settings);
        this.method_9590((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(field_27083, false));
        CAKES_TRANSFORM.put(candle, this);
        this.candle = candle;
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_1799 itemStack = player.method_5998(hand);
        if(itemStack.method_31574(class_1802.field_8884) || itemStack.method_31574(class_1802.field_8814)) return class_1269.field_5811;
        if (!(CandleCaramelCakeBlock.isHittingCandle(hit) && player.method_5998(hand).method_7960() && state.method_11654(field_27083))) {
            class_1269 result = SpecialCakeBlockState.tryEat(world, pos, UsefulFoodCakeBlocks.CaramelCake.method_9564(), player);
            if (result.method_23665()) class_5545.method_9497(state, world, pos);
            return result;
        }
        class_5545.method_31614(player, state, world, pos);
        return class_1269.method_29236(world.field_9236);
    }

    private static boolean isHittingCandle(class_3965 hitResult) {
        return hitResult.method_17784().field_1351 - (double)hitResult.method_17777().method_10264() > 0.5;
    }

    @Override
    public class_1799 method_9574(class_4538 world, class_2338 pos, class_2680 state) {
        return new class_1799(UsefulFoodCakeBlocks.CaramelCake);
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{field_27083});
    }

    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        return direction == class_2350.field_11033 && !state.method_26184(world, pos) ? class_2246.field_10124.method_9564() : super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    public static class_2680 getCandleCakeFromCandle(class_2248 candle) {
        return CAKES_TRANSFORM.get(candle).method_9564();
    }

    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        return world.method_8320(pos.method_10074()).method_51367();
    }

    public int method_9572(class_2680 state, class_1937 world, class_2338 pos) {
        return SpecialCakeBlockState.DEFAULT_COMPARATOR_OUTPUT;
    }

    public static boolean canBeLit(class_2680 state) {
        return state.method_27851(class_3481.field_26984, (statex) -> {
            return statex.method_28498(field_27083) && !(Boolean)state.method_11654(field_27083);
        });
    }

    @Override
    protected MapCodec<? extends CandleCaramelCakeBlock> method_53969() {
        return field_46280;
    }

    @Override
    protected Iterable<class_243> method_31613(class_2680 state) {
        return PARTICLE_OFFSETS;
    }

    static {
        field_27083 = class_5540.field_27083;
        CAKE_SHAPE = class_2248.method_9541(1.0, 0.0, 1.0, 15.0, 8.0, 15.0);
        CANDLE_SHAPE = class_2248.method_9541(7.0, 8.0, 7.0, 9.0, 14.0, 9.0);
        SHAPE = class_259.method_1084(CAKE_SHAPE, CANDLE_SHAPE);
        CANDLES_TO_CANDLE_CAKES = Maps.newHashMap();
        PARTICLE_OFFSETS = ImmutableList.of(new class_243(0.5, 1.0, 0.5));
    }
}