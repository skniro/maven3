package com.skniro.growable_ores_extension.compat;

import com.skniro.growable_ores_extension.compat.category.*;
import com.skniro.growable_ores_extension.compat.display.*;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import com.skniro.growable_ores_extension.recipe.machine.*;
import me.shedaniel.rei.api.common.display.DisplaySerializerRegistry;
import me.shedaniel.rei.api.common.plugins.REICommonPlugin;
import me.shedaniel.rei.api.common.registry.display.ServerDisplayRegistry;

public class IndustrialModREICommon implements REICommonPlugin {

    @Override
    public String getPluginProviderName() {
        return "IndustrialAlpha";
    }

    @Override
    public void registerDisplays(ServerDisplayRegistry registry) {
        registry.beginRecipeFiller(MaceratorCraftingRecipe.class)
                .filterType(AlchemyRecipeType.MACERATOR.type)
                .fill(MaceratorDisplay::new);
        registry.beginRecipeFiller(CompressorCraftingRecipe.class)
                .filterType(AlchemyRecipeType.COMPRESSOR.type)
                .fill(CompressorDisplay::new);
        registry.beginRecipeFiller(MetalFormerExtrudingCraftingRecipe.class)
                .filterType(AlchemyRecipeType.METALFORMER_EXTRUDING.type)
                .fill(MetalFormerExtrudingDisplay::new);
        registry.beginRecipeFiller(MetalFormerRollingCraftingRecipe.class)
                .filterType(AlchemyRecipeType.METALFORMER_ROLLING.type)
                .fill(MetalFormerRollingDisplay::new);
        registry.beginRecipeFiller(MetalFormerCuttingCraftingRecipe.class)
                .filterType(AlchemyRecipeType.METALFORMER_CUTTING.type)
                .fill(MetalFormerCuttingDisplay::new);
        registry.beginRecipeFiller(MolecularTransformerCraftingRecipe.class)
                .filterType(AlchemyRecipeType.MOLECULAR_TRANSFORMER.type)
                .fill(MolecularTransformerDisplay::new);
        registry.beginRecipeFiller(ExtractorCraftingRecipe.class)
                .filterType(AlchemyRecipeType.EXTRACTOR.type)
                .fill(ExtractorDisplay::new);
    }

    @Override
    public void registerDisplaySerializer(DisplaySerializerRegistry registry) {
        registry.register(MaceratorCategory.MACERATOR.getIdentifier(), MaceratorDisplay.SERIALIZER);
        registry.register(CompressorCategory.Compressor.getIdentifier(), CompressorDisplay.SERIALIZER);
        registry.register(MetalFormerExtrudingCategory.MetalFormerExtruding.getIdentifier(), MetalFormerExtrudingDisplay.SERIALIZER);
        registry.register(MetalFormerCuttingCategory.MetalFormerCutting.getIdentifier(), MetalFormerRollingDisplay.SERIALIZER);
        registry.register(MetalFormerRollingCategory.MetalFormerRolling.getIdentifier(), MetalFormerCuttingDisplay.SERIALIZER);
        registry.register(MolecularTransformerCategory.MolecularTransformer.getIdentifier(), MolecularTransformerDisplay.SERIALIZER);
        registry.register(ExtractorCategory.Extractor.getIdentifier(), ExtractorDisplay.SERIALIZER);
    }
}