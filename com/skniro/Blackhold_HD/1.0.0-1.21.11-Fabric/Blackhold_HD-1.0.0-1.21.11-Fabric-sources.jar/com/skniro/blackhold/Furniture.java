package com.skniro.blackhold;

import com.skniro.blackhold.block.FurnitureDrawBlocks;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Furniture implements ModInitializer {
    public static final String MOD_ID = "blackhold";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final class_5321<class_1761> Maple_Group_Furniture = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(MOD_ID, "maple_group_furniture"));
    @Override
    public void onInitialize() {
        class_2378.method_39197(class_7923.field_44687, Maple_Group_Furniture, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(FurnitureDrawBlocks.Acacia_Allay_Draw))
                .method_47321(class_2561.method_43471("itemGroup.blackhold.maple_group_furniture"))
                .method_47324());

        FurnitureContent.registerItem();
        FurnitureContent.registerBlock();
        FurnitureContent.CreativeTab();
    }

}
