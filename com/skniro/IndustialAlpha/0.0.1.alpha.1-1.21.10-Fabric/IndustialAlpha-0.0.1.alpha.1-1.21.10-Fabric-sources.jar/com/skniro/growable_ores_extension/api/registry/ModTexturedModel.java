package com.skniro.growable_ores_extension.api.registry;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4943;
import net.minecraft.class_4946;
import net.minecraft.client.data.*;

import static net.minecraft.class_4944.method_25876;
import static net.minecraft.class_4946.method_25918;

@Environment(EnvType.CLIENT)
public class ModTexturedModel {
    public static final class_4946.class_4947 CUBE;


    static {

        CUBE = method_25918(ModTextureMap::allSides, class_4943.field_22942);
    }
}