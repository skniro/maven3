package com.skniro.growable_ores_extension.block.entity;


import com.skniro.growable_ores_extension.block.init.MapleBlockSetType;
import com.skniro.growable_ores_extension.mixin.SignTypeAccessor;
import net.minecraft.world.level.block.state.properties.WoodType;

public class MapleSignTypes {
    public static final WoodType Rubber =
            SignTypeAccessor.registerNew(SignTypeAccessor.newSignType("maple_rubber", MapleBlockSetType.Rubber));
}