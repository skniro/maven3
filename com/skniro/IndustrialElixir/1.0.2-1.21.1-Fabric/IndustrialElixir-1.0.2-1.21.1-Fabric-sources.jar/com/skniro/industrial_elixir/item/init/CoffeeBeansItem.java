package com.skniro.industrial_elixir.item.init;

import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

public class CoffeeBeansItem extends class_1792 {

    private final class_2248 plant;

    public CoffeeBeansItem(class_2248 plant, class_1793 properties) {
        super(properties);
        this.plant = plant;
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 level = context.method_8045();
        class_2338 clickedPos = context.method_8037();
        class_2350 direction = context.method_8038();

        class_2338 placePos = clickedPos.method_10093(direction);

        class_2680 clickedState = level.method_8320(clickedPos);

        boolean canPlantOn = clickedState.method_27852(class_2246.field_10566) || clickedState.method_27852(class_2246.field_10219) || clickedState.method_27852(class_2246.field_10520) || clickedState.method_27852(class_2246.field_10102) || clickedState.method_27852(class_2246.field_10362);

        if (!canPlantOn) {
            return class_1269.field_5814;
        }

        if (!level.method_8608()) {
            level.method_8652(placePos, plant.method_9564(), class_2248.field_31036);
            context.method_8041().method_7934(1);
        }

        return class_1269.field_5812;
    }
}