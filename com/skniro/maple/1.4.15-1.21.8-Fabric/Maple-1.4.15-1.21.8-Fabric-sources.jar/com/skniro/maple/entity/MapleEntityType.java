package com.skniro.maple.entity;

import com.mojang.datafixers.types.Type;
import com.skniro.maple.Maple;
import com.skniro.maple.entity.furniture.ChairEntity;
import com.skniro.maple.entity.furniture.CushionEntity;
import com.skniro.maple.item.MapleItems;
import java.util.function.Supplier;
import net.minecraft.class_1208;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_156;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7264;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class MapleEntityType {
    public static final class_1299<ChairEntity> CHAIR_ENTITY =
            register("chair_entity",  class_1299.class_1300.method_5903(ChairEntity::new, class_1311.field_17715)
                    .method_17687(0.5f, 0.5f));

    public static final class_1299<CushionEntity> Cushion_ENTITY =
            register("cushion_entity",  class_1299.class_1300.method_5903(CushionEntity::new, class_1311.field_17715)
                    .method_17687(0.5f, 0.5f));

    public static final class_1299<class_1690> Maple_BOAT = register("maple_boat", class_1299.class_1300.method_5903(getBoatFactory(() -> {
        return MapleItems.MAPLE_BOAT;
    }), class_1311.field_17715).method_63006().method_17687(1.375F, 0.5625F).method_55687(0.5625F).method_27299(10));

    public static final class_1299<class_7264> Maple_CHEST_BOAT = register("maple_chest_boat", class_1299.class_1300.method_5903(getChestBoatFactory(() -> {
        return MapleItems.MAPLE_CHEST_BOAT;
    }), class_1311.field_17715).method_63006().method_17687(1.375F, 0.5625F).method_55687(0.5625F).method_27299(10));

    public static final class_1299<class_1690> GINKGO_BOAT = register("ginkgo_boat", class_1299.class_1300.method_5903(getBoatFactory(() -> {
        return MapleItems.MAPLE_BOAT;
    }), class_1311.field_17715).method_63006().method_17687(1.375F, 0.5625F).method_55687(0.5625F).method_27299(10));

    public static final class_1299<class_7264> GINKGO_CHEST_BOAT = register("ginkgo_chest_boat", class_1299.class_1300.method_5903(getChestBoatFactory(() -> {
        return MapleItems.MAPLE_CHEST_BOAT;
    }), class_1311.field_17715).method_63006().method_17687(1.375F, 0.5625F).method_55687(0.5625F).method_27299(10));

    private static <T extends class_1297> class_1299<T> register(String name, class_1299.class_1300<T> builder) {
        Type<?> type = class_156.method_29187(class_1208.field_5729, name);
        return (class_1299) class_2378.method_10230(class_7923.field_41177, class_2960.method_60655(Maple.MOD_ID, name), builder.method_5905(keyOf(name)));
    }
    private static class_5321<class_1299<?>> keyOf(String name) {
        return class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(Maple.MOD_ID, name));
    }

    private static class_1299.class_4049<class_1690> getBoatFactory(Supplier<class_1792> itemSupplier) {
        return (type, world) -> {
            return new class_1690(type, world, itemSupplier);
        };
    }

    private static class_1299.class_4049<class_7264> getChestBoatFactory(Supplier<class_1792> itemSupplier) {
        return (type, world) -> {
            return new class_7264(type, world, itemSupplier);
        };
    }

    public static void registerMapleEntityType() {
        Maple.LOGGER.debug("Registering MapleEntityType for " + Maple.MOD_ID);
    }
}
