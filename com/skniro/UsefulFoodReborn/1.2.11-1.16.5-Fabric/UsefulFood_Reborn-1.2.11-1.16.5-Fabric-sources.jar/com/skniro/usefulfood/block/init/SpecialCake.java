package com.skniro.usefulfood.block.init;

import net.minecraft.class_2248;

public class SpecialCake extends class_2248 {
    static int foodlevel;
    static float saturation;
    String name;
    public SpecialCake(class_2251 settings, int foodlevel, float saturation) {
        super(settings);
        this.foodlevel = foodlevel / 6;
        this.saturation = saturation;
    }
}
