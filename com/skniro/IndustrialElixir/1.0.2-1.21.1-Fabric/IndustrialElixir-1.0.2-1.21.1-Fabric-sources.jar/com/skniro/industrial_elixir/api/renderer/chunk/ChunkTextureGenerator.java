package com.skniro.industrial_elixir.api.renderer.chunk;

import net.minecraft.class_1011;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_2902;

public final class ChunkTextureGenerator {

    public static final int SIZE = 16;

    private ChunkTextureGenerator() {
    }

    /**
     * Generate a 16x16 top-down map image for a chunk.
     * Falls back to a dark placeholder if the chunk is not loaded.
     */
    public static class_1011 generate(class_1937 level, class_1923 chunkPos) {

        class_1011 image = new class_1011(class_1011.class_1012.field_4997, SIZE, SIZE, false);

        class_2818 chunk = level.method_8497(chunkPos.field_9181, chunkPos.field_9180);

        // If chunk is not fully loaded, return a dark placeholder image
        if (chunk == null || chunk.method_12223()) {
            for (int x = 0; x < SIZE; x++) {
                for (int z = 0; z < SIZE; z++) {
                    image.method_4305(x, z, 0xFF222222);
                }
            }
            return image;
        }

        int lastHeight = 0;

        for (int x = 0; x < SIZE; x++) {
            for (int z = 0; z < SIZE; z++) {

                int height = chunk.method_12005(class_2902.class_2903.field_13202, x, z);
                int worldX = chunkPos.method_8326() + x;
                int worldZ = chunkPos.method_8328() + z;

                class_2338 pos = new class_2338(worldX, height - 1, worldZ);
                var state = chunk.method_8320(pos);

                int color = ChunkColorProvider.getColor(level, pos, state);
                color = ChunkColorProvider.applyHeightShade(color, height - lastHeight);
                lastHeight = height;

                image.method_4305(x, z, argbToAbgr(color));
            }
        }

        return image;
    }

    /**
     * {@link class_1011} stores its pixels in ABGR byte order, while
     * {@link ChunkColorProvider} produces conventional ARGB values.
     */
    private static int argbToAbgr(int argb) {
        return (argb & 0xFF00FF00)
                | ((argb & 0x000000FF) << 16)
                | ((argb & 0x00FF0000) >>> 16);
    }
}
