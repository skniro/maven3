package com.skniro.growable_ores_extension.item;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.MapleSignBlocks;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.energy.api.base.SimpleEnergyItem;
import com.skniro.growable_ores_extension.item.init.BatteryItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroupEntries;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModCreativeTab {
    public static final class_5321<class_1761> General = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "general"));
    public static final class_5321<class_1761> Generators_And_Wiring = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "generators_and_wiring"));
    public static final class_5321<class_1761> Reactor = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "reactor"));
    public static final class_5321<class_1761> Machine = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "machine"));
    public static final class_5321<class_1761> Tool_And_Utilities = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "tool_and_utilities"));
    public static final class_5321<class_1761> Combat = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "combat"));
    public static final class_5321<class_1761> Materials = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "materials"));

    public static void CreativeTab() {
        class_2378.method_39197(class_7923.field_44687, General, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GeneralBlocks.Machine.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.general"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Generators_And_Wiring, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.COAL_GENERATOR.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.generators_and_wiring"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Reactor, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.COPPER_CABLE.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.reactor"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Machine, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.Macerator_Block.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.machine"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Tool_And_Utilities, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresItems.ENERGY_STORAGE.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.tool_and_utilities"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Combat, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(MapleArmorItems.Quantum_HELMET.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.combat"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Materials, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresItems.Rubber.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.materials"))
                .method_47324()); // build() no longer registers by itself
    }

    public static void CreativeTabItem() {
        ItemGroupEvents.modifyEntriesEvent(General).register(content -> {
            content.method_45421(GrowableOresBlocks.GrowableOres_Block);

            content.method_45421(GeneralBlocks.Lead_Ore);
            content.method_45421(GeneralBlocks.Tin_Ore);
            content.method_45421(GeneralBlocks.Uranium_Ore);
            content.method_45421(GeneralBlocks.Deepslate_Lead_Ore);
            content.method_45421(GeneralBlocks.Deepslate_Tin_Ore);
            content.method_45421(GeneralBlocks.Deepslate_Uranium_Ore);
            content.method_45421(GeneralBlocks.Raw_Lead_Block);
            content.method_45421(GeneralBlocks.Raw_Tin_Block);
            content.method_45421(GeneralBlocks.Raw_Uranium_Block);
            content.method_45421(GeneralBlocks.Lead_Block);
            content.method_45421(GeneralBlocks.Tin_Block);
            content.method_45421(GeneralBlocks.Uranium_Block);
            content.method_45421(GeneralBlocks.Silver_Block);
            content.method_45421(GeneralBlocks.Bronze_Block);
            content.method_45421(GeneralBlocks.Steel_Block);

            content.method_45421(GeneralBlocks.Rubber_STAIRS);
            content.method_45421(GeneralBlocks.Rubber_SLAB);
            content.method_45421(GeneralBlocks.Rubber_BUTTON);
            content.method_45421(GeneralBlocks.Rubber_PRESSURE_PLATE);
            content.method_45421(GeneralBlocks.Rubber_FENCE);
            content.method_45421(GeneralBlocks.Rubber_FENCE_GATE);
            content.method_45421(GeneralBlocks.Rubber_LOG);
            content.method_45421(GeneralBlocks.Rubber_LOG);
            content.method_45421(GeneralBlocks.Rubber_WOOD);
            content.method_45421(GeneralBlocks.STRIPPED_Rubber_LOG);
            content.method_45421(GeneralBlocks.STRIPPED_Rubber_LOG);
            content.method_45421(GeneralBlocks.STRIPPED_Rubber_WOOD);
            content.method_45421(GeneralBlocks.Rubber_DOOR);
            content.method_45421(GeneralBlocks.Rubber_TRAPDOOR);
            content.method_45421(GeneralBlocks.Rubber_SAPLING);
            content.method_45421(GeneralBlocks.Rubber_LEAVES);
            content.method_45421(GeneralBlocks.Rubber_Rubber_LOG);
            content.method_45421(GrowableOresItems.Rubber);
            content.method_45421(MapleSignBlocks.Rubber_SIGN);
            content.method_45421(MapleSignBlocks.Rubber_HANGING_SIGN);
            content.method_45421(GrowableOresItems.RUBBER_BOAT);
            content.method_45421(GrowableOresItems.RUBBER_CHEST_BOAT);
            content.method_45421(GeneralBlocks.Machine);
            content.method_45421(GeneralBlocks.Advanced_Machine);


        });

        ItemGroupEvents.modifyEntriesEvent(Generators_And_Wiring).register(content -> {
            content.method_45421(GrowableOresBlocks.COPPER_CABLE);
            content.method_45421(GrowableOresBlocks.TIN_CABLE);
            content.method_45421(GrowableOresBlocks.GOLD_CABLE);
            content.method_45421(GrowableOresBlocks.HV_CABLE);
            content.method_45421(GrowableOresBlocks.GLASSFIBER_CABLE);
            content.method_45421(GrowableOresBlocks.INSULATED_COPPER_CABLE);
            content.method_45421(GrowableOresBlocks.INSULATED_GOLD_CABLE);
            content.method_45421(GrowableOresBlocks.INSULATED_HV_CABLE);
            content.method_45421(GrowableOresBlocks.COAL_GENERATOR);
            content.method_45421(GrowableOresBlocks.GENERATOR_Wind_Mill);
            content.method_45421(GrowableOresBlocks.GENERATOR_SolarPanel);
            content.method_45421(GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL);
            content.method_45421(GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL);
            content.method_45421(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL);
            content.method_45421(GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL);

            content.method_45421(GrowableOresBlocks.EnergyBox);
            content.method_45421(GrowableOresBlocks.ChargePad);
            content.method_45421(GrowableOresBlocks.CESU);
            content.method_45421(GrowableOresBlocks.MFE);
            content.method_45421(GrowableOresBlocks.MFSU);
            content.method_45421(GrowableOresBlocks.ChargePad);
            content.method_45421(GrowableOresBlocks.CESU_CHARGE_PAD);
            content.method_45421(GrowableOresBlocks.MFE_CHARGE_PAD);
            content.method_45421(GrowableOresBlocks.MFSU_CHARGE_PAD);
            content.method_45421(GrowableOresBlocks.LV_TRANSFORMER);
            content.method_45421(GrowableOresBlocks.MV_TRANSFORMER);
            content.method_45421(GrowableOresBlocks.HV_TRANSFORMER);
            content.method_45421(GrowableOresBlocks.EV_TRANSFORMER);

        });

        ItemGroupEvents.modifyEntriesEvent(Reactor).register(content -> {

        });

        ItemGroupEvents.modifyEntriesEvent(Machine).register(content -> {
            content.method_45421(GrowableOresBlocks.Macerator_Block);
            content.method_45421(GrowableOresBlocks.Compressor_Block);
            content.method_45421(GrowableOresBlocks.MetalFormerBlock);
            content.method_45421(GrowableOresBlocks.Extractor_Block);

            content.method_45421(GrowableOresBlocks.MolecularTransformerBlock);

            content.method_45421(GrowableOresBlocks.Iron_Furnace_Block);
        });

        ItemGroupEvents.modifyEntriesEvent(Tool_And_Utilities).register(content -> {
            content.method_45421(GrowableOresItems.ENERGY_STORAGE);
            content.method_45421(GrowableOresItems.OVERCLOCKER);
            content.method_45421(GrowableOresItems.TRANSFORMER);
            content.method_45421(GrowableOresItems.REDSTONE_INVERTER);

            content.method_45421(MapleArmorItems.ROLLING);
            content.method_45421(MapleArmorItems.CUTTING);

            content.method_45421(GrowableOresItems.RE_BATTERY);
            addFullEnergyItem(content, GrowableOresItems.RE_BATTERY);
            content.method_45421(GrowableOresItems.ADVANCED_RE_BATTERY);
            addFullEnergyItem(content, GrowableOresItems.ADVANCED_RE_BATTERY);
            content.method_45421(GrowableOresItems.ENERGY_CRYSTAL);
            addFullEnergyItem(content, GrowableOresItems.ENERGY_CRYSTAL);
            content.method_45421(GrowableOresItems.LAPOTRON_CRYSTAL);
            addFullEnergyItem(content, GrowableOresItems.LAPOTRON_CRYSTAL);


        });

        ItemGroupEvents.modifyEntriesEvent(Combat).register(content -> {
            content.method_45421(MapleArmorItems.Quantum_HELMET);
            addFullEnergyItem(content, MapleArmorItems.Quantum_HELMET);
            content.method_45421(MapleArmorItems.Quantum_CHESTPLATE);
            addFullEnergyItem(content, MapleArmorItems.Quantum_CHESTPLATE);
            content.method_45421(MapleArmorItems.Quantum_LEGGINGS);
            addFullEnergyItem(content, MapleArmorItems.Quantum_LEGGINGS);
            content.method_45421(MapleArmorItems.Quantum_BOOTS);
            addFullEnergyItem(content, MapleArmorItems.Quantum_BOOTS);

        });

        ItemGroupEvents.modifyEntriesEvent(Materials).register(content -> {
            content.method_45421(GrowableOresItems.Raw_Lead);
            content.method_45421(GrowableOresItems.Raw_Tin);
            content.method_45421(GrowableOresItems.Raw_Uranium);

            content.method_45421(GrowableOresItems.CRUSHED_COPPER);
            content.method_45421(GrowableOresItems.CRUSHED_GOLD);
            content.method_45421(GrowableOresItems.CRUSHED_IRON);
            content.method_45421(GrowableOresItems.CRUSHED_LEAD);
            content.method_45421(GrowableOresItems.CRUSHED_SILVER);
            content.method_45421(GrowableOresItems.CRUSHED_TIN);
            content.method_45421(GrowableOresItems.CRUSHED_URANIUM);

            content.method_45421(GrowableOresItems.PURIFIED_COPPER);
            content.method_45421(GrowableOresItems.PURIFIED_GOLD);
            content.method_45421(GrowableOresItems.PURIFIED_IRON);
            content.method_45421(GrowableOresItems.PURIFIED_LEAD);
            content.method_45421(GrowableOresItems.PURIFIED_SILVER);
            content.method_45421(GrowableOresItems.PURIFIED_TIN);
            content.method_45421(GrowableOresItems.PURIFIED_URANIUM);

            content.method_45421(GrowableOresItems.BRONZE_DUST);
            content.method_45421(GrowableOresItems.CLAY_DUST);
            content.method_45421(GrowableOresItems.COAL_DUST);
            content.method_45421(GrowableOresItems.COAL_FUEL_DUST);
            content.method_45421(GrowableOresItems.COPPER_DUST);
            content.method_45421(GrowableOresItems.DIAMOND_DUST);
            content.method_45421(GrowableOresItems.ENERGIUM_DUST);
            content.method_45421(GrowableOresItems.GOLD_DUST);
            content.method_45421(GrowableOresItems.IRON_DUST);
            content.method_45421(GrowableOresItems.LAPIS_DUST);
            content.method_45421(GrowableOresItems.LEAD_DUST);
            content.method_45421(GrowableOresItems.LITHIUM_DUST);
            content.method_45421(GrowableOresItems.OBSIDIAN_DUST);
            content.method_45421(GrowableOresItems.SILICON_DIOXIDE_DUST);
            content.method_45421(GrowableOresItems.SILVER_DUST);
            content.method_45421(GrowableOresItems.STONE_DUST);
            content.method_45421(GrowableOresItems.SULFUR_DUST);
            content.method_45421(GrowableOresItems.TIN_DUST);

            content.method_45421(GrowableOresItems.SMALL_BRONZE_DUST);
            content.method_45421(GrowableOresItems.SMALL_COPPER_DUST);
            content.method_45421(GrowableOresItems.SMALL_GOLD_DUST);
            content.method_45421(GrowableOresItems.SMALL_IRON_DUST);
            content.method_45421(GrowableOresItems.SMALL_LAPIS_DUST);
            content.method_45421(GrowableOresItems.SMALL_LEAD_DUST);
            content.method_45421(GrowableOresItems.SMALL_LITHIUM_DUST);
            content.method_45421(GrowableOresItems.SMALL_OBSIDIAN_DUST);
            content.method_45421(GrowableOresItems.SMALL_SILVER_DUST);
            content.method_45421(GrowableOresItems.SMALL_SULFUR_DUST);
            content.method_45421(GrowableOresItems.SMALL_TIN_DUST);

            content.method_45421(GrowableOresItems.BRONZE_INGOT);
            content.method_45421(GrowableOresItems.LEAD_INGOT);
            content.method_45421(GrowableOresItems.SILVER_INGOT);
            content.method_45421(GrowableOresItems.STEEL_INGOT);
            content.method_45421(GrowableOresItems.TIN_INGOT);
            content.method_45421(GrowableOresItems.REFINED_IRON_INGOT);
            content.method_45421(GrowableOresItems.URANIUM_INGOT);

            content.method_45421(GrowableOresItems.BRONZE_PLATE);
            content.method_45421(GrowableOresItems.COPPER_PLATE);
            content.method_45421(GrowableOresItems.GOLD_PLATE);
            content.method_45421(GrowableOresItems.IRON_PLATE);
            content.method_45421(GrowableOresItems.LAPIS_PLATE);
            content.method_45421(GrowableOresItems.LEAD_PLATE);
            content.method_45421(GrowableOresItems.OBSIDIAN_PLATE);
            content.method_45421(GrowableOresItems.STEEL_PLATE);
            content.method_45421(GrowableOresItems.TIN_PLATE);

            content.method_45421(GrowableOresItems.DENSE_BRONZE_PLATE);
            content.method_45421(GrowableOresItems.DENSE_COPPER_PLATE);
            content.method_45421(GrowableOresItems.DENSE_GOLD_PLATE);
            content.method_45421(GrowableOresItems.DENSE_IRON_PLATE);
            content.method_45421(GrowableOresItems.DENSE_LAPIS_PLATE);
            content.method_45421(GrowableOresItems.DENSE_LEAD_PLATE);
            content.method_45421(GrowableOresItems.DENSE_OBSIDIAN_PLATE);
            content.method_45421(GrowableOresItems.DENSE_STEEL_PLATE);
            content.method_45421(GrowableOresItems.DENSE_TIN_PLATE);

            content.method_45421(GrowableOresItems.BRONZE_CASING);
            content.method_45421(GrowableOresItems.COPPER_CASING);
            content.method_45421(GrowableOresItems.GOLD_CASING);
            content.method_45421(GrowableOresItems.IRON_CASING);
            content.method_45421(GrowableOresItems.LEAD_CASING);
            content.method_45421(GrowableOresItems.STEEL_CASING);
            content.method_45421(GrowableOresItems.TIN_CASING);

            content.method_45421(GrowableOresItems.CARBON_FIBRE);
            content.method_45421(GrowableOresItems.CARBON_MESH);
            content.method_45421(GrowableOresItems.CARBON_PLATE);
            content.method_45421(GrowableOresItems.COAL_BALL);
            content.method_45421(GrowableOresItems.COAL_BLOCK);
            content.method_45421(GrowableOresItems.COAL_CHUNK);
            content.method_45421(GrowableOresItems.INDUSTRIAL_DIAMOND);
            content.method_45421(GrowableOresItems.IRIDIUM_SHARD);
            content.method_45421(GrowableOresItems.IRIDIUM_ORE);
            content.method_45421(GrowableOresItems.ALLOY_INGOT);
            content.method_45421(GrowableOresItems.ALLOY_PLATE);
            content.method_45421(GrowableOresItems.Circuit);
            content.method_45421(GrowableOresItems.Advanced_Circuit);


            content.method_45421(AdvancedItems.IRRADIANT_URANIUM_INGOT);
            content.method_45421(AdvancedItems.IRRADIANT_GLASS_PANE);
            content.method_45421(AdvancedItems.SUNNARIUM);
            content.method_45421(AdvancedItems.ENRICHED_SUNNARIUM);
            content.method_45421(AdvancedItems.SUNNARIUM_ALLOY);
            content.method_45421(AdvancedItems.ENRICHED_SUNNARIUM_ALLOY);
            content.method_45421(AdvancedItems.IRIDIUM_IRON_PLATE);
            content.method_45421(AdvancedItems.REINFORCED_IRIDIUM_IRON_PLATE);
            content.method_45421(AdvancedItems.IRRADIANT_REINFORCED_PLATE);
            content.method_45421(AdvancedItems.SUNNARIUM_Part);
            content.method_45421(AdvancedItems.Iridium_INGOT);
            content.method_45421(AdvancedItems.Quantum_Core);
            content.method_45421(AdvancedItems.MT_Core);
        });
    }

    public static void addFullEnergyItem(FabricItemGroupEntries content, class_1792 item) {
        class_1799 stack = new class_1799(item);
        stack.method_7974(0);
        if (stack.method_7909() instanceof SimpleEnergyItem battery) {
            battery.setStoredEnergy(stack, battery.getEnergyCapacity(stack));
        }
        content.method_45420(stack);
    }
}
