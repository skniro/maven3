package com.skniro.growableores.registry.tag;

import com.skniro.growableores.GrowableOres;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_6862;

public class GrowableBlockTags {
    public static final class_6862<class_2248> GrowBlock = of("growblock");



    private static class_6862<class_2248> of(String id) {
        return class_6862.method_40092(class_2378.field_25105, new class_2960(GrowableOres.MOD_ID ,id));
    }
}
