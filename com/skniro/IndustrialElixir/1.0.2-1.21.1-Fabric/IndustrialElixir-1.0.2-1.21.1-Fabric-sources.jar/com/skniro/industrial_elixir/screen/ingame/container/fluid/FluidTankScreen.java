package com.skniro.industrial_elixir.screen.ingame.container.fluid;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.renderer.GuiFluidTankRenderer;
import com.skniro.industrial_elixir.screen.handler.container.fluid.FluidTankScreenHandler;
import com.skniro.industrial_elixir.util.MouseUtil;
import java.util.Optional;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class FluidTankScreen extends class_465<FluidTankScreenHandler> {
    private static final class_2960 TEXTURE =
            class_2960.method_60655(IndustrialElixir.MOD_ID,"textures/gui/container/container/fluidtank.png");
    private GuiFluidTankRenderer fluidRenderer;

    public FluidTankScreen(FluidTankScreenHandler menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        assignFluidRenderer();
    }


    private void assignFluidRenderer() {
        fluidRenderer = new GuiFluidTankRenderer(field_2797.blockEntity.fluidContainer.getCapacity(), true, 16, 50);
    }

    private void renderFluidTooltipArea(class_332 guiGraphics, int pMouseX, int pMouseY, int x, int y,
                                        int offsetX, int offsetY, GuiFluidTankRenderer renderer) {
        if(isMouseAboveArea(pMouseX, pMouseY, x, y, offsetX, offsetY, renderer)) {
            guiGraphics.method_51437(this.field_22793, renderer.getTooltip(field_2797.blockEntity.fluidContainer), Optional.empty(), pMouseX, pMouseY);
        }
    }

    @Override
    protected void method_2388(class_332 graphics, int xm, int ym) {
        super.method_2388(graphics, xm, ym);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        renderFluidTooltipArea(graphics, xm, ym, x, y, 79, 14, fluidRenderer);
    }

    @Override
    protected void method_2389(class_332 graphics, float a, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        graphics.method_25290(TEXTURE, x, y, 0, 0,
                field_2792, field_2779, 256, 256);

        fluidRenderer.render(graphics, x + 79, y + 14, field_2797.blockEntity.fluidContainer);
    }

    public static boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, GuiFluidTankRenderer renderer) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, renderer.getWidth(), renderer.getHeight());
    }

    public static boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, int width, int height) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, width, height);
    }
}