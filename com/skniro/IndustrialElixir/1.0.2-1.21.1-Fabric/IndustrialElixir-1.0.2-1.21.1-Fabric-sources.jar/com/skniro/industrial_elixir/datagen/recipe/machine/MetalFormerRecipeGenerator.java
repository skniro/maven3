package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.item.AdvancedItems;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class MetalFormerRecipeGenerator extends FabricRecipeProvider {
    public MetalFormerRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                // Bronze
                createMetalFormerRolling(GrowableOresItems.BRONZE_INGOT, GrowableOresItems.BRONZE_PLATE).method_10431(output);
                createMetalFormerRolling(GrowableOresItems.BRONZE_PLATE, GrowableOresItems.BRONZE_CASING,2).method_10431(output);

                // Iron
                createMetalFormerRolling(class_1802.field_8620, GrowableOresItems.IRON_PLATE).method_10431(output);
                createMetalFormerRolling(GrowableOresItems.IRON_PLATE, GrowableOresItems.IRON_CASING,2).method_10431(output);

                // Gold
                createMetalFormerRolling(class_1802.field_8695, GrowableOresItems.GOLD_PLATE).method_10431(output);
                createMetalFormerRolling(GrowableOresItems.GOLD_PLATE, GrowableOresItems.GOLD_CASING,2).method_10431(output);

                // Copper
                createMetalFormerRolling(class_1802.field_27022, GrowableOresItems.COPPER_PLATE).method_10431(output);
                createMetalFormerRolling(GrowableOresItems.COPPER_PLATE, GrowableOresItems.COPPER_CASING, 2).method_10431(output);

                // Steel
                createMetalFormerRolling(GrowableOresItems.STEEL_INGOT, GrowableOresItems.STEEL_PLATE).method_10431(output);
                createMetalFormerRolling(GrowableOresItems.STEEL_PLATE, GrowableOresItems.STEEL_CASING,2).method_10431(output);

                // Lead
                createMetalFormerRolling(GrowableOresItems.LEAD_INGOT, GrowableOresItems.LEAD_PLATE).method_10431(output);
                createMetalFormerRolling(GrowableOresItems.LEAD_PLATE, GrowableOresItems.LEAD_CASING,2).method_10431(output);

                // Tin
                createMetalFormerRolling(GrowableOresItems.TIN_INGOT, GrowableOresItems.TIN_PLATE).method_10431(output);
                createMetalFormerRolling(GrowableOresItems.TIN_PLATE, GrowableOresItems.TIN_CASING,2).method_10431(output);

                createMetalFormerCutting(GrowableOresItems.TIN_PLATE, GrowableOresBlocks.TIN_CABLE,3).method_10431(output);
                createMetalFormerCutting(GrowableOresItems.IRON_PLATE, GrowableOresBlocks.HV_CABLE,4).method_10431(output);
                createMetalFormerCutting(GrowableOresItems.GOLD_PLATE, GrowableOresBlocks.GOLD_CABLE,4).method_10431(output);
                createMetalFormerCutting(GrowableOresItems.COPPER_PLATE, GrowableOresBlocks.COPPER_CABLE,2).method_10431(output);

                createMetalFormerExtruding(class_1802.field_27022, GrowableOresBlocks.COPPER_CABLE,3).method_10431(output);
                createMetalFormerExtruding(GrowableOresItems.TIN_INGOT, GrowableOresBlocks.TIN_CABLE,3).method_10431(output);
                createMetalFormerExtruding(class_1802.field_8695, GrowableOresBlocks.GOLD_CABLE,4).method_10431(output);
                createMetalFormerExtruding(class_1802.field_8620, GrowableOresBlocks.HV_CABLE,4).method_10431(output);
                createMetalFormerExtruding(GrowableOresItems.IRIDIUM_PLATE, AdvancedItems.Iridium_INGOT).method_10431(output);
            }
        };
    }

    @Override
    public String method_10321() {
        return "MetalFormer";
    }
}
