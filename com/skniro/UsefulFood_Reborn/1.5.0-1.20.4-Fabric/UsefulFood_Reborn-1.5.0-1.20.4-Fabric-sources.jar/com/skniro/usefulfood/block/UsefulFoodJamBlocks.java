package com.skniro.usefulfood.block;

import com.skniro.usefulfood.UsefulFood;
import com.skniro.usefulfood.block.init.GlassJarBlock;
import com.skniro.usefulfood.block.init.JamJarBlock;
import com.skniro.usefulfood.block.init.jam.JamType;
import com.skniro.usefulfood.item.UsefulFoodItems;
import java.util.logging.Logger;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public class UsefulFoodJamBlocks {

    public static final class_2248 GLASS_JAR = registerBlock("glass_jar", new GlassJarBlock(class_4970.class_2251.method_9637().method_22488().method_9632(0.3F).method_9626(class_2498.field_11537)), UsefulFood.UsefulFood_Group);

    public static final class_2248 Apple_JAM_JAR = registerBlock("apple_jam_jar", new JamJarBlock((class_4970.class_2251.method_9637().method_22488().method_9632(0.3F).method_9626(class_2498.field_11537)), UsefulFoodItems.AppleJam.method_7854(), UsefulFoodJamBlocks.GLASS_JAR, JamType.APPLE), UsefulFood.UsefulFood_Group);
    public static final class_2248 Melon_JAM_JAR = registerBlock("melon_jam_jar", new JamJarBlock((class_4970.class_2251.method_9637().method_22488().method_9632(0.3F).method_9626(class_2498.field_11537)), UsefulFoodItems.MelonJam.method_7854(), UsefulFoodJamBlocks.GLASS_JAR, JamType.MELON), UsefulFood.UsefulFood_Group);
    public static final class_2248 Chorus_JAM_JAR = registerBlock("chorus_jam_jar", new JamJarBlock((class_4970.class_2251.method_9637().method_22488().method_9632(0.3F).method_9626(class_2498.field_11537)), UsefulFoodItems.Chorus_Jam.method_7854(), UsefulFoodJamBlocks.GLASS_JAR, JamType.CHORUS), UsefulFood.UsefulFood_Group);
    public static final class_2248 Sweet_Berries_JAM_JAR = registerBlock("sweet_berries_jam_jar", new JamJarBlock((class_4970.class_2251.method_9637().method_22488().method_9632(0.3F).method_9626(class_2498.field_11537)), UsefulFoodItems.Sweet_Berries_Jam.method_7854(), UsefulFoodJamBlocks.GLASS_JAR, JamType.Sweet_Berries), UsefulFood.UsefulFood_Group);
    public static final class_2248 Glow_Berries_JAM_JAR = registerBlock("glow_berries_jam_jar", new JamJarBlock((class_4970.class_2251.method_9637().method_22488().method_9632(0.3F).method_9626(class_2498.field_11537)), UsefulFoodItems.Glow_Berries_Jam.method_7854(), UsefulFoodJamBlocks.GLASS_JAR, JamType.Glow_Berries), UsefulFood.UsefulFood_Group);

    private static class_2248 registerBlock(String name, class_2248 block, class_5321<class_1761> tab) {
        registerBlockItem(name, block, tab);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_43902(UsefulFood.MOD_ID, name), block);
    }

    private static class_2248 registerBlockWithoutItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_43902(UsefulFood.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_5321<class_1761> tab) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_43902(UsefulFood.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
    }

    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + UsefulFood.MOD_ID);
    }
}
