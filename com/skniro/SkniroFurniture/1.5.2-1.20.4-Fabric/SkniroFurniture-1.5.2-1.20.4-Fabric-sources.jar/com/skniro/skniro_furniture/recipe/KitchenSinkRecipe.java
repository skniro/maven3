package com.skniro.skniro_furniture.recipe;


import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2540;
import net.minecraft.class_3956;
import net.minecraft.class_5455;
import net.minecraft.class_5699;
import net.minecraft.recipe.*;
import java.util.List;


public class KitchenSinkRecipe implements class_1860<class_1277> {
    final class_1799 output;
    final List<class_1856> recipeItems;

    public KitchenSinkRecipe(List<class_1856> recipeItems, class_1799 output) {
        this.output = output;
        this.recipeItems = recipeItems;
    }

    @Override
    public boolean matches(class_1277 inventory, class_1937 world) {
        if (world.method_8608()) {
            return false;
        }
        return recipeItems.get(0).method_8093(inventory.method_5438(0));
    }

    @Override
    public class_1799 craft(class_1277 inventory, class_5455 registryManager) {
        return output;
    }

    @Override
    public boolean method_8113(int width, int height) {
        return true;
    }

    @Override
    public class_1799 method_8110(class_5455 registryManager) {
        return output;
    }

    @Override
    public class_2371<class_1856> method_8117() {
        class_2371<class_1856> list = class_2371.method_37434(this.recipeItems.size());
        list.addAll(recipeItems);
        return list;
    }

    @Override
    public class_1865<?> method_8119() {
        return FurnitureRecipeType.Kitchen_Sink_SERIALIZER;
    }

    @Override
    public class_3956<?> method_17716() {
        return FurnitureRecipeType.Kitchen_Sink_TYPE;
    }

    public static class Serializer implements class_1865<KitchenSinkRecipe> {
        public static final Codec<KitchenSinkRecipe> CODEC = RecordCodecBuilder.create(in -> in.group(
                validateAmount(class_1856.field_46096, 9).fieldOf("ingredient").forGetter(KitchenSinkRecipe::method_8117),
                class_1799.field_47309.fieldOf("result").forGetter(r -> r.output)
        ).apply(in, KitchenSinkRecipe::new));

        private static Codec<List<class_1856>> validateAmount(Codec<class_1856> delegate, int max) {
            return class_5699.method_48112(class_5699.method_48112(
                    delegate.listOf(), list -> list.size() > max ? DataResult.error(() -> "Recipe has too many ingredients!") : DataResult.success(list)
            ), list -> list.isEmpty() ? DataResult.error(() -> "Recipe has no ingredients!") : DataResult.success(list));
        }

        @Override
        public Codec<KitchenSinkRecipe> method_53736() {
            return CODEC;
        }

        @Override
        public KitchenSinkRecipe method_8122(class_2540 buf) {
            class_2371<class_1856> inputs = class_2371.method_10213(buf.readInt(), class_1856.field_9017);

            for(int i = 0; i < inputs.size(); i++) {
                inputs.set(i, class_1856.method_8086(buf));
            }

            class_1799 output = buf.method_10819();
            return new KitchenSinkRecipe(inputs, output);
        }

        @Override
        public void write(class_2540 buf, KitchenSinkRecipe recipe) {
            buf.method_53002(recipe.method_8117().size());

            for (class_1856 ingredient : recipe.method_8117()) {
                ingredient.method_8088(buf);
            }

            buf.method_10793(recipe.method_8110(null));
        }
    }
}








