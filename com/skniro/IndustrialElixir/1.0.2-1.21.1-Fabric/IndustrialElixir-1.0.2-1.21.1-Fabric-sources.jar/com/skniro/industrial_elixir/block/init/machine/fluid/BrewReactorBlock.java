package com.skniro.industrial_elixir.block.init.machine.fluid;

import com.mojang.serialization.MapCodec;

import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.entity.machine.fluid.BrewReactorBlockEntity;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class BrewReactorBlock extends AbstractMachineblock {
    public static final class_2754<class_2350> FACING = class_2741.field_12481;
    public static final class_2746 LIT = class_2741.field_12548;
    public static final MapCodec<BrewReactorBlock> CODEC = method_54094(BrewReactorBlock::new);

    public BrewReactorBlock(class_2251 properties) {
        super(properties, EnergyTier.TIER1);
    }

    /* FACING */
    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(FACING, context.method_8042().method_10153()).method_11657(LIT, false);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, LIT);
    }

    /* BLOCK ENTITY */
    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 worldPosition, class_2680 blockState) {
        return new BrewReactorBlockEntity(worldPosition, blockState);
    }

    @Override
    public void method_9556(class_1937 level, class_1657 player, class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity, class_1799 destroyedWith) {
        if(level.method_8321(pos) instanceof BrewReactorBlockEntity crystallizerBlockEntity) {
            crystallizerBlockEntity.drops();
        }
        super.method_9556(level, player, pos, state, blockEntity, destroyedWith);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos,
                                               class_1657 player, class_3965 hitResult) {
        if(!level.method_8608()) {
            class_2586 entity = level.method_8321(pos);
            if(entity instanceof BrewReactorBlockEntity crystallizerBlockEntity) {
                player.method_17355(crystallizerBlockEntity);
            }
        }
        return class_1269.field_5812;
    }

    @Override
    public @Nullable <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 blockState,
                                                                            class_2591<T> type) {
        if(level.method_8608()) {
            return null;
        }

        return method_31618(type, AlchemyBlockEntityType.Brew_Reactor_BLOCK_ENTITY,
                (level1, pos, state, entity) -> entity.tick(level1, pos, state));
    }

    /* LIT */
    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        if (!state.method_11654(LIT)) {
            return;
        }

        double xPos = (double)pos.method_10263() + 0.5;
        double yPos = pos.method_10264();
        double zPos = (double)pos.method_10260() + 0.5;
        if (random.method_43058() < 0.15) {
            level.method_8486(xPos, yPos, zPos, class_3417.field_26980, class_3419.field_15245, 1.0f, 1.0f, false);
        }

        class_2350 direction = state.method_11654(FACING);
        class_2350.class_2351 axis = direction.method_10166();

        double defaultOffset = random.method_43058() * 0.6 - 0.3;
        double xOffsets = axis == class_2350.class_2351.field_11048 ? (double)direction.method_10148() * 0.52 : defaultOffset;
        double yOffset = random.method_43058() * 6.0 / 8.0;
        double zOffset = axis == class_2350.class_2351.field_11051 ? (double)direction.method_10165() * 0.52 : defaultOffset;

        level.method_8406(class_2398.field_11251, xPos + xOffsets, yPos + yOffset, zPos + zOffset, 0.0, 0.0, 0.0);

        if(level.method_8321(pos) instanceof BrewReactorBlockEntity crystallizerBlockEntity && !crystallizerBlockEntity.inventory.get(1).method_7960()) {
            level.method_8406(new class_2392(class_2398.field_11218, crystallizerBlockEntity.inventory.get(1)),
                    xPos + xOffsets, yPos + yOffset, zPos + zOffset, 0.0, 0.0, 0.0);
        }
    }
}