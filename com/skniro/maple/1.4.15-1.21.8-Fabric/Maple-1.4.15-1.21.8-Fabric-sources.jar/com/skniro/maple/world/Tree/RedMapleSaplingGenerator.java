package com.skniro.maple.world.Tree;

import com.skniro.maple.world.feature.MapleConfiguredFeatures;
import java.util.Optional;
import net.minecraft.class_8813;

public class RedMapleSaplingGenerator {
    public static final class_8813 RedMapleSapling =
            new class_8813("redmapletreesapling", 0f, Optional.empty(),
                    Optional.empty(),
                    Optional.of(MapleConfiguredFeatures.Red_Maple_TREE),
                    Optional.empty(),
                    Optional.empty(),
                    Optional.empty());
    }