package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public abstract class AbstractLampBlock extends class_2248 {
    public static final class_2746 LIT;

    public AbstractLampBlock(class_2251 settings) {
        super(settings);
        this.method_9590((class_2680)this.method_9564().method_11657(LIT, false));
    }

    @Override
    @Nullable
    public class_2680 method_9605(class_1750 ctx) {
        return (class_2680)this.method_9564().method_11657(LIT, ctx.method_8045().method_49803(ctx.method_8037()));
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!world.field_9236) {
            boolean lit = state.method_11654(LIT);
            world.method_8652(pos, state.method_11657(LIT, !lit), 2);
        }
        return class_1269.field_5812;
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if ((Boolean)state.method_11654(LIT) && !world.method_49803(pos)) {
            world.method_8652(pos, (class_2680)state.method_28493(LIT), 2);
        }

    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{LIT});
    }

    static {
        LIT = class_2741.field_12548;
    }
}