package com.skniro.industrial_elixir.networking.packet;

import com.skniro.industrial_elixir.IndustrialElixir;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ToggleHoverC2SPayload() implements class_8710 {

    public static final class_2960 ID = class_2960.method_60655(IndustrialElixir.MOD_ID, "toggle_hover");
    public static final class_9154<ToggleHoverC2SPayload> TYPE = new class_9154<>(ID);
    public static final class_9139<class_9129, ToggleHoverC2SPayload> CODEC =
            class_9139.method_56431(new ToggleHoverC2SPayload());

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
