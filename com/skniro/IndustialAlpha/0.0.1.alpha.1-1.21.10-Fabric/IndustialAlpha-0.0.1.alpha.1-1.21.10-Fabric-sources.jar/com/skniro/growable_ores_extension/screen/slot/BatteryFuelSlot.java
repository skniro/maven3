package com.skniro.growable_ores_extension.screen.slot;

import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class BatteryFuelSlot extends class_1735 {

    public BatteryFuelSlot(class_1263 inventory, int index, int x, int y) {
        super(inventory, index, x, y);
    }

    public boolean method_7680(class_1799 stack) {
        return stack.method_31573(ModItemTags.BATTERY);
    }

    public int method_7676(class_1799 stack) {
        return isBucket(stack) ? 1 : super.method_7676(stack);
    }

    public static boolean isBucket(class_1799 stack) {
        return stack.method_31574(class_1802.field_8550);
    }
}
