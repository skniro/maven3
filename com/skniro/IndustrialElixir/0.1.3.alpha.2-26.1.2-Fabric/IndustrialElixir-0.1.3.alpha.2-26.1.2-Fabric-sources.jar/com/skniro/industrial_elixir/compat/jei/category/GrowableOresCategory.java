package com.skniro.industrial_elixir.compat.jei.category;

import com.skniro.industrial_elixir.api.Helper;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipe;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.recipe.types.IRecipeHolderType;
import mezz.jei.api.recipe.types.IRecipeType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;

public class GrowableOresCategory implements IRecipeCategory<RecipeHolder<AlchemyCraftingRecipe>> {

    public static final IRecipeHolderType<AlchemyCraftingRecipe> TYPE =
            IRecipeHolderType.create(AlchemyRecipeType.CANE_CONVERTER.type);

    private final IDrawable background;
    private final IDrawable icon;
    private final IDrawable energyBar;

    public GrowableOresCategory(IGuiHelper helper) {
        Identifier texture = Helper.id("textures/gui/container/cane_converter.png");

        background = helper.createDrawable(texture, 0, 0, 175, 82);

        icon = helper.createDrawableIngredient(VanillaTypes.ITEM_STACK,
                new ItemStack(GrowableOresBlocks.GrowableOres_Block));

        energyBar = helper.createDrawable(texture, 176, 0, 14, 14);
    }

    @Override
    public IRecipeType<RecipeHolder<AlchemyCraftingRecipe>> getRecipeType() {
        return TYPE;
    }

    @Override
    public Component getTitle() {
        return Component.translatable(FurnitureStrings.CaneConverter);
    }

    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public int getWidth() {
        return background.getWidth();
    }

    @Override
    public int getHeight() {
        return background.getHeight();
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, RecipeHolder<AlchemyCraftingRecipe> recipe, IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 52, 34)
                .add(recipe.value().ingredient());

        builder.addSlot(RecipeIngredientRole.OUTPUT, 100, 34)
                .add(recipe.value().output());
    }

    @Override
    public void draw(RecipeHolder<AlchemyCraftingRecipe> recipe, IRecipeSlotsView slots, GuiGraphicsExtractor guiGraphics, double mouseX, double mouseY) {
        background.draw(guiGraphics);

        energyBar.draw(guiGraphics, 15, 36);

        long ticks = System.currentTimeMillis() / 50;
        int totalTicks = 72;
        int arrowWidth = 28;
        int currentTick = (int)(ticks % totalTicks);
        int progress = currentTick * arrowWidth / totalTicks;

        guiGraphics.blit(Helper.id( "textures/gui/container/cane_converter.png"),
                73, 34, 176, 13, progress, 14, 256, 256);
    }
}