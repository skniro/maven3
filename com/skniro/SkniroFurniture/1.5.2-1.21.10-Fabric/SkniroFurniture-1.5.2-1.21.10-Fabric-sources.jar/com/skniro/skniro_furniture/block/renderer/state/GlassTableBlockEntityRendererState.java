package com.skniro.skniro_furniture.block.renderer.state;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10444;
import net.minecraft.class_11954;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import java.util.Collections;
import java.util.List;

@Environment(EnvType.CLIENT)
public class GlassTableBlockEntityRendererState extends class_11954 {
    public List<class_10444> triplecabinetItemStates = Collections.emptyList();
    public List<class_10444> fourgridcabinetItemStates = Collections.emptyList();
    public class_2371<class_1799> stack;
    public class_1937 world;
}