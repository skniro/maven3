package com.skniro.growable_ores_extension.item;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.item.init.QuantumArmorItem;
import com.skniro.growable_ores_extension.item.init.QuantumSuitItem;
import com.skniro.growable_ores_extension.item.init.equipment.MapleArmorMaterials;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.function.Function;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8051;

public class MapleArmorItems {
/*
    //Tool
    public static final Item Cherry_SWORD = registerItem("cherry_sword", Item::new, new Item.Settings().sword(MapleToolMaterials.Cherry,  3, -2.4F));
    public static final Item Cherry_SHOVEL = registerItem("cherry_shovel", (settings)->  new ShovelItem(MapleToolMaterials.Cherry,2, -3.0F, settings), new Item.Settings());
    public static final Item Cherry_PICKAXE = registerItem("cherry_pickaxe", Item::new, new Item.Settings().pickaxe(MapleToolMaterials.Cherry,1, -2.8F));
    public static final Item Cherry_AXE = registerItem("cherry_axe", (settings)->  new AxeItem(MapleToolMaterials.Cherry,5, -3.0F, settings), new Item.Settings());
    public static final Item Cherry_HOE = registerItem("cherry_hoe", (settings)->  new HoeItem(MapleToolMaterials.Cherry,-3, 0.0F, settings), new Item.Settings());
*/

    //Armor
    public static final class_1792 Quantum_HELMET = registerItem("quantum_helmet", (settings)-> new QuantumSuitItem(settings, MapleArmorMaterials.QUANTUM, class_8051.field_41934, EnergyTier.TIER5), new class_1792.class_1793());
    public static final class_1792 Quantum_CHESTPLATE = registerItem("quantum_chestplate", (settings)-> new QuantumSuitItem(settings, MapleArmorMaterials.QUANTUM, class_8051.field_41935, EnergyTier.TIER5), new class_1792.class_1793());
    public static final class_1792 Quantum_LEGGINGS = registerItem("quantum_leggings", (settings)-> new QuantumSuitItem(settings, MapleArmorMaterials.QUANTUM, class_8051.field_41936, EnergyTier.TIER5), new class_1792.class_1793());
    public static final class_1792 Quantum_BOOTS = registerItem("quantum_boots", (settings)-> new QuantumSuitItem(settings, MapleArmorMaterials.QUANTUM, class_8051.field_41937, EnergyTier.TIER5), new class_1792.class_1793());

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings.method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name))));
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)), item);
    }

    public static void registerMapleArmorItems() {
        GrowableOresExtension.LOGGER.info("Registering Maple armor items for " + GrowableOresExtension.MOD_ID);
    }
}
