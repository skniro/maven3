package com.skniro.growable_ores_extension.compat;

import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.entity.machine.MetalFormerBlockEntity;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.machine.*;
import com.skniro.growable_ores_extension.compat.category.*;
import com.skniro.growable_ores_extension.compat.display.*;
import com.skniro.growable_ores_extension.recipe.AlchemyCraftingRecipe;
import com.skniro.growable_ores_extension.recipe.machine.*;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.plugins.REIClientPlugin;
import me.shedaniel.rei.api.client.registry.category.CategoryRegistry;
import me.shedaniel.rei.api.client.registry.display.DisplayRegistry;
import me.shedaniel.rei.api.client.registry.screen.ScreenRegistry;
import me.shedaniel.rei.api.client.view.ViewSearchBuilder;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.util.EntryStacks;

public class IndustrialModREIClient implements REIClientPlugin {

    @Override
    public String getPluginProviderName() {
        return "IndustrialAlphaClient";
    }

    @Override
    public void registerCategories(CategoryRegistry registry) {
        registry.add(new MaceratorCategory());
        registry.add(new CompressorCategory());
        registry.add(new MetalFormerRollingCategory());
        registry.add(new MetalFormerCuttingCategory());
        registry.add(new MetalFormerExtrudingCategory());
        registry.add(new MolecularTransformerCategory());
        registry.add(new ExtractorCategory());
        registry.add(new GrowableOresCategory());
        registry.addWorkstations(MaceratorCategory.MACERATOR, EntryStacks.of(GrowableOresBlocks.Macerator_Block));
        registry.addWorkstations(CompressorCategory.Compressor, EntryStacks.of(GrowableOresBlocks.Compressor_Block));
        registry.addWorkstations(MetalFormerRollingCategory.MetalFormerRolling, EntryStacks.of(GrowableOresBlocks.MetalFormerBlock));
        registry.addWorkstations(MetalFormerCuttingCategory.MetalFormerCutting, EntryStacks.of(GrowableOresBlocks.MetalFormerBlock));
        registry.addWorkstations(MetalFormerExtrudingCategory.MetalFormerExtruding, EntryStacks.of(GrowableOresBlocks.MetalFormerBlock));
        registry.addWorkstations(ExtractorCategory.Extractor, EntryStacks.of(GrowableOresBlocks.Extractor_Block));
        registry.addWorkstations(MolecularTransformerCategory.MolecularTransformer, EntryStacks.of(GrowableOresBlocks.MolecularTransformerBlock));
        registry.addWorkstations(GrowableOresCategory.GrowableOres, EntryStacks.of(GrowableOresBlocks.GrowableOres_Block));
    }

    @Override
    public void registerDisplays(DisplayRegistry registry) {
        registry.beginFiller(MaceratorCraftingRecipe.class)
                .fill(MaceratorDisplay::new);
        registry.beginFiller(CompressorCraftingRecipe.class)
                .fill(CompressorDisplay::new);
        registry.beginFiller(MetalFormerExtrudingCraftingRecipe.class)
                .fill(MetalFormerExtrudingDisplay::new);
        registry.beginFiller(MetalFormerRollingCraftingRecipe.class)
                .fill(MetalFormerRollingDisplay::new);
        registry.beginFiller(MetalFormerCuttingCraftingRecipe.class)
                .fill(MetalFormerCuttingDisplay::new);
        registry.beginFiller(MolecularTransformerCraftingRecipe.class)
                .fill(MolecularTransformerDisplay::new);
        registry.beginFiller(ExtractorCraftingRecipe.class)
                .fill(ExtractorDisplay::new);
        registry.beginFiller(AlchemyCraftingRecipe.class)
                .fill(GrowableOresDisplay::new);
    }

    @Override
    public void registerScreens(ScreenRegistry registry) {
        registry.registerClickArea(screen -> new Rectangle(((screen.field_22789 - 176) / 2) + 78,
                ((screen.field_22790 - 166) / 2) + 30, 20, 25), MaceratorBlockScreen.class,
                MaceratorCategory.MACERATOR);

        registry.registerClickArea(screen -> new Rectangle(((screen.field_22789 - 176) / 2) + 78,
                        ((screen.field_22790 - 166) / 2) + 30, 20, 25), CompressorBlockScreen.class,
                CompressorCategory.Compressor);

        registry.registerClickArea(screen -> new Rectangle(((screen.field_22789 - 176) / 2) + 78,
                        ((screen.field_22790 - 166) / 2) + 30, 20, 25), MetalFormerBlockScreen.class,
                MetalFormerRollingCategory.MetalFormerRolling);

        registry.registerClickArea(screen -> new Rectangle(((screen.field_22789 - 176) / 2) + 78,
                        ((screen.field_22790 - 166) / 2) + 30, 20, 25), MetalFormerBlockScreen.class,
                MetalFormerCuttingCategory.MetalFormerCutting);

        registry.registerClickArea(screen -> new Rectangle(((screen.field_22789 - 176) / 2) + 78,
                        ((screen.field_22790 - 166) / 2) + 30, 20, 25), MetalFormerBlockScreen.class,
                MetalFormerExtrudingCategory.MetalFormerExtruding);

        registry.registerClickArea(screen -> new Rectangle(((screen.field_22789 - 176) / 2) + 78,
                        ((screen.field_22790 - 166) / 2) + 30, 20, 25), MolecularTransformerBlockScreen.class,
                MolecularTransformerCategory.MolecularTransformer);

        registry.registerClickArea(screen -> new Rectangle(((screen.field_22789 - 176) / 2) + 78,
                        ((screen.field_22790 - 166) / 2) + 30, 20, 25), ExtractorBlockScreen.class,
                ExtractorCategory.Extractor);

        registry.registerClickArea(screen -> new Rectangle(((screen.field_22789 - 176) / 2) + 78,
                        ((screen.field_22790 - 166) / 2) + 30, 20, 25), AlchemyBlockScreen.class,
                GrowableOresCategory.GrowableOres);
    }
}