package com.skniro.nether_ores_reborn.datagen;

import com.skniro.nether_ores_reborn.block.NetherOresBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

import static net.minecraft.class_3481.*;


public class ModBlockTagGeneration extends FabricTagProvider.BlockTagProvider {
    public ModBlockTagGeneration(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(dataGenerator, completableFuture);
    }


    public static class ModBlockTags {
        public static final class_6862<class_2248> C_SAPLING = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "saplings"));
        public static final class_6862<class_2248> C_MAPLE_LOGS = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "maple_logs"));
        public static final class_6862<class_2248> C_CHERRY_LOGS = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "cherry_logs"));
        public static final class_6862<class_2248> C_PLASTER = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "plaster"));

    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        method_10512(field_33715)
                .add(NetherOresBlocks.Nether_Diamond_Ore)
                .add(NetherOresBlocks.Nether_Gold_Ore)
                .add(NetherOresBlocks.Nether_Redstone_Ore)
                .add(NetherOresBlocks.Nether_Emerald_Ore)
                .add(NetherOresBlocks.Nether_Coal_Ore)
                .add(NetherOresBlocks.Nether_Iron_Ore)
                .add(NetherOresBlocks.Nether_Copper_Ore)
                .add(NetherOresBlocks.Nether_Lapis_Ore)
                .add(NetherOresBlocks.End_Diamond_Ore)
                .add(NetherOresBlocks.End_Gold_Ore)
                .add(NetherOresBlocks.End_Redstone_Ore)
                .add(NetherOresBlocks.End_Emerald_Ore)
                .add(NetherOresBlocks.End_Coal_Ore)
                .add(NetherOresBlocks.End_Iron_Ore)
                .add(NetherOresBlocks.End_Copper_Ore)
                .add(NetherOresBlocks.End_Lapis_Ore)
                .setReplace(false);
        method_10512(field_33718)
                .add(NetherOresBlocks.Nether_Diamond_Ore)
                .add(NetherOresBlocks.Nether_Gold_Ore)
                .add(NetherOresBlocks.Nether_Redstone_Ore)
                .add(NetherOresBlocks.Nether_Emerald_Ore)
                .add(NetherOresBlocks.End_Diamond_Ore)
                .add(NetherOresBlocks.End_Gold_Ore)
                .add(NetherOresBlocks.End_Redstone_Ore)
                .add(NetherOresBlocks.End_Emerald_Ore)
                .setReplace(false);
        method_10512(field_33719)
                .add(NetherOresBlocks.Nether_Iron_Ore)
                .add(NetherOresBlocks.Nether_Copper_Ore)
                .add(NetherOresBlocks.Nether_Lapis_Ore)
                .add(NetherOresBlocks.End_Iron_Ore)
                .add(NetherOresBlocks.End_Copper_Ore)
                .add(NetherOresBlocks.End_Lapis_Ore)
                .setReplace(false);

    }
}
