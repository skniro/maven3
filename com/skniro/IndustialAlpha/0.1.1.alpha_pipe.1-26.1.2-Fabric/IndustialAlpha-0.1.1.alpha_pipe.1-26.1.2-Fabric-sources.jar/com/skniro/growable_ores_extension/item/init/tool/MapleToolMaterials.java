package com.skniro.growable_ores_extension.item.init.tool;


import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.ToolMaterial;

public class MapleToolMaterials {
    public static final ToolMaterial BRONZE = new ToolMaterial(BlockTags.INCORRECT_FOR_IRON_TOOL, 340, 6.0F, 2.0F, 14, ModItemTags.BRONZE_TOOL_MATERIALS);
}
