package com.skniro.industrial_elixir.world.gamerules;

import com.skniro.industrial_elixir.IndustrialElixir;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.minecraft.class_1928;


public class MapleGameRules {
    public static final class_1928.class_4313<class_1928.class_4310> HOT_SPRING_SOURCE_CONVERSION =
            GameRuleRegistry.register("hotSpringSourceConversion", class_1928.class_5198.field_24098, GameRuleFactory.createBooleanRule(true));

    public static void maplegamerule() {
        IndustrialElixir.LOGGER.debug("Registering IndustrialElixir Game Rules for " + IndustrialElixir.MOD_ID);
    }
}
