package com.skniro.chunk_loader.datagen;

import com.skniro.chunk_loader.block.GrowableOresBlocks;
import com.skniro.chunk_loader.init.FurnitureStrings;
import com.skniro.chunk_loader.item.*;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.core.HolderLookup;
import java.util.concurrent.CompletableFuture;

public class ChunkLoaderSimplifiedChineseLanguageProvider extends FabricLanguageProvider {
    public ChunkLoaderSimplifiedChineseLanguageProvider(FabricPackOutput dataGenerator, CompletableFuture<HolderLookup.Provider> registryLookup){
        super(dataGenerator,"zh_cn", registryLookup);
    }

    @Override
    public void generateTranslations(HolderLookup.Provider registryLookup, TranslationBuilder translationBuilder){
        translationBuilder.add(FurnitureStrings.ChunkLoader, "区块加载器");
        translationBuilder.add(GrowableOresBlocks.CHUNK_LOADER, "区块加载器");
        translationBuilder.add(ModCreativeTab.Machine, "机器");
    }
}
