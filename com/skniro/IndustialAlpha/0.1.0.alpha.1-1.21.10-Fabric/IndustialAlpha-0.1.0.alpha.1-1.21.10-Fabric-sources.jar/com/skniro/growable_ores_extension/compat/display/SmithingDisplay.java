package com.skniro.growable_ores_extension.compat.display;

import com.mojang.serialization.Codec;
import io.netty.buffer.ByteBuf;
import java.util.function.IntFunction;
import java.util.function.ToIntFunction;

import me.shedaniel.rei.api.common.display.Display;
import net.minecraft.class_6880;
import net.minecraft.class_7995;
import net.minecraft.class_7995.class_7996;
import net.minecraft.class_8056;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.ApiStatus.Experimental;

public interface SmithingDisplay extends Display {
    @Nullable SmithingRecipeType type();

    @Experimental
    public static enum SmithingRecipeType {
        TRIM,
        TRANSFORM;

        public static final Codec<SmithingRecipeType> CODEC = Codec.STRING.xmap(SmithingRecipeType::valueOf, Enum::name);
        public static final IntFunction<SmithingRecipeType> BY_ID = class_7995.method_47914((ToIntFunction<SmithingRecipeType>) Enum::ordinal, values(), class_7996.field_41664);
        public static final class_9139<ByteBuf, SmithingRecipeType> STREAM_CODEC = class_9135.method_56375(BY_ID, Enum::ordinal);
    }

    public interface Trimming {
        class_6880<class_8056> pattern();
    }
}