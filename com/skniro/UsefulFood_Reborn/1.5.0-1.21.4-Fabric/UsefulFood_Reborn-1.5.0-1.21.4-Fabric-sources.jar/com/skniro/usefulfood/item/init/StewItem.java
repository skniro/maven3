package com.skniro.usefulfood.item.init;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;

public class StewItem extends class_1792 {
    public StewItem(class_1793 settings) {
        super(settings);
    }

    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        class_1799 itemStack = super.method_7861(stack, world, user);
        if (user instanceof class_1657 playerEntity) {
            if (playerEntity.method_56992()) {
                return itemStack;
            }
        }

        return new class_1799(class_1802.field_8428);
    }
}

