package com.skniro.blackhold.datagen;

import com.google.common.collect.Lists;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_156;
import net.minecraft.class_1935;
import net.minecraft.class_2446;
import net.minecraft.class_7225;
import net.minecraft.class_8790;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class MapleRecipeGeneration extends FabricRecipeProvider {
    public MapleRecipeGeneration(FabricDataOutput generator, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(generator, registryLookup);
    }


    public static final List<class_1935> STRIPPED_MAPLE = class_156.method_654(Lists.newArrayList(), list -> {
    });
    public static final List<class_1935> Green_Tea = class_156.method_654(Lists.newArrayList(), list -> {
    });

    @Override
    protected class_2446 method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new class_2446(wrapperLookup, exporter) {
            @Override
            public void method_10419() {

            }
        };
    }

    @Override
    public String method_10321() {
        return "";
    }
}