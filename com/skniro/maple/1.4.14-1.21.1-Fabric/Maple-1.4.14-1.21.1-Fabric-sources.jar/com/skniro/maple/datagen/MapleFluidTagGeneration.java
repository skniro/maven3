package com.skniro.maple.datagen;

import com.skniro.maple.Maple;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

public class MapleFluidTagGeneration extends FabricTagProvider<class_3611> {

    public MapleFluidTagGeneration(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, class_7924.field_41270, registriesFuture);
    }


    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        // minecraft:fluid/water -> include mod hot spring fluids
        class_6862<class_3611> minecraftWater = class_6862.method_40092(class_7924.field_41270, class_2960.method_60655("minecraft", "water"));
        method_10512(minecraftWater)
                .method_46835(class_5321.method_29179(class_7924.field_41270, class_2960.method_60655(Maple.MOD_ID, "hot_spring")))
                .method_46835(class_5321.method_29179(class_7924.field_41270, class_2960.method_60655(Maple.MOD_ID, "flowing_hot_spring_water")))
                .setReplace(false);
    }
}

