package com.skniro.usefulfood.util;

import com.skniro.usefulfood.item.UsefulFoodItems;
import net.fabricmc.fabric.api.loot.v1.event.LootTableLoadingCallback;
import net.minecraft.class_141;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_61;
import net.minecraft.class_77;

public class ModLootTableModifiers {
    private static final class_2960 squid_entities_ID
            = new class_2960("minecraft", "entities/squid");
    private static final class_2960 glow_squid_entities_ID
            = new class_2960("minecraft", "entities/glow_squid");


    public static void modifyLootTables() {
        LootTableLoadingCallback.EVENT.register((resourceManager, lootManager, id, tableBuilder, source) -> {
            if(squid_entities_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_289(1))
                        .method_356(class_219.method_932(1f)) // Drops 100% of the time
                        .method_351(class_77.method_411(UsefulFoodItems.SquidTentacleRaw))
                        .method_353(class_141.method_621(class_61.method_377(1.0f, 1.0f)));
                tableBuilder.method_336(poolBuilder);
            }
                if(glow_squid_entities_ID.equals(id)) {
                    class_55.class_56 poolBuilder = class_55.method_347()
                            .method_352(class_44.method_289(1))
                            .method_356(class_219.method_932(1f)) // Drops 100% of the time
                            .method_351(class_77.method_411(UsefulFoodItems.SquidTentacleRaw))
                            .method_353(class_141.method_621(class_61.method_377(1.0f, 1.0f)));
                    tableBuilder.method_336(poolBuilder);
                }
        });
    }
}