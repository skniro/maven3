package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import com.skniro.skniro_furniture.block.entity.DrawerBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3468;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;


public class KitchenCounterDrawerBlock extends class_2237 {
    public static final MapCodec<com.skniro.skniro_furniture.block.init.KitchenCounterDrawerBlock> CODEC = method_54094(com.skniro.skniro_furniture.block.init.KitchenCounterDrawerBlock::new);
    public static final class_2754<class_2350> FACING;

    public MapCodec<com.skniro.skniro_furniture.block.init.KitchenCounterDrawerBlock> method_53969() {
        return field_46280;
    }

    public KitchenCounterDrawerBlock(class_4970.class_2251 settings) {
        super(settings);
        this.method_9590((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043)));
    }

    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world instanceof class_3218 serverWorld) {
            class_2586 var8 = world.method_8321(pos);
            if (var8 instanceof DrawerBlockEntity KitchenCounterDrawerBlockEntity) {
                player.method_17355(KitchenCounterDrawerBlockEntity);
                player.method_7281(class_3468.field_17271);
            }
        }

        return class_1269.field_5812;
    }

    public void method_66388(class_2680 state, class_3218 world, class_2338 pos, boolean moved) {
        class_1264.method_66221(state, world, pos);
        super.method_66388(state, world, pos, moved);
    }

    protected void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof DrawerBlockEntity) {
            ((DrawerBlockEntity)blockEntity).tick();
        }

    }

    @Nullable
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new DrawerBlockEntity(pos, state);
    }

    protected boolean method_9498(class_2680 state) {
        return true;
    }

    protected int getComparatorOutput(class_2680 state, class_1937 world, class_2338 pos) {
        return class_1703.method_7608(world.method_8321(pos));
    }

    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return (class_2680)state.method_11657(FACING, rotation.method_10503((class_2350)state.method_11654(FACING)));
    }

    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345((class_2350)state.method_11654(FACING)));
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    static {
        FACING = class_2741.field_12481;
    }
}
