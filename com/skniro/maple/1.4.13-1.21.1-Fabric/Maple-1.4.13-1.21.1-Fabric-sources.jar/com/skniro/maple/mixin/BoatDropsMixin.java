package com.skniro.maple.mixin;

import com.skniro.maple.entity.MapleBoatType;
import com.skniro.maple.item.MapleItems;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

//CREDIT TO nyuppo/fabric-boat-example ON GITHUB

@Mixin(class_1690.class)
public class BoatDropsMixin {
    @Inject(method = "asItem", at = @At("HEAD"), cancellable = true)
    public void asItem(CallbackInfoReturnable<class_1792> ci) {
        if (((class_1690)(Object)this).method_47885() == class_1690.class_1692.field_42681) {
            ci.setReturnValue(MapleItems.CHERRY_BOAT);
        }else if (((class_1690)(Object)this).method_47885() == class_1690.class_1692.field_40161) {
            ci.setReturnValue(MapleItems.BAMBOO_BOAT);
        }else if (((class_1690)(Object)this).method_47885() == MapleBoatType.MAPLE) {
            ci.setReturnValue(MapleItems.MAPLE_BOAT);
        }else if (((class_1690)(Object)this).method_47885() == MapleBoatType.GINKGO) {
            ci.setReturnValue(MapleItems.GINKGO_BOAT);
        }
    }

/*    @Inject(method = "getMountedHeightOffset",at =@At("HEAD"),cancellable = true)
    public void MountedHeightOffset(CallbackInfoReturnable<Double> cir){
        cir.setReturnValue(((BoatEntity)(Object)this).getVariant() == BoatEntity.Type.BAMBOO ? 0.25D : -0.1D);
    }*/
}
