package com.skniro.industrial_elixir.screen.ingame.generator;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.screen.handler.generator.NuclearReactorScreenHandler;
import com.skniro.industrial_elixir.util.MouseUtil;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.util.List;
import java.util.Optional;

public class NuclearReactorScreen extends class_465<NuclearReactorScreenHandler> {
    private static final class_2960 TEXTURE =
            class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/generator/guinuclearreactor.png");
    private static final int HEAT_BAR_X = 8;
    private static final int STATUS_BAR_Y = 96;
    private static final int OUTPUT_BAR_X = 68;
    public NuclearReactorScreen(NuclearReactorScreenHandler menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
        this.field_2792 = 211;
        this.field_2779 = 242;
        this.field_25270 = 98;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
        field_25268 = 5;
    }

    @Override
    protected void method_2388(class_332 graphics, int mouseX, int mouseY) {
        graphics.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, -12566464, false);
        graphics.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, -12566464, false);

        int localX = mouseX - field_2776;
        int localY = mouseY - field_2800;
        if (MouseUtil.isMouseOver(mouseX, mouseY, field_2776 + HEAT_BAR_X, field_2800 + STATUS_BAR_Y, 54, 8)) {
            graphics.method_51437(Screens.getTextRenderer(this),
                    List.of(class_2561.method_43470("Heat: " + field_2797.getHeat() + " / " + field_2797.getMaxHeat())),
                    Optional.empty(), localX, localY);
        }
        if (MouseUtil.isMouseOver(mouseX, mouseY, field_2776 + OUTPUT_BAR_X, field_2800 + STATUS_BAR_Y, 106, 8)) {
            graphics.method_51437(Screens.getTextRenderer(this),
                    List.of(class_2561.method_43470("Output: " + field_2797.getGeneration() + " E/t")),
                    Optional.empty(), localX, localY);
        }
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTicks, int mouseX, int mouseY) {
        graphics.method_25290(TEXTURE, field_2776, field_2800, 0, 0, field_2792, field_2779, 256, 256);

        int heatWidth = field_2797.getScaledHeatWidth();
        if (heatWidth > 0) {
            graphics.method_25290(TEXTURE, field_2776 + HEAT_BAR_X, field_2800 + STATUS_BAR_Y, 176, 0, heatWidth, 8, 256, 256);
        }

        int outputWidth = Math.min(106, field_2797.getGeneration() * 106 / 420);
        if (outputWidth > 0) {
            graphics.method_25290(TEXTURE, field_2776 + OUTPUT_BAR_X, field_2800 + STATUS_BAR_Y, 176, 8, outputWidth, 8, 256, 256);
        }
    }
}
