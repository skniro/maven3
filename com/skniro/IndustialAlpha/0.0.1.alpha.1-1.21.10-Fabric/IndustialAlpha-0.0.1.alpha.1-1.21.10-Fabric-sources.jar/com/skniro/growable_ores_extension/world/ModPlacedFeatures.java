package com.skniro.growable_ores_extension.world;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5843;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;
import net.minecraft.world.gen.placementmodifier.*;

import java.util.List;

public class ModPlacedFeatures {
    public static final class_5321<class_6796> Deepslate_Lead_Ore_PLACED_KEY = registerKey("deepslate_lead_ore_placed");
    public static final class_5321<class_6796> Deepslate_Tin_Ore_PLACED_KEY = registerKey("deepslate_tin_ore_placed");
    public static final class_5321<class_6796> Deepslate_Uranium_Ore_PLACED_KEY = registerKey("deepslate_uranium_ore_placed");
    public static final class_5321<class_6796> Lead_Ore_PLACED_KEY = registerKey("lead_ore_placed");
    public static final class_5321<class_6796> Tin_Ore_PLACED_KEY = registerKey("tin_ore_placed");
    public static final class_5321<class_6796> Uranium_Ore_PLACED_KEY = registerKey("uranium_ore_placed");

    public static void bootstrap(class_7891<class_6796> context) {
        var configuredFeatureRegistryEntryLookup = context.method_46799(class_7924.field_41239);

        register(context, Deepslate_Lead_Ore_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Deepslate_Lead_Ore_KEY),
                modifiersWithCount(20, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context,Deepslate_Tin_Ore_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Deepslate_Tin_Ore_KEY),
                modifiersWithCount(16, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Deepslate_Uranium_Ore_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Deepslate_Uranium_Ore_KEY),
                modifiersWithCount(8, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Lead_Ore_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Lead_Ore_KEY),
                modifiersWithCount(20, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context,Tin_Ore_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Tin_Ore_KEY),
                modifiersWithCount(16, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Uranium_Ore_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Uranium_Ore_KEY),
                modifiersWithCount(8, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

    }

    public static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(GrowableOresExtension.MOD_ID, name));
    }
    private static void register(class_7891<class_6796> context, class_5321<class_6796> key, class_6880<class_2975<?, ?>> configuration,
                                 List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(configuration, List.copyOf(modifiers)));
    }
    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_6796> context, class_5321<class_6796> key,
                                                                                   class_6880<class_2975<?, ?>> configuration,
                                                                                   class_6797... modifiers) {
        register(context, key, configuration, List.of(modifiers));
    }

    // Used here because the vanilla ones are private
    private static List<class_6797> modifiers(class_6797 countModifier, class_6797 heightModifier) {
        return List.of(countModifier, class_5450.method_39639(), heightModifier, class_6792.method_39614());
    }

    private static List<class_6797> modifiersWithCount(int count, class_6797 heightModifier) {
        return modifiers(class_6793.method_39623(count), heightModifier);
    }

    private static List<class_6797> modifiersWithRarity(int chance, class_6797 heightModifier) {
        return modifiers(class_6799.method_39659(chance), heightModifier);
    }
}
