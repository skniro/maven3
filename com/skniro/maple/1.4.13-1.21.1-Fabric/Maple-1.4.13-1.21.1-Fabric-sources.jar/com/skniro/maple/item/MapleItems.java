package com.skniro.maple.item;

import com.skniro.maple.Maple;
import com.skniro.maple.block.MapleSignBlocks;
import com.skniro.maple.block.MapleBlocks;
import com.skniro.maple.entity.MapleBoatType;
import com.skniro.maple.item.init.snowball.*;
import net.minecraft.class_1690;
import net.minecraft.class_1749;
import net.minecraft.class_1765;
import net.minecraft.class_1792;
import net.minecraft.class_1798;
import net.minecraft.class_1822;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7707;
import net.minecraft.class_7923;
import net.minecraft.item.*;
public class MapleItems {
    public static final class_1792 CHERRY_SIGN = registerItem("cherry_sign",
            new class_1822(new class_1792.class_1793().method_7889(16),
                    MapleSignBlocks.CHERRY_SIGN, MapleSignBlocks.CHERRY_WALL_SIGN));
    public static final class_1792 MAPLE_SIGN = registerItem("maple_sign",
            new class_1822(new class_1792.class_1793().method_7889(16),
                    MapleSignBlocks.Maple_SIGN,MapleSignBlocks.Maple_WALL_SIGN));
    public static final class_1792 BAMBOO_SIGN = registerItem("bamboo_sign",
            new class_1822(new class_1792.class_1793().method_7889(16),
                    MapleSignBlocks.BAMBOO_SIGN,MapleSignBlocks.BAMBOO_WALL_SIGN));
    public static final class_1792 GINKGO_SIGN = registerItem("ginkgo_sign",
            new class_1822(new class_1792.class_1793().method_7889(16),
                    MapleSignBlocks.GINKGO_SIGN, MapleSignBlocks.GINKGO_WALL_SIGN));

    public static final class_1792 GINKGO_HANGING_SIGN = registerItem("ginkgo_hanging_sign", new class_7707(
            MapleSignBlocks.GINKGO_HANGING_SIGN, MapleSignBlocks.GINKGO_WALL_HANGING_SIGN, new class_1792.class_1793().method_7889(16)));
    public static final class_1792 Maple_HANGING_SIGN = registerItem("maple_hanging_sign", new class_7707(
            MapleSignBlocks.Maple_HANGING_SIGN, MapleSignBlocks.Maple_WALL_HANGING_SIGN, new class_1792.class_1793().method_7889(16)));

    public static final class_1792 CHERRY_DOOR = registerItem("cherry_door",new class_1765(MapleBlocks.CHERRY_DOOR, new class_1792.class_1793().method_7889(16)));
    public static final class_1792 MAPLE_DOOR = registerItem("maple_door",new class_1765(MapleBlocks.MAPLE_DOOR, new class_1792.class_1793().method_7889(16)));
    public static final class_1792 BAMBOO_DOOR = registerItem("bamboo_door",new class_1765(MapleBlocks.BAMBOO_DOOR, new class_1792.class_1793().method_7889(16)));
    public static final class_1792 GINKGO_DOOR = registerItem("ginkgo_door",new class_1765(MapleBlocks.GINKGO_DOOR, new class_1792.class_1793().method_7889(16)));
    //Food Materials
    public static final class_1792 Flour = registerItem("flour",new class_1792(new class_1792.class_1793()));
    public static final class_1792 MapleSyrup = registerItem("maple_syrup",new class_1792(new class_1792.class_1793()));
    public static final class_1792 Cream = registerItem("cream",new class_1792(new class_1792.class_1793()));
    public static final class_1792 SOYBEAN = registerItem("soybean",new class_1792(new class_1792.class_1793()));
    public static final class_1792 Salt = registerItem("salt",new class_1792(new class_1792.class_1793()));

    //Seed
    public static final class_1792 Rice = registerItem("rice",new class_1798(MapleBlocks.RICE, (new class_1792.class_1793())));

    //Boat
    public static final class_1792 CHERRY_BOAT = registerItem("cherry_boat", (new class_1749(false, class_1690.class_1692.field_42681, (new class_1792.class_1793()).method_7889(1))));
    public static final class_1792 MAPLE_BOAT = registerItem("maple_boat", (new class_1749(false, MapleBoatType.MAPLE, (new class_1792.class_1793()).method_7889(1))));
    public static final class_1792 BAMBOO_BOAT = registerItem("bamboo_boat", (new class_1749(false, class_1690.class_1692.field_40161, (new class_1792.class_1793()).method_7889(1))));
    public static final class_1792 GINKGO_BOAT = registerItem("ginkgo_boat", (new class_1749(false, MapleBoatType.GINKGO, (new class_1792.class_1793()).method_7889(1))));

    public static final class_1792 CHERRY_CHEST_BOAT = registerItem("cherry_chest_boat", (new class_1749(true, class_1690.class_1692.field_42681, (new class_1792.class_1793()).method_7889(1))));
    public static final class_1792 MAPLE_CHEST_BOAT = registerItem("maple_chest_boat", (new class_1749(true, MapleBoatType.MAPLE, (new class_1792.class_1793()).method_7889(1))));
    public static final class_1792 BAMBOO_CHEST_BOAT = registerItem("bamboo_chest_boat", (new class_1749(true, class_1690.class_1692.field_40161, (new class_1792.class_1793()).method_7889(1))));
    public static final class_1792 GINKGO_CHEST_BOAT = registerItem("ginkgo_chest_boat", (new class_1749(true, MapleBoatType.GINKGO, (new class_1792.class_1793()).method_7889(1))));


    //Snowball
    public static final class_1792 SNOWBALL_STONE = registerItem("snowball_stone", new StoneSnowballItem(new class_1792.class_1793().method_7889(64)));
    public static final class_1792 SNOWBALL_ICE = registerItem("snowball_ice", new IceSnowballItem(new class_1792.class_1793().method_7889(64)));
    public static final class_1792 SNOWBALL_IRON = registerItem("snowball_iron", new IronSnowballItem(new class_1792.class_1793().method_7889(64)));
    public static final class_1792 SNOWBALL_Gold = registerItem("snowball_gold", new GoldSnowballItem(new class_1792.class_1793().method_7889(64)));
    public static final class_1792 SNOWBALL_Diamond = registerItem("snowball_diamond", new DiamondSnowballItem(new class_1792.class_1793().method_7889(64)));
    public static final class_1792 SNOWBALL_Compression = registerItem("snowball_compression", new StoneSnowballItem(new class_1792.class_1793().method_7889(64)));
    public static final class_1792 SNOWBALL_Teleporting = registerItem("snowball_teleporting", new TeleportingSnowballItem(new class_1792.class_1793().method_7889(64)));
    public static final class_1792 SNOWBALL_Confusion = registerItem("snowball_confusion", new ConfusionSnowballItem(new class_1792.class_1793().method_7889(64)));
    public static final class_1792 SNOWBALL_Poison = registerItem("snowball_poison", new PoisonSnowballItem(new class_1792.class_1793().method_7889(64)));
    public static final class_1792 SNOWBALL_Instant_Health = registerItem("snowball_instant_health", new InstantHealthSnowballItem(new class_1792.class_1793().method_7889(64)));

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(Maple.MOD_ID, name), item);
    }

    public static void registerModItems() {
        Maple.LOGGER.info("Registering Mod Items for " + Maple.MOD_ID);
    }
}