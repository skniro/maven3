package com.skniro.growable_ores_extension.recipe;


import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_7225;
import net.minecraft.class_9887;
import net.minecraft.recipe.*;
import org.jetbrains.annotations.Nullable;


public abstract class AbstractMachineCraftingRecipe implements class_1860<AlchemyCraftingRecipeInput> {
    final class_1799 output;
    final class_1856 ingredient;
    @Nullable
    private class_9887 ingredientPlacement;


    public AbstractMachineCraftingRecipe(class_1856 ingredients, class_1799 output) {
        this.output = output;
        this.ingredient = ingredients;
    }

    public class_1856 ingredient() {
        return this.ingredient;
    }

    public class_1799 output() {
        return this.output;
    }

    @Override
    public boolean matches(AlchemyCraftingRecipeInput input, class_1937 world) {
        if (world.method_8608()) {
            return false;
        }
        return this.ingredient.method_8093(input.method_59984(1));
    }

    @Override
    public class_1799 craft(AlchemyCraftingRecipeInput input, class_7225.class_7874 lookup) {
        return output.method_7972();
    }

    @Override
    public class_9887 method_61671() {
        if (this.ingredientPlacement == null) {
            this.ingredientPlacement = class_9887.method_61682(this.ingredient);
        }

        return this.ingredientPlacement;
    }


}









