package com.skniro.maple.tag;

import com.skniro.maple.Maple;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7923;


public class MapleItemTags {
    public static final class_6862<class_1792> BOOKSHELF_BOOKS = of("bookshelf_books");
    public static final class_6862<class_1792> REPAIRS_CHERRY_ARMOR = of("repairs_cherry_armor");
    public static final class_6862<class_1792> CHERRY_TOOL_MATERIALS = of("cherry_tool_materials");


    private static class_6862<class_1792> of(String id) {
        return class_6862.method_40092(class_7923.field_41178.method_46765(), class_2960.method_60655(Maple.MOD_ID,id));
    }
}
