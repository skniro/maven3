package com.skniro.skniro_furniture.block.renderer;

import com.skniro.skniro_furniture.block.entity.KitchenSinkBlockEntity;
import com.skniro.skniro_furniture.block.entity.PlateBlockEntity;

import com.skniro.skniro_furniture.block.renderer.state.KitchenSinkBlockEntityRenderState;
import com.skniro.skniro_furniture.block.renderer.state.PlateBlockEntityRendererState;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_10442;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_12075;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;

public class PlateBlockEntityRenderer implements class_827<PlateBlockEntity, PlateBlockEntityRendererState> {

    public PlateBlockEntityRenderer(class_5614.class_5615 context) {
    }

    @Override
    public void render(PlateBlockEntityRendererState state, class_4587 matrices, class_11659 queue, class_12075 cameraState) {
        class_2350 direction = state.field_62674.method_11654(class_2741.field_12481);
        matrices.method_22903();
        matrices.method_46416(0.5f, 0.01f, 0.5f);
        matrices.method_22905(0.35f, 0.35f, 0.35f);
        matrices.method_22907(class_7833.field_40714.rotationDegrees(90));
        switch (direction) {
            case field_11043 -> matrices.method_22907(class_7833.field_40716.rotationDegrees(0));
            case field_11035 -> matrices.method_22907(class_7833.field_40716.rotationDegrees(180));
            case field_11039 -> matrices.method_22907(class_7833.field_40718.rotationDegrees(90));
            case field_11034 -> matrices.method_22907(class_7833.field_40718.rotationDegrees(180));
        }
        state.item.method_65604(matrices, queue, state.field_62676, class_4608.field_21444,0);
        matrices.method_22909();
    }

    private int getLightLevel(class_1937 world, class_2338 pos) {
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, sLight);
    }

    @Override
    public PlateBlockEntityRendererState method_74335() {
        return new PlateBlockEntityRendererState();
    }

    @Override
    public void updateRenderState(PlateBlockEntity entity, PlateBlockEntityRendererState state, float tickProgress, class_243 cameraPos, @Nullable class_11683.class_11792 crumblingOverlay) {
        class_827.super.method_74331(entity, state, tickProgress, cameraPos, crumblingOverlay);
        class_10442 itemModelResolver = class_310.method_1551().method_65386();
        itemModelResolver.method_65598(state.item, entity.getRenderStack(), class_811.field_4317, entity.method_10997(), null, 1);
        state.field_62673 = entity.method_11016();
        state.field_62674 = entity.method_11010();
        state.field_62676 = getLightLevel(entity.method_10997(), entity.method_11016());
    }
}