package com.skniro.skniro_furniture.block.entity;

import com.mojang.logging.LogUtils;
import net.minecraft.class_1767;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class FurnitureBedBlockEntity extends class_2586 {
    private static final Logger LOGGER = LogUtils.getLogger();
    @Nullable
    private class_2561 customName;
    private final class_1767 baseColor;

    public FurnitureBedBlockEntity(class_2338 pos, class_2680 state) {
        this(pos, state, class_1767.field_7952);
    }


    public FurnitureBedBlockEntity(class_2338 pos, class_2680 state, class_1767 baseColor) {
        super(FurnitureBlockEntityType.Bed_BLOCK_ENTITY, pos, state);
        this.baseColor = baseColor;
    }

}

