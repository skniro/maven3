package com.skniro.usefulfood.datagen;

import com.skniro.usefulfood.block.UsefulFoodCakeBlocks;
import com.skniro.usefulfood.block.UsefulFoodJamBlocks;
import com.skniro.usefulfood.block.api.registry.MapleModelDatagenHelper;
import com.skniro.usefulfood.item.UsefulFoodItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4935;
import net.minecraft.class_4936;
import net.minecraft.class_4941;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.data.client.*;

public class UsefulFoodModelProvider extends FabricModelProvider {
    public UsefulFoodModelProvider(FabricDataOutput dataGenerator){
        super(dataGenerator);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator){

        MapleModelDatagenHelper usefulfoodModelDatagenHelper = new MapleModelDatagenHelper(blockStateModelGenerator);
        usefulfoodModelDatagenHelper.registerJamJarBlock(UsefulFoodJamBlocks.Apple_JAM_JAR);
        usefulfoodModelDatagenHelper.registerJamJarBlock(UsefulFoodJamBlocks.Melon_JAM_JAR);
        usefulfoodModelDatagenHelper.registerJamJarBlock(UsefulFoodJamBlocks.Chorus_JAM_JAR);
        usefulfoodModelDatagenHelper.registerJamJarBlock(UsefulFoodJamBlocks.Sweet_Berries_JAM_JAR);
        usefulfoodModelDatagenHelper.registerJamJarBlock(UsefulFoodJamBlocks.Glow_Berries_JAM_JAR);

        blockStateModelGenerator.method_25708(UsefulFoodJamBlocks.GLASS_JAR);

        registerMagicCake(blockStateModelGenerator);
        registerMagicCandleCake(blockStateModelGenerator);
        registerAppleCake(blockStateModelGenerator);
        registerAppleCandleCake(blockStateModelGenerator);
        registerCaramelCake(blockStateModelGenerator);
        registerCaramelCandleCake(blockStateModelGenerator);
        registerChocolateCake(blockStateModelGenerator);
        registerChocolateCandleCake(blockStateModelGenerator);
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
     itemModelGenerator.method_25733(UsefulFoodItems.MilkBottle, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.ChocolateMilkBottle, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Cheese, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.ChocolateCandy, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.FruitSalad, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.MagicFruitSalad , class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.SugarCube, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.caramel, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.caramelapple , class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.RoastedSeeds, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.FriedEgg, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.PumpkinSoup, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Salad, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Oatmeal, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Jelly, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Marshmallow, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.CookMarshmallow, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.VanillaIceCream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.BreadSlice, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.PorkWich, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Steakwich, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Fishwich, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Chickenwich, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Eggwich, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Biscuit, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Trailmix, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.MuttonSandwich, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Sushi, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.SquidTentacleRaw, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.SquidTentacleCooked, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.SquidSandwich, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.MagicAppleJuice, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.MelonJuice, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.AppleJuice, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.CarrotJuice, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.CarrotSoup, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.PumpkinBread, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.FishnChips, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.SugarBiscuit, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.AppleJamBiscuit, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.ChocoBiscuit, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.CarrotPie, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.hotchocolatebottle , class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.chocolateicecream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.MagicIceCream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.SquidSushi, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.CactusJuice, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Spaghetti, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.AppleIceCream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.MelonIceCream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.ChocolateApple , class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.CaramelBiscuit, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.FishSoup, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Tea, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.HotMilkBottle, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.CheeseSandwich, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.CaramelIceCream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Cereal, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.ChocolateCereal, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.FrenchFries, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.AppleJelly, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.MelonJelly, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Donut, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Oreo, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.CaramelToast, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.ChocolateToast, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.SugarToast, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.SugarPancake, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.AppleJamPanCake, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.AppleJamToast, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.AppleJam, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.CaramelPanCake, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.ChocolatePanCake, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.MelonJamPanCake, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.MelonJamToast, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.MelonJamBiscuit, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.MelonJam, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.PanCakeDough, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.PanCake, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Chorus_Juice, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Glow_Berries_Juice, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Sweet_Berries_Juice, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Chorus_Jelly, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Glow_Berries_Jelly, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Sweet_Berries_Jelly, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Chorus_Ice_Cream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Glow_Berries_Ice_Cream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Sweet_Berries_Ice_Cream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Glow_Berries_JamPanCake, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Glow_Berries_JamToast, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Glow_Berries_JamBiscuit, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Glow_Berries_Jam, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Sweet_Berries_JamPanCake, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Sweet_Berries_JamToast, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Sweet_Berries_JamBiscuit, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Sweet_Berries_Jam, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Chorus_JamPanCake, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Chorus_JamToast, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Chorus_JamBiscuit, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Chorus_Jam, class_4943.field_22938);

     //Reborn 1.5.0
     itemModelGenerator.method_25733(UsefulFoodItems.Baked_Sushi, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Salmon_Sushi, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Cod_Roe_Sushi, class_4943.field_22938);

     itemModelGenerator.method_25733(UsefulFoodItems.Waffle, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Waffle_Vanilla_IceCream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Waffle_Chorus_Ice_Cream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Waffle_Glow_Berries_Ice_Cream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Waffle_Sweet_Berries_Ice_Cream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Waffle_chocolate_icecream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Waffle_Magic_IceCream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Waffle_Apple_IceCream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Waffle_Melon_IceCream, class_4943.field_22938);
     itemModelGenerator.method_25733(UsefulFoodItems.Waffle_Caramel_IceCream, class_4943.field_22938);

    }

 private void registerMagicCake(class_4910 block) {
  block.method_25537(UsefulFoodCakeBlocks.MagicCake.method_8389());
  block.field_22830.accept(class_4925.method_25769(UsefulFoodCakeBlocks.MagicCake)
          .method_25775(class_4926.method_25783(class_2741.field_12505)
                  .method_25793(0, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25842(UsefulFoodCakeBlocks.MagicCake)))
                  .method_25793(1, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.MagicCake, "_slice1")))
                  .method_25793(2, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.MagicCake, "_slice2")))
                  .method_25793(3, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.MagicCake, "_slice3")))
                  .method_25793(4, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.MagicCake, "_slice4")))
                  .method_25793(5, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.MagicCake, "_slice5")))
                  .method_25793(6, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.MagicCake, "_slice6")))));
 }

 private void registerMagicCandleCake(class_4910 block) {
  registerMagicCandle(block, class_2246.field_27100, UsefulFoodCakeBlocks.Magic_WHITE_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27101, UsefulFoodCakeBlocks.Magic_ORANGE_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27102, UsefulFoodCakeBlocks.Magic_MAGENTA_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27103, UsefulFoodCakeBlocks.Magic_LIGHT_BLUE_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27104, UsefulFoodCakeBlocks.Magic_YELLOW_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27105, UsefulFoodCakeBlocks.Magic_LIME_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27106, UsefulFoodCakeBlocks.Magic_PINK_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27107, UsefulFoodCakeBlocks.Magic_GRAY_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27108, UsefulFoodCakeBlocks.Magic_LIGHT_GRAY_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27109, UsefulFoodCakeBlocks.Magic_CYAN_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27110, UsefulFoodCakeBlocks.Magic_PURPLE_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27111, UsefulFoodCakeBlocks.Magic_BLUE_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27112, UsefulFoodCakeBlocks.Magic_BROWN_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27113, UsefulFoodCakeBlocks.Magic_GREEN_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27140, UsefulFoodCakeBlocks.Magic_RED_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27141, UsefulFoodCakeBlocks.Magic_BLACK_CANDLE_CAKE);
  registerMagicCandle(block, class_2246.field_27099, UsefulFoodCakeBlocks.Magic_CANDLE_CAKE);
 }

 private void registerMagicCandle(class_4910 block, class_2248 candle, class_2248 cake) {

  class_2960 candleCake = class_4943.field_27789.method_25846(cake, candleMagicCake(candle, false), block.field_22831);
  class_2960 candleCakeLit = class_4943.field_27789.method_25847(cake, "_lit", candleMagicCake(candle, true), block.field_22831);
  block.field_22830.accept(class_4925.method_25769(cake)
          .method_25775(class_4910.method_25565(class_2741.field_12548, candleCakeLit, candleCake)));
 }

 private static class_4944 candleMagicCake(class_2248 block, boolean lit) {
  return new class_4944()
          .method_25868(class_4945.field_23012, class_4944.method_25866(UsefulFoodCakeBlocks.MagicCake, "_side"))
          .method_25868(class_4945.field_23014, class_4944.method_25866(UsefulFoodCakeBlocks.MagicCake, "_bottom"))
          .method_25868(class_4945.field_23015, class_4944.method_25866(UsefulFoodCakeBlocks.MagicCake, "_top"))
          .method_25868(class_4945.field_23018, class_4944.method_25866(UsefulFoodCakeBlocks.MagicCake, "_side"))
          .method_25868(class_4945.field_27790, class_4944.method_25866(block, lit ? "_lit" : ""));
 }

 private void registerAppleCake(class_4910 block) {
  block.method_25537(UsefulFoodCakeBlocks.AppleCake.method_8389());
  block.field_22830.accept(class_4925.method_25769(UsefulFoodCakeBlocks.AppleCake)
          .method_25775(class_4926.method_25783(class_2741.field_12505)
                  .method_25793(0, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25842(UsefulFoodCakeBlocks.AppleCake)))
                  .method_25793(1, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.AppleCake, "_slice1")))
                  .method_25793(2, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.AppleCake, "_slice2")))
                  .method_25793(3, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.AppleCake, "_slice3")))
                  .method_25793(4, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.AppleCake, "_slice4")))
                  .method_25793(5, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.AppleCake, "_slice5")))
                  .method_25793(6, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.AppleCake, "_slice6")))));
 }

 private void registerAppleCandleCake(class_4910 block) {
  registerAppleCandle(block, class_2246.field_27100, UsefulFoodCakeBlocks.Apple_WHITE_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27101, UsefulFoodCakeBlocks.Apple_ORANGE_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27102, UsefulFoodCakeBlocks.Apple_MAGENTA_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27103, UsefulFoodCakeBlocks.Apple_LIGHT_BLUE_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27104, UsefulFoodCakeBlocks.Apple_YELLOW_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27105, UsefulFoodCakeBlocks.Apple_LIME_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27106, UsefulFoodCakeBlocks.Apple_PINK_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27107, UsefulFoodCakeBlocks.Apple_GRAY_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27108, UsefulFoodCakeBlocks.Apple_LIGHT_GRAY_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27109, UsefulFoodCakeBlocks.Apple_CYAN_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27110, UsefulFoodCakeBlocks.Apple_PURPLE_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27111, UsefulFoodCakeBlocks.Apple_BLUE_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27112, UsefulFoodCakeBlocks.Apple_BROWN_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27113, UsefulFoodCakeBlocks.Apple_GREEN_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27140, UsefulFoodCakeBlocks.Apple_RED_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27141, UsefulFoodCakeBlocks.Apple_BLACK_CANDLE_CAKE);
  registerAppleCandle(block, class_2246.field_27099, UsefulFoodCakeBlocks.Apple_CANDLE_CAKE);
 }

 private void registerAppleCandle(class_4910 block, class_2248 candle, class_2248 cake) {

  class_2960 candleCake = class_4943.field_27789.method_25846(cake, candleAppleCake(candle, false), block.field_22831);
  class_2960 candleCakeLit = class_4943.field_27789.method_25847(cake, "_lit", candleAppleCake(candle, true), block.field_22831);
  block.field_22830.accept(class_4925.method_25769(cake)
          .method_25775(class_4910.method_25565(class_2741.field_12548, candleCakeLit, candleCake)));
 }

 private static class_4944 candleAppleCake(class_2248 block, boolean lit) {
  return new class_4944()
          .method_25868(class_4945.field_23012, class_4944.method_25866(UsefulFoodCakeBlocks.AppleCake, "_side"))
          .method_25868(class_4945.field_23014, class_4944.method_25866(UsefulFoodCakeBlocks.AppleCake, "_bottom"))
          .method_25868(class_4945.field_23015, class_4944.method_25866(UsefulFoodCakeBlocks.AppleCake, "_top"))
          .method_25868(class_4945.field_23018, class_4944.method_25866(UsefulFoodCakeBlocks.AppleCake, "_side"))
          .method_25868(class_4945.field_27790, class_4944.method_25866(block, lit ? "_lit" : ""));
 }

 private void registerCaramelCake(class_4910 block) {
  block.method_25537(UsefulFoodCakeBlocks.CaramelCake.method_8389());
  block.field_22830.accept(class_4925.method_25769(UsefulFoodCakeBlocks.CaramelCake)
          .method_25775(class_4926.method_25783(class_2741.field_12505)
                  .method_25793(0, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25842(UsefulFoodCakeBlocks.CaramelCake)))
                  .method_25793(1, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.CaramelCake, "_slice1")))
                  .method_25793(2, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.CaramelCake, "_slice2")))
                  .method_25793(3, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.CaramelCake, "_slice3")))
                  .method_25793(4, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.CaramelCake, "_slice4")))
                  .method_25793(5, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.CaramelCake, "_slice5")))
                  .method_25793(6, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.CaramelCake, "_slice6")))));
 }

 private void registerCaramelCandleCake(class_4910 block) {
  registerCaramelCandle(block, class_2246.field_27100, UsefulFoodCakeBlocks.Caramel_WHITE_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27101, UsefulFoodCakeBlocks.Caramel_ORANGE_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27102, UsefulFoodCakeBlocks.Caramel_MAGENTA_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27103, UsefulFoodCakeBlocks.Caramel_LIGHT_BLUE_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27104, UsefulFoodCakeBlocks.Caramel_YELLOW_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27105, UsefulFoodCakeBlocks.Caramel_LIME_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27106, UsefulFoodCakeBlocks.Caramel_PINK_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27107, UsefulFoodCakeBlocks.Caramel_GRAY_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27108, UsefulFoodCakeBlocks.Caramel_LIGHT_GRAY_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27109, UsefulFoodCakeBlocks.Caramel_CYAN_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27110, UsefulFoodCakeBlocks.Caramel_PURPLE_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27111, UsefulFoodCakeBlocks.Caramel_BLUE_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27112, UsefulFoodCakeBlocks.Caramel_BROWN_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27113, UsefulFoodCakeBlocks.Caramel_GREEN_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27140, UsefulFoodCakeBlocks.Caramel_RED_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27141, UsefulFoodCakeBlocks.Caramel_BLACK_CANDLE_CAKE);
  registerCaramelCandle(block, class_2246.field_27099, UsefulFoodCakeBlocks.Caramel_CANDLE_CAKE);
 }

 private void registerCaramelCandle(class_4910 block, class_2248 candle, class_2248 cake) {

  class_2960 candleCake = class_4943.field_27789.method_25846(cake, candleCaramelCake(candle, false), block.field_22831);
  class_2960 candleCakeLit = class_4943.field_27789.method_25847(cake, "_lit", candleCaramelCake(candle, true), block.field_22831);
  block.field_22830.accept(class_4925.method_25769(cake)
          .method_25775(class_4910.method_25565(class_2741.field_12548, candleCakeLit, candleCake)));
 }

 private static class_4944 candleCaramelCake(class_2248 block, boolean lit) {
  return new class_4944()
          .method_25868(class_4945.field_23012, class_4944.method_25866(UsefulFoodCakeBlocks.CaramelCake, "_side"))
          .method_25868(class_4945.field_23014, class_4944.method_25866(UsefulFoodCakeBlocks.CaramelCake, "_bottom"))
          .method_25868(class_4945.field_23015, class_4944.method_25866(UsefulFoodCakeBlocks.CaramelCake, "_top"))
          .method_25868(class_4945.field_23018, class_4944.method_25866(UsefulFoodCakeBlocks.CaramelCake, "_side"))
          .method_25868(class_4945.field_27790, class_4944.method_25866(block, lit ? "_lit" : ""));
 }

 private void registerChocolateCake(class_4910 block) {
  block.method_25537(UsefulFoodCakeBlocks.ChocolateCake.method_8389());
  block.field_22830.accept(class_4925.method_25769(UsefulFoodCakeBlocks.ChocolateCake)
          .method_25775(class_4926.method_25783(class_2741.field_12505)
                  .method_25793(0, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25842(UsefulFoodCakeBlocks.ChocolateCake)))
                  .method_25793(1, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.ChocolateCake, "_slice1")))
                  .method_25793(2, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.ChocolateCake, "_slice2")))
                  .method_25793(3, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.ChocolateCake, "_slice3")))
                  .method_25793(4, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.ChocolateCake, "_slice4")))
                  .method_25793(5, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.ChocolateCake, "_slice5")))
                  .method_25793(6, class_4935.method_25824()
                          .method_25828(class_4936.field_22887, class_4941.method_25843(UsefulFoodCakeBlocks.ChocolateCake, "_slice6")))));
 }

 private void registerChocolateCandleCake(class_4910 block) {
  registerChocolateCandle(block, class_2246.field_27100, UsefulFoodCakeBlocks.Chocolate_WHITE_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27101, UsefulFoodCakeBlocks.Chocolate_ORANGE_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27102, UsefulFoodCakeBlocks.Chocolate_MAGENTA_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27103, UsefulFoodCakeBlocks.Chocolate_LIGHT_BLUE_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27104, UsefulFoodCakeBlocks.Chocolate_YELLOW_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27105, UsefulFoodCakeBlocks.Chocolate_LIME_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27106, UsefulFoodCakeBlocks.Chocolate_PINK_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27107, UsefulFoodCakeBlocks.Chocolate_GRAY_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27108, UsefulFoodCakeBlocks.Chocolate_LIGHT_GRAY_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27109, UsefulFoodCakeBlocks.Chocolate_CYAN_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27110, UsefulFoodCakeBlocks.Chocolate_PURPLE_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27111, UsefulFoodCakeBlocks.Chocolate_BLUE_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27112, UsefulFoodCakeBlocks.Chocolate_BROWN_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27113, UsefulFoodCakeBlocks.Chocolate_GREEN_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27140, UsefulFoodCakeBlocks.Chocolate_RED_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27141, UsefulFoodCakeBlocks.Chocolate_BLACK_CANDLE_CAKE);
  registerChocolateCandle(block, class_2246.field_27099, UsefulFoodCakeBlocks.Chocolate_CANDLE_CAKE);
 }

 private void registerChocolateCandle(class_4910 block, class_2248 candle, class_2248 cake) {

  class_2960 candleCake = class_4943.field_27789.method_25846(cake, candleChocolateCake(candle, false), block.field_22831);
  class_2960 candleCakeLit = class_4943.field_27789.method_25847(cake, "_lit", candleChocolateCake(candle, true), block.field_22831);
  block.field_22830.accept(class_4925.method_25769(cake)
          .method_25775(class_4910.method_25565(class_2741.field_12548, candleCakeLit, candleCake)));
 }

 private static class_4944 candleChocolateCake(class_2248 block, boolean lit) {
  return new class_4944()
          .method_25868(class_4945.field_23012, class_4944.method_25866(UsefulFoodCakeBlocks.ChocolateCake, "_side"))
          .method_25868(class_4945.field_23014, class_4944.method_25866(UsefulFoodCakeBlocks.ChocolateCake, "_bottom"))
          .method_25868(class_4945.field_23015, class_4944.method_25866(UsefulFoodCakeBlocks.ChocolateCake, "_top"))
          .method_25868(class_4945.field_23018, class_4944.method_25866(UsefulFoodCakeBlocks.ChocolateCake, "_side"))
          .method_25868(class_4945.field_27790, class_4944.method_25866(block, lit ? "_lit" : ""));
 }
}
