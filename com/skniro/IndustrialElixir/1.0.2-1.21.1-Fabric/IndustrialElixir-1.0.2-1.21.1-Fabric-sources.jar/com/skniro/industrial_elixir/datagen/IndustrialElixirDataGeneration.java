package com.skniro.industrial_elixir.datagen;

import com.skniro.industrial_elixir.datagen.dynamic.ModDamageTypeProvider;
import com.skniro.industrial_elixir.datagen.recipe.RecipeDataGeneration;
import com.skniro.industrial_elixir.world.feature.AgreeTreeConfiguredFeatures;
import com.skniro.industrial_elixir.world.feature.AgreeTreePlacedFeatures;
import com.skniro.industrial_elixir.world.feature.ModConfiguredFeatures;
import com.skniro.industrial_elixir.world.feature.ModPlacedFeatures;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.class_7877;
import net.minecraft.class_7924;

public class IndustrialElixirDataGeneration implements DataGeneratorEntrypoint {
    @Override
    public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {
        fabricDataGenerator.createPack().addProvider(IndustrialElixirModelProvider::new);
        fabricDataGenerator.createPack().addProvider(IndustrialElixirLootTableGenerator::new);
        fabricDataGenerator.createPack().addProvider(IndustrialElixirEnglishLanguageProvider::new);
        fabricDataGenerator.createPack().addProvider(IndustrialElixirSimplifiedChineseLanguageProvider::new);
        fabricDataGenerator.createPack().addProvider(IndustrialElixirBlockTagGenerator::new);
        fabricDataGenerator.createPack().addProvider(IndustrialElixirItemTagGenerator::new);
        fabricDataGenerator.createPack().addProvider(IndustrialElixirBiomeTagGeneration::new);
        fabricDataGenerator.createPack().addProvider(ModDynamicGenerator::new);
        RecipeDataGeneration.onInit(fabricDataGenerator);
    }

    @Override
    public void buildRegistry(class_7877 registryBuilder) {
        registryBuilder.method_46777(class_7924.field_42534, ModDamageTypeProvider::damageTypes);
        registryBuilder.method_46777(class_7924.field_41239, ModConfiguredFeatures::bootstrap);
        registryBuilder.method_46777(class_7924.field_41245, ModPlacedFeatures::bootstrap);
        registryBuilder.method_46777(class_7924.field_41239, AgreeTreeConfiguredFeatures::bootstrap);
        registryBuilder.method_46777(class_7924.field_41245, AgreeTreePlacedFeatures::bootstrap);
    }
}
