package com.skniro.growable_ores_extension.block.entity.generator;

import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.block.init.generator.GeneratorSolarPanelBlock;
import com.skniro.growable_ores_extension.block.init.machine.AbstractMachineblock;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.EnergyStorageUtil;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import com.skniro.growable_ores_extension.screen.generator.CoalGeneratorScreenHandler;
import com.skniro.growable_ores_extension.screen.generator.GeneratorSolarPanelScreenHandler;
import com.skniro.growable_ores_extension.screen.generator.GeneratorWindMillScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;


public class GeneratorSolarPanelBlockEntity extends NewBaseGeneratorBlockEntity {
    private final class_2371<class_1799> inventory = class_2371.method_10213(4, class_1799.field_8037);
    protected final class_3913 propertyDelegate;
    private GeneratorState state = GeneratorState.IDLE;
    private int cachedPower;
    private int DayPower;
    private int NightPower;
    private EnergyTier energyTier;

    public GeneratorSolarPanelBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.GENERATOR_SOLAR_PANEL_BLOCK_ENTITY, pos, state);
        this.DayPower = ((GeneratorSolarPanelBlock)state.method_26204()).getDayPower();
        this.NightPower = ((GeneratorSolarPanelBlock)state.method_26204()).getNightPower();
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> GeneratorSolarPanelBlockEntity.this.cachedPower;
                    case 1 -> GeneratorSolarPanelBlockEntity.this.state.ordinal();
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: GeneratorSolarPanelBlockEntity.this.cachedPower = value;
                    case 1: {
                            GeneratorState[] values = GeneratorState.values();
                            if (value >= 0 && value < values.length) {
                                GeneratorSolarPanelBlockEntity.this.state = values[value];
                            }
                        }
                }
            }

            @Override
            public int method_17389() {
                return 4;
            }
        };
    }

    @Override
    protected void method_11007(class_11372 nbt) {
        super.method_11007(nbt);
        class_1262.method_5426(nbt, inventory);
        nbt.method_71466(("generator_solar_panel.energy"), energyContainer.amount);
        nbt.method_71465("generator_solar_panel.day_power", this.DayPower);
        nbt.method_71465("generator_solar_panel.night_power", this.NightPower);
    }

    @Override
    protected void method_11014(class_11368 nbt) {
        class_1262.method_5429(nbt, inventory);
        energyContainer.amount = nbt.method_71425("generator_solar_panel.energy", 0);
        this.DayPower = nbt.method_71424("generator_solar_panel.day_power", this.DayPower);
        this.NightPower = nbt.method_71424("generator_solar_panel.night_power", this.NightPower);
        super.method_11014(nbt);
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2371<class_1799> getItems() {
        return this.inventory;
    }

    @Override
    public class_2561 method_5476() {
        return switch (((GeneratorSolarPanelBlock)method_11010().method_26204()).getEnergyTier().getMaxInput()) {
            case 0 -> class_2561.method_43471(FurnitureStrings.GENERATOR_SolarPanel);
            case 1 -> class_2561.method_43471(FurnitureStrings.GENERATOR_ADVANCED_SOLAR_PANEL);
            case 2 -> class_2561.method_43471(FurnitureStrings.GENERATOR_HYBRID_SOLAR_PANEL);
            case 3 -> class_2561.method_43471(FurnitureStrings.GENERATOR_ULTIMATE_SOLAR_PANEL);
            case 4 -> class_2561.method_43471(FurnitureStrings.GENERATOR_QUANTUM_SOLAR_PANEL);
            default -> class_2561.method_43471(FurnitureStrings.GENERATOR_SolarPanel);
        };
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new GeneratorSolarPanelScreenHandler(syncId, playerInventory, this, this.propertyDelegate);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world == null || world.method_8608()) return;

        discharge(0);
        discharge(1);
        discharge(2);
        discharge(3);

        cachedPower = calculatePower(world, pos);
        updateState();
        //System.out.println("Wind: " + windStrength + " Power: " + cachedPower);
        method_5431();

        if (cachedPower > 0) {
            if (energyContainer.amount < energyContainer.getCapacity()) {
                try (Transaction transaction = Transaction.openOuter()) {
                    this.energyContainer.getSideStorage(null).insert(cachedPower, transaction);
                    transaction.commit();
                }
            }
        }
        pushEnergyToNeighbours();
    }

    private void updateState() {
        if (cachedPower <= 0) {
            state = GeneratorState.IDLE;
        } else {
            state = GeneratorState.GENERATING;
        }
    }

    private int calculatePower(class_1937 world, class_2338 pos) {
        double power = 0;
        if (world.method_8530() && !world.method_8419() && !world.method_8546()) {
            power = this.DayPower;
        } else {
            power = this.NightPower;
        }

        return (int) Math.ceil(power);
    }

    private void pushEnergyToNeighbours() {
        if (energyContainer.amount <= 0) return;

        for (class_2350 direction : class_2350.values()) {
            EnergyStorage target = EnergyStorage.SIDED.find(
                    field_11863,
                    field_11867.method_10093(direction),
                    direction.method_10153()
            );

            if (target == null) continue;

            EnergyStorageUtil.move(
                    this.energyContainer.getSideStorage(direction),
                    target,
                    ((AbstractMachineblock)method_11010().method_26204()).getEnergyTier().getMaxOutput(),
                    null
            );
        }
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }

    public enum GeneratorState {
        IDLE,
        GENERATING
    }
}