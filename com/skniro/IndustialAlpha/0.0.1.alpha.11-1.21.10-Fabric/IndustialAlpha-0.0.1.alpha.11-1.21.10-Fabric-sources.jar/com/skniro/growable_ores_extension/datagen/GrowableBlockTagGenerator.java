package com.skniro.growable_ores_extension.datagen;

import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3481;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

import static net.minecraft.class_3481.*;

public class GrowableBlockTagGenerator extends FabricTagProvider.BlockTagProvider {
   public GrowableBlockTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
   }
   @Override
   protected void method_10514(class_7225.class_7874 arg) {
      valueLookupBuilder(field_33715)
              .method_71554(GeneralBlocks.Deepslate_Lead_Ore)
              .method_71554(GeneralBlocks.Deepslate_Tin_Ore)
              .method_71554(GeneralBlocks.Deepslate_Uranium_Ore)
              .method_71554(GeneralBlocks.Lead_Ore)
              .method_71554(GeneralBlocks.Tin_Ore)
              .method_71554(GeneralBlocks.Uranium_Ore)
              .method_71554(GrowableOresBlocks.GrowableOres_Block)
              .method_71558(GrowableOresBlocks.Macerator_Block,
                      GrowableOresBlocks.Compressor_Block,
                      GrowableOresBlocks.MetalFormerBlock,

                      GrowableOresBlocks.COPPER_CABLE,
                      GrowableOresBlocks.TIN_CABLE,
                      GrowableOresBlocks.GOLD_CABLE,
                      GrowableOresBlocks.HV_CABLE,
                      GrowableOresBlocks.GLASSFIBER_CABLE,

                      GrowableOresBlocks.INSULATED_TIN_CABLE,
                      GrowableOresBlocks.INSULATED_COPPER_CABLE,
                      GrowableOresBlocks.INSULATED_GOLD_CABLE,
                      GrowableOresBlocks.INSULATED_HV_CABLE,

                      GrowableOresBlocks.COAL_GENERATOR,
                      GrowableOresBlocks.GENERATOR_Wind_Mill,

                      GrowableOresBlocks.EnergyBox,
                      GrowableOresBlocks.ChargePad,
                      GrowableOresBlocks.CESU,
                      GrowableOresBlocks.MFE,
                      GrowableOresBlocks.MFSU,

                      GrowableOresBlocks.CESU_CHARGE_PAD,
                      GrowableOresBlocks.MFE_CHARGE_PAD,
                      GrowableOresBlocks.MFSU_CHARGE_PAD,

                      GrowableOresBlocks.MolecularTransformerBlock,

                      GrowableOresBlocks.GENERATOR_SolarPanel,
                      GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL,
                      GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL,
                      GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL,
                      GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL,

                      GrowableOresBlocks.Extractor_Block,

                      GrowableOresBlocks.EV_TRANSFORMER,
                      GrowableOresBlocks.HV_TRANSFORMER,
                      GrowableOresBlocks.MV_TRANSFORMER,
                      GrowableOresBlocks.LV_TRANSFORMER,

                      GrowableOresBlocks.Iron_Furnace_Block,
                      GeneralBlocks.Raw_Lead_Block,
                      GeneralBlocks.Raw_Tin_Block,
                      GeneralBlocks.Raw_Uranium_Block,

                      GeneralBlocks.Lead_Block,
                      GeneralBlocks.Tin_Block,
                      GeneralBlocks.Uranium_Block,
                      GeneralBlocks.Silver_Block,
                      GeneralBlocks.Bronze_Block,
                      GeneralBlocks.Steel_Block,

                      GeneralBlocks.Advanced_Machine,
                      GeneralBlocks.Machine)
              .setReplace(false);
      valueLookupBuilder(field_33718)
              .method_71554(GeneralBlocks.Deepslate_Lead_Ore)
              .method_71554(GeneralBlocks.Deepslate_Tin_Ore)
              .method_71554(GeneralBlocks.Deepslate_Uranium_Ore)
              .method_71554(GeneralBlocks.Lead_Ore)
              .method_71554(GeneralBlocks.Tin_Ore)
              .method_71554(GeneralBlocks.Uranium_Ore)
              .setReplace(false);
      valueLookupBuilder(field_33719)
              .setReplace(false);
      valueLookupBuilder(class_3481.field_15503)
              .method_71554(GeneralBlocks.Rubber_LEAVES)
              .setReplace(false);
      valueLookupBuilder(class_3481.field_15462)
              .method_71554(GeneralBlocks.Rubber_SAPLING)
              .setReplace(false);
      valueLookupBuilder(field_23210)
              .method_71554(GeneralBlocks.Rubber_LOG)
              .method_71554(GeneralBlocks.Rubber_Rubber_LOG)
              .method_71554(GeneralBlocks.Rubber_WOOD)
              .method_71554(GeneralBlocks.STRIPPED_Rubber_LOG)
              .method_71554(GeneralBlocks.STRIPPED_Rubber_WOOD)
              .setReplace(false);
      valueLookupBuilder(field_15499)
              .method_71554(GeneralBlocks.Rubber_BUTTON)
              .setReplace(false);
      valueLookupBuilder(field_15494)
              .method_71554(GeneralBlocks.Rubber_DOOR)
              .setReplace(false);
      valueLookupBuilder(field_15491)
              .method_71554(GeneralBlocks.Rubber_TRAPDOOR)
              .setReplace(false);
      valueLookupBuilder(field_15477)
              .method_71554(GeneralBlocks.Rubber_PRESSURE_PLATE)
              .setReplace(false);
      valueLookupBuilder(field_15468)
              .method_71554(GeneralBlocks.Rubber_SLAB)
              .setReplace(false);
      valueLookupBuilder(field_15502)
              .method_71554(GeneralBlocks.Rubber_STAIRS)
              .setReplace(false);
      valueLookupBuilder(field_15471)
              .method_71554(GeneralBlocks.Rubber_PLANKS)
              .setReplace(false);
      valueLookupBuilder(field_16584)
              .method_71554(GeneralBlocks.Rubber_FENCE)
              .setReplace(false);


   }
}