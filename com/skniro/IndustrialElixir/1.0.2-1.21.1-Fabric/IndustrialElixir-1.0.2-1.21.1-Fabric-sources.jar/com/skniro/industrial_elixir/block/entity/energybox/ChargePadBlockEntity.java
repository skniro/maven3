package com.skniro.industrial_elixir.block.entity.energybox;

import com.skniro.industrial_elixir.api.block.ImplementedInventory;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.EnergyStorageUtil;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.screen.handler.energybox.ChargePadScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;


public class ChargePadBlockEntity extends BaseEnergyBoxBlockEntity {
    private final class_2371<class_1799> inventory = class_2371.method_10213(8, class_1799.field_8037);

    private static final int Battery_OUTPUT_SLOT = 0;
    private static final int Battery_INPUT_SLOT = 1;


    public ChargePadBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.ChargePad_BLOCK_ENTITY, pos, state);
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        class_1262.method_5426(nbt, inventory, registries);
        nbt.method_10544(("coal_generator.energy"), energyContainer.amount);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        class_1262.method_5429(nbt, inventory, registries);
        energyContainer.amount = (nbt.method_10545("coal_generator.energy") ? nbt.method_10537("coal_generator.energy") : 0);
        super.method_11014(nbt, registries);
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2371<class_1799> getItems() {
        return this.inventory;
    }

    @Override
    public class_2561 method_5476() {
        return switch (energyTier.ordinal()) {
            case 0 -> class_2561.method_43471(FurnitureStrings.Charge_Pad);
            case 1 -> class_2561.method_43471(FurnitureStrings.Charge_Pad_CESU);
            case 2 -> class_2561.method_43471(FurnitureStrings.Charge_Pad_MFE);
            case 3 -> class_2561.method_43471(FurnitureStrings.Charge_Pad_MFSU);
            default -> class_2561.method_43471(FurnitureStrings.Charge_Pad);
        };
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new ChargePadScreenHandler(syncId, playerInventory, this, this.propertyDelegate);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world != null && !world.method_8608()) {
            charge(Battery_OUTPUT_SLOT);
            discharge(Battery_INPUT_SLOT);
            chargePlayersAbove();
            pushEnergyToNeighbours();
        }
    }

    public void discharge(int slot) {
        if (this.field_11863 != null) {
            if (!this.field_11863.method_8608()) {
                if (!this.getOptionalInventory().isEmpty()) {
                    class_1263 inventory = this.getOptionalInventory().get();
                    EnergyStorageUtil.move(this.getSideEnergyStorage(null), ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(slot)).find(EnergyStorage.ITEM), Long.MAX_VALUE, null);
                }
            }
        }
    }



    public Optional<ImplementedInventory> getOptionalInventory() {
        if (this instanceof ImplementedInventory inventory) {
            return inventory == null ? Optional.empty() : Optional.of(inventory);
        } else {
            return Optional.empty();
        }
    }


    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}