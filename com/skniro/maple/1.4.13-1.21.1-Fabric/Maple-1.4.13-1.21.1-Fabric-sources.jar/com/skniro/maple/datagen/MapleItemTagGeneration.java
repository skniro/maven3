package com.skniro.maple.datagen;

import com.skniro.maple.block.MapleBlocks;
import com.skniro.maple.item.MapleArmorItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.registry.*;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static com.skniro.maple.datagen.MapleItemTagGeneration.ModItemTags.C_CHERRY_LOGS;
import static net.minecraft.class_3489.*;


public class MapleItemTagGeneration extends FabricTagProvider<class_1792> {
    public MapleItemTagGeneration(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(dataGenerator, class_7924.field_41197, completableFuture);
    }

    public static class ModItemTags {
        public static final class_6862<class_1792> C_SAPLING = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "saplings"));
        public static final class_6862<class_1792> C_MAPLE_LOGS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "maple_logs"));
        public static final class_6862<class_1792> C_CHERRY_LOGS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "cherry_logs"));
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        method_10512(field_15528)
                .add(class_1792.method_7867(MapleBlocks.MAPLE_SAPLING))
                .add(class_1792.method_7867(MapleBlocks.CHERRY_SAPLING))
                .add(class_1792.method_7867(MapleBlocks.GINKGO_SAPLING))
                .add(class_1792.method_7867(MapleBlocks.SAKURA_SAPLING))
                .add(class_1792.method_7867(MapleBlocks.RED_MAPLE_SAPLING))
                .setReplace(false);
        method_10512(C_CHERRY_LOGS)
                .add(class_1792.method_7867(MapleBlocks.CHERRY_LOG));
        method_10512(class_3489.field_41890)
                .add(MapleArmorItems.Cherry_HELMET, MapleArmorItems.Cherry_CHESTPLATE, MapleArmorItems.Cherry_LEGGINGS, MapleArmorItems.Cherry_BOOTS)
                .setReplace(false);
        method_10512(field_48294)
                .add(MapleArmorItems.Cherry_BOOTS)
                .setReplace(false);
        method_10512(field_48295)
                .add(MapleArmorItems.Cherry_LEGGINGS)
                .setReplace(false);
        method_10512(field_48296)
                .add(MapleArmorItems.Cherry_CHESTPLATE)
                .setReplace(false);
        method_10512(field_48297)
                .add(MapleArmorItems.Cherry_HELMET)
                .setReplace(false);
        method_10512(field_42611)
                .add(MapleArmorItems.Cherry_SWORD)
                .setReplace(false);
        method_10512(field_42612)
                .add(MapleArmorItems.Cherry_AXE)
                .setReplace(false);
        method_10512(field_42613)
                .add(MapleArmorItems.Cherry_HOE)
                .setReplace(false);
        method_10512(field_42614)
                .add(MapleArmorItems.Cherry_PICKAXE)
                .setReplace(false);
        method_10512(field_42615)
                .add(MapleArmorItems.Cherry_SHOVEL)
                .setReplace(false);
    }


}
