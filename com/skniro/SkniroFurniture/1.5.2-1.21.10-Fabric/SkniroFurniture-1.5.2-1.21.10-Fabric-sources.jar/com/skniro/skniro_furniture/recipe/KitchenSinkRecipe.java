package com.skniro.skniro_furniture.recipe;


import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_10355;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9887;
import net.minecraft.recipe.*;
import org.jetbrains.annotations.Nullable;


public class KitchenSinkRecipe implements class_1860<KitchenSinkRecipeInput> {
    final class_1799 output;
    final class_1856 ingredient;
    @Nullable
    private class_9887 ingredientPlacement;


    public KitchenSinkRecipe(class_1856 ingredients, class_1799 output) {
        this.output = output;
        this.ingredient = ingredients;
    }

    public class_1856 ingredient() {
        return this.ingredient;
    }

    public class_1799 output() {
        return this.output;
    }

    @Override
    public boolean matches(KitchenSinkRecipeInput input, class_1937 world) {
        if (world.method_8608()) {
            return false;
        }
        return this.ingredient.method_8093(input.method_59984(1));
    }

    @Override
    public class_1799 craft(KitchenSinkRecipeInput input, class_7225.class_7874 lookup) {
        return output.method_7972();
    }

    @Override
    public class_1865<? extends class_1860<KitchenSinkRecipeInput>> method_8119() {
        return FurnitureRecipeType.Kitchen_Sink_SERIALIZER;
    }

    @Override
    public class_3956<? extends class_1860<KitchenSinkRecipeInput>> method_17716() {
        return FurnitureRecipeType.Kitchen_Sink_TYPE;
    }

    @Override
    public class_9887 method_61671() {
        if (this.ingredientPlacement == null) {
            this.ingredientPlacement = class_9887.method_61682(this.ingredient);
        }

        return this.ingredientPlacement;
    }

    @Override
    public class_10355 method_64668() {
        return null;
    }

    public static class Serializer implements class_1865<KitchenSinkRecipe> {
        public static final MapCodec<KitchenSinkRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
                class_1856.field_46095.fieldOf("ingredient").forGetter((recipe) -> {
                    return recipe.ingredient;
                }),
                class_1799.field_24671.fieldOf("result").forGetter((recipe) -> {
                    return recipe.output;
                })
        ).apply(inst, KitchenSinkRecipe::new));

        public static final class_9139<class_9129, KitchenSinkRecipe> STREAM_CODEC =
                class_9139.method_56435(
                        class_1856.field_48355, KitchenSinkRecipe::ingredient,
                        class_1799.field_48349, KitchenSinkRecipe::output,
                        KitchenSinkRecipe::new);

        public Serializer() {
        }

        public MapCodec<KitchenSinkRecipe> method_53736() {
            return CODEC;
        }

        public class_9139<class_9129, KitchenSinkRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }
}









