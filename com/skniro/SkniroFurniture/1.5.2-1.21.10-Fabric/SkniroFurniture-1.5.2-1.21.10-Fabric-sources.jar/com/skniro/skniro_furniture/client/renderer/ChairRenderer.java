package com.skniro.skniro_furniture.client.renderer;

import com.skniro.skniro_furniture.entity.furniture.ChairEntity;
import net.minecraft.class_10017;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class ChairRenderer extends class_897<ChairEntity, class_10017> {

    public ChairRenderer(class_5617.class_5618 ctx) {
        super(ctx);
    }

    @Override
    public boolean shouldRender(ChairEntity livingEntity, class_4604 camera, double camX, double camY, double camZ) {
        return true;
    }

    @Override
    public class_10017 method_55269() {
        return new class_10017();
    }
}