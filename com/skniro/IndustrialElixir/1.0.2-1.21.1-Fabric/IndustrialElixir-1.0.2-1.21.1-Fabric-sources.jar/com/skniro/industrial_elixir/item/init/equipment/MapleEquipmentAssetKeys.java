package com.skniro.industrial_elixir.item.init.equipment;

import com.skniro.industrial_elixir.IndustrialElixir;
import net.minecraft.class_1741;
import net.minecraft.class_2960;

/**
 * Armour texture layers for the mod's armour sets.
 *
 * <p>26.1 models armour textures through a data-driven {@code EquipmentAsset}; 1.21.1 has no such
 * registry and instead resolves the texture straight from an {@link class_1741.class_9196}.</p>
 */
public interface MapleEquipmentAssetKeys {
    class_1741.class_9196 QUANTUM = register("quantum");
    class_1741.class_9196 BRONZE = register("bronze");
    class_1741.class_9196 ELECTRIC_JETPACK = register("electric_jetpack");

    static class_1741.class_9196 register(String name) {
        return new class_1741.class_9196(class_2960.method_60655(IndustrialElixir.MOD_ID, name));
    }

    public static void registerMapleArmorAssetsKeys() {
        IndustrialElixir.LOGGER.info("Registering Maple armor assets Keys for " + IndustrialElixir.MOD_ID);
    }
}
