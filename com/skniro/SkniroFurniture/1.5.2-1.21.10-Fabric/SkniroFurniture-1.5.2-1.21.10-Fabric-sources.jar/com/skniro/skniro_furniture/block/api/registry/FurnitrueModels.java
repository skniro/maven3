package com.skniro.skniro_furniture.block.api.registry;

import com.skniro.skniro_furniture.Furniture;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_4942;
import net.minecraft.class_4945;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class FurnitrueModels {
    public static final class_4942 PAPER_SLIDING_DOOR_BOTTOM_LEFT;
    public static final class_4942 PAPER_SLIDING_DOOR_BOTTOM_LEFT_OPEN;
    public static final class_4942 PAPER_SLIDING_DOOR_BOTTOM_RIGHT;
    public static final class_4942 PAPER_SLIDING_DOOR_BOTTOM_RIGHT_OPEN;
    public static final class_4942 PAPER_SLIDING_DOOR_TOP_LEFT;
    public static final class_4942 PAPER_SLIDING_DOOR_TOP_LEFT_OPEN;
    public static final class_4942 PAPER_SLIDING_DOOR_TOP_RIGHT;
    public static final class_4942 PAPER_SLIDING_DOOR_TOP_RIGHT_OPEN;


    static {
        PAPER_SLIDING_DOOR_BOTTOM_LEFT = block("paper_sliding_door_bottom_left", "_bottom_left", class_4945.field_23015, class_4945.field_23014);
        PAPER_SLIDING_DOOR_BOTTOM_LEFT_OPEN = block("paper_sliding_door_bottom_left_open", "_bottom_left_open", class_4945.field_23015, class_4945.field_23014);
        PAPER_SLIDING_DOOR_BOTTOM_RIGHT = block("paper_sliding_door_bottom_right", "_bottom_right", class_4945.field_23015, class_4945.field_23014);
        PAPER_SLIDING_DOOR_BOTTOM_RIGHT_OPEN = block("paper_sliding_door_bottom_right_open", "_bottom_right_open", class_4945.field_23015, class_4945.field_23014);
        PAPER_SLIDING_DOOR_TOP_LEFT = block("paper_sliding_door_top_left", "_top_left", class_4945.field_23015, class_4945.field_23014);
        PAPER_SLIDING_DOOR_TOP_LEFT_OPEN = block("paper_sliding_door_top_left_open", "_top_left_open", class_4945.field_23015, class_4945.field_23014);
        PAPER_SLIDING_DOOR_TOP_RIGHT = block("paper_sliding_door_top_right", "_top_right", class_4945.field_23015, class_4945.field_23014);
        PAPER_SLIDING_DOOR_TOP_RIGHT_OPEN = block("paper_sliding_door_top_right_open", "_top_right_open", class_4945.field_23015, class_4945.field_23014);
    }

    private static class_4942 block(String parent, String variant, class_4945... requiredTextureKeys) {
        return new class_4942(Optional.of(class_2960.method_60655(Furniture.MOD_ID,"block/furniture/door/" + parent)), Optional.of(variant), requiredTextureKeys);
    }
}
