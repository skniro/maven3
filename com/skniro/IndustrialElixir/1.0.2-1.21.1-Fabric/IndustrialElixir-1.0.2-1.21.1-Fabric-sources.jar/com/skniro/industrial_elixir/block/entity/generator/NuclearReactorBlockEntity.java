package com.skniro.industrial_elixir.block.entity.generator;

import com.skniro.industrial_elixir.api.block.ImplementedInventory;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.generator.NuclearReactorBlock;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.EnergyStorageUtil;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.init.ReactorComponentItem;
import com.skniro.industrial_elixir.registry.tag.ModItemTags;
import com.skniro.industrial_elixir.screen.handler.generator.NuclearReactorScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public class NuclearReactorBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory {
    public static final int GRID_WIDTH = 9;
    public static final int GRID_HEIGHT = 6;
    public static final int REACTOR_SLOT_COUNT = GRID_WIDTH * GRID_HEIGHT;
    public static final int BATTERY_SLOT = REACTOR_SLOT_COUNT;
    private static final int BASE_MAX_HEAT = 10000;
    private static final int ENERGY_PER_PULSE = 20;
    private static final int ENERGY_TRANSFER_AMOUNT = 2048;
    private static final int HEAT_VENT_ADJACENCY_BONUS = 4;
    private static final int HEAT_VENT_COOLANT_ADJACENCY_BONUS = 2;
    private static final int HEAT_VENT_VENT_ADJACENCY_BONUS = 1;

    private final class_2371<class_1799> inventory = class_2371.method_10213(REACTOR_SLOT_COUNT + 1, class_1799.field_8037);
    public final com.skniro.industrial_elixir.energy.api.base.SimpleSidedEnergyContainer energyContainer;
    private int heat;
    private int maxHeat = BASE_MAX_HEAT;
    private int generation;
    private boolean active;
    private static final int DURABILITY_TICK_INTERVAL = 40; // 1 durability point per 2 seconds
    private int durabilityTickCounter = 0;

    private final class_3913 propertyDelegate;

    public NuclearReactorBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.NUCLEAR_REACTOR_BE, pos, state);
        this.energyContainer = new com.skniro.industrial_elixir.energy.api.base.SimpleSidedEnergyContainer() {
            @Override
            public long getCapacity() {
                return 10000000;
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                return side == null ? EnergyTier.TIER4.getMaxInput() : 0;
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                return EnergyTier.TIER4.getMaxOutput();
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(field_11867, method_11010(), method_11010(), 3);
            }
        };
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> NuclearReactorBlockEntity.this.heat;
                    case 1 -> NuclearReactorBlockEntity.this.maxHeat;
                    case 2 -> NuclearReactorBlockEntity.this.generation;
                    case 3 -> (int) Math.min(Integer.MAX_VALUE, NuclearReactorBlockEntity.this.energyContainer.amount);
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0 -> NuclearReactorBlockEntity.this.heat = value;
                    case 1 -> NuclearReactorBlockEntity.this.maxHeat = value;
                    case 2 -> NuclearReactorBlockEntity.this.generation = value;
                }
            }

            @Override
            public int method_17389() {
                return 4;
            }
        };
    }

    @Override
    protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        class_1262.method_5426(output, inventory, registries);
        output.method_10569("nuclear_reactor.heat", heat);
        output.method_10569("nuclear_reactor.max_heat", maxHeat);
        output.method_10569("nuclear_reactor.generation", generation);
        output.method_10544("nuclear_reactor.energy", energyContainer.amount);
        output.method_10556("nuclear_reactor.active", active);
    }

    @Override
    protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        class_1262.method_5429(input, inventory, registries);
        heat = (input.method_10545("nuclear_reactor.heat") ? input.method_10550("nuclear_reactor.heat") : 0);
        maxHeat = (input.method_10545("nuclear_reactor.max_heat") ? input.method_10550("nuclear_reactor.max_heat") : BASE_MAX_HEAT);
        generation = (input.method_10545("nuclear_reactor.generation") ? input.method_10550("nuclear_reactor.generation") : 0);
        energyContainer.amount = (input.method_10545("nuclear_reactor.energy") ? input.method_10537("nuclear_reactor.energy") : 0);
        active = (input.method_10545("nuclear_reactor.active") ? input.method_10577("nuclear_reactor.active") : false);
        super.method_11014(input, registries);
    }

    public void tick(class_1937 level, class_2338 pos, class_2680 state) {
        if (level.method_8608()) {
            return;
        }

        chargeBattery();
        pushEnergyToNeighbours();
        maxHeat = calculateMaxHeat();
        generation = 0;

        int heatGenerated = 0;
        for (int slot = 0; slot < REACTOR_SLOT_COUNT; slot++) {
            class_1799 stack = inventory.get(slot);
            if (stack.method_7909() instanceof ReactorComponentItem component && component.isFuelRod()) {
                int pulses = component.getRodCount() * (1 + getAdjacentComponentEffect(slot, true));
                generation += pulses * ENERGY_PER_PULSE;
                heatGenerated += pulses * pulses * 4;
                damageOrConsume(stack, slot, 1);
            }
        }

        if (generation > 0) {
            insertGeneratedEnergy(generation);
        }

        heat += heatGenerated;
        coolReactor();
        active = generation > 0;

        if (heat >= maxHeat) {
            meltdown(level, pos);
            return;
        }

        if (state.method_11654(NuclearReactorBlock.LIT) != active) {
            level.method_8652(pos, state.method_11657(NuclearReactorBlock.LIT, active), class_2248.field_31036);
        }
        method_31663(level, pos, state);
    }

    private void insertGeneratedEnergy(int amount) {
        try (Transaction transaction = Transaction.openOuter()) {
            energyContainer.getSideStorage(null).insert(amount, transaction);
            transaction.commit();
        }
    }

    private void chargeBattery() {
        class_1263 inventory = this;
        EnergyStorageUtil.move(
                this.energyContainer.getSideStorage(null),
                ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(BATTERY_SLOT)).find(EnergyStorage.ITEM),
                Long.MAX_VALUE,
                null
        );
    }

    private void pushEnergyToNeighbours() {
        if (energyContainer.amount <= 0) {
            return;
        }
        for (class_2350 direction : class_2350.values()) {
            EnergyStorage target = EnergyStorage.SIDED.find(field_11863, field_11867.method_10093(direction), direction.method_10153());
            if (target == null) {
                continue;
            }
            EnergyStorageUtil.move(energyContainer.getSideStorage(direction), target, ENERGY_TRANSFER_AMOUNT, null);
        }
    }

    private int calculateMaxHeat() {
        int value = BASE_MAX_HEAT;
        for (int slot = 0; slot < REACTOR_SLOT_COUNT; slot++) {
            class_1799 stack = inventory.get(slot);
            if (stack.method_7909() instanceof ReactorComponentItem component) {
                value += component.getExtraMaxHeat();
            }
        }
        return value;
    }

    private void coolReactor() {
        durabilityTickCounter++;
        
        // Only apply durability damage every DURABILITY_TICK_INTERVAL (40) ticks = 2 seconds
        boolean shouldApplyDamage = durabilityTickCounter >= DURABILITY_TICK_INTERVAL;
        if (shouldApplyDamage) {
            durabilityTickCounter = 0;
        }
        
        for (int slot = 0; slot < REACTOR_SLOT_COUNT && heat > 0; slot++) {
            class_1799 stack = inventory.get(slot);
            if (!(stack.method_7909() instanceof ReactorComponentItem component)) {
                continue;
            }

            int cooling = 0;

            if (component.getComponentType() == ReactorComponentItem.ComponentType.COOLANT_CELL) {
                cooling = component.getCoolingPerTick(stack);
            } else if (component.getComponentType() == ReactorComponentItem.ComponentType.HEAT_VENT) {
                cooling = getHeatVentEffectiveCooling(slot);
            } else if (component.getComponentType() == ReactorComponentItem.ComponentType.HEAT_EXCHANGER) {
                cooling = getHeatExchangerEffectiveCooling(slot);
            }

            if (cooling > 0) {
                int actualCooling = Math.min(heat, cooling);
                heat -= actualCooling;
                // Apply 1 durability damage only once every 40 ticks
                if (shouldApplyDamage) {
                    damageOrConsume(stack, slot, 1);
                }
            }
        }
    }

    private boolean isNeutronReflectorAt(int x, int y) {
        if (x < 0 || x >= GRID_WIDTH || y < 0 || y >= GRID_HEIGHT) {
            return false;
        }
        class_1799 stack = inventory.get(y * GRID_WIDTH + x);
        return stack.method_7909() instanceof ReactorComponentItem component && component.getComponentType() == ReactorComponentItem.ComponentType.NEUTRON_REFLECTOR;
    }

    private boolean isHeatVentAt(int x, int y) {
        if (x < 0 || x >= GRID_WIDTH || y < 0 || y >= GRID_HEIGHT) {
            return false;
        }
        class_1799 stack = inventory.get(y * GRID_WIDTH + x);
        return stack.method_7909() instanceof ReactorComponentItem component && component.getComponentType() == ReactorComponentItem.ComponentType.HEAT_VENT;
    }

    private boolean isCoolantCellAt(int x, int y) {
        if (x < 0 || x >= GRID_WIDTH || y < 0 || y >= GRID_HEIGHT) {
            return false;
        }
        class_1799 stack = inventory.get(y * GRID_WIDTH + x);
        return stack.method_7909() instanceof ReactorComponentItem component && component.getComponentType() == ReactorComponentItem.ComponentType.COOLANT_CELL;
    }

    private boolean isHeatExchangerAt(int x, int y) {
        if (x < 0 || x >= GRID_WIDTH || y < 0 || y >= GRID_HEIGHT) {
            return false;
        }
        class_1799 stack = inventory.get(y * GRID_WIDTH + x);
        return stack.method_7909() instanceof ReactorComponentItem component && component.getComponentType() == ReactorComponentItem.ComponentType.HEAT_EXCHANGER;
    }

    private int getHeatVentEffectiveCooling(int slot) {
        class_1799 stack = inventory.get(slot);
        if (!(stack.method_7909() instanceof ReactorComponentItem component) || component.getComponentType() != ReactorComponentItem.ComponentType.HEAT_VENT) {
            return 0;
        }

        int effectiveCooling = component.getHeatVentCoolingAmount();
        int x = slot % GRID_WIDTH;
        int y = slot / GRID_WIDTH;

        int[][] adjacentOffsets = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

        for (int[] offset : adjacentOffsets) {
            int adjX = x + offset[0];
            int adjY = y + offset[1];

            if (isFuelAt(adjX, adjY)) {
                effectiveCooling += HEAT_VENT_ADJACENCY_BONUS;
            } else if (isCoolantCellAt(adjX, adjY)) {
                effectiveCooling += HEAT_VENT_COOLANT_ADJACENCY_BONUS;
            } else if (isHeatVentAt(adjX, adjY)) {
                effectiveCooling += HEAT_VENT_VENT_ADJACENCY_BONUS;
            } else if (isHeatExchangerAt(adjX, adjY)) {
                effectiveCooling += HEAT_VENT_VENT_ADJACENCY_BONUS;
            }
        }
        return effectiveCooling;
    }

    private int getHeatExchangerEffectiveCooling(int slot) {
        class_1799 stack = inventory.get(slot);
        if (!(stack.method_7909() instanceof ReactorComponentItem component) || component.getComponentType() != ReactorComponentItem.ComponentType.HEAT_EXCHANGER) {
            return 0;
        }

        int effectiveCooling = component.getHeatExchangerCoolingAmount();
        int x = slot % GRID_WIDTH;
        int y = slot / GRID_WIDTH;

        int[][] adjacentOffsets = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        for (int[] offset : adjacentOffsets) {
            int adjX = x + offset[0];
            int adjY = y + offset[1];

            if (isFuelAt(adjX, adjY)) {
                effectiveCooling += component.getHeatExchangerTransferAmount();
            } else if (isCoolantCellAt(adjX, adjY) || isHeatVentAt(adjX, adjY)) {
                effectiveCooling += component.getHeatExchangerTransferAmount() / 2;
            }
        }
        return effectiveCooling;
    }

    private int getAdjacentComponentEffect(int slot, boolean damageReflectors) {
        int effect = 0;
        int x = slot % GRID_WIDTH;
        int y = slot / GRID_WIDTH;

        int[][] adjacentOffsets = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

        for (int[] offset : adjacentOffsets) {
            int adjX = x + offset[0];
            int adjY = y + offset[1];

            if (isFuelAt(adjX, adjY)) {
                effect += 1; // Each adjacent fuel rod adds 1 to the pulse multiplier
            } else if (isNeutronReflectorAt(adjX, adjY)) {
                class_1799 adjacentStack = inventory.get(adjY * GRID_WIDTH + adjX);
                if (adjacentStack.method_7909() instanceof ReactorComponentItem component) {
                    effect += component.getNeutronReflectionBonus();
                    if (damageReflectors) {
                        damageOrConsume(adjacentStack, adjY * GRID_WIDTH + adjX, 1);
                    }
                }
            }
        }
        return effect;
    }

    private boolean isFuelAt(int x, int y) {
        if (x < 0 || x >= GRID_WIDTH || y < 0 || y >= GRID_HEIGHT) {
            return false;
        }
        class_1799 stack = inventory.get(y * GRID_WIDTH + x);
        return stack.method_7909() instanceof ReactorComponentItem component && component.isFuelRod();
    }

    private void damageOrConsume(class_1799 stack, int slot, int amount) {
        if (!stack.method_7963()) {
            return;
        }
        stack.method_7974(stack.method_7919() + amount);
        if (stack.method_7919() >= stack.method_7936()) {
            inventory.set(slot, class_1799.field_8037);
        }
    }

    private void meltdown(class_1937 level, class_2338 pos) {
        class_1264.method_5451(level, pos, this);
        level.method_8650(pos, false);
        level.method_8537(null, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, 6.0f, true, class_1937.class_7867.field_40889);
    }

    public boolean canPlaceComponent(class_1799 stack) {
        return stack.method_7909() instanceof ReactorComponentItem || stack.method_31573(ModItemTags.BATTERY);
    }

    public long getEnergy() {
        return energyContainer.amount;
    }

    public long getEnergyCapacity() {
        return energyContainer.getCapacity();
    }

    public int getHeat() {
        return heat;
    }

    public int getMaxHeat() {
        return maxHeat;
    }

    public int getGeneration() {
        return generation;
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return field_11867;
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.NuclearReactor);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new NuclearReactorScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    @Override
    public int[] method_5494(class_2350 side) {
        int[] slots = new int[inventory.size()];
        for (int i = 0; i < slots.length; i++) {
            slots[i] = i;
        }
        return slots;
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        if (slot == BATTERY_SLOT) {
            return stack.method_31573(ModItemTags.BATTERY);
        }
        return stack.method_7909() instanceof ReactorComponentItem;
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}
