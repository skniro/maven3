package com.skniro.industrial_elixir.compat.jei.category;

import com.skniro.industrial_elixir.api.Helper;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.machine.MolecularTransformerCraftingRecipe;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableAnimated;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_8786;
import mezz.jei.api.recipe.RecipeType;

public class MolecularTransformerCategory implements IRecipeCategory<class_8786<MolecularTransformerCraftingRecipe>> {

    public static final RecipeType<class_8786<MolecularTransformerCraftingRecipe>> TYPE =
            RecipeType.createFromVanilla(AlchemyRecipeType.MOLECULAR_TRANSFORMER.type);

    private final IDrawable background;
    private final IDrawable icon;

    private final IDrawableAnimated arrow;

    public MolecularTransformerCategory(IGuiHelper helper) {
        class_2960 texture = Helper.id( "textures/gui/container/machine/molecular_transformer.png");

        background = helper.createDrawable(texture, 0, 0, 175, 82);

        icon = helper.createDrawableIngredient(VanillaTypes.ITEM_STACK,
                new class_1799(GrowableOresBlocks.MolecularTransformerBlock));

        this.arrow = helper.drawableBuilder(Helper.id("textures/gui/container/machine/molecular_transformer.png"), 194, 2, 23, 12).buildAnimated(72, IDrawableAnimated.StartDirection.LEFT, false);
    }

    @Override
    public RecipeType<class_8786<MolecularTransformerCraftingRecipe>> getRecipeType() {
        return TYPE;
    }

    @Override
    public class_2561 getTitle() {
        return class_2561.method_43471(FurnitureStrings.MolecularTransformer);
    }

    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public int getWidth() {
        return background.getWidth();
    }

    @Override
    public int getHeight() {
        return background.getHeight();
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, class_8786<MolecularTransformerCraftingRecipe> recipe, IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 52, 33)
                .addIngredients(recipe.comp_1933().ingredient());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 100, 34)
                .addItemStack(recipe.comp_1933().output());
    }

    @Override
    public void draw(class_8786<MolecularTransformerCraftingRecipe> recipe, IRecipeSlotsView slots, class_332 guiGraphics, double mouseX, double mouseY) {
        background.draw(guiGraphics);

        arrow.draw(guiGraphics, 74, 37);

        int count = recipe.comp_1933().requiredCount();

        if (count > 1) {
            class_327 font = class_310.method_1551().field_1772;
            String text = String.valueOf(count);

            int x = 52 + 16 - font.method_1727(text) - 1;
            int y = 13 + 16 - 8 - 1;

            guiGraphics.method_51433(font, text, x, y, 0xFFFFFFFF, true);
        }

        long energy = recipe.comp_1933().getEnergyRequired();

        class_327 font = class_310.method_1551().field_1772;
        String text = "Energy:" + energy;

        int x = 72 + 16 - font.method_1727(text) - 1;
        int y = 53 + 16 - 8 - 1;

        guiGraphics.method_51433(font, text, x, y, 0xFFFFFFFF, true);
    }
}