package com.skniro.growable_ores_extension.item.init.tool;


import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.minecraft.class_3481;
import net.minecraft.class_9886;

public class MapleToolMaterials {
    public static final class_9886 BRONZE = new class_9886(class_3481.field_49927, 340, 6.0F, 2.0F, 14, ModItemTags.BRONZE_TOOL_MATERIALS);
}
