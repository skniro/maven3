package com.skniro.growable_ores_extension.item.init;

import com.skniro.growable_ores_extension.item.GrowableOresItems;
import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_5819;

public class ScrapboxItem extends class_1792 {
    public ScrapboxItem(class_1793 settings) {
        super(settings);
    }

    private static final Map<class_1792, Double> SCRAPBOX_DROPS = Map.ofEntries(
            Map.entry(class_1802.field_8894, 0.0008),    // 0.08%
            Map.entry(class_1802.field_20398, 0.0387), // 3.87%
            Map.entry(class_1802.field_8261, 0.0174),
            Map.entry(class_1802.field_8862, 0.0002),
            Map.entry(class_1802.field_8876, 0.0193),
            Map.entry(class_1802.field_17534, 0.0097),
            Map.entry(class_1802.field_8745, 0.0193),
            Map.entry(class_1802.field_8279, 0.0290),
            Map.entry(class_1802.field_8599, 0.0097),
            Map.entry(GrowableOresItems.TIN_INGOT, 0.0290),
            Map.entry(class_1802.field_8788, 0.0193),
            Map.entry(class_1802.field_8091, 0.0193),
            Map.entry(class_1802.field_8176, 0.0174),
            Map.entry(class_1802.field_8713, 0.0155),
            Map.entry(GrowableOresItems.TIN_DUST, 0.0155),
            Map.entry(class_1802.field_8477, 0.0019),
            Map.entry(class_1802.field_8606, 0.0193),
            Map.entry(GrowableOresItems.IRON_DUST, 0.0135),
            Map.entry(class_1802.field_8634, 0.0015),
            Map.entry(class_1802.field_8725, 0.0174),
            Map.entry(class_1802.field_8045, 0.0002),
            Map.entry(class_1802.field_8831, 0.0967),
            Map.entry(class_1802.field_8229, 0.0290),
            Map.entry(class_1802.field_8600, 0.0774),
            Map.entry(class_1802.field_8647, 0.0193),
            Map.entry(GrowableOresItems.Raw_Tin, 0.0135),
            Map.entry(class_1802.field_8511, 0.0387),
            Map.entry(class_1802.field_8270, 0.0580),
            Map.entry(class_1802.field_8544, 0.0174),
            Map.entry(class_1802.field_8775, 0.0097),
            Map.entry(class_1802.field_8601, 0.0155),
            Map.entry(class_1802.field_8687, 0.0010),
            Map.entry(class_1802.field_17518, 0.0174),
            Map.entry(class_1802.field_8110, 0.0580),
            Map.entry(class_1802.field_8167, 0.0969),
            Map.entry(GrowableOresItems.GOLD_DUST, 0.0135),
            Map.entry(GrowableOresItems.COPPER_DUST, 0.0155),
            Map.entry(class_1802.field_8777, 0.0116),
            Map.entry(class_1802.field_8153, 0.0193),
            Map.entry(GrowableOresItems.RE_BATTERY, 0.0135),
            Map.entry(class_1802.field_33401, 0.0135),
            Map.entry(class_1802.field_8067, 0.0193),
            Map.entry(GrowableOresItems.Rubber, 0.0155),
            Map.entry(class_1802.field_8803, 0.0155)
    );

    private class_1799 rollScrapboxDrop(class_5819 random) {
        double r = random.method_43058();
        double cumulative = 0.0;

        for (Map.Entry<class_1792, Double> entry : SCRAPBOX_DROPS.entrySet()) {
            cumulative += entry.getValue();
            if (r < cumulative) {
                if (entry.getKey() == null) return class_1799.field_8037;
                return new class_1799(entry.getKey());
            }
        }
        return class_1799.field_8037;
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (!world.method_8608()) {
            class_1799 drop = rollScrapboxDrop(world.field_9229);
            if (!drop.method_7960()) {
                double dx = -Math.sin(Math.toRadians(player.method_36454())) * 0.5;
                double dz = Math.cos(Math.toRadians(player.method_36454())) * 0.5;
                double dy = 0.2;
                class_1542 itemEntity = new class_1542(world, player.method_23317() + dx, player.method_23318() + player.method_5751() - 0.3, player.method_23321() + dz, drop);
                itemEntity.method_18800(dx * 0.5, dy, dz * 0.5);
                itemEntity.method_6982(40);
                world.method_8649(itemEntity);
            }
            if (!player.method_68878()) {
                stack.method_7934(1);
            }
        }
        return class_1269.field_5812;
    }

}
