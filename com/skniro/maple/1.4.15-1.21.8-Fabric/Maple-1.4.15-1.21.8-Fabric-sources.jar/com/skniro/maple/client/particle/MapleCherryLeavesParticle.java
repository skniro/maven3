package com.skniro.maple.client.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;

@Environment(EnvType.CLIENT)
public class MapleCherryLeavesParticle extends class_4003 {
    private static final float field_43372 = 0.0025F;
    private static final int field_43373 = 300;
    private static final int field_43366 = 300;
    private static final float field_43367 = 0.25F;
    private static final float field_43368 = 2.0F;
    private float field_43369;
    private final float field_43370;
    private final float field_43371;

    public MapleCherryLeavesParticle(class_638 world, double x, double y, double z, class_4002 spriteProvider) {
        super(world, x, y, z);
        this.method_18141(spriteProvider.method_18138(this.field_3840.method_43048(12), 12));
        this.field_43369 = (float)Math.toRadians(this.field_3840.method_43056() ? -30.0D : 30.0D);
        this.field_43370 = this.field_3840.method_43057();
        this.field_43371 = (float)Math.toRadians(this.field_3840.method_43056() ? -5.0D : 5.0D);
        this.field_3847 = 300;
        this.field_3844 = 7.5E-4F;
        float f = this.field_3840.method_43056() ? 0.05F : 0.075F;
        this.field_17867 = f;
        this.method_3080(f, f);
        this.field_28786 = 1.0F;
    }

    public class_3999 method_18122() {
        return class_3999.field_17828;
    }

    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        if (this.field_3847-- <= 0) {
            this.method_3085();
        }

        if (!this.field_3843) {
            float f = (float)(300 - this.field_3847);
            float g = Math.min(f / 300.0F, 1.0F);
            double d = Math.cos(Math.toRadians((double)(this.field_43370 * 60.0F))) * 2.0D * Math.pow((double)g, 1.25D);
            double e = Math.sin(Math.toRadians((double)(this.field_43370 * 60.0F))) * 2.0D * Math.pow((double)g, 1.25D);
            this.field_3852 += d * 0.0024999999441206455D;
            this.field_3850 += e * 0.0024999999441206455D;
            this.field_3869 -= (double)this.field_3844;
            this.field_43369 += this.field_43371 / 20.0F;
            this.field_3857 = this.field_3839;
            this.field_3839 += this.field_43369 / 20.0F;
            this.method_3069(this.field_3852, this.field_3869, this.field_3850);
            if (this.field_3845 || this.field_3847 < 299 && (this.field_3852 == 0.0D || this.field_3850 == 0.0D)) {
                this.method_3085();
            }

            if (!this.field_3843) {
                this.field_3852 *= (double)this.field_28786;
                this.field_3869 *= (double)this.field_28786;
                this.field_3850 *= (double)this.field_28786;
            }
        }
    }
}
