package com.skniro.industrial_elixir.block.entity.machine.fluid;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.fluid.CoffeeMachineBlock;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.machine.AbstractMachineCraftingRecipe;
import com.skniro.industrial_elixir.recipe.machine.CoffeeMachineCraftingRecipe;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.CoffeeMachineScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1264;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class CoffeeMachineBlockEntity extends AbstractFluidMachineEntity {


    public CoffeeMachineBlockEntity(class_2338 pos, class_2680 blockState) {
        super(AlchemyBlockEntityType.COFFEE_MACHINE_BLOCK_ENTITY_BLOCK_ENTITY_TYPE, pos, blockState);
        this.DEFAULT_MAX_PROGRESS = 200;
        this.maxProgress = 200;
    }

    // 40/20 = 2 EU/t
    @Override
    public long getCraftEnergyCost() {
        return 40;
    }

    @Override
    protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        SingleVariantStorage.writeNbt(fluidContainer, FluidVariant.CODEC, output, registries);
    }

    @Override
    protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        super.method_11014(input, registries);
        SingleVariantStorage.readNbt(fluidContainer, FluidVariant.CODEC, FluidVariant::blank, input, registries);
    }

    public void drops() {
        class_1264.method_17349(this.field_11863, this.field_11867, inventory);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.CoffeeMachine);
    }

    @Override
    public @Nullable class_1703 createMenu(int containerId, class_1661 inventory, class_1657 player) {
        return new CoffeeMachineScreenHandler(containerId, inventory, this, this.propertyDelegate);
    }

    @Override
    protected void craftItem() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> recipe = getCurrentRecipe();
        if (recipe.isEmpty()) return;

        CoffeeMachineCraftingRecipe coffeeRecipe = (CoffeeMachineCraftingRecipe) recipe.get().comp_1933();
        class_1799 output = coffeeRecipe.output().method_7972();

        this.method_5434(INPUT_SLOT, coffeeRecipe.requiredCount());

        if (coffeeRecipe.ingredient2().isPresent()) {
            this.method_5434(SECOND_INPUT_SLOT, 1);
        }

        if (coffeeRecipe.ingredient3().isPresent()) {
            this.method_5434(THIRD_INPUT_SLOT, 1);
        }

        if (this.method_5438(OUTPUT_SLOT).method_7960()) {
            this.method_5447(OUTPUT_SLOT, output.method_7972());
        } else {
            this.method_5438(OUTPUT_SLOT).method_7933(output.method_7947());
        }

        extractFluidForCrafting();
    }

    @Override
    public void extractFluidForCrafting() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> recipeOpt = getCurrentRecipe();
        if (recipeOpt.isEmpty() || !(recipeOpt.get().comp_1933() instanceof CoffeeMachineCraftingRecipe coffeeRecipe)) {
            return;
        }
        try (Transaction transaction = Transaction.openOuter()) {
            fluidContainer.extract(fluidContainer.getResource(), coffeeRecipe.requiredFluidAmount(), transaction);
            transaction.commit();
        }
    }

    /* SIDED INVENTORY */
    @Override
    public boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 side) {
        if (side == null || side == class_2350.field_11033) return false;
        if (side == class_2350.field_11036) {
            return slot == INPUT_SLOT || slot == SECOND_INPUT_SLOT || slot == THIRD_INPUT_SLOT;
        }

        if (slot != INPUT_SLOT && slot != SECOND_INPUT_SLOT && slot != THIRD_INPUT_SLOT
                && slot != FLUID_ITEM_SLOT && slot != ENERGY_ITEM_SLOT) {
            return false;
        }

        class_2350 localDir = this.field_11863.method_8320(this.method_11016()).method_11654(CoffeeMachineBlock.FACING);
        return switch (slot) {
            case INPUT_SLOT, SECOND_INPUT_SLOT, THIRD_INPUT_SLOT -> side != localDir.method_10153();
            case FLUID_ITEM_SLOT -> side == localDir.method_10170();
            case ENERGY_ITEM_SLOT -> side == localDir.method_10160();
            default -> false;
        };
    }

    @Override
    public boolean method_5493(int slot, class_1799 stack, class_2350 side) {
        if (slot != OUTPUT_SLOT || side == class_2350.field_11036) {
            return false;
        }

        if (side == class_2350.field_11033) {
            return true;
        }

        class_2350 localDir = this.field_11863.method_8320(this.method_11016()).method_11654(CoffeeMachineBlock.FACING);
        return side == localDir.method_10153() || side == localDir.method_10170();
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return slot != OUTPUT_SLOT;
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return AlchemyRecipeType.COFFEE_MACHINE.type;
    }

    @Override
    public int[] method_5494(class_2350 direction) {
        if (direction != class_2350.field_11033) {
            return new int[]{INPUT_SLOT, SECOND_INPUT_SLOT, THIRD_INPUT_SLOT, FLUID_ITEM_SLOT, ENERGY_ITEM_SLOT};
        } else {
            return new int[]{OUTPUT_SLOT};
        }
    }

    @Override
    public Optional<class_8786<AbstractMachineCraftingRecipe>> getCurrentRecipe() {
        return this.method_10997().method_8503().method_3772()
                .method_8132((class_3956<AbstractMachineCraftingRecipe>) getCurrentRecipeType(),
                        new AlchemyCraftingRecipeInput(
                                inventory.get(INPUT_SLOT),
                                inventory.get(SECOND_INPUT_SLOT),
                                inventory.get(THIRD_INPUT_SLOT)), this.method_10997());
    }

    @Override
    public boolean hasRecipe() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> opt = getCurrentRecipe();
        if (opt.isEmpty()) return false;

        var recipeHolder = opt.get();
        var recipe = recipeHolder.comp_1933();
        CoffeeMachineCraftingRecipe coffeeRecipe = (CoffeeMachineCraftingRecipe) recipe;
        class_1799 output = coffeeRecipe.output().method_7972();

        if (!canInsertAmountIntoOutputSlot(output.method_7947()) || !canInsertItemIntoOutputSlot(output)) return false;
        if (!hasEnoughEnergyToCraft()) return false;

        // Check fluid requirement
        var currentFluid = this.fluidContainer.getResource().getFluid();
        var currentId = class_7923.field_41173.method_10221(currentFluid);
        if (currentId == null || !coffeeRecipe.requiredFluid().equals(currentId)) return false;
        if (this.fluidContainer.getAmount() < coffeeRecipe.requiredFluidAmount()) return false;

        return true;
    }
}
