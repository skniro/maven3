package com.skniro.industrial_elixir.api.data.recipe;

import com.skniro.industrial_elixir.recipe.machine.CuttingCraftingRecipe;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_161;
import net.minecraft.class_170;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2119;
import net.minecraft.class_2960;
import net.minecraft.class_5797;
import net.minecraft.class_6862;
import net.minecraft.class_7871;
import net.minecraft.class_8782;
import net.minecraft.class_8790;

public class CuttingRecipeJsonBuilder implements class_5797 {
    private final class_7871<class_1792> itemLookup;
    private class_1856 ingredient;
    private final class_1799 result;
    private int requiredCount;
    private final Map<String, class_175<?>> criteria = new LinkedHashMap<>();

    @Nullable
    private String group;

    private CuttingRecipeJsonBuilder(class_7871<class_1792> itemLookup, class_1799 result) {
        this.itemLookup = itemLookup;
        this.result = result;
    }

    public static CuttingRecipeJsonBuilder create(class_7871<class_1792> itemLookup, class_1935 output, int count) {
        return new CuttingRecipeJsonBuilder(itemLookup, new class_1799(output.method_8389(), count));
    }

    public static CuttingRecipeJsonBuilder create(class_7871<class_1792> itemLookup, class_1935 output) {
        return create(itemLookup, output, 1);
    }

    public CuttingRecipeJsonBuilder input(class_1935 item) {
        return input(item, 1);
    }

    public CuttingRecipeJsonBuilder input(class_1935 item, int amount) {
        this.ingredient = class_1856.method_8091(item);
        this.requiredCount = amount;
        return this;
    }
    public CuttingRecipeJsonBuilder input(class_6862<class_1792> tag) {
        return input(tag, 1);
    }

    public CuttingRecipeJsonBuilder input(class_6862<class_1792> tag, int amount) {
        this.ingredient = class_1856.method_8106(tag);
        this.requiredCount = amount;
        return this;
    }


    public CuttingRecipeJsonBuilder method_33530(String name,
                                              class_175<?> criterion) {
        this.criteria.put(name, criterion);
        return this;
    }

    public CuttingRecipeJsonBuilder method_33529(@Nullable String group) {
        this.group = group;
        return this;
    }

    @Override
    public class_1792 method_36441() {
        return this.result.method_7909();
    }

    @Override
    public void method_17972(class_8790 exporter, class_2960 recipeId) {
        class_2960 finalRecipeId = modifyRecipeKey(recipeId, exporter);
        CuttingCraftingRecipe recipe = new CuttingCraftingRecipe(ingredient, requiredCount, result);
        if (criteria.isEmpty()) {
            exporter.method_53819(finalRecipeId, recipe, null);
            return;
        }

        class_161.class_162 advancementBuilder = exporter.method_53818().method_705("has_the_recipe", class_2119.method_27847(recipeId)).method_703(class_170.class_171.method_753(recipeId)).method_704(class_8782.class_8797.field_1257);

        this.criteria.forEach(advancementBuilder::method_705);

        exporter.method_53819(finalRecipeId, recipe, advancementBuilder.method_695(finalRecipeId.method_45138("recipes/")));

    }

    private class_2960 modifyRecipeKey(class_2960 recipeId, class_8790 exporter) {
        return exporter.getRecipeIdentifier(recipeId.method_45138("cutting/"));
    }
}