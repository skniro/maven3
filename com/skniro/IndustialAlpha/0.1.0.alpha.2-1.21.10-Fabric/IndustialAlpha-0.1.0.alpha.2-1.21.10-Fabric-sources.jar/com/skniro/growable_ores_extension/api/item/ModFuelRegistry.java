package com.skniro.growable_ores_extension.api.item;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_6862;

public class ModFuelRegistry {
    private static final Map<class_1792, Integer> MOD_FUEL = new HashMap<>();
    private static final Map<class_6862<class_1792>, Integer> MOD_FUEL_TAGS = new HashMap<>();

    public static void registerFuel(class_1792 item, int burnTime) {
        MOD_FUEL.put(item, burnTime);
    }

    public static void registerFuel(class_6862<class_1792> tag, int burnTime) {
        MOD_FUEL_TAGS.put(tag, burnTime);
    }

    public static Map<class_1792, Integer> getModFuel() {
        return Collections.unmodifiableMap(MOD_FUEL);
    }

    public static Map<class_6862<class_1792>, Integer> getModFuelTags() {
        return Collections.unmodifiableMap(MOD_FUEL_TAGS);
    }
}
