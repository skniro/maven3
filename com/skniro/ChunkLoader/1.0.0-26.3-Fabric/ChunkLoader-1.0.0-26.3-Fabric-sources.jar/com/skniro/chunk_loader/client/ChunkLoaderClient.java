package com.skniro.chunk_loader.client;

import com.skniro.chunk_loader.screen.ingame.machine.ChunkLoaderScreen;
import com.skniro.chunk_loader.screen.AlchemyScreenHandlerType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;

@Environment(EnvType.CLIENT)
public class ChunkLoaderClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

        ChunkSectionLayer renderLayer2 = ChunkSectionLayer.CUTOUT;


        ChunkSectionLayer renderLayer3 = ChunkSectionLayer.TRANSLUCENT;

        MenuScreens.register(AlchemyScreenHandlerType.ChunkLoader, ChunkLoaderScreen::new);

    }
}
