package com.skniro.industrial_elixir.screen.slot;

import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.api.item.TieredEnergyItem;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_5151;

public class ChestplateSlot extends BatteryChargeSlot {
    public ChestplateSlot(class_1263 inventory, int index, int x, int y, EnergyTier energyTier) {
        super(inventory, index, x, y, energyTier);
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        class_5151 equippable = class_5151.method_48957(stack);
        if (equippable == null) return false;
        if (equippable.method_7685() != class_1304.field_6174) return false;
        if (stack.method_7909() instanceof TieredEnergyItem tiered) {return tiered.getEnergyTier().ordinal() >= this.energyTier.ordinal();}
        return false;
    }

}
