package com.skniro.growable_ores_extension.block.entity.pipe;

import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public class WoodPipeBlockEntity extends PipeBlockEntity {

    public WoodPipeBlockEntity(BlockPos pos, BlockState state) {
        super(AlchemyBlockEntityType.PIPE_Wooden_BLOCK_ENTITY,pos, state);
    }


    public void tick(Level world, BlockPos pos, BlockState state) {
        if (world.isClientSide()) return;
        super.tick(world, pos, state);
        moveItems(world, pos, state);
        extractItems(world, pos, state);
    }
}
