package torcherino.block;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3749;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_9904;
import torcherino.api.TierSupplier;
import torcherino.block.entity.TorcherinoBlockEntity;

public final class LanterinoBlock extends class_3749 implements class_2343, TierSupplier {
    private final class_2960 tierID;

    public LanterinoBlock(class_2251 properties, class_2960 tier) {
        super(properties);
        this.tierID = tier;
    }

    private static boolean isEmittingStrongRedstonePower(class_1937 level, class_2338 pos, class_2350 direction) {
        return level.method_8320(pos).method_26203(level, pos, direction) > 0;
    }

    @Override
    public class_2960 getTier() {
        return tierID;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new TorcherinoBlockEntity(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
        return TorcherinoLogic.getTicker(level, state, type);
    }

    @Deprecated
    public class_3619 getPistonPushReaction() {
        return class_3619.field_15975;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_9615(class_2680 newState, class_1937 level, class_2338 pos, class_2680 state, boolean boolean_1) {
        this.method_9612(null, level, pos, null, null, false);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        class_1268 hand = class_1268.field_5808;
        return TorcherinoLogic.useWithoutItem(state, level, pos, player, hand, hit);
    }


    @Override
    @SuppressWarnings("deprecation")
    public void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 neighborBlock, class_9904 orientation, boolean boolean_1) {
        TorcherinoLogic.neighborUpdate(state, level, pos, neighborBlock, orientation, boolean_1, (be) -> {
            if (state == null) {
                return;
            }
            if (state.method_11654(class_2741.field_16561).equals(true)) {
                be.setPoweredByRedstone(level.method_49807(pos.method_10084(), class_2350.field_11036));
            } else {
                boolean powered = isEmittingStrongRedstonePower(level, pos.method_10067(), class_2350.field_11039) ||
                        isEmittingStrongRedstonePower(level, pos.method_10078(), class_2350.field_11034) ||
                        isEmittingStrongRedstonePower(level, pos.method_10072(), class_2350.field_11035) ||
                        isEmittingStrongRedstonePower(level, pos.method_10095(), class_2350.field_11043);
                be.setPoweredByRedstone(powered);
            }
        });

    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, class_1309 placer, class_1799 stack) {
        TorcherinoLogic.onPlaced(level, pos, state, placer, stack, this);
    }
}
