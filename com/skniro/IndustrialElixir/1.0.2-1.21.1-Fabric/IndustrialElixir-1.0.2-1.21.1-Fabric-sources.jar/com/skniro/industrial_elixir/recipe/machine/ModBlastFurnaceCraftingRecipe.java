package com.skniro.industrial_elixir.recipe.machine;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.world.item.crafting.*;

import java.util.Optional;
import com.skniro.industrial_elixir.recipe.ModRecipeSerializers;

public class ModBlastFurnaceCraftingRecipe extends AbstractMachineCraftingRecipe {
    private final Optional<class_1799> output2;
    private final class_2960 requiredFluid;
    private final int requiredFluidAmount;

    public ModBlastFurnaceCraftingRecipe(class_1856 ingredient, int requiredCount, class_1799 output,
                                         Optional<class_1799> output2, class_2960 requiredFluid, int requiredFluidAmount) {
        super(ingredient, requiredCount, output);
        this.output2 = output2 != null ? output2 : Optional.empty();
        this.requiredFluid = requiredFluid;
        this.requiredFluidAmount = requiredFluidAmount;
    }

    @Override
    public class_1865<? extends class_1860<AlchemyCraftingRecipeInput>> method_8119() {
        return AlchemyRecipeType.MOD_BLAST_FURNACE.serializer;
    }

    @Override
    public class_3956<? extends class_1860<AlchemyCraftingRecipeInput>> method_17716() {
        return AlchemyRecipeType.MOD_BLAST_FURNACE.type;
    }


    public Optional<class_1799> output2() {
        return output2;
    }

    public class_2960 requiredFluid() {
        return requiredFluid;
    }

    public int requiredFluidAmount() {
        return requiredFluidAmount;
    }

    public static final MapCodec<ModBlastFurnaceCraftingRecipe> CODEC =
            RecordCodecBuilder.mapCodec(inst -> inst.group(
                    class_1856.field_46095.fieldOf("ingredient").forGetter(recipe -> recipe.ingredient),
                    Codec.INT.fieldOf("count").forGetter(recipe -> recipe.requiredCount),
                    class_1799.field_24671.fieldOf("result").forGetter(recipe -> recipe.output),
                    class_1799.field_24671.optionalFieldOf("result2").forGetter(recipe -> recipe.output2),
                    class_2960.field_25139.fieldOf("fluid").forGetter(recipe -> recipe.requiredFluid),
                    Codec.INT.fieldOf("fluid_amount").forGetter(recipe -> recipe.requiredFluidAmount)
            ).apply(inst, ModBlastFurnaceCraftingRecipe::new));

    public static final class_9139<class_9129, ModBlastFurnaceCraftingRecipe> field_48356 =
            class_9139.method_58025(
                    class_1856.field_48355, AbstractMachineCraftingRecipe::ingredient,
                    class_9135.field_49675, AbstractMachineCraftingRecipe::requiredCount,
                    class_1799.field_48349, AbstractMachineCraftingRecipe::output,
                    class_9135.method_56382(class_1799.field_48349), ModBlastFurnaceCraftingRecipe::output2,
                    class_2960.field_48267, ModBlastFurnaceCraftingRecipe::requiredFluid,
                    class_9135.field_49675, ModBlastFurnaceCraftingRecipe::requiredFluidAmount,
                    ModBlastFurnaceCraftingRecipe::new);

    public static final class_1865<ModBlastFurnaceCraftingRecipe> SERIALIZER =
            ModRecipeSerializers.of(CODEC, field_48356);
}
