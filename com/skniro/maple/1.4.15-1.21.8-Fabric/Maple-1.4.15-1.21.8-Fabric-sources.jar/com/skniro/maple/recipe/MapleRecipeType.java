package com.skniro.maple.recipe;

import com.skniro.maple.Maple;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

public interface MapleRecipeType<T extends class_1860<?>> {
    public static final class_1865<MapleJuicerCraftingRecipe> Maple_JUIER_SERIALIZER = class_2378.method_10230(
            class_7923.field_41189, class_2960.method_60655(Maple.MOD_ID, "maple_juicer"), new MapleJuicerCraftingRecipe.Serializer());
    public static final class_3956<MapleJuicerCraftingRecipe> Maple_JUIER_TYPE = class_2378.method_10230(
            class_7923.field_41188, class_2960.method_60655(Maple.MOD_ID, "maple_juicer"), new class_3956<>() {
                @Override
                public String toString() {
                    return "maple_juicer";
                }
            });
    public static void registerMapleRecipes() {
        Maple.LOGGER.info("Registering Custom Recipes for " + Maple.MOD_ID);
    }
}

