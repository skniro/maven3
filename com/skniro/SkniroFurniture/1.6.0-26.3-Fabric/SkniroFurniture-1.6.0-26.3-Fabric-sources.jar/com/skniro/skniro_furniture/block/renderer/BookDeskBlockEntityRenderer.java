package com.skniro.skniro_furniture.block.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.skniro.skniro_furniture.block.entity.BookDeskBlockEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.object.book.BookModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.EnchantTableRenderer;
import net.minecraft.client.renderer.blockentity.state.LecternRenderState;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.rendertype.RenderTypes;

import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.sprite.SpriteGetter;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class BookDeskBlockEntityRenderer implements BlockEntityRenderer<BookDeskBlockEntity, LecternRenderState> {
    private final SpriteGetter spriteHolder;
    private final BookModel book;
    private final BookModel.State bookModelState = BookModel.State.forAnimation(0.0F, 0.1F, 0.9F, 1.2F);

    public BookDeskBlockEntityRenderer(BlockEntityRendererProvider.Context ctx) {
        this.spriteHolder = ctx.sprites();
        this.book = new BookModel(ctx.bakeLayer(ModelLayers.BOOK));
    }

    @Override
    public LecternRenderState createRenderState() {
        return new LecternRenderState();
    }

    @Override
    public void extractRenderState(BookDeskBlockEntity bookDeskBlockEntity, LecternRenderState lecternBlockEntityRenderState, float f, Vec3 vec3d, ModelFeatureRenderer.@Nullable CrumblingOverlay crumblingOverlayCommand) {
        BlockEntityRenderer.super.extractRenderState(bookDeskBlockEntity, lecternBlockEntityRenderState, f, vec3d, crumblingOverlayCommand);
        lecternBlockEntityRenderState.hasBook = bookDeskBlockEntity.getBlockState().getValue(LecternBlock.HAS_BOOK);
        lecternBlockEntityRenderState.yRot = bookDeskBlockEntity.getBlockState().getValue(LecternBlock.FACING).getClockWise().toYRot();
    }

    @Override
    public void submit(LecternRenderState lecternBlockEntityRenderState, PoseStack matrixStack, SubmitNodeCollector orderedRenderCommandQueue, CameraRenderState cameraRenderState) {
        if (lecternBlockEntityRenderState.hasBook) {
            matrixStack.pushPose();
            matrixStack.translate(0.5F, 1.1625F, 0.5F);
            matrixStack.translate(0.0F, 0.0F, 0.0F);
            matrixStack.rotate(Axis.YP.rotationDegrees(-lecternBlockEntityRenderState.yRot));
            matrixStack.rotate(Axis.ZP.rotationDegrees(90F));
            matrixStack.rotate(Axis.XP.rotationDegrees(180F));
            matrixStack.translate(-0.15F, 0.0F, 0.0F);
            orderedRenderCommandQueue.submitModel(this.book, this.bookModelState, matrixStack, lecternBlockEntityRenderState.lightCoords, OverlayTexture.NO_OVERLAY, -1, EnchantTableRenderer.BOOK_TEXTURE, this.spriteHolder, 0);
            if (lecternBlockEntityRenderState.breakProgress != null) {
                orderedRenderCommandQueue.order(1).submitCrumblingOverlay(this.book, this.bookModelState, matrixStack, EnchantTableRenderer.BOOK_TEXTURE.renderType(RenderTypes::entitySolid), lecternBlockEntityRenderState.lightCoords, OverlayTexture.NO_OVERLAY, -1, lecternBlockEntityRenderState.breakProgress);
            }
            matrixStack.popPose();
        }
    }
}