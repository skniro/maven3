package com.skniro.usefulfood.item;

import com.skniro.usefulfood.UsefulFood;
import com.skniro.usefulfood.item.init.ItemBottle;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1756;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1814;
import net.minecraft.class_1935;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_7923;
import net.minecraft.item.*;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class UsefulFoodItems {
public static final class_1792 MilkBottle =
        registerItem("milkbottle",new ItemBottle(
                new class_1792
                .class_1793()
                .method_19265
                        (new class_4174
                                .class_4175()
                                .method_19238(0)
                                .method_19237(0.0f)
                                .method_19240()
                                .method_19242()
                        )
                .method_7896(class_1802.field_8469)
                        .method_7889(1)
        ));
    public static final class_1792 ChocolateMilkBottle =
            registerItem( "chocolatemilkbottle", new ItemBottle(
                    new class_1792
                            .class_1793()
                            .method_19265
                                    (new class_4174
                                            .class_4175()
                                            .method_19238(3)
                                            .method_19237(0.8f)
                                            .method_19242()
                                    )
                            .method_7896(class_1802.field_8469)
                            .method_7889(1)
            ));

    public static final class_1792 Cheese =
    registerItem("cheese", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));

    public static final class_1792 ChocolateCandy =
            registerItem("chocolatebar", new class_1792(
                    new class_1792
                            .class_1793()
                            .method_19265
                                    (new class_4174
                                            .class_4175()
                                            .method_19238(6)
                                            .method_19237(1.0f)
                                            .method_19242()
                                    )
            ));
    public static final class_1792 FruitSalad =
            registerItem("fruitsalad", new class_1756(
                    new class_1792
                            .class_1793()
                            .method_19265
                                    (new class_4174
                                            .class_4175()
                                            .method_19238(7)
                                            .method_19237(0.6f)
                                            .method_19242()
                                    )
                            .method_7889(1)
            ));

    public static final class_1792 MagicFruitSalad = registerItem("magicfruitsalad", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5924,50,1),1.0F)
                                    .method_19239(new class_1293(class_1294.field_5907,100,1),1.0F)
                                    .method_19242()
                            )
                    .method_7894(class_1814.field_8903)
                    .method_7889(1)
    ));
    public static final class_1792 SugarCube = registerItem("sugarcube", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(0.1f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,100,1),1.0F)
                                    .method_19242()
                            )
    ));
    public static final class_1792 caramel = registerItem("caramel",new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.2f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,100,1),1.0F)
                                    .method_19242()
                            )
    ));


    public static final class_1792 caramelapple = registerItem("caramelapple",new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(10)
                                    .method_19237(0.5f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,100,1),1.0F)
                                    .method_19242()
                            ).method_7889(1)
    ));
    public static final class_1792 RoastedSeeds = registerItem("roastedseeds", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(1)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 FriedEgg = registerItem("friedegg",new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 PumpkinSoup = registerItem("pumpkinsoup",new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.8f)
                                    .method_19242()
                            ).method_7889(1)
    ));
    public static final class_1792 Salad = registerItem("salad",new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.6f)
                                    .method_19242()
                            ).method_7889(1)
    ));
    public static final class_1792 Oatmeal = registerItem("oatmeal",new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(0.6f)
                                    .method_19242()
                            ).method_7889(1)
    ));
    public static final class_1792 Jelly = registerItem("jelly",new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.3f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5913,50,1),1.0F)
                                    .method_19242()
                            ).method_7889(1)
    ));
    public static final class_1792 Marshmallow = registerItem("rawmarshmallow",new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.3f)
                                    .method_19242()
                            ).method_7889(1)
    ));
    public static final class_1792 CookMarshmallow = registerItem("cookedmarshmallow",new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(0.3f)
                                    .method_19242()
                            ).method_7889(1)
    ));

    public static final class_1792 VanillaIceCream = registerItem("vanillaicecream",new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.3f)
                                    .method_19242()
                            ).method_7889(1)
    ));
    public static final class_1792 BreadSlice = registerItem("breadslice",new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(1)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 PorkWich = registerItem("porkchopsandwich",new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(11)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Steakwich = registerItem("steaksandwich",new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(11)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Fishwich = registerItem("fishsandwich", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Chickenwich = registerItem("chickensandwich",new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Eggwich = registerItem("eggsandwich", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Biscuit = registerItem("biscuit", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(1)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Trailmix = registerItem("trailmix",new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));

    // 1.0
    public static final class_1792 MuttonSandwich = registerItem("muttonsandwich", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));

    // 1.2
    public static final class_1792 Sushi = registerItem("sushi", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 SquidTentacleRaw = registerItem("squidrtentacle", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 SquidTentacleCooked = registerItem("cookedsquidtentacle", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.8f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 SquidSandwich = registerItem("squidsandwich",  new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.8f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 MagicAppleJuice = registerItem("magicapplejuice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(13)
                                    .method_19237(1.2f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5907,6000,1),1.0F)
                                    .method_19239(new class_1293(class_1294.field_5918,6000,1),1.0F)
                                    .method_19239(new class_1293(class_1294.field_5924,6000,3),1.0F)
                                    .method_19239(new class_1293(class_1294.field_5904,6000,1),1.0F)
                                    .method_19239(new class_1293(class_1294.field_5917,6000,1),1.0F)
                                    .method_19242()
                            )
                    .method_7894(class_1814.field_8903)
                    .method_7889(1)
    ));
    public static final class_1792 MelonJuice = registerItem("melonjuice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.9f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,600,1),1.0F)
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));
    public static final class_1792 AppleJuice = registerItem("applejuice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(12)
                                    .method_19237(0.9f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,600,1),1.0F)
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));
    public static final class_1792 CarrotJuice = registerItem("carrotjuice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(12)
                                    .method_19237(0.9f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,600,1),1.0F)
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));
    public static final class_1792 CarrotSoup = registerItem("carrotsoup", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.8f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,600,1),1.0F)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 PumpkinBread = registerItem("pumpkinbread",  new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(10)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 FishnChips = registerItem("fishnchips",  new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(12)
                                    .method_19237(1.2f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 SugarBiscuit = registerItem("sugarbiscuit",  new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 AppleJamBiscuit = registerItem("applejambiscuit",  new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(10)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 ChocoBiscuit = registerItem("chocolatebiscuit",  new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 CarrotPie = registerItem("carrotpie",  new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.8f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 hotchocolatebottle = registerItem("hotchocolatemilkbottle",  new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));
    public static final class_1792 chocolateicecream = registerItem("chocolateicecream", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.8f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));

    // 1.4
    public static final class_1792 MagicIceCream = registerItem("magicicecream", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5924,100,1),1.0F)
                                    .method_19239(new class_1293(class_1294.field_5907,100,1),1.0F)
                                    .method_19242()
                            )
                    .method_7894(class_1814.field_8903)
                    .method_7889(1)
    ));
    public static final class_1792 SquidSushi = registerItem("squidsushi", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 CactusJuice = registerItem("cactusjuice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,100,1),1.0F)
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));
    public static final class_1792 Spaghetti = registerItem("spaghetti", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 AppleIceCream = registerItem("appleicecream", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 MelonIceCream = registerItem("melonicecream", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 ChocolateApple = registerItem("chocolateapple", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(11)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 CaramelBiscuit = registerItem("caramelbiscuit", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,100,1),1.0F)
                                    .method_19242()
                            )
    ));
    public static final class_1792 FishSoup = registerItem("fishsoup", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(12)
                                    .method_19237(0.6F)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 Tea = registerItem("tea", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));
    public static final class_1792 HotMilkBottle = registerItem("hotmilkbottle", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(1)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));


    public static final class_1792 CheeseSandwich = registerItem("cheesesandwich", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 CaramelIceCream = registerItem("caramelicecream", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,100,1),1.0F)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 Cereal = registerItem("cereal", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 ChocolateCereal = registerItem("chocolatecereal", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 FrenchFries = registerItem("frenchfries", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 AppleJelly = registerItem("applejelly", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.4f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5913,300,1),1.0F)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 MelonJelly = registerItem("melonjelly", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.4f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5913,300,1),1.0F)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 Donut = registerItem("donut" , new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Oreo = registerItem("oreo", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 CaramelToast = registerItem("carameltoast", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,100,1),1.0F)
                                    .method_19242()
                            )
    ));
    public static final class_1792 ChocolateToast = registerItem("chocolatetoast", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 SugarToast = registerItem("sugartoast", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.2f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,100,1),1.0F)
                                    .method_19242()
                            )
    ));
    public static final class_1792 SugarPancake = registerItem("sugarpancake", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,100,1),1.0F)
                                    .method_19242()
                            )
    ));
    public static final class_1792 AppleJamPanCake = registerItem("applejampancake", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(15)
                                    .method_19237(0.7f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 AppleJamToast = registerItem("applejamtoast", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(10)
                                    .method_19237(0.7f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 AppleJam = registerItem("applejam", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
                    .method_7889(1)
                    .method_7896(class_1802.field_8428)
    ));
    public static final class_1792 CaramelPanCake = registerItem("caramelpancake", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(12)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,100,1),1.0F)
                                    .method_19242()
                            )
    ));
    public static final class_1792 ChocolatePanCake = registerItem("chocolatepancake", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(13)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 MelonJamPanCake = registerItem("melonjampancake", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(13)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 MelonJamToast = registerItem("melonjamtoast", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 MelonJamBiscuit = registerItem("melonjambiscuit", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 MelonJam = registerItem("melonjam", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
                    .method_7889(1)
                    .method_7896(class_1802.field_8428)
    ));
    public static final class_1792 PanCakeDough = registerItem("pancakedough", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 PanCake = registerItem("pancake", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));

    public static final class_1792 Sweet_Berries_Juice = registerItem("sweet_berries_juice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                            .class_4175()
                                            .method_19238(3)
                                            .method_19237(0.3f)
                                            .method_19240()
                                            .method_19239(new class_1293(class_1294.field_5924,200,1),1.0F)
                                            .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));

    public static final class_1792 Glow_Berries_Juice = registerItem("glow_berries_juice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                            .class_4175()
                                            .method_19238(2)
                                            .method_19237(0.25f)
                                            .method_19240()
                                            .method_19239(new class_1293(class_1294.field_5925,1000,1),1.0F)
                                            .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));

    public static final class_1792 Chorus_Juice = registerItem("chorus_juice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                            .class_4175()
                                            .method_19238(2)
                                            .method_19237(0.2f)
                                            .method_19240()
                                            .method_19239(new class_1293(class_1294.field_5906,200,1),1.0F)
                                            .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));

    public static final class_1792 Chorus_Jelly = registerItem("chorus_jelly", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                            .class_4175()
                                            .method_19238(7)
                                            .method_19237(0.35f)
                                            .method_19240()
                                            .method_19239(new class_1293(class_1294.field_5906,200,1),1.0F)
                                            .method_19242()
                            )
                    .method_7889(1)
    ));

    public static final class_1792 Glow_Berries_Jelly = registerItem("glow_berries_jelly", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                            .class_4175()
                                            .method_19238(6)
                                            .method_19237(0.35f)
                                            .method_19240()
                                            .method_19239(new class_1293(class_1294.field_5925,400,1),1.0F)
                                            .method_19242()
                            )
                    .method_7889(1)
    ));

    public static final class_1792 Sweet_Berries_Jelly = registerItem("sweet_berries_jelly", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                            .class_4175()
                                            .method_19238(7)
                                            .method_19237(0.4f)
                                            .method_19240()
                                            .method_19239(new class_1293(class_1294.field_5924,200,1),1.0F)
                                            .method_19242()
                            )
                    .method_7889(1)
    ));

    public static final class_1792 Chorus_Ice_Cream = registerItem("chorus_ice_cream", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));

    public static final class_1792 Sweet_Berries_Ice_Cream = registerItem("sweet_berries_ice_cream", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.65f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));

    public static final class_1792 Glow_Berries_Ice_Cream = registerItem("glow_berries_ice_cream", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.55f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));

    public static final class_1792 Glow_Berries_JamPanCake = registerItem("glow_berries_jam_pancake", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(10)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Glow_Berries_JamToast = registerItem("glow_berries_jam_toast", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Glow_Berries_JamBiscuit = registerItem("glow_berries_jam_biscuit", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Glow_Berries_Jam = registerItem("glow_berries_jam", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
                    .method_7889(1)
                    .method_7896(class_1802.field_8428)
    ));

    public static final class_1792 Sweet_Berries_JamPanCake = registerItem("sweet_berries_jam_pancake", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(12)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Sweet_Berries_JamToast = registerItem("sweet_berries_jam_toast", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Sweet_Berries_JamBiscuit = registerItem("sweet_berries_jam_biscuit", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Sweet_Berries_Jam = registerItem("sweet_berries_jam", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
                    .method_7889(1)
                    .method_7896(class_1802.field_8428)
    ));

    public static final class_1792 Chorus_JamPanCake = registerItem("chorus_jam_pancake", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(14)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Chorus_JamToast = registerItem("chorus_jam_toast", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Chorus_JamBiscuit = registerItem("chorus_jam_biscuit", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Chorus_Jam = registerItem("chorus_jam", new class_1756(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
                    .method_7889(1)
                    .method_7896(class_1802.field_8428)
    ));

    //Reborn 1.5.0
    public static final class_1792 Baked_Sushi = registerItem("baked_sushi", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));

    public static final class_1792 Cod_Roe_Sushi = registerItem("cod_roe_sushi", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
    ));

    public static final class_1792 Salmon_Sushi = registerItem("salmon_sushi", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));

    public static final class_1792 Waffle = registerItem("waffle", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(1)
                                    .method_19237(0.1f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));

    public static final class_1792 Waffle_Chorus_Ice_Cream = registerItem("waffle_chorus_ice_cream", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));

    public static final class_1792 Waffle_Sweet_Berries_Ice_Cream = registerItem("waffle_sweet_berries_ice_cream", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));

    public static final class_1792 Waffle_Glow_Berries_Ice_Cream = registerItem("waffle_glow_berries_ice_cream", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));
    public static final class_1792 Waffle_Vanilla_IceCream = registerItem("waffle_vanilla_icecream",new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.3f)
                                    .method_19242()
                            ).method_7889(16)
    ));
    public static final class_1792 Waffle_chocolate_icecream = registerItem("waffle_chocolate_icecream", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));
    public static final class_1792 Waffle_Magic_IceCream = registerItem("waffle_magic_icecream", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                            .class_4175()
                                            .method_19238(7)
                                            .method_19237(0.5f)
                                            .method_19240()
                                            .method_19239(new class_1293(class_1294.field_5924,100,1),1.0F)
                                            .method_19239(new class_1293(class_1294.field_5907,100,1),1.0F)
                                            .method_19242()
                            )
                    .method_7894(class_1814.field_8903)
                    .method_7889(16)
    ));
    public static final class_1792 Waffle_Apple_IceCream = registerItem("waffle_apple_icecream", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));
    public static final class_1792 Waffle_Melon_IceCream = registerItem("waffle_melon_icecream", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));
    public static final class_1792 Waffle_Caramel_IceCream = registerItem("waffle_caramel_icecream", new class_1792(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                            .class_4175()
                                            .method_19238(6)
                                            .method_19237(0.5f)
                                            .method_19240()
                                            .method_19239(new class_1293(class_1294.field_5904,100,1),1.0F)
                                            .method_19242()
                            )
                    .method_7889(16)
    ));


    private static final Map<class_2960, List<class_1935>> itemsByGroup = new LinkedHashMap<>();

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_43902(UsefulFood.MOD_ID, name), item);
    }

    public static void registerUsefulFoodItem(){
      UsefulFood.LOGGER.debug("register Useful Food Item.");
    }
}
