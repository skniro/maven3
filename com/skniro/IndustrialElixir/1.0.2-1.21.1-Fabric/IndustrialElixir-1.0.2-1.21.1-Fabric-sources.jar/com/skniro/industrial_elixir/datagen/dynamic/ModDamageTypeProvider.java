package com.skniro.industrial_elixir.datagen.dynamic;

import com.skniro.industrial_elixir.init.ModDamageTypes;
import net.minecraft.class_7891;
import net.minecraft.class_8107;
import net.minecraft.class_8110;

public class ModDamageTypeProvider{

    public static void damageTypes(class_7891<class_8110> context) {
        context.method_46838(ModDamageTypes.ELECTRIC_SHOCK, new class_8110("electric_shock", 0.1F, class_8107.field_42278));
        context.method_46838(ModDamageTypes.FUSION, new class_8110("fusion", 0.1F, class_8107.field_42278));
    }
}