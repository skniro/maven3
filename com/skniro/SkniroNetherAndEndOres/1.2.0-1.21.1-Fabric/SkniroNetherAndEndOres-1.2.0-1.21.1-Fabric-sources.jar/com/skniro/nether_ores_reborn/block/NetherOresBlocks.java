package com.skniro.nether_ores_reborn.block;

import com.skniro.nether_ores_reborn.NetherOres;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2431;
import net.minecraft.class_2498;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_6016;
import net.minecraft.class_6019;
import net.minecraft.class_7923;

public class NetherOresBlocks {

    public static final class_2248 Nether_Coal_Ore = registerBlock("coal_ore", new class_2431(class_6019.method_35017(0, 2), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_9626(class_2498.field_22145).method_31710(class_3620.field_16012).method_51368(class_2766.field_12653)));
    public static final class_2248 Nether_Copper_Ore = registerBlock("copper_ore", new class_2431(class_6016.method_34998(0), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_9626(class_2498.field_22145).method_31710(class_3620.field_16012).method_51368(class_2766.field_12653)));
    public static final class_2248 Nether_Diamond_Ore = registerBlock("diamond_ore", new class_2431(class_6019.method_35017(2, 4), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_9626(class_2498.field_22145).method_31710(class_3620.field_16012).method_51368(class_2766.field_12653)));
    public static final class_2248 Nether_Emerald_Ore = registerBlock("emerald_ore", new class_2431(class_6019.method_35017(3, 7), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_9626(class_2498.field_22145).method_31710(class_3620.field_16012).method_51368(class_2766.field_12653)));
    public static final class_2248 Nether_Gold_Ore = registerBlock("gold_ore", new class_2431(class_6016.method_34998(0), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_9626(class_2498.field_22145).method_31710(class_3620.field_16012).method_51368(class_2766.field_12653)));
    public static final class_2248 Nether_Iron_Ore = registerBlock("iron_ore", new class_2431(class_6016.method_34998(0), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_9626(class_2498.field_22145).method_31710(class_3620.field_16012).method_51368(class_2766.field_12653)));
    public static final class_2248 Nether_Lapis_Ore = registerBlock("lapis_ore", new class_2431(class_6019.method_35017(2, 4), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_9626(class_2498.field_22145).method_31710(class_3620.field_16012).method_51368(class_2766.field_12653)));
    public static final class_2248 Nether_Redstone_Ore = registerBlock("redstone_ore", new class_2431(class_6019.method_35017(2, 4),  class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_9626(class_2498.field_22145).method_31710(class_3620.field_16012).method_51368(class_2766.field_12653)));

    public static final class_2248 End_Coal_Ore = registerBlock("end_coal_ore", new class_2431(class_6019.method_35017(0, 2), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_31710(class_3620.field_15986).method_51368(class_2766.field_12653)));
    public static final class_2248 End_Copper_Ore = registerBlock("end_copper_ore", new class_2431(class_6016.method_34998(0), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_31710(class_3620.field_15986).method_51368(class_2766.field_12653)));
    public static final class_2248 End_Diamond_Ore = registerBlock("end_diamond_ore", new class_2431(class_6019.method_35017(3, 7), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_31710(class_3620.field_15986).method_51368(class_2766.field_12653)));
    public static final class_2248 End_Emerald_Ore = registerBlock("end_emerald_ore", new class_2431(class_6019.method_35017(3, 7), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_31710(class_3620.field_15986).method_51368(class_2766.field_12653)));
    public static final class_2248 End_Gold_Ore = registerBlock("end_gold_ore", new class_2431(class_6016.method_34998(0), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_31710(class_3620.field_15986).method_51368(class_2766.field_12653)));
    public static final class_2248 End_Iron_Ore = registerBlock("end_iron_ore", new class_2431(class_6016.method_34998(0), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_31710(class_3620.field_15986).method_51368(class_2766.field_12653)));
    public static final class_2248 End_Lapis_Ore = registerBlock("end_lapis_ore", new class_2431(class_6019.method_35017(2, 5), class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_31710(class_3620.field_15986).method_51368(class_2766.field_12653)));
    public static final class_2248 End_Redstone_Ore = registerBlock("end_redstone_ore", new class_2431(class_6019.method_35017(2, 4),  class_4970.class_2251.method_9637().method_29292().method_9640().method_9629(3.0F, 3.0F).method_31710(class_3620.field_15986).method_51368(class_2766.field_12653)));




    private static class_2248 registerBlock(String name, class_2248 block) {
        registerBlockItem(name, block);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(NetherOres.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(NetherOres.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
    }

    private static class_2248 registerBlockWithoutItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(NetherOres.MOD_ID, name), block);
    }

    public static void registerBlock() {
        NetherOres.LOGGER.info("register Mod Blocks"+ NetherOres.MOD_ID);
    }
}
