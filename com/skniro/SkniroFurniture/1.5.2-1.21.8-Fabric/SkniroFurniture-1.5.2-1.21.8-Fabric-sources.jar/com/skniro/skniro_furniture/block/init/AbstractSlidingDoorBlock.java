package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.block.*;
import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2750;
import net.minecraft.class_2754;
import net.minecraft.class_2756;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3612;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import net.minecraft.class_8177;
import net.minecraft.class_9904;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;

public abstract class AbstractSlidingDoorBlock extends class_2248 {
    public static final class_2754<class_2350> FACING;
    public static final class_2754<class_2756> HALF;
    public static final class_2754<class_2750> HINGE;
    public static final class_2746 OPEN;
    public static final class_2746 POWERED;
    private final class_8177 blockSetType;

    public AbstractSlidingDoorBlock(class_8177 type, class_2251 settings) {
        super(settings.method_9626(type.comp_1290()));
        this.blockSetType = type;
        this.method_9590((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043)).method_11657(OPEN, false)).method_11657(HINGE, class_2750.field_12588)).method_11657(POWERED, false)).method_11657(HALF, class_2756.field_12607));
    }

    public class_8177 getBlockSetType() {
        return this.blockSetType;
    }

    protected class_2680 method_9559(class_2680 state, class_4538 world, class_10225 tickView, class_2338 pos, class_2350 direction, class_2338 neighborPos, class_2680 neighborState, class_5819 random) {
        class_2756 doubleBlockHalf = (class_2756)state.method_11654(HALF);
        if (direction.method_10166() == class_2350.class_2351.field_11052 && doubleBlockHalf == class_2756.field_12607 == (direction == class_2350.field_11036)) {
            return neighborState.method_26204() instanceof AbstractSlidingDoorBlock && neighborState.method_11654(HALF) != doubleBlockHalf ? (class_2680)neighborState.method_11657(HALF, doubleBlockHalf) : class_2246.field_10124.method_9564();
        } else {
            return doubleBlockHalf == class_2756.field_12607 && direction == class_2350.field_11033 && !state.method_26184(world, pos) ? class_2246.field_10124.method_9564() : super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
        }
    }

    protected void method_55124(class_2680 state, class_3218 world, class_2338 pos, class_1927 explosion, BiConsumer<class_1799, class_2338> stackMerger) {
        if (explosion.method_60274() && state.method_11654(HALF) == class_2756.field_12607 && this.blockSetType.comp_2112() && !(Boolean)state.method_11654(POWERED)) {
            this.setOpen((class_1297)null, world, state, pos, !this.isOpen(state));
        }

        super.method_55124(state, world, pos, explosion, stackMerger);
    }

    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        if (!world.field_9236 && (player.method_66324() || !player.method_7305(state))) {
            onBreakInCreative(world, pos, state, player);
        }

        return super.method_9576(world, pos, state, player);
    }

    protected boolean method_9516(class_2680 state, class_10 type) {
        boolean var10000;
        switch (type) {
            case field_50:
            case field_51:
                var10000 = (Boolean)state.method_11654(OPEN);
                break;
            case field_48:
                var10000 = false;
                break;
            default:
                throw new MatchException((String)null, (Throwable)null);
        }

        return var10000;
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2338 pos = ctx.method_8037();
        class_1937 world = ctx.method_8045();
        class_2350 playerFacing = ctx.method_8042();
        class_2338 upPos = pos.method_10084();
        if (pos.method_10264() < world.method_31600() - 1 && world.method_8320(upPos).method_26166(ctx)) {
            boolean bl = world.method_49803(pos) || world.method_49803(upPos);
            return this.method_9564()
                    .method_11657(FACING, playerFacing)
                    .method_11657(HINGE, getHinge(ctx))
                    .method_11657(OPEN, false)
                    .method_11657(POWERED, bl)
                    .method_11657(HALF, class_2756.field_12607);
        } else {
            return null;
        }
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 stack) {
        world.method_8652(pos.method_10084(), state.method_11657(HALF, class_2756.field_12609), 3);
    }

    private class_2750 getHinge(class_1750 ctx) {
        class_1922 blockView = ctx.method_8045();
        class_2338 blockPos = ctx.method_8037();
        class_2350 direction = ctx.method_8042();
        class_2338 blockPos2 = blockPos.method_10084();
        class_2350 direction2 = direction.method_10160();
        class_2338 blockPos3 = blockPos.method_10093(direction2);
        class_2680 blockState = blockView.method_8320(blockPos3);
        class_2338 blockPos4 = blockPos2.method_10093(direction2);
        class_2680 blockState2 = blockView.method_8320(blockPos4);
        class_2350 direction3 = direction.method_10170();
        class_2338 blockPos5 = blockPos.method_10093(direction3);
        class_2680 blockState3 = blockView.method_8320(blockPos5);
        class_2338 blockPos6 = blockPos2.method_10093(direction3);
        class_2680 blockState4 = blockView.method_8320(blockPos6);
        int i = (blockState.method_26234(blockView, blockPos3) ? -1 : 0) + (blockState2.method_26234(blockView, blockPos4) ? -1 : 0) + (blockState3.method_26234(blockView, blockPos5) ? 1 : 0) + (blockState4.method_26234(blockView, blockPos6) ? 1 : 0);
        boolean bl = blockState.method_26204() instanceof AbstractSlidingDoorBlock && blockState.method_11654(HALF) == class_2756.field_12607;
        boolean bl2 = blockState3.method_26204() instanceof AbstractSlidingDoorBlock && blockState3.method_11654(HALF) == class_2756.field_12607;
        if ((!bl || bl2) && i <= 0) {
            if ((!bl2 || bl) && i >= 0) {
                int j = direction.method_10148();
                int k = direction.method_10165();
                class_243 vec3d = ctx.method_17698();
                double d = vec3d.field_1352 - (double)blockPos.method_10263();
                double e = vec3d.field_1350 - (double)blockPos.method_10260();
                return (j >= 0 || !(e < (double)0.5F)) && (j <= 0 || !(e > (double)0.5F)) && (k >= 0 || !(d > (double)0.5F)) && (k <= 0 || !(d < (double)0.5F)) ? class_2750.field_12588 : class_2750.field_12586;
            } else {
                return class_2750.field_12588;
            }
        } else {
            return class_2750.field_12586;
        }
    }

    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!this.blockSetType.comp_1471()) {
            return class_1269.field_5811;
        } else {
            state = (class_2680)state.method_28493(OPEN);
            world.method_8652(pos, state, 10);
            this.playOpenCloseSound(player, world, pos, (Boolean)state.method_11654(OPEN));
            world.method_33596(player, this.isOpen(state) ? class_5712.field_28168 : class_5712.field_28169, pos);
            return class_1269.field_5812;
        }
    }

    public boolean isOpen(class_2680 state) {
        return (Boolean)state.method_11654(OPEN);
    }

    public void setOpen(@Nullable class_1297 entity, class_1937 world, class_2680 state, class_2338 pos, boolean open) {
        if (state.method_27852(this) && (Boolean)state.method_11654(OPEN) != open) {
            world.method_8652(pos, (class_2680)state.method_11657(OPEN, open), 10);
            this.playOpenCloseSound(entity, world, pos, open);
            world.method_33596(entity, open ? class_5712.field_28168 : class_5712.field_28169, pos);
        }
    }


    protected void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, @Nullable class_9904 wireOrientation, boolean notify) {
        boolean bl = world.method_49803(pos) || world.method_49803(pos.method_10093(state.method_11654(HALF) == class_2756.field_12607 ? class_2350.field_11036 : class_2350.field_11033));
        if (!this.method_9564().method_27852(sourceBlock) && bl != (Boolean)state.method_11654(POWERED)) {
            if (bl != (Boolean)state.method_11654(OPEN)) {
                this.playOpenCloseSound((class_1297)null, world, pos, bl);
                world.method_33596((class_1297)null, bl ? class_5712.field_28168 : class_5712.field_28169, pos);
            }

            world.method_8652(pos, (class_2680)((class_2680)state.method_11657(POWERED, bl)).method_11657(OPEN, bl), 2);
        }

    }

    protected boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2338 blockPos = pos.method_10074();
        class_2680 blockState = world.method_8320(blockPos);
        return state.method_11654(HALF) == class_2756.field_12607 ? blockState.method_26206(world, blockPos, class_2350.field_11036) : blockState.method_27852(this);
    }

    private void playOpenCloseSound(@Nullable class_1297 entity, class_1937 world, class_2338 pos, boolean open) {
        world.method_8396(entity, pos, open ? this.blockSetType.comp_1292() : this.blockSetType.comp_1291(), class_3419.field_15245, 1.0F, world.method_8409().method_43057() * 0.1F + 0.9F);
    }

    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return (class_2680)state.method_11657(FACING, rotation.method_10503((class_2350)state.method_11654(FACING)));
    }

    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return mirror == class_2415.field_11302 ? state : (class_2680)state.method_26186(mirror.method_10345((class_2350)state.method_11654(FACING))).method_28493(HINGE);
    }

    protected long method_9535(class_2680 state, class_2338 pos) {
        return class_3532.method_15371(pos.method_10263(), pos.method_10087(state.method_11654(HALF) == class_2756.field_12607 ? 0 : 1).method_10264(), pos.method_10260());
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{HALF, FACING, OPEN, HINGE, POWERED});
    }

    public static boolean canOpenByHand(class_1937 world, class_2338 pos) {
        return canOpenByHand(world.method_8320(pos));
    }

    public static boolean canOpenByHand(class_2680 state) {
        class_2248 var2 = state.method_26204();
        boolean var10000;
        if (var2 instanceof AbstractSlidingDoorBlock doorBlock) {
            if (doorBlock.getBlockSetType().comp_1471()) {
                var10000 = true;
                return var10000;
            }
        }

        var10000 = false;
        return var10000;
    }

    static {
        FACING = class_2383.field_11177;
        HALF = class_2741.field_12533;
        HINGE = class_2741.field_12520;
        OPEN = class_2741.field_12537;
        POWERED = class_2741.field_12484;
    }


    protected static void onBreakInCreative(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        class_2756 doubleBlockHalf = (class_2756)state.method_11654(HALF);
        if (doubleBlockHalf == class_2756.field_12609) {
            class_2338 blockPos = pos.method_10074();
            class_2680 blockState = world.method_8320(blockPos);
            if (blockState.method_27852(state.method_26204()) && blockState.method_11654(HALF) == class_2756.field_12607) {
                class_2680 blockState2 = blockState.method_26227().method_39360(class_3612.field_15910) ? class_2246.field_10382.method_9564() : class_2246.field_10124.method_9564();
                world.method_8652(blockPos, blockState2, 35);
                world.method_8444(player, 2001, blockPos, class_2248.method_9507(blockState));
            }
        }

    }
}
