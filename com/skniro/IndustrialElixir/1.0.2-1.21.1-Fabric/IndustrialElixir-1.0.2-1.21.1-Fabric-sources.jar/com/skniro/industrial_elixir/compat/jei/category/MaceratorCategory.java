package com.skniro.industrial_elixir.compat.jei.category;

import com.skniro.industrial_elixir.api.Helper;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.machine.MaceratorCraftingRecipe;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableAnimated;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_8786;
import mezz.jei.api.recipe.RecipeType;

public class MaceratorCategory implements IRecipeCategory<class_8786<MaceratorCraftingRecipe>> {

    public static final RecipeType<class_8786<MaceratorCraftingRecipe>> TYPE =
            RecipeType.createFromVanilla(AlchemyRecipeType.MACERATOR.type);

    private final IDrawable background;
    private final IDrawable icon;
    private final IDrawable energyBar;
    private final IDrawableAnimated arrow;

    public MaceratorCategory(IGuiHelper helper) {
        class_2960 texture = Helper.id( "textures/gui/container/machine/macerator.png");

        background = helper.createDrawable(texture, 0, 0, 175, 82);

        icon = helper.createDrawableIngredient(VanillaTypes.ITEM_STACK,
                new class_1799(GrowableOresBlocks.Macerator_Block));

        energyBar = helper.createDrawable(texture, 176, 0, 13, 16);
        this.arrow = helper.drawableBuilder(Helper.id("textures/gui/container/machine/macerator.png"), 192, 0, 23, 12).buildAnimated(72, IDrawableAnimated.StartDirection.LEFT, false);
    }

    @Override
    public RecipeType<class_8786<MaceratorCraftingRecipe>> getRecipeType() {
        return TYPE;
    }

    @Override
    public class_2561 getTitle() {
        return class_2561.method_43471(FurnitureStrings.Macerator);
    }

    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public int getWidth() {
        return background.getWidth();
    }

    @Override
    public int getHeight() {
        return background.getHeight();
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, class_8786<MaceratorCraftingRecipe> recipe, IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 52, 13)
                .addIngredients(recipe.comp_1933().ingredient());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 100, 34)
                .addItemStack(recipe.comp_1933().output());
    }

    @Override
    public void draw(class_8786<MaceratorCraftingRecipe> recipe, IRecipeSlotsView slots, class_332 guiGraphics, double mouseX, double mouseY) {
        background.draw(guiGraphics);

        energyBar.draw(guiGraphics, 52, 30);

        arrow.draw(guiGraphics, 76, 35);
    }
}