package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_3612;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class OreWashingRecipeGenerator extends FabricRecipeProvider {
    public OreWashingRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                oreWashing(GrowableOresItems.CRUSHED_COPPER, GrowableOresItems.PURIFIED_COPPER, GrowableOresItems.SMALL_COPPER_DUST, "crushed_copper_to_purified_copper");
                oreWashing(GrowableOresItems.CRUSHED_GOLD, GrowableOresItems.PURIFIED_GOLD, GrowableOresItems.SMALL_GOLD_DUST, "crushed_gold_to_purified_gold");
                oreWashing(GrowableOresItems.CRUSHED_IRON, GrowableOresItems.PURIFIED_IRON, GrowableOresItems.SMALL_IRON_DUST, "crushed_iron_to_purified_iron");
                oreWashing(GrowableOresItems.CRUSHED_LEAD, GrowableOresItems.PURIFIED_LEAD, GrowableOresItems.SMALL_LEAD_DUST, "crushed_lead_to_purified_lead");
                oreWashing(GrowableOresItems.CRUSHED_SILVER, GrowableOresItems.PURIFIED_SILVER, GrowableOresItems.SMALL_SILVER_DUST, "crushed_silver_to_purified_silver");
                oreWashing(GrowableOresItems.CRUSHED_TIN, GrowableOresItems.PURIFIED_TIN, GrowableOresItems.SMALL_TIN_DUST, "crushed_tin_to_purified_tin");
                oreWashing(GrowableOresItems.CRUSHED_SACRED, GrowableOresItems.PURIFIED_SACRED, null, "crushed_septrin_to_purified_septrin");
            }

            private void oreWashing(class_1935 input, class_1935 primaryOutput, class_1792 secondaryOutput, String name) {
                var builder = createOreWashing(primaryOutput)
                        .fluid(class_3612.field_15910, 1000)
                        .input(input)
                        .output3(GrowableOresItems.STONE_DUST)
                        .method_33530("has_base_item", has(input));

                if (secondaryOutput != null) {
                    builder.output2(secondaryOutput);
                }

                builder.method_36443(output, name);
            }
        };
    }

    @Override
    public String method_10321() {
        return "OreWashing";
    }
}
