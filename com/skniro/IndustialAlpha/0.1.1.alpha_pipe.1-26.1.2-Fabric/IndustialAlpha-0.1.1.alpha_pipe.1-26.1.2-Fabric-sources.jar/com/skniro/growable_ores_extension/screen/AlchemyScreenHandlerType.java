package com.skniro.growable_ores_extension.screen;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.screen.energybox.ChargePadScreenHandler;
import com.skniro.growable_ores_extension.screen.energybox.EnergyBoxScreenHandler;
import com.skniro.growable_ores_extension.screen.generator.CoalGeneratorScreenHandler;
import com.skniro.growable_ores_extension.screen.generator.GeneratorSolarPanelScreenHandler;
import com.skniro.growable_ores_extension.screen.generator.GeneratorWindMillScreenHandler;
import com.skniro.growable_ores_extension.screen.machine.*;
import net.fabricmc.fabric.api.menu.v1.ExtendedMenuType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;

public class AlchemyScreenHandlerType <T extends AbstractContainerMenu>{
    public static final MenuType<AlchemyBlockScreenHandler> ALCHEMY =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "cane_converter_screen_handler"),
                    new ExtendedMenuType<>(AlchemyBlockScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<CoalGeneratorScreenHandler> COAL_GENERATOR_SCREEN_HANDLER =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "coal_generator_screen_handler"),
                    new ExtendedMenuType<>(CoalGeneratorScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<GeneratorWindMillScreenHandler> GENERATOR_Wind_Mill_SCREEN_HANDLER =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "generator_wind_mill_screen_handler"),
                    new ExtendedMenuType<>(GeneratorWindMillScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<GeneratorSolarPanelScreenHandler> GENERATOR_Solar_Panel_SCREEN_HANDLER =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "generator_solar_panel_screen_handler"),
                    new ExtendedMenuType<>(GeneratorSolarPanelScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<MaceratorScreenHandler> Macerator =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "macerator_screen_handler"),
                    new ExtendedMenuType<>(MaceratorScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<CompressorScreenHandler> Compressor =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "compressor_screen_handler"),
                    new ExtendedMenuType<>(CompressorScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<MetalFormerScreenHandler> MetalFormer =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "metal_former_screen_handler"),
                    new ExtendedMenuType<>(MetalFormerScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<EnergyBoxScreenHandler> EnergyBox =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "energy_box_screen_handler"),
                    new ExtendedMenuType<>(EnergyBoxScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<ChargePadScreenHandler> ChargePad =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "charge_pad_screen_handler"),
                    new ExtendedMenuType<>(ChargePadScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<MolecularTransformerScreenHandler> MolecularTransformer =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "molecular_transformer_screen_handler"),
                    new ExtendedMenuType<>(MolecularTransformerScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<ExtractorScreenHandler> Extractor =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "extractor_screen_handler"),
                    new ExtendedMenuType<>(ExtractorScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<ElectricFurnaceScreenHandler> ElectricFurnace =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "electric_furnace_screen_handler"),
                    new ExtendedMenuType<>(ElectricFurnaceScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<RecyclerScreenHandler> Recycler =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "recycler_screen_handler"),
                    new ExtendedMenuType<>(RecyclerScreenHandler::new, BlockPos.STREAM_CODEC));

    public static final MenuType<CuttingScreenHandler> Cutting =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "cutting_screen_handler"),
                    new ExtendedMenuType<>(CuttingScreenHandler::new, BlockPos.STREAM_CODEC));


    public static void registeralchemyscreenhandlertype() {

    }
}
