package com.skniro.maple.datagen;




import com.skniro.maple.block.MapleBlocks;
import com.skniro.maple.item.MapleArmorItems;
import com.skniro.maple.tag.MapleItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

import static com.skniro.maple.datagen.MapleItemTagGeneration.ModItemTags.C_CHERRY_LOGS;
import static net.minecraft.class_3489.*;


public class MapleItemTagGeneration extends FabricTagProvider.ItemTagProvider{
    public MapleItemTagGeneration(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(dataGenerator, completableFuture);
    }

    public static class ModItemTags {
        public static final class_6862<class_1792> C_SAPLING = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "saplings"));
        public static final class_6862<class_1792> C_MAPLE_LOGS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "maple_logs"));
        public static final class_6862<class_1792> C_CHERRY_LOGS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "cherry_logs"));
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        valueLookupBuilder(MapleItemTags.REPAIRS_CHERRY_ARMOR)
                .method_71554(MapleArmorItems.Cherry_INGOT);
        valueLookupBuilder(MapleItemTags.CHERRY_TOOL_MATERIALS)
                .method_71554(MapleArmorItems.Cherry_INGOT);
        valueLookupBuilder(field_15528)
                .method_71554(class_1792.method_7867(MapleBlocks.MAPLE_SAPLING))
                .method_71554(class_1792.method_7867(MapleBlocks.CHERRY_SAPLING))
                .method_71554(class_1792.method_7867(MapleBlocks.GINKGO_SAPLING))
                .method_71554(class_1792.method_7867(MapleBlocks.SAKURA_SAPLING))
                .method_71554(class_1792.method_7867(MapleBlocks.RED_MAPLE_SAPLING))
                .setReplace(false);
        valueLookupBuilder(C_CHERRY_LOGS)
                .method_71554(class_1792.method_7867(MapleBlocks.CHERRY_LOG));
        valueLookupBuilder(class_3489.field_41890)
                .method_71558(MapleArmorItems.Cherry_HELMET, MapleArmorItems.Cherry_CHESTPLATE, MapleArmorItems.Cherry_LEGGINGS, MapleArmorItems.Cherry_BOOTS)
                .setReplace(false);
        valueLookupBuilder(field_48294)
                .method_71554(MapleArmorItems.Cherry_BOOTS)
                .setReplace(false);
        valueLookupBuilder(field_48295)
                .method_71554(MapleArmorItems.Cherry_LEGGINGS)
                .setReplace(false);
        valueLookupBuilder(field_48296)
                .method_71554(MapleArmorItems.Cherry_CHESTPLATE)
                .setReplace(false);
        valueLookupBuilder(field_48297)
                .method_71554(MapleArmorItems.Cherry_HELMET)
                .setReplace(false);
        valueLookupBuilder(field_42611)
                .method_71554(MapleArmorItems.Cherry_SWORD)
                .setReplace(false);
        valueLookupBuilder(field_42612)
                .method_71554(MapleArmorItems.Cherry_AXE)
                .setReplace(false);
        valueLookupBuilder(field_42613)
                .method_71554(MapleArmorItems.Cherry_HOE)
                .setReplace(false);
        valueLookupBuilder(field_42614)
                .method_71554(MapleArmorItems.Cherry_PICKAXE)
                .setReplace(false);
        valueLookupBuilder(field_42615)
                .method_71554(MapleArmorItems.Cherry_SHOVEL)
                .setReplace(false);
    }


}
