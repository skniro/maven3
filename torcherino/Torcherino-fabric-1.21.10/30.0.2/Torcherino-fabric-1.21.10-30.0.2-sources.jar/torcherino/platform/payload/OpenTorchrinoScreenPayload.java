package torcherino.platform.payload;

import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import torcherino.Torcherino;

public record OpenTorchrinoScreenPayload(class_2338 blockPos, String title,  int xRange, int zRange, int yRange, int speed, int redstoneMode, class_2540 buf) implements class_8710 {
    public static final class_2960 OPEN_TORCHERINO_SCREEN = Torcherino.resloc("open_torcherino_screen");
    public static final class_9154<OpenTorchrinoScreenPayload> TYPE = new class_9154<>(OPEN_TORCHERINO_SCREEN);
    public static final class_9139<class_9129, OpenTorchrinoScreenPayload> CODEC = class_8710.method_56484(OpenTorchrinoScreenPayload::write, OpenTorchrinoScreenPayload::new);

    public OpenTorchrinoScreenPayload(final class_2540 buf){
        this(buf.method_10811(),
             buf.method_19772(),
             buf.readInt(),
             buf.readInt(),
             buf.readInt(),
             buf.readInt(),
             buf.readInt(),
             buf.method_52938()
        );
    }

    public void write(class_2540 buffer) {
        buffer.method_10807(blockPos);
        buffer.method_10814(String.valueOf(title));
        buffer.method_53002(xRange);
        buffer.method_53002(zRange);
        buffer.method_53002(yRange);
        buffer.method_53002(speed);
        buffer.method_53002(redstoneMode);
    }

    public void retain() {
        buf.method_52938();
    }

    public void release() {
        buf.release();
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
