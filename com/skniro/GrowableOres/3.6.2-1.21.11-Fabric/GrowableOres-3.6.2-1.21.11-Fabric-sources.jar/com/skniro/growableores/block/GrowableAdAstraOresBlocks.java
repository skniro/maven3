package com.skniro.growableores.block;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.util.GrowableOresItemGroups;
import com.skniro.growableores.block.init.GrowableOreCaneBlock;
import java.util.function.Function;
import java.util.logging.Logger;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class GrowableAdAstraOresBlocks {
    //Ad Astra!
    public static final class_2248 AD_Ostrum_Cane =registerBlock("ad_mars_ore_ostrum_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 AD_Ice_Shard_Cane =registerBlock("ad_moon_ice_shard_ore_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 AD_Cheese_Cane =registerBlock("ad_moon_ore_cheese_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 AD_Desh_Cane =registerBlock("ad_moon_ore_desh_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 AD_Calorite_Cane =registerBlock("ad_venus_calorite_ore_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);


    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings, class_5321<class_1761> tab) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GrowableOres.MOD_ID, name))));
        registerBlockItem(name, block, tab);
        return class_2378.method_39197(class_7923.field_41175, class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GrowableOres.MOD_ID, name)), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_5321<class_1761> tab) {
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOres.MOD_ID, name)),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOres.MOD_ID, name)))));
    }
    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + GrowableOres.MOD_ID);
    }
}

