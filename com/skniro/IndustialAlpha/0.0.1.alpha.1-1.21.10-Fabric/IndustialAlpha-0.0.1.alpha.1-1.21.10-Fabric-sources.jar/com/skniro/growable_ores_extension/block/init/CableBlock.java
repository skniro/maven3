package com.skniro.growable_ores_extension.block.init;


import com.mojang.serialization.MapCodec;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_10225;
import net.minecraft.class_10774;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import net.minecraft.class_9904;
import com.skniro.growable_ores_extension.ModContent;
import com.skniro.growable_ores_extension.block.entity.cable.CableBlockEntity;
import com.skniro.growable_ores_extension.block.entity.cable.CableElectrocutionEvent;
import org.jetbrains.annotations.Nullable;
import reborncore.api.ToolManager;
import reborncore.common.blocks.BlockWrenchEventHandler;
import reborncore.common.util.WrenchUtils;
import techreborn.config.TechRebornConfig;
import techreborn.init.ModSounds;
import techreborn.init.TRBlockSettings;
import techreborn.init.TRContent;
import techreborn.init.TRDamageTypes;
import techreborn.init.TRContent.Plates;

public class CableBlock extends class_2237 implements class_3737 {
    public static final class_2746 EAST;
    public static final class_2746 WEST;
    public static final class_2746 NORTH;
    public static final class_2746 SOUTH;
    public static final class_2746 UP;
    public static final class_2746 DOWN;
    public static final class_2746 WATERLOGGED;
    public static final class_2746 COVERED;
    public static final Map<class_2350, class_2746> PROPERTY_MAP;
    public final ModContent.Cables type;

    public CableBlock(ModContent.Cables type, String name) {
        super(TRBlockSettings.cable(name));
        this.type = type;
        this.method_9590((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)this.method_9595().method_11664()).method_11657(EAST, false)).method_11657(WEST, false)).method_11657(NORTH, false)).method_11657(SOUTH, false)).method_11657(UP, false)).method_11657(DOWN, false)).method_11657(WATERLOGGED, false)).method_11657(COVERED, false));
        BlockWrenchEventHandler.wrenchableBlocks.add(this);
    }

    protected MapCodec<? extends class_2237> method_53969() {
        throw new IllegalStateException("CableBlock does not support getCodec!");
    }

    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new CableBlockEntity(pos, state, this.type);
    }

    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return (world1, pos, state1, blockEntity) -> ((CableBlockEntity)blockEntity).tick(world1, pos, state1, (CableBlockEntity)blockEntity);
    }

    public class_1269 method_55766(class_2680 state, class_1937 worldIn, class_2338 pos, class_1657 playerIn, class_3965 hitResult) {
        class_1799 stack = playerIn.method_5998(class_1268.field_5808);
        class_2586 blockEntity = worldIn.method_8321(pos);
        if (blockEntity == null) {
            return class_1269.field_5814;
        } else if (stack.method_7960()) {
            return super.method_55766(state, worldIn, pos, playerIn, hitResult);
        } else {
            if (ToolManager.INSTANCE.canHandleTool(stack)) {
                if ((Boolean)state.method_11654(COVERED) && !playerIn.method_5715()) {
                    ((CableBlockEntity)blockEntity).setCover((class_2680)null);
                    worldIn.method_8501(pos, (class_2680)state.method_11657(COVERED, false));
                    worldIn.method_8396(playerIn, pos, class_3417.field_15215, class_3419.field_15245, 0.6F, 1.0F);
                    if (!worldIn.method_8608()) {
                        class_1264.method_5449(worldIn, (double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260(), Plates.WOOD.getStack());
                    }

                    return class_1269.field_5812;
                }

                if (WrenchUtils.handleWrench(stack, worldIn, pos, playerIn, hitResult.method_17780())) {
                    return class_1269.field_5812;
                }
            }

            if (!(Boolean)state.method_11654(COVERED) && !this.type.canKill && stack.method_7909() == Plates.WOOD.method_8389()) {
                worldIn.method_8501(pos, (class_2680)state.method_11657(COVERED, true));
                worldIn.method_8396(playerIn, pos, class_3417.field_14718, class_3419.field_15245, 0.6F, 1.0F);
                if (!worldIn.method_8608() && !playerIn.method_68878()) {
                    stack.method_7934(1);
                }

                return class_1269.field_5812;
            } else {
                return super.method_55766(state, worldIn, pos, playerIn, hitResult);
            }
        }
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{EAST, WEST, NORTH, SOUTH, UP, DOWN, WATERLOGGED, COVERED});
    }

    public class_2680 method_9605(class_1750 context) {
        return (class_2680)this.method_9564().method_11657(WATERLOGGED, context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910);
    }

    public class_2680 method_9559(class_2680 state, class_4538 world, class_10225 tickView, class_2338 pos, class_2350 direction, class_2338 neighborPos, class_2680 neighborState, class_5819 random) {
        if ((Boolean)state.method_11654(WATERLOGGED) && world instanceof class_1936 worldIn) {
            worldIn.method_64312(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
        }

        return state;
    }

    public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 block, @Nullable class_9904 wireOrientation, boolean notify) {
        class_2586 var8 = world.method_8321(pos);
        if (var8 instanceof CableBlockEntity cable) {
            cable.neighborUpdate();
        }

        super.method_9612(state, world, pos, block, wireOrientation, notify);
    }

    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 shapeContext) {
        return (Boolean)state.method_11654(COVERED) ? class_259.method_1077() : CableShapeUtil.getShape(state);
    }

    public class_265 method_9571(class_2680 state) {
        return CableShapeUtil.getShape(state);
    }

    protected void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity, class_10774 handler, boolean bl) {
        super.method_9548(state, world, pos, entity, handler, bl);
        if (this.type.canKill) {
            if (entity instanceof class_1309) {
                class_2586 blockEntity = world.method_8321(pos);
                if (blockEntity != null) {
                    if (blockEntity instanceof CableBlockEntity) {
                        CableBlockEntity blockEntityCable = (CableBlockEntity)blockEntity;
                        if (blockEntityCable.getEnergy() > 0L) {
                            if (((CableElectrocutionEvent)CableElectrocutionEvent.EVENT.invoker()).electrocute((class_1309)entity, this.type, pos, world, blockEntityCable)) {
                                if (TechRebornConfig.uninsulatedElectrocutionDamage) {
                                    if (this.type == ModContent.Cables.HV) {
                                        entity.method_5639(1.0F);
                                    }

                                    if (world instanceof class_3218) {
                                        class_3218 serverWorld = (class_3218)world;
                                        entity.method_64397(serverWorld, TRDamageTypes.create(world, TRDamageTypes.ELECTRIC_SHOCK), 1.0F);
                                    }

                                    blockEntityCable.setEnergy(0L);
                                }

                                if (TechRebornConfig.uninsulatedElectrocutionSound) {
                                    world.method_43128((class_1297)null, entity.method_23317(), entity.method_23318(), entity.method_23321(), ModSounds.CABLE_SHOCK, class_3419.field_15245, 0.6F, 1.0F);
                                }

                                if (TechRebornConfig.uninsulatedElectrocutionParticles) {
                                    world.method_8406(class_2398.field_11205, entity.method_23317(), entity.method_23318(), entity.method_23321(), (double)0.0F, (double)0.0F, (double)0.0F);
                                }

                            }
                        }
                    }
                }
            }
        }
    }

    public boolean method_10311(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        return !(Boolean)state.method_11654(COVERED) && class_3737.super.method_10311(world, pos, state, fluidState);
    }

    public boolean method_10310(class_1309 player, class_1922 view, class_2338 pos, class_2680 state, class_3611 fluid) {
        return !(Boolean)state.method_11654(COVERED) && class_3737.super.method_10310(player, view, pos, state, fluid);
    }

    public class_3610 method_9545(class_2680 state) {
        return (Boolean)state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    public class_2680 getAppearance(class_2680 state, class_1920 renderView, class_2338 pos, class_2350 side, @Nullable class_2680 sourceState, @Nullable class_2338 sourcePos) {
        if ((Boolean)state.method_11654(COVERED)) {
            Object var9 = renderView.getBlockEntityRenderData(pos);
            class_2680 cover;
            if (var9 instanceof class_2680) {
                class_2680 blockState = (class_2680)var9;
                cover = blockState;
            } else {
                cover = class_2246.field_10161.method_9564();
            }

            return cover;
        } else {
            return super.getAppearance(state, renderView, pos, side, sourceState, sourcePos);
        }
    }

    static {
        EAST = class_2741.field_12487;
        WEST = class_2741.field_12527;
        NORTH = class_2741.field_12489;
        SOUTH = class_2741.field_12540;
        UP = class_2741.field_12519;
        DOWN = class_2741.field_12546;
        WATERLOGGED = class_2741.field_12508;
        COVERED = class_2746.method_11825("covered");
        PROPERTY_MAP = (Map)class_156.method_654(new HashMap(), (map) -> {
            map.put(class_2350.field_11034, EAST);
            map.put(class_2350.field_11039, WEST);
            map.put(class_2350.field_11043, NORTH);
            map.put(class_2350.field_11035, SOUTH);
            map.put(class_2350.field_11036, UP);
            map.put(class_2350.field_11033, DOWN);
        });
    }
}