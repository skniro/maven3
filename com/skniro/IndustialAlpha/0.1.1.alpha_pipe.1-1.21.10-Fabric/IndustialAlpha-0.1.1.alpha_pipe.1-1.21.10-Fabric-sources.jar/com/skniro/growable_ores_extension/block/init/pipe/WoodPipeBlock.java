package com.skniro.growable_ores_extension.block.init.pipe;

import com.mojang.serialization.MapCodec;
import com.skniro.growable_ores_extension.block.entity.pipe.PipeBlockEntity;
import com.skniro.growable_ores_extension.block.entity.pipe.WoodPipeBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3737;
import net.minecraft.class_5558;
import net.minecraft.world.*;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;

public class WoodPipeBlock extends PipeBlock implements class_3737 {

    public WoodPipeBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new WoodPipeBlockEntity(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return (world1, pos, state1, blockEntity) ->
                ((WoodPipeBlockEntity) blockEntity).tick(world1, pos, state1);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        throw new IllegalStateException("PipeBlock does not support getCodec!");
    }
}