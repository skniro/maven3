package torcherino.blocks;


import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_11515;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1827;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import torcherino.Torcherino;
import torcherino.api.Tier;
import torcherino.api.TorcherinoAPI;
import torcherino.block.JackoLanterinoBlock;
import torcherino.block.LanterinoBlock;
import torcherino.block.TorcherinoBlock;
import torcherino.block.WallTorcherinoBlock;
import torcherino.block.entity.TorcherinoBlockEntity;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class ModBlocks {
    public static final ModBlocks INSTANCE = new ModBlocks();
    Set<class_2248> allBlocks = new HashSet<>();

    public void initialize() {
        Map<class_2960, Tier> tiers = TorcherinoAPI.INSTANCE.getTiers();
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> allBlocks.forEach((entries::method_45421)));

        tiers.forEach((tierId, tier) -> {
            if (!tierId.method_12836().equals(Torcherino.MOD_ID)) {
                return;
            }
            class_2960 torcherinoId = id(tierId, "torcherino");
            class_2960 jackoLanterinoId = id(tierId, "lanterino");
            class_2960 lanterinoId = id(tierId, "lantern");
            class_2400 particleEffect = (class_2400) class_7923.field_41180.method_63535(id(tierId, "flame"));
            TorcherinoBlock torcherinoBlock = new TorcherinoBlock(class_4970.class_2251.method_9630(class_2246.field_10336).method_50012(class_3619.field_15975).method_63500(Torcherino.KeyofBlock(torcherinoId.method_12832())), tierId, particleEffect);
            this.registerAndBlacklist(torcherinoId, torcherinoBlock);
            WallTorcherinoBlock torcherinoWallBlock = new WallTorcherinoBlock(class_4970.class_2251.method_9630(class_2246.field_10099).method_50012(class_3619.field_15975).method_63500(Torcherino.KeyofBlock("wall_" + torcherinoId.method_12832())).method_63501(torcherinoBlock.method_63499()).method_63502(torcherinoBlock.method_26162()), tierId, particleEffect);
            this.registerAndBlacklist(class_2960.method_60655(torcherinoId.method_12836(), "wall_" + torcherinoId.method_12832()), torcherinoWallBlock);
            JackoLanterinoBlock jackoLanterinoBlock = new JackoLanterinoBlock(class_4970.class_2251.method_9630(class_2246.field_10009).method_63500(Torcherino.KeyofBlock(jackoLanterinoId.method_12832())).method_50012(class_3619.field_15975), tierId);
            this.registerAndBlacklist(jackoLanterinoId, jackoLanterinoBlock);
            LanterinoBlock lanterinoBlock = new LanterinoBlock(class_4970.class_2251.method_9630(class_2246.field_16541).method_50012(class_3619.field_15975).method_63500(Torcherino.KeyofBlock(lanterinoId.method_12832())), tierId);
            this.registerAndBlacklist(lanterinoId, lanterinoBlock);
            if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
                this.setRenderType(torcherinoBlock);
                this.setRenderType(torcherinoWallBlock);
                this.setRenderType(lanterinoBlock);
            }
            class_1827 torcherinoItem = new class_1827(torcherinoBlock, torcherinoWallBlock, class_2350.field_11033, new class_1792.class_1793().method_63685().method_63686(Torcherino.KeyofItem(torcherinoId.method_12832())));
            class_2378.method_10230(class_7923.field_41178, torcherinoId, torcherinoItem);
            class_1747 jackoLanterinoItem = new class_1747(jackoLanterinoBlock, new class_1792.class_1793().method_63685().method_63686(Torcherino.KeyofItem(jackoLanterinoId.method_12832())));
            class_2378.method_10230(class_7923.field_41178, jackoLanterinoId, jackoLanterinoItem);
            class_1747 lanterinoItem = new class_1747(lanterinoBlock, new class_1792.class_1793().method_63685().method_63686(Torcherino.KeyofItem(lanterinoId.method_12832())));
            class_2378.method_10230(class_7923.field_41178, lanterinoId, lanterinoItem);
        });
        class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(Torcherino.MOD_ID, "torcherino"),
                FabricBlockEntityTypeBuilder.create(TorcherinoBlockEntity::new, allBlocks.toArray(new class_2248[0])).build(null));
    }

    @Environment(EnvType.CLIENT)
    private void setRenderType(class_2248 block) {
        BlockRenderLayerMap.putBlock(block, class_11515.field_60925);
    }

    private void registerAndBlacklist(class_2960 id, class_2248 block) {
        class_2378.method_10230(class_7923.field_41175, id, block);
        TorcherinoAPI.INSTANCE.blacklistBlock(id);
        allBlocks.add(block);
    }

    private class_2960 id(class_2960 tierID, String type) {
        if (tierID.method_12832().equals("normal")) {
            return class_2960.method_60655(Torcherino.MOD_ID, type);
        }
        return class_2960.method_60655(Torcherino.MOD_ID, tierID.method_12832() + '_' + type);
    }
}
