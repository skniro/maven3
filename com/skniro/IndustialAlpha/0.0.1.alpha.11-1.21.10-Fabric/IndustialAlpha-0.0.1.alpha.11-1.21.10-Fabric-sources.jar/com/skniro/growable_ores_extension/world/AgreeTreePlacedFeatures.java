package com.skniro.growable_ores_extension.world;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6817;
import net.minecraft.class_6819;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;
import java.util.List;

public class AgreeTreePlacedFeatures {
    public static final class_5321<class_6796> Rubber_TREE_PLACED = registerKey("rubber_tree_placed");


    public static void bootstrap(class_7891<class_6796> context) {
        var configuredFeatureRegistryEntryLookup = context.method_46799(class_7924.field_41239);
        register(context, Rubber_TREE_PLACED, configuredFeatureRegistryEntryLookup.method_46747(AgreeTreeConfiguredFeatures.Rubber_TREE),
                class_6819.method_39741(class_6817.method_39736(1, 0.1f, 2), GeneralBlocks.Rubber_SAPLING));
    }

    public static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(GrowableOresExtension.MOD_ID, name));
    }

    private static void register(class_7891<class_6796> context, class_5321<class_6796> key, class_6880<class_2975<?, ?>> configuration,
                                 List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(configuration, List.copyOf(modifiers)));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_6796> context, class_5321<class_6796> key,
                                                                                   class_6880<class_2975<?, ?>> configuration,
                                                                                   class_6797... modifiers) {
        register(context, key, configuration, List.of(modifiers));
    }
}