package com.skniro.growable_ores_extension.block.entity.machine;

import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import com.skniro.growable_ores_extension.recipe.machine.AbstractMachineCraftingRecipe;
import com.skniro.growable_ores_extension.recipe.machine.MolecularTransformerCraftingRecipe;
import com.skniro.growable_ores_extension.screen.machine.CompressorScreenHandler;
import com.skniro.growable_ores_extension.screen.machine.MolecularTransformerScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3956;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;
import java.util.Optional;

public class MolecularTransformerBlockEntity extends AbstractMachineEntity {

    public long energyProgress = 0;
    public long energyRequired = 0;

    public MolecularTransformerBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.MolecularTransformer_BLOCK_ENTITY, pos, state);
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) return;
        Optional<class_8786<AbstractMachineCraftingRecipe>> recipeOpt = getCurrentRecipe();
        if(recipeOpt.isPresent() && canInsertIntoOutputSlot()) {
            MolecularTransformerCraftingRecipe recipe = (MolecularTransformerCraftingRecipe) recipeOpt.get().comp_1933();
            energyRequired = recipe.getEnergyRequired();

            long availableEnergy = Math.min(energyContainer.amount, energyRequired - energyProgress);
            if(availableEnergy > 0) {
                try (Transaction tx = Transaction.openOuter()) {
                    energyContainer.getSideStorage(null).extract(availableEnergy, tx);
                    tx.commit();
                }
                energyProgress += availableEnergy;
            }

            method_31663(world, pos, state);

            if (energyProgress >= energyRequired) {
                craftItem();
                resetProgress();
            }
        }
    }

    private void resetProgress() {
        this.energyProgress = 0;
        this.energyRequired = 0;
    }

    public int getProgressScaled(int scale) {
        if (energyRequired == 0) return 0;
        return (int) ((energyProgress * scale) / energyRequired);
    }

    @Override
    protected void method_11007(class_11372 nbt) {
        super.method_11007(nbt);
        nbt.method_71466("molecular_transformer.energy_progress", energyProgress);
        nbt.method_71466("molecular_transformer.energy_required", energyRequired);
    }

    @Override
    protected void method_11014(class_11368 nbt) {
        super.method_11014(nbt);
        energyProgress = nbt.method_71425("molecular_transformer.energy_progress", energyProgress);
        energyRequired = nbt.method_71425("molecular_transformer.energy_required", energyRequired);
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Compressor);
    }

    public class_3956<?> getCurrentRecipeType() {
        return AlchemyRecipeType.MOLECULAR_TRANSFORMER.type;
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new MolecularTransformerScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }
}