package com.skniro.growable_ores_extension.api.data.recipe;

import com.skniro.growable_ores_extension.recipe.machine.MaceratorCraftingRecipe;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_161;
import net.minecraft.class_170;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1935;
import net.minecraft.class_2119;
import net.minecraft.class_5321;
import net.minecraft.class_5797;
import net.minecraft.class_6862;
import net.minecraft.class_7871;
import net.minecraft.class_8782;
import net.minecraft.class_8790;

public class MaceratorRecipeJsonBuilder implements class_5797 {
    private final class_7871<class_1792> itemLookup;
    private final List<class_1856> ingredient = new ArrayList<>();
    private final class_1792 result;
    private final int count;
    private final Map<String, class_175<?>> criteria = new LinkedHashMap<>();

    @Nullable
    private String group;

    private MaceratorRecipeJsonBuilder(class_7871<class_1792> itemLookup, class_1792 result, int count) {
        this.itemLookup = itemLookup;
        this.result = result;
        this.count = count;
    }

    public static MaceratorRecipeJsonBuilder create(class_7871<class_1792> itemLookup, class_1935 output, int count) {
        return new MaceratorRecipeJsonBuilder(itemLookup, output.method_8389(), count);
    }

    public static MaceratorRecipeJsonBuilder create(class_7871<class_1792> itemLookup, class_1935 output) {
        return create(itemLookup, output, 1);
    }

    public MaceratorRecipeJsonBuilder input(class_1935 item) {
        return input(item, 1);
    }

    public MaceratorRecipeJsonBuilder input(class_1935 item, int amount) {
        for (int i = 0; i < amount; i++) {
            this.ingredient.add(class_1856.method_8091(item));
        }
        return this;
    }
    public MaceratorRecipeJsonBuilder input(class_6862<class_1792> tag) {
        return input(tag, 1);
    }

    public MaceratorRecipeJsonBuilder input(class_6862<class_1792> tag, int amount) {
        class_1856 ing = class_1856.method_8106(itemLookup.method_46735(tag));
        for (int i = 0; i < amount; i++) {
            this.ingredient.add(ing);
        }
        return this;
    }


    public MaceratorRecipeJsonBuilder method_33530(String name,
                                                class_175<?> criterion) {
        this.criteria.put(name, criterion);
        return this;
    }

    public MaceratorRecipeJsonBuilder method_33529(@Nullable String group) {
        this.group = group;
        return this;
    }

    @Override
    public class_1792 method_36441() {
        return result;
    }

    @Override
    public void method_17972(class_8790 exporter, class_5321<class_1860<?>> recipeKey) {
        class_5321<class_1860<?>> finalKey = modifyRecipeKey(recipeKey, exporter);
        MaceratorCraftingRecipe recipe = new MaceratorCraftingRecipe(ingredient.getFirst(), new class_1799(result, count));
        if (criteria.isEmpty()) {
            exporter.method_53819(finalKey, recipe, null);
            return;
        }

        class_161.class_162 advancementBuilder = exporter.method_53818().method_705("has_the_recipe", class_2119.method_27847(recipeKey)).method_703(class_170.class_171.method_753(recipeKey)).method_704(class_8782.class_8797.field_1257);

        this.criteria.forEach(advancementBuilder::method_705);

        exporter.method_53819(finalKey, recipe, advancementBuilder.method_695(finalKey.method_29177().method_45138("recipes/")));

    }

    private class_5321<class_1860<?>> modifyRecipeKey(class_5321<class_1860<?>> recipeKey, class_8790 exporter) {
        return class_5321.method_29179(recipeKey.method_58273(), exporter.getRecipeIdentifier(recipeKey.method_29177().method_45138("macerator/")));
    }
}