package com.skniro.chunk_loader.datagen;

import com.skniro.chunk_loader.block.GrowableOresBlocks;
import com.skniro.chunk_loader.init.FurnitureStrings;
import com.skniro.chunk_loader.item.*;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.core.HolderLookup;
import java.util.concurrent.CompletableFuture;

public class ChunkLoaderEnglishLanguageProvider extends FabricLanguageProvider {
    public ChunkLoaderEnglishLanguageProvider(FabricPackOutput dataGenerator, CompletableFuture<HolderLookup.Provider> registryLookup){
        super(dataGenerator,"en_us",registryLookup);
    }

    @Override
    public void generateTranslations(HolderLookup.Provider registryLookup, TranslationBuilder translationBuilder) {
        translationBuilder.add(FurnitureStrings.ChunkLoader, "ChunkLoader");
        translationBuilder.add(GrowableOresBlocks.CHUNK_LOADER, "ChunkLoader");
        translationBuilder.add(ModCreativeTab.Machine, "Machines");
    }
}
