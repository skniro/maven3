package torcherino.config;

import com.google.gson.*;
import java.lang.reflect.Type;
import net.minecraft.class_2960;
import net.minecraft.class_3518;

public class ResourceLocationAdapter implements JsonSerializer<class_2960>, JsonDeserializer<class_2960> {

    @Override
    public JsonElement serialize(class_2960 resourceLocation, Type type, JsonSerializationContext jsonSerializationContext) {
        return new JsonPrimitive(resourceLocation.toString());
    }

    @Override
    public class_2960 deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
        return class_2960.method_60654(class_3518.method_15287(jsonElement, "location"));
    }
}
