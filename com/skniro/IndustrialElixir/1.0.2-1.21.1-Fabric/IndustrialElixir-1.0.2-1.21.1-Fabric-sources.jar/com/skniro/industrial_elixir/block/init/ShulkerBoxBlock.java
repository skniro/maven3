package com.skniro.industrial_elixir.block.init;

import com.mojang.serialization.MapCodec;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_1606;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_2627;
import net.minecraft.class_2627.class_2628;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3468;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4838;
import net.minecraft.class_5558;
import net.minecraft.class_8567;
import org.jetbrains.annotations.Nullable;

public class ShulkerBoxBlock extends class_2237 {
    public static final MapCodec<ShulkerBoxBlock> CODEC = method_54094(ShulkerBoxBlock::new);
    // 26.1 builds this with Shapes.rotateAll(Block.boxZ(...)); 1.21.1 has neither helper, so the six
    // rotated copies of the 1/16 thick slab are listed explicitly (the same values vanilla uses).
    public static final Map<class_2350, class_265> SHAPES_BY_DIRECTION = createShapesByDirection();
    public static final class_2754<class_2350> FACING;
    public static final class_2960 CONTENTS_DYNAMIC_DROP_ID;

    private static Map<class_2350, class_265> createShapesByDirection() {
        Map<class_2350, class_265> shapes = new EnumMap<>(class_2350.class);
        shapes.put(class_2350.field_11043, class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 1.0));
        shapes.put(class_2350.field_11035, class_2248.method_9541(0.0, 0.0, 15.0, 16.0, 16.0, 16.0));
        shapes.put(class_2350.field_11039, class_2248.method_9541(0.0, 0.0, 0.0, 1.0, 16.0, 16.0));
        shapes.put(class_2350.field_11034, class_2248.method_9541(15.0, 0.0, 0.0, 16.0, 16.0, 16.0));
        shapes.put(class_2350.field_11033, class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 1.0, 16.0));
        shapes.put(class_2350.field_11036, class_2248.method_9541(0.0, 15.0, 0.0, 16.0, 16.0, 16.0));
        return shapes;
    }

    public MapCodec<ShulkerBoxBlock> method_53969() {
        return field_46280;
    }

    public ShulkerBoxBlock(class_2251 settings) {
        super(settings);
        this.method_9590((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11036));
    }

    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new class_2627(pos, state);
    }

    public <T extends class_2586> @Nullable class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, class_2591.field_11896, class_2627::method_31694);
    }

    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world instanceof class_3218) {
            class_2586 var8 = world.method_8321(pos);
            if (var8 instanceof class_2627 shulkerBoxBlockEntity) {
                if (canOpen(state, world, pos, shulkerBoxBlockEntity)) {
                    player.method_17355(shulkerBoxBlockEntity);
                    player.method_7281(class_3468.field_15418);
                    class_4838.method_24733(player, true);
                }
            }
        }

        return class_1269.field_5812;
    }

    private static boolean canOpen(class_2680 state, class_1937 world, class_2338 pos, class_2627 entity) {
        if (entity.method_11313() != class_2628.field_12065) {
            return true;
        } else {
            class_238 box = class_1606.method_33347(1.0F, (class_2350)state.method_11654(FACING), 0.0F, 0.5F).method_996(pos).method_1011(1.0E-6);
            return world.method_18026(box);
        }
    }

    public class_2680 method_9605(class_1750 ctx) {
        return (class_2680)this.method_9564().method_11657(FACING, ctx.method_8038());
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{FACING});
    }

    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof class_2627 shulkerBoxBlockEntity) {
            if (!world.method_8608() && player.method_7337() && !shulkerBoxBlockEntity.method_5442()) {
                class_1799 itemStack = state.method_26204().method_8389().method_7854();
                itemStack.method_57365(blockEntity.method_57590());
                class_1542 itemEntity = new class_1542(world, (double)pos.method_10263() + (double)0.5F, (double)pos.method_10264() + (double)0.5F, (double)pos.method_10260() + (double)0.5F, itemStack);
                itemEntity.method_6988();
                world.method_8649(itemEntity);
            } else {
                shulkerBoxBlockEntity.method_54873(player);
            }
        }

        return super.method_9576(world, pos, state, player);
    }

    protected List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder) {
        class_2586 blockEntity = (class_2586)builder.method_51876(class_181.field_1228);
        if (blockEntity instanceof class_2627 shulkerBoxBlockEntity) {
            builder = builder.method_51872(CONTENTS_DYNAMIC_DROP_ID, (consumer) -> {
                for(int i = 0; i < shulkerBoxBlockEntity.method_5439(); ++i) {
                    consumer.accept(shulkerBoxBlockEntity.method_5438(i));
                }

            });
        }

        return super.method_9560(state, builder);
    }

    protected void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            class_2586 blockEntity = world.method_8321(pos);
            super.method_9536(state, world, pos, newState, moved);
            if (blockEntity instanceof class_2627) {
                world.method_8455(pos, state.method_26204());
            }
        }
    }

    protected class_265 method_25959(class_2680 state, class_1922 world, class_2338 pos) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof class_2627 shulkerBoxBlockEntity) {
            if (!shulkerBoxBlockEntity.method_27093()) {
                return (class_265)SHAPES_BY_DIRECTION.get(((class_2350)state.method_11654(FACING)).method_10153());
            }
        }

        return class_259.method_1077();
    }

    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof class_2627 shulkerBoxBlockEntity) {
            return class_259.method_1078(shulkerBoxBlockEntity.method_11314(state));
        } else {
            return class_259.method_1077();
        }
    }

    protected boolean method_9579(class_2680 state, class_1922 world, class_2338 pos) {
        return false;
    }

    protected boolean method_9498(class_2680 state) {
        return true;
    }

    protected int method_9572(class_2680 state, class_1937 world, class_2338 pos) {
        return class_1703.method_7608(world.method_8321(pos));
    }

    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return (class_2680)state.method_11657(FACING, rotation.method_10503((class_2350)state.method_11654(FACING)));
    }

    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345((class_2350)state.method_11654(FACING)));
    }

    static {
        FACING = class_2318.field_10927;
        CONTENTS_DYNAMIC_DROP_ID = class_2960.method_60656("contents");
    }
}
