package com.skniro.industrial_elixir.api.block;

import com.skniro.industrial_elixir.fluid.IndustrialElixirFluidItems;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluids;
import com.skniro.industrial_elixir.util.ModBooleanPropertys;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2263;
import net.minecraft.class_2338;
import net.minecraft.class_2402;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3610;
import net.minecraft.class_3611;

public interface SimpleHotsSpringLoggedBlock extends class_2263, class_2402 {
    default boolean canPlaceLiquid(final @Nullable class_1309 user, final class_1922 level, final class_2338 pos, final class_2680 state, final class_3611 type) {
        return type == IndustrialElixirFluids.STILL_Hot_Spring;
    }

    default boolean method_10311(final class_1936 level, final class_2338 pos, final class_2680 state, final class_3610 fluidState) {
        if (!(Boolean)state.method_11654(ModBooleanPropertys.HOT_SPRING_LOGGED) && fluidState.method_39360(IndustrialElixirFluids.STILL_Hot_Spring)) {
            if (!level.method_8608()) {
                level.method_8652(pos, (class_2680)state.method_11657(ModBooleanPropertys.HOT_SPRING_LOGGED, true), 3);
                level.method_39281(pos, fluidState.method_15772(), fluidState.method_15772().method_15789(level));
            }

            return true;
        } else {
            return false;
        }
    }

    default class_1799 pickupBlock(final @Nullable class_1309 user, final class_1936 level, final class_2338 pos, final class_2680 state) {
        if (state.method_11654(ModBooleanPropertys.HOT_SPRING_LOGGED)) {
            level.method_8652(pos, (class_2680)state.method_11657(ModBooleanPropertys.HOT_SPRING_LOGGED, false), 3);
            if (!state.method_26184(level, pos)) {
                level.method_22352(pos, true);
            }

            return new class_1799(IndustrialElixirFluidItems.Hot_Spring_BUCKET);
        } else {
            return class_1799.field_8037;
        }
    }

    default Optional<class_3414> method_32351() {
        return IndustrialElixirFluids.STILL_Fluid_UU.method_32359();
    }
}
