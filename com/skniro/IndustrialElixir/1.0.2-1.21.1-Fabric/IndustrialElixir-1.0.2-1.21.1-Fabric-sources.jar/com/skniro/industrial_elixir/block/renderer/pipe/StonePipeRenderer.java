package com.skniro.industrial_elixir.block.renderer.pipe;

import com.skniro.industrial_elixir.block.entity.pipe.PipeBlockEntity.PipeItem;
import com.skniro.industrial_elixir.block.entity.pipe.WoodPipeBlockEntity;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_918;

public class StonePipeRenderer implements class_827<WoodPipeBlockEntity> {

    @Override
    public void render(WoodPipeBlockEntity entity, float partialTick, class_4587 matrices, class_4597 buffer, int packedLight, int packedOverlay) {
        class_918 itemRenderer = class_310.method_1551().method_1480();
        class_1937 level = entity.method_10997();
        int light = getLightLevel(level, entity.method_11016());

        for (PipeItem item : entity.getItems()) {
            if (item.variant.isBlank() || item.amount <= 0) {
                continue;
            }

            matrices.method_22903();
            matrices.method_22904(0.5 + item.direction.method_10148() * item.progress,
                    0.5 + item.direction.method_10164() * item.progress,
                    0.5 + item.direction.method_10165() * item.progress);
            matrices.method_22905(0.35f, 0.35f, 0.35f);
            itemRenderer.method_23178(item.variant.toStack(), class_811.field_4318, light,
                    class_4608.field_21444, matrices, buffer, level, 0);
            matrices.method_22909();
        }
    }

    private int getLightLevel(class_1937 world, class_2338 pos) {
        if (world == null) {
            return class_765.field_32767;
        }
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, Math.max(sLight, 15));
    }
}
