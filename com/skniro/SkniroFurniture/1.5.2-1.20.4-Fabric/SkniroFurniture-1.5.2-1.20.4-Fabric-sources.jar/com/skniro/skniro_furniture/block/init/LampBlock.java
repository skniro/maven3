package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;

public class LampBlock extends AbstractLampBlock{
    public static final MapCodec<LampBlock> CODEC = method_54094(LampBlock::new);
    private static final class_265 SHAPE = class_2248.method_9541(0.0, 14.5, 0.0, 16.0, 16.0, 16.0);

    public LampBlock(class_2251 settings) {
        super(settings);
    }

    public MapCodec<LampBlock> method_53969() {
        return field_46280;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }
}
