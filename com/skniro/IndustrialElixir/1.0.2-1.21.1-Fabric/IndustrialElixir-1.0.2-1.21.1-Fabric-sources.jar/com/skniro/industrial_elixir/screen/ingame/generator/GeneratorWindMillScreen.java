package com.skniro.industrial_elixir.screen.ingame.generator;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.block.entity.generator.GeneratorWindMillBlockEntity;
import com.skniro.industrial_elixir.screen.handler.generator.GeneratorWindMillScreenHandler;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class GeneratorWindMillScreen extends class_465<GeneratorWindMillScreenHandler> {
    private static final class_2960 GUI_TEXTURE =
            class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/generator/guiwindmill.png");

    public GeneratorWindMillScreen(GeneratorWindMillScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        // Center title
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
    }

    public void drawState(class_332 context) {
        GeneratorWindMillBlockEntity.GeneratorState state = field_2797.getState();
        Integer statey = switch (state) {
            case IDLE -> 0;
            case GENERATING -> 13;
            case DANGER -> 26;
        };
        context.method_25290(GUI_TEXTURE, field_2776 + 80, field_2800 + 65, 176, statey, 13, 15,256,256);
    }

    @Override
    protected void method_2389(class_332 context, float partialTicks, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        context.method_25290(GUI_TEXTURE, x, y, 0, 0, field_2792, field_2779,256,256);
        drawState(context);
    }


    @Override
    public void method_25394(class_332 context , int mouseX, int mouseY, float delta) {
        method_2389(context, delta, mouseX, mouseY);
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }
}