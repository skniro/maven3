package com.skniro.industrial_elixir.api.item;

import com.skniro.industrial_elixir.ModContent;
import com.skniro.industrial_elixir.api.block.TieredEnergyBlock;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.init.CableBlock;
import com.skniro.industrial_elixir.energy.api.base.SimpleEnergyItem;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2561;

public class EnergyTooltipHelper {

    private static final String ENERGY_UNIT = "EP";

    public static void appendEnergyTooltip(class_1799 stack, Consumer<class_2561> tooltip) {
        // For items that store energy (batteries, quantum armor, jetpack)
        if (stack.method_7909() instanceof SimpleEnergyItem energyItem) {
            long stored = energyItem.getStoredEnergy(stack);
            long capacity = energyItem.getEnergyCapacity(stack);

            tooltip.accept(class_2561.method_43469("tooltip.industrial_elixir.energy.stored",
                            formatNumber(stored), formatNumber(capacity))
                    .method_27692(class_124.field_1065));

            if (energyItem instanceof TieredEnergyItem tieredItem) {
                EnergyTier tier = tieredItem.getEnergyTier();
                tooltip.accept(class_2561.method_43469("tooltip.industrial_elixir.energy.tier",
                                tier.name())
                        .method_27692(class_124.field_1080));

                long maxIn = energyItem.getEnergyMaxInput(stack);
                long maxOut = energyItem.getEnergyMaxOutput(stack);
                if (maxIn > 0 || maxOut > 0) {
                    tooltip.accept(class_2561.method_43469("tooltip.industrial_elixir.energy.max_io",
                                    formatNumber(maxIn), formatNumber(maxOut))
                            .method_27692(class_124.field_1063));
                }
            }
        }

        // For machine block items
        if (stack.method_7909() instanceof class_1747 blockItem) {
            if (blockItem.method_7711() instanceof CableBlock cableBlock) {
                ModContent.Cables cable = cableBlock.type;
                tooltip.accept(class_2561.method_43469("tooltip.industrial_elixir.cable.transfer_rate",
                                formatNumber(cable.transferRate))
                        .method_27692(class_124.field_1065));
                tooltip.accept(class_2561.method_43469("tooltip.industrial_elixir.cable.tier",
                                cable.tier.name())
                        .method_27692(class_124.field_1080));
                if (cable.canKill) {
                    tooltip.accept(class_2561.method_43471("tooltip.industrial_elixir.cable.uninsulated")
                            .method_27692(class_124.field_1061));
                } else {
                    tooltip.accept(class_2561.method_43471("tooltip.industrial_elixir.cable.insulated")
                            .method_27692(class_124.field_1077));
                }
            }

            if (blockItem.method_7711() instanceof TieredEnergyBlock energyBlock) {
                EnergyTier tier = energyBlock.getEnergyTier();
                long capacity = energyBlock.getMaxCapacity();

                tooltip.accept(class_2561.method_43469("tooltip.industrial_elixir.energy.tier",
                                tier.name())
                        .method_27692(class_124.field_1080));
                tooltip.accept(class_2561.method_43469("tooltip.industrial_elixir.energy.capacity",
                                formatNumber(capacity) + " " + ENERGY_UNIT)
                        .method_27692(class_124.field_1063));
                tooltip.accept(class_2561.method_43469("tooltip.industrial_elixir.energy.max_io",
                                formatNumber(tier.getMaxInput()), formatNumber(tier.getMaxOutput()))
                        .method_27692(class_124.field_1063));
            }
        }
    }

    private static String formatNumber(long number) {
        if (number >= 1_000_000_000) {
            double val = number / 1_000_000_000.0;
            if (val == Math.floor(val)) {
                return String.format("%.0fG", val);
            }
            return String.format("%.1fG", val);
        }
        if (number >= 1_000_000) {
            double val = number / 1_000_000.0;
            if (val == Math.floor(val)) {
                return String.format("%.0fM", val);
            }
            return String.format("%.1fM", val);
        }
        if (number >= 1_000) {
            double val = number / 1_000.0;
            if (val == Math.floor(val)) {
                return String.format("%.0fK", val);
            }
            return String.format("%.1fK", val);
        }
        java.text.NumberFormat nf = java.text.NumberFormat.getIntegerInstance();
        return nf.format(number);
    }
}
