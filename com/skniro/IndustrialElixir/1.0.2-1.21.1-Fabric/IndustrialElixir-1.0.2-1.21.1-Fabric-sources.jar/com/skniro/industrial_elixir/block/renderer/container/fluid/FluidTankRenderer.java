package com.skniro.industrial_elixir.block.renderer.container.fluid;

import com.skniro.industrial_elixir.block.entity.container.fluid.FluidTankBlockEntity;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.minecraft.class_1058;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_827;

public class FluidTankRenderer implements class_827<FluidTankBlockEntity> {
    private static final float TANK_INSET = 0.14f;
    private static final float MIN_FLUID_Y = 0.02f;
    private static final float MAX_FLUID_Y = 0.98f;
    private static final float MIN_VISIBLE_HEIGHT = 0.02f;

    public FluidTankRenderer(class_5614.class_5615 context) {
    }

    @Override
    public void render(FluidTankBlockEntity entity, float partialTick, class_4587 matrices, class_4597 buffer, int packedLight, int packedOverlay) {
        class_1937 level = entity.method_10997();
        int lightmapCoordinates = level == null ? class_765.field_32767 : getLightLevel(level, entity.method_11016());

        FluidVariant fluidVariant = entity.getFluidVariant();
        boolean hasFluid = entity.getAmount() > 0 && !fluidVariant.isBlank();
        if (!hasFluid) {
            return;
        }

        int fluidColor = resolveColor(fluidVariant);
        float fluidHeight = getFluidHeight(entity.getFillRatio());

        class_1058 fluidStillSprite = FluidVariantRendering.getSprite(fluidVariant);
        class_1058 fluidFlowSprite = fluidStillSprite;

        matrices.method_22903();

        // 即使没有精灵，我们也可以渲染纯色液体
        // 这会允许至少看到液体的存在
        class_4588 vertexConsumer = buffer.getBuffer(class_1921.method_29380());
        if (fluidStillSprite != null && fluidFlowSprite != null) {
            renderFluidBox(matrices.method_23760(), vertexConsumer, fluidStillSprite, fluidFlowSprite, fluidColor, lightmapCoordinates, fluidHeight);
        } else {
            // 作为回退，使用纯色渲染
            renderFluidBoxSolidColor(matrices.method_23760(), vertexConsumer, fluidColor, lightmapCoordinates, fluidHeight);
        }

        matrices.method_22909();
    }

    private static void renderFluidBoxSolidColor(class_4587.class_4665 pose, class_4588 vertexConsumer, int color, int light, float height) {
        float minX = TANK_INSET;
        float maxX = 1.0f - TANK_INSET;
        float minZ = TANK_INSET;
        float maxZ = 1.0f - TANK_INSET;
        float minY = MIN_FLUID_Y;
        float maxY = Math.min(MAX_FLUID_Y, MIN_FLUID_Y + height);

        if (maxY <= minY) {
            return;
        }

        // 使用固定的 UV（不需要精灵）
        float u0 = 0.0f;
        float u1 = 1.0f;
        float v0 = 0.0f;
        float v1 = 1.0f;

        // 顶面
        quad(vertexConsumer, pose, color, light,
                minX, maxY, minZ,
                minX, maxY, maxZ,
                maxX, maxY, maxZ,
                maxX, maxY, minZ,
                u0, v1, u1, v0,
                0.0f, 1.0f, 0.0f);

        // 底面
        quad(vertexConsumer, pose, color, light,
                minX, minY, maxZ,
                minX, minY, minZ,
                maxX, minY, minZ,
                maxX, minY, maxZ,
                u0, v1, u1, v0,
                0.0f, -1.0f, 0.0f);

        // 四个侧面
        quad(vertexConsumer, pose, color, light,
                minX, minY, minZ,
                minX, maxY, minZ,
                maxX, maxY, minZ,
                maxX, minY, minZ,
                u0, v1, u1, v0,
                0.0f, 0.0f, -1.0f);

        quad(vertexConsumer, pose, color, light,
                maxX, minY, maxZ,
                maxX, maxY, maxZ,
                minX, maxY, maxZ,
                minX, minY, maxZ,
                u0, v1, u1, v0,
                0.0f, 0.0f, 1.0f);

        quad(vertexConsumer, pose, color, light,
                minX, minY, maxZ,
                maxX, minY, maxZ,
                maxX, maxY, maxZ,
                minX, maxY, maxZ,
                u0, v1, u1, v0,
                1.0f, 0.0f, 0.0f);

        quad(vertexConsumer, pose, color, light,
                minX, minY, minZ,
                minX, maxY, minZ,
                minX, maxY, maxZ,
                minX, minY, maxZ,
                u0, v1, u1, v0,
                -1.0f, 0.0f, 0.0f);
    }

    private int getLightLevel(class_1937 world, class_2338 pos) {
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, Math.max(sLight, 15));
    }

    private static float getFluidHeight(float fillRatio) {
        float clampedRatio = Math.max(0.0f, Math.min(1.0f, fillRatio));
        float usableHeight = MAX_FLUID_Y - MIN_FLUID_Y;
        if (clampedRatio <= 0.0f) {
            return 0.0f;
        }
        return Math.max(MIN_VISIBLE_HEIGHT, clampedRatio * usableHeight);
    }

    private static int resolveColor(net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant variant) {
        try {
            int color = FluidVariantRendering.getColor(variant);
            return color;
        } catch (Throwable ignored) {
        }

        class_3611 fluid = variant.getFluid();
        // 回退到硬编码的颜色
        if (fluid == class_3612.field_15908 || fluid == class_3612.field_15907) {
            return 0xFFFFA000;
        }
        if (fluid == class_3612.field_15910 || fluid == class_3612.field_15909) {
            return 0xFF3F76E4;
        }
        return 0xFFFFFFFF;
    }

    private static void renderFluidBox(class_4587.class_4665 pose, class_4588 vertexConsumer, class_1058 stillSprite, class_1058 flowSprite, int color, int light, float height) {
        float minX = TANK_INSET;
        float maxX = 1.0f - TANK_INSET;
        float minZ = TANK_INSET;
        float maxZ = 1.0f - TANK_INSET;
        float minY = MIN_FLUID_Y;
        float maxY = Math.min(MAX_FLUID_Y, MIN_FLUID_Y + height);

        if (maxY <= minY) {
            return;
        }

        float u0 = stillSprite.method_4594();
        float u1 = stillSprite.method_4577();
        float v0 = stillSprite.method_4593();
        float v1 = stillSprite.method_4575();
        float fu0 = flowSprite.method_4594();
        float fu1 = flowSprite.method_4577();
        float fv0 = flowSprite.method_4593();
        float fv1 = flowSprite.method_4575();
        float sideV1 = lerp(maxY - minY, fv0, fv1);

        quad(vertexConsumer, pose, color, light,
                minX, maxY, minZ,
                minX, maxY, maxZ,
                maxX, maxY, maxZ,
                maxX, maxY, minZ,
                u0, v1, u1, v0,
                0.0f, 1.0f, 0.0f);

        quad(vertexConsumer, pose, color, light,
                minX, minY, maxZ,
                minX, minY, minZ,
                maxX, minY, minZ,
                maxX, minY, maxZ,
                u0, v1, u1, v0,
                0.0f, -1.0f, 0.0f);

        quad(vertexConsumer, pose, color, light,
                minX, minY, minZ,
                minX, maxY, minZ,
                maxX, maxY, minZ,
                maxX, minY, minZ,
                fu0, sideV1, fu1, fv0,
                0.0f, 0.0f, -1.0f);

        quad(vertexConsumer, pose, color, light,
                maxX, minY, maxZ,
                maxX, maxY, maxZ,
                minX, maxY, maxZ,
                minX, minY, maxZ,
                fu0, sideV1, fu1, fv0,
                0.0f, 0.0f, 1.0f);

        quad(vertexConsumer, pose, color, light,
                minX, minY, maxZ,
                maxX, minY, maxZ,
                maxX, maxY, maxZ,
                minX, maxY, maxZ,
                fu0, sideV1, fu1, fv0,
                1.0f, 0.0f, 0.0f);

        quad(vertexConsumer, pose, color, light,
                minX, minY, minZ,
                minX, maxY, minZ,
                minX, maxY, maxZ,
                minX, minY, maxZ,
                fu0, sideV1, fu1, fv0,
                -1.0f, 0.0f, 0.0f);
    }

    private static float lerp(float delta, float start, float end) {
        return start + delta * (end - start);
    }

    private static void quad(class_4588 consumer, class_4587.class_4665 pose, int color, int light,
                             float x0, float y0, float z0,
                             float x1, float y1, float z1,
                             float x2, float y2, float z2,
                             float x3, float y3, float z3,
                             float u0, float v0, float u1, float v1,
                             float nx, float ny, float nz) {
        vertex(consumer, pose, x0, y0, z0, color, u0, v1, light, nx, ny, nz);
        vertex(consumer, pose, x1, y1, z1, color, u0, v0, light, nx, ny, nz);
        vertex(consumer, pose, x2, y2, z2, color, u1, v0, light, nx, ny, nz);
        vertex(consumer, pose, x3, y3, z3, color, u1, v1, light, nx, ny, nz);
    }

    private static void vertex(class_4588 consumer, class_4587.class_4665 pose, float x, float y, float z, int color, float u, float v, int light, float nx, float ny, float nz) {
        consumer.method_56824(pose, x, y, z)
                .method_39415(color)
                .method_22913(u, v)
                .method_22922(class_4608.field_21444)
                .method_60803(light)
                .method_60831(pose, nx, ny, nz);
    }
}
