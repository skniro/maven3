package torcherino.platform;

import com.google.common.base.Suppliers;
import com.google.common.collect.ImmutableMap;
import io.netty.buffer.Unpooled;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import torcherino.Torcherino;
import torcherino.TorcherinoImpl;
import torcherino.api.Tier;
import torcherino.api.TorcherinoAPI;
import torcherino.block.entity.TorcherinoBlockEntity;
import torcherino.client.screen.TorcherinoScreen;
import torcherino.config.Config;

import java.util.HashMap;
import java.util.HashSet;
import java.util.function.Supplier;

public class NetworkUtilsImpl implements NetworkUtils {
    private static final Supplier<NetworkUtilsImpl> instance = Suppliers.memoize(NetworkUtilsImpl::new);
    private static final class_2960 UPDATE_TORCHERINO_VALUES = Torcherino.resloc("update_torcherino_values");
    private static final class_2960 TORCHERINO_TIER_SYNC = Torcherino.resloc("torcherino_tier_sync");
    private static final class_2960 OPEN_TORCHERINO_SCREEN = Torcherino.resloc("open_torcherino_screen");
    private final HashSet<String> allowedUuids = new HashSet<>();

    public static NetworkUtilsImpl getInstance() {
        return instance.get();
    }

    public void initialize() {
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            ClientNetworking.initialize();
        }
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.field_14140;
            allowedUuids.add(player.method_5845());

            ImmutableMap<class_2960, Tier> tiers = TorcherinoAPI.INSTANCE.getTiers();
            class_2540 buffer = new class_2540(Unpooled.buffer());
            buffer.method_53002(tiers.size());
            tiers.forEach((id, tier) -> {
                buffer.method_10812(id);
                buffer.method_53002(tier.maxSpeed());
                buffer.method_53002(tier.xzRange());
                buffer.method_53002(tier.yRange());
            });

            sender.sendPacket(TORCHERINO_TIER_SYNC, buffer);
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            if (Config.INSTANCE.online_mode.equals("ONLINE")) {
                allowedUuids.remove(handler.field_14140.method_5845());
            }
        });
        ServerPlayConnectionEvents.INIT.register((handler, server) -> {
            ServerPlayNetworking.registerReceiver(handler, NetworkUtilsImpl.UPDATE_TORCHERINO_VALUES, (server1, player, handler1, buffer, responseSender) -> {
                class_1937 level = player.method_37908();
                class_2338 pos = buffer.method_10811();
                int xRange = buffer.readInt();
                int zRange = buffer.readInt();
                int yRange = buffer.readInt();
                int speed = buffer.readInt();
                int redstoneMode = buffer.readInt();
                server1.method_20493(() -> {
                    if (level.method_8321(pos) instanceof TorcherinoBlockEntity blockEntity) {
                        if (!blockEntity.readClientData(xRange, zRange, yRange, speed, redstoneMode)) {
                            Torcherino.LOGGER.error("Data received from " + player.method_5477().getString() + "(" + player.method_5845() + ") is invalid.");
                        }
                    }
                });
            });
        });
    }

    @Override
    public void c2s_updateTorcherinoValues(class_2338 pos, int xRange, int zRange, int yRange, int speed, int redstoneMode) {
        if (ClientPlayNetworking.canSend(NetworkUtilsImpl.UPDATE_TORCHERINO_VALUES)) {
            class_2540 buffer = new class_2540(Unpooled.buffer());
            buffer.method_10807(pos);
            buffer.method_53002(xRange);
            buffer.method_53002(zRange);
            buffer.method_53002(yRange);
            buffer.method_53002(speed);
            buffer.method_53002(redstoneMode);
            ClientPlayNetworking.send(NetworkUtilsImpl.UPDATE_TORCHERINO_VALUES, buffer);
        }
    }

    @Override
    public void s2c_openTorcherinoScreen(class_3222 player, class_2338 pos, class_2561 name, int xRange, int zRange, int yRange, int speed, int redstoneMode) {
        if (ServerPlayNetworking.canSend(player, NetworkUtilsImpl.OPEN_TORCHERINO_SCREEN)) {
            class_2540 buffer = new class_2540(Unpooled.buffer());
            buffer.method_10807(pos);
            buffer.method_10805(name);
            buffer.method_53002(xRange);
            buffer.method_53002(zRange);
            buffer.method_53002(yRange);
            buffer.method_53002(speed);
            buffer.method_53002(redstoneMode);
            ServerPlayNetworking.send(player, NetworkUtilsImpl.OPEN_TORCHERINO_SCREEN, buffer);
        }
    }

    @Override
    public boolean s_isPlayerOnline(String uuid) {
        return allowedUuids.contains(uuid);
    }

    private static class ClientNetworking {
        private static void initialize() {
            ClientPlayConnectionEvents.INIT.register((handler, client) -> {
                ClientPlayNetworking.registerReceiver(NetworkUtilsImpl.OPEN_TORCHERINO_SCREEN, (client1, handler1, buffer, responseSender) -> {
                    class_1937 world = class_310.method_1551().field_1687;
                    class_2338 pos = buffer.method_10811();
                    class_2561 title = buffer.method_10808();
                    int xRange = buffer.readInt();
                    int zRange = buffer.readInt();
                    int yRange = buffer.readInt();
                    int speed = buffer.readInt();
                    int redstoneMode = buffer.readInt();
                    buffer.method_52938();
                    client1.execute(() -> {
                        if (world.method_8321(pos) instanceof TorcherinoBlockEntity blockEntity) {
                            class_310.method_1551().method_1507(new TorcherinoScreen(title, xRange, zRange, yRange, speed, redstoneMode, pos, blockEntity.getTier()));
                        }
                        buffer.release();
                    });
                });

                ClientPlayNetworking.registerReceiver(NetworkUtilsImpl.TORCHERINO_TIER_SYNC, (client1, handler1, buffer, responseSender) -> {
                    HashMap<class_2960, Tier> tiers = new HashMap<>();
                    int count = buffer.readInt();
                    for (int i = 0; i < count; i++) {
                        class_2960 id = buffer.method_10810();
                        int maxSpeed = buffer.readInt();
                        int xzRange = buffer.readInt();
                        int yRange = buffer.readInt();
                        tiers.put(id, new Tier(maxSpeed, xzRange, yRange));
                    }
                    client1.execute(() -> ((TorcherinoImpl) TorcherinoAPI.INSTANCE).setRemoteTiers(tiers));
                });
            });
        }
    }
}
