package com.skniro.industrial_elixir.screen.ingame.generator.heat;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.screen.handler.generator.heat.ElectricHeaterScreenHandler;
import com.skniro.industrial_elixir.util.MouseUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.util.List;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class ElectricHeaterBlockScreen extends class_465<ElectricHeaterScreenHandler> {
    private static final class_2960 TEXTURE = class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/generator/heat/guielectricheatgenerator.png");

    public ElectricHeaterBlockScreen(ElectricHeaterScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25269 = 145;
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
    }

    public List<class_2561> getTooltips() {
               return List.of(class_2561.method_43470(field_2797.blockEntity.energyContainer.getSideStorage(null).getAmount()+" / "+ field_2797.blockEntity.energyContainer.getSideStorage(null).getCapacity()+" EP"));
    }

    private void renderEnergyAreaTooltips(class_332 context, int pMouseX, int pMouseY, int x, int y) {
        if(isMouseAboveArea(pMouseX, pMouseY, x, y, 8, 42, 13, 16)) {
            context.method_51437(Screens.getTextRenderer(this), getTooltips(),
                    Optional.empty(), pMouseX, pMouseY);
        }
    }

    private void renderEnergyArea(class_332 context, int x, int y) {
        context.method_25290(TEXTURE, x + 8, y + 42, 176, 0, 13, field_2797.getScaledEnergyHeight(),256,256);
    }


    private void renderHeatAreaTooltips(class_332 context) {
        context.method_51439(field_22793, field_2797.getHeatTooltips(), 43, 68,  -12566464, false);
    }


    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        super.method_2388(context, mouseX, mouseY);
        renderEnergyAreaTooltips(context, mouseX, mouseY, field_2776, field_2800);
        renderHeatAreaTooltips(context);
    }

    @Override
       protected void method_2389(class_332 context, float partialTicks, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        context.method_25290(TEXTURE, x, y, 0, 0, field_2792, field_2779,256,256);
        renderEnergyArea(context, x, y);
    }


    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        super.method_25394(context, mouseX, mouseY, deltaTicks);
        this.method_2380(context, mouseX, mouseY);
    }

    private boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, int width, int height) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, width, height);
    }
}

