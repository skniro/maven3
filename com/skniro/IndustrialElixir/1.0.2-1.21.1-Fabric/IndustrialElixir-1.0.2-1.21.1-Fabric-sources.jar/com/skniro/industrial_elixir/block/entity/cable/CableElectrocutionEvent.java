package com.skniro.industrial_elixir.block.entity.cable;

import com.skniro.industrial_elixir.ModContent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

// CREDIT: https://github.com/techreborn/techreborn
// Under MIT-License: https://github.com/TechReborn/TechReborn/blob/26.1/LICENSE.md
public interface CableElectrocutionEvent {
    Event<CableElectrocutionEvent> EVENT = EventFactory.createArrayBacked(CableElectrocutionEvent.class, (listeners) -> (livingEntity, cableType, blockPos, world, cableBlockEntity) -> {
            for(CableElectrocutionEvent listener : listeners) {
                if (!listener.electrocute(livingEntity, cableType, blockPos, world, cableBlockEntity)) {
                    return false;
                }
            }

            return true;
        });

    boolean electrocute(class_1309 var1, ModContent.Cables var2, class_2338 var3, class_1937 var4, CableBlockEntity var5);
}