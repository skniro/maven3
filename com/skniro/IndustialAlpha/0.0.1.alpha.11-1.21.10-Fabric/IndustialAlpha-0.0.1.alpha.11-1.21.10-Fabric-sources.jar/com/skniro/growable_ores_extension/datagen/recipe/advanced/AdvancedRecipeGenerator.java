package com.skniro.growable_ores_extension.datagen.recipe.advanced;

import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.item.AdvancedItems;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class AdvancedRecipeGenerator extends FabricRecipeProvider {
    public AdvancedRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {
                method_62749(class_7800.field_40642, AdvancedItems.SUNNARIUM)
                        .method_10449(AdvancedItems.SUNNARIUM_Part,9)
                        .method_10442("has_item", this.method_10426(AdvancedItems.SUNNARIUM_Part)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, AdvancedItems.SUNNARIUM_ALLOY)
                        .method_10434('R', AdvancedItems.SUNNARIUM).method_10434('D', GrowableOresItems.IRIDIUM_PLATE)
                        .method_10439("DDD").method_10439("DRD").method_10439("DDD")
                        .method_10429("has_item_tags", this.method_10426(GrowableOresItems.IRIDIUM_PLATE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, AdvancedItems.IRRADIANT_URANIUM_INGOT)
                        .method_10434('R', class_1802.field_8601).method_10434('D', GrowableOresItems.URANIUM_INGOT)
                        .method_10439(" R ").method_10439("RDR").method_10439(" R ")
                        .method_10429("has_item_tags", this.method_10426(GrowableOresItems.URANIUM_INGOT)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, AdvancedItems.ENRICHED_SUNNARIUM)
                        .method_10434('R', AdvancedItems.SUNNARIUM).method_10434('D', AdvancedItems.IRRADIANT_URANIUM_INGOT)
                        .method_10439("DDD").method_10439("DRD").method_10439("DDD")
                        .method_10429("has_item_tags", this.method_10426(AdvancedItems.IRRADIANT_URANIUM_INGOT)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, AdvancedItems.ENRICHED_SUNNARIUM_ALLOY)
                        .method_10434('R', AdvancedItems.ENRICHED_SUNNARIUM).method_10434('D', AdvancedItems.SUNNARIUM_ALLOY)
                        .method_10439(" R ").method_10439("RDR").method_10439(" R ")
                        .method_10429("has_item_tags", this.method_10426(GrowableOresItems.URANIUM_INGOT)).method_10431(this.field_53721);

                //TEM
                method_62746(class_7800.field_40642, AdvancedItems.IRRADIANT_GLASS_PANE)
                        .method_10434('R', class_1802.field_8601).method_10434('D', AdvancedItems.IRRADIANT_URANIUM_INGOT).method_10434('G', class_1802.field_8280)
                        .method_10439("GGG").method_10439("DRD").method_10439("GGG")
                        .method_10429("has_item_tags", this.method_10426(AdvancedItems.IRRADIANT_URANIUM_INGOT)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, AdvancedItems.IRIDIUM_IRON_PLATE)
                        .method_10434('R', AdvancedItems.Iridium_INGOT).method_10434('D', GrowableOresItems.IRIDIUM_PLATE)
                        .method_10439("DDD").method_10439("DRD").method_10439("DDD")
                        .method_10429("has_item_tags", this.method_10426(GrowableOresItems.IRIDIUM_PLATE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, AdvancedItems.REINFORCED_IRIDIUM_IRON_PLATE)
                        .method_10434('R', AdvancedItems.IRIDIUM_IRON_PLATE).method_10434('D', GrowableOresItems.CARBON_PLATE).method_10434('A', GrowableOresItems.ALLOY_PLATE)
                        .method_10439("ADA").method_10439("DRD").method_10439("ADA")
                        .method_10429("has_item_tags", this.method_10426(GrowableOresItems.CARBON_PLATE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, AdvancedItems.IRRADIANT_REINFORCED_PLATE)
                        .method_10434('R', AdvancedItems.REINFORCED_IRIDIUM_IRON_PLATE).method_10434('P', AdvancedItems.SUNNARIUM_Part).method_10434('D', class_1802.field_8477).method_10434('A', class_1802.field_8725).method_10434('L', class_1802.field_8759)
                        .method_10439("APA").method_10439("LRL").method_10439("ADA")
                        .method_10429("has_item_tags", this.method_10426(AdvancedItems.SUNNARIUM_Part)).method_10431(this.field_53721);

                //TEM
                method_62746(class_7800.field_40642, AdvancedItems.MT_Core)
                        .method_10434('R', AdvancedItems.IRRADIANT_GLASS_PANE).method_10434('P', GrowableOresItems.COPPER_PLATE)
                        .method_10439("RPR").method_10439("R R").method_10439("RPR")
                        .method_10429("has_item_tags", this.method_10426(AdvancedItems.IRRADIANT_GLASS_PANE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, AdvancedItems.Quantum_Core)
                        .method_10434('R', AdvancedItems.ENRICHED_SUNNARIUM_ALLOY).method_10434('P', class_1802.field_8137).method_10434('E', class_1802.field_8449)
                        .method_10439("RPR").method_10439("PEP").method_10439("RPR")
                        .method_10429("has_item_tags", this.method_10426(class_1802.field_8137)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.MolecularTransformerBlock)
                        .method_10434('R', AdvancedItems.MT_Core).method_10434('P', GrowableOresItems.Advanced_Circuit).method_10434('A', GeneralBlocks.Advanced_Machine).method_10434('E', GrowableOresBlocks.EV_TRANSFORMER)
                        .method_10439("AEA").method_10439("PRP").method_10439("AEA")
                        .method_10429("has_item_tags", this.method_10426(GrowableOresItems.Advanced_Circuit)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL)
                        .method_10434('R', AdvancedItems.IRRADIANT_GLASS_PANE).method_10434('P', GrowableOresItems.Advanced_Circuit).method_10434('A', GrowableOresBlocks.GENERATOR_SolarPanel).method_10434('E', AdvancedItems.IRRADIANT_REINFORCED_PLATE).method_10434('D', GrowableOresItems.ALLOY_PLATE)
                        .method_10439("RRR").method_10439("DAD").method_10439("PEP")
                        .method_10429("has_item_tags", this.method_10426(GrowableOresItems.Advanced_Circuit)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL)
                        .method_10434('R', GrowableOresItems.CARBON_PLATE)
                        .method_10434('L', class_1802.field_8055)
                        .method_10434('P', GrowableOresItems.Advanced_Circuit)
                        .method_10434('A', GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL)
                        .method_10434('E', AdvancedItems.ENRICHED_SUNNARIUM)
                        .method_10434('D', GrowableOresItems.IRIDIUM_PLATE)
                        .method_10439("RLR").method_10439("DAD").method_10439("PEP")
                        .method_10429("has_item_tags", this.method_10426(GrowableOresItems.Advanced_Circuit)).method_10431(this.field_53721);

                method_62750(class_7800.field_40642, GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL, 8)
                        .method_10454(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL)
                        .method_10442("has_item", this.method_10426(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL)).method_36443(this.field_53721,"generator_ultimate_solar_panel_to_generator_hybrid_solar_panel");

                method_62746(class_7800.field_40642, GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL)
                        .method_10434('L', class_1802.field_8055)
                        .method_10434('A', GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL)
                        .method_10434('E', AdvancedItems.ENRICHED_SUNNARIUM_ALLOY)
                        .method_10434('D', GrowableOresItems.COAL_CHUNK)
                        .method_10439(" L ").method_10439("DAD").method_10439("EDE")
                        .method_10429("has_item_tags", this.method_10426(GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL)).method_10431(this.field_53721);


                method_62746(class_7800.field_40642, GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL)
                        .method_10434('A', GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL)
                        .method_10434('P', GrowableOresItems.Advanced_Circuit)
                        .method_10439("AAA").method_10439("APA").method_10439("AAA")
                        .method_10429("has_item_tags", this.method_10426(GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL)).method_36443(this.field_53721,"generator_hybrid_solar_panel_to_generator_ultimate_solar_panel");

                method_62746(class_7800.field_40642, GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL)
                        .method_10434('A', GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL)
                        .method_10434('P', AdvancedItems.Quantum_Core)
                        .method_10439("AAA").method_10439("APA").method_10439("AAA")
                        .method_10429("has_item_tags", this.method_10426(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL)).method_10431(this.field_53721);

            }
        };
    }


    @Override
    public String method_10321() {
        return "Advanced";
    }
}