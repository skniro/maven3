package com.skniro.industrial_elixir.datagen.recipe;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Items;
import java.util.concurrent.CompletableFuture;

public class BaseMachineRecipeGenerator extends FabricRecipeProvider {
    public BaseMachineRecipeGenerator(FabricPackOutput output, CompletableFuture<HolderLookup.Provider> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator createRecipeProvider(HolderLookup.Provider wrapperLookup, RecipeOutput exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void buildRecipes() {
                shaped(RecipeCategory.MISC, GrowableOresBlocks.COAL_GENERATOR)
                        .define('G', GrowableOresBlocks.Iron_Furnace_Block).define('E', GrowableOresItems.RE_BATTERY).define('S', GrowableOresItems.IRON_PLATE)
                        .pattern(" E ").pattern("SSS").pattern(" G ")
                        .unlockedBy("has_item", this.has(GrowableOresItems.RE_BATTERY)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.COAL_GENERATOR)
                        .define('G', Items.FURNACE).define('E', GrowableOresItems.RE_BATTERY).define('S', GeneralBlocks.Machine)
                        .pattern(" E ").pattern(" S ").pattern(" G ")
                        .unlockedBy("has_item", this.has(GrowableOresItems.RE_BATTERY)).save(this.output,"base_machine_to_coal_generator");

                shaped(RecipeCategory.MISC, GrowableOresBlocks.GENERATOR_SolarPanel)
                        .define('G', Items.GLASS).define('E', GrowableOresItems.COAL_DUST).define('S', GrowableOresBlocks.COAL_GENERATOR).define('C', GrowableOresItems.Circuit)
                        .pattern("EGE").pattern("GEG").pattern("CSC")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.COAL_GENERATOR)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.GENERATOR_Wind_Mill)
                        .define('G', Items.IRON_INGOT).define('S', GrowableOresBlocks.COAL_GENERATOR)
                        .pattern("G G").pattern(" S ").pattern("G G")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.COAL_GENERATOR)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.Compressor_Block)
                        .define('G', Items.STONE).define('S', GeneralBlocks.Machine).define('C', GrowableOresItems.Circuit)
                        .pattern("G G").pattern("GSG").pattern("GCG")
                        .unlockedBy("has_item", this.has(GeneralBlocks.Machine)).save(this.output);

                //临时配方
                shaped(RecipeCategory.MISC, GrowableOresBlocks.Extractor_Block)
                        .define('G', GrowableOresItems.Sticky_Resin).define('S', GeneralBlocks.Machine).define('C', GrowableOresItems.Circuit)
                        .pattern("   ").pattern("GSG").pattern("GCG")
                        .unlockedBy("has_item", this.has(GeneralBlocks.Machine)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.Iron_Furnace_Block)
                        .define('G', GrowableOresItems.IRON_PLATE).define('C', Items.FURNACE)
                        .pattern(" G ").pattern("G G").pattern("GCG")
                        .unlockedBy("has_item", this.has(Items.FURNACE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.Macerator_Block)
                        .define('G', Items.STONE).define('S', GeneralBlocks.Machine).define('C', GrowableOresItems.Circuit).define('F', Items.FLINT)
                        .pattern("FFF").pattern("GSG").pattern(" C ")
                        .unlockedBy("has_item", this.has(GeneralBlocks.Machine)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.MetalFormerBlock)
                        .define('G', GrowableOresItems.BRONZE_CASING).define('S', GeneralBlocks.Machine).define('C', GrowableOresItems.Circuit).define('F', GrowableOresItems.Coil)
                        .pattern(" C ").pattern("GSG").pattern("FFF")
                        .unlockedBy("has_item", this.has(GeneralBlocks.Machine)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.ChargePad)
                        .define('G', Items.STONE_PRESSURE_PLATE).define('S', GrowableOresBlocks.EnergyBox).define('C', GrowableOresItems.Circuit).define('F', GrowableOresItems.Rubber)
                        .pattern("   ").pattern("CGC").pattern("FSF")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.EnergyBox)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.CESU_CHARGE_PAD)
                        .define('G', Items.STONE_PRESSURE_PLATE).define('S', GrowableOresBlocks.CESU).define('C', GrowableOresItems.Circuit).define('F', GrowableOresItems.Rubber)
                        .pattern("   ").pattern("CGC").pattern("FSF")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.CESU)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.MFE_CHARGE_PAD)
                        .define('G', Items.STONE_PRESSURE_PLATE).define('S', GrowableOresBlocks.MFE).define('C', GrowableOresItems.Circuit).define('F', GrowableOresItems.Rubber)
                        .pattern("   ").pattern("CGC").pattern("FSF")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.MFE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.MFSU_CHARGE_PAD)
                        .define('G', Items.STONE_PRESSURE_PLATE).define('S', GrowableOresBlocks.MFSU).define('C', GrowableOresItems.Circuit).define('F', GrowableOresItems.Rubber)
                        .pattern("   ").pattern("CGC").pattern("FSF")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.MFSU)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.EnergyBox)
                        .define('G', ItemTags.PLANKS).define('S', GrowableOresBlocks.INSULATED_TIN_CABLE).define('F', GrowableOresItems.RE_BATTERY)
                        .pattern("GSG").pattern("FFF").pattern("GGG")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.INSULATED_TIN_CABLE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.CESU)
                        .define('G', GrowableOresItems.BRONZE_PLATE).define('S', GrowableOresBlocks.INSULATED_COPPER_CABLE).define('F', GrowableOresItems.ADVANCED_RE_BATTERY)
                        .pattern("GSG").pattern("FFF").pattern("GGG")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.INSULATED_COPPER_CABLE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.MFE)
                        .define('G', GrowableOresItems.ENERGY_CRYSTAL).define('S', GrowableOresBlocks.INSULATED_GOLD_CABLE).define('F', GeneralBlocks.Machine)
                        .pattern("SGS").pattern("GFG").pattern("SGS")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.INSULATED_GOLD_CABLE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.MFSU)
                        .define('G', GrowableOresItems.LAPOTRON_CRYSTAL).define('S', GeneralBlocks.Advanced_Machine).define('F', GrowableOresBlocks.MFE).define('C', GrowableOresItems.Advanced_Circuit)
                        .pattern("GCG").pattern("GFG").pattern("GSG")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.MFE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.LV_TRANSFORMER)
                        .define('G', ItemTags.PLANKS).define('F', GrowableOresBlocks.INSULATED_TIN_CABLE).define('C', GrowableOresItems.Coil)
                        .pattern("GFG").pattern("GCG").pattern("GFG")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.INSULATED_TIN_CABLE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.MV_TRANSFORMER)
                        .define('G', GeneralBlocks.Machine).define('F', GrowableOresBlocks.INSULATED_COPPER_CABLE)
                        .pattern(" F ").pattern(" G ").pattern(" F ")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.INSULATED_COPPER_CABLE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.HV_TRANSFORMER)
                        .define('G', GrowableOresBlocks.MV_TRANSFORMER).define('F', GrowableOresBlocks.INSULATED_GOLD_CABLE).define('C', GrowableOresItems.Circuit).define('R', GrowableOresItems.ADVANCED_RE_BATTERY)
                        .pattern(" F ").pattern("CGR").pattern(" F ")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.INSULATED_GOLD_CABLE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.EV_TRANSFORMER)
                        .define('G', GrowableOresBlocks.HV_TRANSFORMER).define('F', GrowableOresBlocks.INSULATED_HV_CABLE).define('C', GrowableOresItems.Advanced_Circuit).define('R', GrowableOresItems.LAPOTRON_CRYSTAL)
                        .pattern(" F ").pattern("CGR").pattern(" F ")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.INSULATED_HV_CABLE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.ElectricFurnace_Block)
                        .define('G', GrowableOresBlocks.Iron_Furnace_Block).define('C', GrowableOresItems.Circuit).define('R', Items.REDSTONE)
                        .pattern("   ").pattern(" C ").pattern("RGR")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.Iron_Furnace_Block)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.RECYCLER_Block)
                        .define('G', GrowableOresBlocks.Compressor_Block).define('C', Items.GLOWSTONE_DUST).define('R', Items.IRON_INGOT).define('D', ItemTags.DIRT)
                        .pattern(" C ").pattern("DGD").pattern("RDR")
                        .unlockedBy("has_item", this.has(GrowableOresBlocks.Compressor_Block)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresBlocks.CUTTING_Block)
                        .define('G', GeneralBlocks.Machine).define('C', GrowableOresItems.Circuit).define('R', GrowableOresItems.Electric_Motor)
                        .pattern(" C ").pattern(" G ").pattern(" R ")
                        .unlockedBy("has_item", this.has(GrowableOresItems.Circuit)).save(this.output);
            }
        };
    }

    @Override
    public String getName() {
        return "BaseMachine";
    }
}