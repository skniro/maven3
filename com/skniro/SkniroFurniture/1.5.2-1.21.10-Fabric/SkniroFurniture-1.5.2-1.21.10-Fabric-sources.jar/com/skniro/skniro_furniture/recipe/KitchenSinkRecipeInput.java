package com.skniro.skniro_furniture.recipe;

import net.minecraft.class_1799;
import net.minecraft.class_9695;

public class KitchenSinkRecipeInput implements class_9695 {
    private final class_1799 input;

    public KitchenSinkRecipeInput(class_1799 input) {
        this.input = input;
    }

    @Override
    public class_1799 method_59984(int slot) {
        return input;
    }

    @Override
    public int method_59983() {
        return 1;
    }
}