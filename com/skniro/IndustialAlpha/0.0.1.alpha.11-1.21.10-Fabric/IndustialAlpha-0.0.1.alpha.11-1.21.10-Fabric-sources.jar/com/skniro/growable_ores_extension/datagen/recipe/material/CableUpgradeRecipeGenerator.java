package com.skniro.growable_ores_extension.datagen.recipe.material;

import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class CableUpgradeRecipeGenerator extends FabricRecipeProvider {
    public CableUpgradeRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {

                method_62749(class_7800.field_40642, GrowableOresBlocks.INSULATED_COPPER_CABLE)
                        .method_10454(GrowableOresBlocks.COPPER_CABLE).method_10454(GrowableOresItems.Rubber)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.Rubber)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresBlocks.INSULATED_TIN_CABLE)
                        .method_10454(GrowableOresBlocks.TIN_CABLE).method_10454(GrowableOresItems.Rubber)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.Rubber)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresBlocks.INSULATED_GOLD_CABLE)
                        .method_10454(GrowableOresBlocks.GOLD_CABLE).method_10454(GrowableOresItems.Rubber)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.Rubber)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresBlocks.INSULATED_HV_CABLE)
                        .method_10454(GrowableOresBlocks.HV_CABLE).method_10454(GrowableOresItems.Rubber)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.Rubber)).method_10431(this.field_53721);

                method_62747(class_7800.field_40642, GrowableOresBlocks.GLASSFIBER_CABLE, 6)
                        .method_10434('G', class_1802.field_8280).method_10434('E',GrowableOresItems.ENERGIUM_DUST).method_10434('S',GrowableOresItems.SILVER_DUST)
                        .method_10439("GGG").method_10439("ESE").method_10439("GGG")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.ENERGIUM_DUST)).method_10431(this.field_53721);

                //临时配方
                method_62746(class_7800.field_40642, GrowableOresItems.OVERCLOCKER)
                        .method_10434('G', class_1802.field_8759).method_10434('E', GrowableOresItems.Circuit).method_10434('S',GrowableOresBlocks.INSULATED_COPPER_CABLE)
                        .method_10439("   ").method_10439("GGG").method_10439("SES")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.Circuit)).method_10431(this.field_53721);

                //临时配方
                method_62747(class_7800.field_40642, GrowableOresItems.OVERCLOCKER, 6)
                        .method_10434('G', class_1802.field_8055).method_10434('E', GrowableOresItems.Circuit).method_10434('S',GrowableOresBlocks.INSULATED_COPPER_CABLE)
                        .method_10439("   ").method_10439("GGG").method_10439("SES")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.Circuit)).method_36443(this.field_53721,"get_more_overclocker");

                method_62746(class_7800.field_40642, GrowableOresItems.ENERGY_STORAGE)
                        .method_10434('G', class_1802.field_8280).method_10434('E', GrowableOresItems.Circuit).method_10434('S',GrowableOresBlocks.INSULATED_GOLD_CABLE).method_10434('M',GrowableOresBlocks.MV_TRANSFORMER)
                        .method_10439("GGG").method_10439("SMS").method_10439("GEG")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.Circuit)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.TRANSFORMER)
                        .method_10433('G', class_3489.field_15537).method_10434('E', GrowableOresItems.Circuit).method_10434('S',GrowableOresBlocks.INSULATED_COPPER_CABLE).method_10434('M',GrowableOresItems.RE_BATTERY)
                        .method_10439("GGG").method_10439("SMS").method_10439("GEG")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.Circuit)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.REDSTONE_INVERTER)
                        .method_10434('G', GrowableOresItems.TIN_PLATE).method_10434('M',class_1802.field_8865)
                        .method_10439("G G").method_10439(" M ").method_10439("G G")
                        .method_10429("has_item", this.method_10426(class_1802.field_8865)).method_10431(this.field_53721);

                method_62747(class_7800.field_40642, GrowableOresItems.REDSTONE_INVERTER, 9)
                        .method_10434('G', GrowableOresItems.DENSE_TIN_PLATE).method_10434('M',class_1802.field_8865)
                        .method_10439("G G").method_10439(" M ").method_10439("G G")
                        .method_10429("has_item", this.method_10426(class_1802.field_8865)).method_36443(this.field_53721,"get_more_redstone_inverter");
            }
        };
    }

    @Override
    public String method_10321() {
        return "Cable";
    }
}