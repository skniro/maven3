package com.skniro.maple.world.gen;

import com.skniro.maple.world.biome.MapleBiomeKeys;
import com.skniro.maple.world.feature.MaplePlacedFeatures;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_1972;
import net.minecraft.class_2893;

public class MapleTreeGeneration {

    public static void generateTrees() {

/*        BiomeModifications.addFeature(BiomeSelectors.includeByKey(MapleBiomeKeys.Sakura),
                GenerationStep.Feature.VEGETAL_DECORATION, MaplePlacedFeatures.MAGE_SAKURA_TREE_PLACED);*/
/*        BiomeModifications.addFeature(BiomeSelectors.includeByKey(MapleBiomeKeys.Maple_Grove),
                GenerationStep.Feature.VEGETAL_DECORATION, MaplePlacedFeatures.Red_Maple_TREE_PLACED);*/
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(MapleBiomeKeys.Sakura),
                class_2893.class_2895.field_13178, MaplePlacedFeatures.Sakura_carpet_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(MapleBiomeKeys.Maple_Grove),
                class_2893.class_2895.field_13178, MaplePlacedFeatures.Maple_carpet_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(MapleBiomeKeys.Maple_Grove),
                class_2893.class_2895.field_13178, MaplePlacedFeatures.Red_Maple_carpet_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(class_1972.field_9420),
                class_2893.class_2895.field_13178, MaplePlacedFeatures.PATCH_TEA_COMMON);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(class_1972.field_35119),
                class_2893.class_2895.field_13178, MaplePlacedFeatures.PATCH_TEA_COMMON);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(class_1972.field_35119),
                class_2893.class_2895.field_13178, MaplePlacedFeatures.PATCH_TEA_RARE);
    }
}
