package com.skniro.skniro_furniture.block.entity;

import com.skniro.skniro_furniture.init.FurnitureStrings;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3917;

public class DeskCabinetBlockEntity extends AbstractFurnitureContainerBlockEntity {

    public DeskCabinetBlockEntity(class_2338 pos, class_2680 state) {
        super(FurnitureBlockEntityType.Desk_Cabinet_BLOCK_ENTITY, pos, state,18);
    }


    protected class_2561 method_17823() {
        return class_2561.method_43471(FurnitureStrings.Desk_Cabinet);
    }

    protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return new class_1707(class_3917.field_18665, syncId, playerInventory, this, 2);
    }
}
