package com.skniro.industrial_elixir.api.block;

import net.minecraft.class_3956;

@FunctionalInterface
public interface MachineRecipeProvider {

    class_3956<?> getCurrentRecipeType();

}