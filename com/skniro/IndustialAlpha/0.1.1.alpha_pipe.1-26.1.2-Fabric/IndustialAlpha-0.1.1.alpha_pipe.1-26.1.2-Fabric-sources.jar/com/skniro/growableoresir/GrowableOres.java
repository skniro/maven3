package com.skniro.growableoresir;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growableoresir.conifg.Configuration;
import com.skniro.growableoresir.conifg.GrowableOresConfig;
import net.fabricmc.api.ModInitializer;


public class GrowableOres implements ModInitializer {
    @Override
    public void onInitialize() {
        new Configuration(GrowableOresConfig.class, GrowableOresExtension.MOD_ID);
        ModContent.registerItem();
        ModContent.registerBlock();
        ModContent.CreativeTab();
    }
}
