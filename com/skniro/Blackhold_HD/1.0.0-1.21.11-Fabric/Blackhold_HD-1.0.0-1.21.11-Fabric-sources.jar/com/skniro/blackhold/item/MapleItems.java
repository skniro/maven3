package com.skniro.blackhold.item;

import com.skniro.blackhold.Furniture;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.item.*;
import java.util.function.Function;

public class MapleItems {

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings.method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Furniture.MOD_ID, name))));
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Furniture.MOD_ID, name)), item);
    }

    private static Function<class_1792.class_1793, class_1792> createBlockItemWithUniqueName(class_2248 block) {
        return (settings) -> {
            return new class_1747(block, settings.method_63687());
        };
    }

    public static void registerModItems() {
        Furniture.LOGGER.info("Registering Mod Items for " + Furniture.MOD_ID);
    }
}