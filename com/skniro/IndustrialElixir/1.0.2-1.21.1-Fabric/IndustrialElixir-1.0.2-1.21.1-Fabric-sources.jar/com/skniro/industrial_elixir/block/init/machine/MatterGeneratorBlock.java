package com.skniro.industrial_elixir.block.init.machine;

import com.mojang.serialization.MapCodec;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.entity.machine.fluid.MatterGeneratorEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

/**
 * Minimal Matter Generator block. Energy tier set to TIER3.
 * BlockEntity and ticking are wired similarly to other machine blocks.
 * The BlockEntity implements the machine logic; user will complete remaining behavior.
 */
public class MatterGeneratorBlock extends AbstractMachineblock {
    public MatterGeneratorBlock(class_2251 settings) {
        super(settings, EnergyTier.TIER3);
    }

    public static final MapCodec<MatterGeneratorBlock> field_46280 = method_54094(MatterGeneratorBlock::new);

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new MatterGeneratorEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, AlchemyBlockEntityType.MATTER_GENERATOR_BE, (world1, pos, state1, blockEntity) -> blockEntity.tick(world1, pos, state1));
    }
}

