package com.skniro.maple.block;

import com.skniro.maple.Maple;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2431;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6019;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class MapleNetherOresBlocks {
    public static final class_2248 Nether_Coal_Ore = registerBlock("coal_ore", new class_2431(class_6019.method_35017(2, 4), FabricBlockSettings.method_9630(class_2246.field_10418)),class_7706.field_40743);
    public static final class_2248 Nether_Copper_Ore = registerBlock("copper_ore", new class_2431(class_6019.method_35017(2, 4), FabricBlockSettings.method_9630(class_2246.field_10418)),class_7706.field_40743);
    public static final class_2248 Nether_Diamond_Ore = registerBlock("diamond_ore", new class_2431(class_6019.method_35017(2, 4), FabricBlockSettings.method_9630(class_2246.field_10418)),class_7706.field_40743);
    public static final class_2248 Nether_Emerald_Ore = registerBlock("emerald_ore", new class_2431(class_6019.method_35017(2, 4), FabricBlockSettings.method_9630(class_2246.field_10418)),class_7706.field_40743);
    public static final class_2248 Nether_Gold_Ore = registerBlock("gold_ore", new class_2431(class_6019.method_35017(2, 4), FabricBlockSettings.method_9630(class_2246.field_10418)),class_7706.field_40743);
    public static final class_2248 Nether_Iron_Ore = registerBlock("iron_ore", new class_2431(class_6019.method_35017(2, 4), FabricBlockSettings.method_9630(class_2246.field_10418)),class_7706.field_40743);
    public static final class_2248 Nether_Lapis_Ore = registerBlock("lapis_ore", new class_2431(class_6019.method_35017(2, 4), FabricBlockSettings.method_9630(class_2246.field_10418)),class_7706.field_40743);
    public static final class_2248 Nether_Redstone_Ore = registerBlock("redstone_ore", new class_2431(class_6019.method_35017(2, 4), FabricBlockSettings.method_9630(class_2246.field_10418)), class_7706.field_40743);



    private static class_2248 registerBlock(String name, class_2248 block, class_5321<class_1761> tab) {
        registerBlockItem(name, block, tab);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(Maple.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_5321<class_1761> tab) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(Maple.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
    }

    private static class_2248 registerBlockWithoutItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(Maple.MOD_ID, name), block);
    }

    public static void registerNetherOresBlock() {
        Maple.LOGGER.info("register Mod Nether Ores Blocks"+ Maple.MOD_ID);
    }
}
