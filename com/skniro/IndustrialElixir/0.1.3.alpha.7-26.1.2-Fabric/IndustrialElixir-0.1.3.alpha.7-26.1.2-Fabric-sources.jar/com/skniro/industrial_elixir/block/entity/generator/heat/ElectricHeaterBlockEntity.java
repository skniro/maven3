package com.skniro.industrial_elixir.block.entity.generator.heat;

import com.skniro.industrial_elixir.api.ImplementedInventory;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.entity.machine.AbstractMachineEntity;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.EnergyStorageUtil;
import com.skniro.industrial_elixir.energy.heat.api.HeatStorage;
import com.skniro.industrial_elixir.energy.heat.api.HeatStorageUtil;
import com.skniro.industrial_elixir.energy.heat.api.base.SimpleHeatStorage;
import com.skniro.industrial_elixir.energy.heat.api.base.SimpleSidedHeatContainer;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.screen.handler.energybox.ChargePadScreenHandler;
import com.skniro.industrial_elixir.screen.handler.generator.heat.ElectricHeaterScreenHandler;
import net.fabricmc.fabric.api.menu.v1.ExtendedMenuProvider;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jspecify.annotations.Nullable;

public class ElectricHeaterBlockEntity extends AbstractMachineEntity {
    private final NonNullList<ItemStack> inventory = NonNullList.withSize(21, ItemStack.EMPTY);

    public SimpleSidedHeatContainer heatContainer;
    private static final int COIL_SLOT_START = 11;
    private static final int COIL_SLOT_END = 20;
    private static final long EU_PER_COIL = 10;
    private static final long HEAT_PER_COIL = 10;

    public ElectricHeaterBlockEntity(BlockPos pos, BlockState state) {
        super(AlchemyBlockEntityType.ELECTRIC_HEATER_BLOCK_ENTITY, pos, state);;
        heatContainer = new SimpleSidedHeatContainer() {

            @Override
            public long getCapacity() {
                return 100;
            }

            @Override
            public long getMaxInsert(@Nullable Direction side) {
                if (side == null) return 100;
                return 0;
            }

            @Override
            public long getMaxExtract(@Nullable Direction side) {
                return 100;
            }

            @Override
            protected void onFinalCommit() {
                setChanged();
                getLevel().sendBlockUpdated(pos, getBlockState(), getBlockState(), 3);
            }
        };
    }

    @Override
    public void tick(Level level, BlockPos pos, BlockState state) {
        if (level.isClientSide()) return;
        int coilCount = 0;
        for (int i = COIL_SLOT_START; i <= COIL_SLOT_END; i++) if (inventory.get(i).is(GrowableOresItems.Coil)) coilCount += inventory.get(i).getCount();
        if (coilCount > 0) {
            long required = coilCount * EU_PER_COIL;
            if (energyContainer.getSideStorage(null).getAmount() >= required) {
                try (Transaction tx = Transaction.openOuter()) {
                    if (energyContainer.getSideStorage(null).extract(required, tx) == required) {
                        heatContainer.getSideStorage(null).insert(coilCount * HEAT_PER_COIL, tx);
                        tx.commit();
                    }
                }
            }
        }
        pushHeatToNeighbours();
        charge(ENERGY_ITEM_SLOT);
        setChanged();
    }

    private void pushHeatToNeighbours() {
        if (heatContainer.amount <= 0) return;
        for (Direction direction : Direction.values()) {HeatStorage target = HeatStorage.SIDED.find(level, worldPosition.relative(direction), direction.getOpposite());
            if (target == null) continue;
            HeatStorageUtil.move(this.heatContainer.getSideStorage(direction), target, heatContainer.getSideStorage(null).getAmount(), null);
        }
    }

    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        ContainerHelper.saveAllItems(output, inventory);
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        ContainerHelper.loadAllItems(input, inventory);
    }

    public HeatStorage getHeatStorage() {
        return heatContainer.getSideStorage(null);
    }

    @Override
    public NonNullList<ItemStack> getItems() {
        return this.inventory;
    }

    @Override
    public BlockPos getScreenOpeningData(ServerPlayer player) {
        return this.worldPosition;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable(FurnitureStrings.CoalGenerator);
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public AbstractContainerMenu createMenu(int syncId, Inventory playerInventory, Player player) {
        return new ElectricHeaterScreenHandler(syncId, playerInventory, this, this.propertyDelegate);
    }

    @Override
    public RecipeType<?> getCurrentRecipeType() {
        return null;
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registryLookup) {
        return saveWithoutMetadata(registryLookup);
    }
}