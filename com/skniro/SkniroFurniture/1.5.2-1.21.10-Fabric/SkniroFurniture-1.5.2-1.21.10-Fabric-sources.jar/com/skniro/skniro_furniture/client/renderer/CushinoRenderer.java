package com.skniro.skniro_furniture.client.renderer;

import com.skniro.skniro_furniture.entity.furniture.CushionEntity;
import net.minecraft.class_10017;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class CushinoRenderer extends class_897<CushionEntity, class_10017> {

    public CushinoRenderer(class_5617.class_5618 ctx) {
        super(ctx);
    }

    @Override
    public boolean shouldRender(CushionEntity livingEntity, class_4604 camera, double camX, double camY, double camZ) {
        return true;
    }

    @Override
    public class_10017 method_55269() {
        return new class_10017();
    }
}