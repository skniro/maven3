package com.skniro.growable_ores_extension.item;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.api.registry.MapleModelDatagenHelper;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.MapleSignBlocks;
import com.skniro.growable_ores_extension.block.NetherOresBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModCreativeTab {
    public static final class_5321<class_1761> General = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "general"));
    public static final class_5321<class_1761> Generators_And_Wiring = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "generators_and_wiring"));
    public static final class_5321<class_1761> Reactor = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "reactor"));
    public static final class_5321<class_1761> Machine = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "machine"));
    public static final class_5321<class_1761> Tool_And_Utilities = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "tool_and_utilities"));
    public static final class_5321<class_1761> Combat = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "combat"));
    public static final class_5321<class_1761> Materials = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(GrowableOresExtension.MOD_ID, "materials"));

    public static void CreativeTab() {
        class_2378.method_39197(class_7923.field_44687, General, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.Cable_Block.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.general"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Generators_And_Wiring, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.Cable_Block.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.generators_and_wiring"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Reactor, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.Cable_Block.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.reactor"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Machine, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.Cable_Block.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.machine"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Tool_And_Utilities, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.Cable_Block.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.tool_and_utilities"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Combat, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.Cable_Block.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.combat"))
                .method_47324()); // build() no longer registers by itself

        class_2378.method_39197(class_7923.field_44687, Materials, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.Cable_Block.method_8389()))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores_extension.materials"))
                .method_47324()); // build() no longer registers by itself
    }

    public static void CreativeTabItem() {
        ItemGroupEvents.modifyEntriesEvent(General).register(content -> {
            content.method_45421(GrowableOresBlocks.GrowableOres_Block);

            content.method_45421(NetherOresBlocks.Lead_Ore);
            content.method_45421(NetherOresBlocks.Tin_Ore);
            content.method_45421(NetherOresBlocks.Uranium_Ore);
            content.method_45421(NetherOresBlocks.Deepslate_Lead_Ore);
            content.method_45421(NetherOresBlocks.Deepslate_Tin_Ore);
            content.method_45421(NetherOresBlocks.Deepslate_Uranium_Ore);
            content.method_45421(NetherOresBlocks.Raw_Lead_Block);
            content.method_45421(NetherOresBlocks.Raw_Tin_Block);
            content.method_45421(NetherOresBlocks.Raw_Uranium_Block);

            content.method_45421(NetherOresBlocks.Rubber_STAIRS);
            content.method_45421(NetherOresBlocks.Rubber_SLAB);
            content.method_45421(NetherOresBlocks.Rubber_BUTTON);
            content.method_45421(NetherOresBlocks.Rubber_PRESSURE_PLATE);
            content.method_45421(NetherOresBlocks.Rubber_FENCE);
            content.method_45421(NetherOresBlocks.Rubber_FENCE_GATE);
            content.method_45421(NetherOresBlocks.Rubber_LOG);
            content.method_45421(NetherOresBlocks.Rubber_LOG);
            content.method_45421(NetherOresBlocks.Rubber_WOOD);
            content.method_45421(NetherOresBlocks.STRIPPED_Rubber_LOG);
            content.method_45421(NetherOresBlocks.STRIPPED_Rubber_LOG);
            content.method_45421(NetherOresBlocks.STRIPPED_Rubber_WOOD);
            content.method_45421(NetherOresBlocks.Rubber_DOOR);
            content.method_45421(NetherOresBlocks.Rubber_TRAPDOOR);
            content.method_45421(NetherOresBlocks.Rubber_SAPLING);
            content.method_45421(NetherOresBlocks.Rubber_LEAVES);
            content.method_45421(NetherOresBlocks.Rubber_Rubber_LOG);
            content.method_45421(GrowableOresItems.Rubber);
            content.method_45421(MapleSignBlocks.Rubber_SIGN);
            content.method_45421(MapleSignBlocks.Rubber_HANGING_SIGN);
            content.method_45421(GrowableOresItems.RUBBER_BOAT);
            content.method_45421(GrowableOresItems.RUBBER_CHEST_BOAT);
            content.method_45421(GrowableOresBlocks.Cable_Block);

            content.method_45421(GrowableOresItems.ENERGY_STORAGE);
            content.method_45421(GrowableOresItems.OVERCLOCKER);
            content.method_45421(GrowableOresItems.TRANSFORMER);
            content.method_45421(GrowableOresItems.REDSTONE_INVERTER);
        });

        ItemGroupEvents.modifyEntriesEvent(Generators_And_Wiring).register(content -> {

        });

        ItemGroupEvents.modifyEntriesEvent(Reactor).register(content -> {

        });

        ItemGroupEvents.modifyEntriesEvent(Machine).register(content -> {
            content.method_45421(GrowableOresBlocks.Macerator_Block);

        });

        ItemGroupEvents.modifyEntriesEvent(Tool_And_Utilities).register(content -> {

        });

        ItemGroupEvents.modifyEntriesEvent(Combat).register(content -> {

        });

        ItemGroupEvents.modifyEntriesEvent(Materials).register(content -> {
            content.method_45421(GrowableOresItems.Raw_Lead);
            content.method_45421(GrowableOresItems.Raw_Tin);
            content.method_45421(GrowableOresItems.Raw_Uranium);

            content.method_45421(GrowableOresItems.CRUSHED_COPPER);
            content.method_45421(GrowableOresItems.CRUSHED_GOLD);
            content.method_45421(GrowableOresItems.CRUSHED_IRON);
            content.method_45421(GrowableOresItems.CRUSHED_LEAD);
            content.method_45421(GrowableOresItems.CRUSHED_SILVER);
            content.method_45421(GrowableOresItems.CRUSHED_TIN);
            content.method_45421(GrowableOresItems.CRUSHED_URANIUM);

            content.method_45421(GrowableOresItems.PURIFIED_COPPER);
            content.method_45421(GrowableOresItems.PURIFIED_GOLD);
            content.method_45421(GrowableOresItems.PURIFIED_IRON);
            content.method_45421(GrowableOresItems.PURIFIED_LEAD);
            content.method_45421(GrowableOresItems.PURIFIED_SILVER);
            content.method_45421(GrowableOresItems.PURIFIED_TIN);
            content.method_45421(GrowableOresItems.PURIFIED_URANIUM);

            content.method_45421(GrowableOresItems.BRONZE_DUST);
            content.method_45421(GrowableOresItems.CLAY_DUST);
            content.method_45421(GrowableOresItems.COAL_DUST);
            content.method_45421(GrowableOresItems.COAL_FUEL_DUST);
            content.method_45421(GrowableOresItems.COPPER_DUST);
            content.method_45421(GrowableOresItems.DIAMOND_DUST);
            content.method_45421(GrowableOresItems.ENERGIUM_DUST);
            content.method_45421(GrowableOresItems.GOLD_DUST);
            content.method_45421(GrowableOresItems.IRON_DUST);
            content.method_45421(GrowableOresItems.LAPIS_DUST);
            content.method_45421(GrowableOresItems.LEAD_DUST);
            content.method_45421(GrowableOresItems.LITHIUM_DUST);
            content.method_45421(GrowableOresItems.OBSIDIAN_DUST);
            content.method_45421(GrowableOresItems.SILICON_DIOXIDE_DUST);
            content.method_45421(GrowableOresItems.SILVER_DUST);
            content.method_45421(GrowableOresItems.STONE_DUST);
            content.method_45421(GrowableOresItems.SULFUR_DUST);
            content.method_45421(GrowableOresItems.TIN_DUST);

            content.method_45421(GrowableOresItems.SMALL_BRONZE_DUST);
            content.method_45421(GrowableOresItems.SMALL_COPPER_DUST);
            content.method_45421(GrowableOresItems.SMALL_GOLD_DUST);
            content.method_45421(GrowableOresItems.SMALL_IRON_DUST);
            content.method_45421(GrowableOresItems.SMALL_LAPIS_DUST);
            content.method_45421(GrowableOresItems.SMALL_LEAD_DUST);
            content.method_45421(GrowableOresItems.SMALL_LITHIUM_DUST);
            content.method_45421(GrowableOresItems.SMALL_OBSIDIAN_DUST);
            content.method_45421(GrowableOresItems.SMALL_SILVER_DUST);
            content.method_45421(GrowableOresItems.SMALL_SULFUR_DUST);
            content.method_45421(GrowableOresItems.SMALL_TIN_DUST);

            content.method_45421(GrowableOresItems.BRONZE_INGOT);
            content.method_45421(GrowableOresItems.LEAD_INGOT);
            content.method_45421(GrowableOresItems.SILVER_INGOT);
            content.method_45421(GrowableOresItems.STEEL_INGOT);
            content.method_45421(GrowableOresItems.TIN_INGOT);
            content.method_45421(GrowableOresItems.REFINED_IRON_INGOT);
            content.method_45421(GrowableOresItems.URANIUM_INGOT);

            content.method_45421(GrowableOresItems.BRONZE_PLATE);
            content.method_45421(GrowableOresItems.COPPER_PLATE);
            content.method_45421(GrowableOresItems.GOLD_PLATE);
            content.method_45421(GrowableOresItems.IRON_PLATE);
            content.method_45421(GrowableOresItems.LAPIS_PLATE);
            content.method_45421(GrowableOresItems.LEAD_PLATE);
            content.method_45421(GrowableOresItems.OBSIDIAN_PLATE);
            content.method_45421(GrowableOresItems.STEEL_PLATE);
            content.method_45421(GrowableOresItems.TIN_PLATE);

            content.method_45421(GrowableOresItems.DENSE_BRONZE_PLATE);
            content.method_45421(GrowableOresItems.DENSE_COPPER_PLATE);
            content.method_45421(GrowableOresItems.DENSE_GOLD_PLATE);
            content.method_45421(GrowableOresItems.DENSE_IRON_PLATE);
            content.method_45421(GrowableOresItems.DENSE_LAPIS_PLATE);
            content.method_45421(GrowableOresItems.DENSE_LEAD_PLATE);
            content.method_45421(GrowableOresItems.DENSE_OBSIDIAN_PLATE);
            content.method_45421(GrowableOresItems.DENSE_STEEL_PLATE);
            content.method_45421(GrowableOresItems.DENSE_TIN_PLATE);

            content.method_45421(GrowableOresItems.BRONZE_CASING);
            content.method_45421(GrowableOresItems.COPPER_CASING);
            content.method_45421(GrowableOresItems.GOLD_CASING);
            content.method_45421(GrowableOresItems.IRON_CASING);
            content.method_45421(GrowableOresItems.LEAD_CASING);
            content.method_45421(GrowableOresItems.STEEL_CASING);
            content.method_45421(GrowableOresItems.TIN_CASING);
        });
    }

}
