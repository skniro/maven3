package com.skniro.growable_ores_extension.datagen;

import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.NetherOresBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3481;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

import static net.minecraft.class_3481.*;

public class GrowableBlockTagGenerator extends FabricTagProvider.BlockTagProvider {
   public GrowableBlockTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
   }
   @Override
   protected void method_10514(class_7225.class_7874 arg) {
      valueLookupBuilder(field_33715)
              .method_71554(NetherOresBlocks.Deepslate_Lead_Ore)
              .method_71554(NetherOresBlocks.Deepslate_Tin_Ore)
              .method_71554(NetherOresBlocks.Deepslate_Uranium_Ore)
              .method_71554(NetherOresBlocks.Lead_Ore)
              .method_71554(NetherOresBlocks.Tin_Ore)
              .method_71554(NetherOresBlocks.Uranium_Ore)
              .method_71554(GrowableOresBlocks.GrowableOres_Block)
              .setReplace(false);
      valueLookupBuilder(field_33718)
              .method_71554(NetherOresBlocks.Deepslate_Lead_Ore)
              .method_71554(NetherOresBlocks.Deepslate_Tin_Ore)
              .method_71554(NetherOresBlocks.Deepslate_Uranium_Ore)
              .method_71554(NetherOresBlocks.Lead_Ore)
              .method_71554(NetherOresBlocks.Tin_Ore)
              .method_71554(NetherOresBlocks.Uranium_Ore)
              .setReplace(false);
      valueLookupBuilder(field_33719)
              .setReplace(false);
      valueLookupBuilder(class_3481.field_15503)
              .method_71554(NetherOresBlocks.Rubber_LEAVES)
              .setReplace(false);
      valueLookupBuilder(class_3481.field_15462)
              .method_71554(NetherOresBlocks.Rubber_SAPLING)
              .setReplace(false);
      valueLookupBuilder(field_23210)
              .method_71554(NetherOresBlocks.Rubber_LOG)
              .method_71554(NetherOresBlocks.Rubber_Rubber_LOG)
              .method_71554(NetherOresBlocks.Rubber_WOOD)
              .method_71554(NetherOresBlocks.STRIPPED_Rubber_LOG)
              .method_71554(NetherOresBlocks.STRIPPED_Rubber_WOOD)
              .setReplace(false);
      valueLookupBuilder(field_15499)
              .method_71554(NetherOresBlocks.Rubber_BUTTON)
              .setReplace(false);
      valueLookupBuilder(field_15494)
              .method_71554(NetherOresBlocks.Rubber_DOOR)
              .setReplace(false);
      valueLookupBuilder(field_15491)
              .method_71554(NetherOresBlocks.Rubber_TRAPDOOR)
              .setReplace(false);
      valueLookupBuilder(field_15477)
              .method_71554(NetherOresBlocks.Rubber_PRESSURE_PLATE)
              .setReplace(false);
      valueLookupBuilder(field_15468)
              .method_71554(NetherOresBlocks.Rubber_SLAB)
              .setReplace(false);
      valueLookupBuilder(field_15502)
              .method_71554(NetherOresBlocks.Rubber_STAIRS)
              .setReplace(false);
      valueLookupBuilder(field_15471)
              .method_71554(NetherOresBlocks.Rubber_PLANKS)
              .setReplace(false);
      valueLookupBuilder(field_16584)
              .method_71554(NetherOresBlocks.Rubber_FENCE)
              .setReplace(false);


   }
}