package torcherino.platform.payload;

import com.mojang.datafixers.util.Pair;
import torcherino.Torcherino;
import torcherino.api.Tier;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record TorchrinoTierPayload(Map<class_2960, Tier> tiers) implements class_8710 {
    private static final class_2960 TORCHERINO_TIER_SYNC = Torcherino.resloc("torcherino_tier_sync");
    public static final class_9154<TorchrinoTierPayload> TYPE = new class_9154<>(TORCHERINO_TIER_SYNC);
    public static final class_9139<class_9129, TorchrinoTierPayload> CODEC = class_8710.method_56484(TorchrinoTierPayload::write, TorchrinoTierPayload::decode);

    public static void write(TorchrinoTierPayload message, class_2540 buffer) {
        buffer.method_53002(message.tiers.size());
        message.tiers.forEach((name, tier) -> TorchrinoTierPayload.writeTier(name, tier, buffer));
    }

    public static TorchrinoTierPayload decode(class_2540 buffer) {
        Map<class_2960, Tier> localTiers = new HashMap<>();
        int count = buffer.readInt();
        for (int i = 0; i < count; i++) {
            Pair<class_2960, Tier> entry = TorchrinoTierPayload.readTier(buffer);
            localTiers.put(entry.getFirst(), entry.getSecond());
        }
        return new TorchrinoTierPayload(localTiers);
    }



    private static Pair<class_2960, Tier> readTier(class_2540 buffer) {
        return new Pair<>(buffer.method_10810(), new Tier(buffer.readInt(), buffer.readInt(), buffer.readInt()));
    }

    private static void writeTier(class_2960 name, Tier tier, class_2540 buffer) {
        buffer.method_10812(name).method_53002(tier.maxSpeed()).method_53002(tier.xzRange()).method_53002(tier.yRange());
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
