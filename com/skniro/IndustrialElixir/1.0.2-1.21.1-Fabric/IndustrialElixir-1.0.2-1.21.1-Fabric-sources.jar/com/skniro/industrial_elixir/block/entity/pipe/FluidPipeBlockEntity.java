package com.skniro.industrial_elixir.block.entity.pipe;

import com.skniro.industrial_elixir.block.init.pipe.PipeBlock;
import com.skniro.industrial_elixir.block.init.pipe.WoodPipeBlock;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_3610;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public abstract class FluidPipeBlockEntity extends PipeBlockEntity {
    private static final long STEP = 100;
    private static final int MAX_PACKETS = 64;
    private static final long BUCKET_VOLUME_MB = FluidConstants.BUCKET / 81;
    private static final long PIPE_CAPACITY = BUCKET_VOLUME_MB * 4;
    private static final double ARRIVAL_EPSILON = 1.0E-6;
    private final List<FluidPacket> fluids = new ArrayList<>();

    protected FluidPipeBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    @Override
    protected boolean isConnectable(class_2350 dir) {
        if (isBlocked(dir)) return false;
        class_2338 target = field_11867.method_10093(dir);
        class_2586 be = field_11863.method_8321(target);
        if (be instanceof FluidPipeBlockEntity) return true;
        Storage<FluidVariant> storage = FluidStorage.SIDED.find(field_11863, target, dir.method_10153());
        return storage != null;
    }

    protected void moveFluids(class_1937 world, class_2338 pos) {
        boolean changed = false;
        Iterator<FluidPacket> it = fluids.iterator();

        while (it.hasNext()) {
            FluidPacket packet = it.next();

            if (packet.variant.isBlank() || packet.amount <= 0) {
                it.remove();
                changed = true;
                continue;
            }

            packet.progress += 0.1;
            if (packet.progress + ARRIVAL_EPSILON < 1.0) continue;
            packet.progress = 1.0;

            if (tryRoutePacket(world, pos, packet)) {
                changed = true;

                // 只有 Packet 完全转移/插入后才能删除
                if (packet.amount <= 0 || packet.variant.isBlank()) {
                    it.remove();
                } else {
                    // 还有剩余液体，继续留在当前管道
                    packet.progress = 1.0;
                }

                continue;
            }

            packet.progress = 1.0;
        }

        if (changed) {
            syncToClient();
        }
    }

    /**
     * 尝试将流体包路由到其他管道或机器。
     * 优先沿当前方向移动，失败时尝试其余已连接的、非封堵的方向（避免回流）。
     */
    private boolean tryRoutePacket(class_1937 world, class_2338 pos, FluidPacket packet) {
        class_2350 backDir = packet.lastDirection != null ? packet.lastDirection.method_10153() : null;

        // 先尝试按当前方向移动/插入
        if (!isBlocked(packet.direction)) {
            class_2338 target = pos.method_10093(packet.direction);
            if (tryMoveToNext(world, target, packet.direction, packet)
                    || tryInsert(world, target, packet.direction, packet)) {
                return true;
            }
        }

        // 再尝试其他已连接的、非封堵的方向（排除回流方向）
        class_2680 state = method_11010();
        for (class_2350 dir : class_2350.values()) {
            if (dir == packet.direction) continue;
            if (backDir != null && dir == backDir) continue;
            if (isBlocked(dir)) continue;
            class_2746 property = PipeBlock.PROPERTY_MAP.get(dir);
            if (property == null || !state.method_11654(property)) continue;

            class_2338 target = pos.method_10093(dir);
            if (tryMoveToNext(world, target, dir, packet)
                    || tryInsert(world, target, dir, packet)) {
                return true;
            }
        }

        return false;
    }

    protected void extractFluids(class_1937 world, class_2338 pos) {
        if (getFluidVolume() >= PIPE_CAPACITY) return;
        if (fluids.size() >= MAX_PACKETS) return;

        class_2350 preferredDir = getPreferredExtractDirection();

        // 玩家指定了抽取方向
        if (preferredDir != null) {

            // ① 优先从 FluidStorage 抽取
            if (tryExtractFromSide(world, pos, preferredDir)) {
                onExtractDirectionChanged(preferredDir);
                return;
            }

            // ② FluidStorage 抽取失败，尝试吸取水源方块
            if (tryExtractSourceFluid(world, pos, preferredDir)) {
                onExtractDirectionChanged(preferredDir);
                return;
            }

            // 保持当前指示方向
            onExtractDirectionChanged(preferredDir);
            return;
        }

/*        if (preferredDir != null) {
            boolean canExtract = hasOutputPath(world, pos, preferredDir)
                    || world.getFluidState(pos.relative(preferredDir)).isSource();
            if (canExtract && tryExtractFromSide(world, pos, preferredDir)) {
                onExtractDirectionChanged(preferredDir);
            } else {
                onExtractDirectionChanged(preferredDir);
            }
            return;
        }*/

        for (class_2350 dir : class_2350.values()) {
            if (!hasOutputPath(world, pos, dir)) continue;
            if (tryExtractFromSide(world, pos, dir)) {
                onExtractDirectionChanged(dir);
                return;
            }
        }

        for (class_2350 dir : class_2350.values()) {
            if (tryExtractSourceFluid(world, pos, dir)) {
                onExtractDirectionChanged(dir);
                return;
            }
        }
        onExtractDirectionChanged(null);
    }

    public List<PipeFluid> getFluids() {
        List<PipeFluid> result = new ArrayList<>();
        for (FluidPacket packet : fluids) {
            result.add(new PipeFluid(packet.variant, packet.amount, packet.direction, packet.progress));
        }
        return result;
    }

    private long getFluidVolume() {
        long total = 0;
        for (FluidPacket packet : fluids) {
            total += packet.amount;
        }
        return total;
    }

    private boolean hasOutputPath(class_1937 world, class_2338 pos, class_2350 extractDir) {
        return searchOutputPath(world, pos, extractDir, new HashSet<>());
    }

    private boolean searchOutputPath(class_1937 world, class_2338 pos, class_2350 excludeDir, Set<class_2338> visited) {
        if (!visited.add(pos)) return false;
        class_2680 state = world.method_8320(pos);
        class_2586 be = world.method_8321(pos);
        if (!(be instanceof FluidPipeBlockEntity pipe)) return false;

        for (class_2350 dir : class_2350.values()) {
            if (dir == excludeDir) continue;
            if (pipe.isBlocked(dir)) continue;
            if (!state.method_11654(PipeBlock.PROPERTY_MAP.get(dir))) continue;

            class_2338 next = pos.method_10093(dir);
            if (FluidStorage.SIDED.find(world, next, dir.method_10153()) != null) return true;

            class_2586 nextBe = world.method_8321(next);
            if (nextBe instanceof FluidPipeBlockEntity) {
                if (searchOutputPath(world, next, dir.method_10153(), visited)) return true;
            }
        }
        return false;
    }

    private boolean tryMoveToNext(class_1937 world, class_2338 pos, class_2350 moveDir, FluidPacket packet) {
        if (isBlocked(moveDir)) return false;
        class_2586 be = world.method_8321(pos);
        if (!(be instanceof FluidPipeBlockEntity pipe)) return false;
        if (be instanceof WoodFluidPipeBlockEntity) return false;
        if (pipe.fluids.size() >= MAX_PACKETS) return false;
        long available = PIPE_CAPACITY - pipe.getFluidVolume();
        if (available <= 0) return false;
        long moveAmount = Math.min(packet.amount, available);
        if (moveAmount <= 0) return false;
        class_2350 newDir = getNextDirection(world, pos, moveDir);
        // 目标管道没有向前的出口，避免进入后立即被送回（来回弹跳）
        if (newDir == moveDir.method_10153()) return false;
        FluidPacket moved = new FluidPacket(packet.variant, moveAmount, newDir);
        moved.lastDirection = moveDir;
        pipe.fluids.add(moved);
        packet.amount -= moveAmount;
        if (packet.amount <= 0) {
            packet.amount = 0;
            packet.variant = FluidVariant.blank();
        }
        pipe.syncToClient();
        return true;
    }

    private class_2350 getNextDirection(class_1937 world, class_2338 pos, class_2350 moveDir) {
        class_2586 be = world.method_8321(pos);
        if (!(be instanceof FluidPipeBlockEntity pipe)) {
            return moveDir.method_10153();
        }
        List<class_2350> possible = new ArrayList<>();
        class_2680 state = world.method_8320(pos);
        class_2350 backDir = moveDir.method_10153();
        for (class_2350 dir : class_2350.values()) {
            if (pipe.isBlocked(dir)) continue;
            if (dir == backDir) continue;
            class_2746 property = PipeBlock.PROPERTY_MAP.get(dir);
            if (property != null && state.method_11654(property)) possible.add(dir);
        }
        if (possible.isEmpty()) return backDir;
        return possible.get(world.method_8409().method_43048(possible.size()));
    }

    private boolean tryInsert(class_1937 world, class_2338 pos, class_2350 insertDir, FluidPacket packet) {
        if (isBlocked(insertDir)) return false;
        Storage<FluidVariant> storage = FluidStorage.SIDED.find(world, pos, insertDir.method_10153());
        if (storage == null) return false;

        class_2586 be = world.method_8321(pos);
        if (be instanceof WoodFluidPipeBlockEntity) {
            class_2680 state = world.method_8320(pos);
            class_2350 pullSide = insertDir.method_10153();
            class_2746 pullProp = WoodPipeBlock.PULL_PROPERTY_MAP.get(pullSide);
            if (pullProp != null && state.method_11654(pullProp)) return false;
        }
        long before = packet.amount;
        try (Transaction tx = Transaction.openOuter()) {
            long inserted = storage.insert(packet.variant, before, tx);
            if (inserted <= 0) return false;
            packet.amount -= inserted;
            tx.commit();
            if (packet.amount <= 0) {
                packet.amount = 0;
                packet.variant = FluidVariant.blank();
            }
            syncToClient();
            return true;
        }
    }

    private boolean tryExtractFromSide(class_1937 world, class_2338 pos, class_2350 dir) {
        if (isBlocked(dir)) return false;
        class_2338 targetPos = pos.method_10093(dir);
        Storage<FluidVariant> storage = FluidStorage.SIDED.find(world, targetPos, dir.method_10153());
        if (storage != null) {
            try (Transaction tx = Transaction.openOuter()) {
                StorageView<FluidVariant> view = null;
                for (StorageView<FluidVariant> v : storage) {
                    if (!v.isResourceBlank()) {
                        view = v;
                        break;
                    }
                }
                if (view != null) {
                    FluidVariant resource = view.getResource();
                    long toExtract = Math.min(STEP, PIPE_CAPACITY - getFluidVolume());
                    if (toExtract <= 0) return false;
                    long extracted = storage.extract(resource, toExtract, tx);
                    if (extracted > 0) {
                        fluids.add(new FluidPacket(resource, extracted, dir.method_10153()));
                        tx.commit();
                        syncToClient();
                        return true;
                    }
                }
            }
        }

        // Fallback: pull directly from source fluid blocks (e.g. water/lava source).
/*        FluidState fluidState = world.getFluidState(targetPos);
        if (!fluidState.isEmpty() && fluidState.isSource()) {
            FluidVariant source = FluidVariant.of(fluidState.getType());
            fluids.add(new FluidPacket(source, BUCKET_VOLUME_MB, dir.getOpposite()));
            world.removeBlock(targetPos, false);
            syncToClient();
            return true;
        }*/

        return false;
    }

    private boolean tryExtractSourceFluid(class_1937 world, class_2338 pos, class_2350 dir) {
        if (isBlocked(dir)) return false;
        class_2338 targetPos = pos.method_10093(dir);
        class_3610 fluidState = world.method_8316(targetPos);
        if (!fluidState.method_15771()) {
            return false;
        }
        long amount = Math.min(STEP, PIPE_CAPACITY - getFluidVolume());
        if (amount <= 0) {
            return false;
        }

        FluidVariant source = FluidVariant.of(fluidState.method_15772());
        fluids.add(new FluidPacket(source, amount, dir.method_10153()));
        syncToClient();

        return true;
    }

    private static final class FluidPacket {
        FluidVariant variant;
        long amount;
        class_2350 direction;
        class_2350 lastDirection;
        double progress;

        FluidPacket(FluidVariant variant, long amount, class_2350 direction) {
            this.variant = variant;
            this.amount = amount;
            this.direction = direction;
            this.lastDirection = direction;
            this.progress = 0.0;
        }
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        fluids.clear();
        int count = Math.min((nbt.method_10545("pipe.fluid_count") ? nbt.method_10550("pipe.fluid_count") : 0), MAX_PACKETS);
        for (int i = 0; i < count; i++) {
            int fluidId = (nbt.method_10545("pipe.fid_" + i) ? nbt.method_10550("pipe.fid_" + i) : -1);
            long amount = (nbt.method_10545("pipe.amt_" + i) ? nbt.method_10537("pipe.amt_" + i) : 0L);
            int dirId = (nbt.method_10545("pipe.dir_" + i) ? nbt.method_10550("pipe.dir_" + i) : -1);
            int lastDirId = (nbt.method_10545("pipe.ldir_" + i) ? nbt.method_10550("pipe.ldir_" + i) : -1);
            int progress = (nbt.method_10545("pipe.prog_" + i) ? nbt.method_10550("pipe.prog_" + i) : 0);
            if (fluidId < 0 || dirId < 0 || amount <= 0) continue;
            class_2350 dir = class_2350.method_10143(dirId);
            if (dir == null) continue;
            FluidPacket packet = new FluidPacket(FluidVariant.of(class_7923.field_41173.method_10200(fluidId)), amount, dir);
            packet.progress = progress / 1000.0;
            packet.lastDirection = lastDirId >= 0 ? class_2350.method_10143(lastDirId) : dir;
            if (packet.lastDirection == null) packet.lastDirection = dir;
            fluids.add(packet);
        }
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        int count = Math.min(fluids.size(), MAX_PACKETS);
        nbt.method_10569("pipe.fluid_count", count);

        for (int i = 0; i < count; i++) {
            FluidPacket packet = fluids.get(i);
            nbt.method_10569("pipe.fid_" + i, class_7923.field_41173.method_10206(packet.variant.getFluid()));
            nbt.method_10544("pipe.amt_" + i, packet.amount);
            nbt.method_10569("pipe.dir_" + i, packet.direction.method_10146());
            nbt.method_10569("pipe.ldir_" + i, packet.lastDirection.method_10146());
            nbt.method_10569("pipe.prog_" + i, (int) Math.round(packet.progress * 1000.0));
        }
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }

    private void syncToClient() {
        method_5431();
        if (field_11863 != null && !field_11863.method_8608()) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    public static final class PipeFluid {
        public final FluidVariant variant;
        public final long amount;
        public final class_2350 direction;
        public final double progress;

        private PipeFluid(FluidVariant variant, long amount, class_2350 direction, double progress) {
            this.variant = variant;
            this.amount = amount;
            this.direction = direction;
            this.progress = progress;
        }
    }
}
