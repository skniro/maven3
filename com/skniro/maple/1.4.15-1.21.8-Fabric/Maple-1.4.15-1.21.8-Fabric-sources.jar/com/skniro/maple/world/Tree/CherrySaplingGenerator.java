package com.skniro.maple.world.Tree;

import com.skniro.maple.world.feature.MapleConfiguredFeatures;
import java.util.Optional;
import net.minecraft.class_8813;

public class CherrySaplingGenerator {
    public static final class_8813 CherrySapling =
            new class_8813("cherrytreesapling", 0f, Optional.empty(),
                    Optional.empty(),
                    Optional.of(MapleConfiguredFeatures.CHERRY_TREE),
                    Optional.empty(),
                    Optional.empty(),
                    Optional.empty());
}