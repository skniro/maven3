package com.skniro.maple.world.biome;

import com.skniro.maple.world.feature.MapleBiomeFeatures;
import net.minecraft.class_1143;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_2922;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_3864;
import net.minecraft.class_4968;
import net.minecraft.class_5195;
import net.minecraft.class_5483;
import net.minecraft.class_5485;
import net.minecraft.class_6796;
import net.minecraft.class_6819;
import net.minecraft.class_7871;
import net.minecraft.world.biome.*;
import org.jetbrains.annotations.Nullable;


public class MapleOverworldBiomes {
    public static class_1959 createMapleGrove(class_7871<class_6796> featureLookup, class_7871<class_2922<?>> carverLookup) {
        class_5485.class_5495 lookupBackedBuilder = new class_5485.class_5495(featureLookup, carverLookup);
        class_5483.class_5496 builder = new class_5483.class_5496();
        class_3864.method_30581(builder);
        addBasicFeatures(lookupBackedBuilder);
        class_3864.method_16981(lookupBackedBuilder);
        class_3864.method_38568(lookupBackedBuilder);
        class_3864.method_17010(lookupBackedBuilder);
        class_3864.method_16977(lookupBackedBuilder);
        lookupBackedBuilder.method_30992(class_2893.class_2895.field_13178, class_6819.field_36130);
        class_3864.method_16979(lookupBackedBuilder);
        MapleBiomeFeatures.addMapleGroveFeatures(lookupBackedBuilder);
        class_3864.method_16971(lookupBackedBuilder);
        class_3864.method_16984(lookupBackedBuilder);
        class_3864.method_17008(lookupBackedBuilder);
        class_3864.method_17009(lookupBackedBuilder);
        class_3864.method_30580(builder);
        class_5195 musicSound = class_1143.method_27283(class_3417.field_35348);
        return createBiome(true, 0.5F, 0.8F, 4159204, 329011, 13408563, 11983713, builder, lookupBackedBuilder, musicSound);
    }

    public static class_1959 createSakura(class_7871<class_6796> featureLookup, class_7871<class_2922<?>> carverLookup) {
        class_5485.class_5495 lookupBackedBuilder = new class_5485.class_5495(featureLookup, carverLookup);
        class_5483.class_5496 builder = new class_5483.class_5496();
        builder.method_31011(class_1311.field_6294, new class_5483.class_1964(class_1299.field_6093, 1, 1, 2)).method_31011(class_1311.field_6294, new class_5483.class_1964(class_1299.field_6140, 2, 2, 6)).method_31011(class_1311.field_6294, new class_5483.class_1964(class_1299.field_6115, 2, 2, 4));
        addBasicFeatures(lookupBackedBuilder);
        class_3864.method_16981(lookupBackedBuilder);
        class_3864.method_38568(lookupBackedBuilder);
        class_3864.method_17010(lookupBackedBuilder);
        class_3864.method_16977(lookupBackedBuilder);
        lookupBackedBuilder.method_30992(class_2893.class_2895.field_13178, class_6819.field_36130);
        MapleBiomeFeatures.addSakuraFeatures(lookupBackedBuilder);
        class_3864.method_16984(lookupBackedBuilder);
        class_3864.method_17008(lookupBackedBuilder);
        class_3864.method_17009(lookupBackedBuilder);
        class_5195 musicSound = class_1143.method_27283(class_3417.field_35348);
        return createBiome(true, 0.5F, 0.8F, 6141935, 6141935, 11983713, 11983713, builder, lookupBackedBuilder, musicSound);
    }

    private static void addBasicFeatures(class_5485.class_5495 generationSettings) {
        class_3864.method_16983(generationSettings);
        class_3864.method_32236(generationSettings);
        class_3864.method_17004(generationSettings);
        class_3864.method_17005(generationSettings);
        class_3864.method_16996(generationSettings);
        class_3864.method_16999(generationSettings);
    }

    protected static int getSkyColor(float temperature) {
        float f = temperature / 3.0F;
        f = class_3532.method_15363(f, -1.0F, 1.0F);
        return class_3532.method_15369(0.62222224F - f * 0.05F, 0.5F + f * 0.1F, 1.0F);
    }


    private static class_1959 createBiome(boolean precipitation, float temperature, float downfall, class_5483.class_5496 spawnSettings, net.minecraft.class_5485.class_7868 generationSettings, @Nullable class_5195 music) {
        return createBiome(precipitation, temperature, downfall, 4159204, 329011, (Integer)null, (Integer)null, spawnSettings, generationSettings, music);
    }

    private static class_1959 createBiome(boolean precipitation, float temperature, float downfall, int waterColor, int waterFogColor, @Nullable Integer grassColor, @Nullable Integer foliageColor, class_5483.class_5496 spawnSettings, net.minecraft.class_5485.class_7868 generationSettings, @Nullable class_5195 music) {
        net.minecraft.class_4763.class_4764 builder = (new net.minecraft.class_4763.class_4764()).method_24395(waterColor).method_24397(waterFogColor).method_24392(12638463).method_30820(getSkyColor(temperature)).method_24943(class_4968.field_23146).method_27346(music);
        if (grassColor != null) {
            builder.method_30822(grassColor);
        }

        if (foliageColor != null) {
            builder.method_30821(foliageColor);
        }

        return (new net.minecraft.class_1959.class_1960()).method_48164(true).method_8747(temperature).method_8727(downfall).method_24379(builder.method_24391()).method_30974(spawnSettings.method_31007()).method_30973(generationSettings.method_46671()).method_30972();
    }
}
