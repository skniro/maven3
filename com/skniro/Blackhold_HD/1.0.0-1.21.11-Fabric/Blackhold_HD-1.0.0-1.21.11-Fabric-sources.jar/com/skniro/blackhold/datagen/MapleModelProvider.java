package com.skniro.blackhold.datagen;

import com.skniro.blackhold.block.*;
import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_4910;
import net.minecraft.class_4915;

public class MapleModelProvider extends FabricModelProvider {
    public MapleModelProvider(FabricDataOutput dataGenerator){
        super(dataGenerator);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator){
        blockStateModelGenerator.method_25708(FurnitureDrawBlocks.Oak_Allay_Draw);
        blockStateModelGenerator.method_25708(FurnitureDrawBlocks.Spruce_Allay_Draw);
        blockStateModelGenerator.method_25708(FurnitureDrawBlocks.Birch_Allay_Draw);
        blockStateModelGenerator.method_25708(FurnitureDrawBlocks.Jungle_Allay_Draw);
        blockStateModelGenerator.method_25708(FurnitureDrawBlocks.Acacia_Allay_Draw);
        blockStateModelGenerator.method_25708(FurnitureDrawBlocks.DarkOak_Allay_Draw);
        blockStateModelGenerator.method_25708(FurnitureDrawBlocks.Mangrove_Allay_Draw);
        blockStateModelGenerator.method_25708(FurnitureDrawBlocks.Bamboo_Allay_Draw);
        blockStateModelGenerator.method_25708(FurnitureDrawBlocks.Cherry_Allay_Draw);
        blockStateModelGenerator.method_25708(FurnitureDrawBlocks.Crimson_Allay_Draw);
        blockStateModelGenerator.method_25708(FurnitureDrawBlocks.Warped_Allay_Draw);
        blockStateModelGenerator.method_25708(FurnitureDrawBlocks.PaleOak_Allay_Draw);
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {

    }
}
