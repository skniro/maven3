package com.skniro.skniro_furniture.block.entity;

import com.skniro.skniro_furniture.block.init.BookDeskBlock;
import net.minecraft.class_1263;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1843;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3829;
import net.minecraft.class_3908;
import net.minecraft.class_3913;
import net.minecraft.class_3916;
import net.minecraft.class_7225;
import net.minecraft.class_9301;
import net.minecraft.class_9302;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;

public class BookDeskBlockEntity extends class_2586 implements class_3829, class_3908 {
    private final class_1263 inventory = new class_1263() {
        public int method_5439() {
            return 1;
        }

        public boolean method_5442() {
            return BookDeskBlockEntity.this.book.method_7960();
        }

        public class_1799 method_5438(int slot) {
            return slot == 0 ? BookDeskBlockEntity.this.book : class_1799.field_8037;
        }

        public class_1799 method_5434(int slot, int amount) {
            if (slot == 0) {
                class_1799 itemStack = BookDeskBlockEntity.this.book.method_7971(amount);
                if (BookDeskBlockEntity.this.book.method_7960()) {
                    BookDeskBlockEntity.this.onBookRemoved();
                }

                return itemStack;
            } else {
                return class_1799.field_8037;
            }
        }

        public class_1799 method_5441(int slot) {
            if (slot == 0) {
                class_1799 itemStack = BookDeskBlockEntity.this.book;
                BookDeskBlockEntity.this.book = class_1799.field_8037;
                BookDeskBlockEntity.this.onBookRemoved();
                return itemStack;
            } else {
                return class_1799.field_8037;
            }
        }

        public void method_5447(int slot, class_1799 stack) {
        }

        public int method_5444() {
            return 1;
        }

        public void method_5431() {
            BookDeskBlockEntity.this.method_5431();
        }

        public boolean method_5443(class_1657 player) {
            return class_1263.method_49105(BookDeskBlockEntity.this, player) && BookDeskBlockEntity.this.hasBook();
        }

        public boolean method_5437(int slot, class_1799 stack) {
            return false;
        }

        public void method_5448() {
        }
    };
    private final class_3913 propertyDelegate = new class_3913() {
        public int method_17390(int index) {
            return index == 0 ? BookDeskBlockEntity.this.currentPage : 0;
        }

        public void method_17391(int index, int value) {
            if (index == 0) {
                BookDeskBlockEntity.this.setCurrentPage(value);
            }

        }

        public int method_17389() {
            return 1;
        }
    };
    class_1799 book;
    int currentPage;
    private int pageCount;

    public BookDeskBlockEntity(class_2338 pos, class_2680 state) {
        super(FurnitureBlockEntityType.BOOK_DESK_BLOCK_ENTITY, pos, state);
        this.book = class_1799.field_8037;
    }

    public class_1799 getBook() {
        return this.book;
    }

    public boolean hasBook() {
        return this.book.method_57826(class_9334.field_49653) || this.book.method_57826(class_9334.field_49606);
    }

    public void setBook(class_1799 book) {
        this.setBook(book, null);
    }

    void onBookRemoved() {
        this.currentPage = 0;
        this.pageCount = 0;
        BookDeskBlock.setHasBook(null, this.method_10997(), this.method_11016(), this.method_11010(), false);
    }

    public void setBook(class_1799 book, @Nullable class_1657 player) {
        this.book = this.resolveBook(book, player);
        this.currentPage = 0;
        this.pageCount = getPageCount(this.book);
        this.method_5431();
    }

    void setCurrentPage(int currentPage) {
        int i = class_3532.method_15340(currentPage, 0, this.pageCount - 1);
        if (i != this.currentPage) {
            this.currentPage = i;
            this.method_5431();
        }

    }

    public int getCurrentPage() {
        return this.currentPage;
    }

    public int getComparatorOutput() {
        float f = this.pageCount > 1 ? (float)this.getCurrentPage() / ((float)this.pageCount - 1.0F) : 1.0F;
        return class_3532.method_15375(f * 14.0F) + (this.hasBook() ? 1 : 0);
    }

    private class_1799 resolveBook(class_1799 book, @Nullable class_1657 player) {
        class_1937 var4 = this.field_11863;
        if (var4 instanceof class_3218 serverWorld) {
            class_1843.method_8054(book, this.getCommandSource(player, serverWorld), player);
        }

        return book;
    }

    private class_2168 getCommandSource(@Nullable class_1657 player, class_3218 world) {
        String string;
        class_2561 text;
        if (player == null) {
            string = "Book Desk";
            text = class_2561.method_43470("Book Desk");
        } else {
            string = player.method_5477().getString();
            text = player.method_5476();
        }

        class_243 vec3d = class_243.method_24953(this.field_11867);
        return new class_2168(class_2165.field_17395, vec3d, class_241.field_1340, world, 2, string, text, world.method_8503(), player);
    }

    protected void method_11014(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11014(nbt, registryLookup);
        if (nbt.method_10573("Book", 10)) {
            this.book = this.resolveBook((class_1799)class_1799.method_57360(registryLookup, nbt.method_10562("Book")).orElse(class_1799.field_8037), (class_1657)null);
        } else {
            this.book = class_1799.field_8037;
        }

        this.pageCount = getPageCount(this.book);
        this.currentPage = class_3532.method_15340(nbt.method_10550("Page"), 0, this.pageCount - 1);
    }

    protected void method_11007(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11007(nbt, registryLookup);
        if (!this.getBook().method_7960()) {
            nbt.method_10566("Book", this.getBook().method_57358(registryLookup));
            nbt.method_10569("Page", this.currentPage);
        }

    }

    public void method_5448() {
        this.setBook(class_1799.field_8037);
    }

    public void onBlockReplaced(class_2338 pos, class_2680 oldState) {
        if (oldState.method_11654(BookDeskBlock.HAS_BOOK) && this.field_11863 != null) {
            class_2350 direction = oldState.method_11654(BookDeskBlock.FACING);
            class_1799 itemStack = this.getBook().method_7972();
            float f = 0.25F * (float)direction.method_10148();
            float g = 0.25F * (float)direction.method_10165();
            class_1542 itemEntity = new class_1542(this.field_11863, (double)pos.method_10263() + (double)0.5F + (double)f, pos.method_10264() + 1, (double)pos.method_10260() + (double)0.5F + (double)g, itemStack);
            itemEntity.method_6988();
            this.field_11863.method_8649(itemEntity);
        }

    }

    public class_1703 createMenu(int i, class_1661 playerInventory, class_1657 playerEntity) {
        return new class_3916(i, this.inventory, this.propertyDelegate);
    }

    public class_2561 method_5476() {
        return class_2561.method_43471("container.lectern");
    }

    private static int getPageCount(class_1799 stack) {
        class_9302 writtenBookContentComponent = stack.method_57824(class_9334.field_49606);
        if (writtenBookContentComponent != null) {
            return writtenBookContentComponent.comp_2422().size();
        } else {
            class_9301 writableBookContentComponent = stack.method_57824(class_9334.field_49653);
            return writableBookContentComponent != null ? writableBookContentComponent.comp_2422().size() : 0;
        }
    }
}