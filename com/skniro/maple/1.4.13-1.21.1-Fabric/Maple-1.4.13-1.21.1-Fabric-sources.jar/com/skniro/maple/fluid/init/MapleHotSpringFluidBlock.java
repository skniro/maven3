package com.skniro.maple.fluid.init;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_3609;

public class MapleHotSpringFluidBlock extends class_2404 {
    public MapleHotSpringFluidBlock(class_3609 fluid, class_2251 settings) {
        super(fluid, settings);
    }

    @Override
    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        if (entity instanceof class_1309 && this.method_9545(state).method_15772().method_15793(this.method_9545(state))) {
            if(!((class_1309) entity).method_6059(class_1294.field_5924)){
                ((class_1309) entity).method_6092(new class_1293(class_1294.field_5924, 10 * 6,1));
            }
        }
    }
}
