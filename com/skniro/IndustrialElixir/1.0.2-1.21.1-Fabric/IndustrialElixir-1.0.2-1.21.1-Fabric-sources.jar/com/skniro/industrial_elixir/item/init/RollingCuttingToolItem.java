package com.skniro.industrial_elixir.item.init;

import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class RollingCuttingToolItem extends class_1792 {

    public RollingCuttingToolItem(class_1793 settings) {
        super(settings.method_7895(80));
    }
    public static class_1799 getRemainingTool(class_1799 stack) {
        int damage = stack.method_7919() + 1;
        if (damage >= stack.method_7936()) {
            return class_1799.field_8037;
        }

        class_1799 copy = stack.method_7972();
        copy.method_7974(damage);
        return copy;
    }
}
