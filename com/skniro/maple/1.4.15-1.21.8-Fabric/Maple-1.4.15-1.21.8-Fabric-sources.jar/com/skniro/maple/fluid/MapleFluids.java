package com.skniro.maple.fluid;

import com.skniro.maple.Maple;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_7923;

    public class MapleFluids {
        public static class_3609 STILL_Hot_Spring;
        public static class_3609 FLOWING_Hot_Spring;

        public static void registerFluids() {
            STILL_Hot_Spring = class_2378.method_10230(class_7923.field_41173,
                    class_2960.method_60655(Maple.MOD_ID, "hot_spring"), new MapleHotSpringFluid.Still());

            FLOWING_Hot_Spring = class_2378.method_10230(class_7923.field_41173,
                    class_2960.method_60655(Maple.MOD_ID, "flowing_hot_spring_water"), new MapleHotSpringFluid.Flowing());
        }
    }

