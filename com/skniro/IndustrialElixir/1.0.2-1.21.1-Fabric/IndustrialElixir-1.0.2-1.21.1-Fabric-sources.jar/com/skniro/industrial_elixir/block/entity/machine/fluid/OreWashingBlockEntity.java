package com.skniro.industrial_elixir.block.entity.machine.fluid;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.fluid.OreWashingBlock;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.machine.AbstractMachineCraftingRecipe;
import com.skniro.industrial_elixir.recipe.machine.OreWashingCraftingRecipe;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.OreWashingScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1264;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class OreWashingBlockEntity extends AbstractFluidMachineEntity {

    public OreWashingBlockEntity(class_2338 pos, class_2680 blockState) {
        super(AlchemyBlockEntityType.Ore_Washing_BLOCK_ENTITY, pos, blockState);
        this.DEFAULT_MAX_PROGRESS = 500;
        this.maxProgress = 500;
        this.inventory = class_2371.method_10213(12, class_1799.field_8037);
    }

    // 320/20 = 16 EU/t
    @Override
    public long getCraftEnergyCost() {
        return 320;
    }

    @Override
    protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        SingleVariantStorage.writeNbt(fluidContainer, FluidVariant.CODEC, output, registries);
    }

    @Override
    protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        super.method_11014(input, registries);
        SingleVariantStorage.readNbt(fluidContainer, FluidVariant.CODEC, FluidVariant::blank, input, registries);
    }

    public void drops() {
        class_1264.method_17349(this.field_11863, this.field_11867, inventory);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.OreWashing);
    }

    @Override
    public @Nullable class_1703 createMenu(int containerId, class_1661 inventory, class_1657 player) {
        return new OreWashingScreenHandler(containerId, inventory, this, this.propertyDelegate);
    }

    @Override
    protected void craftItem() {
        OreWashingCraftingRecipe recipe = (OreWashingCraftingRecipe) getCurrentRecipe().get().comp_1933();
        this.method_5434(INPUT_SLOT, recipe.requiredCount());
        insertOutput(OUTPUT_SLOT, recipe.output().method_7972());
        recipe.output2().ifPresent(output -> insertOutput(OUTPUT_SLOT_2, output.method_7972()));
        recipe.output3().ifPresent(output -> insertOutput(OUTPUT_SLOT_3, output.method_7972()));
        try (Transaction tx = Transaction.openOuter()) {
            fluidContainer.extract(fluidContainer.getResource(), recipe.requiredFluidAmount(), tx);
            tx.commit();
        }
    }

    private void insertOutput(int slot, class_1799 output) {
        if (output.method_7960()) {
            return;
        }
        if (this.method_5438(slot).method_7960()) {
            this.method_5447(slot, output.method_7972());
        } else {
            this.method_5438(slot).method_7933(output.method_7947());
        }
    }

    /* SIDED INVENTORY */
    @Override
    public boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 side) {
        if (side == null || side == class_2350.field_11033) return false;
        if (side == class_2350.field_11036) return slot == INPUT_SLOT;

        if (slot != INPUT_SLOT && slot != FLUID_ITEM_SLOT && slot != ENERGY_ITEM_SLOT) {
            return false;
        }

        class_2350 localDir = this.field_11863.method_8320(this.method_11016()).method_11654(OreWashingBlock.FACING);
        return switch (slot) {
            case INPUT_SLOT, SECOND_INPUT_SLOT -> side != localDir.method_10153(); // If not Up/Down/Back, it must be Front/Left/Right
            case FLUID_ITEM_SLOT -> side == localDir.method_10170(); // Left
            case ENERGY_ITEM_SLOT -> side == localDir.method_10160(); // Right
            default -> false; // Fallback
        };
    }

    @Override
    public boolean method_5493(int slot, class_1799 stack, class_2350 side) {
        if ((slot != OUTPUT_SLOT && slot != OUTPUT_SLOT_2 && slot != OUTPUT_SLOT_3) || side == class_2350.field_11036) {
            return false;
        }

        if (side == class_2350.field_11033) {
            return true;
        }

        class_2350 localDir = this.field_11863.method_8320(this.method_11016()).method_11654(OreWashingBlock.FACING);
        return side == localDir.method_10153() || side == localDir.method_10170();
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return slot != OUTPUT_SLOT && slot != OUTPUT_SLOT_2 && slot != OUTPUT_SLOT_3;
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return AlchemyRecipeType.ORE_WASHING.type;
    }

    @Override
    public int[] method_5494(class_2350 direction) {
        if (direction != class_2350.field_11033) {
            return new int[]{INPUT_SLOT, FLUID_ITEM_SLOT, ENERGY_ITEM_SLOT};
        } else {
            return new int[]{OUTPUT_SLOT, OUTPUT_SLOT_2, OUTPUT_SLOT_3};
        }
    }

    @Override
    public Optional<class_8786<AbstractMachineCraftingRecipe>> getCurrentRecipe() {
        return this.method_10997().method_8503().method_3772()
                .method_8132((class_3956<AbstractMachineCraftingRecipe>) getCurrentRecipeType(),
                        new AlchemyCraftingRecipeInput(inventory.get(INPUT_SLOT)), this.method_10997());
    }

    @Override
    public boolean hasRecipe() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> opt = getCurrentRecipe();
        if (opt.isEmpty()) return false;

        var recipeHolder = opt.get();
        var recipe = recipeHolder.comp_1933();
        OreWashingCraftingRecipe washingRecipe = (OreWashingCraftingRecipe) recipe;

        if (!canInsertIntoSlot(OUTPUT_SLOT, washingRecipe.output().method_7972())) return false;
        if (washingRecipe.output2().isPresent() && !canInsertIntoSlot(OUTPUT_SLOT_2, washingRecipe.output2().get().method_7972())) return false;
        if (washingRecipe.output3().isPresent() && !canInsertIntoSlot(OUTPUT_SLOT_3, washingRecipe.output3().get().method_7972())) return false;
        if (!hasEnoughEnergyToCraft()) return false;

        var currentFluid = this.fluidContainer.getResource().getFluid();
        var currentId = class_7923.field_41173.method_10221(currentFluid);
        return currentId != null
                && washingRecipe.requiredFluid().equals(currentId)
                && this.fluidContainer.getAmount() >= washingRecipe.requiredFluidAmount();
    }

    private boolean canInsertIntoSlot(int slot, class_1799 output) {
        if (output.method_7960()) {
            return true;
        }
        class_1799 stack = this.method_5438(slot);
        int maxCount = stack.method_7960() ? output.method_7914() : stack.method_7914();
        return (stack.method_7960() || class_1799.method_31577(stack, output))
                && maxCount >= stack.method_7947() + output.method_7947();
    }

    @Override
    public void extractFluidForCrafting() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> recipe = getCurrentRecipe();
        if (recipe.isEmpty() || !(recipe.get().comp_1933() instanceof OreWashingCraftingRecipe washingRecipe)) {
            return;
        }
        try (Transaction transaction = Transaction.openOuter()) {
            fluidContainer.extract(fluidContainer.getResource(), washingRecipe.requiredFluidAmount(), transaction);
            transaction.commit();
        }
    }
}
