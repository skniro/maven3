package com.skniro.industrial_elixir.keybind;

import com.skniro.industrial_elixir.IndustrialElixir;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class ModKeyMappings {
    public static final String INDUSTRIAL_ELIXIR = "key.category.industrial_elixir.industrial_elixir.keybinds";

    public static final class_304 Mode_Switch_Keybind = KeyBindingHelper.registerKeyBinding(
            new class_304("key.industrial_elixir.mode_switch_key", class_3675.class_307.field_1668, GLFW.GLFW_KEY_M, INDUSTRIAL_ELIXIR));
    public static final class_304 ALT_Keybind = KeyBindingHelper.registerKeyBinding(
            new class_304("key.industrial_elixir.alt_key", class_3675.class_307.field_1668, GLFW.GLFW_KEY_LEFT_ALT, INDUSTRIAL_ELIXIR));
    public static final class_304 Boost_Keybind = KeyBindingHelper.registerKeyBinding(
            new class_304("key.industrial_elixir.boost_key", class_3675.class_307.field_1668, GLFW.GLFW_KEY_LEFT_CONTROL, INDUSTRIAL_ELIXIR));

    public static void registerKeys() {
        IndustrialElixir.LOGGER.info("Registering Keys for " + IndustrialElixir.MOD_ID);
    }
}
