package com.skniro.maple.block.renderer;


import com.skniro.maple.block.entity.MapleJuicerBlockEntity;
import com.skniro.maple.block.renderer.state.MapleJuicerBlockEntityRenderState;
import org.jetbrains.annotations.Nullable;

import java.util.Random;
import net.minecraft.class_10442;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_12075;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;

public class MapleJuicerEntityRenderer implements class_827<MapleJuicerBlockEntity, MapleJuicerBlockEntityRenderState> {
    public MapleJuicerEntityRenderer(class_5614.class_5615 context) {
    }

    @Override
    public void render(MapleJuicerBlockEntityRenderState state, class_4587 matrices, class_11659 queue, class_12075 cameraState) {
        int itemCount = 15;

        Random random = new Random(state.field_62673.method_10063());
        for (int i = 0; i < itemCount; i++) {
            matrices.method_22903();

            double offsetX = 0.4 + random.nextDouble() * 0.20;
            double offsetY = 0.3 + random.nextDouble() * 0.20;
            double offsetZ = 0.4 + random.nextDouble() * 0.20;
            matrices.method_22904(offsetX, offsetY, offsetZ);

            float scale = 0.45f + random.nextFloat() * 0.1f;
            matrices.method_22905(scale, scale, scale);

            float rotation = random.nextFloat() * 260.0f;
            matrices.method_22907(class_7833.field_40714.rotationDegrees(rotation));

            state.item.method_65604(matrices, queue, state.field_62676, class_4608.field_21444,0);
            matrices.method_22909();
        }
    }


    private int getLightLevel(class_1937 world, class_2338 pos) {
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, Math.max(sLight, 15));
    }

    @Override
    public MapleJuicerBlockEntityRenderState method_74335() {
        return new MapleJuicerBlockEntityRenderState();
    }

    @Override
    public void updateRenderState(MapleJuicerBlockEntity entity, MapleJuicerBlockEntityRenderState state, float tickProgress, class_243 cameraPos, @Nullable class_11683.class_11792 crumblingOverlay) {
        class_827.super.method_74331(entity, state, tickProgress, cameraPos, crumblingOverlay);
        class_10442 itemModelResolver = class_310.method_1551().method_65386();
        itemModelResolver.method_65598(state.item, entity.getRenderStack(), class_811.field_4317, entity.method_10997(), null, 1);
        state.field_62673 = entity.method_11016();
        state.field_62674 = entity.method_11010();
        state.field_62676 = getLightLevel(entity.method_10997(), entity.method_11016());
    }
}