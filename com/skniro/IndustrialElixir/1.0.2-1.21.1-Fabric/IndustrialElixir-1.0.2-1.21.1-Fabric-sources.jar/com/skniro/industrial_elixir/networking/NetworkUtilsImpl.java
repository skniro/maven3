package com.skniro.industrial_elixir.networking;

import com.google.common.base.Suppliers;
import com.skniro.industrial_elixir.block.entity.machine.MetalFormerBlockEntity;
import com.skniro.industrial_elixir.screen.handler.machine.VendorMachineScreenHandler;
import com.skniro.industrial_elixir.networking.packet.VendorMachineSynPayload;
import com.skniro.industrial_elixir.networking.packet.BoostJumpC2SPayload;
import com.skniro.industrial_elixir.networking.packet.JetpackInputC2SPayload;
import com.skniro.industrial_elixir.networking.packet.MetalFormerStateC2SPayload;
import com.skniro.industrial_elixir.networking.packet.ToggleHoverC2SPayload;
import com.skniro.industrial_elixir.networking.packet.ToggleNightVisionC2SPayload;
import com.skniro.industrial_elixir.item.init.JetpackHelper;
import com.skniro.industrial_elixir.item.init.QuantumSuitItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1657;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8103;
import java.util.function.Supplier;

public class NetworkUtilsImpl {
    private static final Supplier<NetworkUtilsImpl> instance = Suppliers.memoize(NetworkUtilsImpl::new);

    public static NetworkUtilsImpl getInstance() {
        return instance.get();
    }

    public void initialize() {
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            ClientNetworking.initialize();
        }

        ServerPlayNetworking.registerGlobalReceiver(
                MetalFormerStateC2SPayload.TYPE,
                (payload, context) -> {
                    class_3222 player = context.player();
                    class_3218 world = player.method_51469();
                    context.server().execute(() -> {
                        class_2586 be = world.method_8321(payload.pos());
                        if (be instanceof MetalFormerBlockEntity machine) {
                            machine.setState(MetalFormerBlockEntity.MetalFormerState.values()[payload.state()]);
                            machine.method_5431();
                        }
                    });
                }
        );

        ServerPlayNetworking.registerGlobalReceiver(
                ToggleNightVisionC2SPayload.TYPE,
                (payload, context) -> {
                    context.server().execute(() -> {
                        QuantumSuitItem.toggleNightVision(context.player().method_5667());
                    });
                }
        );

        ServerPlayNetworking.registerGlobalReceiver(
                BoostJumpC2SPayload.TYPE,
                (payload, context) -> {
                    context.server().execute(() -> {
                        QuantumSuitItem.performBoostJump(context.player());
                    });
                }
        );

        ServerPlayNetworking.registerGlobalReceiver(
                ToggleHoverC2SPayload.TYPE,
                (payload, context) -> {
                    context.server().execute(() -> {
                        JetpackHelper.toggleHover(context.player().method_5667());
                    });
                }
        );

        ServerPlayNetworking.registerGlobalReceiver(
                JetpackInputC2SPayload.TYPE,
                (payload, context) -> {
                    context.server().execute(() -> {
                        JetpackHelper.updateInput(
                                context.player().method_5667(),
                                payload.jumpHeld(),
                                payload.forwardHeld(),
                                payload.strafe()
                        );
                    });
                }
        );

        // Unified damage handling for all Quantum Suit pieces
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!(entity instanceof class_1657 player)) return true;

            // Fall damage negation (Quantum Boots)
            if (source.method_48793().method_40220(class_8103.field_42250)) {
                return !QuantumSuitItem.tryNegateFallDamage(player);
            }

            // Lava immunity (full Quantum set)
            if (source.method_48793().method_40220(class_8103.field_42246)
                    && player.method_5771()
                    && QuantumSuitItem.hasFullQuantumSet(player)) {
                return false;
            }

            // General damage absorption for all quantum pieces
            if (amount > 0) {
                return QuantumSuitItem.absorbDamage(player, amount, source);
            }

            return true;
        });
    }

    private static class ClientNetworking {
        private static void initialize() {
            ClientPlayNetworking.registerGlobalReceiver(VendorMachineSynPayload.TYPE,
                    (payload, context) -> {
                        context.client().execute(() -> {
                            if (class_310.method_1551().field_1724 != null
                                    && class_310.method_1551().field_1724.field_7512 instanceof VendorMachineScreenHandler menu) {
                                menu.setOffers(payload.toMerchantOffers());
                            }
                        });
                    });
        }
    }
}
