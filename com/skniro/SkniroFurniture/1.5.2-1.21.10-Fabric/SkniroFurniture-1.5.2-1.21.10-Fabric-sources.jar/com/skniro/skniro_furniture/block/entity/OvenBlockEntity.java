package com.skniro.skniro_furniture.block.entity;

import com.skniro.skniro_furniture.init.FurnitureStrings;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2609;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3706;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_9895;
import org.jetbrains.annotations.Nullable;

public class OvenBlockEntity extends class_2609 {
    public OvenBlockEntity(class_2338 pos, class_2680 state) {
        super(FurnitureBlockEntityType.OVEN_BLOCK_ENTITY, pos, state, class_3956.field_17548);
    }

    protected class_2561 method_17823() {
        return class_2561.method_43471(FurnitureStrings.Oven);
    }

    protected int method_11200(class_9895 fuelRegistry, class_1799 stack) {
        return super.method_11200(fuelRegistry, stack) / 2;
    }

    protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return new class_3706(syncId, playerInventory, this, this.field_17374);
    }

    @Override
    public void method_5431() {
        field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        super.method_5431();
    }

    public class_1799 getRenderStack() {
        if (this.method_5438(field_31286).method_7960()){
            return this.method_5438(field_31288);
        } else {
            return this.method_5438(field_31286);
        }
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }


    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }

}
