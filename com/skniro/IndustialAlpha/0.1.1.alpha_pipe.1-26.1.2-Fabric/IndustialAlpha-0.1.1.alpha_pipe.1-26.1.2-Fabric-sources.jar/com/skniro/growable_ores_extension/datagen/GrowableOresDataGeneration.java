package com.skniro.growable_ores_extension.datagen;

import com.skniro.growable_ores_extension.datagen.dynamic.ModDamageTypeProvider;
import com.skniro.growable_ores_extension.datagen.recipe.RecipeDataGeneration;
import com.skniro.growable_ores_extension.world.feature.AgreeTreeConfiguredFeatures;
import com.skniro.growable_ores_extension.world.feature.AgreeTreePlacedFeatures;
import com.skniro.growable_ores_extension.world.feature.ModConfiguredFeatures;
import com.skniro.growable_ores_extension.world.feature.ModPlacedFeatures;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.core.RegistrySetBuilder;
import net.minecraft.core.registries.Registries;

public class GrowableOresDataGeneration implements DataGeneratorEntrypoint {
    @Override
    public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {
        fabricDataGenerator.createPack().addProvider(GrowableModelProvider::new);
        fabricDataGenerator.createPack().addProvider(GrowableLootTableGenerator::new);
        fabricDataGenerator.createPack().addProvider(GrowableEnglishLanguageProvider::new);
        fabricDataGenerator.createPack().addProvider(GrowableSimplifiedChineseLanguageProvider::new);
        fabricDataGenerator.createPack().addProvider(GrowableBlockTagGenerator::new);
        fabricDataGenerator.createPack().addProvider(GrowableItemTagGenerator::new);
        fabricDataGenerator.createPack().addProvider(ModDynamicGenerator::new);
        RecipeDataGeneration.onInit(fabricDataGenerator);
    }

    @Override
    public void buildRegistry(RegistrySetBuilder registryBuilder) {
        registryBuilder.add(Registries.DAMAGE_TYPE, ModDamageTypeProvider::damageTypes);
        registryBuilder.add(Registries.CONFIGURED_FEATURE, ModConfiguredFeatures::bootstrap);
        registryBuilder.add(Registries.PLACED_FEATURE, ModPlacedFeatures::bootstrap);
        registryBuilder.add(Registries.CONFIGURED_FEATURE, AgreeTreeConfiguredFeatures::bootstrap);
        registryBuilder.add(Registries.PLACED_FEATURE, AgreeTreePlacedFeatures::bootstrap);
    }
}
