package com.skniro.growable_ores_extension.datagen.recipe.material;

import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_7225;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class MaterialRecipeGenerator extends FabricRecipeProvider {
    public MaterialRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {

            }
        };
    }

    @Override
    public String method_10321() {
        return "Material";
    }
}