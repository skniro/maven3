package com.skniro.growable_ores_extension.item.init;

import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.api.item.TieredEnergyItem;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.base.SimpleEnergyItem;
import net.minecraft.class_1792;
import net.minecraft.class_1799;


public class BatteryItem extends class_1792 implements SimpleEnergyItem, TieredEnergyItem {
    private EnergyTier energyTier;
    private long capacity;

    public BatteryItem(class_1793 settings, EnergyTier energyTier, long capacity) {
        super(settings.method_7889(1));
        this.energyTier = energyTier;
        this.capacity = capacity;
        EnergyStorage.ITEM.registerForItems((stack, context) -> SimpleEnergyItem.createStorage(context, this.getEnergyCapacity(stack), this.getEnergyMaxInput(stack), this.getEnergyMaxOutput(stack)), this);
    }

    @Override
    public int method_31569(class_1799 stack) {
        return getPowerForDurabilityBar(stack);
    }

    public boolean method_31567(class_1799 stack) {
        return true;
    }

    public int method_31571(class_1799 stack) {
        return getColorForDurabilityBar(stack);
    }

    public long getEnergyCapacity(class_1799 stack) {
        return capacity;
    }

    @Override
    public long getEnergyMaxInput(class_1799 stack) {
        return energyTier.getMaxInput();
    }

    @Override
    public long getEnergyMaxOutput(class_1799 stack) {
        return energyTier.getMaxOutput();
    }

    public static int getPowerForDurabilityBar(class_1799 stack) {
        class_1792 var2 = stack.method_7909();
        if (var2 instanceof BatteryItem energyItem) {
            return Math.round((float)energyItem.getStoredEnergy(stack) * 100.0F / (float)energyItem.getEnergyCapacity(stack) * 13.0F) / 100;
        } else {
            throw new UnsupportedOperationException();
        }
    }

    public static int getColorForDurabilityBar(class_1799 stack) {
        return 16744454;
    }

    @Override
    public EnergyTier getEnergyTier() {
        return energyTier;
    }
}
