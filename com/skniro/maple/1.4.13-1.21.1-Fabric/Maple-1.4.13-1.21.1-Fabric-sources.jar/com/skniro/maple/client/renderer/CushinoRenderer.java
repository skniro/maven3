package com.skniro.maple.client.renderer;

import com.skniro.maple.entity.furniture.CushionEntity;
import net.minecraft.class_2960;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class CushinoRenderer extends class_897<CushionEntity> {

    public CushinoRenderer(class_5617.class_5618 ctx) {
        super(ctx);
    }

    @Override
    public class_2960 getTexture(CushionEntity entity) {
        return null;
    }
    @Override
    public boolean shouldRender(CushionEntity livingEntity, class_4604 camera, double camX, double camY, double camZ) {
        return true;
    }


}