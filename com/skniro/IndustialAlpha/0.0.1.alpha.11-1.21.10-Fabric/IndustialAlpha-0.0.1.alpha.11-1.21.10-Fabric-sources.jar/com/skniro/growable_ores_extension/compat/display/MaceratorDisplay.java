package com.skniro.growable_ores_extension.compat.display;

import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.growable_ores_extension.compat.MaceratorCategory;
import com.skniro.growable_ores_extension.recipe.machine.MaceratorCraftingRecipe;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2960;
import net.minecraft.class_8786;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import java.util.List;
import java.util.Optional;

public class MaceratorDisplay extends BasicDisplay {

    public static final DisplaySerializer<MaceratorDisplay> SERIALIZER = DisplaySerializer.of(
            RecordCodecBuilder.mapCodec(instance -> instance.group(
                    EntryIngredient.codec().listOf().fieldOf("inputs").forGetter(MaceratorDisplay::getInputEntries),
                    EntryIngredient.codec().listOf().fieldOf("outputs").forGetter(MaceratorDisplay::getOutputEntries),
                    class_2960.field_25139.optionalFieldOf("location").forGetter(MaceratorDisplay::getDisplayLocation)
            ).apply(instance, MaceratorDisplay::new)),
            class_9139.method_56436(
                    EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
                    MaceratorDisplay::getInputEntries,
                    EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
                    MaceratorDisplay::getOutputEntries,
                    class_9135.method_56382(class_2960.field_48267),
                    MaceratorDisplay::getDisplayLocation,
                    MaceratorDisplay::new
            )
    );

    public MaceratorDisplay(MaceratorCraftingRecipe recipe) {
        this(
                List.of(
                        EntryIngredients.ofIngredient(recipe.ingredient())
                ),
                List.of(
                        EntryIngredients.of(recipe.output())
                ),
                Optional.empty()
        );
    }

    public MaceratorDisplay(List<EntryIngredient> inputs, List<EntryIngredient> outputs, Optional<class_2960> location) {
        super(inputs, outputs, location);
    }

    public MaceratorDisplay(class_8786<MaceratorCraftingRecipe> recipe) {
        super(List.of(EntryIngredients.ofIngredient(recipe.comp_1933().ingredient())),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.comp_1933().output()))));
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return MaceratorCategory.MACERATOR;
    }

    @Override
    public DisplaySerializer<? extends Display> getSerializer() {
        return SERIALIZER;
    }
}