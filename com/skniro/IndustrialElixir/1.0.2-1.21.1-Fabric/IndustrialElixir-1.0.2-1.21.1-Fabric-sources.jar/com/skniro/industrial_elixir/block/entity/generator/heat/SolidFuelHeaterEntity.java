package com.skniro.industrial_elixir.block.entity.generator.heat;

import com.skniro.industrial_elixir.api.item.ModFuelRegistry;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.entity.machine.AbstractMachineEntity;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.energy.heat.api.HeatStorage;
import com.skniro.industrial_elixir.energy.heat.api.HeatStorageUtil;
import com.skniro.industrial_elixir.energy.heat.api.base.SimpleSidedHeatContainer;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.screen.handler.generator.heat.SolidFuelHeaterScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2609;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3913;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public class SolidFuelHeaterEntity extends AbstractMachineEntity {

    public SimpleSidedHeatContainer heatContainer;
    private int burnProgress;
    private int maxBurnProgress;
    private int burnTime = 0;
    private int burnDuration = 0;
    protected final class_3913 propertyDelegate;
    private static final long HEAT_PER_TICK = 10;
    public static final long HEAT_CAPACITY = 100;
    public long getHeatCapacity() { return HEAT_CAPACITY; }

    public SolidFuelHeaterEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.SOLID_FUEL_HEATER_BE, pos, state);
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> SolidFuelHeaterEntity.this.burnProgress;
                    case 1 -> SolidFuelHeaterEntity.this.maxBurnProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: SolidFuelHeaterEntity.this.burnProgress = value;
                    case 1: SolidFuelHeaterEntity.this.maxBurnProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };
        heatContainer = new SimpleSidedHeatContainer() {

            @Override
            public long getCapacity() {
                return 8000;
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                if (side == null) return 100;
                return 0;
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                if (side == null) return 100;
                return side == method_11010().method_11654(AbstractMachineblock.FACING) ? 100 : 0;
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(pos, method_11010(), method_11010(), 3);
            }
        };
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) return;

        // Push heat to neighbors
        pushHeatToNeighbours();

        boolean burning = false;

        if (burnTime > 0) {
            // Currently burning fuel
            if (heatContainer.amount < HEAT_CAPACITY) {
                // Heat has room: produce heat and consume burn time
                try (Transaction tx = Transaction.openOuter()) {
                    heatContainer.getSideStorage(null).insert(HEAT_PER_TICK, tx);
                    tx.commit();
                }
                burnTime--;
                burning = true;
            }
            // If heat is full, burnTime is NOT decremented (paused)
        }

        if (burnTime <= 0 && heatContainer.amount < HEAT_CAPACITY) {
            // Try to start burning new fuel
            class_1799 fuel = inventory.get(INPUT_SLOT);
            int fuelTime = getFuelTime(fuel);
            if (fuelTime > 0) {
                fuel.method_7934(1);
                outputAsh();
                burnTime = fuelTime;
                burnDuration = fuelTime;
                burning = true;
            }
        }

        // Sync progress to property delegate
        this.burnProgress = burnTime;
        this.maxBurnProgress = burnDuration;

        if (state.method_11654(AbstractMachineblock.LIT) != (burning || burnTime > 0)) {
            world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, burning || burnTime > 0), 3);
        }

        method_5431();
    }

    private void outputAsh() {
        class_1799 ash = new class_1799(GrowableOresItems.ASHES);
        class_1799 output = inventory.get(OUTPUT_SLOT);
        if (output.method_7960()) {
            inventory.set(OUTPUT_SLOT, ash.method_7972());
        } else if (class_1799.method_31577(output, ash) && output.method_7947() < output.method_7914()) {
            output.method_7933(1);
        }
    }

    private void pushHeatToNeighbours() {
        if (heatContainer.amount <= 0) return;
        class_2350 direction = method_11010().method_11654(AbstractMachineblock.FACING);
        HeatStorage target = HeatStorage.SIDED.find(field_11863, field_11867.method_10093(direction), direction.method_10153());
        if (target == null) return;
        HeatStorageUtil.move(heatContainer.getSideStorage(direction), target,
                heatContainer.getSideStorage(null).getAmount(), null);
    }

    private int getFuelTime(class_1799 stack) {
        if (stack.method_7960()) return 0;
        Integer custom = ModFuelRegistry.getModFuel().get(stack.method_7909());
        if (custom != null) return custom;
        for (var entry : ModFuelRegistry.getModFuelTags().entrySet()) {
            if (stack.method_31573(entry.getKey())) return entry.getValue();
        }
        if (this.field_11863 != null) {
            return class_2609.method_11196().getOrDefault(stack.method_7909(), 0) / 2;
        }
        return 0;
    }

    public int getBurnTime() { return burnTime; }
    public int getBurnDuration() { return burnDuration; }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Solid_Fuel_Heater);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new SolidFuelHeaterScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    @Override
    public class_3956<?> getCurrentRecipeType() { return null; }

    @Override
    protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        output.method_10569("solid_fuel_heater.burnTime", burnTime);
        output.method_10569("solid_fuel_heater.burnDuration", burnDuration);
        output.method_10544("solid_fuel_heater.heat", heatContainer.amount);
    }

    @Override
    protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        super.method_11014(input, registries);
        burnTime = (input.method_10545("solid_fuel_heater.burnTime") ? input.method_10550("solid_fuel_heater.burnTime") : 0);
        burnDuration = (input.method_10545("solid_fuel_heater.burnDuration") ? input.method_10550("solid_fuel_heater.burnDuration") : 0);
        heatContainer.amount = (input.method_10545("solid_fuel_heater.heat") ? input.method_10537("solid_fuel_heater.heat") : 0);
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_58692(registryLookup);
    }
}
