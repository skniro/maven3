package com.skniro.maple.block.renderer;


import com.skniro.maple.block.entity.MapleJuicerBlockEntity;
import java.util.Random;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_918;

public class MapleJuicerEntityRenderer implements class_827<MapleJuicerBlockEntity> {
    public MapleJuicerEntityRenderer(class_5614.class_5615 context) {
    }

    @Override
    public void render(MapleJuicerBlockEntity entity, float tickDelta, class_4587 matrices,
                       class_4597 vertexConsumers, int light, int overlay, class_243 cameraPos) {
        class_918 itemRenderer = class_310.method_1551().method_1480();
        class_1799 stack = entity.getRenderStack();

        int itemCount = 15;

        Random random = new Random(entity.method_11016().method_10063());
        for (int i = 0; i < itemCount; i++) {
            matrices.method_22903();

            double offsetX = 0.4 + random.nextDouble() * 0.20;
            double offsetY = 0.3 + random.nextDouble() * 0.20;
            double offsetZ = 0.4 + random.nextDouble() * 0.20;
            matrices.method_22904(offsetX, offsetY, offsetZ);

            float scale = 0.45f + random.nextFloat() * 0.1f;
            matrices.method_22905(scale, scale, scale);

            float rotation = random.nextFloat() * 260.0f;
            matrices.method_22907(class_7833.field_40714.rotationDegrees(rotation));

            itemRenderer.method_23178(stack, class_811.field_4317, getLightLevel(entity.method_10997(),
                    entity.method_11016()), class_4608.field_21444, matrices, vertexConsumers, entity.method_10997(), 1);
            matrices.method_22909();
        }
    }


    private int getLightLevel(class_1937 world, class_2338 pos) {
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, Math.max(sLight, 15));
    }
}