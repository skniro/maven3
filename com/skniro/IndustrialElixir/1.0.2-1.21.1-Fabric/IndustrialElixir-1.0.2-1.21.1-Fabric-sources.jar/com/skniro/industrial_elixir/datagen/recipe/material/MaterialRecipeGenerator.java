package com.skniro.industrial_elixir.datagen.recipe.material;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.item.AdvancedItems;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.item.MapleArmorItems;
import com.skniro.industrial_elixir.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_7225;
import net.minecraft.class_7709;
import net.minecraft.class_7800;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class MaterialRecipeGenerator extends FabricRecipeProvider {
    public MaterialRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                shaped(class_7800.field_40642, GrowableOresItems.ENERGIUM_DUST)
                        .method_10434('R', class_1802.field_8725).method_10434('D', GrowableOresItems.DIAMOND_DUST)
                        .method_10439("RDR").method_10439("DRD").method_10439("RDR")
                        .method_10429("has_item", this.has(class_1802.field_8725)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.BRONZE_DUST)
                        .method_10449(GrowableOresItems.SMALL_BRONZE_DUST,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SMALL_BRONZE_DUST)).method_36443(this.output,"small_bronze_dust_to_bronze_dust");

                shapeless(class_7800.field_40642, GrowableOresItems.COPPER_DUST)
                        .method_10449(GrowableOresItems.SMALL_COPPER_DUST,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SMALL_BRONZE_DUST)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.BRONZE_DUST, 4)
                        .method_10433('R', ModItemTags.DUST_TIN).method_10433('D', ModItemTags.DUST_COPPER)
                        .method_10439("RD ").method_10439("DD ").method_10439("   ")
                        .method_10429("has_item_tags", this.has(ModItemTags.DUST_COPPER)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.GOLD_DUST)
                        .method_10449(GrowableOresItems.SMALL_GOLD_DUST,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SMALL_GOLD_DUST)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.IRON_DUST)
                        .method_10449(GrowableOresItems.SMALL_IRON_DUST,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SMALL_IRON_DUST)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.LAPIS_DUST)
                        .method_10449(GrowableOresItems.SMALL_LAPIS_DUST,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SMALL_LAPIS_DUST)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.LEAD_DUST)
                        .method_10449(GrowableOresItems.SMALL_LEAD_DUST,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SMALL_LEAD_DUST)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.LITHIUM_DUST)
                        .method_10449(GrowableOresItems.SMALL_LITHIUM_DUST,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SMALL_LITHIUM_DUST)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.OBSIDIAN_DUST)
                        .method_10449(GrowableOresItems.SMALL_OBSIDIAN_DUST,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SMALL_OBSIDIAN_DUST)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.SILVER_DUST)
                        .method_10449(GrowableOresItems.SMALL_SILVER_DUST,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SMALL_SILVER_DUST)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.SULFUR_DUST)
                        .method_10449(GrowableOresItems.SMALL_SULFUR_DUST,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SMALL_SULFUR_DUST)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.TIN_DUST)
                        .method_10449(GrowableOresItems.SMALL_TIN_DUST,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SMALL_TIN_DUST)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.ALLOY_INGOT)
                        .method_10434('I', GrowableOresItems.IRON_PLATE).method_10434('B', GrowableOresItems.BRONZE_PLATE).method_10434('T', GrowableOresItems.TIN_PLATE)
                        .method_10439("III").method_10439("BBB").method_10439("TTT")
                        .method_10429("has_item", this.has(GrowableOresItems.BRONZE_PLATE)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.BRONZE_INGOT, 9)
                        .method_10454(GeneralBlocks.Bronze_Block)
                        .method_10442("has_item", this.has(GeneralBlocks.Bronze_Block)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.LEAD_INGOT, 9)
                        .method_10454(GeneralBlocks.Lead_Block)
                        .method_10442("has_item", this.has(GeneralBlocks.Lead_Block)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.SILVER_INGOT, 9)
                        .method_10454(GeneralBlocks.Silver_Block)
                        .method_10442("has_item", this.has(GeneralBlocks.Silver_Block)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.STEEL_INGOT, 9)
                        .method_10454(GeneralBlocks.Steel_Block)
                        .method_10442("has_item", this.has(GeneralBlocks.Steel_Block)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.SACRED_INGOT, 9)
                        .method_10454(GeneralBlocks.SACRED_Block)
                        .method_10442("has_item", this.has(GeneralBlocks.SACRED_Block)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.TIN_INGOT, 9)
                        .method_10454(GeneralBlocks.Tin_Block)
                        .method_10442("has_item", this.has(GeneralBlocks.Tin_Block)).method_10431(this.output);

                oreSmelting(List.of(GrowableOresItems.Sticky_Resin), class_7800.field_40642, class_7709.field_40244, GrowableOresItems.Rubber, 0.45F, 300, "sticky_resin");

                shaped(class_7800.field_40642, GrowableOresItems.Circuit)
                        .method_10434('I', GrowableOresItems.IRON_PLATE).method_10434('B', GrowableOresBlocks.INSULATED_COPPER_CABLE).method_10434('T', class_1802.field_8725)
                        .method_10439("BBB").method_10439("TIT").method_10439("BBB")
                        .method_10429("has_item", this.has(GrowableOresItems.IRON_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.Advanced_Circuit)
                        .method_10434('I', GrowableOresItems.Circuit).method_10434('B', class_1802.field_8601).method_10434('T', class_1802.field_8725).method_10434('L', class_1802.field_8759)
                        .method_10439("TBT").method_10439("LIL").method_10439("TBT")
                        .method_10429("has_item", this.has(GrowableOresItems.Circuit)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.IRIDIUM_PLATE)
                        .method_10434('I', class_1802.field_8477).method_10434('B', GrowableOresItems.ALLOY_PLATE).method_10434('T', GrowableOresItems.IRIDIUM_ORE)
                        .method_10439("TBT").method_10439("BIB").method_10439("TBT")
                        .method_10429("has_item", this.has(GrowableOresItems.ALLOY_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.CARBON_FIBRE)
                        .method_10434('I', GrowableOresItems.COAL_DUST)
                        .method_10439("II ").method_10439("II ").method_10439("   ")
                        .method_10429("has_item", this.has(GrowableOresItems.COAL_DUST)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.CARBON_MESH)
                        .method_10434('I', GrowableOresItems.CARBON_FIBRE)
                        .method_10439("II ").method_10439("   ").method_10439("   ")
                        .method_10429("has_item", this.has(GrowableOresItems.CARBON_FIBRE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.COAL_BALL)
                        .method_10434('I', GrowableOresItems.COAL_DUST).method_10434('B', class_1802.field_8145)
                        .method_10439("III").method_10439("IBI").method_10439("III")
                        .method_10429("has_item", this.has(GrowableOresItems.COAL_DUST)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.COAL_CHUNK)
                        .method_10434('I', GrowableOresItems.COAL_BALL).method_10434('B', class_1802.field_8773)
                        .method_10439("III").method_10439("IBI").method_10439("III")
                        .method_10429("has_item", this.has(GrowableOresItems.COAL_BALL)).method_10431(this.output);


                shaped(class_7800.field_40642, GrowableOresItems.RE_BATTERY)
                        .method_10434('T', GrowableOresBlocks.INSULATED_TIN_CABLE).method_10434('I', GrowableOresItems.IRON_CASING).method_10434('B', class_1802.field_8725)
                        .method_10439(" T ").method_10439("IBI").method_10439("IBI")
                        .method_10429("has_item", this.has(GrowableOresItems.IRON_CASING)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.ADVANCED_RE_BATTERY)
                        .method_10434('T', GrowableOresBlocks.INSULATED_COPPER_CABLE).method_10434('I', GrowableOresItems.BRONZE_CASING).method_10434('B', GrowableOresItems.SULFUR_DUST).method_10434('C', GrowableOresItems.LEAD_DUST)
                        .method_10439("TIT").method_10439("IBI").method_10439("ICI")
                        .method_10429("has_item", this.has(GrowableOresItems.BRONZE_CASING)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.LAPOTRON_CRYSTAL)
                        .method_10434('T', GrowableOresItems.Advanced_Circuit).method_10434('I', GrowableOresItems.LAPIS_DUST).method_10434('B', GrowableOresItems.ENERGY_CRYSTAL)
                        .method_10439("ITI").method_10439("IBI").method_10439("ITI")
                        .method_10429("has_item", this.has(GrowableOresItems.ENERGY_CRYSTAL)).method_10431(this.output);

                shaped(class_7800.field_40642, MapleArmorItems.ROLLING)
                        .method_10434('T', class_1802.field_8620).method_10434('I', class_1802.field_8600)
                        .method_10439("TT ").method_10439("TII").method_10439("TT ")
                        .method_10429("has_item", this.has(class_1802.field_8620)).method_10431(this.output);

                shaped(class_7800.field_40642, MapleArmorItems.ROLLING)
                        .method_10434('T', class_1802.field_8620).method_10434('I', class_1802.field_8600)
                        .method_10439(" TT").method_10439("IIT").method_10439(" TT")
                        .method_10429("has_item", this.has(class_1802.field_8620)).method_36443(this.output, "right_side_tool_rolling");

                shaped(class_7800.field_40642, MapleArmorItems.CUTTING)
                        .method_10434('T', class_1802.field_8620).method_10434('I', GrowableOresItems.IRON_PLATE)
                        .method_10439("I I").method_10439(" I ").method_10439("T T")
                        .method_10429("has_item", this.has(class_1802.field_8620)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.Coil)
                        .method_10434('T', class_1802.field_8620).method_10434('I', GrowableOresBlocks.COPPER_CABLE)
                        .method_10439("III").method_10439("ITI").method_10439("III")
                        .method_10429("has_item", this.has(class_1802.field_8620)).method_10431(this.output);

                shaped(class_7800.field_40642, GeneralBlocks.Machine)
                        .method_10434('I', GrowableOresItems.IRON_PLATE)
                        .method_10439("III").method_10439("I I").method_10439("III")
                        .method_10429("has_item", this.has(GrowableOresItems.IRON_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, GeneralBlocks.Advanced_Machine)
                        .method_10434('I', GrowableOresItems.STEEL_PLATE).method_10434('M', GeneralBlocks.Machine).method_10434('C', GrowableOresItems.CARBON_PLATE).method_10434('A', GrowableOresItems.ALLOY_PLATE)
                        .method_10439("ICI").method_10439("AMA").method_10439("ICI")
                        .method_10429("has_item", this.has(GrowableOresItems.IRON_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, GeneralBlocks.Super_Machine)
                        .method_10434('I', GrowableOresItems.Advanced_Circuit).method_10434('M', GeneralBlocks.Advanced_Machine).method_10433('C', ModItemTags.Diamond).method_10434('A', GrowableOresBlocks.GLASSFIBER_CABLE)
                        .method_10439("ICI").method_10439("AMA").method_10439("ICI")
                        .method_10429("has_item", this.has(GrowableOresItems.IRON_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.Electric_Motor)
                        .method_10434('I', GrowableOresItems.Coil).method_10434('C', GrowableOresItems.IRON_CASING).method_10434('M', class_1802.field_8620)
                        .method_10439(" C ").method_10439("IMI").method_10439(" C ")
                        .method_10429("has_item", this.has(class_1802.field_8620)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresItems.Scrap_box)
                        .method_10449(GrowableOresItems.Scrap,9)
                        .method_10442("has_item", this.has(GrowableOresItems.Scrap)).method_10431(this.output);

                oreSmelting(List.of(GrowableOresItems.CRUSHED_COPPER, GrowableOresItems.PURIFIED_COPPER, GrowableOresItems.COPPER_DUST), class_7800.field_40642, class_7709.field_40244, class_1802.field_27022, 0.45F, 300, "copper_ingot");
                oreSmelting(List.of(GrowableOresItems.BRONZE_DUST), class_7800.field_40642, class_7709.field_40244, GrowableOresItems.BRONZE_INGOT, 0.45F, 300, "bronze_ingot");
                oreSmelting(List.of(GeneralBlocks.SACRED_Ore, GeneralBlocks.Deepslate_SACRED_Ore, GrowableOresItems.CRUSHED_SACRED, GrowableOresItems.PURIFIED_SACRED), class_7800.field_40642, class_7709.field_40244, GrowableOresItems.SACRED_INGOT, 0.45F, 300, "sacred_ingot");
                oreSmelting(List.of(GrowableOresItems.TIN_DUST, GeneralBlocks.Tin_Ore, GeneralBlocks.Deepslate_Tin_Ore, GrowableOresItems.CRUSHED_TIN, GrowableOresItems.PURIFIED_TIN), class_7800.field_40642, class_7709.field_40244, GrowableOresItems.TIN_INGOT, 0.45F, 300, "tin_ingot");
                oreSmelting(List.of(GrowableOresItems.LEAD_DUST, GeneralBlocks.Lead_Ore, GeneralBlocks.Deepslate_Lead_Ore, GrowableOresItems.CRUSHED_LEAD, GrowableOresItems.PURIFIED_LEAD), class_7800.field_40642, class_7709.field_40244, GrowableOresItems.LEAD_INGOT, 0.45F, 300, "lead_ingot");
                oreSmelting(List.of(GrowableOresItems.CRUSHED_SILVER, GrowableOresItems.PURIFIED_SILVER, GrowableOresItems.SILVER_DUST), class_7800.field_40642, class_7709.field_40244, GrowableOresItems.SILVER_INGOT, 0.45F, 300, "silver_ingot");
                oreSmelting(List.of(GrowableOresItems.CRUSHED_IRON, GrowableOresItems.PURIFIED_IRON, GrowableOresItems.IRON_DUST), class_7800.field_40642, class_7709.field_40244, class_1802.field_8620, 0.45F, 300, "iron_ingot");
                oreSmelting(List.of(GrowableOresItems.CRUSHED_GOLD, GrowableOresItems.PURIFIED_GOLD, GrowableOresItems.GOLD_DUST), class_7800.field_40642, class_7709.field_40244, class_1802.field_8695, 0.45F, 300, "gold_ingot");

                //Nuclear
                shaped(class_7800.field_40642, GrowableOresItems.SACRED_SHARD)
                        .method_10434('U', GrowableOresItems.SACRED_ESSENCE).method_10434('P', AdvancedItems.LUMINITE_ALLOY)
                        .method_10439(" U ").method_10439(" P ").method_10439(" U ")
                        .method_10429("has_item", this.has(GrowableOresItems.SACRED_ESSENCE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.SACRED_CORE)
                        .method_10434('U', GrowableOresItems.SACRED_SHARD).method_10434('P', AdvancedItems.ENRICHED_LUMINITE_ALLOY)
                        .method_10439("UPU").method_10439("   ").method_10439("UPU")
                        .method_10429("has_item", this.has(GrowableOresItems.SACRED_SHARD)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.COOLANT_CELL_10K)
                        .method_10434('C', GrowableOresItems.WATER_CELL).method_10434('P', GrowableOresItems.TIN_PLATE)
                        .method_10439(" P ").method_10439("PCP").method_10439(" P ")
                        .method_10429("has_item", this.has(GrowableOresItems.WATER_CELL)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.COOLANT_CELL_30K)
                        .method_10434('C', GrowableOresItems.COOLANT_CELL_10K).method_10434('P', GrowableOresItems.TIN_PLATE)
                        .method_10439("PPP").method_10439("CCC").method_10439("PPP")
                        .method_10429("has_item", this.has(GrowableOresItems.TIN_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.COOLANT_CELL_60K)
                        .method_10434('C', GrowableOresItems.COOLANT_CELL_10K).method_10434('P', GrowableOresItems.TIN_PLATE)
                        .method_10434('A', GrowableOresItems.IRON_PLATE)
                        .method_10439("PCP").method_10439("PAP").method_10439("PCP")
                        .method_10429("has_item", this.has(GrowableOresItems.TIN_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.HEAT_VENT)
                        .method_10434('P', GrowableOresItems.IRON_PLATE)
                        .method_10434('B', class_1802.field_8076)
                        .method_10434('C', GrowableOresItems.COPPER_PLATE)
                        .method_10439("BPB").method_10439("PCP").method_10439("BPB")
                        .method_10429("has_item", this.has(GrowableOresItems.COPPER_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.ADVANCED_HEAT_VENT)
                        .method_10434('D', class_1802.field_8477)
                        .method_10434('H', GrowableOresItems.HEAT_VENT)
                        .method_10434('B', class_1802.field_8076)
                        .method_10439("BHB").method_10439("BDB").method_10439("BHB")
                        .method_10429("has_item", this.has(class_1802.field_8076)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.OVERCLOCKED_HEAT_VENT)
                        .method_10434('H', GrowableOresItems.ADVANCED_HEAT_VENT)
                        .method_10434('G', GrowableOresItems.GOLD_PLATE)
                        .method_10439(" G ").method_10439("GHG").method_10439(" G ")
                        .method_10429("has_item", this.has(GrowableOresItems.GOLD_PLATE)).method_10431(this.output);

/*                shaped(RecipeCategory.MISC, GrowableOresItems.REACTOR_PLATING)
                        .define('P', GrowableOresItems.LEAD_PLATE).define('C', GrowableOresItems.CARBON_PLATE)
                        .pattern("PPP").pattern("PCP").pattern("PPP")
                        .unlockedBy("has_item", this.has(GrowableOresItems.LEAD_PLATE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.NEUTRON_REFLECTOR)
                        .define('T', GrowableOresItems.TIN_PLATE).define('C', GrowableOresItems.COAL_DUST)
                        .pattern("TTT").pattern("CCC").pattern("TTT")
                        .unlockedBy("has_item", this.has(GrowableOresItems.COAL_DUST)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.HEAT_EXCHANGER)
                        .define('P', GrowableOresItems.COPPER_PLATE).define('V', GrowableOresItems.HEAT_VENT).define('C', GrowableOresItems.Circuit)
                        .pattern(" P ").pattern("VCV").pattern(" P ")
                        .unlockedBy("has_item", this.has(GrowableOresItems.HEAT_VENT)).save(this.output);*/

                shaped(class_7800.field_40642, GrowableOresItems.HEAT_CONDUCTOR)
                        .method_10434('P', GrowableOresItems.COPPER_PLATE).method_10434('C', GrowableOresItems.Rubber)
                        .method_10439("CPC").method_10439("CPC").method_10439("CPC")
                        .method_10429("has_item", this.has(GrowableOresItems.COPPER_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, GeneralBlocks.Reinforced_Glass,7)
                        .method_10434('P', class_2246.field_10033).method_10434('C', GrowableOresItems.ALLOY_PLATE)
                        .method_10439("PPP").method_10439("CPC").method_10439("PPP")
                        .method_10429("has_item", this.has(GrowableOresItems.ALLOY_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, GeneralBlocks.Reinforced_Stone,8)
                        .method_10434('P', class_2246.field_10340)
                        .method_10434('C', GrowableOresItems.ALLOY_PLATE)
                        .method_10439("PPP").method_10439("PCP").method_10439("PPP")
                        .method_10429("has_item", this.has(GrowableOresItems.ALLOY_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, GeneralBlocks.Reinforced_DOOR)
                        .method_10434('P', GrowableOresItems.IRON_PLATE)
                        .method_10434('C', GrowableOresItems.LEAD_PLATE)
                        .method_10439("PCP").method_10439("PCP").method_10439("PCP")
                        .method_10429("has_item", this.has(GrowableOresItems.LEAD_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresItems.RAW_PATTERN_STORAGE_CRYSTAL)
                        .method_10434('I', GrowableOresItems.SILICON_DIOXIDE_DUST)
                        .method_10434('E', GrowableOresItems.OBSIDIAN_DUST)
                        .method_10439("IEI").method_10439("EIE").method_10439("IEI")
                        .method_10429("has_item", this.has(GrowableOresItems.SILICON_DIOXIDE_DUST))
                        .method_10431(this.output);

                oreSmelting(List.of(GrowableOresItems.RAW_PATTERN_STORAGE_CRYSTAL), class_7800.field_40642, class_7709.field_40244, GrowableOresItems.PATTERN_STORAGE_CRYSTAL, 0.45F, 300, "pattern_storage_crystal");

                shaped(class_7800.field_40634, GeneralBlocks.PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', class_2246.field_10102)
                        .method_10434('i', class_2246.field_41072)
                        .method_10429(method_32807(class_2246.field_10102),
                                has(class_2246.field_10102))
                        .method_10429(method_32807(class_2246.field_41072),
                                has(class_2246.field_41072))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.GREEN_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8408)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8408),
                                has(class_1802.field_8408))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.ORANGE_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8492)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8492),
                                has(class_1802.field_8492))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.MAGENTA_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8669)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8669),
                                has(class_1802.field_8669))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.LIGHT_BLUE_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8273)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8273),
                                has(class_1802.field_8273))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.YELLOW_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8192)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8192),
                                has(class_1802.field_8192))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.LIME_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8131)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8131),
                                has(class_1802.field_8131))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.PINK_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8330)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8330),
                                has(class_1802.field_8330))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.GRAY_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8298)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8298),
                                has(class_1802.field_8298))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.LIGHT_GRAY_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8851)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8851),
                                has(class_1802.field_8851))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.CYAN_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8632)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8632),
                                has(class_1802.field_8632))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.PURPLE_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8296)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8296),
                                has(class_1802.field_8296))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.BLUE_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8345)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8345),
                                has(class_1802.field_8345))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.BROWN_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8099)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8099),
                                has(class_1802.field_8099))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.RED_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                        .method_10434('b', GeneralBlocks.PLASTER)
                        .method_10434('i', class_1802.field_8408)
                        .method_10429(method_32807(GeneralBlocks.PLASTER),
                                has(GeneralBlocks.PLASTER))
                        .method_10429(method_32807(class_1802.field_8264),
                                has(class_1802.field_8264))
                        .method_10431(output);

                shaped(class_7800.field_40634 ,GeneralBlocks.COBBLESTONE_STAIRS,6)
                        .method_10439("b  ")
                        .method_10439("bi ")
                        .method_10439("bbb")
                        .method_10434('b', class_2246.field_10445)
                        .method_10434('i', class_1802.field_8345)
                        .method_10429(method_32807(class_1802.field_8345),
                                has(class_1802.field_8345))
                        .method_10431(output);

            }
        };
    }

    @Override
    public String method_10321() {
        return "Material";
    }
}