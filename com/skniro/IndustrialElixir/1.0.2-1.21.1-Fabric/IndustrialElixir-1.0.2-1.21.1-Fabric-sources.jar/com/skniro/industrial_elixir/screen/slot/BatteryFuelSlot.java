package com.skniro.industrial_elixir.screen.slot;

import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.api.item.TieredEnergyItem;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class BatteryFuelSlot extends class_1735 {
    private final EnergyTier energyTier;
    public BatteryFuelSlot(class_1263 inventory, int index, int x, int y, EnergyTier energyTier) {
        super(inventory, index, x, y);
        this.energyTier = energyTier;
    }

    public boolean method_7680(class_1799 stack) {
        if (stack.method_7909() instanceof TieredEnergyItem tiered) {return tiered.getEnergyTier().ordinal() <= this.energyTier.ordinal();
        }
        return false;
    }

    public int method_7676(class_1799 stack) {
        return isBucket(stack) ? 1 : super.method_7676(stack);
    }

    public static boolean isBucket(class_1799 stack) {
        return stack.method_31574(class_1802.field_8550);
    }
}
