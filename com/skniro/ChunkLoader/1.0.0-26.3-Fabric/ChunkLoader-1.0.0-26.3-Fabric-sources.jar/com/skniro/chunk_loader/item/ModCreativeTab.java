package com.skniro.chunk_loader.item;

import com.skniro.chunk_loader.SkniroChunkLoader;
import com.skniro.chunk_loader.block.GrowableOresBlocks;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

public class ModCreativeTab {
    public static final ResourceKey<CreativeModeTab> Machine = ResourceKey.create(Registries.CREATIVE_MODE_TAB, Identifier.fromNamespaceAndPath(SkniroChunkLoader.MOD_ID, "machine"));
    public static void CreativeTab() {
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, Machine, FabricCreativeModeTab.builder()
                .icon(() -> new ItemStack(GrowableOresBlocks.CHUNK_LOADER.asItem()))
                .title(Component.translatable("itemGroup.chunk_loader.machine"))
                .build()); // build() no longer registers by itself

    }

    public static void CreativeTabItem() {
        CreativeModeTabEvents.modifyOutputEvent(Machine).register(content -> {
            content.accept(GrowableOresBlocks.CHUNK_LOADER);
        });
    }
}
