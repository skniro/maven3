package com.skniro.skniro_furniture.block.entity;

import com.skniro.skniro_furniture.block.init.AbstractWallCabinetBlock;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2382;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2624;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5561;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public abstract class AbstractFurnitureContainerBlockEntity extends class_2624 {
    private final class_5561 stateManager;
    public class_2371<class_1799> inventory;

    protected AbstractFurnitureContainerBlockEntity(class_2591<?> blockEntityType, class_2338 blockPos, class_2680 blockState, int size) {
        super(blockEntityType, blockPos, blockState);
        this.inventory = class_2371.method_10213(size, class_1799.field_8037);
        this.stateManager = new class_5561() {
            protected void method_31681(class_1937 world, class_2338 pos, class_2680 state) {
                AbstractFurnitureContainerBlockEntity.this.playSound(state, class_3417.field_17604);
            }

            protected void method_31683(class_1937 world, class_2338 pos, class_2680 state) {
                AbstractFurnitureContainerBlockEntity.this.playSound(state, class_3417.field_17603);
            }

            protected void method_31682(class_1937 world, class_2338 pos, class_2680 state, int oldViewerCount, int newViewerCount) {
            }

            public boolean method_31679(class_1657 player) {
                if (player.field_7512 instanceof class_1707) {
                    class_1263 inventory = ((class_1707) player.field_7512).method_7629();
                    return inventory == AbstractFurnitureContainerBlockEntity.this;
                } else {
                    return false;
                }
            }
        };
    }

    void playSound(class_2680 state, class_3414 soundEvent) {
        class_2382 vec3i = ((class_2350) state.method_11654(AbstractWallCabinetBlock.FACING)).method_62675();
        double d = (double) this.field_11867.method_10263() + 0.5 + (double) vec3i.method_10263() / 2.0;
        double e = (double) this.field_11867.method_10264() + 0.5 + (double) vec3i.method_10264() / 2.0;
        double f = (double) this.field_11867.method_10260() + 0.5 + (double) vec3i.method_10260() / 2.0;
        this.field_11863.method_43128((class_1657) null, d, e, f, soundEvent, class_3419.field_15245, 0.5F, this.field_11863.field_9229.method_43057() * 0.1F + 0.9F);
    }

    protected void method_11007(class_11372 nbt) {
        super.method_11007(nbt);
        class_1262.method_5426(nbt, this.inventory);
    }

    protected void method_11014(class_11368 nbt) {
        super.method_11014(nbt);
        this.inventory = class_2371.method_10213(this.method_5439(), class_1799.field_8037);
        class_1262.method_5429(nbt, this.inventory);

    }

    public int method_5439() {
        return inventory.size();
    }

    @Override
    public class_1799 method_5438(int slot) {
        return inventory.get(slot);
    }


    protected class_2371<class_1799> method_11282() {
        return this.inventory;
    }

    protected void method_11281(class_2371<class_1799> inventory) {
        this.inventory = inventory;
    }

    @Override
    protected class_2561 method_17823() {
        return null;
    }

    @Override
    protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return null;
    }

    public void onOpen(class_1657 player) {
        if (!this.field_11865 && !player.method_7325()) {
            this.stateManager.method_31684(player, this.method_10997(), this.method_11016(), this.method_11010(), player.method_72381());
        }

    }

    public void onClose(class_1657 player) {
        if (!this.field_11865 && !player.method_7325()) {
            this.stateManager.method_31685(player, this.method_10997(), this.method_11016(), this.method_11010());
        }

    }

    public void tick() {
        if (!this.field_11865) {
            this.stateManager.method_31686(this.method_10997(), this.method_11016(), this.method_11010());
        }

    }

    @Override
    public void method_5431() {
        field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        super.method_5431();
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }


    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}
