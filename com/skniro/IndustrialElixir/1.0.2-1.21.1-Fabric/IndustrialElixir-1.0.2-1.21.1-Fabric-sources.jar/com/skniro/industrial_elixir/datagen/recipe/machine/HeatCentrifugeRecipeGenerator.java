package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class HeatCentrifugeRecipeGenerator extends FabricRecipeProvider {
    public HeatCentrifugeRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                heatCentrifuge(GrowableOresItems.CRUSHED_COPPER, GrowableOresItems.COPPER_DUST, GrowableOresItems.SMALL_TIN_DUST, GrowableOresItems.STONE_DUST, "crushed_copper_to_purified_copper");
                heatCentrifuge(GrowableOresItems.CRUSHED_GOLD, GrowableOresItems.GOLD_DUST, GrowableOresItems.SMALL_SILVER_DUST, GrowableOresItems.STONE_DUST,"crushed_gold_to_purified_gold");
                heatCentrifuge(GrowableOresItems.CRUSHED_IRON, GrowableOresItems.IRON_DUST, GrowableOresItems.SMALL_GOLD_DUST, GrowableOresItems.STONE_DUST,"crushed_iron_to_purified_iron");
                heatCentrifuge(GrowableOresItems.CRUSHED_LEAD, GrowableOresItems.LEAD_DUST, GrowableOresItems.SMALL_COPPER_DUST, GrowableOresItems.STONE_DUST,"crushed_lead_to_purified_lead");
                heatCentrifuge(GrowableOresItems.CRUSHED_SILVER, GrowableOresItems.SILVER_DUST, GrowableOresItems.SMALL_SILVER_DUST,GrowableOresItems.STONE_DUST, "crushed_silver_to_purified_silver");
                heatCentrifuge(GrowableOresItems.CRUSHED_TIN, GrowableOresItems.TIN_DUST, GrowableOresItems.SMALL_IRON_DUST, GrowableOresItems.STONE_DUST,"crushed_tin_to_purified_tin");
                heatCentrifuge(GrowableOresItems.CRUSHED_SACRED, GrowableOresItems.IMPURE_SACRED_STONE, GrowableOresItems.STONE_DUST,null, "crushed_septrin_to_purified_septrin");
                heatCentrifuge(GrowableOresItems.PURIFIED_COPPER, GrowableOresItems.COPPER_DUST, GrowableOresItems.SMALL_TIN_DUST, GrowableOresItems.STONE_DUST, "purified_copper_to_purified_copper");
                heatCentrifuge(GrowableOresItems.PURIFIED_GOLD, GrowableOresItems.GOLD_DUST, GrowableOresItems.SMALL_SILVER_DUST, GrowableOresItems.STONE_DUST,"purified_gold_to_purified_gold");
                heatCentrifuge(GrowableOresItems.PURIFIED_IRON, GrowableOresItems.IRON_DUST, GrowableOresItems.SMALL_GOLD_DUST, GrowableOresItems.STONE_DUST,"purified_iron_to_purified_iron");
                heatCentrifuge(GrowableOresItems.PURIFIED_LEAD, GrowableOresItems.LEAD_DUST, GrowableOresItems.SMALL_COPPER_DUST, GrowableOresItems.STONE_DUST,"purified_lead_to_purified_lead");
                heatCentrifuge(GrowableOresItems.PURIFIED_SILVER, GrowableOresItems.SILVER_DUST, GrowableOresItems.SMALL_SILVER_DUST,GrowableOresItems.STONE_DUST, "purified_silver_to_purified_silver");
                heatCentrifuge(GrowableOresItems.PURIFIED_TIN, GrowableOresItems.TIN_DUST, GrowableOresItems.SMALL_IRON_DUST, GrowableOresItems.STONE_DUST,"purified_tin_to_purified_tin");
                heatCentrifuge(GrowableOresItems.PURIFIED_SACRED, GrowableOresItems.IMPURE_SACRED_STONE, GrowableOresItems.STONE_DUST,null, "purified_septrin_to_purified_septrin");
                createHeatCentrifuge(GrowableOresItems.COAL_DUST,5).input(GrowableOresItems.SLAG).output2(GrowableOresItems.SMALL_GOLD_DUST).method_36443(output, "slag_to_small_gold_dust");
                createHeatCentrifuge(GrowableOresItems.SILICON_DIOXIDE_DUST,5).input(GrowableOresItems.CLAY_DUST,4).method_36443(output, "clay_dust_to_silicon_dioxide_dust");
            }

            private void heatCentrifuge(class_1935 input, class_1935 primaryOutput, class_1792 secondaryOutput, class_1792 thirdOutput, String name) {
                var builder = createHeatCentrifuge(primaryOutput)
                        .input(input)
                        .method_33530("has_base_item", has(input));

                if (secondaryOutput != null) {
                    builder.output2(secondaryOutput);
                }

                if (thirdOutput != null) {
                    builder.output3(thirdOutput);
                }

                builder.method_36443(output, name);
            }
        };
    }

    @Override
    public String method_10321() {
        return "heatCentrifuge";
    }
}
