package torcherino_unofficial;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_11515;
import net.minecraft.class_11710;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import torcherino.Torcherino;
import torcherino.api.Tier;
import torcherino.api.TorcherinoAPI;
import torcherino.blocks.ModBlocks;
import torcherino_unofficial.block.CopperLanterinoBlock;
import torcherino_unofficial.block.WeatheringLanterinoBlock;
import torcherino_unofficial.block.api.LanterinoOxidizableRegistry;
import torcherino.block.entity.TorcherinoBlockEntity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

public final class UnofficialContent {
    public static final UnofficialContent INSTANCE = new UnofficialContent();
    Set<class_2248> allBlocks = new HashSet<>();
    public class_11710 copperLanterino;

    public void initialise() {
        Map<class_2960, Tier> tiers = TorcherinoAPI.INSTANCE.getTiers();
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> allBlocks.forEach((entries::method_45421)));
        tiers.forEach((tierId, tier) -> {
            if (!tierId.method_12836().equals(Torcherino.MOD_ID)) {
                return;
            }
            class_2960 copperlanterinoId = id(tierId, "copper_lantern");
            this.copperLanterino = class_11710.method_73123(
                    copperlanterinoId.method_12832(),
                    this::register,
                    (props) -> new CopperLanterinoBlock(props, tierId),
                    (state, props) -> new WeatheringLanterinoBlock(state, props, tierId),
                    (weatherState) -> class_4970.class_2251.method_9637()
                                                               .method_31710(class_3620.field_16005)
                                                               .method_51369()
                                                               .method_9632(3.5F)
                                                               .method_9626(class_2498.field_17734)
                                                               .method_9631(state -> 15)
                                                               .method_22488()
                                                               .method_50012(class_3619.field_15975)
                                                               .method_9640()
            );
            LanterinoOxidizableRegistry.registerWeatheringSet(copperLanterino);
            if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
                copperLanterino.method_73125(this::setRenderType);
            }
            copperLanterino.method_73125(block -> {
                class_2960 itemId = class_7923.field_41175.method_10221(block);
                class_1747 item = new class_1747(block, new class_1792.class_1793()
                        .method_63685()
                        .method_63686(Torcherino.KeyofItem(itemId.method_12832())));
                class_2378.method_10230(class_7923.field_41178, itemId, item);
            });
        });
        class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(Torcherino.MOD_ID, "copper_lantern"),
                FabricBlockEntityTypeBuilder.create((pos, state) -> new TorcherinoBlockEntity(CopperLanterinoBlock.copperBlockEntityType(), pos, state), allBlocks.toArray(new class_2248[0])).build(null));
    }

    @Environment(EnvType.CLIENT)
    private void setRenderType(class_2248 block) {
        BlockRenderLayerMap.putBlock(block, class_11515.field_60925);
    }

    private class_2248 register(String id, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(Torcherino.KeyofBlock(id)));
        TorcherinoAPI.INSTANCE.blacklistBlock(block);
        allBlocks.add(block);
        return class_2378.method_39197(class_7923.field_41175, Torcherino.KeyofBlock(id), block);
    }

    private void registerAndBlacklist(class_2960 id, class_2248 block) {
        class_2378.method_10230(class_7923.field_41175, id, block);
        TorcherinoAPI.INSTANCE.blacklistBlock(id);
        allBlocks.add(block);
    }

    private class_2960 id(class_2960 tierID, String type) {
        if (tierID.method_12832().equals("normal")) {
            return class_2960.method_60655(Torcherino.MOD_ID, type);
        }
        return class_2960.method_60655(Torcherino.MOD_ID, tierID.method_12832() + '_' + type);
    }
}
