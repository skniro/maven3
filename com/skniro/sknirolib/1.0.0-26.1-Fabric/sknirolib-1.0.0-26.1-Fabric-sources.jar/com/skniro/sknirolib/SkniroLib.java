package com.skniro.sknirolib;

import com.skniro.sknirolib.impl.resource.conditions.ResourceConditionsImpl;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;




public class SkniroLib implements ModInitializer {
    public static final String MOD_ID = "sknirolib";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);



    @Override
    public void onInitialize() {
        ResourceConditionsImpl.onInitialize();
    }
}
