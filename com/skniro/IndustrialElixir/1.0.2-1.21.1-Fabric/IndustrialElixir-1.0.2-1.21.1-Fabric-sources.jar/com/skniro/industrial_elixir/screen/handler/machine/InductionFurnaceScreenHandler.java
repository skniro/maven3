package com.skniro.industrial_elixir.screen.handler.machine;

import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.entity.machine.InductionFurnaceEntity;
import com.skniro.industrial_elixir.screen.AlchemyScreenHandlerType;
import com.skniro.industrial_elixir.screen.slot.BatteryFuelSlot;
import com.skniro.industrial_elixir.screen.slot.UpgradeSlot;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1719;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3913;
import net.minecraft.class_3919;

public class InductionFurnaceScreenHandler extends class_1703 {
    final class_1263 inventory;
    final class_3913 propertyDelegate;
    public final InductionFurnaceEntity blockEntity;

    public InductionFurnaceScreenHandler(int syncId, class_1661 playerInventory, class_2338 pos) {
        this(syncId, playerInventory, playerInventory.field_7546.method_37908().method_8321(pos), new class_3919(3));
    }

    public InductionFurnaceScreenHandler(int syncId, class_1661 playerInventory, class_2586 blockEntity, class_3913 delegate) {
        super(AlchemyScreenHandlerType.InductionFurnace, syncId);
        method_17359((class_1263) blockEntity, 10);
        this.inventory = (class_1263) blockEntity;
        this.blockEntity = (InductionFurnaceEntity) blockEntity;
        this.propertyDelegate = delegate;

        this.method_7621(new class_1735(inventory, InductionFurnaceEntity.INPUT_SLOT_A, 37, 34));
        this.method_7621(new class_1735(inventory, InductionFurnaceEntity.INPUT_SLOT_B, 55, 34));
        this.method_7621(new class_1719(playerInventory.field_7546, inventory, InductionFurnaceEntity.OUTPUT_SLOT, 104, 35));
        this.method_7621(new BatteryFuelSlot(inventory, InductionFurnaceEntity.ENERGY_SLOT, 15, 52, blockEntity instanceof InductionFurnaceEntity ? this.blockEntity.getEnergyTier() : EnergyTier.TIER2));

        addUpgradeSlots();
        addPlayerInventory(playerInventory);
        addPlayerHotbar(playerInventory);
        method_17360(propertyDelegate);
    }

    private void addUpgradeSlots() {
        this.method_7621(new UpgradeSlot(inventory, 4, 151, 9));
        this.method_7621(new UpgradeSlot(inventory, 5, 151, 27));
        this.method_7621(new UpgradeSlot(inventory, 6, 151, 45));
        this.method_7621(new UpgradeSlot(inventory, 7, 151, 63));
    }

    public boolean isCrafting() {
        return propertyDelegate.method_17390(0) > 0;
    }

    public int getHeat() {
        return propertyDelegate.method_17390(2);
    }

    public int getScaledHeatWidth() {
        return getHeat() * 54 / 100;
    }

    public int getScaledEnergyHeight() {
        return blockEntity.getScaledEnergyHeight();
    }

    public int getScaledProgress() {
        int progress = propertyDelegate.method_17390(0);
        int maxProgress = propertyDelegate.method_17390(1);
        return maxProgress != 0 && progress != 0 ? progress * 21 / maxProgress : 0;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int invSlot) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(invSlot);
        if (slot != null && slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();
            if (invSlot < this.inventory.method_5439()) {
                if (!this.method_7616(originalStack, this.inventory.method_5439(), this.field_7761.size(), true)) {
                    return class_1799.field_8037;
                }
            } else if (!this.method_7616(originalStack, 0, this.inventory.method_5439(), false)) {
                return class_1799.field_8037;
            }

            if (originalStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }

        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return inventory.method_5443(player);
    }

    private void addPlayerInventory(class_1661 playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.method_7621(new class_1735(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }
    }

    private void addPlayerHotbar(class_1661 playerInventory) {
        for (int i = 0; i < 9; ++i) {
            this.method_7621(new class_1735(playerInventory, i, 8 + i * 18, 142));
        }
    }
}
