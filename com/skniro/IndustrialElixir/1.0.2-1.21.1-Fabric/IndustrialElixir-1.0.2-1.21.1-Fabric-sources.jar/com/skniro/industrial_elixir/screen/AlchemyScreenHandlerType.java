package com.skniro.industrial_elixir.screen;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.screen.handler.energybox.ChargePadScreenHandler;
import com.skniro.industrial_elixir.screen.handler.energybox.EnergyBoxScreenHandler;
import com.skniro.industrial_elixir.screen.handler.generator.heat.ElectricHeaterScreenHandler;
import com.skniro.industrial_elixir.screen.handler.generator.heat.SolidFuelHeaterScreenHandler;
import com.skniro.industrial_elixir.screen.handler.machine.*;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.BrewReactorScreenHandler;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.CoffeeMachineScreenHandler;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.MatterGeneratorScreenHandler;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.OreWashingScreenHandler;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.ReplicatorScreenHandler;
import com.skniro.industrial_elixir.screen.handler.container.fluid.FluidTankScreenHandler;
import com.skniro.industrial_elixir.screen.handler.generator.CoalGeneratorScreenHandler;
import com.skniro.industrial_elixir.screen.handler.generator.fluid.FluidGeneratorScreenHandler;
import com.skniro.industrial_elixir.screen.handler.generator.GeneratorSolarPanelScreenHandler;
import com.skniro.industrial_elixir.screen.handler.generator.GeneratorWindMillScreenHandler;
import com.skniro.industrial_elixir.screen.handler.generator.NuclearReactorScreenHandler;
import com.skniro.industrial_elixir.screen.handler.generator.SacredGeneratorScreenHandler;
import com.skniro.industrial_elixir.screen.handler.machine.heat.ModBlastFurnaceScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class AlchemyScreenHandlerType <T extends class_1703>{
    public static final class_3917<AlchemyBlockScreenHandler> ALCHEMY =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "cane_converter_screen_handler"),
                    new ExtendedScreenHandlerType<>(AlchemyBlockScreenHandler::new, class_2338.field_48404));

    public static final class_3917<CoalGeneratorScreenHandler> COAL_GENERATOR_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "coal_generator_screen_handler"),
                    new ExtendedScreenHandlerType<>(CoalGeneratorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<NuclearReactorScreenHandler> NuclearReactor =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "nuclear_reactor_screen_handler"),
                    new ExtendedScreenHandlerType<>(NuclearReactorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<SacredGeneratorScreenHandler> SACRED_GENERATOR =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "sacred_generator_screen_handler"),
                    new ExtendedScreenHandlerType<>(SacredGeneratorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<GeneratorWindMillScreenHandler> GENERATOR_Wind_Mill_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "generator_wind_mill_screen_handler"),
                    new ExtendedScreenHandlerType<>(GeneratorWindMillScreenHandler::new, class_2338.field_48404));

    public static final class_3917<GeneratorSolarPanelScreenHandler> GENERATOR_Solar_Panel_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "generator_solar_panel_screen_handler"),
                    new ExtendedScreenHandlerType<>(GeneratorSolarPanelScreenHandler::new, class_2338.field_48404));

    public static final class_3917<MaceratorScreenHandler> Macerator =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "macerator_screen_handler"),
                    new ExtendedScreenHandlerType<>(MaceratorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<CompressorScreenHandler> Compressor =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "compressor_screen_handler"),
                    new ExtendedScreenHandlerType<>(CompressorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<MetalFormerScreenHandler> MetalFormer =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "metal_former_screen_handler"),
                    new ExtendedScreenHandlerType<>(MetalFormerScreenHandler::new, class_2338.field_48404));

    public static final class_3917<EnergyBoxScreenHandler> EnergyBox =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "energy_box_screen_handler"),
                    new ExtendedScreenHandlerType<>(EnergyBoxScreenHandler::new, class_2338.field_48404));

    public static final class_3917<ChargePadScreenHandler> ChargePad =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "charge_pad_screen_handler"),
                    new ExtendedScreenHandlerType<>(ChargePadScreenHandler::new, class_2338.field_48404));

    public static final class_3917<MolecularTransformerScreenHandler> MolecularTransformer =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "molecular_transformer_screen_handler"),
                    new ExtendedScreenHandlerType<>(MolecularTransformerScreenHandler::new, class_2338.field_48404));

    public static final class_3917<ExtractorScreenHandler> Extractor =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "extractor_screen_handler"),
                    new ExtendedScreenHandlerType<>(ExtractorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<ElectricFurnaceScreenHandler> ElectricFurnace =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "electric_furnace_screen_handler"),
                    new ExtendedScreenHandlerType<>(ElectricFurnaceScreenHandler::new, class_2338.field_48404));

    public static final class_3917<InductionFurnaceScreenHandler> InductionFurnace =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "induction_furnace_screen_handler"),
                    new ExtendedScreenHandlerType<>(InductionFurnaceScreenHandler::new, class_2338.field_48404));

    public static final class_3917<HeatCentrifugeScreenHandler> HeatCentrifuge =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "heat_centrifuge_screen_handler"),
                    new ExtendedScreenHandlerType<>(HeatCentrifugeScreenHandler::new, class_2338.field_48404));

    public static final class_3917<RecyclerScreenHandler> Recycler =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "recycler_screen_handler"),
                    new ExtendedScreenHandlerType<>(RecyclerScreenHandler::new, class_2338.field_48404));

    public static final class_3917<CuttingScreenHandler> Cutting =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "cutting_screen_handler"),
                    new ExtendedScreenHandlerType<>(CuttingScreenHandler::new, class_2338.field_48404));

    public static final class_3917<BrewReactorScreenHandler> BrewReactor =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "brew_reactor_screen_handler"),
                    new ExtendedScreenHandlerType<>(BrewReactorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<OreWashingScreenHandler> OreWashing =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "ore_washing_screen_handler"),
                    new ExtendedScreenHandlerType<>(OreWashingScreenHandler::new, class_2338.field_48404));

    public static final class_3917<FluidTankScreenHandler> FluidTank =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "fluid_tank_screen_handler"),
                    new ExtendedScreenHandlerType<>(FluidTankScreenHandler::new, class_2338.field_48404));

    public static final class_3917<ElectricHeaterScreenHandler> ElectricHeater =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "electric_heater_screen_handler"),
                    new ExtendedScreenHandlerType<>(ElectricHeaterScreenHandler::new, class_2338.field_48404));

    public static final class_3917<SolidFuelHeaterScreenHandler> SolidFuelHeater =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "solid_fuel_heater_screen_handler"),
                    new ExtendedScreenHandlerType<>(SolidFuelHeaterScreenHandler::new, class_2338.field_48404));

    public static final class_3917<ModBlastFurnaceScreenHandler> ModBlastFurnace =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "mod_blast_furnace_screen_handler"),
                    new ExtendedScreenHandlerType<>(ModBlastFurnaceScreenHandler::new, class_2338.field_48404));

    public static final class_3917<MatterGeneratorScreenHandler> MatterGenerator =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "matter_generator_screen_handler"),
                    new ExtendedScreenHandlerType<>(MatterGeneratorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<PatternStorageScreenHandler> PatternStorage =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "pattern_storage_screen_handler"),
                    new ExtendedScreenHandlerType<>(PatternStorageScreenHandler::new, class_2338.field_48404));

    public static final class_3917<ReplicatorScreenHandler> Replicator =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "replicator_screen_handler"),
                    new ExtendedScreenHandlerType<>(ReplicatorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<FluidGeneratorScreenHandler> FluidGenerator =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "fluid_generator_screen_handler"),
                    new ExtendedScreenHandlerType<>(FluidGeneratorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<ChunkLoaderScreenHandler> ChunkLoader =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "chunk_loader_screen_handler"),
                    new ExtendedScreenHandlerType<>(ChunkLoaderScreenHandler::new, class_2338.field_48404));

    public static final class_3917<CoffeeMachineScreenHandler> CoffeeMachine =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "coffee_machine_screen_handler"),
                    new ExtendedScreenHandlerType<>(CoffeeMachineScreenHandler::new, class_2338.field_48404));

    public static final class_3917<CropFarmScreenHandler> CropFarm =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "crop_farm_screen_handler"),
                    new ExtendedScreenHandlerType<>(CropFarmScreenHandler::new, class_2338.field_48404));

    public static final class_3917<VendorMachineScreenHandler> VendorMachine =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(IndustrialElixir.MOD_ID, "vendor_machine_screen_handler"),
                    new ExtendedScreenHandlerType<>(VendorMachineScreenHandler::new, class_2338.field_48404));

    public static void registeralchemyscreenhandlertype() {

    }
}
