package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.material.Fluids;

import java.util.concurrent.CompletableFuture;

public class HeatCentrifugeRecipeGenerator extends FabricRecipeProvider {
    public HeatCentrifugeRecipeGenerator(FabricPackOutput output, CompletableFuture<HolderLookup.Provider> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected ModRecipeGenerator createRecipeProvider(HolderLookup.Provider wrapperLookup, RecipeOutput exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void buildRecipes() {
                heatCentrifuge(GrowableOresItems.CRUSHED_COPPER, GrowableOresItems.PURIFIED_COPPER, GrowableOresItems.SMALL_COPPER_DUST,null, "crushed_copper_to_purified_copper");
                heatCentrifuge(GrowableOresItems.CRUSHED_GOLD, GrowableOresItems.PURIFIED_GOLD, GrowableOresItems.SMALL_GOLD_DUST, null,"crushed_gold_to_purified_gold");
                heatCentrifuge(GrowableOresItems.CRUSHED_IRON, GrowableOresItems.PURIFIED_IRON, GrowableOresItems.SMALL_IRON_DUST, null,"crushed_iron_to_purified_iron");
                heatCentrifuge(GrowableOresItems.CRUSHED_LEAD, GrowableOresItems.PURIFIED_LEAD, GrowableOresItems.SMALL_LEAD_DUST, null,"crushed_lead_to_purified_lead");
                heatCentrifuge(GrowableOresItems.CRUSHED_SILVER, GrowableOresItems.PURIFIED_SILVER, GrowableOresItems.SMALL_SILVER_DUST,null, "crushed_silver_to_purified_silver");
                heatCentrifuge(GrowableOresItems.CRUSHED_TIN, GrowableOresItems.PURIFIED_TIN, GrowableOresItems.SMALL_TIN_DUST, null,"crushed_tin_to_purified_tin");
                heatCentrifuge(GrowableOresItems.CRUSHED_SEPTRIN, GrowableOresItems.PURIFIED_SEPTRIN, null,null, "crushed_septrin_to_purified_septrin");
            }

            private void heatCentrifuge(ItemLike input, ItemLike primaryOutput, Item secondaryOutput, Item thirdOutput, String name) {
                var builder = createHeatCentrifuge(primaryOutput)
                        .input(input)
                        .unlockedBy("has_base_item", has(input));

                if (secondaryOutput != null) {
                    builder.output2(secondaryOutput);
                }

                if (thirdOutput != null) {
                    builder.output3(thirdOutput);
                }

                builder.save(output, name);
            }
        };
    }

    @Override
    public String getName() {
        return "heatCentrifuge";
    }
}
