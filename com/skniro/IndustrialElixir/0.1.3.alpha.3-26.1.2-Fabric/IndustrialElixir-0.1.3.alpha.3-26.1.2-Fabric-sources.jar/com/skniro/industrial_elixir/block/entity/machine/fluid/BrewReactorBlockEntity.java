package com.skniro.industrial_elixir.block.entity.machine.fluid;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.fluid.BrewReactorBlock;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.BrewReactorScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.Containers;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jspecify.annotations.Nullable;

public class BrewReactorBlockEntity extends AbstractFluidMachineEntity {

    protected final ContainerData propertyDelegate;
    private int progress = 0;
    private int maxProgress = 72;

    private static final int ENERGY_CRAFT_AMOUNT = 25; // amount per TICK to craft




    public BrewReactorBlockEntity(BlockPos pos, BlockState blockState) {
        super(AlchemyBlockEntityType.Brew_Reactor_BLOCK_ENTITY, pos, blockState);
        this.propertyDelegate = new ContainerData() {
            @Override
            public int get(int dataId) {
                return switch (dataId) {
                    case 0 -> BrewReactorBlockEntity.this.progress;
                    case 1 -> BrewReactorBlockEntity.this.maxProgress;
                    default -> 0;
                };
            }

            @Override
            public void set(int dataId, int value) {
                switch (dataId) {
                    case 0: BrewReactorBlockEntity.this.progress = value;
                    case 1: BrewReactorBlockEntity.this.maxProgress = value;
                }
            }

            @Override
            public int getCount() {
                return 2;
            }
        };
    }

    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        output.putInt("brew_reactor.progress", progress);
        output.putInt("brew_reactor.max_progress", maxProgress);
        output.putLong("brew_reactor.energy", energyContainer.amount);

        ContainerHelper.saveAllItems(output, inventory);
        SingleVariantStorage.writeValue(fluidContainer, FluidVariant.CODEC, output);
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        progress = input.getIntOr("brew_reactor.progress", 0);
        maxProgress = input.getIntOr("brew_reactor.max_progress", 72);
        energyContainer.amount = input.getLongOr("brew_reactor.energy", 0);

        ContainerHelper.loadAllItems(input, inventory);
        SingleVariantStorage.readValue(fluidContainer, FluidVariant.CODEC, FluidVariant::blank, input);
    }

    public void drops() {
        Containers.dropContents(this.level, this.worldPosition, inventory);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable(FurnitureStrings.BrewReactor);
    }

    @Override
    public @Nullable AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new BrewReactorScreenHandler(containerId, inventory, this, this.propertyDelegate);
    }

    /* SIDED INVENTORY */
    @Override
    public boolean canPlaceItemThroughFace(int slot, ItemStack stack, @Nullable Direction side) {
        if (side == null || side == Direction.DOWN) return false;
        if (side == Direction.UP) return slot == INPUT_SLOT;

        if (slot != INPUT_SLOT && slot != FLUID_ITEM_SLOT && slot != ENERGY_ITEM_SLOT) {
            return false;
        }

        Direction localDir = this.level.getBlockState(this.getBlockPos()).getValue(BrewReactorBlock.FACING);
        return switch (slot) {
            case INPUT_SLOT -> side != localDir.getOpposite(); // If not Up/Down/Back, it must be Front/Left/Right
            case FLUID_ITEM_SLOT -> side == localDir.getClockWise(); // Left
            case ENERGY_ITEM_SLOT -> side == localDir.getCounterClockWise(); // Right
            default -> false; // Fallback
        };
    }

    @Override
    public boolean canTakeItemThroughFace(int slot, ItemStack stack, Direction side) {
        if (slot != OUTPUT_SLOT || side == Direction.UP) {
            return false;
        }

        if (side == Direction.DOWN) {
            return true;
        }

        Direction localDir = this.level.getBlockState(this.getBlockPos()).getValue(BrewReactorBlock.FACING);
        return side == localDir.getOpposite() || side == localDir.getClockWise();
    }

    @Override
    public RecipeType<?> getCurrentRecipeType() {
        return AlchemyRecipeType.BREW_REACTOR.type;
    }
}