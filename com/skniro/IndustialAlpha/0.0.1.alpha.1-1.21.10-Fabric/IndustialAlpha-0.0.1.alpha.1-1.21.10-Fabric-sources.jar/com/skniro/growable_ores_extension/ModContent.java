package com.skniro.growable_ores_extension;


import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.MapleSignBlocks;
import com.skniro.growable_ores_extension.block.NetherOresBlocks;
import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.block.init.CableBlock;
import com.skniro.growable_ores_extension.entity.MapleEntityType;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.item.ModCreativeTab;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import com.skniro.growable_ores_extension.screen.AlchemyScreenHandlerType;
import com.skniro.growable_ores_extension.world.ModOreGeneration;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import reborncore.common.powerSystem.RcEnergyTier;
import techreborn.init.TRContent;

import java.util.Locale;


public class ModContent {


    public static void registerItem() {
        GrowableOresItems.shield_item();
    }

    public static void registerBlock() {
        GrowableOresBlocks.registerGrowableOresBlocks();
        AlchemyRecipeType.registerRecipes();
        AlchemyBlockEntityType.registerMapleBlockEntityType();
        AlchemyScreenHandlerType.registeralchemyscreenhandlertype();
        NetherOresBlocks.registerNetherOresBlock();
        MapleSignBlocks.registerMapleSignBlocks();
    }

    public static void CreativeTab() {
        ModCreativeTab.CreativeTab();
        ModCreativeTab.CreativeTabItem();
    }

    public static void registerEntity() {
        MapleEntityType.registerMapleEntityType();
    }

    public static void WorldGen() {
        ModOreGeneration.generateOres();
    }


    public enum Cables {
        COPPER(128, 12.0F, true, RcEnergyTier.MEDIUM),
        TIN(32, 12.0F, true, RcEnergyTier.LOW),
        GOLD(512, 12.0F, true, RcEnergyTier.HIGH),
        HV(2048, 12.0F, true, RcEnergyTier.EXTREME),
        GLASSFIBER(8192, 12.0F, false, RcEnergyTier.INSANE),
        INSULATED_COPPER(128, 10.0F, false, RcEnergyTier.MEDIUM),
        INSULATED_GOLD(512, 10.0F, false, RcEnergyTier.HIGH),
        INSULATED_HV(2048, 10.0F, false, RcEnergyTier.EXTREME),
        SUPERCONDUCTOR(536870911, 10.0F, false, RcEnergyTier.INFINITE);

        public final String name;
        public final int transferRate;
        public final int defaultTransferRate;
        public final double cableThickness;
        public final boolean canKill;
        public final boolean defaultCanKill;
        public final RcEnergyTier tier;

        private CableBlock block;

        private Cables(int transferRate, double cableThickness, boolean canKill, RcEnergyTier tier) {
            this.name = this.toString().toLowerCase(Locale.ROOT);
            this.transferRate = transferRate;
            this.defaultTransferRate = transferRate;
            this.cableThickness = cableThickness / 2.0 / 16.0;
            this.canKill = canKill;
            this.defaultCanKill = canKill;
            this.tier = tier;
            this.block = (CableBlock) GrowableOresBlocks.Cable_Block;
        }

        public CableBlock getBlock() {
            if (this.block == null) {
                throw new IllegalStateException("Block for " + this.name + " not set yet!");
            }
            return this.block;
        }

        public class_1799 getStack() {
            return new class_1799(this.getBlock());
        }

        public class_1792 asItem() {
            return this.getBlock().method_8389();
        }
    }
}
