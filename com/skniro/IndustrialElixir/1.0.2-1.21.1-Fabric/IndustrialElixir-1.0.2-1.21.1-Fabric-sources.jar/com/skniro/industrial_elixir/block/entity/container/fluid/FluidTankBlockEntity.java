package com.skniro.industrial_elixir.block.entity.container.fluid;

import com.skniro.industrial_elixir.api.block.ImplementedInventory;
import com.skniro.industrial_elixir.api.fluid.ContainerInfo;
import com.skniro.industrial_elixir.api.fluid.FluidOutputMap;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.item.init.FluidCellItem;
import com.skniro.industrial_elixir.screen.handler.container.fluid.FluidTankScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.FullItemFluidStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.StoragePreconditions;
import net.fabricmc.fabric.api.transfer.v1.storage.base.CombinedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1262;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;

import static com.skniro.industrial_elixir.api.fluid.FluidOutputMap.FLUID_CONTAINERS;

public class FluidTankBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory {
    private static final long BUCKET_VOLUME_MB = FluidConstants.BUCKET / 81;
    private static final long TANK_CAPACITY_MB = BUCKET_VOLUME_MB * 16;
    protected static final int FLUID_ITEM_SLOT = 0;
    protected static final int EMPTY_FLUID_ITEM_SLOT = 8;
    protected static final int OUTPUT_EMPTY_FLUID_ITEM_SLOT = 9;
    protected static final int FLUID_ITEM_OUTPUT_SLOT = 10;
    private record FluidInput(FluidVariant fluid, class_1799 remainder) {}
    public final class_2371<class_1799> inventory = class_2371.method_10213(11, class_1799.field_8037);
    protected final class_3913 propertyDelegate;
    public SingleVariantStorage<FluidVariant> fluidContainer = new SingleVariantStorage<FluidVariant>() {
        @Override
        protected FluidVariant getBlankVariant() {
            return FluidVariant.blank();
        }

        @Override
        protected long getCapacity(FluidVariant variant) {
            return TANK_CAPACITY_MB;
        }

        @Override
        protected void onFinalCommit() {
            method_31663(field_11863, method_11016(), method_11010());
            method_10997().method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    };

    public FluidTankBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.FLUID_TANK_BLOCK_ENTITY, pos, state);
        this.propertyDelegate = new class_3913(){

            @Override
            public int method_17390(int dataId) {
                return 0;
            }

            @Override
            public void method_17391(int dataId, int value) {

            }

            @Override
            public int method_17389() {
                return 0;
            }
        };
    }

    public void tick(class_1937 level, class_2338 pos, class_2680 state) {
        if (level.method_8608()) {
            return;
        }

        boolean worked = false;

        if (hasFluidStackInFluidSlot()) {
            long amount = fluidContainer.getAmount();

            fillUpFluidTank();

            worked = amount != fluidContainer.getAmount();
        }

        if (!worked) {
            long amount = fluidContainer.getAmount();

            fillFluidContainer();

            worked = amount != fluidContainer.getAmount();
        }

        if (worked) {
            method_31663(level, pos, state);
        }
    }

    public float getFillRatio() {
        if (fluidContainer.amount <= 0) return 0.0f;
        return Math.min(1.0f, (float) fluidContainer.amount / (float) fluidContainer.getCapacity());
    }

    public FluidVariant getFluidVariant() {
        return fluidContainer.variant;
    }

    public long getAmount() {
        return fluidContainer.amount;
    }

    public class_1269 interactBucket(class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        // Fill tank from filled bucket
        if (stack.method_31574(class_1802.field_8705) || stack.method_31574(class_1802.field_8187)) {
            class_3611 fluid = stack.method_31574(class_1802.field_8705) ? class_3612.field_15910 : class_3612.field_15908;
            FluidVariant toInsert = FluidVariant.of(fluid);
            if (!fluidContainer.variant.isBlank() && !fluidContainer.variant.equals(toInsert)) {
                return class_1269.field_5811;
            }
            long inserted;
            try (Transaction tx = Transaction.openOuter()) {
                inserted = fluidContainer.insert(toInsert, BUCKET_VOLUME_MB, tx);
                if (inserted == BUCKET_VOLUME_MB) {
                    tx.commit();
                }
            }
            if (inserted == BUCKET_VOLUME_MB) {
                if (!player.method_7337()) {
                    player.method_6122(hand, new class_1799(class_1802.field_8550));
                }
                return class_1269.field_5812;
            }
            return class_1269.field_5811;
        }

        // Drain tank to empty bucket
        if (stack.method_31574(class_1802.field_8550) && fluidContainer.amount >= BUCKET_VOLUME_MB && !fluidContainer.variant.isBlank()) {
            class_1799 filled = new class_1799(fluidContainer.variant.getFluid().method_15774());
            if (filled.method_7960()) {
                return class_1269.field_5811;
            }
            long extracted;
            try (Transaction tx = Transaction.openOuter()) {
                extracted = fluidContainer.extract(fluidContainer.variant, BUCKET_VOLUME_MB, tx);
                if (extracted == BUCKET_VOLUME_MB) {
                    tx.commit();
                }
            }
            if (extracted == BUCKET_VOLUME_MB) {
                if (!player.method_7337()) {
                    stack.method_7934(1);
                    if (stack.method_7960()) {
                        player.method_6122(hand, filled);
                    } else if (!player.method_31548().method_7394(filled)) {
                        player.method_7328(filled, false);
                    }
                }
                return class_1269.field_5812;
            }
        }

        return class_1269.field_5811;
    }

    public boolean hasFluidStackInFluidSlot() {
        class_1799 inputStack = inventory.get(FLUID_ITEM_SLOT);
        if (getKnownFluidInput(inputStack) != null) {
            return true;
        }

        var itemStorage = FluidStorage.ITEM.find(inputStack, ContainerItemContext.withConstant(inputStack));
        return itemStorage != null
                && itemStorage.supportsExtraction()
                && itemStorage instanceof CombinedStorage<?, ?> combinedStorage
                && combinedStorage.parts.get(0) instanceof FullItemFluidStorage;
    }

    public void fillUpFluidTank() {
        class_1799 inputStack = inventory.get(FLUID_ITEM_SLOT);
        if (fillFromKnownContainer(inputStack)) {
            return;
        }

        var itemStorage = FluidStorage.ITEM.find(inputStack, ContainerItemContext.withConstant(inputStack));
        if (itemStorage == null || !itemStorage.supportsExtraction()
                || !(itemStorage instanceof CombinedStorage<?, ?> combinedStorage)
                || !(combinedStorage.parts.get(0) instanceof FullItemFluidStorage fluidStorage)) {
            return;
        }

        class_1799 craftRemainder = inputStack.method_7909() instanceof FluidCellItem
                ? new class_1799(GrowableOresItems.EMPTY_CELL)
                : (inputStack.method_7909().method_7857()
                   ? new class_1799(inputStack.method_7909().method_7858())
                   : new class_1799(class_1802.field_8550));

        if (!canAcceptFluid(fluidStorage) || !canStoreCraftRemainder(inputStack, craftRemainder)) {
            return;
        }

        try (Transaction transaction = Transaction.openOuter()) {
            long inserted = this.fluidContainer.insert(fluidStorage.getResource(), BUCKET_VOLUME_MB, transaction);
            if (inserted != BUCKET_VOLUME_MB) {
                return;
            }

            if (inputStack.method_7909() instanceof FluidCellItem) {
                inputStack.method_7934(1);
                storeCraftRemainder(craftRemainder);
            } else {
                inventory.set(FLUID_ITEM_SLOT, craftRemainder);
            }
            transaction.commit();
        }
    }

    private boolean fillFromKnownContainer(class_1799 inputStack) {
        FluidInput fluidInput = getKnownFluidInput(inputStack);
        if (fluidInput == null || !canAcceptFluid(fluidInput.fluid())) {
            return false;
        }

        if (inputStack.method_7909() instanceof FluidCellItem && !canStoreCraftRemainder(inputStack, fluidInput.remainder())) {
            return false;
        }

        try (Transaction transaction = Transaction.openOuter()) {
            long inserted = this.fluidContainer.insert(fluidInput.fluid(), BUCKET_VOLUME_MB, transaction);
            if (inserted != BUCKET_VOLUME_MB) {
                return false;
            }

            if (inputStack.method_7909() instanceof FluidCellItem) {
                inputStack.method_7934(1);
                storeCraftRemainder(fluidInput.remainder());
            } else {
                inventory.set(FLUID_ITEM_SLOT, fluidInput.remainder());
            }

            transaction.commit();
            return true;
        }
    }

    private FluidInput getKnownFluidInput(class_1799 stack) {
        if (stack.method_7960()) {
            return null;
        }

        for (Map.Entry<class_3611, List<ContainerInfo>> entry : FLUID_CONTAINERS.entrySet()) {
            for (ContainerInfo info : entry.getValue()) {
                if (stack.method_31574(info.fullItem())) {
                    return new FluidInput(FluidVariant.of(entry.getKey()), new class_1799(info.emptyItem()));
                }
            }
        }

        return null;
    }

    private boolean canAcceptFluid(FluidVariant fluid) {
        return (fluidContainer.getResource().equals(fluid) || fluidContainer.isResourceBlank())
                && fluidContainer.getAmount() + BUCKET_VOLUME_MB <= fluidContainer.getCapacity();
    }

    private boolean canAcceptFluid(FullItemFluidStorage fluidStorage) {
        return canAcceptFluid(fluidStorage.getResource());
    }


    private boolean canStoreCraftRemainder(class_1799 inputStack, class_1799 craftRemainder) {
        if (!(inputStack.method_7909() instanceof FluidCellItem)) {
            return true;
        }

        class_1799 remainderSlot = inventory.get(EMPTY_FLUID_ITEM_SLOT);
        return remainderSlot.method_7960()
                || (class_1799.method_31577(remainderSlot, craftRemainder)
                && remainderSlot.method_7947() + craftRemainder.method_7947() <= remainderSlot.method_7914());
    }

    private void storeCraftRemainder(class_1799 craftRemainder) {
        class_1799 remainderSlot = inventory.get(EMPTY_FLUID_ITEM_SLOT);
        if (remainderSlot.method_7960()) {
            inventory.set(EMPTY_FLUID_ITEM_SLOT, craftRemainder.method_7972());
        } else {
            remainderSlot.method_7933(craftRemainder.method_7947());
        }
    }

    public void fillFluidContainer() {
        if (fluidContainer.isResourceBlank() || fluidContainer.getAmount() < BUCKET_VOLUME_MB) {
            return;
        }

        class_3611 fluid = fluidContainer.getResource().getFluid();
        class_1799 emptyContainerStack = inventory.get(OUTPUT_EMPTY_FLUID_ITEM_SLOT);
        if (emptyContainerStack.method_7960()) {
            return;
        }

        ContainerInfo containerInfo = FluidOutputMap.getContainerInfo(fluid, emptyContainerStack.method_7909());

        if (containerInfo == null) {
            return;
        }

        class_1799 fullContainer = new class_1799(containerInfo.fullItem());

        if (!canStoreFilledContainer(fullContainer)) {
            return;
        }

        try (Transaction transaction = Transaction.openOuter()) {

            long extracted = fluidContainer.extract(
                    FluidVariant.of(fluid),
                    BUCKET_VOLUME_MB,
                    transaction
            );

            if (extracted != BUCKET_VOLUME_MB) {
                return;
            }

            emptyContainerStack.method_7934(1);
            storeFilledContainer(fullContainer);

            transaction.commit();
        }
    }

    private boolean canStoreFilledContainer(class_1799 stack) {
        class_1799 output = inventory.get(FLUID_ITEM_OUTPUT_SLOT);

        return output.method_7960()
                || (class_1799.method_31577(output, stack)
                && output.method_7947() + stack.method_7947() <= output.method_7914());
    }

    private void storeFilledContainer(class_1799 stack) {
        class_1799 output = inventory.get(FLUID_ITEM_OUTPUT_SLOT);

        if (output.method_7960()) {
            inventory.set(FLUID_ITEM_OUTPUT_SLOT, stack.method_7972());
        } else {
            output.method_7933(stack.method_7947());
        }
    }


    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        class_1262.method_5426(nbt, inventory, registries);
        nbt.method_10544("tank.amount", fluidContainer.amount);
        if (!fluidContainer.variant.isBlank()) {
            nbt.method_10569("tank.fluid_id", class_7923.field_41173.method_10206(fluidContainer.variant.getFluid()));
        } else {
            nbt.method_10569("tank.fluid_id", -1);
        }
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        class_1262.method_5429(nbt, inventory, registries);
        long amount = (nbt.method_10545("tank.amount") ? nbt.method_10537("tank.amount") : 0);
        int fluidId = (nbt.method_10545("tank.fluid_id") ? nbt.method_10550("tank.fluid_id") : -1);
        if (amount <= 0 || fluidId < 0) {
            fluidContainer.variant = FluidVariant.blank();
            fluidContainer.amount = 0;
            return;
        }
        fluidContainer.variant = FluidVariant.of(class_7923.field_41173.method_10200(fluidId));
        fluidContainer.amount = Math.min(amount, fluidContainer.getCapacity());
        StoragePreconditions.notBlankNotNegative(fluidContainer.variant, fluidContainer.amount);
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Fluid_Tank);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new FluidTankScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }
}
