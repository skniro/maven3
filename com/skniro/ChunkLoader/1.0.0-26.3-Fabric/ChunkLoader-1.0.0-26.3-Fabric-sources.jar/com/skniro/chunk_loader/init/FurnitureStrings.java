package com.skniro.chunk_loader.init;

public class FurnitureStrings {
    public static final String ChunkLoader = "gui.chunk_loader.chunk_loader";
}
