package com.skniro.maple.entity.projectile.thrown;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1545;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3966;

public class MapleGoldSnowballEntity extends MapleSnowballEntity {
    public MapleGoldSnowballEntity(class_1937 world, class_1309 owner, class_1799 stack) {
        super(world, owner, stack);
    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {
        super.method_7454(entityHitResult);
        class_1297 entity = entityHitResult.method_17782();
        int i = entity instanceof class_1545 ? 10 : 8;
        entity.method_64419(this.method_48923().method_48811(this, this.method_24921()), i);
    }
}
