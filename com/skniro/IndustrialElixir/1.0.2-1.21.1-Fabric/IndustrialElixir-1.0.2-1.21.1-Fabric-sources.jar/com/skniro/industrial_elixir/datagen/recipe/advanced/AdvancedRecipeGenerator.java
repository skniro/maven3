package com.skniro.industrial_elixir.datagen.recipe.advanced;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.item.AdvancedItems;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class AdvancedRecipeGenerator extends FabricRecipeProvider {
    public AdvancedRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                shapeless(class_7800.field_40642, AdvancedItems.LUMINITE)
                        .method_10449(AdvancedItems.LUMINITE_Part,9)
                        .method_10442("has_item", this.has(AdvancedItems.LUMINITE_Part)).method_10431(this.output);

                shaped(class_7800.field_40642, AdvancedItems.LUMINITE_ALLOY)
                        .method_10434('R', AdvancedItems.LUMINITE).method_10434('D', GrowableOresItems.IRIDIUM_PLATE)
                        .method_10439("DDD").method_10439("DRD").method_10439("DDD")
                        .method_10429("has_item_tags", this.has(GrowableOresItems.IRIDIUM_PLATE)).method_10431(this.output);

                 shaped(class_7800.field_40642, AdvancedItems.IRRADIANT_SACRED_INGOT)
                        .method_10434('R', class_1802.field_8601).method_10434('D', GrowableOresItems.SACRED_INGOT)
                        .method_10439(" R ").method_10439("RDR").method_10439(" R ")
                        .method_10429("has_item_tags", this.has(GrowableOresItems.SACRED_INGOT)).method_10431(this.output);

                shaped(class_7800.field_40642, AdvancedItems.ENRICHED_LUMINITE)
                        .method_10434('R', AdvancedItems.LUMINITE).method_10434('D', AdvancedItems.IRRADIANT_SACRED_INGOT)
                        .method_10439("DDD").method_10439("DRD").method_10439("DDD")
                        .method_10429("has_item_tags", this.has(AdvancedItems.IRRADIANT_SACRED_INGOT)).method_10431(this.output);

                shaped(class_7800.field_40642, AdvancedItems.ENRICHED_LUMINITE_ALLOY)
                        .method_10434('R', AdvancedItems.ENRICHED_LUMINITE).method_10434('D', AdvancedItems.LUMINITE_ALLOY)
                        .method_10439(" R ").method_10439("RDR").method_10439(" R ")
                        .method_10429("has_item_tags", this.has(GrowableOresItems.SACRED_INGOT)).method_10431(this.output);

                //TEM
                shaped(class_7800.field_40642, AdvancedItems.IRRADIANT_GLASS_PANE)
                        .method_10434('R', class_1802.field_8601).method_10434('D', AdvancedItems.IRRADIANT_SACRED_INGOT).method_10434('G', class_1802.field_8280)
                        .method_10439("GGG").method_10439("DRD").method_10439("GGG")
                        .method_10429("has_item_tags", this.has(AdvancedItems.IRRADIANT_SACRED_INGOT)).method_10431(this.output);

                shaped(class_7800.field_40642, AdvancedItems.IRIDIUM_AMETHYST_PLATE)
                        .method_10434('R', AdvancedItems.Iridium_INGOT).method_10434('D', GrowableOresItems.IRIDIUM_PLATE)
                        .method_10439("DDD").method_10439("DRD").method_10439("DDD")
                        .method_10429("has_item_tags", this.has(GrowableOresItems.IRIDIUM_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, AdvancedItems.REINFORCED_IRIDIUM_AMETHYST_PLATE)
                        .method_10434('R', AdvancedItems.IRIDIUM_AMETHYST_PLATE).method_10434('D', GrowableOresItems.CARBON_PLATE).method_10434('A', GrowableOresItems.ALLOY_PLATE)
                        .method_10439("ADA").method_10439("DRD").method_10439("ADA")
                        .method_10429("has_item_tags", this.has(GrowableOresItems.CARBON_PLATE)).method_10431(this.output);

                shaped(class_7800.field_40642, AdvancedItems.IRRADIANT_REINFORCED_PLATE)
                        .method_10434('R', AdvancedItems.REINFORCED_IRIDIUM_AMETHYST_PLATE).method_10434('P', AdvancedItems.LUMINITE_Part).method_10434('D', class_1802.field_8477).method_10434('A', class_1802.field_8725).method_10434('L', class_1802.field_8759)
                        .method_10439("APA").method_10439("LRL").method_10439("ADA")
                        .method_10429("has_item_tags", this.has(AdvancedItems.LUMINITE_Part)).method_10431(this.output);

                //TEM
                shaped(class_7800.field_40642, AdvancedItems.MT_Core)
                        .method_10434('R', AdvancedItems.IRRADIANT_GLASS_PANE).method_10434('P', GrowableOresItems.COPPER_PLATE)
                        .method_10439("RPR").method_10439("R R").method_10439("RPR")
                        .method_10429("has_item_tags", this.has(AdvancedItems.IRRADIANT_GLASS_PANE)).method_10431(this.output);

                shaped(class_7800.field_40642, AdvancedItems.Quantum_Core)
                        .method_10434('R', AdvancedItems.ENRICHED_LUMINITE_ALLOY).method_10434('P', class_1802.field_8137).method_10434('E', class_1802.field_8449)
                        .method_10439("RPR").method_10439("PEP").method_10439("RPR")
                        .method_10429("has_item_tags", this.has(class_1802.field_8137)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.MolecularTransformerBlock)
                        .method_10434('R', AdvancedItems.MT_Core).method_10434('P', GrowableOresItems.Advanced_Circuit).method_10434('A', GeneralBlocks.Advanced_Machine).method_10434('E', GrowableOresBlocks.EV_TRANSFORMER)
                        .method_10439("AEA").method_10439("PRP").method_10439("AEA")
                        .method_10429("has_item_tags", this.has(GrowableOresItems.Advanced_Circuit)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL)
                        .method_10434('R', AdvancedItems.IRRADIANT_GLASS_PANE).method_10434('P', GrowableOresItems.Advanced_Circuit).method_10434('A', GrowableOresBlocks.GENERATOR_SolarPanel).method_10434('E', AdvancedItems.IRRADIANT_REINFORCED_PLATE).method_10434('D', GrowableOresItems.ALLOY_PLATE)
                        .method_10439("RRR").method_10439("DAD").method_10439("PEP")
                        .method_10429("has_item_tags", this.has(GrowableOresItems.Advanced_Circuit)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL)
                        .method_10434('R', GrowableOresItems.CARBON_PLATE)
                        .method_10434('L', class_1802.field_8055)
                        .method_10434('P', GrowableOresItems.Advanced_Circuit)
                        .method_10434('A', GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL)
                        .method_10434('E', AdvancedItems.ENRICHED_LUMINITE)
                        .method_10434('D', GrowableOresItems.IRIDIUM_PLATE)
                        .method_10439("RLR").method_10439("DAD").method_10439("PEP")
                        .method_10429("has_item_tags", this.has(GrowableOresItems.Advanced_Circuit)).method_10431(this.output);

                shapeless(class_7800.field_40642, GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL, 8)
                        .method_10454(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL)
                        .method_10442("has_item", this.has(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL)).method_36443(this.output,"generator_ultimate_solar_panel_to_generator_hybrid_solar_panel");

                shaped(class_7800.field_40642, GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL)
                        .method_10434('L', class_1802.field_8055)
                        .method_10434('A', GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL)
                        .method_10434('E', AdvancedItems.ENRICHED_LUMINITE_ALLOY)
                        .method_10434('D', GrowableOresItems.COAL_CHUNK)
                        .method_10439(" L ").method_10439("DAD").method_10439("EDE")
                        .method_10429("has_item_tags", this.has(GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL)).method_10431(this.output);


                shaped(class_7800.field_40642, GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL)
                        .method_10434('A', GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL)
                        .method_10434('P', GrowableOresItems.Advanced_Circuit)
                        .method_10439("AAA").method_10439("APA").method_10439("AAA")
                        .method_10429("has_item_tags", this.has(GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL)).method_36443(this.output,"generator_hybrid_solar_panel_to_generator_ultimate_solar_panel");

                shaped(class_7800.field_40642, GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL)
                        .method_10434('A', GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL)
                        .method_10434('P', AdvancedItems.Quantum_Core)
                        .method_10439("AAA").method_10439("APA").method_10439("AAA")
                        .method_10429("has_item_tags", this.has(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL)).method_10431(this.output);

            }
        };
    }


    @Override
    public String method_10321() {
        return "Advanced";
    }
}