package com.skniro.maple.fluid;

import com.skniro.maple.particle.MapleParticleTypes;
import com.skniro.maple.world.gamerules.MapleGameRules;
import net.minecraft.class_1792;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.world.*;
import org.jetbrains.annotations.Nullable;

public class MapleHotSpringFluid extends class_3609 {
    @Override
    protected boolean method_15737(class_1937 world) {
        return world.method_8450().method_8355(MapleGameRules.HOT_SPRING_SOURCE_CONVERSION);
    }

    @Override
    protected void method_15730(class_1936 world, class_2338 pos, class_2680 state) {
        final class_2586 blockEntity = state.method_31709() ? world.method_8321(pos) : null;
        class_2248.method_9610(state, world, pos, blockEntity);
    }

    public void method_15776(class_1937 world, class_2338 pos, class_3610 state, class_5819 random) {
        if (!state.method_15771() && !(Boolean)state.method_11654(field_15902)) {
            if (random.method_43048(64) == 0) {
                world.method_8486((double)pos.method_10263() + 0.5, (double)pos.method_10264() + 0.5, (double)pos.method_10260() + 0.5, class_3417.field_15237, class_3419.field_15245, random.method_43057() * 0.25F + 0.75F, random.method_43057() + 0.5F, false);
            }
        } else if (random.method_43048(10) == 0) {
            world.method_8406(class_2398.field_11210, (double)pos.method_10263() + random.method_43058(), (double)pos.method_10264() + random.method_43058(), (double)pos.method_10260() + random.method_43058(), 0.0, 0.0, 0.0);
        }
        if (random.method_43057() < 0.07F) {
            world.method_8406(MapleParticleTypes.HOT_SPRING, (double) pos.method_10263() + random.method_43058(), (double) pos.method_10264() + random.method_43058(), (double) pos.method_10260() + random.method_43058(), 0.0, 0.03, 0.0);
        }
    }

    @Override
    protected int method_15733(class_4538 world) {
        return 4;
    }

    @Override
    protected int method_15739(class_4538 world) {
        return 1;
    }

    @Override
    public boolean method_15780(class_3611 fluid) {
        return fluid == method_15751() || fluid == method_15750();
    }

    @Override
    public int method_15779(class_3610 state) {
        return 0;
    }

    @Override
    public int method_15789(class_4538 world) {
        return 5;
    }

    @Override
    protected float method_15784() {
        return 100f;
    }

    @Nullable
    protected class_2394 method_15787() {
        return null;
    }

    @Override
    protected boolean method_15777(class_3610 state, class_1922 world, class_2338 pos, class_3611 fluid, class_2350 direction) {
        return false;
    }

    @Override
    public class_3611 method_15751() {
        return MapleFluids.STILL_Hot_Spring;
    }

    @Override
    public class_3611 method_15750() {
        return MapleFluids.FLOWING_Hot_Spring;
    }

    @Override
    public class_1792 method_15774() {
        return MapleFluidBlockOrItem.Hot_Spring_BUCKET;
    }

    @Override
    protected class_2680 method_15790(class_3610 state) {
        return MapleFluidBlockOrItem.Hot_Spring_BLOCK.method_9564().method_11657(class_2741.field_12538, method_15741(state));
    }

    @Override
    public boolean method_15793(class_3610 state) {
        return false;
    }

    public static class Flowing extends MapleHotSpringFluid {
        @Override
        protected void method_15775(class_2689.class_2690<class_3611, class_3610> builder) {
            super.method_15775(builder);
            builder.method_11667(field_15900);
        }

        @Override
        public int method_15779(class_3610 state) {
            return state.method_11654(field_15900);
        }

        @Override
        public boolean method_15793(class_3610 state) {
            return false;
        }
    }

    public static class Still extends MapleHotSpringFluid {
        @Override
        public int method_15779(class_3610 state) {
            return 8;
        }

        @Override
        public boolean method_15793(class_3610 state) {
            return true;
        }
    }
}
