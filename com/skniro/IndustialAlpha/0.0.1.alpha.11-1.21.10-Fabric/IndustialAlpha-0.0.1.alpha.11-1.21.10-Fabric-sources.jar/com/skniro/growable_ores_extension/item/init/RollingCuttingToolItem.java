package com.skniro.growable_ores_extension.item.init;

import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class RollingCuttingToolItem extends class_1792 {

    public RollingCuttingToolItem(class_1793 settings) {
        super(settings.method_7895(80));
    }

    @Override
    public class_1799 getRecipeRemainder(class_1799 stack) {
        class_1799 copy = stack.method_7972();
        copy.method_7974(copy.method_7919() + 1);

        if (copy.method_7919() >= copy.method_7936()) {
            return class_1799.field_8037;
        }

        return copy;
    }
}