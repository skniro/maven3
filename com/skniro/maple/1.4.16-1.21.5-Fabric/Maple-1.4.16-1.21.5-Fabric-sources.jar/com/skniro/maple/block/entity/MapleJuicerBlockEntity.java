package com.skniro.maple.block.entity;

import com.skniro.maple.recipe.MapleCraftingRecipeInput;
import com.skniro.maple.recipe.MapleJuicerCraftingRecipe;
import com.skniro.maple.recipe.MapleRecipeType;
import com.skniro.maple.screen.MapleJuicerBlockScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1262;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class MapleJuicerBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory, ImplementedInventory {
    private final class_2371<class_1799> inventory = class_2371.method_10213(4, class_1799.field_8037);
    private float rotation = 0;
    private static final int INPUT_SLOT = 0;
    private static final int Glass_SLOT = 1;
    private static final int OUTPUT_SLOT = 2;
    private static final int ENERGY_ITEM_SLOT = 3;

    protected final class_3913 propertyDelegate;
    private int progress = 0;
    private int maxProgress = 72;
    private final int DEFAULT_MAX_PROGRESS = 72;

    public MapleJuicerBlockEntity(class_2338 pos, class_2680 state) {
        super(MapleBlockEntityType.MAPLE_JUICER_BLOCK_ENTITY_BLOCK_ENTITY_TYPE, pos, state);
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> MapleJuicerBlockEntity.this.progress;
                    case 1 -> MapleJuicerBlockEntity.this.maxProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: MapleJuicerBlockEntity.this.progress = value;
                    case 1: MapleJuicerBlockEntity.this.maxProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };
    }

    public class_1799 getRenderStack() {
            return this.method_5438(INPUT_SLOT);
    }
    @Override
    public void method_5431() {
        field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        super.method_5431();
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471("gui.maple.maple_juicer");
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new MapleJuicerBlockScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registryLookup) {
        super.method_11007(nbt, registryLookup);
        class_1262.method_5426(nbt, inventory, registryLookup);
        nbt.method_10569("maple_juicer.progress", progress);
        nbt.method_10569("maple_juicer.max_progress", maxProgress);
    }

    @Override
    public void method_11014(class_2487 nbt, class_7225.class_7874 registryLookup) {
        class_1262.method_5429(nbt, inventory, registryLookup);
        progress = nbt.method_10550("maple_juicer.progress").orElse(0);
        maxProgress = nbt.method_10550("maple_juicer.max_progress").orElse(72);
        super.method_11014(nbt, registryLookup);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if(world.method_8608()) {
            return;
        }
        if(hasRecipe() && canInsertIntoOutputSlot()) {
            increaseCraftingProgress();
            method_31663(world, pos, state);

            if(hasCraftingFinished()) {
                craftItem();
                resetProgress();
            }
        } else {
            resetProgress();
        }
    }

    private void resetProgress() {
        this.progress = 0;
        this.maxProgress = DEFAULT_MAX_PROGRESS;
    }

    private void craftItem() {
        Optional<class_8786<MapleJuicerCraftingRecipe>> recipe = getCurrentRecipe();
        this.method_5434(INPUT_SLOT, 1);
        this.method_5434(Glass_SLOT, 1);
        this.method_5447(OUTPUT_SLOT, new class_1799(recipe.get().comp_1933().getResult(null).method_7909(),
                this.method_5438(OUTPUT_SLOT).method_7947() + recipe.get().comp_1933().getResult(null).method_7947()));
    }

    @Override
    public int[] method_5494(class_2350 direction) {
        return switch (direction){
            case field_11036 -> new int[]{INPUT_SLOT};
            case field_11033 -> new int[]{Glass_SLOT};
            default -> new int[]{OUTPUT_SLOT};
        };
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return slot != OUTPUT_SLOT;
    }

    private boolean hasCraftingFinished() {
        return this.progress >= this.maxProgress;
    }

    private void increaseCraftingProgress() {
        this.progress++;
    }

    private boolean canInsertIntoOutputSlot() {
        return this.method_5438(OUTPUT_SLOT).method_7960() ||
                this.method_5438(OUTPUT_SLOT).method_7947() < this.method_5438(OUTPUT_SLOT).method_7914();
    }

    private boolean hasRecipe() {
        Optional<class_8786<MapleJuicerCraftingRecipe>> recipe = getCurrentRecipe();
        if(recipe.isEmpty()) {
            return false;
        }

        class_1799 output = recipe.get().comp_1933().getResult(null);
        return recipe.isPresent() && canInsertAmountIntoOutputSlot(output.method_7947()) && canInsertItemIntoOutputSlot(output);
    }

    private Optional<class_8786<MapleJuicerCraftingRecipe>> getCurrentRecipe() {
        class_1277 inv = new class_1277(this.method_5439());
        for(int i = 0; i < this.method_5439(); i++) {
            inv.method_5447(i, this.method_5438(i));
        }
        return this.method_10997().method_8503().method_3772()
                .method_8132(MapleRecipeType.Maple_JUIER_TYPE, new MapleCraftingRecipeInput(inventory.get(INPUT_SLOT), inventory.get(Glass_SLOT)), this.method_10997());
    }

    private boolean canInsertItemIntoOutputSlot(class_1799 output) {
        return this.method_5438(OUTPUT_SLOT).method_7960() || this.method_5438(OUTPUT_SLOT).method_7909() == output.method_7909();
    }

    private boolean canInsertAmountIntoOutputSlot(int count) {
    int maxCount = this.method_5438(OUTPUT_SLOT).method_7960() ? 1 : this.method_5438(OUTPUT_SLOT).method_7914();
    int currentCount = this.method_5438(OUTPUT_SLOT).method_7947();

        return maxCount >= currentCount + count;
}

   @Nullable
   @Override
    public class_2596<class_2602> method_38235() {
    return class_2622.method_38585(this);
}


    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}
