package com.skniro.industrial_elixir.world.gen.trunk;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.block.init.LogCropBlock;
import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3746;
import net.minecraft.class_4643;
import net.minecraft.class_4647;
import net.minecraft.class_5140;
import net.minecraft.class_5142;
import net.minecraft.class_5819;
import net.minecraft.class_7923;

public class RubberTrunkPlacer extends class_5140 {
    public static final MapCodec<RubberTrunkPlacer> field_24971 = RecordCodecBuilder.mapCodec(instance ->
            instance.group(
                    Codec.intRange(0, 32).fieldOf("base_height").forGetter(p -> p.field_23760),
                    Codec.intRange(0, 24).fieldOf("height_rand_a").forGetter(p -> p.field_23761),
                    Codec.intRange(0, 24).fieldOf("height_rand_b").forGetter(p -> p.field_23762),
                    class_2680.field_24734.fieldOf("state").forGetter(p -> p.blockState),
                    Codec.FLOAT.fieldOf("extra_chance").forGetter(p -> p.extraChance)
            ).apply(instance, RubberTrunkPlacer::new));

    public static final class_5142<RubberTrunkPlacer> TYPE = new class_5142<>(field_24971);

    private final class_2680 blockState;
    private final float extraChance;

    public RubberTrunkPlacer(int baseHeight, int firstRandomHeight, int secondRandomHeight, class_2680 blockState, float extraChance) {
        super(baseHeight, firstRandomHeight, secondRandomHeight);
        this.blockState = blockState;
        this.extraChance = extraChance;
    }

    public static void registerTrunkPlacerType() {
        class_2378.method_10230(
                class_7923.field_41151,
                class_2960.method_60655(IndustrialElixir.MOD_ID, "rubber_trunk_placer"),
                TYPE);
    }

    @Override
    protected class_5142<?> method_28903() {
        return TYPE;
    }

    @Override
    public List<class_4647.class_5208> method_26991(class_3746 world, BiConsumer<class_2338, class_2680> replacer, class_5819 random, int height, class_2338 startPos, class_4643 config) {
        class_2680 rubberRubberState = blockState.method_11657(class_2465.field_11459, class_2350.class_2351.field_11052).method_11657(LogCropBlock.AGE, 2);
        class_2680 normalLogState = GeneralBlocks.Rubber_LOG.method_9564().method_11657(class_2465.field_11459, class_2350.class_2351.field_11052);

        // 确保每棵树有 1-2 个 rubber_rubber_log，但至少有一个
        int specialHeight = height > 0 ? random.method_43048(height) : 0;
        for (int i = 0; i < height; i++) {
            class_2338 pos = startPos.method_10086(i);
            replacer.accept(pos, i == specialHeight ? rubberRubberState : normalLogState);
        }

        // 有 extraChance 的概率额外放置第二个 rubber_rubber_log（总共不超过两个）
        if (height > 1 && random.method_43057() < extraChance) {
            int extraHeight = (specialHeight + 1 + random.method_43048(height - 1)) % height;
            replacer.accept(startPos.method_10086(extraHeight), rubberRubberState);
        }

        return List.of(new class_4647.class_5208(startPos.method_10086(height), 0, false));
    }
}
