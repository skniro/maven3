package com.skniro.growable_ores_extension.datagen.recipe;

import com.skniro.growable_ores_extension.datagen.recipe.machine.CompressorRecipeGenerator;
import com.skniro.growable_ores_extension.datagen.recipe.machine.MaceratorRecipeGenerator;
import com.skniro.growable_ores_extension.datagen.recipe.material.MaterialRecipeGenerator;
import com.skniro.growable_ores_extension.datagen.recipe.material.TreeBlockRecipeGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;

public class RecipeDataGeneration {

    public static void onInit(FabricDataGenerator fabricDataGenerator) {
        fabricDataGenerator.createPack().addProvider(MaterialRecipeGenerator::new);
        fabricDataGenerator.createPack().addProvider(CompressorRecipeGenerator::new);
        fabricDataGenerator.createPack().addProvider(MaceratorRecipeGenerator::new);
        fabricDataGenerator.createPack().addProvider(TreeBlockRecipeGenerator::new);
        fabricDataGenerator.createPack().addProvider(BaseMachineRecipeGenerator::new);
    }
}
