package com.skniro.industrial_elixir.api.data.model;


import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_2742;
import net.minecraft.class_2750;
import net.minecraft.class_2756;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4917;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4935;
import net.minecraft.class_4936;
import net.minecraft.class_4941;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.class_4946;


public class MapleModelDatagenHelper {
    private final class_4910 generator;

    public MapleModelDatagenHelper(class_4910 generator) {
        this.generator = generator;
    }

    private static class_4935 plainVariant(class_2960 modelLocation) {
        return class_4935.method_25824().method_25828(class_4936.field_22887, modelLocation);
    }

    public void registerModLogs(class_2248 block) {

        class_2960[] verticalModels = new class_2960[3];
        class_2960[] horizontalModels = new class_2960[3];

        for (int age = 0; age <= 2; age++) {

            class_4944 textures = new class_4944()
                    .method_25868(class_4945.field_23018, class_4944.method_25866(block, "_stage" + age))
                    .method_25868(class_4945.field_23013, class_4944.method_25866(block, "_top"))
                    .method_25868(class_4945.field_23012, class_4944.method_25866(block, "_stage" + age));

            verticalModels[age] = class_4943.field_22974.method_25847(
                    block,
                    "_stage" + age,
                    textures,
                    generator.field_22831
            );

            horizontalModels[age] = class_4943.field_22975.method_25847(
                    block,
                    "_stage" + age,
                    textures,
                    generator.field_22831
            );
        }

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4926.method_25784(class_2741.field_12556, class_2741.field_12496)
                                .method_25800((age, axis) -> {

                                    if (axis == class_2350.class_2351.field_11052) {
                                        return plainVariant(verticalModels[age]);
                                    }

                                    class_4935 variant = plainVariant(horizontalModels[age]);

                                    if (axis == class_2350.class_2351.field_11048) {
                                        return variant.method_25828(class_4936.field_22885, class_4936.class_4937.field_22891);
                                    }

                                    // Z
                                    return variant
                                            .method_25828(class_4936.field_22885, class_4936.class_4937.field_22891)
                                            .method_25828(class_4936.field_22886, class_4936.class_4937.field_22891);
                                })
                        )
        );

        generator.method_25623(block, verticalModels[0]);
    }


    public void registerBaseMachineBlock(class_2248 block, boolean hasActiveTexture) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_left"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_right"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_left"));
        }).method_25916(block, generator.field_22831);

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_25770(block, plainVariant(baseModel))
                            .method_25775(class_4910.method_25599())
            );
            return;
        }

        class_2960 litModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top_active"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom_active"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back_active"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_left_active"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_right_active"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_left"));
        }).method_25915(block, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerBaseMachineBlockSameSide(class_2248 cooker, class_4946.class_4947 modelFactory) {
        Map<class_4945, String> faceTextureSuffixes = Map.of(
                class_4945.field_23024, "_down",
                class_4945.field_23023, "_up",
                class_4945.field_23019, "_front",
                class_4945.field_23020, "_back",
                class_4945.field_23022, "_side",
                class_4945.field_23021, "_side"
        );

        class_2960 baseModel = modelFactory.get(cooker).method_25917(textures -> {
            faceTextureSuffixes.forEach((key, suffix) -> {
                textures.method_25868(key, class_4944.method_25866(cooker, suffix));
            });
        }).method_25916(cooker, generator.field_22831);

        class_2960 litModel = modelFactory.get(cooker).method_25917(textures -> {
            faceTextureSuffixes.forEach((key, suffix) -> {
                if (key == class_4945.field_23019) {
                    textures.method_25868(key, class_4944.method_25866(cooker, "_front_on"));
                } else {
                    textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                }
            });
        }).method_25915(cooker, "_on", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(cooker)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerBaseMachineBlockSameUpAndDown(class_2248 cooker, class_4946.class_4947 modelFactory) {
        Map<class_4945, String> faceTextureSuffixes = Map.of(
                class_4945.field_23024, "_side",
                class_4945.field_23023, "_side",
                class_4945.field_23019, "_front",
                class_4945.field_23020, "_back",
                class_4945.field_23022, "_left",
                class_4945.field_23021, "_right"
        );

        class_2960 baseModel = modelFactory.get(cooker).method_25917(textures -> {
            faceTextureSuffixes.forEach((key, suffix) -> {
                textures.method_25868(key, class_4944.method_25866(cooker, suffix));
            });
        }).method_25916(cooker, generator.field_22831);

        class_2960 litModel = modelFactory.get(cooker).method_25917(textures -> {
            faceTextureSuffixes.forEach((key, suffix) -> {
                if (key == class_4945.field_23019) {
                    textures.method_25868(key, class_4944.method_25866(cooker, "_front_on"));
                } else {
                    textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                }
            });
        }).method_25915(cooker, "_on", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(cooker)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerBaseMachineBlockSameUpDownSide(class_2248 cooker, class_4946.class_4947 modelFactory) {
        Map<class_4945, String> faceTextureSuffixes = Map.of(
                class_4945.field_23024, "_side",
                class_4945.field_23023, "_side",
                class_4945.field_23019, "_front",
                class_4945.field_23020, "_back",
                class_4945.field_23022, "_side",
                class_4945.field_23021, "_side"
        );

        class_2960 baseModel = modelFactory.get(cooker).method_25917(textures -> {
            faceTextureSuffixes.forEach((key, suffix) -> {
                textures.method_25868(key, class_4944.method_25866(cooker, suffix));
            });
        }).method_25916(cooker, generator.field_22831);

        class_2960 litModel = modelFactory.get(cooker).method_25917(textures -> {
            faceTextureSuffixes.forEach((key, suffix) -> {
                if (key == class_4945.field_23019) {
                    textures.method_25868(key, class_4944.method_25866(cooker, "_front_on"));
                } else {
                    textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                }
            });
        }).method_25915(cooker, "_on", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(cooker)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerBaseMachineBlockSameSideBack(class_2248 cooker, class_4946.class_4947 modelFactory) {
        Map<class_4945, String> faceTextureSuffixes = Map.of(
                class_4945.field_23024, "_bottom",
                class_4945.field_23023, "_top",
                class_4945.field_23019, "_front",
                class_4945.field_23020, "_leftrightback",
                class_4945.field_23022, "_leftrightback",
                class_4945.field_23021, "_leftrightback"
        );

        class_2960 baseModel = modelFactory.get(cooker).method_25917(textures -> {
            faceTextureSuffixes.forEach((key, suffix) -> {
                textures.method_25868(key, class_4944.method_25866(cooker, suffix));
            });
        }).method_25916(cooker, generator.field_22831);

        class_2960 litModel = modelFactory.get(cooker).method_25917(textures -> {
            faceTextureSuffixes.forEach((key, suffix) -> {
                if (key == class_4945.field_23019) {
                    textures.method_25868(key, class_4944.method_25866(cooker, "_front_active"));
                } else {
                    textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                }
            });
        }).method_25915(cooker, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(cooker)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerMachine(class_2248 block, boolean hasActiveTexture) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_top"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_25770(block, plainVariant(baseModel))
                            .method_25775(class_4910.method_25599())
            );
            return;
        }

        class_2960 litModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_top"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25915(block, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerMachineSameNorthSouth(class_2248 block, boolean hasActiveTexture) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_top"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_front"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_25770(block, plainVariant(baseModel))
                            .method_25775(class_4910.method_25599())
            );
            return;
        }

        class_2960 litModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_top"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_front_active"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25915(block, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerMachineSameSide(class_2248 block) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_side"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25770(block, plainVariant(baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }


    public void registerMachineDiffBottom(class_2248 block, boolean hasActiveTexture) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_25770(block, plainVariant(baseModel))
                            .method_25775(class_4910.method_25599())
            );
            return;
        }

        class_2960 litModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top_active"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25915(block, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerMachineExtractor(class_2248 block, boolean hasActiveTexture) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_25770(block, plainVariant(baseModel))
                            .method_25775(class_4910.method_25599())
            );
            return;
        }

        class_2960 litModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25915(block, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerMachineTransformer(class_2248 block, boolean hasActiveTexture) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_top"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_25770(block, plainVariant(baseModel))
                            .method_25775(class_4910.method_25599())
            );
            return;
        }

        class_2960 litModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top_active"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_top_active"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25915(block, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerMachineDiffBottomBack(class_2248 block, boolean hasActiveTexture) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_25770(block, plainVariant(baseModel))
                            .method_25775(class_4910.method_25599())
            );
            return;
        }

        class_2960 litModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top_active"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25915(block, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }


    public void registerMachineElectricHeater(class_2248 block, boolean hasActiveTexture) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_25770(block, plainVariant(baseModel))
                            .method_25775(class_4910.method_25599())
            );
            return;
        }

        class_2960 litModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top_active"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back_active"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25915(block, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerMachineBlastFurnace(class_2248 block, boolean hasActiveTexture) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_25770(block, plainVariant(baseModel))
                            .method_25775(class_4910.method_25599())
            );
            return;
        }

        class_2960 litModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top_active"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25915(block, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerMachineHeatCentrifuge(class_2248 block, boolean hasActiveTexture) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_25770(block, plainVariant(baseModel))
                            .method_25775(class_4910.method_25599())
            );
            return;
        }

        class_2960 litModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top_active"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25915(block, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerMachineSolidHeater(class_2248 block, boolean hasActiveTexture) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_25770(block, plainVariant(baseModel))
                            .method_25775(class_4910.method_25599())
            );
            return;
        }

        class_2960 litModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back_active"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25915(block, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerMachineChunkLoader(class_2248 block, boolean hasActiveTexture) {

        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_side"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_25770(block, plainVariant(baseModel))
                            .method_25775(class_4910.method_25599())
            );
            return;
        }

        class_2960 litModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_side_active"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side_active"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25915(block, "_active", generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25769(block)
                        .method_25775(class_4910.method_25565(class_2741.field_12548, litModel, baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }

    public void registerCable(class_2248 block) {
        class_2960 baseModel = ModTexturedModel.CUBE.get(block).method_25917(textures -> {
            textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
            textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_top"));

            textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

            textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
            textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
        }).method_25916(block, generator.field_22831);

        generator.field_22830.accept(
                class_4925.method_25770(block, plainVariant(baseModel))
                        .method_25775(class_4910.method_25599())
        );
    }


    public void registerModSweetBerryBush(class_1792 fruititem, class_2248 block) {
        generator.method_25537(fruititem);
        generator.field_22830.accept(class_4925.method_25769(block)
                .method_25775(class_4926.method_25783(class_2741.field_12497).method_25795(stage ->
                        plainVariant(generator.method_25557(block, "_stage" + stage, class_4943.field_22921, class_4944::method_25880)
                        )
                ))
        );
    }

    public void registerModBookshelf(class_2248 block, class_2248 plank) {
        class_4944 textureMap = class_4944.method_25870(class_4944.method_25860(block), class_4944.method_25860(plank));
        class_2960 model = class_4943.field_22974.method_25846(block, textureMap, generator.field_22831);
        generator.field_22830.accept(class_4910.method_25644(block, model));
    }

    public void registerLamp(class_2248 block) {
        class_2960 identifier = class_4941.method_25842(block);
        class_2960 identifier2 = class_4941.method_25843(block, "_on");
        generator.field_22830.accept(class_4925.method_25769(block)
                .method_25775(class_4910.method_25565(class_2741.field_12548, identifier2, identifier)));
    }

    public final void registerBlockState(class_2248 block) {
        generator.field_22830.accept(class_4925.method_25770(block, plainVariant(class_4941.method_25842(block))));
    }

    public void registerFridge(class_2248 block) {
        class_2960 bottomModel = class_4941.method_25843(block, "_bottom");
        class_2960 topModel = class_4941.method_25843(block, "_top");

        class_4926.class_4928<class_2350, class_2756> variantMap =
                class_4926.method_25784(class_2741.field_12481, class_2741.field_12533);

        fillSimpleDoubleVariantMap(variantMap, class_2756.field_12607, bottomModel);
        fillSimpleDoubleVariantMap(variantMap, class_2756.field_12609, topModel);

        generator.field_22830.accept(class_4925.method_25769(block).method_25775(variantMap));
    }


    public static class_4926.class_4928<class_2350, class_2756> fillSimpleDoubleVariantMap(
            class_4926.class_4928<class_2350, class_2756> variantMap,
            class_2756 targetHalf,
            class_2960 baseModelId
    ) {
        return variantMap
                .method_25797(class_2350.field_11043, targetHalf, plainVariant(baseModelId))
                .method_25797(class_2350.field_11034, targetHalf, plainVariant(baseModelId).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                .method_25797(class_2350.field_11035, targetHalf, plainVariant(baseModelId).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                .method_25797(class_2350.field_11039, targetHalf, plainVariant(baseModelId).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893));
    }

    public void registerPaperSlidingDoor(class_2248 doorBlock) {
        class_4935 bottomLeft = plainVariant(class_4941.method_25843(doorBlock, "_bottom_left"));
        class_4935 bottomLeftOpen = plainVariant(class_4941.method_25843(doorBlock, "_bottom_left_open"));
        class_4935 bottomRight = plainVariant(class_4941.method_25843(doorBlock, "_bottom_right"));
        class_4935 bottomRightOpen = plainVariant(class_4941.method_25843(doorBlock, "_bottom_right_open"));
        class_4935 topLeft = plainVariant(class_4941.method_25843(doorBlock, "_top_left"));
        class_4935 topLeftOpen = plainVariant(class_4941.method_25843(doorBlock, "_top_left_open"));
        class_4935 topRight = plainVariant(class_4941.method_25843(doorBlock, "_top_right"));
        class_4935 topRightOpen = plainVariant(class_4941.method_25843(doorBlock, "_top_right_open"));
        generator.field_22830.accept(createDoorBlockState(doorBlock, bottomLeft, bottomLeftOpen, bottomRight, bottomRightOpen, topLeft, topLeftOpen, topRight, topRightOpen));
    }

    public static class_4917 createDoorBlockState(class_2248 doorBlock, class_4935 bottomLeftClosedModel, class_4935 bottomLeftOpenModel, class_4935 bottomRightClosedModel, class_4935 bottomRightOpenModel, class_4935 topLeftClosedModel, class_4935 topLeftOpenModel, class_4935 topRightClosedModel, class_4935 topRightOpenModel) {
        return class_4925.method_25769(doorBlock)
                .method_25775(class_4926
                        .method_25786(class_2741.field_12481, class_2741.field_12533, class_2741.field_12520, class_2741.field_12537)
                        .method_25811(class_2350.field_11034, class_2756.field_12607, class_2750.field_12588, false, bottomLeftClosedModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12607, class_2750.field_12588, false, bottomLeftClosedModel)
                        .method_25811(class_2350.field_11039, class_2756.field_12607, class_2750.field_12588, false, bottomLeftClosedModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12607, class_2750.field_12588, false, bottomLeftClosedModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                        .method_25811(class_2350.field_11034, class_2756.field_12607, class_2750.field_12586, false, bottomRightClosedModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12607, class_2750.field_12586, false, bottomRightClosedModel)
                        .method_25811(class_2350.field_11039, class_2756.field_12607, class_2750.field_12586, false, bottomRightClosedModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12607, class_2750.field_12586, false, bottomRightClosedModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                        .method_25811(class_2350.field_11034, class_2756.field_12607, class_2750.field_12588, true, bottomLeftOpenModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12607, class_2750.field_12588, true, bottomLeftOpenModel)
                        .method_25811(class_2350.field_11039, class_2756.field_12607, class_2750.field_12588, true, bottomLeftOpenModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12607, class_2750.field_12588, true, bottomLeftOpenModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                        .method_25811(class_2350.field_11034, class_2756.field_12607, class_2750.field_12586, true, bottomRightOpenModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12607, class_2750.field_12586, true, bottomRightOpenModel)
                        .method_25811(class_2350.field_11039, class_2756.field_12607, class_2750.field_12586, true, bottomRightOpenModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12607, class_2750.field_12586, true, bottomRightOpenModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                        .method_25811(class_2350.field_11034, class_2756.field_12609, class_2750.field_12588, false, topLeftClosedModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12609, class_2750.field_12588, false, topLeftClosedModel)
                        .method_25811(class_2350.field_11039, class_2756.field_12609, class_2750.field_12588, false, topLeftClosedModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12609, class_2750.field_12588, false, topLeftClosedModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                        .method_25811(class_2350.field_11034, class_2756.field_12609, class_2750.field_12586, false, topRightClosedModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12609, class_2750.field_12586, false, topRightClosedModel)
                        .method_25811(class_2350.field_11039, class_2756.field_12609, class_2750.field_12586, false, topRightClosedModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12609, class_2750.field_12586, false, topRightClosedModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                        .method_25811(class_2350.field_11034, class_2756.field_12609, class_2750.field_12588, true, topLeftOpenModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12609, class_2750.field_12588, true, topLeftOpenModel)
                        .method_25811(class_2350.field_11039, class_2756.field_12609, class_2750.field_12588, true, topLeftOpenModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12609, class_2750.field_12588, true, topLeftOpenModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                        .method_25811(class_2350.field_11034, class_2756.field_12609, class_2750.field_12586, true, topRightOpenModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12609, class_2750.field_12586, true, topRightOpenModel)
                        .method_25811(class_2350.field_11039, class_2756.field_12609, class_2750.field_12586, true, topRightOpenModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12609, class_2750.field_12586, true, topRightOpenModel.method_25828(class_4936.field_22886, class_4936.class_4937.field_22892)));
    }


    public void registerTV(class_2248 block) {
        class_2960 identifier = class_4941.method_25842(block);
        class_2960 identifier2 = class_4941.method_25843(block, "_open");
        generator.field_22830.accept(class_4925.method_25769(block)
                .method_25775(class_4910.method_25565(class_2741.field_12548, identifier2, identifier))
                .method_25775(class_4910.method_25599()));
    }

    public static class_4926.class_4928<class_2350, class_2742> fillSimpleDoubleVariantMap(
            class_4926.class_4928<class_2350, class_2742> variantMap,
            class_2742 targetHalf,
            class_2960 baseModelId
    ) {
        return variantMap
                .method_25797(class_2350.field_11043, targetHalf, plainVariant(baseModelId))
                .method_25797(class_2350.field_11034, targetHalf, plainVariant(baseModelId).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                .method_25797(class_2350.field_11035, targetHalf, plainVariant(baseModelId).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                .method_25797(class_2350.field_11039, targetHalf, plainVariant(baseModelId).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893));
    }
}
