package com.skniro.maple.item.init.snowball;

import com.skniro.maple.entity.projectile.thrown.MapleInstantHealthSnowballEntity;
import com.skniro.maple.entity.projectile.thrown.MapleSnowballEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;

public class InstantHealthSnowballItem extends MapleSnowballItem {
    public InstantHealthSnowballItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 itemStack = user.method_5998(hand);
        world.method_43128(null, user.method_23317(), user.method_23318(), user.method_23321(), class_3417.field_14873, class_3419.field_15254, 0.5f, 0.4f / (world.method_8409().method_43057() * 0.4f + 0.8f));
        if (!world.field_9236) {
            MapleSnowballEntity snowballEntity = new MapleInstantHealthSnowballEntity(world, user);
            snowballEntity.method_16940(itemStack);
            snowballEntity.method_24919(user, user.method_36455(), user.method_36454(), 0.0f, 1.5f, 1.0f);
            world.method_8649(snowballEntity);
        }
        user.method_7259(class_3468.field_15372.method_14956(this));
        if (!user.method_31549().field_7477) {
            itemStack.method_7934(1);
        }
        return class_1271.method_29237(itemStack, world.method_8608());
    }
}
