package com.skniro.industrial_elixir.api.renderer.chunk;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class ChunkTextureCache {

    private static final Map<class_1923, class_2960> CACHE = new HashMap<>();

    private static final String TEXTURE_PREFIX =
            "chunk_map/";

    private ChunkTextureCache() {
    }


    /**
     * 获取 Chunk 的地图纹理
     */
    public static class_2960 getTexture(
            class_1937 level,
            class_1923 chunkPos
    ) {

        class_2960 cached = CACHE.get(chunkPos);

        if (cached != null) {
            return cached;
        }


        class_2960 textureId = createTexture(
                level,
                chunkPos
        );


        CACHE.put(
                chunkPos,
                textureId
        );


        return textureId;
    }



    /**
     * 创建并上传 GPU 纹理
     */
    private static class_2960 createTexture(
            class_1937 level,
            class_1923 chunkPos
    ) {

        class_310 minecraft = class_310.method_1551();

        class_1060 textureManager =
                minecraft.method_1531();


        class_1011 image =
                ChunkTextureGenerator.generate(
                        level,
                        chunkPos
                );


        class_2960 id = class_2960.method_60655(
                "industrialelixir",
                TEXTURE_PREFIX
                        + chunkPos.field_9181
                        + "_"
                        + chunkPos.field_9180
        );


        class_1043 texture = new class_1043(image);


        textureManager.method_4616(
                id,
                texture
        );


        return id;
    }



    /**
     * 删除一个 Chunk 的缓存
     */
    public static void invalidate(
            class_1923 pos
    ) {

        CACHE.remove(pos);
    }



    /**
     * 清空全部纹理
     *
     * GUI关闭或世界切换时调用
     */
    public static void clear() {

        class_310 minecraft =
                class_310.method_1551();


        class_1060 manager =
                minecraft.method_1531();


        for (class_2960 id : CACHE.values()) {

            manager.method_4615(id);
        }


        CACHE.clear();
    }
}