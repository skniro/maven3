package com.skniro.growable_ores_extension.datagen;

import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class GrowableItemTagGenerator extends FabricTagProvider.ItemTagProvider {
   public GrowableItemTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
   }
   @Override
   protected void method_10514(class_7225.class_7874 arg) {
      valueLookupBuilder(ModItemTags.BATTERY)
              .method_71554(GrowableOresItems.RE_BATTERY)
              .method_71554(GrowableOresItems.ADVANCED_RE_BATTERY)
              .method_71554(GrowableOresItems.ENERGY_CRYSTAL)
              .method_71554(GrowableOresItems.LAPOTRON_CRYSTAL);
      valueLookupBuilder(class_3489.field_15558)
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_LEAVES))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15528)
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_SAPLING))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_23212)
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_LOG))
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_Rubber_LOG))
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_WOOD))
              .method_71554(class_1792.method_7867(GeneralBlocks.STRIPPED_Rubber_LOG))
              .method_71554(class_1792.method_7867(GeneralBlocks.STRIPPED_Rubber_WOOD))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15555)
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_BUTTON))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15552)
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_DOOR))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15550)
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_TRAPDOOR))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15540)
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_PRESSURE_PLATE))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15534)
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_SLAB))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15557)
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_STAIRS))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15537)
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_PLANKS))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_16585)
              .method_71554(class_1792.method_7867(GeneralBlocks.Rubber_FENCE))
              .setReplace(false);
      valueLookupBuilder(ModItemTags.URANIUM_ORES)
              .method_71554(class_1792.method_7867(GeneralBlocks.Uranium_Ore))
              .method_71554(class_1792.method_7867(GeneralBlocks.Deepslate_Uranium_Ore))
              .setReplace(false);
      valueLookupBuilder(ModItemTags.TIN_ORES)
              .method_71554(class_1792.method_7867(GeneralBlocks.Tin_Ore))
              .method_71554(class_1792.method_7867(GeneralBlocks.Deepslate_Tin_Ore))
              .setReplace(false);
      valueLookupBuilder(ModItemTags.LEAD_ORES)
              .method_71554(class_1792.method_7867(GeneralBlocks.Lead_Ore))
              .method_71554(class_1792.method_7867(GeneralBlocks.Deepslate_Lead_Ore))
              .setReplace(false);
      valueLookupBuilder(ModItemTags.DUST_TIN)
              .method_71554(GrowableOresItems.TIN_DUST)
              .method_71554(GrowableOresItems.PURIFIED_TIN)
              .method_71554(GrowableOresItems.CRUSHED_TIN)
              .setReplace(false);
      valueLookupBuilder(ModItemTags.DUST_COPPER)
              .method_71554(GrowableOresItems.COPPER_DUST)
              .method_71554(GrowableOresItems.PURIFIED_COPPER)
              .method_71554(GrowableOresItems.CRUSHED_COPPER)
              .setReplace(false);
   }
}