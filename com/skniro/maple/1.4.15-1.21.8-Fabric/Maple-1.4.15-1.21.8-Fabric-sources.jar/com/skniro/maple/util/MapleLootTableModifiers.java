package com.skniro.maple.util;

import com.skniro.maple.item.MapleItems;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.class_141;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;

public class MapleLootTableModifiers {
    private static final class_2960 Grass_entities_ID
            = class_2960.method_60655("minecraft", "blocks/grass");


    public static void modifyLootTables() {
        LootTableEvents.MODIFY.register((id, tableBuilder, source) -> {
            if(Grass_entities_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.15f)) // Drops 35% of the time
                        .method_351(class_77.method_411(MapleItems.Rice))
                        .apply(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)).method_515());
                tableBuilder.pool(poolBuilder.method_355());
            }
        });
    }
}