package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1865;
import net.minecraft.class_1874;
import net.minecraft.class_1935;
import net.minecraft.class_2454;
import net.minecraft.class_3862;
import net.minecraft.class_3920;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import net.minecraft.world.item.crafting.*;
import java.util.concurrent.CompletableFuture;

public class MaceratorRecipeGenerator extends FabricRecipeProvider {
    public MaceratorRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {

                createMacerator(class_1802.field_8276, 2).input(class_1802.field_19044)
                        .method_33530("has_base_item", has(class_1802.field_19044)).method_10431(output);
                createMacerator(GrowableOresItems.COAL_DUST).input(class_1802.field_8713)
                        .method_33530("has_base_item", has(class_1802.field_8713)).method_10431(output);
                createMacerator(GrowableOresItems.COAL_DUST,9).input(class_1802.field_8797)
                        .method_33530("has_base_item", has(class_1802.field_8797)).method_36443(output,"coal_block_to_coal_dust");
                createMacerator(class_1802.field_8725,9).input(class_1802.field_8793)
                        .method_33530("has_base_item", has(class_1802.field_8793)).method_10431(output);

                createMacerator(class_1802.field_8145).input(class_1802.field_8110)
                        .method_33530("has_base_item", has(class_1802.field_8110)).method_10431(output);

                createMacerator(class_1802.field_8601, 9).input(class_1802.field_8801)
                        .method_33530("has_base_item", has(class_1802.field_8801)).method_10431(output);

                createMacerator(class_1802.field_8155, 4).input(class_1802.field_20402)
                        .method_33530("has_base_item", has(class_1802.field_20402)).method_10431(output);

                createMacerator(class_1802.field_8543, 1).input(class_1802.field_8426)
                        .method_33530("has_base_item", has(class_1802.field_8426)).method_10431(output);

                createMacerator(class_1802.field_8324, 4).input(class_1802.field_8606)
                        .method_33530("has_base_item", has(class_1802.field_8606)).method_10431(output);

                createMacerator(GrowableOresItems.CLAY_DUST, 2).input(class_1802.field_19060)
                        .method_33530("has_base_item", has(class_1802.field_19060)).method_10431(output);

                createMacerator(GrowableOresItems.IRON_DUST, 2).input(GrowableOresItems.STEEL_INGOT)
                        .method_33530("has_base_item", has(GrowableOresItems.STEEL_INGOT)).method_36443(output,"steel_ingot_to_iron_dust");

                createMacerator(class_1802.field_8858, 2).input(class_1802.field_20384)
                        .method_33530("has_base_item", has(class_1802.field_20384)).method_10431(output);

                createMacerator(class_1802.field_8858, 2).input(class_1802.field_20412)
                        .method_33530("has_base_item", has(class_1802.field_20391)).method_36443(output,"stone_to_sand");

                createMacerator(class_1802.field_20412, 2).input(class_1802.field_20391)
                        .method_33530("has_base_item", has(class_1802.field_20391)).method_10431(output);

                createMacerator(class_1802.field_8183, 5).input(class_1802.field_8894)
                        .method_33530("has_base_item", has(class_1802.field_8894)).method_10431(output);

       /*         createMacerator(GrowableOresItems.ENERGIUM_DUST, 2).input(Items.ENDER_EYE)
                        .criterion("has_base_item", conditionsFromItem(Items.SANDSTONE)).offerTo(exporter,"steel_ingot_to_iron_dust");
*/
                createMacerator(GrowableOresItems.CRUSHED_IRON,2).input(class_1802.field_33400)
                        .method_33530("has_base_item", has(class_1802.field_33400)).method_36443(output,"raw_iron_to_crushed_iron");
                createMacerator(GrowableOresItems.CRUSHED_IRON,2).input(ConventionalItemTags.IRON_ORES)
                        .method_33530("has_base_item", has(ConventionalItemTags.IRON_ORES)).method_10431(output);
                createMacerator(GrowableOresItems.IRON_DUST,9).input(GrowableOresItems.DENSE_IRON_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.DENSE_IRON_PLATE)).method_36443(output,"dense_iron_plate_to_iron_dust");
                createMacerator(GrowableOresItems.IRON_DUST).input(GrowableOresItems.IRON_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.IRON_PLATE)).method_36443(output,"iron_plate_to_iron_dust");
                createMacerator(GrowableOresItems.IRON_DUST).input(GrowableOresItems.PURIFIED_IRON)
                        .method_33530("has_base_item", has(GrowableOresItems.PURIFIED_IRON)).method_36443(output,"purified_iron_to_iron_dust");
                createMacerator(GrowableOresItems.IRON_DUST).input(GrowableOresItems.CRUSHED_IRON)
                        .method_33530("has_base_item", has(GrowableOresItems.CRUSHED_IRON)).method_36443(output,"crushed_iron_to_iron_dust");
                createMacerator(GrowableOresItems.IRON_DUST).input(class_1802.field_8620)
                        .method_33530("has_base_item", has(class_1802.field_8620)).method_36443(output,"iron_ingot_to_iron_dust");

                createMacerator(GrowableOresItems.CRUSHED_GOLD,2).input(class_1802.field_33402)
                        .method_33530("has_base_item", has(class_1802.field_33402)).method_36443(output,"raw_gold_to_crushed_gold");
                createMacerator(GrowableOresItems.CRUSHED_GOLD,2).input(ConventionalItemTags.GOLD_ORES)
                        .method_33530("has_base_item", has(ConventionalItemTags.GOLD_ORES)).method_10431(output);
                createMacerator(GrowableOresItems.GOLD_DUST,9).input(GrowableOresItems.DENSE_GOLD_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.DENSE_GOLD_PLATE)).method_36443(output,"dense_gold_plate_to_gold_dust");
                createMacerator(GrowableOresItems.GOLD_DUST).input(GrowableOresItems.GOLD_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.GOLD_PLATE)).method_36443(output,"gold_plate_to_gold_dust");
                createMacerator(GrowableOresItems.GOLD_DUST).input(GrowableOresItems.PURIFIED_GOLD)
                        .method_33530("has_base_item", has(GrowableOresItems.PURIFIED_GOLD)).method_36443(output,"purified_gold_to_gold_dust");
                createMacerator(GrowableOresItems.GOLD_DUST).input(GrowableOresItems.CRUSHED_GOLD)
                        .method_33530("has_base_item", has(GrowableOresItems.CRUSHED_GOLD)).method_36443(output,"crushed_gold_to_gold_dust");
                createMacerator(GrowableOresItems.GOLD_DUST).input(class_1802.field_8695)
                        .method_33530("has_base_item", has(class_1802.field_8695)).method_36443(output,"gold_ingot_to_gold_dust");

                createMacerator(GrowableOresItems.BRONZE_DUST,9).input(GrowableOresItems.DENSE_BRONZE_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.DENSE_BRONZE_PLATE)).method_36443(output,"dense_bronze_plate_to_bronze_dust");
                createMacerator(GrowableOresItems.BRONZE_DUST).input(GrowableOresItems.BRONZE_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.BRONZE_PLATE)).method_36443(output,"bronze_plate_to_bronze_dust");
                createMacerator(GrowableOresItems.BRONZE_DUST).input(GrowableOresItems.BRONZE_INGOT)
                        .method_33530("has_base_item", has(GrowableOresItems.BRONZE_INGOT)).method_36443(output,"bronze_ingot_to_bronze_dust");

                createMacerator(GrowableOresItems.DIAMOND_DUST).input(class_1802.field_8477)
                        .method_33530("has_base_item", has(class_1802.field_8477)).method_36443(output,"bronze_ingot_to_diamond_dust");

                createMacerator(GrowableOresItems.CRUSHED_COPPER,2).input(class_1802.field_33401)
                        .method_33530("has_base_item", has(class_1802.field_33401)).method_36443(output,"raw_copper_to_crushed_copper");
                createMacerator(GrowableOresItems.CRUSHED_COPPER,2).input(ConventionalItemTags.COPPER_ORES)
                        .method_33530("has_base_item", has(ConventionalItemTags.COPPER_ORES)).method_10431(output);
                createMacerator(GrowableOresItems.COPPER_DUST,9).input(GrowableOresItems.DENSE_COPPER_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.DENSE_COPPER_PLATE)).method_36443(output,"dense_copper_plate_to_copper_dust");
                createMacerator(GrowableOresItems.COPPER_DUST).input(GrowableOresItems.COPPER_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.COPPER_PLATE)).method_36443(output,"copper_plate_to_copper_dust");
                createMacerator(GrowableOresItems.COPPER_DUST).input(GrowableOresItems.PURIFIED_COPPER)
                        .method_33530("has_base_item", has(GrowableOresItems.PURIFIED_COPPER)).method_36443(output,"purified_copper_to_copper_dust");
                createMacerator(GrowableOresItems.COPPER_DUST).input(GrowableOresItems.CRUSHED_COPPER)
                        .method_33530("has_base_item", has(GrowableOresItems.CRUSHED_COPPER)).method_36443(output,"crushed_copper_to_copper_dust");
                createMacerator(GrowableOresItems.COPPER_DUST).input(class_1802.field_27022)
                        .method_33530("has_base_item", has(class_1802.field_27022)).method_36443(output,"copper_ingot_to_copper_dust");

                createMacerator(GrowableOresItems.CRUSHED_SACRED,2).input(GrowableOresItems.Raw_SACRED)
                        .method_33530("has_base_item", has(GrowableOresItems.Raw_SACRED)).method_36443(output,"raw_septrin_to_crushed_septrin");
                createMacerator(GrowableOresItems.CRUSHED_SACRED,2).input(ModItemTags.SACRED_ORES)
                        .method_33530("has_base_item", has(ModItemTags.SACRED_ORES)).method_10431(output);

                createMacerator(GrowableOresItems.CRUSHED_LEAD,2).input(GrowableOresItems.Raw_Lead)
                        .method_33530("has_base_item", has(GrowableOresItems.Raw_Lead)).method_36443(output,"raw_lead_to_crushed_lead");
                createMacerator(GrowableOresItems.CRUSHED_LEAD,2).input(ModItemTags.LEAD_ORES)
                        .method_33530("has_base_item", has(ModItemTags.LEAD_ORES)).method_10431(output);
                createMacerator(GrowableOresItems.LEAD_DUST,9).input(GrowableOresItems.DENSE_LEAD_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.DENSE_LEAD_PLATE)).method_36443(output,"dense_lead_plate_to_lead_dust");
                createMacerator(GrowableOresItems.LEAD_DUST).input(GrowableOresItems.LEAD_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.LEAD_PLATE)).method_36443(output,"lead_plate_to_lead_dust");
                createMacerator(GrowableOresItems.LEAD_DUST).input(GrowableOresItems.PURIFIED_LEAD)
                        .method_33530("has_base_item", has(GrowableOresItems.PURIFIED_LEAD)).method_36443(output,"purified_lead_to_lead_dust");
                createMacerator(GrowableOresItems.LEAD_DUST).input(GrowableOresItems.CRUSHED_LEAD)
                        .method_33530("has_base_item", has(GrowableOresItems.CRUSHED_LEAD)).method_36443(output,"crushed_lead_to_lead_dust");
                createMacerator(GrowableOresItems.LEAD_DUST).input(GrowableOresItems.LEAD_INGOT)
                        .method_33530("has_base_item", has(GrowableOresItems.LEAD_INGOT)).method_36443(output,"lead_ingot_to_lead_dust");

                createMacerator(GrowableOresItems.CRUSHED_TIN,2).input(GrowableOresItems.Raw_Tin)
                        .method_33530("has_base_item", has(GrowableOresItems.Raw_Tin)).method_36443(output,"raw_tin_to_crushed_tin");
                createMacerator(GrowableOresItems.CRUSHED_TIN,2).input(ModItemTags.TIN_ORES)
                        .method_33530("has_base_item", has(ModItemTags.TIN_ORES)).method_10431(output);
                createMacerator(GrowableOresItems.TIN_DUST,9).input(GrowableOresItems.DENSE_TIN_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.DENSE_TIN_PLATE)).method_36443(output,"dense_tin_plate_to_tin_dust");
                createMacerator(GrowableOresItems.TIN_DUST).input(GrowableOresItems.TIN_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.TIN_PLATE)).method_36443(output,"tin_plate_to_tin_dust");
                createMacerator(GrowableOresItems.TIN_DUST).input(GrowableOresItems.PURIFIED_TIN)
                        .method_33530("has_base_item", has(GrowableOresItems.PURIFIED_TIN)).method_36443(output,"purified_tin_to_tin_dust");
                createMacerator(GrowableOresItems.TIN_DUST).input(GrowableOresItems.CRUSHED_TIN)
                        .method_33530("has_base_item", has(GrowableOresItems.CRUSHED_TIN)).method_36443(output,"crushed_tin_to_tin_dust");
                createMacerator(GrowableOresItems.TIN_DUST).input(GrowableOresItems.TIN_INGOT)
                        .method_33530("has_base_item", has(GrowableOresItems.TIN_INGOT)).method_36443(output,"tin_ingot_to_tin_dust");

                createMacerator(GrowableOresItems.LAPIS_DUST).input(class_1802.field_8759)
                        .method_33530("has_base_item", has(class_1802.field_8759)).method_36443(output,"lapis_to_lapis_dust");
                createMacerator(GrowableOresItems.LAPIS_DUST, 9).input(class_1802.field_8055)
                        .method_33530("has_base_item", has(class_1802.field_8055)).method_36443(output,"lapis_block_to_lapis_dust");

                createMacerator(GrowableOresItems.OBSIDIAN_DUST).input(class_1802.field_8281)
                        .method_33530("has_base_item", has(class_1802.field_8281)).method_36443(output,"obsidian_to_obsidian_dust");
                createMacerator(GrowableOresItems.OBSIDIAN_DUST).input(GrowableOresItems.OBSIDIAN_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.OBSIDIAN_PLATE)).method_36443(output,"obsidian_plate_to_obsidian_dust");
                createMacerator(GrowableOresItems.OBSIDIAN_DUST,9).input(GrowableOresItems.DENSE_OBSIDIAN_PLATE)
                        .method_33530("has_base_item", has(GrowableOresItems.OBSIDIAN_PLATE)).method_36443(output,"dense_obsidian_plate_to_obsidian_dust");
                createMacerator(GrowableOresItems.IRIDIUM_SHARD,9).input(GrowableOresItems.IRIDIUM_ORE)
                        .method_33530("has_base_item", has(GrowableOresItems.IRIDIUM_ORE)).method_10431(output);
            }



            public void offerCampfireCooking(class_1935 inputs, class_1935 output, float experience, int cookingTime) {
                this.simpleCookingRecipe("campfire_cooking", class_1865.field_17347, class_3920::new, cookingTime, inputs, output, experience);
            }

            public void offerSmoking(class_1935 inputs, class_1935 output, float experience, int cookingTime) {
                this.simpleCookingRecipe("smoking", class_1865.field_17085, class_3862::new, cookingTime, inputs, output, experience);
            }

            public void offerSmoking(class_6862<class_1792> inputs, class_1935 output, float experience, int cookingTime) {
                this.simpleCookingRecipeTag("smoking", class_1865.field_17085, class_3862::new, cookingTime, inputs, output, experience);
            }

            public void offerCampfireCooking(class_6862<class_1792> inputs, class_1935 output, float experience, int cookingTime) {
                this.simpleCookingRecipeTag("campfire_cooking", class_1865.field_17347, class_3920::new, cookingTime, inputs, output, experience);
            }

            public <T extends class_1874> void simpleCookingRecipeTag(final String source, final class_1865<T> serializer, final class_1874.class_3958<T> factory, final int cookingTime, final class_6862<class_1792> baseTag, final class_1935 result, final float experience) {
                class_2454.method_17801(this.tag(baseTag), class_7800.field_40640, result, experience, cookingTime, serializer, factory).method_10469("has_" + baseTag.comp_327().method_12832(), this.has(baseTag)).method_36443(this.output, method_33716(result) + "_from_" + baseTag.comp_327().method_12832() + "_" + source);
            }

        };
    }

    @Override
    public String method_10321() {
        return "Macerator";
    }
}
