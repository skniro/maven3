package com.skniro.skniro_furniture.block.renderer;

import com.skniro.skniro_furniture.Furniture;
import com.skniro.skniro_furniture.block.entity.OvenBlockEntity;
import com.skniro.skniro_furniture.block.init.OvenBlock;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.client.render.*;
import net.minecraft.util.math.*;
import org.joml.Matrix4f;

public class OvenBlockEntityRenderer implements class_827<OvenBlockEntity> {

    private static final class_2960 LIGHT_TEXTURE = class_2960.method_43902(Furniture.MOD_ID, "textures/block/oven_light.png");

    public OvenBlockEntityRenderer(class_5614.class_5615 ctx) {}

    @Override
    public void render(OvenBlockEntity entity, float tickDelta, class_4587 matrices,
                       class_4597 vertexConsumers, int light, int overlay) {

        var state = entity.method_11010();
        var facing = state.method_11654(class_2741.field_12481);

        if (!(state.method_26204() instanceof OvenBlock)) return;
        matrices.method_22903();

        switch (facing) {
            case field_11043 -> matrices.method_22904(0.5, 0.4, 0.15);
            case field_11035 -> matrices.method_22904(0.5, 0.4, 0.85);
            case field_11039 -> matrices.method_22904(0.15, 0.4, 0.5);
            case field_11034 -> matrices.method_22904(0.85, 0.4, 0.5);
        }

        float angle = switch (facing) {
            case field_11043 -> 0f;
            case field_11035 -> 180f;
            case field_11039 -> 90f;
            case field_11034 -> -90f;
            default -> 0f;
        };

        matrices.method_22907(class_7833.field_40716.rotationDegrees(angle)); // 按 Y 轴旋转

        Matrix4f mat = matrices.method_23760().method_23761();

        if (state.method_11654(OvenBlock.field_11105)){
            class_4588 glowVc = vertexConsumers.getBuffer(class_1921.method_23026(LIGHT_TEXTURE));
            drawQuad(mat, glowVc, 0x80FFFF00, light);
        }

        class_1799 stack = entity.getRenderStack();
        if (!stack.method_7960()) {
            renderItemAsIcon(facing, stack, matrices, vertexConsumers, light, overlay);
        }
        matrices.method_22909();
    }

    private void drawQuad(Matrix4f mat, class_4588 vc, int color, int light) {
        vc.method_22918(mat, -0.3F,  0.21F, 0F)
                .method_39415(color)
                .method_22913(0F, 0F)
                .method_22922(class_4608.field_21444)
                .method_22916(light)
                .method_22914(0F, 0F, -1F);
        vc.method_22918(mat,  0.3F,  0.21F, 0F)
                .method_39415(color)
                .method_22913(1F, 0F)
                .method_22922(class_4608.field_21444)
                .method_22916(light)
                .method_22914(0F, 0F, -1F);
        vc.method_22918(mat,  0.3F, -0.21F, 0F)
                .method_39415(color)
                .method_22913(1F, 1F)
                .method_22922(class_4608.field_21444)
                .method_22916(light)
                .method_22914(0F, 0F, -1F);
        vc.method_22918(mat, -0.3F, -0.21F, 0F)
                .method_39415(color)
                .method_22913(0F, 1F)
                .method_22922(class_4608.field_21444)
                .method_22916(light)
                .method_22914(0F, 0F, -1F);
    }

    private void renderItemAsIcon(class_2350 direction, class_1799 stack, class_4587 matrices,
                                  class_4597 vertexConsumers, int light, int overlay) {

        matrices.method_22903();
        matrices.method_22905(0.4f, 0.4f, 0.4f);
        matrices.method_22904(0.0, 0.3, 0.3);

        class_310.method_1551().method_1480()
                .method_23178(stack, class_811.field_4317, light, overlay, matrices, vertexConsumers, null, 0);
        matrices.method_22909();
    }
}
