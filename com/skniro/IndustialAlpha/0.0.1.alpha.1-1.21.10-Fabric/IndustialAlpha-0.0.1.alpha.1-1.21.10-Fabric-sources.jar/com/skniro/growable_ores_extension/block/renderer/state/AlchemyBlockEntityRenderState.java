package com.skniro.growable_ores_extension.block.renderer.state;

import net.minecraft.class_10444;
import net.minecraft.class_11954;


public class AlchemyBlockEntityRenderState extends class_11954 {
    public final class_10444 item = new class_10444();
}