package com.skniro.maple.block;

import com.skniro.maple.Maple;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2431;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_6019;
import net.minecraft.class_7923;

public class MapleOreBlocks {
    public static final class_2248 Salt_Ore =registerBlock("salt_ore",new class_2431(class_6019.method_35017(3, 7), class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)),Maple.Maple_Group);
    public static final class_2248 DEEPSLATE_Salt_Ore =registerBlock("deepslate_salt_ore",new class_2431(class_6019.method_35017(3, 7), class_4970.class_2251.method_9630(Salt_Ore).method_31710(class_3620.field_33532).method_9629(4.5F, 3.0F).method_9626(class_2498.field_29033)),Maple.Maple_Group);

    private static class_2248 registerBlockWithoutItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(Maple.MOD_ID, name), block);
    }
    private static class_2248 registerBlock(String name, class_2248 block, class_5321<class_1761> tab) {
        registerBlockItem(name, block, tab);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(Maple.MOD_ID, name), block);
    }
    private static class_1792 registerBlockItem(String name, class_2248 block, class_5321<class_1761> tab) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(Maple.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
    }

    public static void registerMapleOreBlocks() {
        Maple.LOGGER.debug("Registering ModBlocks for " + Maple.MOD_ID);
    }
}
