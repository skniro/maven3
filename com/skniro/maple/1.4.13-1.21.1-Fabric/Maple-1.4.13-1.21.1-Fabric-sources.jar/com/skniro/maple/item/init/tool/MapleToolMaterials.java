package com.skniro.maple.item.init.tool;


import com.google.common.base.Suppliers;
import com.skniro.maple.item.MapleArmorItems;
import java.util.function.Supplier;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_6862;

public enum MapleToolMaterials implements class_1832 {
    Cherry(class_3481.field_49925,3, 3231, 12.0F, 3.0F, 22, () -> {
        return class_1856.method_8091(new class_1935[]{MapleArmorItems.Cherry_INGOT});
    });

    private final class_6862<class_2248> inverseTag;
    private final int itemDurability;
    private final float miningSpeed;
    private final float attackDamage;
    private final int enchantability;
    private final Supplier<class_1856> repairIngredient;

    private MapleToolMaterials(class_6862<class_2248> inverseTag, int miningLevel, int itemDurability, float miningSpeed, float attackDamage, int enchantability, Supplier<class_1856> repairIngredient) {
        this.inverseTag = inverseTag;
        this.itemDurability = itemDurability;
        this.miningSpeed = miningSpeed;
        this.attackDamage = attackDamage;
        this.enchantability = enchantability;
        this.repairIngredient = Suppliers.memoize(repairIngredient::get);
    }

    @Override
    public int method_8025() {
        return this.itemDurability;
    }

    @Override
    public float method_8027() {
        return this.miningSpeed;
    }

    @Override
    public float method_8028() {
        return this.attackDamage;
    }

    @Override
    public class_6862<class_2248> method_58419() {
        return this.inverseTag;
    }

    @Override
    public int method_8026() {
        return this.enchantability;
    }

    @Override
    public class_1856 method_8023() {
        return (class_1856) this.repairIngredient.get();
    }
}
