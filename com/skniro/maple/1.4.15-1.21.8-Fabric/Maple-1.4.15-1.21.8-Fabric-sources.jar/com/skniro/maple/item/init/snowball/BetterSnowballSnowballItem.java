package com.skniro.maple.item.init.snowball;

import com.skniro.maple.entity.projectile.thrown.*;
import com.skniro.maple.item.MapleItems;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_2374;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_9463;

public class BetterSnowballSnowballItem
        extends class_1792 implements class_9463 {
    public BetterSnowballSnowballItem(class_1792.class_1793 settings) {
        super(settings);
    }

    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 itemStack = user.method_5998(hand);
        world.method_43128((class_1657)null, user.method_23317(), user.method_23318(), user.method_23321(), class_3417.field_14873, class_3419.field_15254, 0.5F, 0.4F / (world.method_8409().method_43057() * 0.4F + 0.8F));
        if (world instanceof class_3218 serverWorld) {
            if (itemStack.method_7909() == MapleItems.SNOWBALL_STONE) {
                class_1676.method_61549(MapleStoneSnowballEntity::new, serverWorld, itemStack, user, 0.0F, 1.5F, 1.0F);
            } else if (itemStack.method_7909() == MapleItems.SNOWBALL_ICE) {
                class_1676.method_61549(MapleStoneSnowballEntity::new, serverWorld, itemStack, user, 0.0F, 1.5F, 1.0F);
            } else if (itemStack.method_7909() == MapleItems.SNOWBALL_IRON) {
                class_1676.method_61549(MapleIronSnowballEntity::new, serverWorld, itemStack, user, 0.0F, 1.5F, 1.0F);
            } else if (itemStack.method_7909() == MapleItems.SNOWBALL_Gold) {
                class_1676.method_61549(MapleGoldSnowballEntity::new, serverWorld, itemStack, user, 0.0F, 1.5F, 1.0F);
            } else if (itemStack.method_7909() == MapleItems.SNOWBALL_Diamond) {
                class_1676.method_61549(MapleDiamondSnowballEntity::new, serverWorld, itemStack, user, 0.0F, 1.5F, 1.0F);
            } else if (itemStack.method_7909() == MapleItems.SNOWBALL_Compression) {
                class_1676.method_61549(MapleStoneSnowballEntity::new, serverWorld, itemStack, user, 0.0F, 1.5F, 1.0F);
            } else if (itemStack.method_7909() == MapleItems.SNOWBALL_Teleporting) {
                class_1676.method_61549(MapletransSnowballEntity::new, serverWorld, itemStack, user, 0.0F, 1.5F, 1.0F);
            } else if (itemStack.method_7909() == MapleItems.SNOWBALL_Confusion) {
                class_1676.method_61549(MapleConfusionSnowballEntity::new, serverWorld, itemStack, user, 0.0F, 1.5F, 1.0F);
            } else if (itemStack.method_7909() == MapleItems.SNOWBALL_Poison) {
                class_1676.method_61549(MaplePoisonSnowballEntity::new, serverWorld, itemStack, user, 0.0F, 1.5F, 1.0F);
            } else if (itemStack.method_7909() == MapleItems.SNOWBALL_Instant_Health) {
                class_1676.method_61549(MapleInstantHealthSnowballEntity::new, serverWorld, itemStack, user, 0.0F, 1.5F, 1.0F);
            } else {
                class_1676.method_61549(MapleSnowballEntity::new, serverWorld, itemStack, user, 0.0F, 1.5F, 1.0F);
            }
        }

        user.method_7259(class_3468.field_15372.method_14956(this));
        itemStack.method_57008(1, user);
        return class_1269.field_5812;
    }

    public class_1676 method_58648(class_1937 world, class_2374 pos, class_1799 stack, class_2350 direction) {
        return new MapleSnowballEntity(world, pos.method_10216(), pos.method_10214(), pos.method_10215(), stack);
    }
}