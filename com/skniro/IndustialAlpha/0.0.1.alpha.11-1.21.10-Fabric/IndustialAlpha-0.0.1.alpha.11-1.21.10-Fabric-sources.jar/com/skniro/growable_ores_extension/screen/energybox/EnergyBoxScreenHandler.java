package com.skniro.growable_ores_extension.screen.energybox;

import com.skniro.growable_ores_extension.block.entity.energybox.EnergyBoxBlockEntity;
import com.skniro.growable_ores_extension.screen.AlchemyScreenHandlerType;
import com.skniro.growable_ores_extension.screen.slot.*;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3913;
import net.minecraft.class_3919;

public class EnergyBoxScreenHandler extends class_1703 {
    final class_1263 inventory;
    final class_3913 propertyDelegate;
    public final EnergyBoxBlockEntity blockEntity;

    public EnergyBoxScreenHandler(int syncId, class_1661 playerInventory, class_2338 pos){
        this(syncId,playerInventory, playerInventory.field_7546.method_73183().method_8321(pos),new class_3919(3));
    }


    public EnergyBoxScreenHandler(int syncId, class_1661 playerInventory, class_2586 blockEntity, class_3913 delegate) {
        super(AlchemyScreenHandlerType.EnergyBox, syncId);
        method_17359((class_1263) blockEntity,8);
        this.inventory = (class_1263) blockEntity;
        inventory.method_5435(playerInventory.field_7546);
        this.propertyDelegate = delegate;
        this.blockEntity = (EnergyBoxBlockEntity) blockEntity;
        this.method_7621(new BatteryFuelSlot(inventory, 0, 52, 13, ((EnergyBoxBlockEntity) blockEntity).getEnergyTier()));
        this.method_7621(new BatteryChargeSlot(inventory, 1, 52, 49, ((EnergyBoxBlockEntity) blockEntity).getEnergyTier()));

        addBasic(inventory, playerInventory, delegate);
    }

    private void addBasic(class_1263 inventory, class_1661 playerInventory, class_3913 propertyDelegate){
        addUpgradeSlot(inventory);
        addPlayerInventory(playerInventory);
        addPlayerHotbar(playerInventory);
        method_17360(propertyDelegate);
    }

    private void addUpgradeSlot(class_1263 inventory) {
        this.method_7621(new HelmetSlot(inventory, 4, 151, 9, blockEntity.getEnergyTier()));
        this.method_7621(new ChestplateSlot(inventory, 5, 151, 27, blockEntity.getEnergyTier()));
        this.method_7621(new LeggingsSlot(inventory, 6, 151, 45, blockEntity.getEnergyTier()));
        this.method_7621(new BootsSlot(inventory, 7, 151, 63, blockEntity.getEnergyTier()));
    }

    public boolean isCrafting() {
        return propertyDelegate.method_17390(0) > 0;
    }



    public int getScaledEnergyHeight() {
        long energy = blockEntity.energyContainer.amount;
        long capacity = blockEntity.energyContainer.getCapacity();
        int energyBarSize = 12;

        return Math.toIntExact(capacity != 0 && energy != 0 ? energy * energyBarSize / capacity : 0);
    }

    public int getScaledProgress() {
        int progress = this.propertyDelegate.method_17390(0);
        int maxProgress = this.propertyDelegate.method_17390(1);  // Max Progress
        int progressArrowSize = 46; // This is the width in pixels of your arrow

        return maxProgress != 0 && progress != 0 ? progress * progressArrowSize / maxProgress : 0;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int invSlot) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(invSlot);
        if (slot != null && slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();
            if (invSlot < this.inventory.method_5439()) {
                if (!this.method_7616(originalStack, this.inventory.method_5439(), this.field_7761.size(), true)) {
                    return class_1799.field_8037;
                }
            } else if (!this.method_7616(originalStack, 0, this.inventory.method_5439(), false)) {
                return class_1799.field_8037;
            }

            if (originalStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }

        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return this.inventory.method_5443(player);
    }

    private void addPlayerInventory(class_1661 playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.method_7621(new class_1735(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }
    }

    private void addPlayerHotbar(class_1661 playerInventory) {
        for (int i = 0; i < 9; ++i) {
            this.method_7621(new class_1735(playerInventory, i, 8 + i * 18, 142));
        }
    }
}
