package com.skniro.growable_ores_extension.init;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import net.minecraft.class_1282;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public final class ModDamageTypes {
    public static final class_5321<class_8110> ELECTRIC_SHOCK;
    public static final class_5321<class_8110> FUSION;

    public static class_1282 create(class_1937 world, class_5321<class_8110> key) {
        return new class_1282(world.method_30349().method_30530(class_7924.field_42534).method_46747(key));
    }

    static {
        ELECTRIC_SHOCK = class_5321.method_29179(class_7924.field_42534, class_2960.method_60655(GrowableOresExtension.MOD_ID, "electric_shock"));
        FUSION = class_5321.method_29179(class_7924.field_42534, class_2960.method_60655(GrowableOresExtension.MOD_ID, "fusion"));
    }
}