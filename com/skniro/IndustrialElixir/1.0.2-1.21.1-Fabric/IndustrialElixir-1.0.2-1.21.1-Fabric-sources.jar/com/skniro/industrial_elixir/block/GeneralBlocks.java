package com.skniro.industrial_elixir.block;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.block.entity.MapleSignTypes;
import com.skniro.industrial_elixir.block.init.*;
import com.skniro.industrial_elixir.block.init.machine.fluid.CoffeeMachineBlock;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.item.MapleFoodComponents;
import com.skniro.industrial_elixir.world.Tree.RubberSaplingGenerator;
import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2362;
import net.minecraft.class_2378;
import net.minecraft.class_2397;
import net.minecraft.class_2431;
import net.minecraft.class_2440;
import net.minecraft.class_2465;
import net.minecraft.class_2473;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2533;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_6019;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8177;

public class GeneralBlocks {
    public static final class_2248 Lead_Ore = registerBlock("lead_ore", (settings)-> new class_2431(class_6019.method_35017(2, 4), settings),class_4970.class_2251.method_9630(class_2246.field_10212));
    public static final class_2248 Tin_Ore = registerBlock("tin_ore", (settings)-> new class_2431(class_6019.method_35017(2, 4), settings),class_4970.class_2251.method_9630(class_2246.field_27120));
    public static final class_2248 SACRED_Ore = registerBlock("sacred_ore", (settings)-> new class_2431(class_6019.method_35017(2, 4), settings),class_4970.class_2251.method_9630(class_2246.field_10212));
    public static final class_2248 Deepslate_Lead_Ore = registerBlock("deepslate_lead_ore", (settings)-> new class_2431(class_6019.method_35017(2, 4), settings),class_4970.class_2251.method_9630(class_2246.field_29027));
    public static final class_2248 Deepslate_Tin_Ore = registerBlock("deepslate_tin_ore", (settings)-> new class_2431(class_6019.method_35017(2, 4), settings),class_4970.class_2251.method_9630(class_2246.field_29221));
    public static final class_2248 Deepslate_SACRED_Ore = registerBlock("deepslate_sacred_ore", (settings)-> new class_2431(class_6019.method_35017(2, 4), settings),class_4970.class_2251.method_9630(class_2246.field_29027));
    public static final class_2248 Raw_Lead_Block = registerBlock("raw_lead_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Raw_Tin_Block = registerBlock("raw_tin_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Raw_SACRED_Block = registerBlock("raw_sacred_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Lead_Block = registerBlock("lead_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Tin_Block = registerBlock("tin_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 SACRED_Block = registerBlock("sacred_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Silver_Block = registerBlock("silver_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Bronze_Block = registerBlock("bronze_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Steel_Block = registerBlock("steel_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Advanced_Machine = registerBlock("advanced_machine", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Machine = registerBlock("machine", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Super_Machine = registerBlock("super_machine", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));

    public static final class_2248 Rubber_SAPLING = registerBlock("rubber_sapling",
            (settings)-> new class_2473(RubberSaplingGenerator.RubberSapling, settings), class_4970.class_2251.method_55226(class_2246.field_10394));

    public static final class_2248 POTTED_Rubber_SAPLING = registerBlockWithoutItem("potted_rubber_sapling",
            (settings)-> new class_2362(Rubber_SAPLING, settings), class_4970.class_2251.method_9637().method_9618().method_22488());

    public static final class_2248 Rubber_LEAVES =registerBlock("rubber_leaves",
            class_2397::new, (class_4970.class_2251.method_9630(class_2246.field_10503).method_31710(class_3620.field_16028)));

    public static final class_2248 Rubber_Rubber_LOG =registerBlock("rubber_rubber_log",
            (settings)-> new LogCropBlock(settings, GrowableOresItems.Sticky_Resin), class_4970.class_2251.method_9630(class_2246.field_10431).method_31710(class_3620.field_15977));

    public static final class_2248 Rubber_LOG = registerBlock("rubber_log",class_2465::new, (class_4970.class_2251.method_9630(class_2246.field_10431).method_31710(class_3620.field_15977)));
    public static final class_2248 STRIPPED_Rubber_LOG = registerBlock("stripped_rubber_log",
            class_2465::new, (class_4970.class_2251.method_9630(class_2246.field_10519).method_31710(class_3620.field_15977)));
    public static final class_2248 STRIPPED_Rubber_WOOD = registerBlock("stripped_rubber_wood",
            class_2465::new, (class_4970.class_2251.method_9630(class_2246.field_10250).method_31710(class_3620.field_15977)));
    public static final class_2248 Rubber_WOOD = registerBlock("rubber_wood",
            class_2465::new, (class_4970.class_2251.method_9630(class_2246.field_10126).method_31710(class_3620.field_15977)));

    public static final class_2248 Rubber_PLANKS = registerBlock("rubber_planks",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10161).method_31710(class_3620.field_15977)));
    public static final class_2248 Rubber_BUTTON = registerBlock("rubber_button",
            (settings)-> new class_2269(MapleBlockSetType.Rubber,30, settings), class_4970.class_2251.method_9637().method_9634().method_9632(0.5F).method_50012(class_3619.field_15971));
    public static final class_2248 Rubber_STAIRS = registerBlock("rubber_stairs",
            (settings)-> new ModStairBlock(class_2246.field_10161.method_9564(), settings), class_4970.class_2251.method_9630(class_2246.field_10563));
    public static final class_2248 Rubber_SLAB = registerBlock("rubber_slab",
            class_2482::new, (class_4970.class_2251.method_9637().method_31710(class_3620.field_15992).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547)));
    public static final class_2248 Rubber_FENCE_GATE = registerBlock("rubber_fence_gate",
            (settings)-> new class_2349(MapleSignTypes.Rubber, settings),  class_4970.class_2251.method_9637().method_31710(Rubber_PLANKS.method_26403()).method_9629(2.0F, 3.0F));
    public static final class_2248 Rubber_FENCE = registerBlock("rubber_fence",
            class_2354::new, (class_4970.class_2251.method_9637().method_31710(Rubber_PLANKS.method_26403()).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547)));
    public static final class_2248 Rubber_DOOR = registerBlock("rubber_door",
            (settings)-> new class_2323(class_8177.field_42827, settings), class_4970.class_2251.method_9637().method_31710(Rubber_PLANKS.method_26403()).method_9632(3.0f).method_9626(class_2498.field_11547).method_22488());
    public static final class_2248 Rubber_TRAPDOOR = registerBlock("rubber_trapdoor",
            (settings)-> new class_2533(MapleBlockSetType.Rubber, settings),class_4970.class_2251.method_9637().method_31710(class_3620.field_15992).method_9632(3.0F).method_22488());
    public static final class_2248 Rubber_PRESSURE_PLATE = registerBlock("rubber_pressure_plate",
            (settings)-> new class_2440(MapleBlockSetType.Rubber, settings), class_4970.class_2251.method_9637().method_31710(
                    Rubber_PLANKS.method_26403()).method_9634().method_9632(0.5F).method_50013().method_51368(class_2766.field_12651).method_50012(class_3619.field_15971));

    public static final class_2248 Reinforced_Stone = registerBlock("reinforced_stone",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10340)).method_31710(class_3620.field_16027).method_9629(100.0F, 1000.0F));
    public static final class_2248 Reinforced_Glass = registerBlock("reinforced_glass",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10033).method_31710(class_3620.field_16027).method_9629(80.0F, 800.0F)));

    public static final class_2248 Reinforced_DOOR = registerBlock("reinforced_door",
            (settings)-> new class_2323(class_8177.field_42819, settings), class_4970.class_2251.method_9637().method_31710(class_3620.field_16027).method_9629(80.0F, 1000.0F).method_22488().method_50012(class_3619.field_15975));

    //PLASTER
    public static final class_2248 GREEN_PLASTER =registerBlock("green_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10367)));
    public static final class_2248 PLASTER =registerBlock("plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10107)));
    public static final class_2248 ORANGE_PLASTER =registerBlock("orange_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10210)));
    public static final class_2248 MAGENTA_PLASTER =registerBlock("magenta_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10585)));
    public static final class_2248 LIGHT_BLUE_PLASTER =registerBlock("light_blue_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10242)));
    public static final class_2248 YELLOW_PLASTER =registerBlock("yellow_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10542)));
    public static final class_2248 LIME_PLASTER =registerBlock("lime_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10421)));
    public static final class_2248 PINK_PLASTER =registerBlock("pink_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10434)));
    public static final class_2248 GRAY_PLASTER =registerBlock("gray_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10038)));
    public static final class_2248 LIGHT_GRAY_PLASTER =registerBlock("light_gray_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10172)));
    public static final class_2248 CYAN_PLASTER =registerBlock("cyan_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10308)));
    public static final class_2248 PURPLE_PLASTER =registerBlock("purple_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10206)));
    public static final class_2248 BLUE_PLASTER =registerBlock("blue_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10011)));
    public static final class_2248 BROWN_PLASTER =registerBlock("brown_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10439)));
    public static final class_2248 RED_PLASTER =registerBlock("red_plaster",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10058)));

    //Coffee
    public static final class_2248 Coffee_Block = registerBlock("coffee_block", (properties)-> new CoffeeBlock(properties),class_4970.class_2251.method_9637().method_22488().method_29292().method_9629(3.0F, 3.0F));

    public static final class_2248 COFFEE_BLACK = registerBlockWithoutItem("coffee_black", CupSpecialBlock::new, class_4970.class_2251.method_9637().method_9632(0.5F).method_22488());
    public static final class_2248 CAPPUCCINO = registerBlockWithoutItem("cappuccino", CupBlock::new, class_4970.class_2251.method_9637().method_9632(0.5F).method_22488());
    public static final class_2248 LATTE = registerBlockWithoutItem("latte", CupBlock::new, class_4970.class_2251.method_9637().method_9632(0.5F).method_22488());
    public static final class_2248 MOCHA = registerBlockWithoutItem("mocha", CupBlock::new, class_4970.class_2251.method_9637().method_9632(0.5F).method_22488());
    public static final class_2248 HOT_COCOA = registerBlockWithoutItem("hot_cocoa", CupBlock::new, class_4970.class_2251.method_9637().method_9632(0.5F).method_22488());

    public static final class_2248 COBBLESTONE_STAIRS = registerBlock("cobblestone_stairs",
            (settings)-> new ModStairBlock(class_2246.field_10596.method_9564(), settings), class_4970.class_2251.method_9630(class_2246.field_10596));

    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings);
        registerBlockItem(name, block);
        return class_2378.method_39197(class_7923.field_41175, class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(IndustrialElixir.MOD_ID, name)), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(IndustrialElixir.MOD_ID, name)),
                new class_1747(block, new class_1792.class_1793()
                        ));
    }

    private static class_2248 registerBlockWithoutItem(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings);
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }

    private static class_5321<class_2248> keyOf(String name) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(IndustrialElixir.MOD_ID, name));
    }

    public static void registerNetherOresBlock() {
        IndustrialElixir.LOGGER.info("register Mod Nether Ores Blocks"+ IndustrialElixir.MOD_ID);
    }
}
