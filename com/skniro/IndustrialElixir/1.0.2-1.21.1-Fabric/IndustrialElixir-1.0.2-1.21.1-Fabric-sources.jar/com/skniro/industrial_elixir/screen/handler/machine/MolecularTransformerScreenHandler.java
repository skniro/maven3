package com.skniro.industrial_elixir.screen.handler.machine;

import com.skniro.industrial_elixir.block.entity.machine.AbstractMachineEntity;
import com.skniro.industrial_elixir.block.entity.machine.MolecularTransformerBlockEntity;
import com.skniro.industrial_elixir.screen.AlchemyScreenHandlerType;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1719;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3913;
import net.minecraft.class_3919;

public class MolecularTransformerScreenHandler extends class_1703 {
    final class_1263 inventory;
    final class_3913 propertyDelegate;
    public final AbstractMachineEntity blockEntity;

    public MolecularTransformerScreenHandler(int syncId, class_1661 playerInventory, class_2338 pos){
        this(syncId,playerInventory, playerInventory.field_7546.method_37908().method_8321(pos),new class_3919(2));
    }


    public MolecularTransformerScreenHandler(int syncId, class_1661 playerInventory, class_2586 blockEntity, class_3913 delegate) {
        super(AlchemyScreenHandlerType.MolecularTransformer, syncId);
        method_17359((class_1263) blockEntity,8);
        this.inventory = (class_1263) blockEntity;
        inventory.method_5435(playerInventory.field_7546);
        this.propertyDelegate = delegate;
        this.blockEntity = (MolecularTransformerBlockEntity) blockEntity;
        this.method_7621(new class_1735(inventory, 1, 52, 33));
        this.method_7621(new class_1719(playerInventory.field_7546, inventory, 2, 100, 34));

        addBasic(inventory, playerInventory, delegate);
    }

    private void addBasic(class_1263 inventory, class_1661 playerInventory, class_3913 propertyDelegate){
        addPlayerInventory(playerInventory);
        addPlayerHotbar(playerInventory);
        method_17360(propertyDelegate);
    }

    public boolean isCrafting() {
        return propertyDelegate.method_17390(0) > 0;
    }



    public int getScaledEnergyHeight() {
        long energy = blockEntity.energyContainer.amount;
        long capacity = blockEntity.energyContainer.getCapacity();
        int energyBarSize = 14;

        return Math.toIntExact(capacity != 0 && energy != 0 ? energy * energyBarSize / capacity : 0);
    }

    public int getScaledProgress() {
        MolecularTransformerBlockEntity molecularTransformerBlockEntity = (MolecularTransformerBlockEntity) blockEntity;
        if (molecularTransformerBlockEntity.energyRequired == 0) return 0;
        return (int) ((double) molecularTransformerBlockEntity.energyProgress * 17 / molecularTransformerBlockEntity.energyRequired);
    }

    public int getProgressPercent() {
        MolecularTransformerBlockEntity be = (MolecularTransformerBlockEntity) blockEntity;
        if (be.energyRequired == 0) return 0;
        return (int) (be.energyProgress * 100 / be.energyRequired);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int invSlot) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(invSlot);
        if (slot != null && slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();
            if (invSlot < this.inventory.method_5439()) {
                if (!this.method_7616(originalStack, this.inventory.method_5439(), this.field_7761.size(), true)) {
                    return class_1799.field_8037;
                }
            } else if (!this.method_7616(originalStack, 0, this.inventory.method_5439(), false)) {
                return class_1799.field_8037;
            }

            if (originalStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }

        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return this.inventory.method_5443(player);
    }

    private void addPlayerInventory(class_1661 playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.method_7621(new class_1735(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }
    }

    private void addPlayerHotbar(class_1661 playerInventory) {
        for (int i = 0; i < 9; ++i) {
            this.method_7621(new class_1735(playerInventory, i, 8 + i * 18, 142));
        }
    }
}
