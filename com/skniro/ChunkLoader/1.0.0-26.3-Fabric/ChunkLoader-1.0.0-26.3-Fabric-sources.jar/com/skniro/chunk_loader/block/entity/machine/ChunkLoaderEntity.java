package com.skniro.chunk_loader.block.entity.machine;

import com.skniro.chunk_loader.block.entity.AlchemyBlockEntityType;
import com.skniro.chunk_loader.block.init.machine.AbstractMachineblock;
import com.skniro.chunk_loader.init.FurnitureStrings;
import com.skniro.chunk_loader.screen.handler.machine.ChunkLoaderScreenHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jetbrains.annotations.Nullable;

public class ChunkLoaderEntity extends AbstractMachineEntity {
    // 5x5 grid, 25 chunks, center chunk (index 12) always loaded
    // Bit i represents chunk i in row-major order
    private int selectedChunks = 0;
    // Mask of optional chunks this loader currently has force-loaded.
    private int appliedChunks = 0;
    private boolean chunksApplied = false;

    public ChunkLoaderEntity(BlockPos pos, BlockState state) {
        super(AlchemyBlockEntityType.CHUNK_LOADER_BE, pos, state);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable(FurnitureStrings.ChunkLoader);
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int syncId, Inventory playerInventory, Player player) {
        return new ChunkLoaderScreenHandler(syncId, playerInventory, worldPosition);
    }

    public int getSelectedChunks() {
        return selectedChunks;
    }

    public void toggleChunk(int index) {
        if (index < 0 || index >= 25 || index == 12) return;
        selectedChunks ^= (1 << index);
        setChanged();
    }

    public void tick(Level world, BlockPos pos, BlockState state) {
        if (world.isClientSide()) return;

        applyChunkForcing(world, pos);

        if (!state.getValue(AbstractMachineblock.LIT)) {
            world.setBlock(pos, state.setValue(AbstractMachineblock.LIT, true), 3);
        }

        setChanged(world, pos, state);
    }

    private void applyChunkForcing(Level world, BlockPos pos) {
        if (!(world instanceof ServerLevel serverLevel)) return;
        int chunkX = pos.getX() >> 4;
        int chunkZ = pos.getZ() >> 4;

        if (!chunksApplied) {
            for (int i = 0; i < 25; i++) {
                if (i == 12 || (selectedChunks & (1 << i)) != 0) {
                    serverLevel.setChunkForced(chunkX + (i % 5) - 2, chunkZ + (i / 5) - 2, true);
                }
            }
            appliedChunks = selectedChunks;
            chunksApplied = true;
        } else {
            int changed = appliedChunks ^ selectedChunks;
            if (changed != 0) {
                for (int i = 0; i < 25; i++) {
                    if (i == 12) continue;
                    if ((changed & (1 << i)) != 0) {
                        boolean force = (selectedChunks & (1 << i)) != 0;
                        serverLevel.setChunkForced(chunkX + (i % 5) - 2, chunkZ + (i / 5) - 2, force);
                    }
                }
                appliedChunks = selectedChunks;
            }
        }

        // The chunk containing the loader is always force-loaded.
        serverLevel.setChunkForced(chunkX, chunkZ, true);
    }

    /**
     * Drops every force-loaded chunk belonging to this loader.
     * Called when the block is actually removed, not when its chunk merely unloads.
     */
    public void unforceAllChunks() {
        if (level instanceof ServerLevel serverLevel) {
            int chunkX = worldPosition.getX() >> 4;
            int chunkZ = worldPosition.getZ() >> 4;
            for (int i = 0; i < 25; i++) {
                serverLevel.setChunkForced(chunkX + (i % 5) - 2, chunkZ + (i / 5) - 2, false);
            }
        }
        appliedChunks = 0;
        chunksApplied = false;
    }

    @Override
    public void preRemoveSideEffects(BlockPos pos, BlockState state) {
        unforceAllChunks();
        super.preRemoveSideEffects(pos, state);
    }

    @Override
    protected void saveAdditional(ValueOutput nbt) {
        super.saveAdditional(nbt);
        nbt.putInt("chunkLoader.selectedChunks", selectedChunks);
    }

    @Override
    protected void loadAdditional(ValueInput nbt) {
        super.loadAdditional(nbt);
        selectedChunks = nbt.getIntOr("chunkLoader.selectedChunks", 0);
    }
}
