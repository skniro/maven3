package com.skniro.industrial_elixir.screen.ingame.machine;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.screen.handler.machine.VendorMachineScreenHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1914;
import net.minecraft.class_1916;
import net.minecraft.class_2561;
import net.minecraft.class_2863;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3850;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_5244;

@Environment(EnvType.CLIENT)
public class VendorMachineScreen extends class_465<VendorMachineScreenHandler> {
    private static final class_2960 OUT_OF_STOCK_SPRITE = class_2960.method_60656("container/villager/out_of_stock");
    private static final class_2960 EXPERIENCE_BAR_BACKGROUND_SPRITE = class_2960.method_60656("container/villager/experience_bar_background");
    private static final class_2960 EXPERIENCE_BAR_CURRENT_SPRITE = class_2960.method_60656("container/villager/experience_bar_current");
    private static final class_2960 EXPERIENCE_BAR_RESULT_SPRITE = class_2960.method_60656("container/villager/experience_bar_result");
    private static final class_2960 SCROLLER_SPRITE = class_2960.method_60656("container/villager/scroller");
    private static final class_2960 SCROLLER_DISABLED_SPRITE = class_2960.method_60656("container/villager/scroller_disabled");
    private static final class_2960 TRADE_ARROW_OUT_OF_STOCK_SPRITE = class_2960.method_60656("container/villager/trade_arrow_out_of_stock");
    private static final class_2960 TRADE_ARROW_SPRITE = class_2960.method_60656("container/villager/trade_arrow");
    private static final class_2960 DISCOUNT_STRIKETHRUOGH_SPRITE = class_2960.method_60656("container/villager/discount_strikethrough");
    private static final class_2960 VILLAGER_LOCATION = class_2960.method_60656("textures/gui/container/villager.png");
    private static final class_2561 TRADES_LABEL = class_2561.method_43471("merchant.trades");
    private static final class_2561 DEPRECATED_TOOLTIP = class_2561.method_43471("merchant.deprecated");
    private int shopItem;
    private final TradeOfferButton[] tradeOfferButtons = new TradeOfferButton[7];
    private int scrollOff;
    private boolean isDragging;

    public VendorMachineScreen(final VendorMachineScreenHandler menu, final class_1661 inventory, final class_2561 title) {
        super(menu, inventory, title);
        this.field_2792 = 276;
        this.field_2779 = 166;
        this.field_25269 = 107;
    }

    private void postButtonClick() {
        (this.field_2797).setSelectionHint(this.shopItem);
        (this.field_2797).tryMoveItems(this.shopItem);
        this.field_22787.method_1562().method_52787(
                new class_2863(this.shopItem)
        );
    }

    protected void method_25426() {
        super.method_25426();
        int xo = (this.field_22789 - this.field_2792) / 2;
        int yo = (this.field_22790 - this.field_2779) / 2;
        int buttonY = yo + 16 + 2;

        for(int i = 0; i < 7; ++i) {
            this.tradeOfferButtons[i] = (TradeOfferButton)this.method_37063(new TradeOfferButton(xo + 5, buttonY, i, (button) -> {
                if (button instanceof TradeOfferButton) {
                    this.shopItem = ((TradeOfferButton)button).getIndex() + this.scrollOff;
                    this.postButtonClick();
                }

            }));
            buttonY += 20;
        }

    }

    protected void method_2388(final class_332 graphics, final int xm, final int ym) {
        int traderLevel = (this.field_2797).getTraderLevel();
        if (traderLevel > 0 && traderLevel <= 5 && (this.field_2797).showProgressBar()) {
            class_2561 titleAndLevel = class_2561.method_43469("merchant.title", new Object[]{this.field_22785, class_2561.method_43471("merchant.level." + traderLevel)});
            int totalWidth = this.field_22793.method_27525(titleAndLevel);
            int startX = 49 + this.field_2792 / 2 - totalWidth / 2;
            graphics.method_51439(this.field_22793, titleAndLevel, startX, 6, -12566464, false);
        } else {
            graphics.method_51439(this.field_22793, this.field_22785, 49 + this.field_2792 / 2 - this.field_22793.method_27525(this.field_22785) / 2, 6, -12566464, false);
        }

        graphics.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, -12566464, false);
        int textWidth = this.field_22793.method_27525(TRADES_LABEL);
        graphics.method_51439(this.field_22793, TRADES_LABEL, 5 - textWidth / 2 + 48, 6, -12566464, false);
    }

    protected void method_2389(class_332 graphics, float a, int mouseX, int mouseY) {

        int xo = (this.field_22789 - this.field_2792) / 2;
        int yo = (this.field_22790 - this.field_2779) / 2;
        graphics.method_25290(VILLAGER_LOCATION, xo, yo, 0.0F, 0.0F, this.field_2792, this.field_2779, 512, 256);
        class_1916 offers = (this.field_2797).getOffers();
        if (!offers.isEmpty()) {
            int itemIndex = this.shopItem;
            if (itemIndex < 0 || itemIndex >= offers.size()) {
                return;
            }

            class_1914 offer = (class_1914)offers.get(itemIndex);
            if (offer.method_8255()) {
                graphics.method_52706(OUT_OF_STOCK_SPRITE, this.field_2776 + 83 + 99, this.field_2800 + 35, 28, 21);
            }
        }

    }

    private void extractProgressBar(final class_332 graphics, final int xo, final int yo, final class_1914 offer) {
        int traderLevel = (this.field_2797).getTraderLevel();
        int traderXp = (this.field_2797).getTraderXp();
        if (traderLevel < 5) {
            graphics.method_52706(EXPERIENCE_BAR_BACKGROUND_SPRITE, xo + 136, yo + 16, 102, 5);
            int minXp = class_3850.method_19194(traderLevel);
            if (traderXp >= minXp && class_3850.method_19196(traderLevel)) {
                int progressLength = 102;
                float multiplier = 102.0F / (float)(class_3850.method_19195(traderLevel) - minXp);
                int w = Math.min(class_3532.method_15375(multiplier * (float)(traderXp - minXp)), 102);
                graphics.method_52708(EXPERIENCE_BAR_CURRENT_SPRITE, 102, 5, 0, 0, xo + 136, yo + 16, w, 5);
                int futureXp = (this.field_2797).getFutureTraderXp();
                if (futureXp > 0) {
                    int futureXpWidth = Math.min(class_3532.method_15375((float)futureXp * multiplier), 102 - w);
                    graphics.method_52708(EXPERIENCE_BAR_RESULT_SPRITE, 102, 5, w, 0, xo + 136 + w, yo + 16, futureXpWidth, 5);
                }

            }
        }
    }

    private void extractScroller(final class_332 graphics, final int xo, final int yo, final int mouseX, final int mouseY, final class_1916 offers) {
        int steps = offers.size() + 1 - 7;
        if (steps > 1) {
            int leftOver = 139 - (27 + (steps - 1) * 139 / steps);
            int stepHeight = 1 + leftOver / steps + 139 / steps;
            int maxScrollerOff = 113;
            int scrollerYOff = Math.min(113, this.scrollOff * stepHeight);
            if (this.scrollOff == steps - 1) {
                scrollerYOff = 113;
            }

            int scrollerX = xo + 94;
            int scrollerY = yo + 18 + scrollerYOff;
            graphics.method_52706(SCROLLER_SPRITE, scrollerX, scrollerY, 6, 27);
        } else {
            graphics.method_52706(SCROLLER_DISABLED_SPRITE, xo + 94, yo + 18, 6, 27);
        }

    }

    public void method_25394(final class_332 graphics, final int mouseX, final int mouseY, final float a) {
        super.method_25394(graphics, mouseX, mouseY, a);
        class_1916 offers = this.field_2797.getOffers();
/*        IndustrialElixir.LOGGER.info(
                "CLIENT MERCHANT OFFERS = "
                        + offers.size()
        );*/
        if (!offers.isEmpty()) {
            int xo = (this.field_22789 - this.field_2792) / 2;
            int yo = (this.field_22790 - this.field_2779) / 2;
            int offerY = yo + 16 + 1;
            int sellItem1X = xo + 5 + 5;
            this.extractScroller(graphics, xo, yo, mouseX, mouseY, offers);
            int currentOfferIndex = 0;
            for(class_1914 offer : offers) {
                if (!this.canScroll(offers.size()) || currentOfferIndex >= this.scrollOff && currentOfferIndex < 7 + this.scrollOff) {
                    class_1799 baseCostA = offer.method_8246();
                    class_1799 costA = offer.method_19272();
                    class_1799 costB = offer.method_8247();
                    class_1799 result = offer.method_8250();
                    int decorHeight = offerY + 2;
                    this.extractAndDecorateCostA(graphics, costA, baseCostA, sellItem1X, decorHeight);
                    if (!costB.method_7960()) {
                        graphics.method_51445(costB, xo + 5 + 35, decorHeight);
                        graphics.method_51431(this.field_22793, costB, xo + 5 + 35, decorHeight);
                    }

                    this.extractButtonArrows(graphics, offer, xo, decorHeight);
                    graphics.method_51445(result, xo + 5 + 68, decorHeight);
                    graphics.method_51431(this.field_22793, result, xo + 5 + 68, decorHeight);
                    offerY += 20;
                    ++currentOfferIndex;
                } else {
                    ++currentOfferIndex;
                }
            }

            int itemIndex = this.shopItem;
            class_1914 selectedOffer = (class_1914)offers.get(itemIndex);
            if ((this.field_2797).showProgressBar()) {
                this.extractProgressBar(graphics, xo, yo, selectedOffer);
            }

            if (selectedOffer.method_8255() && this.method_2378(186, 35, 22, 21, (double)mouseX, (double)mouseY) && (this.field_2797).canRestock()) {
                graphics.method_51438(this.field_22793, DEPRECATED_TOOLTIP, mouseX, mouseY);
            }

            for(TradeOfferButton button : this.tradeOfferButtons) {
                if (button.method_25367()) {
                    button.extractToolTip(graphics, mouseX, mouseY);
                }

                button.field_22764 = button.index < (this.field_2797).getOffers().size();
            }
        }

    }

    private void extractButtonArrows(final class_332 graphics, final class_1914 offer, final int xo, final int decorHeight) {
        if (offer.method_8255()) {
            graphics.method_52706(TRADE_ARROW_OUT_OF_STOCK_SPRITE, xo + 5 + 35 + 20, decorHeight + 3, 10, 9);
        } else {
            graphics.method_52706(TRADE_ARROW_SPRITE, xo + 5 + 35 + 20, decorHeight + 3, 10, 9);
        }

    }

    private void extractAndDecorateCostA(final class_332 graphics, final class_1799 costA, final class_1799 baseCostA, final int sellItem1X, final int decorHeight) {
        graphics.method_51445(costA, sellItem1X, decorHeight);
        if (baseCostA.method_7947() == costA.method_7947()) {
            graphics.method_51431(this.field_22793, costA, sellItem1X, decorHeight);
        } else {
            graphics.method_51432(this.field_22793, baseCostA, sellItem1X, decorHeight, baseCostA.method_7947() == 1 ? "1" : null);
            graphics.method_51432(this.field_22793, costA, sellItem1X + 14, decorHeight, costA.method_7947() == 1 ? "1" : null);
            graphics.method_52706(DISCOUNT_STRIKETHRUOGH_SPRITE, sellItem1X + 7, decorHeight + 12, 9, 2);
        }

    }

    private boolean canScroll(final int numberOfOffers) {
        return numberOfOffers > 7;
    }

    public boolean method_25401(final double x, final double y, final double scrollX, final double scrollY) {
        if (super.method_25401(x, y, scrollX, scrollY)) {
            return true;
        } else {
            int numberOfOffers = (this.field_2797).getOffers().size();
            if (this.canScroll(numberOfOffers)) {
                int maxScrollOff = numberOfOffers - 7;
                this.scrollOff = class_3532.method_15340((int)((double)this.scrollOff - scrollY), 0, maxScrollOff);
            }

            return true;
        }
    }

    public boolean method_25403(final double mouseX, final double mouseY, final int button, final double dx, final double dy) {
        int numberOfOffers = (this.field_2797).getOffers().size();
        if (this.isDragging) {
            int fullScrollTopPos = this.field_2800 + 18;
            int fullScrollBottomPos = fullScrollTopPos + 139;
            int maxScrollOff = numberOfOffers - 7;
            float scrolling = ((float)mouseY - (float)fullScrollTopPos - 13.5F) / ((float)(fullScrollBottomPos - fullScrollTopPos) - 27.0F);
            scrolling = scrolling * (float)maxScrollOff + 0.5F;
            this.scrollOff = class_3532.method_15340((int)scrolling, 0, maxScrollOff);
            return true;
        } else {
            return super.method_25403(mouseX, mouseY, button, dx, dy);
        }
    }

    public boolean method_25402(final double mouseX, final double mouseY, final int button) {
        int xo = (this.field_22789 - this.field_2792) / 2;
        int yo = (this.field_22790 - this.field_2779) / 2;
        if (this.canScroll((this.field_2797).getOffers().size()) && mouseX > (double)(xo + 94) && mouseX < (double)(xo + 94 + 6) && mouseY > (double)(yo + 18) && mouseY <= (double)(yo + 18 + 139 + 1)) {
            this.isDragging = true;
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    public boolean method_25406(final double mouseX, final double mouseY, final int button) {
        this.isDragging = false;
        return super.method_25406(mouseX, mouseY, button);
    }

    @Environment(EnvType.CLIENT)
    private class TradeOfferButton extends class_4185 {
        final int index;

        public TradeOfferButton(final int x, final int y, final int index, final class_4185.class_4241 onPress) {
            super(x, y, 88, 20, class_5244.field_39003, onPress, field_40754);
            this.index = index;
            this.field_22764 = false;
        }

        public int getIndex() {
            return this.index;
        }

        public void extractToolTip(final class_332 graphics, final int xm, final int ym) {
            if (this.field_22762 && (VendorMachineScreen.this.field_2797).getOffers().size() > this.index + VendorMachineScreen.this.scrollOff) {
                if (xm < this.method_46426() + 20) {
                    class_1799 item = ((class_1914)(VendorMachineScreen.this.field_2797).getOffers().get(this.index + VendorMachineScreen.this.scrollOff)).method_19272();
                    graphics.method_51446(VendorMachineScreen.this.field_22793, item, xm, ym);
                } else if (xm < this.method_46426() + 50 && xm > this.method_46426() + 30) {
                    class_1799 item = ((class_1914)(VendorMachineScreen.this.field_2797).getOffers().get(this.index + VendorMachineScreen.this.scrollOff)).method_8247();
                    if (!item.method_7960()) {
                        graphics.method_51446(VendorMachineScreen.this.field_22793, item, xm, ym);
                    }
                } else if (xm > this.method_46426() + 65) {
                    class_1799 item = ((class_1914)(VendorMachineScreen.this.field_2797).getOffers().get(this.index + VendorMachineScreen.this.scrollOff)).method_8250();
                    graphics.method_51446(VendorMachineScreen.this.field_22793, item, xm, ym);
                }
            }

        }
    }
}