package com.skniro.growable_ores_extension.block.entity.generator;

import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.EnergyStorageUtil;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import com.skniro.growable_ores_extension.screen.GeneratorWindMillScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1264;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_5819;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;


public class GeneratorWindMillBlockEntity extends BaseGeneratorBlockEntity {
    private final class_2371<class_1799> inventory = class_2371.method_10213(1, class_1799.field_8037);

    private static final int Battery_SLOT = 0;

    protected final class_3913 propertyDelegate;
    private static final int ENERGY_TRANSFER_AMOUNT = 320;
    private static final int WIND_UPDATE_INTERVAL = 128;
    private int tickCounter = 0;
    private int windStrength = 10;
    private int cachedPower = 0;
    private GeneratorState state = GeneratorState.IDLE;

    public GeneratorWindMillBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.GENERATOR_WIND_MILL_BLOCK_ENTITY, pos, state, 100, EnergyTier.TIER1);
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> GeneratorWindMillBlockEntity.this.tickCounter;
                    case 1 -> GeneratorWindMillBlockEntity.this.windStrength;
                    case 2 -> GeneratorWindMillBlockEntity.this.cachedPower;
                    case 3 -> GeneratorWindMillBlockEntity.this.state.ordinal();
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: GeneratorWindMillBlockEntity.this.tickCounter = value;
                    case 1: GeneratorWindMillBlockEntity.this.windStrength = value;
                    case 2: GeneratorWindMillBlockEntity.this.cachedPower = value;
                    case 3: {
                            GeneratorState[] values = GeneratorState.values();
                            if (value >= 0 && value < values.length) {
                                GeneratorWindMillBlockEntity.this.state = values[value];
                            }
                        }
                }
            }

            @Override
            public int method_17389() {
                return 4;
            }
        };
    }

    @Override
    protected void method_11007(class_11372 nbt) {
        super.method_11007(nbt);
        class_1262.method_5426(nbt, inventory);
        nbt.method_71466(("generator_wind_mill.energy"), energyContainer.amount);
        nbt.method_71465(("generator_wind_mill.windstrength"), windStrength);
    }

    @Override
    protected void method_11014(class_11368 nbt) {
        class_1262.method_5429(nbt, inventory);
        energyContainer.amount = nbt.method_71425("generator_wind_mill.energy", 0);
        windStrength = nbt.method_71424("generator_wind_mill.windstrength", 10);
        super.method_11014(nbt);
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2371<class_1799> getItems() {
        return this.inventory;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43470(FurnitureStrings.GeneratorWindMill);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new GeneratorWindMillScreenHandler(syncId, playerInventory, this, this.propertyDelegate);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world == null || world.method_8608()) return;

        discharge(Battery_SLOT);

        tickCounter++;

        if (tickCounter % WIND_UPDATE_INTERVAL == 0) {
            updateWindStrength(world);
            cachedPower = calculatePower(world, pos);
            updateState();
            //System.out.println("Wind: " + windStrength + " Power: " + cachedPower);
            method_5431();

            if (cachedPower >= 15) {
                tryBreakGenerator(world, pos);
            }
        }
        if (cachedPower > 0) {
            try (Transaction transaction = Transaction.openOuter()) {
                this.energyContainer.getSideStorage(null).insert(cachedPower, transaction);
                transaction.commit();
            }
            pushEnergyToNeighbours();
        }
    }

    private void updateState() {

        if (cachedPower <= 0) {
            state = GeneratorState.IDLE;
            return;
        }

        if (cachedPower >= 15) {
                state = GeneratorState.DANGER;
            } else {
            state = GeneratorState.GENERATING;
        }
    }

    private int calculatePower(class_1937 world, class_2338 pos) {

        int y = pos.method_10264();

        if (y < 64) return 0;

        int obstacleCount = countObstacles(world, pos);

        int h = y - obstacleCount;

        double weatherMultiplier = 3.0;

        if (world.method_8546()) {
            weatherMultiplier = 6.0;
        } else if (world.method_8419()) {
            weatherMultiplier = 8.0;
        }

        double power = weatherMultiplier * windStrength * (h - 64) / 750.0;

        if (power < 0) return 0;

        return (int) Math.ceil(power);
    }

    private void tryBreakGenerator(class_1937 world, class_2338 pos) {
        class_5819 random = world.method_8409();

        double breakChance = (cachedPower / 11.46) * 0.001292;

        if (random.method_43058() < breakChance) {

            world.method_8501(pos, GrowableOresBlocks.COAL_GENERATOR.method_9564());

            int ironCount = random.method_43048(5);
            if (ironCount > 0) {
                class_1264.method_5449(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), new class_1799(class_1802.field_8620, ironCount));
            }
        }
    }

    private int countObstacles(class_1937 world, class_2338 center) {
        int count = 0;

        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                for (int dy = -2; dy <= 4; dy++) {

                    class_2338 checkPos = center.method_10069(dx, dy, dz);

                    if (checkPos.equals(center)) continue;

                    class_2680 state = world.method_8320(checkPos);

                    if (!state.method_26215()) {
                        count++;
                    }
                }
            }
        }

        return count;
    }

    private void updateWindStrength(class_1937 world) {
        class_5819 random = world.method_8409();
        int s = windStrength;

        if (s >= 0 && s <= 20 && random.method_43057() < 0.10f) {
            s++;
        }

        if (s >= 20 && s <= 30 && random.method_43057() < 0.10f) {
            s--;
        }

        if (s >= 0 && s <= 9 && random.method_43057() < (s / 100f)) {
            s--;
        }

        if (s >= 21 && s <= 30 && random.method_43057() < ((30 - s) / 100f)) {
            s++;
        }

        windStrength = Math.max(0, Math.min(30, s));
    }

    private void pushEnergyToNeighbours() {
        if (energyContainer.amount <= 0) return;

        for (class_2350 direction : class_2350.values()) {
            EnergyStorage target = EnergyStorage.SIDED.find(
                    field_11863,
                    field_11867.method_10093(direction),
                    direction.method_10153()
            );

            if (target == null) continue;

            EnergyStorageUtil.move(
                    this.energyContainer.getSideStorage(direction),
                    target,
                    ENERGY_TRANSFER_AMOUNT,
                    null
            );
        }
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }

    public enum GeneratorState {
        IDLE,
        GENERATING,
        DANGER
    }
}