package com.skniro.growable_ores_extension.compat.display;

import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.compat.category.GrowableOresCategory;
import com.skniro.growable_ores_extension.recipe.AlchemyCraftingRecipe;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2960;
import net.minecraft.class_8786;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import java.util.List;
import java.util.Optional;

public class GrowableOresDisplay extends BasicDisplay {
    public static final CategoryIdentifier<GrowableOresDisplay> GrowableOres =
            CategoryIdentifier.of(GrowableOresExtension.MOD_ID, "cane_converter");

    public static final DisplaySerializer<GrowableOresDisplay> SERIALIZER = DisplaySerializer.of(
            RecordCodecBuilder.mapCodec(instance -> instance.group(
                    EntryIngredient.codec().listOf().fieldOf("inputs").forGetter(GrowableOresDisplay::getInputEntries),
                    EntryIngredient.codec().listOf().fieldOf("outputs").forGetter(GrowableOresDisplay::getOutputEntries),
                    class_2960.field_25139.optionalFieldOf("location").forGetter(GrowableOresDisplay::getDisplayLocation)
            ).apply(instance, GrowableOresDisplay::new)),
            class_9139.method_56436(
                    EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
                    GrowableOresDisplay::getInputEntries,
                    EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
                    GrowableOresDisplay::getOutputEntries,
                    class_9135.method_56382(class_2960.field_48267),
                    GrowableOresDisplay::getDisplayLocation,
                    GrowableOresDisplay::new
            )
    );

    public GrowableOresDisplay(AlchemyCraftingRecipe recipe) {
        this(List.of(EntryIngredients.ofIngredient(recipe.ingredient())),
                List.of(EntryIngredients.of(recipe.output())), Optional.empty());
    }

    public GrowableOresDisplay(List<EntryIngredient> inputs, List<EntryIngredient> outputs, Optional<class_2960> location) {
        super(inputs, outputs, location);
    }

    public GrowableOresDisplay(class_8786<AlchemyCraftingRecipe> recipe){
        super(List.of(EntryIngredients.ofIngredient(recipe.comp_1933().ingredient())),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.comp_1933().output()))));
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return GrowableOres;
    }

    @Override
    public DisplaySerializer<? extends Display> getSerializer() {
        return SERIALIZER;
    }
}