package com.skniro.growable_ores_extension.block.entity.generator;

import com.skniro.growable_ores_extension.api.ImplementedInventory;
import com.skniro.growable_ores_extension.block.init.machine.AbstractMachineblock;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.EnergyStorageUtil;
import com.skniro.growable_ores_extension.energy.api.base.SimpleSidedEnergyContainer;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;


public abstract class NewBaseGeneratorBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory {

    public SimpleSidedEnergyContainer energyContainer;

    public NewBaseGeneratorBlockEntity(class_2591<?> blockEntityType, class_2338 pos, class_2680 state) {
        super(blockEntityType, pos, state);
        energyContainer = new SimpleSidedEnergyContainer() {

            @Override
            public long getCapacity() {
                return ((AbstractMachineblock)state.method_26204()).getMaxCapacity();
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                if (side == null) return ((AbstractMachineblock)state.method_26204()).getEnergyTier().getMaxInput();
                return 0;
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                return ((AbstractMachineblock)state.method_26204()).getEnergyTier().getMaxOutput();
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(pos, method_11010(), method_11010(), 3);
            }
        };
    }

    public EnergyStorage getSideEnergyStorage(@Nullable class_2350 side) {
        return this.energyContainer.getSideStorage(side);
    }

    private void pushEnergyToNeighbours() {
        for (class_2350 dir : class_2350.values()) {
            EnergyStorage target = EnergyStorage.SIDED.find(field_11863, field_11867.method_10093(dir), dir.method_10153());
            if (target == null) continue;
            EnergyStorageUtil.move(energyContainer.getSideStorage(dir), target, ((AbstractMachineblock)method_11010().method_26204()).getEnergyTier().getMaxOutput(), null);
        }
    }

    public void discharge(int slot) {
        if (this.field_11863 != null) {
            if (!this.field_11863.method_8608()) {
                if (!this.getOptionalInventory().isEmpty()) {
                    class_1263 inventory = this.getOptionalInventory().get();
                    EnergyStorageUtil.move(this.getSideEnergyStorage(null), ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(slot)).find(EnergyStorage.ITEM), Long.MAX_VALUE, null);
                }
            }
        }
    }

    public Optional<ImplementedInventory> getOptionalInventory() {
        if (this instanceof ImplementedInventory inventory) {
            return inventory == null ? Optional.empty() : Optional.of(inventory);
        } else {
            return Optional.empty();
        }
    }

    public boolean canInsert(class_1799 stack) {
        return stack.method_31573(ModItemTags.BATTERY);
    }
}