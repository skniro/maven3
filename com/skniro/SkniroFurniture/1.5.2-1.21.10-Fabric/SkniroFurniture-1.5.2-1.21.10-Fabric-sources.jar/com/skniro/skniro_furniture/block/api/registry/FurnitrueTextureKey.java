package com.skniro.skniro_furniture.block.api.registry;

import net.minecraft.class_4945;

public final class FurnitrueTextureKey {
    public static final class_4945 PLANK = class_4945.method_27043("plank");
    public static final class_4945 PAPER = class_4945.method_27043("paper");


}