package com.skniro.chunk_loader.datagen.recipe;

import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;

public class RecipeDataGeneration {

    public static void onInit(FabricDataGenerator fabricDataGenerator) {
        fabricDataGenerator.createPack().addProvider(BaseMachineRecipeGenerator::new);
    }
}
