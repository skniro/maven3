package com.skniro.skniro_furniture.block.entity;

import com.skniro.skniro_furniture.block.init.FurnitureBedBlock;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1767;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_8824;
import net.minecraft.class_9307;
import org.jetbrains.annotations.Nullable;

public class FurnitureBedBlockEntity extends class_2586 {
    private class_9307 patterns = class_9307.field_49404;
    @Nullable
    private class_2561 customName;
    private final class_1767 baseColor;

    public FurnitureBedBlockEntity(class_2338 pos, class_2680 state) {
        this(pos, state, class_1767.field_7952);
    }


    public FurnitureBedBlockEntity(class_2338 pos, class_2680 state, class_1767 baseColor) {
        super(FurnitureBlockEntityType.Bed_BLOCK_ENTITY, pos, state);
        this.baseColor = baseColor;
    }

    public class_9307 getPatterns() {
        return patterns;
    }

    public void setPatterns(class_9307 patterns) {
        this.patterns = patterns;
        method_5431();
    }

    @Override
    protected void method_11014(class_11368 view) {
        super.method_11014(view);
        this.customName = method_59894(view, "CustomName");
        this.patterns = view.method_71426("patterns", class_9307.field_49405)
                .orElse(class_9307.field_49404);
    }

    public class_2622 method_38235() {
        return class_2622.method_38585(this);
    }


    @Override
    protected void method_11007(class_11372 view) {
        super.method_11007(view);
        if (!patterns.equals(class_9307.field_49404)) {
            view.method_71468("patterns", class_9307.field_49405, patterns);
        }
        view.method_71477("CustomName", class_8824.field_46597, customName);
    }
}

