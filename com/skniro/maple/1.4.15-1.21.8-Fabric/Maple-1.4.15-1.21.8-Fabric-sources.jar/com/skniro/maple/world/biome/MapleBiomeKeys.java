package com.skniro.maple.world.biome;

import com.skniro.maple.Maple;
import net.minecraft.class_1959;
import net.minecraft.class_2922;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_7871;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.registry.*;


public class MapleBiomeKeys {
    public static final class_5321<class_1959> Maple_Grove = register("maple_grove");
    public static final class_5321<class_1959> Sakura = register("sakura");

    private static class_5321<class_1959> register(String name) {
        return class_5321.method_29179(class_7924.field_41236, class_2960.method_60655(Maple.MOD_ID,name));
    }


   public static void bootstrap(class_7891<class_1959> biomeRegisterable) {
        class_7871<class_6796> registryEntryLookup = biomeRegisterable.method_46799(class_7924.field_41245);
        class_7871<class_2922<?>> registryEntryLookup2 = biomeRegisterable.method_46799(class_7924.field_41238);
        biomeRegisterable.method_46838(Maple_Grove, MapleOverworldBiomes.createMapleGrove(registryEntryLookup,registryEntryLookup2));
        biomeRegisterable.method_46838(Sakura, MapleOverworldBiomes.createSakura(registryEntryLookup,registryEntryLookup2));
    }

    public static void registerBiome() {
        Maple.LOGGER.debug("Registering the MapleBiomeKeysFeatures for " + Maple.MOD_ID);
    }
}
