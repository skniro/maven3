package com.skniro.nether_ores_reborn.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_2446;
import net.minecraft.class_7225;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class NetherOresRecipeProvider extends FabricRecipeProvider {
    protected NetherOresRecipeProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    protected class_2446 method_62766(class_7225.class_7874 wrapperLookup, class_8790 recipeExporter) {
        return new class_2446(wrapperLookup, recipeExporter) {
            @Override
            public void method_10419() {

            }
        };
    }

    @Override
    public String method_10321() {
        return "";
    }
}
