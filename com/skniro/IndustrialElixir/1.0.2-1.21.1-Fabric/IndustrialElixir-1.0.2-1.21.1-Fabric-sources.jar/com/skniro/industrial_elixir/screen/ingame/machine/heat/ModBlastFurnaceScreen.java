package com.skniro.industrial_elixir.screen.ingame.machine.heat;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.renderer.GuiFluidTankRenderer;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.BrewReactorScreenHandler;
import com.skniro.industrial_elixir.screen.handler.machine.heat.ModBlastFurnaceScreenHandler;
import com.skniro.industrial_elixir.util.MouseUtil;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.util.List;
import java.util.Optional;

public class ModBlastFurnaceScreen extends class_465<ModBlastFurnaceScreenHandler> {
    private static final class_2960 TEXTURE =
            class_2960.method_60655(IndustrialElixir.MOD_ID,"textures/gui/container/machine/blastfurnace.png");
    private GuiFluidTankRenderer fluidRenderer;

    public ModBlastFurnaceScreen(ModBlastFurnaceScreenHandler menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        field_25269 = 45;
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
        field_25268 = 4;

        assignFluidRenderer();
    }

    private void assignFluidRenderer() {
        fluidRenderer = new GuiFluidTankRenderer(field_2797.blockEntity.fluidContainer.getCapacity(), true, 16, 50);
    }

    private void renderFluidTooltipArea(class_332 context, int pMouseX, int pMouseY, int x, int y,
                                        int offsetX, int offsetY, GuiFluidTankRenderer renderer) {
        if(isMouseAboveArea(pMouseX, pMouseY, x, y, offsetX, offsetY, renderer)) {
            context.method_51437(this.field_22793, renderer.getTooltip(field_2797.blockEntity.fluidContainer), Optional.empty(), pMouseX, pMouseY);
        }
    }

    private void renderHeatAreaTooltips(class_332 context) {
        context.method_51433(field_22793, field_2797.blockEntity.heatContainer.getSideStorage(null).getAmount() + "/" + field_2797.blockEntity.heatContainer.getSideStorage(null).getCapacity() + "H", 78, 68, -12566464, false);
    }

    @Override
    protected void method_2388(class_332 context, int xm, int ym) {
        super.method_2388(context, xm, ym);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        renderHeatAreaTooltips(context);
        renderFluidTooltipArea(context, xm, ym, x, y, 8, 7, fluidRenderer);
    }

    @Override
    protected void method_2389(class_332 context, float a, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        context.method_25290(TEXTURE, x, y, 0, 0,
                field_2792, field_2779, 256, 256);

        fluidRenderer.render(context, x + 8, y + 5, field_2797.blockEntity.fluidContainer);

        renderProgressArrow(context, x, y);
    }

    private void renderProgressArrow(class_332 context, int x, int y) {
        if(field_2797.isCrafting()) {
            context.method_25290(TEXTURE,x + 73, y + 34,
                    189, 0, field_2797.getScaledProgress(), 16, 256, 256);
        }
    }

    public static boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, GuiFluidTankRenderer renderer) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, renderer.getWidth(), renderer.getHeight());
    }

    public static boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, int width, int height) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, width, height);
    }
}