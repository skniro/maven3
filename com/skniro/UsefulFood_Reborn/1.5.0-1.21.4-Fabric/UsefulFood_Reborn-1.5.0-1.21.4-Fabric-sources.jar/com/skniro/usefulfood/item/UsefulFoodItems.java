package com.skniro.usefulfood.item;

import com.skniro.usefulfood.UsefulFood;
import com.skniro.usefulfood.item.init.ItemBottle;
import com.skniro.usefulfood.item.init.StewItem;
import java.util.List;
import java.util.function.Function;
import net.minecraft.class_10128;
import net.minecraft.class_10132;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class UsefulFoodItems {
public static final class_1792 MilkBottle =
        registerItem("milkbottle",ItemBottle::new, (
                new class_1792
                .class_1793()
                .method_62833
                        (new class_4174
                                .class_4175()
                                .method_19238(0)
                                .method_19237(0.0f)
                                .method_19240()
                                .method_19242()
                                , class_10128.field_53780
                        )
                .method_7896(class_1802.field_8469)
                        .method_7889(1)
        ));
    public static final class_1792 ChocolateMilkBottle =
            registerItem( "chocolatemilkbottle", ItemBottle::new, (
                    new class_1792
                            .class_1793()
                            .method_62833
                                    (new class_4174
                                            .class_4175()
                                            .method_19238(3)
                                            .method_19237(0.8f)
                                            .method_19242()
                                            , class_10128.field_53780
                                    )
                            .method_7896(class_1802.field_8469)
                            .method_7889(1)
            ));

    public static final class_1792 Cheese =
    registerItem("cheese", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));

    public static final class_1792 ChocolateCandy =
            registerItem("chocolatebar", class_1792::new, (
                    new class_1792
                            .class_1793()
                            .method_19265
                                    (new class_4174
                                            .class_4175()
                                            .method_19238(6)
                                            .method_19237(1.0f)
                                            .method_19242()
                                    )
            ));
    public static final class_1792 FruitSalad =
            registerItem("fruitsalad", StewItem::new, (
                    new class_1792
                            .class_1793()
                            .method_19265
                                    (new class_4174
                                            .class_4175()
                                            .method_19238(7)
                                            .method_19237(0.6f)
                                            .method_19242()
                                    )
                            .method_7889(1)
            ));

    public static final class_1792 MagicFruitSalad = registerItem("magicfruitsalad", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(List.of(
                                                            new class_1293(class_1294.field_5924,50,1),
                                                            new class_1293(class_1294.field_5907,100,1)
                                                    ))
                                            )
                                            .method_62851()
                            )
                    .method_7894(class_1814.field_8903)
                    .method_7889(1)
    ));
    public static final class_1792 SugarCube = registerItem("sugarcube", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(0.1f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,100,1),1.0F)
                                            )
                                            .method_62851()
                            )
    ));
    public static final class_1792 caramel = registerItem("caramel",class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.2f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,100,1),1.0F)
                                            )
                                            .method_62851()
                            )
    ));


    public static final class_1792 caramelapple = registerItem("caramelapple",class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(10)
                                    .method_19237(0.5f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,100,1),1.0F)
                                            )
                                            .method_62851()
                            ).method_7889(1)
    ));
    public static final class_1792 RoastedSeeds = registerItem("roastedseeds", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(1)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 FriedEgg = registerItem("friedegg",class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 PumpkinSoup = registerItem("pumpkinsoup",StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.8f)
                                    .method_19242()
                            ).method_7889(1)
    ));
    public static final class_1792 Salad = registerItem("salad",StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.6f)
                                    .method_19242()
                            ).method_7889(1)
    ));
    public static final class_1792 Oatmeal = registerItem("oatmeal",StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(0.6f)
                                    .method_19242()
                            ).method_7889(1)
    ));
    public static final class_1792 Jelly = registerItem("jelly",StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.3f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5913,50,1),1.0F)
                                            )
                                            .method_62851()
                            ).method_7889(1)
    ));
    public static final class_1792 Marshmallow = registerItem("rawmarshmallow",class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.3f)
                                    .method_19242()
                            ).method_7889(1)
    ));
    public static final class_1792 CookMarshmallow = registerItem("cookedmarshmallow",class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(0.3f)
                                    .method_19242()
                            ).method_7889(1)
    ));

    public static final class_1792 VanillaIceCream = registerItem("vanillaicecream",StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.3f)
                                    .method_19242()
                            ).method_7889(1)
    ));
    public static final class_1792 BreadSlice = registerItem("breadslice",class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(1)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 PorkWich = registerItem("porkchopsandwich",class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(11)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Steakwich = registerItem("steaksandwich",class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(11)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Fishwich = registerItem("fishsandwich", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Chickenwich = registerItem("chickensandwich",class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Eggwich = registerItem("eggsandwich", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Biscuit = registerItem("biscuit", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(1)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Trailmix = registerItem("trailmix",StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));

    // 1.0
    public static final class_1792 MuttonSandwich = registerItem("muttonsandwich", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));

    // 1.2
    @Deprecated(since = "Reborn 1.5.0", forRemoval = true)
    public static final class_1792 Sushi = registerItem("sushi", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));

    public static final class_1792 SquidTentacleRaw = registerItem("squidrtentacle", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 SquidTentacleCooked = registerItem("cookedsquidtentacle", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.8f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 SquidSandwich = registerItem("squidsandwich",  class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.8f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 MagicAppleJuice = registerItem("magicapplejuice", ItemBottle::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(13)
                                    .method_19237(1.2f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62859()
                                            .method_62854(new class_10132(List.of(
                                                    new class_1293(class_1294.field_5907,6000,1),
                                                    new class_1293(class_1294.field_5918,6000,1),
                                                    new class_1293(class_1294.field_5924,6000,3),
                                                    new class_1293(class_1294.field_5904,6000,1),
                                                    new class_1293(class_1294.field_5917,6000,1)
                                                    ))
                                            )
                                            .method_62851()
                            )
                    .method_7894(class_1814.field_8903)
                    .method_7889(1)
    ));
    public static final class_1792 MelonJuice = registerItem("melonjuice", ItemBottle::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.9f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62859()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,600,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));
    public static final class_1792 AppleJuice = registerItem("applejuice", ItemBottle::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(12)
                                    .method_19237(0.9f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62859()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,600,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));
    public static final class_1792 CarrotJuice = registerItem("carrotjuice", ItemBottle::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(12)
                                    .method_19237(0.9f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62859()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,600,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));
    public static final class_1792 CarrotSoup = registerItem("carrotsoup", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.8f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,100,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 PumpkinBread = registerItem("pumpkinbread",  class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(10)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 FishnChips = registerItem("fishnchips",  class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(12)
                                    .method_19237(1.2f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 SugarBiscuit = registerItem("sugarbiscuit",  class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 AppleJamBiscuit = registerItem("applejambiscuit",  class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(10)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 ChocoBiscuit = registerItem("chocolatebiscuit",  class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 CarrotPie = registerItem("carrotpie",  class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.8f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 hotchocolatebottle = registerItem("hotchocolatemilkbottle",  ItemBottle::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(1.0f)
                                    .method_19242()
                                    , class_10128.field_53780
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));
    public static final class_1792 chocolateicecream = registerItem("chocolateicecream", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.8f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));

    // 1.4
    public static final class_1792 MagicIceCream = registerItem("magicicecream", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(List.of(
                                                    new class_1293(class_1294.field_5924,100,1),
                                                    new class_1293(class_1294.field_5907,100,1)
                                                    ))
                                            )
                                            .method_62851()
                            )
                    .method_7894(class_1814.field_8903)
                    .method_7889(1)
    ));
    public static final class_1792 SquidSushi = registerItem("squidsushi", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 CactusJuice = registerItem("cactusjuice", ItemBottle::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62859()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,100,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));
    public static final class_1792 Spaghetti = registerItem("spaghetti", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 AppleIceCream = registerItem("appleicecream", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 MelonIceCream = registerItem("melonicecream", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 ChocolateApple = registerItem("chocolateapple", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(11)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 CaramelBiscuit = registerItem("caramelbiscuit", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,100,1),1.0F)
                                            )
                                            .method_62851()
                            )
    ));
    public static final class_1792 FishSoup = registerItem("fishsoup", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(12)
                                    .method_19237(0.6F)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 Tea = registerItem("tea", ItemBottle::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19242()
                                    , class_10128.field_53780
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));
    public static final class_1792 HotMilkBottle = registerItem("hotmilkbottle", ItemBottle::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(1)
                                    .method_19237(0.3f)
                                    .method_19242()
                                    , class_10128.field_53780
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));


    public static final class_1792 CheeseSandwich = registerItem("cheesesandwich", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 CaramelIceCream = registerItem("caramelicecream", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,100,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 Cereal = registerItem("cereal", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 ChocolateCereal = registerItem("chocolatecereal", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 FrenchFries = registerItem("frenchfries", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 AppleJelly = registerItem("applejelly", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.4f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5913,300,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 MelonJelly = registerItem("melonjelly", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.4f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5913,300,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7889(1)
    ));
    public static final class_1792 Donut = registerItem("donut" , class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Oreo = registerItem("oreo", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(1.0f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 CaramelToast = registerItem("carameltoast", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,100,1),1.0F)
                                            )
                                            .method_62851()
                            )
    ));
    public static final class_1792 ChocolateToast = registerItem("chocolatetoast", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 SugarToast = registerItem("sugartoast", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.2f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,100,1),1.0F)
                                            )
                                            .method_62851()
                            )
    ));
    public static final class_1792 SugarPancake = registerItem("sugarpancake", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,100,1),1.0F)
                                            )
                                            .method_62851()
                            )
    ));
    public static final class_1792 AppleJamPanCake = registerItem("applejampancake", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(15)
                                    .method_19237(0.7f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 AppleJamToast = registerItem("applejamtoast", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(10)
                                    .method_19237(0.7f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 AppleJam = registerItem("applejam", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
                    .method_7889(1)
                    .method_7896(class_1802.field_8428)
    ));
    public static final class_1792 CaramelPanCake = registerItem("caramelpancake", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(12)
                                    .method_19237(0.6f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,100,1),1.0F)
                                            )
                                            .method_62851()
                            )
    ));
    public static final class_1792 ChocolatePanCake = registerItem("chocolatepancake", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(13)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 MelonJamPanCake = registerItem("melonjampancake", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(13)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 MelonJamToast = registerItem("melonjamtoast", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 MelonJamBiscuit = registerItem("melonjambiscuit", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 MelonJam = registerItem("melonjam", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
                    .method_7889(1)
                    .method_7896(class_1802.field_8428)
    ));
    public static final class_1792 PanCakeDough = registerItem("pancakedough", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.3f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 PanCake = registerItem("pancake", class_1792::new, (
             new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));

    public static final class_1792 Sweet_Berries_Juice = registerItem("sweet_berries_juice", ItemBottle::new,(
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.3f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62859()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5924,200,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));

    public static final class_1792 Glow_Berries_Juice = registerItem("glow_berries_juice", ItemBottle::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.25f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62859()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5925,1000,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));

    public static final class_1792 Chorus_Juice = registerItem("chorus_juice", ItemBottle::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.2f)
                                    .method_19240()
                                    .method_19242()
                                    , class_10128.method_62859()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5906,200,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));

    public static final class_1792 Chorus_Jelly = registerItem("chorus_jelly", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                            .class_4175()
                                            .method_19238(7)
                                            .method_19237(0.35f)
                                            .method_19240()
                                            .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5906,200,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7889(1)
    ));

    public static final class_1792 Glow_Berries_Jelly = registerItem("glow_berries_jelly", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                            .class_4175()
                                            .method_19238(6)
                                            .method_19237(0.35f)
                                            .method_19240()
                                            .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5925,400,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7889(1)
    ));

    public static final class_1792 Sweet_Berries_Jelly = registerItem("sweet_berries_jelly", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                            .class_4175()
                                            .method_19238(7)
                                            .method_19237(0.4f)
                                            .method_19240()
                                            .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5924,200,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7889(1)
    ));

    public static final class_1792 Chorus_Ice_Cream = registerItem("chorus_ice_cream", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));

    public static final class_1792 Sweet_Berries_Ice_Cream = registerItem("sweet_berries_ice_cream", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.65f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));

    public static final class_1792 Glow_Berries_Ice_Cream = registerItem("glow_berries_ice_cream", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.55f)
                                    .method_19242()
                            )
                    .method_7889(1)
    ));

    public static final class_1792 Glow_Berries_JamPanCake = registerItem("glow_berries_jam_pancake", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(10)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Glow_Berries_JamToast = registerItem("glow_berries_jam_toast", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Glow_Berries_JamBiscuit = registerItem("glow_berries_jam_biscuit", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Glow_Berries_Jam = registerItem("glow_berries_jam", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
                    .method_7889(1)
                    .method_7896(class_1802.field_8428)
    ));

    public static final class_1792 Sweet_Berries_JamPanCake = registerItem("sweet_berries_jam_pancake", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(12)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Sweet_Berries_JamToast = registerItem("sweet_berries_jam_toast", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Sweet_Berries_JamBiscuit = registerItem("sweet_berries_jam_biscuit", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Sweet_Berries_Jam = registerItem("sweet_berries_jam", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.4f)
                                    .method_19242()
                            )
                    .method_7889(1)
                    .method_7896(class_1802.field_8428)
    ));

    public static final class_1792 Chorus_JamPanCake = registerItem("chorus_jam_pancake", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(14)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Chorus_JamToast = registerItem("chorus_jam_toast", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Chorus_JamBiscuit = registerItem("chorus_jam_biscuit", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(9)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
    ));
    public static final class_1792 Chorus_Jam = registerItem("chorus_jam", StewItem::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(7)
                                    .method_19237(0.35f)
                                    .method_19242()
                            )
                    .method_7889(1)
                    .method_7896(class_1802.field_8428)
    ));

    //Reborn 1.5.0
    public static final class_1792 Baked_Sushi = registerItem("baked_sushi", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(8)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));

    public static final class_1792 Cod_Roe_Sushi = registerItem("cod_roe_sushi", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
    ));

    public static final class_1792 Salmon_Sushi = registerItem("salmon_sushi", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
    ));

    public static final class_1792 Waffle = registerItem("waffle", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(1)
                                    .method_19237(0.1f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));

    public static final class_1792 Waffle_Chorus_Ice_Cream = registerItem("waffle_chorus_ice_cream", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(4)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));

    public static final class_1792 Waffle_Sweet_Berries_Ice_Cream = registerItem("waffle_sweet_berries_ice_cream", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));

    public static final class_1792 Waffle_Glow_Berries_Ice_Cream = registerItem("waffle_glow_berries_ice_cream", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));
    public static final class_1792 Waffle_Vanilla_IceCream = registerItem("waffle_vanilla_icecream",class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(3)
                                    .method_19237(0.3f)
                                    .method_19242()
                            ).method_7889(16)
    ));
    public static final class_1792 Waffle_chocolate_icecream = registerItem("waffle_chocolate_icecream", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(6)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));
    public static final class_1792 Waffle_Magic_IceCream = registerItem("waffle_magic_icecream", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                            .class_4175()
                                            .method_19238(7)
                                            .method_19237(0.5f)
                                            .method_19240()
                                            .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(List.of(
                                                            new class_1293(class_1294.field_5924,100,1),
                                                            new class_1293(class_1294.field_5907,100,1)
                                                    ))
                                            )
                                            .method_62851()
                            )
                    .method_7894(class_1814.field_8903)
                    .method_7889(16)
    ));
    public static final class_1792 Waffle_Apple_IceCream = registerItem("waffle_apple_icecream", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.6f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));
    public static final class_1792 Waffle_Melon_IceCream = registerItem("waffle_melon_icecream", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(5)
                                    .method_19237(0.5f)
                                    .method_19242()
                            )
                    .method_7889(16)
    ));
    public static final class_1792 Waffle_Caramel_IceCream = registerItem("waffle_caramel_icecream", class_1792::new, (
            new class_1792
                    .class_1793()
                    .method_62833
                            (new class_4174
                                            .class_4175()
                                            .method_19238(6)
                                            .method_19237(0.5f)
                                            .method_19240()
                                            .method_19242()
                                    , class_10128.method_62858()
                                            .method_62854(new class_10132(
                                                    new class_1293(class_1294.field_5904,100,1),1.0F)
                                            )
                                            .method_62851()
                            )
                    .method_7889(16)
    ));

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings.method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(UsefulFood.MOD_ID, name))));
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(UsefulFood.MOD_ID, name)), item);
    }

    public static void registerUsefulFoodItem(){
      UsefulFood.LOGGER.debug("register Useful Food Item.");
    }
}
