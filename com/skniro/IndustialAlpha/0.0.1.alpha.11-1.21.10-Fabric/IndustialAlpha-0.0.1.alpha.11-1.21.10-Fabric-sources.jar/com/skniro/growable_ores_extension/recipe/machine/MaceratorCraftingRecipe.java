package com.skniro.growable_ores_extension.recipe.machine;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.growable_ores_extension.recipe.AlchemyCraftingRecipeInput;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import net.minecraft.class_10355;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class MaceratorCraftingRecipe extends AbstractMachineCraftingRecipe {

    public MaceratorCraftingRecipe(class_1856 ingredients, class_1799 output) {
        super(ingredients, output);
    }

    @Override
    public class_1865<? extends class_1860<AlchemyCraftingRecipeInput>> method_8119() {
        return AlchemyRecipeType.MACERATOR.serializer;
    }

    @Override
    public class_3956<? extends class_1860<AlchemyCraftingRecipeInput>> method_17716() {
        return AlchemyRecipeType.MACERATOR.type;
    }

    @Override
    public class_10355 method_64668() {
        return null;
    }

    public static class Serializer implements class_1865<MaceratorCraftingRecipe> {
        public static final MapCodec<MaceratorCraftingRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
                class_1856.field_46095.fieldOf("ingredient").forGetter((recipe) -> {
                    return recipe.ingredient;
                }),
                class_1799.field_24671.fieldOf("result").forGetter((recipe) -> {
                    return recipe.output;
                })
        ).apply(inst, MaceratorCraftingRecipe::new));

        public static final class_9139<class_9129, MaceratorCraftingRecipe> STREAM_CODEC =
                class_9139.method_56435(
                        class_1856.field_48355, AbstractMachineCraftingRecipe::ingredient,
                        class_1799.field_48349, AbstractMachineCraftingRecipe::output,
                        MaceratorCraftingRecipe::new);

        public Serializer() {
        }

        public MapCodec<MaceratorCraftingRecipe> method_53736() {
            return CODEC;
        }

        public class_9139<class_9129, MaceratorCraftingRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }
}
