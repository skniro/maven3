package com.skniro.growable_ores_extension.api.item;

import com.skniro.growable_ores_extension.api.energytier.EnergyTier;

public interface TieredEnergyItem {
    EnergyTier getEnergyTier();
}