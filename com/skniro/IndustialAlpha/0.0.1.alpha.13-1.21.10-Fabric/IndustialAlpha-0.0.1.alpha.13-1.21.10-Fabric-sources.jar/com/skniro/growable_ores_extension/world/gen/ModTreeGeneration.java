package com.skniro.growable_ores_extension.world.gen;

import com.skniro.growable_ores_extension.world.feature.AgreeTreePlacedFeatures;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_1972;
import net.minecraft.class_2893;

public class ModTreeGeneration {

    public static void generateTrees() {
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(class_1972.field_9409),
                class_2893.class_2895.field_13178, AgreeTreePlacedFeatures.Rubber_TREE_PLACED);
    }
}
