package com.skniro.skniro_furniture.block.renderer;

import com.skniro.skniro_furniture.block.entity.BookDeskBlockEntity;
import com.skniro.skniro_furniture.block.init.BookDeskBlock;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_2680;
import net.minecraft.class_3715;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_557;
import net.minecraft.class_5602;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.minecraft.class_828;

@Environment(EnvType.CLIENT)
public class BookDeskBlockEntityRenderer implements class_827<BookDeskBlockEntity> {
    private final class_557 book;
    public BookDeskBlockEntityRenderer(class_5614.class_5615 ctx) {
        this.book = new class_557(ctx.method_32140(class_5602.field_27685));
    }

    @Override
    public void render(BookDeskBlockEntity bookDeskBlockEntity, float f, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, int j) {
        class_2680 blockState = bookDeskBlockEntity.method_11010();
        if (blockState.method_11654(BookDeskBlock.HAS_BOOK)) {
            matrixStack.method_22903();
            matrixStack.method_46416(0.5F, 1.1625F, 0.5F);
            matrixStack.method_46416(0.0F, 0.0F, 0.0F);
            float bookRotationDegrees = blockState.method_11654(class_3715.field_16404).method_10170().method_10144();
            matrixStack.method_22907(class_7833.field_40716.rotationDegrees(-bookRotationDegrees));
            matrixStack.method_22907(class_7833.field_40718.rotationDegrees(90F));
            matrixStack.method_22907(class_7833.field_40714.rotationDegrees(180F));
            matrixStack.method_46416(-0.15F, 0.0F, 0.0F);
            this.book.method_17073(0.0F, 0.1F, 0.9F, 1.2F);
            class_4588 vertexConsumer = class_828.field_4369.method_24145(vertexConsumerProvider, class_1921::method_23572);
            this.book.method_62100(matrixStack, vertexConsumer, i, j, -1);
            matrixStack.method_22909();
        }
    }
}