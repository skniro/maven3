package com.skniro.growable_ores_extension.block.entity.machine;

import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import com.skniro.growable_ores_extension.screen.machine.MetalFormerScreenHandler;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3913;
import net.minecraft.class_3956;
import org.jetbrains.annotations.Nullable;

public class MetalFormerBlockEntity extends AbstractMachineEntity {
    private MetalFormerState recipe_state = MetalFormerState.ROLLING;
    protected final class_3913 propertyDelegate;

    public MetalFormerBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.MetalFormer_BLOCK_ENTITY ,pos, state);
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> MetalFormerBlockEntity.this.progress;
                    case 1 -> MetalFormerBlockEntity.this.maxProgress;
                    case 2 -> recipe_state.ordinal();
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: MetalFormerBlockEntity.this.progress = value;
                    case 1: MetalFormerBlockEntity.this.maxProgress = value;
                    case 2: recipe_state = MetalFormerState.values()[value];
                }
            }

            @Override
            public int method_17389() {
                return 3;
            }
        };
    }

    @Override
    protected void method_11007(class_11372 nbt) {
        super.method_11007(nbt);
        nbt.method_71465("metal_former.state", recipe_state.ordinal());
    }

    public class_3956<?> getCurrentRecipeType() {
        return switch (recipe_state) {
            case ROLLING -> AlchemyRecipeType.METALFORMER_ROLLING.type;
            case CUTTING -> AlchemyRecipeType.METALFORMER_CUTTING.type;
            case EXTRUDING -> AlchemyRecipeType.METALFORMER_EXTRUDING.type;
        };
    }

    @Override
    protected void method_11014(class_11368 nbt) {
        if (nbt.contains("metal_former.state")) {
            this.recipe_state = MetalFormerState.values()[nbt.method_71424("metal_former.state", 0)];
        }
        super.method_11014(nbt);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.MetalFormer);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new MetalFormerScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    public void nextState() {
        recipe_state = MetalFormerState.values()[(recipe_state.ordinal() + 1) % MetalFormerState.values().length];
        method_5431();
    }

    public MetalFormerState getState() {
        return recipe_state;
    }

    public void setState(MetalFormerState state) {
        this.recipe_state = state;
        method_5431();
        if (field_11863 != null) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    public enum MetalFormerState{
        ROLLING,
        CUTTING,
        EXTRUDING;
    }

}
