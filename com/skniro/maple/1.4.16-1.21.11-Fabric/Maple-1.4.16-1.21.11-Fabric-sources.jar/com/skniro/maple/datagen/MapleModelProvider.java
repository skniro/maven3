package com.skniro.maple.datagen;

import com.skniro.maple.block.*;
import com.skniro.maple.block.api.registry.MapleModelDatagenHelper;
import com.skniro.maple.fluid.MapleFluidBlockOrItem;
import com.skniro.maple.item.GlassCupItems;
import com.skniro.maple.item.MapleArmorItems;
import com.skniro.maple.item.MapleFoodComponents;
import com.skniro.maple.item.MapleItems;
import com.skniro.maple.item.init.equipment.MapleEquipmentAssetKeys;
import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2741;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;

import static net.minecraft.class_4915.*;

public class MapleModelProvider extends FabricModelProvider {
    public MapleModelProvider(FabricDataOutput dataGenerator){
        super(dataGenerator);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator){
        class_4910.class_4912 GINKGOPool = blockStateModelGenerator.method_25650(MapleBlocks.GINKGO_PLANKS);

        GINKGOPool.method_25725(MapleBlocks.GINKGO_STAIRS);
        GINKGOPool.method_25724(MapleBlocks.GINKGO_SLAB);
        GINKGOPool.method_25716(MapleBlocks.GINKGO_BUTTON);
        GINKGOPool.method_25723(MapleBlocks.GINKGO_PRESSURE_PLATE);
        GINKGOPool.method_25721(MapleBlocks.GINKGO_FENCE);
        GINKGOPool.method_25722(MapleBlocks.GINKGO_FENCE_GATE);

        class_4910.class_4912 MaplePool = blockStateModelGenerator.method_25650(MapleBlocks.MAPLE_PLANKS);

        MaplePool.method_25725(MapleBlocks.MAPLE_STAIRS);
        MaplePool.method_25724(MapleBlocks.MAPLE_SLAB);
        MaplePool.method_25716(MapleBlocks.MAPLE_BUTTON);
        MaplePool.method_25723(MapleBlocks.MAPLE_PRESSURE_PLATE);
        MaplePool.method_25721(MapleBlocks.MAPLE_FENCE);
        MaplePool.method_25722(MapleBlocks.MAPLE_FENCE_GATE);

        class_4910.class_4912 white =blockStateModelGenerator.method_25650(class_2246.field_10087);
        white.method_25724(MapleBlocks.WHITE_STAINED_GLASS_SLAB);
        white.method_25725(MapleBlocks.WHITE_STAINED_GLASS_STAIRS);

        class_4910.class_4912 orange =blockStateModelGenerator.method_25650(class_2246.field_10227);
        orange.method_25724(MapleBlocks.ORANGE_STAINED_GLASS_SLAB);
        orange.method_25725(MapleBlocks.ORANGE_STAINED_GLASS_STAIRS);

        class_4910.class_4912 magenta =blockStateModelGenerator.method_25650(class_2246.field_10574);
        magenta.method_25724(MapleBlocks.MAGENTA_STAINED_GLASS_SLAB);
        magenta.method_25725(MapleBlocks.MAGENTA_STAINED_GLASS_STAIRS);

        class_4910.class_4912 light_blue =blockStateModelGenerator.method_25650(class_2246.field_10271);
        light_blue.method_25724(MapleBlocks.LIGHT_BLUE_STAINED_GLASS_SLAB);
        light_blue.method_25725(MapleBlocks.LIGHT_BLUE_STAINED_GLASS_STAIRS);

        class_4910.class_4912 yellow =blockStateModelGenerator.method_25650(class_2246.field_10049);
        yellow.method_25724(MapleBlocks.YELLOW_STAINED_GLASS_SLAB);
        yellow.method_25725(MapleBlocks.YELLOW_STAINED_GLASS_STAIRS);

        class_4910.class_4912 lime =blockStateModelGenerator.method_25650(class_2246.field_10157);
        lime.method_25724(MapleBlocks.LIME_STAINED_GLASS_SLAB);
        lime.method_25725(MapleBlocks.LIME_STAINED_GLASS_STAIRS);

        class_4910.class_4912 pink =blockStateModelGenerator.method_25650(class_2246.field_10317);
        pink.method_25724(MapleBlocks.PINK_STAINED_GLASS_SLAB);
        pink.method_25725(MapleBlocks.PINK_STAINED_GLASS_STAIRS);

        class_4910.class_4912 gray =blockStateModelGenerator.method_25650(class_2246.field_10555);
        gray.method_25724(MapleBlocks.GRAY_STAINED_GLASS_SLAB);
        gray.method_25725(MapleBlocks.GRAY_STAINED_GLASS_STAIRS);

        class_4910.class_4912 light_gray =blockStateModelGenerator.method_25650(class_2246.field_9996);
        light_gray.method_25724(MapleBlocks.LIGHT_GRAY_STAINED_GLASS_SLAB);
        light_gray.method_25725(MapleBlocks.LIGHT_GRAY_STAINED_GLASS_STAIRS);

        class_4910.class_4912 cyan =blockStateModelGenerator.method_25650(class_2246.field_10248);
        cyan.method_25724(MapleBlocks.CYAN_STAINED_GLASS_SLAB);
        cyan.method_25725(MapleBlocks.CYAN_STAINED_GLASS_STAIRS);

        class_4910.class_4912 purple =blockStateModelGenerator.method_25650(class_2246.field_10399);
        purple.method_25724(MapleBlocks.PURPLE_STAINED_GLASS_SLAB);
        purple.method_25725(MapleBlocks.PURPLE_STAINED_GLASS_STAIRS);

        class_4910.class_4912 blue =blockStateModelGenerator.method_25650(class_2246.field_10060);
        blue.method_25724(MapleBlocks.BLUE_STAINED_GLASS_SLAB);
        blue.method_25725(MapleBlocks.BLUE_STAINED_GLASS_STAIRS);

        class_4910.class_4912 brown =blockStateModelGenerator.method_25650(class_2246.field_10073);
        brown.method_25724(MapleBlocks.BROWN_STAINED_GLASS_SLAB);
        brown.method_25725(MapleBlocks.BROWN_STAINED_GLASS_STAIRS);

        class_4910.class_4912 green =blockStateModelGenerator.method_25650(class_2246.field_10357);
        green.method_25724(MapleBlocks.GREEN_STAINED_GLASS_SLAB);
        green.method_25725(MapleBlocks.GREEN_STAINED_GLASS_STAIRS);

        class_4910.class_4912 red =blockStateModelGenerator.method_25650(class_2246.field_10272);
        red.method_25724(MapleBlocks.RED_STAINED_GLASS_SLAB);
        red.method_25725(MapleBlocks.RED_STAINED_GLASS_STAIRS);

        class_4910.class_4912 black =blockStateModelGenerator.method_25650(class_2246.field_9997);
        black.method_25724(MapleBlocks.BLACK_STAINED_GLASS_SLAB);
        black.method_25725(MapleBlocks.BLACK_STAINED_GLASS_STAIRS);

        class_4910.class_4912 glass =blockStateModelGenerator.method_25650(class_2246.field_10033);
        glass.method_25724(MapleBlocks.GLASS_SLAB);
        glass.method_25725(MapleBlocks.GLASS_STAIRS);

        //Concrete
        class_4910.class_4912 white1 = blockStateModelGenerator.method_25650(class_2246.field_10107);
        white1.method_25724(MapleBlocks.WHITE_CONCRETE_SLAB);
        white1.method_25725(MapleBlocks.WHITE_CONCRETE_STAIRS);

        class_4910.class_4912 orange1 = blockStateModelGenerator.method_25650(class_2246.field_10210);
        orange1.method_25724(MapleBlocks.ORANGE_CONCRETE_SLAB);
        orange1.method_25725(MapleBlocks.ORANGE_CONCRETE_STAIRS);

        class_4910.class_4912 magenta1 = blockStateModelGenerator.method_25650(class_2246.field_10585);
        magenta1.method_25724(MapleBlocks.MAGENTA_CONCRETE_SLAB);
        magenta1.method_25725(MapleBlocks.MAGENTA_CONCRETE_STAIRS);

        class_4910.class_4912 light_blue1 = blockStateModelGenerator.method_25650(class_2246.field_10242);
        light_blue1.method_25724(MapleBlocks.LIGHT_BLUE_CONCRETE_SLAB);
        light_blue1.method_25725(MapleBlocks.LIGHT_BLUE_CONCRETE_STAIRS);

        class_4910.class_4912 yellow1 = blockStateModelGenerator.method_25650(class_2246.field_10542);
        yellow1.method_25724(MapleBlocks.YELLOW_CONCRETE_SLAB);
        yellow1.method_25725(MapleBlocks.YELLOW_CONCRETE_STAIRS);

        class_4910.class_4912 lime1 = blockStateModelGenerator.method_25650(class_2246.field_10421);
        lime1.method_25724(MapleBlocks.LIME_CONCRETE_SLAB);
        lime1.method_25725(MapleBlocks.LIME_CONCRETE_STAIRS);

        class_4910.class_4912 pink1 = blockStateModelGenerator.method_25650(class_2246.field_10434);
        pink1.method_25724(MapleBlocks.PINK_CONCRETE_SLAB);
        pink1.method_25725(MapleBlocks.PINK_CONCRETE_STAIRS);

        class_4910.class_4912 gray1 = blockStateModelGenerator.method_25650(class_2246.field_10038);
        gray1.method_25724(MapleBlocks.GRAY_CONCRETE_SLAB);
        gray1.method_25725(MapleBlocks.GRAY_CONCRETE_STAIRS);

        class_4910.class_4912 light_gray1 = blockStateModelGenerator.method_25650(class_2246.field_10172);
        light_gray1.method_25724(MapleBlocks.LIGHT_GRAY_CONCRETE_SLAB);
        light_gray1.method_25725(MapleBlocks.LIGHT_GRAY_CONCRETE_STAIRS);

        class_4910.class_4912 cyan1 = blockStateModelGenerator.method_25650(class_2246.field_10308);
        cyan1.method_25724(MapleBlocks.CYAN_CONCRETE_SLAB);
        cyan1.method_25725(MapleBlocks.CYAN_CONCRETE_STAIRS);

        class_4910.class_4912 purple1 = blockStateModelGenerator.method_25650(class_2246.field_10206);
        purple1.method_25724(MapleBlocks.PURPLE_CONCRETE_SLAB);
        purple1.method_25725(MapleBlocks.PURPLE_CONCRETE_STAIRS);

        class_4910.class_4912 blue1 = blockStateModelGenerator.method_25650(class_2246.field_10011);
        blue1.method_25724(MapleBlocks.BLUE_CONCRETE_SLAB);
        blue1.method_25725(MapleBlocks.BLUE_CONCRETE_STAIRS);

        class_4910.class_4912 brown1 = blockStateModelGenerator.method_25650(class_2246.field_10439);
        brown1.method_25724(MapleBlocks.BROWN_CONCRETE_SLAB);
        brown1.method_25725(MapleBlocks.BROWN_CONCRETE_STAIRS);

        class_4910.class_4912 green1 = blockStateModelGenerator.method_25650(class_2246.field_10367);
        green1.method_25724(MapleBlocks.GREEN_CONCRETE_SLAB);
        green1.method_25725(MapleBlocks.GREEN_CONCRETE_STAIRS);

        class_4910.class_4912 red1 = blockStateModelGenerator.method_25650(class_2246.field_10058);
        red1.method_25724(MapleBlocks.RED_CONCRETE_SLAB);
        red1.method_25725(MapleBlocks.RED_CONCRETE_STAIRS);

        class_4910.class_4912 black1 = blockStateModelGenerator.method_25650(class_2246.field_10458);
        black1.method_25724(MapleBlocks.BLACK_CONCRETE_SLAB);
        black1.method_25725(MapleBlocks.BLACK_CONCRETE_STAIRS);

        //Cube Block
        blockStateModelGenerator.method_25650(MapleBlocks.CHERRY_PLANKS);
        blockStateModelGenerator.method_25650(MapleBlocks.BAMBOO_PLANKS);
        blockStateModelGenerator.method_25650(MapleBlocks.BAMBOO_MOSAIC);
        blockStateModelGenerator.method_25650(MapleOreBlocks.Salt_Ore);
        blockStateModelGenerator.method_25650(MapleOreBlocks.DEEPSLATE_Salt_Ore);
        blockStateModelGenerator.method_25650(MapleNetherOresBlocks.Nether_Coal_Ore);
        blockStateModelGenerator.method_25650(MapleNetherOresBlocks.Nether_Copper_Ore);
        blockStateModelGenerator.method_25650(MapleNetherOresBlocks.Nether_Diamond_Ore);
        blockStateModelGenerator.method_25650(MapleNetherOresBlocks.Nether_Emerald_Ore);
        blockStateModelGenerator.method_25650(MapleNetherOresBlocks.Nether_Gold_Ore);
        blockStateModelGenerator.method_25650(MapleNetherOresBlocks.Nether_Iron_Ore);
        blockStateModelGenerator.method_25650(MapleNetherOresBlocks.Nether_Lapis_Ore);
        blockStateModelGenerator.method_25650(MapleNetherOresBlocks.Nether_Redstone_Ore);

        //LOG Block
        blockStateModelGenerator.method_25676(MapleBlocks.MAPLE_LOG).method_25730(MapleBlocks.MAPLE_LOG).method_25728(MapleBlocks.MAPLE_WOOD);
        blockStateModelGenerator.method_25676(MapleBlocks.STRIPPED_MAPLE_LOG).method_25730(MapleBlocks.STRIPPED_MAPLE_LOG).method_25728(MapleBlocks.STRIPPED_MAPLE_WOOD);
        blockStateModelGenerator.method_25676(MapleBlocks.GINKGO_LOG).method_25730(MapleBlocks.GINKGO_LOG).method_25728(MapleBlocks.GINKGO_WOOD);
        blockStateModelGenerator.method_25676(MapleBlocks.STRIPPED_GINKGO_LOG).method_25730(MapleBlocks.STRIPPED_GINKGO_LOG).method_25728(MapleBlocks.STRIPPED_GINKGO_WOOD);

        //Door
        blockStateModelGenerator.method_25658(MapleBlocks.MAPLE_DOOR);
        blockStateModelGenerator.method_25658(MapleBlocks.CHERRY_DOOR);
        blockStateModelGenerator.method_25658(MapleBlocks.BAMBOO_DOOR);
        blockStateModelGenerator.method_25658(MapleBlocks.GINKGO_DOOR);

        //TRAPDOOR
        blockStateModelGenerator.method_25671(MapleBlocks.CHERRY_TRAPDOOR);
        blockStateModelGenerator.method_25671(MapleBlocks.MAPLE_TRAPDOOR);
        blockStateModelGenerator.method_25671(MapleBlocks.BAMBOO_TRAPDOOR);
        blockStateModelGenerator.method_25671(MapleBlocks.GINKGO_TRAPDOOR);

        //SAPLING
        blockStateModelGenerator.method_65407(MapleBlocks.CHERRY_SAPLING, MapleBlocks.POTTED_CHERRY_SAPLING, class_4910.class_4913.field_22840);
        blockStateModelGenerator.method_65407(MapleBlocks.MAPLE_SAPLING, MapleBlocks.POTTED_MAPLE_SAPLING, class_4910.class_4913.field_22840);
        blockStateModelGenerator.method_65407(MapleBlocks.RED_MAPLE_SAPLING, MapleBlocks.POTTED_RED_MAPLE_SAPLING, class_4910.class_4913.field_22840);
        blockStateModelGenerator.method_65407(MapleBlocks.SAKURA_SAPLING, MapleBlocks.POTTED_SAKURA_SAPLING, class_4910.class_4913.field_22840);
        blockStateModelGenerator.method_65407(MapleBlocks.GINKGO_SAPLING, MapleBlocks.POTTED_GINKGO_SAPLING, class_4910.class_4913.field_22840);

        //Crop
        blockStateModelGenerator.method_25547(MapleBlocks.RICE, class_2741.field_12550, 0, 0, 0, 1, 1, 1, 1, 2);
        MapleModelDatagenHelper mapleModelDatagenHelper = new MapleModelDatagenHelper(blockStateModelGenerator);
        mapleModelDatagenHelper.registerModSweetBerryBush(MapleFoodComponents.Green_Tea_Leaves, MapleBlocks.Tea_Block);

        //Block and Carpet
        blockStateModelGenerator.method_25642(MapleBlocks.SAKURA_LEAVES,MapleBlocks.SAKURA_CARPET);
        blockStateModelGenerator.method_25642(MapleBlocks.MAPLE_LEAVES,MapleBlocks.Maple_CARPET);
        blockStateModelGenerator.method_25642(MapleBlocks.GINKGO_LEAVES,MapleBlocks.GINKGO_CARPET);
        blockStateModelGenerator.method_25642(MapleBlocks.RED_MAPLE_LEAVES,MapleBlocks.RED_MAPLE_CARPET);


        class_4910.class_4912 tatami =blockStateModelGenerator.method_25650(MapleBlocks.TATAMI);
        tatami.method_25724(MapleBlocks.TATAMI_SLAB);

        //PLASTER
        blockStateModelGenerator.method_25650(MapleBlocks.GREEN_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.ORANGE_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.MAGENTA_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.LIGHT_BLUE_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.YELLOW_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.LIME_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.PINK_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.GRAY_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.LIGHT_GRAY_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.CYAN_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.PURPLE_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.BLUE_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.BROWN_PLASTER);
        blockStateModelGenerator.method_25650(MapleBlocks.RED_PLASTER);

        //Sea Lantern
        blockStateModelGenerator.method_25650(MapleBlocks.Iron_Sea_Lantern);
        blockStateModelGenerator.method_25650(MapleBlocks.Gold_Sea_Lantern);

        //Cushion
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_OAK_BLACK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_SPRUCE_BLACK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BIRCH_BLACK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_JUNGLE_BLACK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_ACACIA_BLACK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_DARK_OAK_BLACK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CRIMSON_BLACK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_WARPED_BLACK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MANGROVE_BLACK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_MAPLE_BLACK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_CHERRY_BLACK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_GINKGO_BLACK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_WHITE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_ORANGE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_MAGENTA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_LIGHT_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_YELLOW);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_LIME);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_PINK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_LIGHT_GRAY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_CYAN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_PURPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_BLUE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_BROWN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_GREEN);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_RED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.CUSHION_BAMBOO_BLACK);

        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_OAK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_SPRUCE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_BIRCH);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_JUNGLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_ACACIA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_DARK_OAK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_CRIMSON);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_WARPED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_MANGROVE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_BAMBOO);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_CHERRY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_MAPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TABLE_GINKGO);

        //CoffeeTable
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_WOOD_OAK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_WOOD_SPRUCE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_WOOD_BIRCH);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_WOOD_JUNGLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_WOOD_ACACIA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_WOOD_DARK_OAK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_WOOD_CRIMSON);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_WOOD_WARPED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_WOOD_MANGROVE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_WOOD_BAMBOO);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_WOOD_CHERRY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_Wood_MAPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_Wood_GINKGO);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_OAK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_SPRUCE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_BIRCH);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_JUNGLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_ACACIA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_DARK_OAK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_CRIMSON);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_WARPED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_MANGROVE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_BAMBOO);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_CHERRY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_MAPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Coffee_Table_PLANK_GINKGO);

        //Chair
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_WOOD_OAK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_WOOD_SPRUCE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_WOOD_BIRCH);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_WOOD_JUNGLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_WOOD_ACACIA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_WOOD_DARK_OAK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_WOOD_CRIMSON);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_WOOD_WARPED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_WOOD_MANGROVE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_WOOD_BAMBOO);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_WOOD_CHERRY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_Wood_MAPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_Wood_GINKGO);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_OAK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_SPRUCE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_BIRCH);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_JUNGLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_ACACIA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_DARK_OAK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_CRIMSON);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_WARPED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_MANGROVE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_BAMBOO);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_CHERRY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_MAPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.Chair_PLANK_GINKGO);

        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_OAK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_SPRUCE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_BIRCH);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_JUNGLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_ACACIA);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_DARK_OAK);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_CRIMSON);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_WARPED);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_MANGROVE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_BAMBOO);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_CHERRY);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_MAPLE);
        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.END_TABLE_GINKGO);

        blockStateModelGenerator.method_25708(MapleBlocks.Maple_Juicer_Block);
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        itemModelGenerator.method_65442(GlassCupItems.HIGH_GLASS_CUP, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.MILK_BOTTOM, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.MapleSyrup, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.Flour, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.Cream, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.SOYBEAN, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.Salt, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.BAMBOO_BOAT, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.BAMBOO_CHEST_BOAT, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Anko_Dango, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Beef_Rice, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Cheese, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Mochi, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Cooked_Rice, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Kinako_Dango, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.MILK_ICECREAM, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.SakuraMochi, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Sanshoku_Dango, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.TOFU, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Zunda_Dango, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Chorus_Juice, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.AppleJuice, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.CarrotJuice, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.MelonJuice, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Sweet_Berries_Juice, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Glow_Berries_Juice, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.GINKGO_BOAT, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.GINKGO_CHEST_BOAT, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.MAPLE_BOAT, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.MAPLE_CHEST_BOAT, class_4943.field_22938);


        itemModelGenerator.method_65441(MapleItems.SNOWBALL_STONE, class_1802.field_8543, class_4943.field_22938);
        itemModelGenerator.method_65441(MapleItems.SNOWBALL_Diamond, class_1802.field_8543, class_4943.field_22938);
        itemModelGenerator.method_65441(MapleItems.SNOWBALL_Gold, class_1802.field_8543, class_4943.field_22938);
        itemModelGenerator.method_65441(MapleItems.SNOWBALL_ICE, class_1802.field_8543, class_4943.field_22938);
        itemModelGenerator.method_65441(MapleItems.SNOWBALL_IRON, class_1802.field_8543, class_4943.field_22938);
        itemModelGenerator.method_65441(MapleItems.SNOWBALL_Compression, class_1802.field_8543, class_4943.field_22938);
        itemModelGenerator.method_65441(MapleItems.SNOWBALL_Teleporting, class_1802.field_8543, class_4943.field_22938);
        itemModelGenerator.method_65441(MapleItems.SNOWBALL_Confusion, class_1802.field_8543, class_4943.field_22938);
        itemModelGenerator.method_65441(MapleItems.SNOWBALL_Instant_Health, class_1802.field_8543, class_4943.field_22938);
        itemModelGenerator.method_65441(MapleItems.SNOWBALL_Poison, class_1802.field_8543, class_4943.field_22938);

        itemModelGenerator.method_65442(MapleFluidBlockOrItem.Hot_Spring_BUCKET, class_4943.field_22938);

        //Cherry tools
        itemModelGenerator.method_65442(MapleArmorItems.Cherry_NUGGET, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleArmorItems.Cherry_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleArmorItems.Cherry_PICKAXE, class_4943.field_22939);
        itemModelGenerator.method_65442(MapleArmorItems.Cherry_AXE, class_4943.field_22939);
        itemModelGenerator.method_65442(MapleArmorItems.Cherry_SHOVEL, class_4943.field_22939);
        itemModelGenerator.method_65442(MapleArmorItems.Cherry_SWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(MapleArmorItems.Cherry_HOE, class_4943.field_22939);

        //Cherry armors
        itemModelGenerator.method_65429(MapleArmorItems.Cherry_HELMET, MapleEquipmentAssetKeys.Cherry, field_56347, false);
        itemModelGenerator.method_65429(MapleArmorItems.Cherry_CHESTPLATE, MapleEquipmentAssetKeys.Cherry, field_56348, false);
        itemModelGenerator.method_65429(MapleArmorItems.Cherry_LEGGINGS, MapleEquipmentAssetKeys.Cherry, field_56349, false);
        itemModelGenerator.method_65429(MapleArmorItems.Cherry_BOOTS, MapleEquipmentAssetKeys.Cherry, field_56350, false);

        //Sign
        itemModelGenerator.method_65442(MapleItems.Maple_HANGING_SIGN, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.GINKGO_HANGING_SIGN, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.MAPLE_SIGN, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleItems.GINKGO_SIGN, class_4943.field_22938);

        //Tea
        itemModelGenerator.method_65442(MapleFoodComponents.Green_Tea, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Red_Tea, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleFoodComponents.Red_Tea_Leaves, class_4943.field_22938);
    }
}
