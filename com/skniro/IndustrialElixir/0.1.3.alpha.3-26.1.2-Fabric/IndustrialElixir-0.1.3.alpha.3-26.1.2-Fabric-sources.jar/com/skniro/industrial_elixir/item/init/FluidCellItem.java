package com.skniro.industrial_elixir.item.init;

import net.minecraft.world.item.Item;

public class FluidCellItem extends Item {
    public FluidCellItem(Properties properties) {
        super(properties);
    }
}
