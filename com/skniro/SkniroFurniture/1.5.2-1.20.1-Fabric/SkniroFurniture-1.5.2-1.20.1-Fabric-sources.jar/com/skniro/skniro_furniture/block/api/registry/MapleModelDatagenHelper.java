package com.skniro.skniro_furniture.block.api.registry;

import com.mojang.datafixers.util.Pair;
import com.skniro.skniro_furniture.block.init.FurnitureBedBlock;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_2742;
import net.minecraft.class_2750;
import net.minecraft.class_2756;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4918;
import net.minecraft.class_4922;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4935;
import net.minecraft.class_4936;
import net.minecraft.class_4941;
import net.minecraft.class_4942;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.data.client.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static net.minecraft.class_4910.method_25565;
import static net.minecraft.class_4910.method_25599;


public class MapleModelDatagenHelper {
    private final class_4910 generator;
    private static final Map<ChiseledBookshelfModelCacheKey, class_2960> CHISELED_BOOKSHELF_MODEL_CACHE = new HashMap();;

    public MapleModelDatagenHelper(class_4910 generator) {
        this.generator = generator;
    }

    public void registerModSweetBerryBush(class_1792 fruititem, class_2248 block) {
        generator.method_25537(fruititem);
        generator.field_22830.accept(class_4925.method_25769(block)
                .method_25775(class_4926.method_25783(class_2741.field_12497).method_25795(stage ->
                        class_4935.method_25824().method_25828(class_4936.field_22887,
                                generator.method_25557(block, "_stage" + stage, class_4943.field_22921, class_4944::method_25880)
                        )
                ))
        );
    }

    public void registerModBookshelf(class_2248 block, class_2248 plank) {
        class_4944 textureMap = class_4944.method_25870(class_4944.method_25860(block), class_4944.method_25860(plank));
        class_2960 identifier = class_4943.field_22974.method_25846(block, textureMap, generator.field_22831);
        generator.field_22830.accept(class_4910.method_25644(block, identifier));
    }

    public void registerLamp(class_2248 block) {
        class_2960 identifier = class_4941.method_25842(block);
        class_2960 identifier2 = class_4941.method_25843(block,"_on");
        generator.field_22830.accept(class_4925.method_25769(block).method_25775(method_25565(class_2741.field_12548, identifier2, identifier)));
    }

    public void registerFridge(class_2248 block) {
        class_2960 bottomModel = class_4941.method_25843(block, "_bottom");
        class_2960 topModel = class_4941.method_25843(block, "_top");

        class_4926.class_4928<class_2350, class_2756> variantMap =
                class_4926.method_25784(class_2741.field_12481, class_2741.field_12533);

        fillSimpleDoubleVariantMap(variantMap, class_2756.field_12607, bottomModel);
        fillSimpleDoubleVariantMap(variantMap, class_2756.field_12609, topModel);

        generator.field_22830.accept(class_4925.method_25769(block).method_25775(variantMap));
    }


    public static class_4926.class_4928<class_2350, class_2756> fillSimpleDoubleVariantMap(
            class_4926.class_4928<class_2350, class_2756> variantMap,
            class_2756 targetHalf,
            class_2960 baseModelId
    ) {
        return variantMap
                .method_25797(class_2350.field_11043, targetHalf, class_4935.method_25824().method_25828(class_4936.field_22887, baseModelId))
                .method_25797(class_2350.field_11034, targetHalf, class_4935.method_25824().method_25828(class_4936.field_22887, baseModelId).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                .method_25797(class_2350.field_11035, targetHalf, class_4935.method_25824().method_25828(class_4936.field_22887, baseModelId).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                .method_25797(class_2350.field_11039, targetHalf, class_4935.method_25824().method_25828(class_4936.field_22887, baseModelId).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893));
    }

    public void registerModChiseledBookshelf(class_2248 block) {
        class_2960 identifier = class_4941.method_25842(block);
        class_4922 multipartBlockStateSupplier = class_4922.method_25758(block);
        List.of(Pair.of(class_2350.field_11043, class_4936.class_4937.field_22890), Pair.of(class_2350.field_11034, class_4936.class_4937.field_22891), Pair.of(class_2350.field_11035, class_4936.class_4937.field_22892), Pair.of(class_2350.field_11039, class_4936.class_4937.field_22893)).forEach((pair) -> {
            class_2350 direction = (class_2350)pair.getFirst();
            class_4936.class_4937 rotation = (class_4936.class_4937)pair.getSecond();
            class_4918.class_4921 propertyCondition = class_4918.method_25744().method_25751(class_2741.field_12481, direction);
            multipartBlockStateSupplier.method_25760(propertyCondition, class_4935.method_25824().method_25828(class_4936.field_22887, identifier).method_25828(class_4936.field_22886, rotation).method_25828(class_4936.field_22888, true));
            generator.method_47812(multipartBlockStateSupplier, propertyCondition, rotation);
        });
        generator.field_22830.accept(multipartBlockStateSupplier);
        generator.method_25623(block, class_4941.method_25843(block, "_inventory"));
        CHISELED_BOOKSHELF_MODEL_CACHE.clear();
    }

    @Environment(EnvType.CLIENT)
    static record ChiseledBookshelfModelCacheKey(class_4942 template, String modelSuffix) {
        ChiseledBookshelfModelCacheKey(class_4942 template, String modelSuffix) {
            this.template = template;
            this.modelSuffix = modelSuffix;
        }

        public class_4942 template() {
            return this.template;
        }

        public String modelSuffix() {
            return this.modelSuffix;
        }
    }

    public void registerPaperSlidingDoor(class_2248 doorBlock) {
        class_2960 Identifier = class_4941.method_25843(doorBlock, "_bottom_left");
        class_2960 Identifier2 = class_4941.method_25843(doorBlock, "_bottom_left_open");
        class_2960 Identifier3 = class_4941.method_25843(doorBlock, "_bottom_right");
        class_2960 Identifier4 = class_4941.method_25843(doorBlock, "_bottom_right_open");
        class_2960 Identifier5 = class_4941.method_25843(doorBlock, "_top_left");
        class_2960 Identifier6 = class_4941.method_25843(doorBlock, "_top_left_open");
        class_2960 Identifier7 = class_4941.method_25843(doorBlock, "_top_right");
        class_2960 Identifier8 = class_4941.method_25843(doorBlock, "_top_right_open");
        generator.field_22830.accept(createDoorBlockState(doorBlock, Identifier, Identifier2, Identifier3, Identifier4, Identifier5, Identifier6, Identifier7, Identifier8));
    }

    public static class_4925 createDoorBlockState(class_2248 doorBlock, class_2960 bottomLeftClosedModel, class_2960 bottomLeftOpenModel, class_2960 bottomRightClosedModel, class_2960 bottomRightOpenModel, class_2960 topLeftClosedModel, class_2960 topLeftOpenModel, class_2960 topRightClosedModel, class_2960 topRightOpenModel) {
        return class_4925.method_25769(doorBlock)
                .method_25775(class_4926
                        .method_25786(class_2741.field_12481, class_2741.field_12533, class_2741.field_12520, class_2741.field_12537)
                        .method_25811(class_2350.field_11034,  class_2756.field_12607, class_2750.field_12588,  false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomLeftClosedModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12607, class_2750.field_12588,  false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomLeftClosedModel))
                        .method_25811(class_2350.field_11039,  class_2756.field_12607, class_2750.field_12588,  false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomLeftClosedModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12607, class_2750.field_12588,  false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomLeftClosedModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))

                        .method_25811(class_2350.field_11034,  class_2756.field_12607, class_2750.field_12586, false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomRightClosedModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12607, class_2750.field_12586, false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomRightClosedModel))
                        .method_25811(class_2350.field_11039,  class_2756.field_12607, class_2750.field_12586, false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomRightClosedModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12607, class_2750.field_12586, false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomRightClosedModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))

                        .method_25811(class_2350.field_11034,  class_2756.field_12607, class_2750.field_12588,  true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomLeftOpenModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12607, class_2750.field_12588,  true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomLeftOpenModel))
                        .method_25811(class_2350.field_11039,  class_2756.field_12607, class_2750.field_12588,  true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomLeftOpenModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12607, class_2750.field_12588,  true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomLeftOpenModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))

                        .method_25811(class_2350.field_11034,  class_2756.field_12607, class_2750.field_12586, true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomRightOpenModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12607, class_2750.field_12586, true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomRightOpenModel))
                        .method_25811(class_2350.field_11039,  class_2756.field_12607, class_2750.field_12586, true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomRightOpenModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12607, class_2750.field_12586, true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, bottomRightOpenModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))

                        .method_25811(class_2350.field_11034,  class_2756.field_12609, class_2750.field_12588,  false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topLeftClosedModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12609, class_2750.field_12588,  false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topLeftClosedModel))
                        .method_25811(class_2350.field_11039,  class_2756.field_12609, class_2750.field_12588,  false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topLeftClosedModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12609, class_2750.field_12588,  false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topLeftClosedModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))

                        .method_25811(class_2350.field_11034,  class_2756.field_12609, class_2750.field_12586, false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topRightClosedModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12609, class_2750.field_12586, false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topRightClosedModel))
                        .method_25811(class_2350.field_11039,  class_2756.field_12609, class_2750.field_12586, false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topRightClosedModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12609, class_2750.field_12586, false,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topRightClosedModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))

                        .method_25811(class_2350.field_11034,  class_2756.field_12609, class_2750.field_12588,  true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topLeftOpenModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12609, class_2750.field_12588,  true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topLeftOpenModel))
                        .method_25811(class_2350.field_11039,  class_2756.field_12609, class_2750.field_12588,  true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topLeftOpenModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12609, class_2750.field_12588,  true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topLeftOpenModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))

                        .method_25811(class_2350.field_11034,  class_2756.field_12609, class_2750.field_12586, true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topRightOpenModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                        .method_25811(class_2350.field_11035, class_2756.field_12609, class_2750.field_12586, true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topRightOpenModel))
                        .method_25811(class_2350.field_11039,  class_2756.field_12609, class_2750.field_12586, true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topRightOpenModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        .method_25811(class_2350.field_11043, class_2756.field_12609, class_2750.field_12586, true,
                                class_4935.method_25824().method_25828(class_4936.field_22887, topRightOpenModel).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                );
    }

    public final void registerBed(class_2248 block) {
        class_2960 headModel = class_4941.method_25843(block, "_head");
        class_2960 footModel = class_4941.method_25843(block, "_foot");

        class_4926.class_4928<class_2350, class_2742> variantMap =
                class_4926.method_25784(class_2741.field_12481, FurnitureBedBlock.PART);

        fillSimpleDoubleVariantMap(variantMap, class_2742.field_12560, headModel);
        fillSimpleDoubleVariantMap(variantMap, class_2742.field_12557, footModel);
        generator.field_22830.accept(class_4925.method_25769(block).method_25775(variantMap));
    }

    public void registerTV(class_2248 block) {
        class_2960 identifier = class_4941.method_25842(block);
        class_2960 identifier2 = class_4941.method_25843(block,"_open");
        generator.field_22830.accept(class_4925.method_25769(block).method_25775(method_25565(class_2741.field_12548, identifier2, identifier)).method_25775(method_25599()));
    }

    public static class_4926.class_4928<class_2350, class_2742> fillSimpleDoubleVariantMap(
            class_4926.class_4928<class_2350, class_2742> variantMap,
            class_2742 targetHalf,
            class_2960 baseModelId
    ) {
        return variantMap
                .method_25797(class_2350.field_11043, targetHalf, class_4935.method_25824().method_25828(class_4936.field_22887, baseModelId))
                .method_25797(class_2350.field_11034, targetHalf, class_4935.method_25824().method_25828(class_4936.field_22887, baseModelId).method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                .method_25797(class_2350.field_11035, targetHalf, class_4935.method_25824().method_25828(class_4936.field_22887, baseModelId).method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                .method_25797(class_2350.field_11039, targetHalf, class_4935.method_25824().method_25828(class_4936.field_22887, baseModelId).method_25828(class_4936.field_22886, class_4936.class_4937.field_22893));
    }
}