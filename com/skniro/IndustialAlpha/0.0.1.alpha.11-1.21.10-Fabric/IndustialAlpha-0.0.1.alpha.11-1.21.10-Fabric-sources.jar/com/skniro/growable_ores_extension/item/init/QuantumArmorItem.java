package com.skniro.growable_ores_extension.item.init;

import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.api.item.TieredEnergyItem;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.base.SimpleEnergyItem;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class QuantumArmorItem extends class_1792 implements SimpleEnergyItem, TieredEnergyItem {
    private EnergyTier energyTier;
    public static final long CAPACITY = 10000000;

    public QuantumArmorItem(class_1793 settings, EnergyTier energyTier) {
        super(settings);
        this.energyTier = energyTier;
        EnergyStorage.ITEM.registerForItems((stack, context) -> SimpleEnergyItem.createStorage(context, this.getEnergyCapacity(stack), this.getEnergyMaxInput(stack), this.getEnergyMaxOutput(stack)), this);
    }

    @Override
    public long getEnergyCapacity(class_1799 stack) {
        return CAPACITY;
    }

    @Override
    public long getEnergyMaxInput(class_1799 stack) {
        return 200;
    }

    @Override
    public long getEnergyMaxOutput(class_1799 stack) {
        return 200;
    }

    @Override
    public EnergyTier getEnergyTier() {
        return energyTier;
    }

    @Override
    public boolean method_31567(class_1799 stack) {
        return true;
    }

    @Override
    public int method_31569(class_1799 stack) {
        return getPowerForDurabilityBar(stack);
    }

    public static int getPowerForDurabilityBar(class_1799 stack) {
        class_1792 var2 = stack.method_7909();
        if (var2 instanceof BatteryItem energyItem) {
            return Math.round((float)energyItem.getStoredEnergy(stack) * 100.0F / (float)energyItem.getEnergyCapacity(stack) * 13.0F) / 100;
        } else {
            throw new UnsupportedOperationException();
        }
    }

    @Override
    public int method_31571(class_1799 stack) {
        return 0x00FFFF;
    }
}