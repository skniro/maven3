package com.skniro.skniro_furniture.screen;

import com.skniro.skniro_furniture.Furniture;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class FurnitureScreenHandlerType<T extends class_1703>{
    public static final class_3917<KitchenSinkBlockScreenHandler> Kitchen_Sink_Block_Screen_Handler =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Furniture.MOD_ID, "kitchen_sink_screen_handler"),
                    new ExtendedScreenHandlerType<>(KitchenSinkBlockScreenHandler::new, class_2338.field_48404));

    public static void RegisterFurnitureScreenHandlerType () {
        Furniture.LOGGER.info("Registering Screen Handler for " + Furniture.MOD_ID);
    }
}
