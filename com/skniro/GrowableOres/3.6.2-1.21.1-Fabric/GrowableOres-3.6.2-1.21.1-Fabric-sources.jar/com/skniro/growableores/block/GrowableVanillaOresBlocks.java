package com.skniro.growableores.block;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.init.GrowableOreCaneBlock;
import com.skniro.growableores.util.GrowableOresItemGroups;
import java.util.logging.Logger;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public class GrowableVanillaOresBlocks {
    //Village
    public static final class_2248 Iron_Cane =registerBlock("iron_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)), GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Coal_Cane =registerBlock("coal_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Emerald_Cane =registerBlock("emerald_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Gold_Cane =registerBlock("gold_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Redstone_Cane =registerBlock("redstone_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Nether_Quartz_Cane =registerBlock("nether_quartz_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Lapis_Cane =registerBlock("lapis_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Diamond_Cane =registerBlock("diamond_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Copper_Cane =registerBlock("copper_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Blaze_Rod_Cane =registerBlock("blaze_rod_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Ender_Pearl_Cane =registerBlock("ender_pearl_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);

    public static final class_2248 Netherite_Ingot_Cane = registerBlock("netherite_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Netherite_Scrap_Cane = registerBlock("netherite_scrap_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Clay_Cane = registerBlock("clay_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Slime_Cane = registerBlock("slime_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Nether_Star_Cane = registerBlock("nether_star_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Glowstone_Cane = registerBlock("glowstone_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Bone_Cane = registerBlock("bone_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Egg_Cane = registerBlock("egg_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Feather_Cane = registerBlock("feather_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Wool_Cane = registerBlock("wool_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Gunpowder_Cane = registerBlock("gunpowder_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Leather_Cane = registerBlock("leather_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);

    public static final class_2248 Oak_Log_Cane = registerBlock("oak_log_cane",new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Spruce_Log_Cane = registerBlock("spruce_log_cane",new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Birch_Log_Cane = registerBlock("birch_log_cane",new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Jungle_Log_Cane = registerBlock("jungle_log_cane",new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Acacia_Log_Cane = registerBlock("acacia_log_cane",new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Dark_Oak_Log_Cane = registerBlock("dark_oak_log_cane",new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Mangrove_Log_Cane = registerBlock("mangrove_log_cane",new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Bamboo_Block_Cane = registerBlock("bamboo_block_cane",new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Cherry_Log_Cane = registerBlock("cherry_log_cane",new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Crimson_Stem_Cane = registerBlock("crimson_stem_cane",new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Warped_Stem_Cane = registerBlock("warped_stem_cane",new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Amethyst_Shard_Cane = registerBlock("amethyst_shard_cane",new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Prismarine_Crystals_Cane = registerBlock("prismarine_crystals_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11537).method_50012(class_3619.field_15971)), GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Prismarine_Shard_Cane = registerBlock("prismarine_shard_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11537).method_50012(class_3619.field_15971)), GrowableOresItemGroups.Growable_Ores_Group);

    public static final class_2248 String_Cane = registerBlock("string_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11537).method_50012(class_3619.field_15971)), GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Sand_Cane = registerBlock("sand_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11537).method_50012(class_3619.field_15971)), GrowableOresItemGroups.Growable_Ores_Group);



    private static class_2248 registerBlock(String name, class_2248 block, class_5321<class_1761> tab) {
        registerBlockItem(name, block, tab);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(GrowableOres.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_5321<class_1761> tab) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(GrowableOres.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
    }
    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + GrowableOres.MOD_ID);
    }
}

