package com.skniro.growable_ores_extension.client;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.block.renderer.AlchemyblockentityRenderer;
import com.skniro.growable_ores_extension.block.renderer.pipe.WoodenPipeRenderer;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.energybox.ChargePadBlockScreen;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.energybox.EnergyBoxBlockScreen;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.generator.CoalGeneratorScreen;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.generator.GeneratorSolarPanelScreen;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.generator.GeneratorWindMillScreen;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.machine.*;
import com.skniro.growable_ores_extension.entity.MapleEntityType;
import com.skniro.growable_ores_extension.screen.AlchemyScreenHandlerType;
import com.skniro.growableoresir.client.GrowableOresClienttwo;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.object.boat.BoatModel;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.entity.BoatRenderer;
import net.minecraft.resources.Identifier;

@Environment(EnvType.CLIENT)
public class GrowableOresClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ChunkSectionLayer renderLayer2 = ChunkSectionLayer.CUTOUT;
        ModItemBlockRenderTypes.setRenderLayer(GeneralBlocks.Rubber_SAPLING, renderLayer2);
        ModItemBlockRenderTypes.setRenderLayer(GeneralBlocks.Rubber_LEAVES, renderLayer2);
        ModItemBlockRenderTypes.setRenderLayer(GrowableOresBlocks.GLASSFIBER_CABLE, renderLayer2);
        ModItemBlockRenderTypes.setRenderLayer(GrowableOresBlocks.Pipe_Stone_Item_Block, renderLayer2);
        ModItemBlockRenderTypes.setRenderLayer(GrowableOresBlocks.Pipe_Wooden_Iten_Block, renderLayer2);

        MenuScreens.register(AlchemyScreenHandlerType.ALCHEMY, AlchemyBlockScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.COAL_GENERATOR_SCREEN_HANDLER, CoalGeneratorScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.Macerator, MaceratorBlockScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.Compressor, CompressorBlockScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.GENERATOR_Wind_Mill_SCREEN_HANDLER, GeneratorWindMillScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.GENERATOR_Solar_Panel_SCREEN_HANDLER, GeneratorSolarPanelScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.MetalFormer, MetalFormerBlockScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.ChargePad, ChargePadBlockScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.EnergyBox, EnergyBoxBlockScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.MolecularTransformer, MolecularTransformerBlockScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.Extractor, ExtractorBlockScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.ElectricFurnace, ElectricFurnaceBlockScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.Cutting, CuttingBlockScreen::new);
        MenuScreens.register(AlchemyScreenHandlerType.Recycler, RecyclerBlockScreen::new);

        BlockEntityRenderers.register(AlchemyBlockEntityType.ALCHEMY_BLOCK_ENTITY, AlchemyblockentityRenderer::new);
        BlockEntityRenderers.register(AlchemyBlockEntityType.PIPE_Wooden_BLOCK_ENTITY, WoodenPipeRenderer::new);
        BlockEntityRenderers.register(AlchemyBlockEntityType.PIPE_Stone_BLOCK_ENTITY, WoodenPipeRenderer::new);

        registerClientEntityRenderer();

        HudElementRegistry.addFirst(Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID,"water"), this::renderHud);

        GrowableOresClienttwo.register();
    }

    private void renderHud(GuiGraphicsExtractor context, DeltaTracker tickCounter) {
        WindowsWatermarkRenderer.render(context);
    }

    @Environment(EnvType.CLIENT)
    public static void registerClientEntityRenderer() {

        var rubber_boat = new ModelLayerLocation(Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "boat/rubber"), "main");
        ModelLayerRegistry.registerModelLayer(rubber_boat, BoatModel::createBoatModel);
        EntityRendererRegistry.register(MapleEntityType.RUBBER_BOAT, (dispatcher) -> new BoatRenderer(dispatcher, rubber_boat));

        var rubber_chest_boat = new ModelLayerLocation(Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "chest_boat/rubber"), "main");
        ModelLayerRegistry.registerModelLayer(rubber_chest_boat, BoatModel::createChestBoatModel);
        EntityRendererRegistry.register(MapleEntityType.RUBBER_CHEST_BOAT, (dispatcher) -> new BoatRenderer(dispatcher, rubber_chest_boat));
    }
}