package com.skniro.industrial_elixir.mixin;

import com.skniro.industrial_elixir.item.init.RollingCuttingToolItem;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_2371;
import net.minecraft.class_9695;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 1.21.1's {@code Recipe#getRemainingItems} can only produce a fixed item for each ingredient
 * ({@code Item#getCraftingRemainingItem()}), so a rolling/cutting tool used as a crafting
 * ingredient would be consumed outright. 26.1 passes the actual input stack to
 * {@code Item#getCraftingRemainder(ItemStack)}; reproduce that by replacing the tool's
 * remainder with a copy that has one extra point of damage (or nothing when it breaks).
 */
@Mixin(class_1860.class)
public interface RecipeRemainderMixin {

    @Inject(method = "getRemainingItems", at = @At("RETURN"), cancellable = true)
    private void industrialElixir$damageRollingCuttingTool(class_9695 input, CallbackInfoReturnable<class_2371<class_1799>> cir) {
        class_2371<class_1799> original = cir.getReturnValue();
        class_2371<class_1799> result = null;

        for (int i = 0; i < input.method_59983() && i < original.size(); i++) {
            class_1799 stack = input.method_59984(i);
            if (stack.method_7909() instanceof RollingCuttingToolItem) {
                if (result == null) {
                    result = class_2371.method_10213(original.size(), class_1799.field_8037);
                    for (int j = 0; j < original.size(); j++) {
                        result.set(j, original.get(j));
                    }
                }
                result.set(i, RollingCuttingToolItem.getRemainingTool(stack));
            }
        }

        if (result != null) {
            cir.setReturnValue(result);
        }
    }
}
