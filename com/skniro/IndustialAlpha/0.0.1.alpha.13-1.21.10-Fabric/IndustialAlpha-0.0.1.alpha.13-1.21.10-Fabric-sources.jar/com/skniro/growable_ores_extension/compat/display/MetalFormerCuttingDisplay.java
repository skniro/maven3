package com.skniro.growable_ores_extension.compat.display;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.growable_ores_extension.compat.category.MetalFormerCuttingCategory;
import com.skniro.growable_ores_extension.compat.category.MetalFormerRollingCategory;
import com.skniro.growable_ores_extension.recipe.machine.MetalFormerCuttingCraftingRecipe;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2960;
import net.minecraft.class_8786;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import java.util.List;
import java.util.Optional;

public class MetalFormerCuttingDisplay extends BasicDisplay {
    private int count;

    public static final DisplaySerializer<MetalFormerCuttingDisplay> SERIALIZER = DisplaySerializer.of(
            RecordCodecBuilder.mapCodec(instance -> instance.group(
                    EntryIngredient.codec().listOf().fieldOf("inputs").forGetter(MetalFormerCuttingDisplay::getInputEntries),
                    EntryIngredient.codec().listOf().fieldOf("outputs").forGetter(MetalFormerCuttingDisplay::getOutputEntries),
                    class_2960.field_25139.optionalFieldOf("location").forGetter(MetalFormerCuttingDisplay::getDisplayLocation),
                    Codec.INT.fieldOf("count").forGetter(MetalFormerCuttingDisplay::getCount)
            ).apply(instance, MetalFormerCuttingDisplay::new)),
            class_9139.method_56905(
                    EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
                    MetalFormerCuttingDisplay::getInputEntries,
                    EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
                    MetalFormerCuttingDisplay::getOutputEntries,
                    class_9135.method_56382(class_2960.field_48267),
                    MetalFormerCuttingDisplay::getDisplayLocation,
                    class_9135.field_49675,
                    MetalFormerCuttingDisplay::getCount,
                    MetalFormerCuttingDisplay::new
            )
    );

    public MetalFormerCuttingDisplay(MetalFormerCuttingCraftingRecipe recipe) {
        this(List.of(EntryIngredients.ofIngredient(recipe.ingredient())),
                List.of(EntryIngredients.of(recipe.output())), Optional.empty(), recipe.requiredCount());
        this.count = recipe.requiredCount();
    }

    public MetalFormerCuttingDisplay(List<EntryIngredient> inputs, List<EntryIngredient> outputs, Optional<class_2960> location, int count) {
        super(inputs, outputs, location);
        this.count = count;
    }

    public MetalFormerCuttingDisplay(class_8786<MetalFormerCuttingCraftingRecipe> recipe){
        super(List.of(EntryIngredients.ofIngredient(recipe.comp_1933().ingredient())),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.comp_1933().output()))));
        this.count = recipe.comp_1933().requiredCount();
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return MetalFormerCuttingCategory.MetalFormerCutting;
    }

    @Override
    public DisplaySerializer<? extends Display> getSerializer() {
        return SERIALIZER;
    }

    public int getCount() {
        return count;
    }
}