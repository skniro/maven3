package torcherino.platform;

import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import torcherino.Torcherino;

public interface NetworkUtils {
    static NetworkUtils getInstance() {
        return Services.NETWORK;
    }

    void c2s_updateTorcherinoValues(class_2338 pos, int xRange, int zRange, int yRange, int speed, int redstoneMode);

    void s2c_openTorcherinoScreen(class_3222 player, class_2338 worldPosition, class_2561 name, int xRange, int zRange, int yRange, int speed, int redstoneMode);

    boolean s_isPlayerOnline(String uuid);
}
