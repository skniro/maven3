package com.skniro.maple.item;

import com.skniro.maple.Maple;
import com.skniro.maple.block.MapleBlocks;
import com.skniro.maple.item.init.food.ItemBottle;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1792;
import net.minecraft.class_1798;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_7923;
import net.minecraft.item.*;

public class MapleFoodComponents {
    public static final class_1792 Sanshoku_Dango =
            registerItem("sanshoku_dango",
                    new class_1792(
                            new class_1792
                                    .class_1793()
                                    .method_19265
                                            (new class_4174
                                                    .class_4175()
                                                    .method_19238(6)
                                                    .method_19237(0.6f)
                                                    .method_19242()
                                            )
                                    ));

    public static final class_1792 Anko_Dango =
            registerItem("anko_dango",
                    new class_1792(
                            new class_1792
                                    .class_1793()
                                    .method_19265
                                            (new class_4174
                                                    .class_4175()
                                                    .method_19238(6)
                                                    .method_19237(0.6f)
                                                    .method_19242()
                                            )
                                    ));
    public static final class_1792 Kinako_Dango =
            registerItem("kinako_dango",
                    new class_1792(
                            new class_1792
                                    .class_1793()
                                    .method_19265
                                            (new class_4174
                                                    .class_4175()
                                                    .method_19238(6)
                                                    .method_19237(0.6f)
                                                    .method_19242()
                                            )
                                    ));

    public static final class_1792 Zunda_Dango =
            registerItem("zunda_dango",
                    new class_1792(
                            new class_1792
                                    .class_1793()
                                    .method_19265
                                            (new class_4174
                                                    .class_4175()
                                                    .method_19238(6)
                                                    .method_19237(0.6f)
                                                    .method_19242()
                                            )
                                    ));

    public static final class_1792 Mochi =
            registerItem("mochi",
                    new class_1792(
                            new class_1792
                                    .class_1793()
                                    .method_19265
                                            (new class_4174
                                                    .class_4175()
                                                    .method_19238(6)
                                                    .method_19237(0.6f)
                                                    .method_19242()
                                            )
                                    ));

    public static final class_1792 SakuraMochi =
            registerItem("sakura_mochi",
                    new class_1792(
                            new class_1792
                                    .class_1793()
                                    .method_19265
                                            (new class_4174
                                                    .class_4175()
                                                    .method_19238(6)
                                                    .method_19237(0.6f)
                                                    .method_19242()
                                            )
                                    ));

    public static final class_1792 TOFU =
            registerItem("tofu",
                    new class_1792(
                            new class_1792
                                    .class_1793()
                                    .method_19265
                                            (new class_4174
                                                    .class_4175()
                                                    .method_19238(1)
                                                    .method_19237(0.1f)
                                                    .method_19242()
                                            )
                                    ));

    public static final class_1792 MILK_ICECREAM =
            registerItem("milk_icecream",
                    new class_1792(
                            new class_1792
                                    .class_1793()
                                    .method_19265
                                            (new class_4174
                                                    .class_4175()
                                                    .method_19238(1)
                                                    .method_19237(0.1f)
                                                    .method_19242()
                                            )
                                    ));

    public static final class_1792 Cooked_Rice =
            registerItem("cooked_rice",
                    new class_1792(
                            new class_1792
                                    .class_1793()
                                    .method_19265
                                            (new class_4174
                                                    .class_4175()
                                                    .method_19238(2)
                                                    .method_19237(0.2f)
                                                    .method_19242()
                                            )
                                    ));

    public static final class_1792 Beef_Rice =
            registerItem("beef_rice",
                    new class_1792(
                            new class_1792
                                    .class_1793()
                                    .method_19265
                                            (new class_4174
                                                    .class_4175()
                                                    .method_19238(11)
                                                    .method_19237(0.7f)
                                                    .method_19242()
                                            )
                                    ));

    public static final class_1792 Cheese =
            registerItem("cheese",
                    new class_1792(
                            new class_1792
                                    .class_1793()
                                    .method_19265
                                            (new class_4174
                                                    .class_4175()
                                                    .method_19238(3)
                                                    .method_19237(0.3f)
                                                    .method_19242()
                                            )
                                    ));

    public static final class_1792 MILK_BOTTOM = registerItem("milk_bottom",new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.2f)
                                    .method_19240()
                                    .method_19242()
                            )
                    .method_7889(16)
    ));

    public static final class_1792 MelonJuice = registerItem("melon_juice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.2f)
                                    .method_19240()
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));

    public static final class_1792 AppleJuice = registerItem("apple_juice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.2f)
                                    .method_19240()
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));

    public static final class_1792 CarrotJuice = registerItem("carrot_juice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.2f)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904,600,1),1.0F)
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));

    public static final class_1792 Sweet_Berries_Juice = registerItem("sweet_berries_juice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.2f)
                                    .method_19240()
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));

    public static final class_1792 Glow_Berries_Juice = registerItem("glow_berries_juice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.2f)
                                    .method_19240()
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));

    public static final class_1792 Chorus_Juice = registerItem("chorus_juice", new ItemBottle(
            new class_1792
                    .class_1793()
                    .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(2)
                                    .method_19237(0.2f)
                                    .method_19240()
                                    .method_19242()
                            )
                    .method_7896(class_1802.field_8469)
                    .method_7889(1)
    ));

    public static final class_1792 Green_Tea_Leaves = registerItem("green_tea_leaves",
            new class_1798(MapleBlocks.Tea_Block,
                    new class_1792
                            .class_1793() .method_19265
                                    (new class_4174
                                            .class_4175()
                                            .method_19238(1)
                                            .method_19237(0.1f)
                                            .method_19240()
                                            .method_19242()
                                    )
                            .method_7889(64)
            ));

    public static final class_1792 Red_Tea_Leaves = registerItem("red_tea_leaves",
            new class_1792(
                    new class_1792
                            .class_1793() .method_19265
                                    (new class_4174
                                            .class_4175()
                                            .method_19238(1)
                                            .method_19237(0.1f)
                                            .method_19240()
                                            .method_19242()
                                    )
                            .method_7889(64)
            ));

    public static final class_1792 Red_Tea = registerItem("red_tea",
            new class_1792(
                    new class_1792
                            .class_1793() .method_19265
                                    (new class_4174
                                            .class_4175()
                                            .method_19238(4)
                                            .method_19237(0.4f)
                                            .method_19240()
                                            .method_19242()
                                    )
                            .method_7889(1)
            ));

    public static final class_1792 Green_Tea = registerItem("green_tea",
            new class_1792(
                    new class_1792
                            .class_1793() .method_19265
                                    (new class_4174
                                            .class_4175()
                                            .method_19238(4)
                                            .method_19237(0.4f)
                                            .method_19240()
                                            .method_19242()
                                    )
                            .method_7889(1)
            ));

       /* public static final Item Mutton_Rice =
            registerItem("mutton_rice",
                    new Item(
                            new Item
                                    .Settings()
                                    .food
                                            (new FoodComponent
                                                    .Builder()
                                                    .nutrition(9)
                                                    .saturationModifier(0.7f)
                                                    .build()
                                            )
                                    ));


    public static final Item Chicken_Rice =
            registerItem("chicken_rice",
                    new Item(
                            new Item
                                    .Settings()
                                    .food
                                            (new FoodComponent
                                                    .Builder()
                                                    .nutrition(9)
                                                    .saturationModifier(0.7f)
                                                    .build()
                                            )
                    ));

    public static final Item Porkchop_Rice =
            registerItem("porkchop_rice",
                    new Item(
                            new Item
                                    .Settings()
                                    .food
                                            (new FoodComponent
                                                    .Builder()
                                                    .nutrition(9)
                                                    .saturationModifier(0.7f)
                                                    .build()
                                            )
                                    ));

    public static final Item Mushroom_Rice =
            registerItem("mushroom_rice",
                    new Item(
                            new Item
                                    .Settings()
                                    .food
                                            (new FoodComponent
                                                    .Builder()
                                                    .nutrition(9)
                                                    .saturationModifier(0.7f)
                                                    .build()
                                            )
                                    ));

     public static final Item RICEBALL =
            registerItem("riceball",
                    new Item(
                            new Item
                                    .Settings()
                                    .food
                                            (new FoodComponent
                                                    .Builder()
                                                    .nutrition(3)
                                                    .saturationModifier(0.3f)
                                                    .build()
                                            )
                                    ));

    public static final Item Mushroom_RICEBALL =
            registerItem("mushroom_riceball",
                    new Item(
                            new Item
                                    .Settings()
                                    .food
                                            (new FoodComponent
                                                    .Builder()
                                                    .nutrition(4)
                                                    .saturationModifier(0.3f)
                                                    .build()
                                            )
                                    ));

    public static final Item Salmon_RICEBALL =
            registerItem("salmon_riceball",
                    new Item(
                            new Item
                                    .Settings()
                                    .food
                                            (new FoodComponent
                                                    .Builder()
                                                    .nutrition(4)
                                                    .saturationModifier(0.3f)
                                                    .build()
                                            )
                                    ));*/




    private static class_1792 registerItem(String name,class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(Maple.MOD_ID, name),item);
    }
    public static void registerMapleFoodItems() {
        Maple.LOGGER.info("Registering Maple Food Items for " + Maple.MOD_ID);
    }
}
