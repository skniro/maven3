package com.skniro.industrial_elixir.block.entity.pipe;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class StoneFluidPipeBlockEntity extends FluidPipeBlockEntity {
    public StoneFluidPipeBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.PIPE_Stone_Fluid_BLOCK_ENTITY, pos, state);
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) return;
        super.tick(world, pos, state);
        moveFluids(world, pos);
    }
}
