package com.skniro.industrial_elixir.world.gen;

import com.skniro.industrial_elixir.world.feature.AgreeTreePlacedFeatures;
import com.skniro.industrial_elixir.world.feature.ModPlacedFeatures;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_1972;
import net.minecraft.class_2893;

public class ModTreeGeneration {

    public static void generateTrees() {
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(class_1972.field_9409),
                class_2893.class_2895.field_13178, AgreeTreePlacedFeatures.Rubber_TREE_PLACED);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(class_1972.field_9420),
                class_2893.class_2895.field_13178, ModPlacedFeatures.PATCH_COFFEE_COMMON);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(class_1972.field_35119),
                class_2893.class_2895.field_13178, ModPlacedFeatures.PATCH_COFFEE_COMMON);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(class_1972.field_35119),
                class_2893.class_2895.field_13178, ModPlacedFeatures.PATCH_COFFEE_RARE);
    }
}
