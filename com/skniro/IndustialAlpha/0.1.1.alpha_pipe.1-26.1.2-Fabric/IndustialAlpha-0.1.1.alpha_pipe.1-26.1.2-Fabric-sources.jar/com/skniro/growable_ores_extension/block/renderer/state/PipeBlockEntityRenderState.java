package com.skniro.growable_ores_extension.block.renderer.state;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.world.phys.Vec3;

public class PipeBlockEntityRenderState extends BlockEntityRenderState {
    public final List<PipeItemRender> items = new ArrayList<>();

    public static class PipeItemRender {
        public final ItemStackRenderState item = new ItemStackRenderState();
        public Vec3 offset = Vec3.ZERO;
        public int lightmapCoordinates;
    }
}
