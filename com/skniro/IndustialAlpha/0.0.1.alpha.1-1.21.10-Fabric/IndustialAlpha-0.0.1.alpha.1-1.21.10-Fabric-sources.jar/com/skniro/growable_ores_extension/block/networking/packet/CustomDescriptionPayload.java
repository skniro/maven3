package com.skniro.growable_ores_extension.block.networking.packet;

import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import reborncore.common.network.BlockPosPayload;

public record CustomDescriptionPayload(class_2338 pos, class_2487 nbt) implements class_8710, BlockPosPayload {
    public static final class_8710.class_9154<CustomDescriptionPayload> ID = new class_8710.class_9154(class_2960.method_60654("reborncore:custom_description"));
    public static final class_9139<class_9129, CustomDescriptionPayload> PACKET_CODEC;

    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }

    static {
        PACKET_CODEC = class_9139.method_56435(class_2338.field_48404, CustomDescriptionPayload::pos, class_9135.field_48556, CustomDescriptionPayload::nbt, CustomDescriptionPayload::new);
    }
}