package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class ExtractorRecipeGenerator extends FabricRecipeProvider {
    public ExtractorRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                createExtractor(class_1802.field_8696, 4).input(class_1802.field_19060)
                        .method_33530("has_base_item", has(class_1802.field_19060)).method_10431(output);
                createExtractor(class_1802.field_8543, 4).input(class_1802.field_8246)
                        .method_33530("has_base_item", has(class_1802.field_8246)).method_10431(output);
                createExtractor(class_1802.field_8621, 4).input(class_1802.field_20390)
                        .method_33530("has_base_item", has(class_1802.field_20390)).method_10431(output);
                createExtractor(class_1802.field_8729, 4).input(class_1802.field_20398)
                        .method_33530("has_base_item", has(class_1802.field_20398)).method_10431(output);
                createExtractor(GrowableOresItems.Rubber).input(GeneralBlocks.Rubber_LOG)
                        .method_33530("has_base_item", has(GeneralBlocks.Rubber_LOG)).method_10431(output);
                createExtractor(GrowableOresItems.Rubber).input(GeneralBlocks.Rubber_Rubber_LOG)
                        .method_33530("has_base_item", has(GeneralBlocks.Rubber_Rubber_LOG)).method_36443(output,"rubber_log_to_rubber");
                createExtractor(GrowableOresItems.Rubber).input(GeneralBlocks.Rubber_SAPLING)
                        .method_33530("has_base_item", has(GeneralBlocks.Rubber_SAPLING)).method_36443(output,"rubber_sapling_to_rubber");
                createExtractor(GrowableOresItems.Rubber).input(GrowableOresItems.Sticky_Resin)
                        .method_33530("has_base_item", has(GrowableOresItems.Sticky_Resin)).method_36443(output,"sticky_resin_to_rubber");
                createExtractor(GrowableOresItems.SULFUR_DUST).input(class_1802.field_8054)
                        .method_33530("has_base_item", has(class_1802.field_8054)).method_10431(output);
            }
        };
    }

    @Override
    public String method_10321() {
        return "Extractor";
    }
}
