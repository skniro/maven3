package com.skniro.skniro_furniture.recipe;

import com.skniro.skniro_furniture.Furniture;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

public interface FurnitureRecipeType<T extends class_1860<?>> {
    public static final class_1865<KitchenSinkRecipe> Kitchen_Sink_SERIALIZER = class_2378.method_10230(
            class_7923.field_41189, class_2960.method_60655(Furniture.MOD_ID, "kitchen_sink"), new KitchenSinkRecipe.Serializer());
    public static final class_3956<KitchenSinkRecipe> Kitchen_Sink_TYPE = class_2378.method_10230(
            class_7923.field_41188, class_2960.method_60655(Furniture.MOD_ID, "kitchen_sink"), new class_3956<>() {
                @Override
                public String toString() {
                    return "kitchen_sink";
                }
            });

    public static void registerRecipes() {
        Furniture.LOGGER.info("Registering Custom Recipes for " + Furniture.MOD_ID);
    }
}

