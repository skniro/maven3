package com.skniro.growable_ores_extension.datagen;

import com.skniro.growable_ores_extension.block.NetherOresBlocks;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

import static net.minecraft.class_3481.*;
import static net.minecraft.class_3481.field_16584;
import static net.minecraft.class_3481.field_15471;
import static net.minecraft.class_3481.field_15477;
import static net.minecraft.class_3481.field_15468;
import static net.minecraft.class_3481.field_15502;
import static net.minecraft.class_3481.field_15491;

public class GrowableItemTagGenerator extends FabricTagProvider.ItemTagProvider {
   public GrowableItemTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
   }
   @Override
   protected void method_10514(class_7225.class_7874 arg) {
      valueLookupBuilder(ModItemTags.BATTERY)
              .method_71554(GrowableOresItems.Test_battery);
      valueLookupBuilder(class_3489.field_15558)
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_LEAVES))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15528)
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_SAPLING))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_23212)
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_LOG))
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_Rubber_LOG))
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_WOOD))
              .method_71554(class_1792.method_7867(NetherOresBlocks.STRIPPED_Rubber_LOG))
              .method_71554(class_1792.method_7867(NetherOresBlocks.STRIPPED_Rubber_WOOD))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15555)
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_BUTTON))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15552)
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_DOOR))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15550)
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_TRAPDOOR))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15540)
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_PRESSURE_PLATE))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15534)
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_SLAB))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15557)
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_STAIRS))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_15537)
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_PLANKS))
              .setReplace(false);
      valueLookupBuilder(class_3489.field_16585)
              .method_71554(class_1792.method_7867(NetherOresBlocks.Rubber_FENCE))
              .setReplace(false);
   }
}