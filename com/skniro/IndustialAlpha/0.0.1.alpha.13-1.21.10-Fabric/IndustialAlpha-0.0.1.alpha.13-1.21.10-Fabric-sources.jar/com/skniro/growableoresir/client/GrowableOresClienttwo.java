package com.skniro.growableoresir.client;

import com.skniro.growableoresir.block.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.class_11515;

@Environment(EnvType.CLIENT)
public class GrowableOresClienttwo {
    public static void register() {
        BlockRenderLayerMap.putBlock(GrowableICOresBlocks.IC2_Bronze_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableICOresBlocks.IC2_silver_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableICOresBlocks.IC2_Tin_Cane, class_11515.field_60925);;
        BlockRenderLayerMap.putBlock(GrowableICOresBlocks.IC2_Uranium_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableICOresBlocks.IC2_steel_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableICOresBlocks.IC2_LEAD_Cane, class_11515.field_60925);
    }
}
