package com.skniro.skniro_furniture.block.api.registry;

import com.mojang.datafixers.util.Pair;
import com.skniro.skniro_furniture.block.init.FurnitureBedBlock;
import com.skniro.skniro_furniture.block.init.KitchenCounterBlock;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10804;
import net.minecraft.class_10821;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_2742;
import net.minecraft.class_2750;
import net.minecraft.class_2756;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4917;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4941;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_807;
import net.minecraft.client.data.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static net.minecraft.class_4910.*;

public class MapleModelDatagenHelper {
    private final class_4910 generator;;
    private static final class_4926<class_10804> NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS;

    public MapleModelDatagenHelper(class_4910 generator) {
        this.generator = generator;
    }

    public void registerModSweetBerryBush(class_1792 fruititem, class_2248 block) {
        generator.method_25537(fruititem);
        generator.field_22830.accept(class_4925.method_67852(block)
                .method_67859(class_4926.method_67864(class_2741.field_12497).method_25795(stage ->
                                method_67835(
                                generator.method_25557(block, "_stage" + stage, class_4943.field_22921, class_4944::method_25880)
                        )
                ))
        );
    }

    public void registerModBookshelf(class_2248 block, class_2248 plank) {
        class_4944 textureMap = class_4944.method_25870(class_4944.method_25860(block), class_4944.method_25860(plank));
        class_807 identifier = method_67835(class_4943.field_22974.method_25846(block, textureMap, generator.field_22831));
        generator.field_22830.accept(class_4910.method_25644(block, identifier));
    }

    public void registerLamp(class_2248 block) {
        class_807 identifier = method_67835(class_4941.method_25842(block));
        class_807 identifier2 = method_67835(class_4941.method_25843(block,"_on"));
        generator.field_22830.accept(class_4925.method_67852(block).method_67859(method_25565(class_2741.field_12548, identifier2, identifier)));
    }

    public final void registerBlockState(class_2248 block) {
        generator.field_22830.accept(class_4925.method_67853(block, method_67835(class_4941.method_25842(block))));
    }

    public void registerFridge(class_2248 block) {
        class_2960 bottomModel = class_4941.method_25843(block, "_bottom");
        class_2960 topModel = class_4941.method_25843(block, "_top");

        class_4926.class_4928<class_807,class_2350, class_2756> variantMap =
                class_4926.method_67865(class_2741.field_12481, class_2741.field_12533);

        fillSimpleDoubleVariantMap(variantMap, class_2756.field_12607, bottomModel);
        fillSimpleDoubleVariantMap(variantMap, class_2756.field_12609, topModel);

        generator.field_22830.accept(class_4925.method_67852(block).method_67859(variantMap));
    }


    public static class_4926.class_4928<class_807, class_2350, class_2756> fillSimpleDoubleVariantMap(
            class_4926.class_4928<class_807, class_2350, class_2756> variantMap,
            class_2756 targetHalf,
            class_2960 baseModelId
    ) {
        return variantMap
                .method_25798(class_2350.field_11043, targetHalf, method_67835(baseModelId))
                .method_25798(class_2350.field_11034, targetHalf, method_67835(baseModelId).method_67929(class_10804.field_56937.withValue(class_10821.field_57030)))
                .method_25798(class_2350.field_11035, targetHalf, method_67835(baseModelId).method_67929(class_10804.field_56937.withValue(class_10821.field_57031)))
                .method_25798(class_2350.field_11039, targetHalf, method_67835(baseModelId).method_67929(class_10804.field_56937.withValue(class_10821.field_57032)));
    }

    public void registerPaperSlidingDoor(class_2248 doorBlock) {
        class_807 weightedVariant = method_67835(class_4941.method_25843(doorBlock, "_bottom_left"));
        class_807 weightedVariant2 = method_67835(class_4941.method_25843(doorBlock, "_bottom_left_open"));
        class_807 weightedVariant3 = method_67835(class_4941.method_25843(doorBlock, "_bottom_right"));
        class_807 weightedVariant4 = method_67835(class_4941.method_25843(doorBlock, "_bottom_right_open"));
        class_807 weightedVariant5 = method_67835(class_4941.method_25843(doorBlock, "_top_left"));
        class_807 weightedVariant6 = method_67835(class_4941.method_25843(doorBlock, "_top_left_open"));
        class_807 weightedVariant7 = method_67835(class_4941.method_25843(doorBlock, "_top_right"));
        class_807 weightedVariant8 = method_67835(class_4941.method_25843(doorBlock, "_top_right_open"));
        generator.field_22830.accept(createDoorBlockState(doorBlock, weightedVariant, weightedVariant2, weightedVariant3, weightedVariant4, weightedVariant5, weightedVariant6, weightedVariant7, weightedVariant8));
    }

    public static class_4917 createDoorBlockState(class_2248 doorBlock, class_807 bottomLeftClosedModel, class_807 bottomLeftOpenModel, class_807 bottomRightClosedModel, class_807 bottomRightOpenModel, class_807 topLeftClosedModel, class_807 topLeftOpenModel, class_807 topRightClosedModel, class_807 topRightOpenModel) {
        return class_4925.method_67852(doorBlock)
                .method_67859(class_4926
                        .method_67867(class_2741.field_12481, class_2741.field_12533, class_2741.field_12520, class_2741.field_12537)
                        .method_25812(class_2350.field_11034, class_2756.field_12607, class_2750.field_12588, false, bottomLeftClosedModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12607, class_2750.field_12588, false, bottomLeftClosedModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12607, class_2750.field_12588, false, bottomLeftClosedModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12607, class_2750.field_12588, false, bottomLeftClosedModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12607, class_2750.field_12586, false, bottomRightClosedModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12607, class_2750.field_12586, false, bottomRightClosedModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12607, class_2750.field_12586, false, bottomRightClosedModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12607, class_2750.field_12586, false, bottomRightClosedModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12607, class_2750.field_12588, true, bottomLeftOpenModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12607, class_2750.field_12588, true, bottomLeftOpenModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12607, class_2750.field_12588, true, bottomLeftOpenModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12607, class_2750.field_12588, true, bottomLeftOpenModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12607, class_2750.field_12586, true, bottomRightOpenModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12607, class_2750.field_12586, true, bottomRightOpenModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12607, class_2750.field_12586, true, bottomRightOpenModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12607, class_2750.field_12586, true, bottomRightOpenModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12609, class_2750.field_12588, false, topLeftClosedModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12609, class_2750.field_12588, false, topLeftClosedModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12609, class_2750.field_12588, false, topLeftClosedModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12609, class_2750.field_12588, false, topLeftClosedModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12609, class_2750.field_12586, false, topRightClosedModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12609, class_2750.field_12586, false, topRightClosedModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12609, class_2750.field_12586, false, topRightClosedModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12609, class_2750.field_12586, false, topRightClosedModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12609, class_2750.field_12588, true, topLeftOpenModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12609, class_2750.field_12588, true, topLeftOpenModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12609, class_2750.field_12588, true, topLeftOpenModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12609, class_2750.field_12588, true, topLeftOpenModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12609, class_2750.field_12586, true, topRightOpenModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12609, class_2750.field_12586, true, topRightOpenModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12609, class_2750.field_12586, true, topRightOpenModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12609, class_2750.field_12586, true, topRightOpenModel.method_67929(field_56786)));
    }


    public final void registerBed(class_2248 block) {
        class_2960 headModel = class_4941.method_25843(block, "_head");
        class_2960 footModel = class_4941.method_25843(block, "_foot");

        class_4926.class_4928<class_807,class_2350, class_2742> variantMap =
                class_4926.method_67865(class_2741.field_12481, FurnitureBedBlock.PART);

        fillSimpleDoubleVariantMap(variantMap, class_2742.field_12560, headModel);
        fillSimpleDoubleVariantMap(variantMap, class_2742.field_12557, footModel);
        generator.field_22830.accept(class_4925.method_67852(block).method_67859(variantMap));
    }

    public void registerTV(class_2248 block) {
        class_807 identifier = method_67835(class_4941.method_25842(block));
        class_807 identifier2 = method_67835(class_4941.method_25843(block,"_open"));
        generator.field_22830.accept(class_4925.method_67852(block).method_67859(method_25565(class_2741.field_12548, identifier2, identifier)).method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS));
    }

    public static class_4926.class_4928<class_807, class_2350, class_2742> fillSimpleDoubleVariantMap(
            class_4926.class_4928<class_807, class_2350, class_2742> variantMap,
            class_2742 targetHalf,
            class_2960 baseModelId
    ) {
        return variantMap
                .method_25798(class_2350.field_11043, targetHalf, method_67835(baseModelId))
                .method_25798(class_2350.field_11034, targetHalf, method_67835(baseModelId).method_67929(class_10804.field_56937.withValue(class_10821.field_57030)))
                .method_25798(class_2350.field_11035, targetHalf, method_67835(baseModelId).method_67929(class_10804.field_56937.withValue(class_10821.field_57031)))
                .method_25798(class_2350.field_11039, targetHalf, method_67835(baseModelId).method_67929(class_10804.field_56937.withValue(class_10821.field_57032)));
    }

    static {
        NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS = class_4926.method_67869(class_2741.field_12481).method_25794(class_2350.field_11034, field_56785).method_25794(class_2350.field_11035, field_56786).method_25794(class_2350.field_11039, field_56787).method_25794(class_2350.field_11043, field_56780);
    }
}