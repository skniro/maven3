package torcherino.block.api;

import net.fabricmc.fabric.api.registry.OxidizableBlocksRegistry;
import net.minecraft.class_11710;

public class LanterinoOxidizableRegistry {

    public static void registerWeatheringSet(class_11710 blocks) {
        OxidizableBlocksRegistry.registerOxidizableBlockPair(blocks.comp_4576(), blocks.comp_4577());
        OxidizableBlocksRegistry.registerOxidizableBlockPair(blocks.comp_4577(), blocks.comp_4578());
        OxidizableBlocksRegistry.registerOxidizableBlockPair(blocks.comp_4578(), blocks.comp_4579());

        OxidizableBlocksRegistry.registerWaxableBlockPair(blocks.comp_4576(), blocks.comp_4580());
        OxidizableBlocksRegistry.registerWaxableBlockPair(blocks.comp_4577(), blocks.comp_4581());
        OxidizableBlocksRegistry.registerWaxableBlockPair(blocks.comp_4578(), blocks.comp_4582());
        OxidizableBlocksRegistry.registerWaxableBlockPair(blocks.comp_4579(), blocks.comp_4583());
    }
}
