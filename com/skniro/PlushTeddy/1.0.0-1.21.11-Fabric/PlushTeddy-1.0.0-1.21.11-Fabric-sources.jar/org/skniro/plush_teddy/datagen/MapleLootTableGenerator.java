package org.skniro.plush_teddy.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_7225;
import org.skniro.plush_teddy.block.*;

import java.util.concurrent.CompletableFuture;


public class MapleLootTableGenerator extends FabricBlockLootTableProvider {
    public MapleLootTableGenerator(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataGenerator, registryLookup);
    }

    @Override
    public void method_10379() {

        method_46025(MapleFurnitureBlocks.TEDDY_BEAR_NORMAL);
    }

}
