package com.skniro.growableores.mixin;

import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2523;
import net.minecraft.class_2680;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2523.class)
public class Mixin_SugarCaneBlock extends class_2248 {
    @Shadow
    @Final
    public static class_2758 AGE;

    public Mixin_SugarCaneBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (world.method_22347(pos.method_10084())) {
            int i;
            for(i = 1; world.method_8320(pos.method_10087(i)).method_27852(this); ++i) {
            }

            if (i < 3) {
                int j = (Integer)state.method_11654(AGE);
                if (j >= 2) {
                    world.method_8501(pos.method_10084(), this.method_9564());
                    world.method_8652(pos, (class_2680)state.method_11657(AGE, 0), 2);
                } else {
                    world.method_8652(pos, (class_2680)state.method_11657(AGE, j + 1), 2);
                }
            }
        }
    }
}
