package com.skniro.industrial_elixir.screen.ingame.machine;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.block.entity.machine.MolecularTransformerBlockEntity;
import com.skniro.industrial_elixir.screen.handler.machine.MolecularTransformerScreenHandler;
import com.skniro.industrial_elixir.util.MouseUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class MolecularTransformerBlockScreen extends class_465<MolecularTransformerScreenHandler> {
    private static final class_2960 TEXTURE = class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/machine/molecular_transformer.png");

    public MolecularTransformerBlockScreen(MolecularTransformerScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
    }

    public class_2561 getTooltips() {
        return class_2561.method_43470(((MolecularTransformerBlockEntity) field_2797.blockEntity).energyInputPerTick + " EP/t");
    }

    private void renderArrowTooltips(class_332 context) {
        context.method_51439(field_22793, class_2561.method_43470( field_2797.getProgressPercent() + "%"), 74, 22, -12566464, false);
    }
    
    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        context.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, -12566464, false);
        context.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, -12566464, false);
        context.method_51439(field_22793, getTooltips(), 64, 61, -12566464, false);
        renderArrowTooltips(context);
    }

    @Override
       protected void method_2389(class_332 context, float partialTicks, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        context.method_25290(TEXTURE, x, y, 0, 0, field_2792, field_2779,256,256);
        renderProgressArrow(context, x, y);
    }

    private void renderProgressArrow(class_332 context, int x, int y) {
        int progress = field_2797.getScaledProgress();
        if (progress > 0) {
            context.method_25290(TEXTURE,
                    x + 74, y + 37, 194, 2, progress, 9,
                    256, 256);
        }
    }

    @Override
    public void method_25394(class_332 context , int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
         method_2380(context, mouseX, mouseY);
    }

    private boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, int width, int height) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, width, height);
    }
}

