package com.skniro.industrial_elixir.util;

import net.minecraft.class_2746;

public class ModBooleanPropertys {
    public static final class_2746 HOT_SPRING_LOGGED = class_2746.method_11825("hot_spring_logged");
}
