package com.skniro.usefulfood.util;

import com.skniro.usefulfood.item.UsefulFoodItems;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.class_141;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;
import net.minecraft.class_7924;

public class ModLootTableModifiers {
    public static final class_2960 SQUID_ID = class_2960.method_60656("entities/squid");
    public static final class_2960 GLOW_SQUID_ID = class_2960.method_60656("entities/glow_squid");

    public static void modifyLootTables() {
        LootTableEvents.MODIFY.register((id, tableBuilder, source, wrapperLookup) -> {
            if(class_5321.method_29179(class_7924.field_50079, SQUID_ID).equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(1f)) // Drops 100% of the time
                        .method_351(class_77.method_411(UsefulFoodItems.SquidTentacleRaw))
                        .apply(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)).method_515());
                tableBuilder.method_336(poolBuilder);
            }
            if(class_5321.method_29179(class_7924.field_50079, GLOW_SQUID_ID).equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(1f)) // Drops 100% of the time
                        .method_351(class_77.method_411(UsefulFoodItems.SquidTentacleRaw))
                        .apply(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)).method_515());
                tableBuilder.method_336(poolBuilder);
            }
        });
    }
}