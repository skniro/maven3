package com.skniro.growableores.block;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.init.GrowableOreCaneBlock;
import com.skniro.growableores.util.GrowableOresItemGroups;
import java.util.function.Function;
import java.util.logging.Logger;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public class GrowableAetherOresBlocks {
    //Aether
    public static final class_2248 AET_Ambrosium_Shard_Cane =registerBlock("aet_ambrosium_shard_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 AET_Enchanted_Gravitite_Cane =registerBlock("aet_enchanted_gravitite_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 AET_Zanite_Gemstone_Cane =registerBlock("aet_zanite_gemstone_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 AET_Skyroot_Stick_Cane =registerBlock("aet_skyroot_stick_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 AET_Golden_Amber_Cane =registerBlock("aet_golden_amber_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));


    private static class_2248 registerBlock(String name, class_2248 block) {
        registerBlockItem(name, block);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_43902(GrowableOres.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_43902(GrowableOres.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
    }
    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + GrowableOres.MOD_ID);
    }
}

