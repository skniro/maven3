package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import com.skniro.skniro_furniture.block.entity.FridgeBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2756;
import net.minecraft.class_3218;
import net.minecraft.class_3468;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;


public class FridgeBlock extends AbstractFurnitureContainerBlock {
    public static final class_2754<class_2756> HALF;

    public FridgeBlock(class_2251 settings) {
        super(settings);
        this.method_9590((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043).method_11657(HALF, class_2756.field_12607)));
    }

    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (world instanceof class_3218 serverWorld) {
            class_2586 var8 = world.method_8321(pos);
            if (var8 instanceof FridgeBlockEntity BlockEntity) {
                player.method_17355(BlockEntity);
                player.method_7281(class_3468.field_17271);
            }
        }

        return class_1269.field_5812;
    }

    public void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof FridgeBlockEntity) {
            ((FridgeBlockEntity)blockEntity).tick();
        }

    }

    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        class_2756 doubleBlockHalf = (class_2756)state.method_11654(HALF);
        if (direction.method_10166() == class_2350.class_2351.field_11052 && doubleBlockHalf == class_2756.field_12607 == (direction == class_2350.field_11036)) {
            return neighborState.method_26204() instanceof FridgeBlock && neighborState.method_11654(HALF) != doubleBlockHalf ? (class_2680)neighborState.method_11657(HALF, doubleBlockHalf) : class_2246.field_10124.method_9564();
        } else {
            return doubleBlockHalf == class_2756.field_12607 && direction == class_2350.field_11033 && !state.method_26184(world, pos) ? class_2246.field_10124.method_9564() : super.method_9559(state, direction, neighborState, world, pos, neighborPos);
        }
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack) {
        world.method_8652(pos.method_10084(), (class_2680)state.method_11657(HALF, class_2756.field_12609), 3);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        if (state.method_11654(HALF) == class_2756.field_12607) {
            class_2338 blockPos = pos.method_10074();
            class_2680 blockState = world.method_8320(blockPos);
            return blockState.method_26206(world, blockPos, class_2350.field_11036);
        } else {
            class_2680 lowerState = world.method_8320(pos.method_10074());
            return lowerState.method_26204() == this && lowerState.method_11654(HALF) == class_2756.field_12607;
        }
    }

    @Nullable
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new FridgeBlockEntity(pos, state);
    }

    @Override
    public long method_9535(class_2680 state, class_2338 pos) {
        return class_3532.method_15371(pos.method_10263(), pos.method_10087(state.method_11654(HALF) == class_2756.field_12607 ? 0 : 1).method_10264(), pos.method_10260());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(HALF, FACING);
    }

    static {
        HALF = class_2741.field_12533;
    }
}
