package com.skniro.maple.world.gamerules;

import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.minecraft.class_1928;

public class MapleGameRules {
    public static final class_1928.class_4313<class_1928.class_4310> HOT_SPRING_SOURCE_CONVERSION =
            GameRuleRegistry.register("HotSpringSourceConversion", class_1928.class_5198.field_24098, GameRuleFactory.createBooleanRule(false));

    public static void maplegamerule() {
    }
}
