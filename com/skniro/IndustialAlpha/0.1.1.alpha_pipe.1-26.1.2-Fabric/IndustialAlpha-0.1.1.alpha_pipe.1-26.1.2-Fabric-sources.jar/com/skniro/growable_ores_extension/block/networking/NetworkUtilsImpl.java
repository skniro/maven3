package com.skniro.growable_ores_extension.block.networking;

import com.google.common.base.Suppliers;
import com.skniro.growable_ores_extension.block.entity.machine.MetalFormerBlockEntity;
import com.skniro.growable_ores_extension.block.networking.packet.MetalFormerStateC2SPayload;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import java.util.function.Supplier;

public class NetworkUtilsImpl {
    private static final Supplier<NetworkUtilsImpl> instance = Suppliers.memoize(NetworkUtilsImpl::new);

    public static NetworkUtilsImpl getInstance() {
        return instance.get();
    }

    public void initialize() {
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            ClientNetworking.initialize();
        }

        ServerPlayNetworking.registerGlobalReceiver(
                MetalFormerStateC2SPayload.TYPE,
                (payload, context) -> {
                    ServerPlayer player = context.player();
                    ServerLevel world = player.level();
                    context.server().execute(() -> {
                        BlockEntity be = world.getBlockEntity(payload.pos());
                        if (be instanceof MetalFormerBlockEntity machine) {
                            machine.setState(MetalFormerBlockEntity.MetalFormerState.values()[payload.state()]);
                            machine.setChanged();
                        }
                    });
                }
        );
    }

    private static class ClientNetworking {
        private static void initialize() {

        }
    }
}