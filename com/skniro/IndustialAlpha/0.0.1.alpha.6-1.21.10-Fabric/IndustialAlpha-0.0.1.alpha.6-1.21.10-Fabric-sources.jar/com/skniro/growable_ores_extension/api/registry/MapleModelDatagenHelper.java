package com.skniro.growable_ores_extension.api.registry;

import net.minecraft.class_10804;
import net.minecraft.class_10821;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_2742;
import net.minecraft.class_2750;
import net.minecraft.class_2756;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4917;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4941;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.class_4946;
import net.minecraft.class_807;
import net.minecraft.client.data.*;
import java.util.Map;

import static net.minecraft.class_4910.*;

public class MapleModelDatagenHelper {
    private final class_4910 generator;;
    private static final class_4926<class_10804> NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS;

    public MapleModelDatagenHelper(class_4910 generator) {
        this.generator = generator;
    }

/*    public void registerModLogs(Block block) {
        generator.blockStateCollector.accept(VariantsBlockModelDefinitionCreator.of(block)
                .with(BlockStateVariantMap.models(Properties.AGE_2).generate(stage ->
                        createWeightedVariant(generator.createSubModel(block, "_stage" + stage, Models.CUBE_ALL, TextureMap::all)
                        )
                ))
        );
    }*/

    public void registerModLogs(class_2248 block) {

        class_2960[] verticalModels = new class_2960[3];
        class_2960[] horizontalModels = new class_2960[3];

        for (int age = 0; age <= 2; age++) {

            class_4944 textures = new class_4944()
                    .method_25868(class_4945.field_23018, class_4944.method_25866(block, "_stage" + age))
                    .method_25868(class_4945.field_23013, class_4944.method_25866(block, "_top"))
                    .method_25868(class_4945.field_23012, class_4944.method_25866(block, "_stage" + age));

            verticalModels[age] = class_4943.field_22974.method_25847(
                    block,
                    "_stage" + age,
                    textures,
                    generator.field_22831
            );

            horizontalModels[age] = class_4943.field_22975.method_25847(
                    block,
                    "_stage" + age,
                    textures,
                    generator.field_22831
            );
        }

        generator.field_22830.accept(
                class_4925.method_67852(block)
                        .method_67859(class_4926.method_67865(class_2741.field_12556, class_2741.field_12496)
                                .method_25800((age, axis) -> {

                                    if (axis == class_2350.class_2351.field_11052) {
                                        return class_4910
                                                .method_67835(verticalModels[age]);
                                    }

                                    class_807 variant =
                                            class_4910
                                                    .method_67835(horizontalModels[age]);

                                    if (axis == class_2350.class_2351.field_11048) {
                                        return variant.method_67929(
                                                generator.field_56782
                                        );
                                    }

                                    // Z
                                    return variant
                                            .method_67929(generator.field_56782)
                                            .method_67929(generator.field_56785);
                                })
                        )
        );

        generator.method_25623(block, verticalModels[0]);
    }




    public void registerBaseMachineBlock(class_2248 cooker, class_4946.class_4947 modelFactory) {
        Map<class_4945, String> faceTextureSuffixes = Map.of(

                class_4945.field_23024, "_down",
                class_4945.field_23023, "_up",
                class_4945.field_23019, "_front",
                class_4945.field_23020, "_back",
                class_4945.field_23022, "_left",
                class_4945.field_23021, "_right"
        );

        class_807 baseVariant = method_67835(
                modelFactory.get(cooker).method_25917(textures -> {
                    faceTextureSuffixes.forEach((key, suffix) -> {
                        textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                    });
                }).method_25916(cooker, generator.field_22831)
        );

        class_807 litVariant = method_67835(
                modelFactory.get(cooker).method_25917(textures -> {
                    faceTextureSuffixes.forEach((key, suffix) -> {
                        if (key == class_4945.field_23019) {
                            textures.method_25868(key, class_4944.method_25866(cooker, "_front_on"));
                        } else {
                            textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                        }
                    });
                }).method_25915(cooker, "_on", generator.field_22831)
        );

        generator.field_22830.accept(
                class_4925.method_67852(cooker)
                        .method_67859(method_25565(class_2741.field_12548, litVariant, baseVariant))
                        .method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
        );
    }

    public void registerBaseMachineBlockSameSide(class_2248 cooker, class_4946.class_4947 modelFactory) {
        Map<class_4945, String> faceTextureSuffixes = Map.of(
                class_4945.field_23024, "_down",
                class_4945.field_23023, "_up",
                class_4945.field_23019, "_front",
                class_4945.field_23020, "_back",
                class_4945.field_23022, "_side",
                class_4945.field_23021, "_side"
        );

        class_807 baseVariant = method_67835(
                modelFactory.get(cooker).method_25917(textures -> {
                    faceTextureSuffixes.forEach((key, suffix) -> {
                        textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                    });
                }).method_25916(cooker, generator.field_22831)
        );

        class_807 litVariant = method_67835(
                modelFactory.get(cooker).method_25917(textures -> {
                    faceTextureSuffixes.forEach((key, suffix) -> {
                        if (key == class_4945.field_23019) {
                            textures.method_25868(key, class_4944.method_25866(cooker, "_front_on"));
                        } else {
                            textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                        }
                    });
                }).method_25915(cooker, "_on", generator.field_22831)
        );

        generator.field_22830.accept(
                class_4925.method_67852(cooker)
                        .method_67859(method_25565(class_2741.field_12548, litVariant, baseVariant))
                        .method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
        );
    }

    public void registerBaseMachineBlockSameUpAndDown(class_2248 cooker, class_4946.class_4947 modelFactory) {
        Map<class_4945, String> faceTextureSuffixes = Map.of(
                class_4945.field_23024, "_side",
                class_4945.field_23023, "_side",
                class_4945.field_23019, "_front",
                class_4945.field_23020, "_back",
                class_4945.field_23022, "_left",
                class_4945.field_23021, "_right"
        );

        class_807 baseVariant = method_67835(
                modelFactory.get(cooker).method_25917(textures -> {
                    faceTextureSuffixes.forEach((key, suffix) -> {
                        textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                    });
                }).method_25916(cooker, generator.field_22831)
        );

        class_807 litVariant = method_67835(
                modelFactory.get(cooker).method_25917(textures -> {
                    faceTextureSuffixes.forEach((key, suffix) -> {
                        if (key == class_4945.field_23019) {
                            textures.method_25868(key, class_4944.method_25866(cooker, "_front_on"));
                        } else {
                            textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                        }
                    });
                }).method_25915(cooker, "_on", generator.field_22831)
        );

        generator.field_22830.accept(
                class_4925.method_67852(cooker)
                        .method_67859(method_25565(class_2741.field_12548, litVariant, baseVariant))
                        .method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
        );
    }

    public void registerBaseMachineBlockSameUpDownSide(class_2248 cooker, class_4946.class_4947 modelFactory) {
        Map<class_4945, String> faceTextureSuffixes = Map.of(
                class_4945.field_23024, "_side",
                class_4945.field_23023, "_side",
                class_4945.field_23019, "_front",
                class_4945.field_23020, "_back",
                class_4945.field_23022, "_side",
                class_4945.field_23021, "_side"
        );

        class_807 baseVariant = method_67835(
                modelFactory.get(cooker).method_25917(textures -> {
                    faceTextureSuffixes.forEach((key, suffix) -> {
                        textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                    });
                }).method_25916(cooker, generator.field_22831)
        );

        class_807 litVariant = method_67835(
                modelFactory.get(cooker).method_25917(textures -> {
                    faceTextureSuffixes.forEach((key, suffix) -> {
                        if (key == class_4945.field_23019) {
                            textures.method_25868(key, class_4944.method_25866(cooker, "_front_on"));
                        } else {
                            textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                        }
                    });
                }).method_25915(cooker, "_on", generator.field_22831)
        );

        generator.field_22830.accept(
                class_4925.method_67852(cooker)
                        .method_67859(method_25565(class_2741.field_12548, litVariant, baseVariant))
                        .method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
        );
    }

    public void registerBaseMachineBlockSameSideBack(class_2248 cooker, class_4946.class_4947 modelFactory) {
        Map<class_4945, String> faceTextureSuffixes = Map.of(
                class_4945.field_23024, "_bottom",
                class_4945.field_23023, "_top",
                class_4945.field_23019, "_front",
                class_4945.field_23020, "_leftrightback",
                class_4945.field_23022, "_leftrightback",
                class_4945.field_23021, "_leftrightback"
        );

        class_807 baseVariant = method_67835(
                modelFactory.get(cooker).method_25917(textures -> {
                    faceTextureSuffixes.forEach((key, suffix) -> {
                        textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                    });
                }).method_25916(cooker, generator.field_22831)
        );

        class_807 litVariant = method_67835(
                modelFactory.get(cooker).method_25917(textures -> {
                    faceTextureSuffixes.forEach((key, suffix) -> {
                        if (key == class_4945.field_23019) {
                            textures.method_25868(key, class_4944.method_25866(cooker, "_front_active"));
                        } else {
                            textures.method_25868(key, class_4944.method_25866(cooker, suffix));
                        }
                    });
                }).method_25915(cooker, "_active", generator.field_22831)
        );

        generator.field_22830.accept(
                class_4925.method_67852(cooker)
                        .method_67859(method_25565(class_2741.field_12548, litVariant, baseVariant))
                        .method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
        );
    }

    public void registerMachine(class_2248 block, boolean hasActiveTexture) {

        class_807 baseVariant = method_67835(
                ModTexturedModel.CUBE.get(block).method_25917(textures -> {
                    textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
                    textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_top"));

                    textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

                    textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
                }).method_25916(block, generator.field_22831)
        );

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_67853(block, baseVariant).method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
            );
            return;
        }

        class_807 litVariant = method_67835(
                ModTexturedModel.CUBE.get(block).method_25917(textures -> {
                    textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
                    textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_top"));

                    textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

                    textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
                }).method_25915(block, "_active", generator.field_22831)
        );

        generator.field_22830.accept(
                class_4925.method_67852(block)
                        .method_67859(method_25565(class_2741.field_12548, litVariant, baseVariant))
                        .method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
        );
    }

    public void registerMachineSameNorthSouth(class_2248 block, boolean hasActiveTexture) {

        class_807 baseVariant = method_67835(
                ModTexturedModel.CUBE.get(block).method_25917(textures -> {
                    textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
                    textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_top"));

                    textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

                    textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_front"));
                    textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
                }).method_25916(block, generator.field_22831)
        );

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_67853(block, baseVariant).method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
            );
            return;
        }

        class_807 litVariant = method_67835(
                ModTexturedModel.CUBE.get(block).method_25917(textures -> {
                    textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
                    textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_top"));

                    textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

                    textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_front_active"));
                    textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
                }).method_25915(block, "_active", generator.field_22831)
        );

        generator.field_22830.accept(
                class_4925.method_67852(block)
                        .method_67859(method_25565(class_2741.field_12548, litVariant, baseVariant))
                        .method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
        );
    }

    public void registerMachineSameSide(class_2248 block) {

        class_807 baseVariant = method_67835(
                ModTexturedModel.CUBE.get(block).method_25917(textures -> {
                    textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
                    textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

                    textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_side"));

                    textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
                }).method_25916(block, generator.field_22831)
        );

        generator.field_22830.accept(
                class_4925.method_67853(block, baseVariant).method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
        );
    }


    public void registerMachineDiffBottom(class_2248 block, boolean hasActiveTexture) {

        class_807 baseVariant = method_67835(
                ModTexturedModel.CUBE.get(block).method_25917(textures -> {
                    textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
                    textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

                    textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

                    textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
                }).method_25916(block, generator.field_22831)
        );

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_67853(block, baseVariant).method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
            );
            return;
        }

        class_807 litVariant = method_67835(
                ModTexturedModel.CUBE.get(block).method_25917(textures -> {
                    textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top_active"));
                    textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

                    textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

                    textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
                }).method_25915(block, "_active", generator.field_22831)
        );

        generator.field_22830.accept(
                class_4925.method_67852(block)
                        .method_67859(method_25565(class_2741.field_12548, litVariant, baseVariant))
                        .method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
        );
    }

    public void registerMachineDiffBottomBack(class_2248 block, boolean hasActiveTexture) {

        class_807 baseVariant = method_67835(
                ModTexturedModel.CUBE.get(block).method_25917(textures -> {
                    textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
                    textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

                    textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

                    textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
                    textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
                }).method_25916(block, generator.field_22831)
        );

        if (!hasActiveTexture) {
            generator.field_22830.accept(
                    class_4925.method_67853(block, baseVariant).method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
            );
            return;
        }

        class_807 litVariant = method_67835(
                ModTexturedModel.CUBE.get(block).method_25917(textures -> {
                    textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top_active"));
                    textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_bottom"));

                    textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front_active"));

                    textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_back"));
                    textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
                }).method_25915(block, "_active", generator.field_22831)
        );

        generator.field_22830.accept(
                class_4925.method_67852(block)
                        .method_67859(method_25565(class_2741.field_12548, litVariant, baseVariant))
                        .method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
        );
    }

    public void registerCable(class_2248 block) {
        class_807 baseVariant = method_67835(
                ModTexturedModel.CUBE.get(block).method_25917(textures -> {
                    textures.method_25868(class_4945.field_23023, class_4944.method_25866(block, "_top"));
                    textures.method_25868(class_4945.field_23024, class_4944.method_25866(block, "_top"));

                    textures.method_25868(class_4945.field_23019, class_4944.method_25866(block, "_front"));

                    textures.method_25868(class_4945.field_23020, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23022, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23021, class_4944.method_25866(block, "_side"));
                    textures.method_25868(class_4945.field_23012, class_4944.method_25866(block, "_side"));
                }).method_25916(block, generator.field_22831)
        );

        generator.field_22830.accept(
                class_4925.method_67853(block, baseVariant).method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS)
        );
    }




    public void registerModSweetBerryBush(class_1792 fruititem, class_2248 block) {
        generator.method_25537(fruititem);
        generator.field_22830.accept(class_4925.method_67852(block)
                .method_67859(class_4926.method_67864(class_2741.field_12497).method_25795(stage ->
                                method_67835(
                                generator.method_25557(block, "_stage" + stage, class_4943.field_22921, class_4944::method_25880)
                        )
                ))
        );
    }

    public void registerModBookshelf(class_2248 block, class_2248 plank) {
        class_4944 textureMap = class_4944.method_25870(class_4944.method_25860(block), class_4944.method_25860(plank));
        class_807 identifier = method_67835(class_4943.field_22974.method_25846(block, textureMap, generator.field_22831));
        generator.field_22830.accept(class_4910.method_25644(block, identifier));
    }

    public void registerLamp(class_2248 block) {
        class_807 identifier = method_67835(class_4941.method_25842(block));
        class_807 identifier2 = method_67835(class_4941.method_25843(block,"_on"));
        generator.field_22830.accept(class_4925.method_67852(block).method_67859(method_25565(class_2741.field_12548, identifier2, identifier)));
    }

    public final void registerBlockState(class_2248 block) {
        generator.field_22830.accept(class_4925.method_67853(block, method_67835(class_4941.method_25842(block))));
    }

    public void registerFridge(class_2248 block) {
        class_2960 bottomModel = class_4941.method_25843(block, "_bottom");
        class_2960 topModel = class_4941.method_25843(block, "_top");

        class_4926.class_4928<class_807,class_2350, class_2756> variantMap =
                class_4926.method_67865(class_2741.field_12481, class_2741.field_12533);

        fillSimpleDoubleVariantMap(variantMap, class_2756.field_12607, bottomModel);
        fillSimpleDoubleVariantMap(variantMap, class_2756.field_12609, topModel);

        generator.field_22830.accept(class_4925.method_67852(block).method_67859(variantMap));
    }


    public static class_4926.class_4928<class_807, class_2350, class_2756> fillSimpleDoubleVariantMap(
            class_4926.class_4928<class_807, class_2350, class_2756> variantMap,
            class_2756 targetHalf,
            class_2960 baseModelId
    ) {
        return variantMap
                .method_25798(class_2350.field_11043, targetHalf, method_67835(baseModelId))
                .method_25798(class_2350.field_11034, targetHalf, method_67835(baseModelId).method_67929(class_10804.field_56937.withValue(class_10821.field_57030)))
                .method_25798(class_2350.field_11035, targetHalf, method_67835(baseModelId).method_67929(class_10804.field_56937.withValue(class_10821.field_57031)))
                .method_25798(class_2350.field_11039, targetHalf, method_67835(baseModelId).method_67929(class_10804.field_56937.withValue(class_10821.field_57032)));
    }

    public void registerPaperSlidingDoor(class_2248 doorBlock) {
        class_807 weightedVariant = method_67835(class_4941.method_25843(doorBlock, "_bottom_left"));
        class_807 weightedVariant2 = method_67835(class_4941.method_25843(doorBlock, "_bottom_left_open"));
        class_807 weightedVariant3 = method_67835(class_4941.method_25843(doorBlock, "_bottom_right"));
        class_807 weightedVariant4 = method_67835(class_4941.method_25843(doorBlock, "_bottom_right_open"));
        class_807 weightedVariant5 = method_67835(class_4941.method_25843(doorBlock, "_top_left"));
        class_807 weightedVariant6 = method_67835(class_4941.method_25843(doorBlock, "_top_left_open"));
        class_807 weightedVariant7 = method_67835(class_4941.method_25843(doorBlock, "_top_right"));
        class_807 weightedVariant8 = method_67835(class_4941.method_25843(doorBlock, "_top_right_open"));
        generator.field_22830.accept(createDoorBlockState(doorBlock, weightedVariant, weightedVariant2, weightedVariant3, weightedVariant4, weightedVariant5, weightedVariant6, weightedVariant7, weightedVariant8));
    }

    public static class_4917 createDoorBlockState(class_2248 doorBlock, class_807 bottomLeftClosedModel, class_807 bottomLeftOpenModel, class_807 bottomRightClosedModel, class_807 bottomRightOpenModel, class_807 topLeftClosedModel, class_807 topLeftOpenModel, class_807 topRightClosedModel, class_807 topRightOpenModel) {
        return class_4925.method_67852(doorBlock)
                .method_67859(class_4926
                        .method_67867(class_2741.field_12481, class_2741.field_12533, class_2741.field_12520, class_2741.field_12537)
                        .method_25812(class_2350.field_11034, class_2756.field_12607, class_2750.field_12588, false, bottomLeftClosedModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12607, class_2750.field_12588, false, bottomLeftClosedModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12607, class_2750.field_12588, false, bottomLeftClosedModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12607, class_2750.field_12588, false, bottomLeftClosedModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12607, class_2750.field_12586, false, bottomRightClosedModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12607, class_2750.field_12586, false, bottomRightClosedModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12607, class_2750.field_12586, false, bottomRightClosedModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12607, class_2750.field_12586, false, bottomRightClosedModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12607, class_2750.field_12588, true, bottomLeftOpenModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12607, class_2750.field_12588, true, bottomLeftOpenModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12607, class_2750.field_12588, true, bottomLeftOpenModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12607, class_2750.field_12588, true, bottomLeftOpenModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12607, class_2750.field_12586, true, bottomRightOpenModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12607, class_2750.field_12586, true, bottomRightOpenModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12607, class_2750.field_12586, true, bottomRightOpenModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12607, class_2750.field_12586, true, bottomRightOpenModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12609, class_2750.field_12588, false, topLeftClosedModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12609, class_2750.field_12588, false, topLeftClosedModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12609, class_2750.field_12588, false, topLeftClosedModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12609, class_2750.field_12588, false, topLeftClosedModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12609, class_2750.field_12586, false, topRightClosedModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12609, class_2750.field_12586, false, topRightClosedModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12609, class_2750.field_12586, false, topRightClosedModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12609, class_2750.field_12586, false, topRightClosedModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12609, class_2750.field_12588, true, topLeftOpenModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12609, class_2750.field_12588, true, topLeftOpenModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12609, class_2750.field_12588, true, topLeftOpenModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12609, class_2750.field_12588, true, topLeftOpenModel.method_67929(field_56786))
                        .method_25812(class_2350.field_11034, class_2756.field_12609, class_2750.field_12586, true, topRightOpenModel.method_67929(field_56787))
                        .method_25812(class_2350.field_11035, class_2756.field_12609, class_2750.field_12586, true, topRightOpenModel)
                        .method_25812(class_2350.field_11039, class_2756.field_12609, class_2750.field_12586, true, topRightOpenModel.method_67929(field_56785))
                        .method_25812(class_2350.field_11043, class_2756.field_12609, class_2750.field_12586, true, topRightOpenModel.method_67929(field_56786)));
    }


    public void registerTV(class_2248 block) {
        class_807 identifier = method_67835(class_4941.method_25842(block));
        class_807 identifier2 = method_67835(class_4941.method_25843(block,"_open"));
        generator.field_22830.accept(class_4925.method_67852(block).method_67859(method_25565(class_2741.field_12548, identifier2, identifier)).method_25775(NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS));
    }

    public static class_4926.class_4928<class_807, class_2350, class_2742> fillSimpleDoubleVariantMap(
            class_4926.class_4928<class_807, class_2350, class_2742> variantMap,
            class_2742 targetHalf,
            class_2960 baseModelId
    ) {
        return variantMap
                .method_25798(class_2350.field_11043, targetHalf, method_67835(baseModelId))
                .method_25798(class_2350.field_11034, targetHalf, method_67835(baseModelId).method_67929(class_10804.field_56937.withValue(class_10821.field_57030)))
                .method_25798(class_2350.field_11035, targetHalf, method_67835(baseModelId).method_67929(class_10804.field_56937.withValue(class_10821.field_57031)))
                .method_25798(class_2350.field_11039, targetHalf, method_67835(baseModelId).method_67929(class_10804.field_56937.withValue(class_10821.field_57032)));
    }

    static {
        NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS = class_4926.method_67869(class_2741.field_12481).method_25794(class_2350.field_11034, field_56785).method_25794(class_2350.field_11035, field_56786).method_25794(class_2350.field_11039, field_56787).method_25794(class_2350.field_11043, field_56780);
    }
}