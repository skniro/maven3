package com.skniro.industrial_elixir.item.init;

import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.api.item.TieredEnergyItem;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.base.SimpleEnergyItem;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_6880;
import net.minecraft.class_9300;
import net.minecraft.class_9334;

public class ElectricJetpackItem extends class_1738 implements SimpleEnergyItem, TieredEnergyItem {

    private static final long CAPACITY = 300000;

    private final EnergyTier energyTier;

    public ElectricJetpackItem(class_1793 settings, class_6880<class_1741> material, class_1738.class_8051 chestplate, EnergyTier energyTier) {
        super(material, chestplate, settings.method_7889(1)
                .method_57349(class_9334.field_49630, new class_9300(false)));
        this.energyTier = energyTier;
        EnergyStorage.ITEM.registerForItems((stack, context) ->
                SimpleEnergyItem.createStorage(context, this.getEnergyCapacity(stack),
                        this.getEnergyMaxInput(stack), this.getEnergyMaxOutput(stack)), this);
    }

    // ===============================================
    // Energy
    // ===============================================

    @Override
    public long getEnergyCapacity(class_1799 stack) { return CAPACITY; }

    @Override
    public long getEnergyMaxInput(class_1799 stack) { return energyTier.getMaxInput(); }

    @Override
    public long getEnergyMaxOutput(class_1799 stack) { return 0; }

    @Override
    public EnergyTier getEnergyTier() { return energyTier; }

    // ===============================================
    // Durability bar → energy bar
    // ===============================================

    @Override
    public boolean method_31567(class_1799 stack) { return true; }

    @Override
    public int method_31569(class_1799 stack) {
        return Math.round((float) getStoredEnergy(stack) * 13.0F / (float) getEnergyCapacity(stack));
    }

    @Override
    public int method_31571(class_1799 stack) { return 0x00FFFF; }

    // ===============================================
    // Tick — jetpack flight delegated to JetpackHelper
    // ===============================================

    @Override
    public void method_7888(class_1799 stack, class_1937 level, class_1297 entity, int slotId, boolean selected) {
        if (!(entity instanceof class_1657 player)) return;
        // 26.1's ServerLevel signature limited this logic to the server side.
        if (level.method_8608()) return;
        if (player.method_6118(class_1304.field_6174) != stack) return;

        boolean powered = getStoredEnergy(stack) > 0;

        if (player.method_5809()) player.method_5646();

        JetpackHelper.onChestplateTick(player, powered,
                JetpackHelper.FLIGHT_COST_PER_TICK,
                JetpackHelper.HOVER_COST_PER_TICK);
    }
}
