package com.skniro.industrial_elixir.block.entity.energybox;

import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.api.item.TieredEnergyItem;
import com.skniro.industrial_elixir.block.entity.BasePowerBlockBlockEntity;
import com.skniro.industrial_elixir.block.init.energybox.ChargePadBlock;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.EnergyStorageUtil;
import com.skniro.industrial_elixir.energy.api.base.SimpleSidedEnergyContainer;
import com.skniro.industrial_elixir.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2383;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3913;
import org.jetbrains.annotations.Nullable;

import java.util.List;


public abstract class BaseEnergyBoxBlockEntity extends BasePowerBlockBlockEntity {
    // NOTE: do not redeclare energyContainer here. The directional container below replaces the
    // field from BasePowerBlockBlockEntity; a local field would hide it and leave inherited code
    // (pushEnergyToNeighbours, getFreeSpace, ...) looking at the unused base instance.
    protected final class_3913 propertyDelegate;

    public BaseEnergyBoxBlockEntity(class_2591<?> blockEntityType, class_2338 pos, class_2680 state) {
        super(blockEntityType, pos, state);
        energyContainer = new SimpleSidedEnergyContainer() {

            @Override
            public long getCapacity() {
                return getMachineCapacity();
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                if (side == null) return energyTier.getMaxInput();
                class_2350 front = method_11010().method_11654(class_2383.field_11177);
                if (side == front) return energyTier.getMaxInput();
                return 0;
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                if (side == null) return energyTier.getMaxOutput();
                class_2350 front = method_11010().method_11654(class_2383.field_11177);
                if (side == front) {
                    return 0;
                }
                return energyTier.getMaxOutput();
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(pos, method_11010(), method_11010(), 3);
            }
        };

        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return 0;
            }

            @Override
            public void method_17391(int index, int value) {
            }

            @Override
            public int method_17389() {
                return 0;
            }
        };
    }

    public EnergyStorage getSideEnergyStorage(@Nullable class_2350 side) {
        return this.energyContainer.getSideStorage(side);
    }


    public void discharge(int slot) {
        if (this.field_11863 != null) {
            if (!this.field_11863.method_8608()) {
                if (!this.getOptionalInventory().isEmpty()) {
                    class_1263 inventory = this.getOptionalInventory().get();
                    EnergyStorageUtil.move(this.getSideEnergyStorage(null), ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(slot)).find(EnergyStorage.ITEM), Long.MAX_VALUE, null);
                }
            }
        }
    }

    public void charge(int slot) {
        if (this.field_11863 != null) {
            if (!this.field_11863.method_8608()) {
                long chargeEnergy = Math.min(this.getFreeSpace(), energyTier.getMaxInput());
                if (chargeEnergy > 0L) {
                    if (!this.getOptionalInventory().isEmpty()) {
                        class_1263 inventory = this.getOptionalInventory().get();
                        EnergyStorageUtil.move(ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(slot)).find(EnergyStorage.ITEM), this.getSideEnergyStorage(null), Long.MAX_VALUE, null);
                    }
                }
            }
        }
    }

    public void chargePlayersAbove() {
        if (field_11863 == null || field_11863.method_8608()) return;

        class_238 box = new class_238(field_11867).method_989(0, 1, 0);
        List<class_1657> players = field_11863.method_8390(class_1657.class, box, p -> true);
        boolean hasPlayer = !players.isEmpty();
        class_2680 state = field_11863.method_8320(field_11867);

        if (!hasPlayer || energyContainer.amount <= 0) {
            if (state.method_11654(ChargePadBlock.LIT)) {
                field_11863.method_8652(field_11867, state.method_11657(ChargePadBlock.LIT, false), 3);
            }
            return;
        }

        boolean charged = false;
        for (class_1657 player : players) {
            class_1661 inv = player.method_31548();

            for (int i = 0; i < inv.method_5439(); i++) {
                if (energyContainer.amount <= 0) break;

                class_1799 stack = inv.method_5438(i);
                if (!stack.method_7960() && stack.method_7909() instanceof TieredEnergyItem energyItem) {
                    int itemTier = energyItem.getEnergyTier().ordinal();
                    if (itemTier >= this.energyTier.ordinal()) {
                        class_1263 inventory = player.method_31548();
                        long moved = EnergyStorageUtil.move(this.getSideEnergyStorage(null), ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(i)).find(EnergyStorage.ITEM), Long.MAX_VALUE, null);
                        if (moved > 0) {
                            charged = true;
                        }
                    }
                }
            }
        }

        if (state.method_11654(ChargePadBlock.LIT) != charged) {
            field_11863.method_8652(field_11867, state.method_11657(ChargePadBlock.LIT, charged), 3);
        }
    }

    private void chargeItem(class_1799 stack) {
        EnergyStorageUtil.move(this.getSideEnergyStorage(null), ContainerItemContext.withConstant(stack).find(EnergyStorage.ITEM), Long.MAX_VALUE, null);
    }

    public long getFreeSpace() {
        return this.energyContainer.getCapacity() - energyContainer.amount;
    }


    public boolean canInsert(class_1799 stack) {
        return stack.method_31573(ModItemTags.BATTERY);
    }


}