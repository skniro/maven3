package com.skniro.maple.item.init.equipment;

import com.skniro.maple.Maple;
import net.minecraft.class_10191;
import net.minecraft.class_10394;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public interface MapleEquipmentAssetKeys {
    class_5321<class_10394> Cherry = register("cherry");

    static class_5321<class_10394> register(String name) {
        return class_5321.method_29179(class_10191.field_55214, class_2960.method_60655(Maple.MOD_ID,name));
    }

    public static void registerMapleArmorAssetsKeys() {
        Maple.LOGGER.info("Registering Maple armor assets Keys for " + Maple.MOD_ID);
    }
}