package com.skniro.industrial_elixir.block;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.ModContent;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.init.*;
import com.skniro.industrial_elixir.block.init.energybox.ChargePadBlock;
import com.skniro.industrial_elixir.block.init.energybox.EnergyBoxBlock;
import com.skniro.industrial_elixir.block.init.generator.init.ElectricHeaterBlock;
import com.skniro.industrial_elixir.block.init.generator.init.SolidFuelHeaterBlock;
import com.skniro.industrial_elixir.block.init.machine.fluid.BrewReactorBlock;
import com.skniro.industrial_elixir.block.init.container.fluid.FluidTankBlock;
import com.skniro.industrial_elixir.block.init.generator.CoalGeneratorBlock;
import com.skniro.industrial_elixir.block.init.generator.FluidGeneratorBlock;
import com.skniro.industrial_elixir.block.init.generator.SacredGeneratorBlock;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.init.generator.GeneratorSolarPanelBlock;
import com.skniro.industrial_elixir.block.init.generator.GeneratorWindMillBlock;
import com.skniro.industrial_elixir.block.init.generator.NuclearReactorBlock;
import com.skniro.industrial_elixir.block.init.machine.*;
import com.skniro.industrial_elixir.block.init.machine.fluid.CoffeeMachineBlock;
import com.skniro.industrial_elixir.block.init.machine.fluid.OreWashingBlock;
import com.skniro.industrial_elixir.block.init.machine.fluid.ReplicatorBlock;
import com.skniro.industrial_elixir.block.init.machine.heat.ModBlastFurnaceBlock;
import com.skniro.industrial_elixir.block.init.pipe.StoneFluidPipeBlock;
import com.skniro.industrial_elixir.block.init.pipe.StonePipeBlock;
import com.skniro.industrial_elixir.block.init.pipe.WoodFluidPipeBlock;
import com.skniro.industrial_elixir.block.init.pipe.WoodPipeBlock;
import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class GrowableOresBlocks {
    public static final class_2248 GrowableOres_Block =registerBlock("growableores_block", Alchemyblock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));

    public static final class_2248 Macerator_Block =registerBlock("macerator", MaceratorBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 Compressor_Block =registerBlock("compressor", CompressorBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 MATTER_GENERATOR = registerBlock("matter_generator", MatterGeneratorBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 FLUID_GENERATOR = registerBlock("fluid_generator", FluidGeneratorBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 MetalFormerBlock =registerBlock("metalformer", MetalFormerBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));

    public static final class_2248 COPPER_CABLE = registerBlock("copper_cable", (settings)-> new CableBlock(settings, ModContent.Cables.COPPER, "copper"), class_4970.class_2251.method_9637().method_9626(class_2498.field_11533).method_31710(class_3620.field_16005).method_9629(3.0F, 8.0F));
    public static final class_2248 TIN_CABLE = registerBlock("tin_cable", (settings)-> new CableBlock(settings, ModContent.Cables.TIN, "tin"), class_4970.class_2251.method_9637().method_9626(class_2498.field_11533).method_31710(class_3620.field_16005).method_9629(3.0F, 8.0F));
    public static final class_2248 GOLD_CABLE = registerBlock("gold_cable", (settings)-> new CableBlock(settings, ModContent.Cables.GOLD, "gold"), class_4970.class_2251.method_9637().method_9626(class_2498.field_11533).method_31710(class_3620.field_16005).method_9629(3.0F, 8.0F));
    public static final class_2248 HV_CABLE = registerBlock("hv_cable", (settings)-> new CableBlock(settings, ModContent.Cables.HV, "hv"), class_4970.class_2251.method_9637().method_9626(class_2498.field_11533).method_31710(class_3620.field_16005).method_9629(3.0F, 8.0F));
    public static final class_2248 GLASSFIBER_CABLE = registerBlock("glassfiber_cable", (settings)-> new CableBlock(settings, ModContent.Cables.GLASSFIBER, "glassfiber"), class_4970.class_2251.method_9637().method_9626(class_2498.field_11533).method_31710(class_3620.field_16005).method_9629(3.0F, 8.0F));
    public static final class_2248 INSULATED_TIN_CABLE = registerBlock("insulated_tin_cable", (settings)-> new CableBlock(settings, ModContent.Cables.INSULATED_TIN, "insulated_tin"), class_4970.class_2251.method_9637().method_9626(class_2498.field_11533).method_31710(class_3620.field_16005).method_9629(3.0F, 8.0F));
    public static final class_2248 INSULATED_COPPER_CABLE = registerBlock("insulated_copper_cable", (settings)-> new CableBlock(settings, ModContent.Cables.INSULATED_COPPER, "insulated_copper"), class_4970.class_2251.method_9637().method_9626(class_2498.field_11533).method_31710(class_3620.field_16005).method_9629(3.0F, 8.0F));
    public static final class_2248 INSULATED_GOLD_CABLE = registerBlock("insulated_gold_cable", (settings)-> new CableBlock(settings, ModContent.Cables.INSULATED_GOLD, "insulated_gold"), class_4970.class_2251.method_9637().method_9626(class_2498.field_11533).method_31710(class_3620.field_16005).method_9629(3.0F, 8.0F));
    public static final class_2248 INSULATED_HV_CABLE = registerBlock("insulated_hv_cable", (settings)-> new CableBlock(settings, ModContent.Cables.INSULATED_HV, "insulated_hv"), class_4970.class_2251.method_9637().method_9626(class_2498.field_11533).method_31710(class_3620.field_16005).method_9629(3.0F, 8.0F));

    public static final class_2248 COAL_GENERATOR = registerBlock("coal_generator", CoalGeneratorBlock::new, (class_4970.class_2251.method_9637().method_9629(3.0F, 3.0F).method_29292().method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 NUCLEAR_REACTOR = registerBlock("nuclear_reactor", NuclearReactorBlock::new, (class_4970.class_2251.method_9637().method_9629(5.0F, 10.0F).method_29292().method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 SACRED_GENERATOR = registerBlock("sacred_generator", (settings) -> new SacredGeneratorBlock(settings, EnergyTier.TIER3, 4096), (class_4970.class_2251.method_9637().method_29292().method_9629(5.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));

    public static final class_2248 GENERATOR_Wind_Mill =registerBlock("generator_wind_mill", GeneratorWindMillBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));

    public static final class_2248 EnergyBox =registerBlock("energy_box", (settings)-> new EnergyBoxBlock(settings, 40000, EnergyTier.TIER1), (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));
    public static final class_2248 ChargePad =registerBlock("charge_pad", (settings)-> new ChargePadBlock(settings, 40000, EnergyTier.TIER1), (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));
    public static final class_2248 CESU = registerBlock("cesu", s -> new EnergyBoxBlock(s, 300000, EnergyTier.TIER2), class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F));
    public static final class_2248 MFE = registerBlock("mfe", s -> new EnergyBoxBlock(s, 4000000, EnergyTier.TIER3), class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F));
    public static final class_2248 MFSU = registerBlock("mfsu", s -> new EnergyBoxBlock(s, 40000000, EnergyTier.TIER4), class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F));
    public static final class_2248 CESU_CHARGE_PAD = registerBlock("charge_pad_cesu", s -> new ChargePadBlock(s, 300000, EnergyTier.TIER2), class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F));
    public static final class_2248 MFE_CHARGE_PAD = registerBlock("charge_pad_mfe", s -> new ChargePadBlock(s, 4000000, EnergyTier.TIER3), class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F));
    public static final class_2248 MFSU_CHARGE_PAD = registerBlock("charge_pad_mfsu", s -> new ChargePadBlock(s, 40000000, EnergyTier.TIER4), class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F));

    public static final class_2248 MolecularTransformerBlock =registerBlock("molecular_transformer_block", MolecularTransformerBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));

    public static final class_2248 GENERATOR_SolarPanel = registerSolar("generator_solar_panel", EnergyTier.TIER1, 1, 0, 1000);
    public static final class_2248 GENERATOR_ADVANCED_SOLAR_PANEL = registerSolar("generator_advanced_solar_panel", EnergyTier.TIER2, 8, 1, 10000);
    public static final class_2248 GENERATOR_HYBRID_SOLAR_PANEL = registerSolar("generator_hybrid_solar_panel", EnergyTier.TIER3, 64, 8, 100000);
    public static final class_2248 GENERATOR_ULTIMATE_SOLAR_PANEL = registerSolar("generator_ultimate_solar_panel", EnergyTier.TIER4, 512, 64, 1000000);
    public static final class_2248 GENERATOR_QUANTUM_SOLAR_PANEL = registerSolar("generator_quantum_solar_panel", EnergyTier.TIER5, 4096, 2048, 10000000);

    public static final class_2248 Extractor_Block =registerBlock("extractor", ExtractorBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));

    public static final class_2248 EV_TRANSFORMER =registerBlock("ev_transformer", TransformerBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));
    public static final class_2248 HV_TRANSFORMER =registerBlock("hv_transformer", TransformerBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));
    public static final class_2248 MV_TRANSFORMER =registerBlock("mv_transformer", TransformerBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));
    public static final class_2248 LV_TRANSFORMER =registerBlock("lv_transformer", TransformerBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));

    public static final class_2248 Iron_Furnace_Block =registerBlock("iron_furnace", IronFurnaceBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));

    public static final class_2248 ElectricFurnace_Block =registerBlock("electric_furnace", ElectricFurnaceBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));
    public static final class_2248 INDUCTION_FURNACE = registerBlock("induction_furnace", InductionFurnaceBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 4.0F)));
    public static final class_2248 HEAT_CENTRIFUGE = registerBlock("heat_centrifuge", HeatCentrifugeBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 4.0F)));
    public static final class_2248 PATTERN_STORAGE = registerBlock("pattern_storage", PatternStorageBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));
    public static final class_2248 CUTTING_Block =registerBlock("cutting_block", CuttingBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));
    public static final class_2248 RECYCLER_Block =registerBlock("recycler_block", RecyclerBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));

    public static final class_2248 Pipe_Wooden_Iten_Block =registerBlock("pipe_wooden_item", WoodPipeBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));
    public static final class_2248 Pipe_Stone_Item_Block =registerBlock("pipe_stone_item", StonePipeBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));
    public static final class_2248 Pipe_Wooden_Fluid_Block =registerBlock("pipe_wooden_fluid", WoodFluidPipeBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));
    public static final class_2248 Pipe_Stone_Fluid_Block =registerBlock("pipe_stone_fluid", StoneFluidPipeBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)));
    public static final class_2248 FLUID_TANK_BLOCK =registerBlock("fluid_tank", FluidTankBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9632(1.5F).method_22488().method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 Brew_Reactor_BLOCK =registerBlock("brew_reactor_tank", BrewReactorBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9632(1.5F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 Ore_Washing_Block =registerBlock("ore_washing_block", OreWashingBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9632(1.5F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 Replicator =registerBlock("replicator", ReplicatorBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(4.0F, 5.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));

    public static final class_2248 CHUNK_LOADER = registerBlock("chunk_loader", ChunkLoaderBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));

    public static final class_2248 Electric_Heater_Block =registerBlock("electric_heater", ElectricHeaterBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 SOLID_FUEL_HEATER_GENERATOR = registerBlock("solid_fuel_heater_generator", (properties)-> new SolidFuelHeaterBlock(properties,1000), (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 BLAST_FURNACE_BLOCK =registerBlock("blast_furnace", ModBlastFurnaceBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 CROP_FARM_Block =registerBlock("crop_farm", CropFarmBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 VENDOR_MACHINE_Block =registerBlock("vendor_machine", VendorMachineBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005)));
    public static final class_2248 COFFEE_MACHINE_Block =registerBlock("coffee_machine_block", CoffeeMachineBlock::new, class_4970.class_2251.method_9637().method_22488().method_29292().method_9629(3.0F, 3.0F));

    private static class_2248 registerSolar(String name, EnergyTier tier, int DayPower, int NightPower, long capacity) {
        return registerBlock(name, (settings) -> new GeneratorSolarPanelBlock(settings, tier, DayPower, NightPower, capacity),
                class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F).method_9626(class_2498.field_11533).method_31710(class_3620.field_16005));
    }

    private static class_2248 registerBlockWithoutItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(IndustrialElixir.MOD_ID, name), block);
    }

    private static class_2248 registerCableBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings);
        registerBlockItem(name, block);
        return class_2378.method_39197(class_7923.field_41175, class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(IndustrialElixir.MOD_ID, name)), block);
    }

    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings);
        registerBlockItem(name, block);
        return class_2378.method_39197(class_7923.field_41175, class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(IndustrialElixir.MOD_ID, name)), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(IndustrialElixir.MOD_ID, name)),
                new class_1747(block, new class_1792.class_1793()
                        ));
    }

    public static void registerGrowableOresBlocks() {
        IndustrialElixir.LOGGER.info("Registering GrowableOres Blocks for " + IndustrialElixir.MOD_ID);
    }
}
