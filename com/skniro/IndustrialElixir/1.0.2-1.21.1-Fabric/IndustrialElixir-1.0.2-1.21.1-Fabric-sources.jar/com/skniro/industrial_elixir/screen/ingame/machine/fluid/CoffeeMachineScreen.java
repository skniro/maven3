package com.skniro.industrial_elixir.screen.ingame.machine.fluid;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.renderer.GuiFluidTankRenderer;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.CoffeeMachineScreenHandler;
import com.skniro.industrial_elixir.util.MouseUtil;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.util.List;
import java.util.Optional;

public class CoffeeMachineScreen extends class_465<CoffeeMachineScreenHandler> {
    private static final class_2960 TEXTURE =
            class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/machine/coffee_machine.png");
    private GuiFluidTankRenderer fluidRenderer;

    public CoffeeMachineScreen(CoffeeMachineScreenHandler menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25269 = 45;
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
        field_25268 = 4;
        fluidRenderer = new GuiFluidTankRenderer(field_2797.blockEntity.fluidContainer.getCapacity(), true, 16, 50);
    }

    public List<class_2561> getTooltips() {
        return List.of(class_2561.method_43470(field_2797.blockEntity.energyContainer.getSideStorage(null).getAmount() + " / " + field_2797.blockEntity.energyContainer.getSideStorage(null).getCapacity() + " E"));
    }

    private void renderEnergyArea(class_332 context, int x, int y) {
        context.method_25290(TEXTURE, x + 129, y + 45, 176, 0, 13, field_2797.getScaledEnergyHeight(), 256, 256);
    }

    @Override
    protected void method_2388(class_332 graphics, int xm, int ym) {
        super.method_2388(graphics, xm, ym);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        if (MouseUtil.isMouseOver(xm, ym, x + 131, y + 45, 13, 14)) {
            graphics.method_51437(Screens.getTextRenderer(this), getTooltips(), Optional.empty(), xm, ym);
        }
        if (MouseUtil.isMouseOver(xm, ym, x + 8, y + 5, fluidRenderer.getWidth(), fluidRenderer.getHeight())) {
            graphics.method_51437(this.field_22793, fluidRenderer.getTooltip(field_2797.blockEntity.fluidContainer), Optional.empty(), xm, ym);
        }
    }

    @Override
    protected void method_2389(class_332 graphics, float a, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        graphics.method_25290(TEXTURE, x, y, 0, 0, field_2792, field_2779, 256, 256);
        renderEnergyArea(graphics, x, y);
        fluidRenderer.render(graphics, x + 8, y + 5, field_2797.blockEntity.fluidContainer);
        renderProgressArrow(graphics, x, y);
    }

    private void renderProgressArrow(class_332 guiGraphics, int x, int y) {
        if (field_2797.isCrafting()) {
            guiGraphics.method_25290(TEXTURE, x + 70, y + 34, 189, 0, field_2797.getScaledProgress(), 16, 256, 256);
        }
    }
}
