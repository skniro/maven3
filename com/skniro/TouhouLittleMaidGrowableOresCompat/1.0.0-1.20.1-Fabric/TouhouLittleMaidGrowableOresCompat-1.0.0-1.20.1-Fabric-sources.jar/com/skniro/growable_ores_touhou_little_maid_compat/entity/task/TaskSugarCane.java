package com.skniro.growable_ores_touhou_little_maid_compat.entity.task;

import com.github.tartaricacid.touhoulittlemaid.api.task.IFarmTask;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.skniro.growable_ores_touhou_little_maid_compat.GrowableOresExtension;
import com.skniro.growableores.block.GrowableVanillaOresBlocks;
import com.skniro.growableores.block.init.GrowableOreCaneBlock;
import com.skniro.growableores.registry.tag.GrowableBlockTags;
import com.skniro.growableores.registry.tag.GrowableFluidTags;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_3610;

public class TaskSugarCane implements IFarmTask {
    private static final class_2960 UID = class_2960.method_43902(GrowableOresExtension.MOD_ID, "growable_cane");

    public class_2960 getUid() {
        return UID;
    }

    public class_1799 getIcon() {
        return GrowableVanillaOresBlocks.Iron_Cane.method_8389().method_7854();
    }

    public boolean isSeed(class_1799 stack) {
        return false;
    }

    public boolean canHarvest(EntityMaid maid, class_2338 cropPos, class_2680 cropState) {
        class_2680 blockDownState = maid.method_37908().method_8320(cropPos.method_10074());
        class_2680 blockDown2State = maid.method_37908().method_8320(cropPos.method_10087(2));
        return cropState.method_26204() instanceof GrowableOreCaneBlock && blockDownState.method_26204() instanceof GrowableOreCaneBlock && this.canSustainSugarCane(blockDown2State);
    }

    public void harvest(EntityMaid maid, class_2338 cropPos, class_2680 cropState) {
        maid.destroyBlock(cropPos);
    }

    public boolean canPlant(EntityMaid maid, class_2338 basePos, class_2680 baseState, class_1799 seed) {return false;}

    public class_1799 plant(EntityMaid maid, class_2338 basePos, class_2680 baseState, class_1799 seed) {return seed;}

    public double getCloseEnoughDist() {
        return (double)2.0F;
    }

    private boolean canSustainSugarCane(class_2680 state) {
        return state.method_26164(class_3481.field_29822) || state.method_26164(class_3481.field_15466) || state.method_26164(GrowableBlockTags.GrowBlock);
    }

    private boolean hasWaterSourceBlock(class_1937 world, class_2338 basePos) {
        for(class_2350 direction : class_2350.class_2353.field_11062) {
            class_2680 offsetState = world.method_8320(basePos.method_10093(direction));
            class_3610 fluidState = world.method_8316(basePos.method_10093(direction));
            if (fluidState.method_15767(class_3486.field_15517) || offsetState.method_27852(class_2246.field_10110) || fluidState.method_15767(GrowableFluidTags.GrowFluid)) {
                return true;
            }
        }

        return false;
    }
}
