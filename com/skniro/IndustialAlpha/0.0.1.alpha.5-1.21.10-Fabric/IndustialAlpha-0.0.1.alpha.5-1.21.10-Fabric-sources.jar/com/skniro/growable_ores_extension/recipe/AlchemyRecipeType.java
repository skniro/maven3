package com.skniro.growable_ores_extension.recipe;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.recipe.machine.*;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

public interface AlchemyRecipeType<T extends class_1860<?>> {
    public static final RecipeRegistration<AlchemyCraftingRecipe> CANE_CONVERTER =
            register("cane_converter", new AlchemyCraftingRecipe.Serializer());
    public static final RecipeRegistration<MaceratorCraftingRecipe> MACERATOR =
            register("macerator", new MaceratorCraftingRecipe.Serializer());
    public static final RecipeRegistration<CompressorCraftingRecipe> COMPRESSOR =
            register("compressor", new CompressorCraftingRecipe.Serializer());
    public static final RecipeRegistration<MetalFormerRollingCraftingRecipe> METALFORMER_ROLLING =
            register("metal_former_rolling", new MetalFormerRollingCraftingRecipe.Serializer());
    public static final RecipeRegistration<MetalFormerCuttingCraftingRecipe> METALFORMER_CUTTING =
            register("metal_former_cutting", new MetalFormerCuttingCraftingRecipe.Serializer());
    public static final RecipeRegistration<MetalFormerExtrudingCraftingRecipe> METALFORMER_EXTRUDING =
            register("metal_former_extruding", new MetalFormerExtrudingCraftingRecipe.Serializer());


    public static <R extends class_1860<?>> RecipeRegistration<R> register(String idName, class_1865<R> serializer) {
        class_2960 id = class_2960.method_60655(GrowableOresExtension.MOD_ID, idName);

        class_3956<R> type = class_2378.method_10230(class_7923.field_41188, id, new class_3956<R>() {
            @Override
            public String toString() {
                return idName;
            }
        });
        class_1865<R> ser = class_2378.method_10230(class_7923.field_41189, id, serializer);

        return new RecipeRegistration<>(type, ser);
    }

    public static class RecipeRegistration<R extends class_1860<?>> {
        public final class_3956<R> type;
        public final class_1865<R> serializer;

        public RecipeRegistration(class_3956<R> type, class_1865<R> serializer) {
            this.type = type;
            this.serializer = serializer;
        }
    }

    public static void registerRecipes() {
        GrowableOresExtension.LOGGER.info("Registering Custom Recipes for " + GrowableOresExtension.MOD_ID);
    }
}

