package com.skniro.growable_ores_extension.item.init.equipment;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import net.minecraft.class_10191;
import net.minecraft.class_10394;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public interface MapleEquipmentAssetKeys {
    class_5321<class_10394> QUANTUM = register("quantum");

    static class_5321<class_10394> register(String name) {
        return class_5321.method_29179(class_10191.field_55214, class_2960.method_60655(GrowableOresExtension.MOD_ID,name));
    }

    public static void registerMapleArmorAssetsKeys() {
        GrowableOresExtension.LOGGER.info("Registering Maple armor assets Keys for " + GrowableOresExtension.MOD_ID);
    }
}