package com.skniro.industrial_elixir.item.init;

import com.skniro.industrial_elixir.energy.api.base.SimpleEnergyItem;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;

/**
 * Shared IC2-style jetpack flight logic used by Quantum Chestplate and Electric Jetpack.
 * All state is static so it works across different item classes.
 */
public final class JetpackHelper {

    // ===============================================
    // Thrust constants
    // ===============================================

    public static final double THRUST_UP_FLIGHT = 0.30;
    public static final double THRUST_UP_HOVER = 0.08;
    public static final double THRUST_UP_HOVER_BOOST = 0.04;
    public static final double THRUST_FORWARD = 0.08;
    public static final double MAX_H_SPEED = 0.35;
    public static final double MAX_FALL_SPEED = -4;
    public static final long FLIGHT_COST_PER_TICK = 25;
    public static final long HOVER_COST_PER_TICK = 37;

    // ===============================================
    // Effect throttling
    // ===============================================

    private static final int PARTICLE_EVERY_TICKS = 2;
    private static final int SOUND_EVERY_TICKS = 4;

    // ===============================================
    // Per-player state
    // ===============================================

    private static final Map<UUID, Boolean> hoverToggled = new ConcurrentHashMap<>();
    private static final Map<UUID, Boolean> jumpHeld = new ConcurrentHashMap<>();
    private static final Map<UUID, Boolean> forwardHeld = new ConcurrentHashMap<>();
    private static final Map<UUID, Float> strafe = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> tickCounter = new ConcurrentHashMap<>();

    // ===============================================
    // Public API (called from network / lifecycle)
    // ===============================================

    public static void toggleHover(UUID playerId) {
        boolean wasOn = hoverToggled.getOrDefault(playerId, false);
        if (wasOn) {
            hoverToggled.remove(playerId);
        } else {
            hoverToggled.put(playerId, true);
        }
    }

    public static boolean isHoverToggled(UUID playerId) {
        return hoverToggled.getOrDefault(playerId, false);
    }

    public static void updateInput(UUID playerId, boolean jump, boolean forward, float s) {
        jumpHeld.put(playerId, jump);
        forwardHeld.put(playerId, forward);
        strafe.put(playerId, s);
    }

    public static void onUnequip(UUID playerId) {
        hoverToggled.remove(playerId);
        jumpHeld.remove(playerId);
        forwardHeld.remove(playerId);
        strafe.remove(playerId);
        tickCounter.remove(playerId);
    }

    // ===============================================
    // Per-tick handler — call from inventoryTick for CHEST slot
    // ===============================================

    public static void onChestplateTick(class_1657 player, boolean powered,
                                        long flightCostPerTick, long hoverCostPerTick) {
        UUID id = player.method_5667();
        boolean hover = isHoverToggled(id);

        if (!powered) {
            onUnequip(id);
            return;
        }

        boolean jh = jumpHeld.getOrDefault(id, false);
        float s = strafe.getOrDefault(id, 0f);
        boolean anyHoriz = forwardHeld.getOrDefault(id, false) || s != 0f;

        if (hover) {
            handleHover(player, id, jh, s, anyHoriz, hoverCostPerTick);
        } else {
            handleFlight(player, id, jh, s, anyHoriz, flightCostPerTick);
        }
    }

    // ===============================================
    // Flight / Hover modes
    // ===============================================

    private static void handleFlight(class_1657 player, UUID id, boolean jh, float s,
                                     boolean anyHoriz, long costPerTick) {
        if (!jh) {
            applySlowFall(player, MAX_FALL_SPEED);
            return;
        }

        class_1799 chest = player.method_6118(class_1304.field_6174);
        SimpleEnergyItem storage = (SimpleEnergyItem) chest.method_7909();
        if (!storage.tryUseEnergy(chest, costPerTick)) return;

        applyThrust(player, THRUST_UP_FLIGHT, THRUST_FORWARD, MAX_H_SPEED, s, anyHoriz);
        spawnEffects(player, id);
        player.field_6017 = 0;
    }

    private static void handleHover(class_1657 player, UUID id, boolean jh, float s,
                                    boolean anyHoriz, long costPerTick) {
        class_1799 chest = player.method_6118(class_1304.field_6174);
        SimpleEnergyItem storage = (SimpleEnergyItem) chest.method_7909();
        if (!storage.tryUseEnergy(chest, costPerTick)) {
            applySlowFall(player, MAX_FALL_SPEED);
            return;
        }

        double up = jh ? THRUST_UP_HOVER + THRUST_UP_HOVER_BOOST : THRUST_UP_HOVER;
        double fwd = anyHoriz ? THRUST_FORWARD * 0.4 : 0;
        applyThrust(player, up, fwd, MAX_H_SPEED * 0.3, s, anyHoriz);
        spawnEffects(player, id);
        player.field_6017 = 0;
    }

    // ===============================================
    // Physics helpers
    // ===============================================

    private static void applyThrust(class_1657 player, double upThrust, double forwardThrust,
                                    double maxHSpeed, float strafeVal, boolean anyHoriz) {
        var m = player.method_18798();
        double dy = m.method_10214() + upThrust;
        if (dy > upThrust * 1.5) dy = upThrust * 1.5;

        double dx = m.method_10216();
        double dz = m.method_10215();
        if (anyHoriz) {
            var look = player.method_5720();
            dx += look.field_1352 * forwardThrust;
            dz += look.field_1350 * forwardThrust;
            dx += (-look.field_1350) * strafeVal * forwardThrust;
            dz += look.field_1352 * strafeVal * forwardThrust;
        }

        double hs = Math.sqrt(dx * dx + dz * dz);
        if (hs > maxHSpeed) {
            double scale = maxHSpeed / hs;
            dx *= scale;
            dz *= scale;
        }

        player.method_18800(dx, dy, dz);
        player.field_6037 = true;
    }

    private static void applySlowFall(class_1657 player, double maxFallSpeed) {
        var m = player.method_18798();
        if (m.method_10214() < maxFallSpeed) {
            player.method_18800(m.method_10216(), maxFallSpeed, m.method_10215());
            player.field_6037 = true;
        }
    }

    // ===============================================
    // Particles and sound
    // ===============================================

    private static void spawnEffects(class_1657 player, UUID id) {
        if (!(player.method_37908() instanceof class_3218 level)) return;
        int t = tickCounter.getOrDefault(id, 0) + 1;
        tickCounter.put(id, t);

        if (t % PARTICLE_EVERY_TICKS == 0) {
            level.method_14199(
                    class_2398.field_11240,
                    player.method_23317(), player.method_23318() + 0.2, player.method_23321(),
                    2, 0.3, 0.0, 0.3, 0.02
            );
        }
        if (t % SOUND_EVERY_TICKS == 0) {
            player.method_5783(class_3417.field_15013, 0.15f, 1.5f);
        }
    }

    private JetpackHelper() {}
}
