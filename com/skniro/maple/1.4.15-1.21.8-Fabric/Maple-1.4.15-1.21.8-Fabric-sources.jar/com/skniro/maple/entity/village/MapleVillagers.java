package com.skniro.maple.entity.village;

import com.skniro.maple.Maple;
import com.skniro.maple.world.biome.MapleBiomeKeys;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3854;
import net.minecraft.class_7923;

public class MapleVillagers {

    public static final class_3854 Cherry = registerProfession("cherry");

    private static class_3854 registerProfession(String name) {
        return class_2378.method_10230(class_7923.field_41194, class_2960.method_60655(Maple.MOD_ID, name),
                new class_3854());
    }
    public static void registerVillagerType() {
        Maple.LOGGER.info("Registering Villagers " + Maple.MOD_ID);
    }
}