package com.skniro.industrial_elixir.block.entity.machine;

import com.skniro.industrial_elixir.api.block.ImplementedInventory;
import com.skniro.industrial_elixir.api.block.MachineEnergyProvider;
import com.skniro.industrial_elixir.api.block.MachineRecipeProvider;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.entity.BasePowerBlockBlockEntity;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.EnergyStorageUtil;
import com.skniro.industrial_elixir.energy.api.base.SimpleSidedEnergyContainer;
import com.skniro.industrial_elixir.item.init.ItemUpgradeModule;
import com.skniro.industrial_elixir.recipe.machine.AbstractMachineCraftingRecipe;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1262;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3913;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public abstract class AbstractMachineEntity extends BasePowerBlockBlockEntity implements MachineRecipeProvider  {
    public int progress = 0;
    public int maxProgress = 72;
    protected int DEFAULT_MAX_PROGRESS = 72;
    protected final class_3913 propertyDelegate;

    public AbstractMachineEntity(class_2591 entityType, class_2338 pos, class_2680 state) {
        super(entityType, pos, state);

        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> AbstractMachineEntity.this.progress;
                    case 1 -> AbstractMachineEntity.this.maxProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: AbstractMachineEntity.this.progress = value;
                    case 1: AbstractMachineEntity.this.maxProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };

        energyContainer = new SimpleSidedEnergyContainer() {
            @Override
            public long getCapacity() {
                return getMachineCapacity();
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                return getEffectiveTier().getMaxInput();
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                if (side == null) return getEffectiveTier().getMaxOutput();
                return 0;
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(pos, method_11010(), method_11010(), 3);
            }
        };
    }


    @Override
    public boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 side) {
        class_2350 localDir = this.method_10997().method_8320(field_11867).method_11654(AbstractMachineblock.FACING);

        if(side == null) {
            return false;
        }

        if(side == class_2350.field_11033) {
            return false;
        }

        if(side == class_2350.field_11036) {
            return slot == INPUT_SLOT;
        }

        return switch (localDir) {
            default -> //NORTH
                    side == class_2350.field_11043 && slot == INPUT_SLOT ||
                            side == class_2350.field_11034 && slot == INPUT_SLOT ||
                            side == class_2350.field_11039 && slot == INPUT_SLOT;
            case field_11034 ->
                    side.method_10160() == class_2350.field_11043 && slot == INPUT_SLOT ||
                            side.method_10160() == class_2350.field_11034 && slot == INPUT_SLOT ||
                            side.method_10160() == class_2350.field_11039 && slot == INPUT_SLOT;
            case field_11035 ->
                    side.method_10153() == class_2350.field_11043 && slot == INPUT_SLOT ||
                            side.method_10153()  == class_2350.field_11034 && slot == INPUT_SLOT ||
                            side.method_10153()  == class_2350.field_11039 && slot == INPUT_SLOT;
            case field_11039 ->
                    side.method_10170() == class_2350.field_11043 && slot == INPUT_SLOT ||
                            side.method_10170() == class_2350.field_11034 && slot == INPUT_SLOT ||
                            side.method_10170() == class_2350.field_11039 && slot == INPUT_SLOT;
        };
    }

    @Override
    public boolean method_5493(int slot, class_1799 stack, class_2350 side) {
        class_2350 localDir = this.method_10997().method_8320(this.field_11867).method_11654(AbstractMachineblock.FACING);

        if(side == class_2350.field_11036) {
            return false;
        }

        // Down extract
        if(side == class_2350.field_11033) {
            return slot == OUTPUT_SLOT;
        }

        // backside extract
        // right extract
        return switch (localDir) {
            default ->  side == class_2350.field_11035 && slot == OUTPUT_SLOT ||
                    side == class_2350.field_11034 && slot == OUTPUT_SLOT;

            case field_11034 -> side.method_10160() == class_2350.field_11035 && slot == OUTPUT_SLOT ||
                    side.method_10160() == class_2350.field_11034 && slot == OUTPUT_SLOT;

            case field_11035 ->  side.method_10153() == class_2350.field_11035 && slot == OUTPUT_SLOT ||
                    side.method_10153() == class_2350.field_11034 && slot == OUTPUT_SLOT;

            case field_11039 -> side.method_10170() == class_2350.field_11035 && slot == OUTPUT_SLOT ||
                    side.method_10170() == class_2350.field_11034 && slot == OUTPUT_SLOT;
        };
    }

    public class_1799 getRenderStack() {
            return this.method_5438(INPUT_SLOT);
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        class_1262.method_5426(nbt, inventory, registries);
        nbt.method_10569("abstract_machine.progress", progress);
        nbt.method_10569("abstract_machine.max_progress", maxProgress);
        nbt.method_10544("abstract_machine.energy", energyContainer.amount);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        class_1262.method_5429(nbt, inventory, registries);
        progress = (nbt.method_10545("abstract_machine.progress") ? nbt.method_10550("abstract_machine.progress") : 0);
        maxProgress = (nbt.method_10545("abstract_machine.max_progress") ? nbt.method_10550("abstract_machine.max_progress") : DEFAULT_MAX_PROGRESS);
        energyContainer.amount = (nbt.method_10545("abstract_machine.energy") ? nbt.method_10537("abstract_machine.energy") : 300);
        super.method_11014(nbt, registries);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if(world.method_8608()) {
            return;
        }
        charge(ENERGY_ITEM_SLOT);

        if (hasRecipe() && canInsertIntoOutputSlot()) {
            increaseCraftingProgress();
            useEnergyForCrafting();
            method_31663(world, pos, state);

            if (hasCraftingFinished()) {
                craftItem();
                resetProgress();
            }
        } else {
            resetProgress();
        }

        boolean isWorking = hasRecipe() && hasEnoughEnergyToCraft();
        if (state.method_11654(AbstractMachineblock.LIT) != isWorking) {
            world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, isWorking), 3);
        }
    }

    public void useEnergyForCrafting() {
        long baseUse = getCraftEnergyCost() / 20;
        long effectiveUse = (long)(baseUse * getEnergyDemandMultiplier());
        try (Transaction tx = Transaction.openOuter()) {
            energyContainer.getSideStorage(null).extract(effectiveUse, tx);
            tx.commit();
        }
    }


    public void resetProgress() {
        this.progress = 0;
        this.maxProgress = DEFAULT_MAX_PROGRESS;
    }

    protected void craftItem() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> recipe = getCurrentRecipe();
        class_1799 output = recipe.get().comp_1933().output().method_7972();
        this.method_5434(INPUT_SLOT, recipe.get().comp_1933().requiredCount());
        if (this.method_5438(OUTPUT_SLOT).method_7960()) {
            this.method_5447(OUTPUT_SLOT, output.method_7972());
        } else {
            this.method_5438(OUTPUT_SLOT).method_7933(output.method_7947());
        }
    }

    @Override
    public int[] method_5494(class_2350 direction) {
        if (direction != class_2350.field_11033) {
            return new int[]{INPUT_SLOT};
        } else {
            return new int[]{OUTPUT_SLOT};
        }
    }
    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return slot != OUTPUT_SLOT;
    }

    public boolean hasCraftingFinished() {
        return this.progress >= this.maxProgress;
    }

    // 处理速度受 Overclocker 升级影响
    public void increaseCraftingProgress() {
        double speedMult = getProcessTimeMultiplier();
        this.progress += (int) speedMult;
    }

    protected boolean canInsertIntoOutputSlot() {
        return this.method_5438(OUTPUT_SLOT).method_7960() ||
                this.method_5438(OUTPUT_SLOT).method_7947() < this.method_5438(OUTPUT_SLOT).method_7914();
    }

    public boolean hasRecipe() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> recipe = getCurrentRecipe();
        if(recipe.isEmpty()) {
            return false;
        }

        class_1799 output = recipe.get().comp_1933().output().method_7972();
        return canInsertAmountIntoOutputSlot(output.method_7947()) && canInsertItemIntoOutputSlot(output) && hasEnoughEnergyToCraft();
    }

    protected boolean hasEnoughEnergyToCraft() {
        long baseUse = getCraftEnergyCost() / 20;
        long effectiveUse = (long)(baseUse * getEnergyDemandMultiplier());
        return this.energyContainer.amount >= effectiveUse;
    }

    protected Optional<class_8786<AbstractMachineCraftingRecipe>> getCurrentRecipe() {
        return this.method_10997().method_8503().method_3772()
                .method_8132((class_3956<AbstractMachineCraftingRecipe>) getCurrentRecipeType(), new AlchemyCraftingRecipeInput(inventory.get(INPUT_SLOT)), this.method_10997());
    }

    protected boolean canInsertItemIntoOutputSlot(class_1799 output) {
        return this.method_5438(OUTPUT_SLOT).method_7960() || class_1799.method_31577(this.method_5438(OUTPUT_SLOT), output);
    }

    protected boolean canInsertAmountIntoOutputSlot(int count) {
        int maxCount = this.method_5438(OUTPUT_SLOT).method_7960() ? 64 : this.method_5438(OUTPUT_SLOT).method_7914();
        int currentCount = this.method_5438(OUTPUT_SLOT).method_7947();

        return maxCount >= currentCount + count;
    }

    @Override
    public long getMachineCapacity() {
        long extra = getEnergyStorageUpgrade();
        return energyTier == EnergyTier.INFINITE ? Long.MAX_VALUE : 512 + extra;
    }

    @Override
    public long getCraftEnergyCost(){
        return ENERGY_CRAFTING_AMOUNT;
    }
}
