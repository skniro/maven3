package com.skniro.industrial_elixir.item.init.equipment;

import com.google.common.collect.Maps;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.registry.tag.ModItemTags;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public interface MapleArmorMaterials
{
    class_6880<class_1741> QUANTUM = register("quantum", new class_1741(
            createDefenseMap(4, 7, 10, 4, 15), 25, class_3417.field_21866, () -> class_1856.field_9017,
            List.of(MapleEquipmentAssetKeys.QUANTUM), 5.0F, 0.1F
    ));

    class_6880<class_1741> BRONZE = register("bronze", new class_1741(
            createDefenseMap(2, 5, 6, 2, 5), 9, class_3417.field_14862,
            () -> class_1856.method_8106(ModItemTags.REPAIRS_BRONZE_ARMOR), List.of(MapleEquipmentAssetKeys.BRONZE), 0.0F, 0.0F));

    class_6880<class_1741> ELECTRIC_JETPACK = register("electric_jetpack", new class_1741(
            createDefenseMap(0, 0, 4, 0, 0), 25, class_3417.field_14862, () -> class_1856.field_9017,
            List.of(MapleEquipmentAssetKeys.ELECTRIC_JETPACK), 0.0F, 0.0F
    ));

    private static class_6880<class_1741> register(String name, class_1741 material) {
        class_5321<class_1741> key = class_5321.method_29179(class_7924.field_48977,
                class_2960.method_60655(IndustrialElixir.MOD_ID, name));
        return class_2378.method_47984(class_7923.field_48976, key, material);
    }

    private static Map<class_1738.class_8051, Integer> createDefenseMap(int bootsDefense, int leggingsDefense, int chestplateDefense, int helmetDefense, int bodyDefense) {
        return Maps.newEnumMap(Map.of(class_1738.class_8051.field_41937, bootsDefense, class_1738.class_8051.field_41936, leggingsDefense, class_1738.class_8051.field_41935, chestplateDefense, class_1738.class_8051.field_41934, helmetDefense, class_1738.class_8051.field_48838, bodyDefense));
    }
}
