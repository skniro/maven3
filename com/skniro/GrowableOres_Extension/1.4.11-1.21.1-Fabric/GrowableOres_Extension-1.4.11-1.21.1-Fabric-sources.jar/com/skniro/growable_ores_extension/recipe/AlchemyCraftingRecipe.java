package com.skniro.growable_ores_extension.recipe;


import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.recipe.*;



    public record AlchemyCraftingRecipe(class_1856 inputItem, class_1799 output) implements class_1860<AlchemyCraftingRecipeInput> {
        @Override
        public class_2371<class_1856> method_8117() {
            class_2371<class_1856> list = class_2371.method_10211();
            list.add(this.inputItem);
            return list;
        }
        @Override
        public boolean matches(AlchemyCraftingRecipeInput input, class_1937 world) {
            if(world.method_8608()) {
                return false;
            }
            return inputItem.method_8093(input.method_59984(1));
        }
        @Override
        public class_1799 craft(AlchemyCraftingRecipeInput input, class_7225.class_7874 lookup) {
            return output.method_7972();
        }
        @Override
        public boolean method_8113(int width, int height) {
            return true;
        }
        @Override
        public class_1799 method_8110(class_7225.class_7874 registriesLookup) {
            return output;
        }
        @Override
        public class_1865<?> method_8119() {
            return AlchemyRecipeType.Cane_Converter_SERIALIZER;
        }
        @Override
        public class_3956<?> method_17716() {
            return AlchemyRecipeType.Cane_Converter_TYPE;
        }
        public static class Serializer implements class_1865<AlchemyCraftingRecipe> {
            public static final MapCodec<AlchemyCraftingRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
                    class_1856.field_46096.fieldOf("ingredient").forGetter(AlchemyCraftingRecipe::inputItem),
                    class_1799.field_24671.fieldOf("result").forGetter(AlchemyCraftingRecipe::output)
            ).apply(inst, AlchemyCraftingRecipe::new));
            public static final class_9139<class_9129, AlchemyCraftingRecipe> STREAM_CODEC =
                    class_9139.method_56435(
                            class_1856.field_48355, AlchemyCraftingRecipe::inputItem,
                            class_1799.field_48349, AlchemyCraftingRecipe::output,
                            AlchemyCraftingRecipe::new);
            @Override
            public MapCodec<AlchemyCraftingRecipe> method_53736() {
                return CODEC;
            }
            @Override
            public class_9139<class_9129, AlchemyCraftingRecipe> method_56104() {
                return STREAM_CODEC;
            }
        }
    }




