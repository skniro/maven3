package com.skniro.growable_ores_extension.screen;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import net.fabricmc.fabric.api.menu.v1.ExtendedMenuType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;

public class AlchemyScreenHandlerType <T extends AbstractContainerMenu>{
    public static final MenuType<AlchemyBlockScreenHandler> ALCHEMY =
            Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "cane_converter_screen_handler"),
                    new ExtendedMenuType<>(AlchemyBlockScreenHandler::new, BlockPos.STREAM_CODEC));

    public static void registeralchemyscreenhandlertype () {

    }
}
