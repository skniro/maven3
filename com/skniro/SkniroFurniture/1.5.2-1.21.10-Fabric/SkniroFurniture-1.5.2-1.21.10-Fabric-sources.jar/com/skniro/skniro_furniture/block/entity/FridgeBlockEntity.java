package com.skniro.skniro_furniture.block.entity;

import com.skniro.skniro_furniture.block.init.FridgeBlock;
import com.skniro.skniro_furniture.init.FurnitureStrings;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2756;

public class FridgeBlockEntity extends AbstractFurnitureContainerBlockEntity {

    public FridgeBlockEntity(class_2338 pos, class_2680 state) {
        super(FurnitureBlockEntityType.Fridge_BLOCK_ENTITY, pos, state,54);
    }

    @Override
    protected class_2561 method_17823() {

        if(method_11010().method_11654(FridgeBlock.HALF) == class_2756.field_12609) {
            return class_2561.method_43471(FurnitureStrings.Fridge_UPPER);
        }
        return class_2561.method_43471(FurnitureStrings.Fridge_LOWER);
    }
    @Override
    protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return class_1707.method_19247(syncId, playerInventory, this);
    }
}
