package com.skniro.growable_ores_extension.block.entity;

import com.mojang.datafixers.types.Type;
import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.entity.cable.CableBlockEntity;
import com.skniro.growable_ores_extension.block.entity.energybox.ChargePadBlockEntity;
import com.skniro.growable_ores_extension.block.entity.energybox.EnergyBoxBlockEntity;
import com.skniro.growable_ores_extension.block.entity.generator.CoalGeneratorBlockEntity;
import com.skniro.growable_ores_extension.block.entity.generator.GeneratorSolarPanelBlockEntity;
import com.skniro.growable_ores_extension.block.entity.generator.GeneratorWindMillBlockEntity;
import com.skniro.growable_ores_extension.block.entity.machine.*;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_1208;
import net.minecraft.class_156;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;


public class AlchemyBlockEntityType {
    public static final class_2591<Alchemyblockentity> ALCHEMY_BLOCK_ENTITY;
    public static final class_2591<CableBlockEntity> CABLE;
    public static final class_2591<CoalGeneratorBlockEntity> COAL_GENERATOR_BE;
    public static final class_2591<MaceratorEntity> Macerator_BLOCK_ENTITY;
    public static final class_2591<CompressorEntity> Compressor_BLOCK_ENTITY;
    public static final class_2591<GeneratorWindMillBlockEntity> GENERATOR_WIND_MILL_BLOCK_ENTITY;
    public static final class_2591<GeneratorSolarPanelBlockEntity> GENERATOR_SOLAR_PANEL_BLOCK_ENTITY;
    public static final class_2591<MetalFormerBlockEntity> MetalFormer_BLOCK_ENTITY;
    public static final class_2591<ChargePadBlockEntity> ChargePad_BLOCK_ENTITY;
    public static final class_2591<EnergyBoxBlockEntity> EnergyBox_BLOCK_ENTITY;
    public static final class_2591<MolecularTransformerBlockEntity> MolecularTransformer_BLOCK_ENTITY;
    public static final class_2591<ExtractorEntity> Extractor_BLOCK_ENTITY;
    public static final class_2591<IronFurnaceBlockEntity> Iron_Furnace_BLOCK_ENTITY;

    static {
        ALCHEMY_BLOCK_ENTITY = create("alchemy_block", FabricBlockEntityTypeBuilder.create(Alchemyblockentity::new, GrowableOresBlocks.GrowableOres_Block));
        CABLE = create("cable", FabricBlockEntityTypeBuilder.create(CableBlockEntity::new,
                        GrowableOresBlocks.COPPER_CABLE,
                        GrowableOresBlocks.TIN_CABLE,
                        GrowableOresBlocks.GOLD_CABLE,
                        GrowableOresBlocks.HV_CABLE,
                        GrowableOresBlocks.GLASSFIBER_CABLE,
                        GrowableOresBlocks.INSULATED_TIN_CABLE,
                        GrowableOresBlocks.INSULATED_COPPER_CABLE,
                        GrowableOresBlocks.INSULATED_GOLD_CABLE,
                        GrowableOresBlocks.INSULATED_HV_CABLE
                )
        );
        COAL_GENERATOR_BE = create("coal_generator_be", FabricBlockEntityTypeBuilder.create(CoalGeneratorBlockEntity::new , GrowableOresBlocks.COAL_GENERATOR));
        Macerator_BLOCK_ENTITY = create("macerator_block", FabricBlockEntityTypeBuilder.create(MaceratorEntity::new, GrowableOresBlocks.Macerator_Block));
        Compressor_BLOCK_ENTITY = create("compressor_block", FabricBlockEntityTypeBuilder.create(CompressorEntity::new, GrowableOresBlocks.Compressor_Block));
        GENERATOR_WIND_MILL_BLOCK_ENTITY = create("generator_wind_mill_be", FabricBlockEntityTypeBuilder.create(GeneratorWindMillBlockEntity::new, GrowableOresBlocks.GENERATOR_Wind_Mill));

        GENERATOR_SOLAR_PANEL_BLOCK_ENTITY = create("generator_solar_panel_be", FabricBlockEntityTypeBuilder.create(GeneratorSolarPanelBlockEntity::new,
                GrowableOresBlocks.GENERATOR_SolarPanel,
                GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL,
                GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL,
                GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL,
                GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL
        ));

        MetalFormer_BLOCK_ENTITY = create("generator_metal_former_be", FabricBlockEntityTypeBuilder.create(MetalFormerBlockEntity::new, GrowableOresBlocks.MetalFormerBlock));
        ChargePad_BLOCK_ENTITY = create("charge_pad_be", FabricBlockEntityTypeBuilder.create(ChargePadBlockEntity::new,
                GrowableOresBlocks.ChargePad,
                GrowableOresBlocks.CESU_CHARGE_PAD,
                GrowableOresBlocks.MFE_CHARGE_PAD,
                GrowableOresBlocks.MFSU_CHARGE_PAD));

        EnergyBox_BLOCK_ENTITY = create("energy_box_former_be", FabricBlockEntityTypeBuilder.create(EnergyBoxBlockEntity::new,
                GrowableOresBlocks.EnergyBox,
                GrowableOresBlocks.CESU,
                GrowableOresBlocks.MFE,
                GrowableOresBlocks.MFSU));

        MolecularTransformer_BLOCK_ENTITY = create("molecular_transformer_former_be", FabricBlockEntityTypeBuilder.create(MolecularTransformerBlockEntity::new, GrowableOresBlocks.MolecularTransformerBlock));
        Extractor_BLOCK_ENTITY = create("extractor_be", FabricBlockEntityTypeBuilder.create(ExtractorEntity::new, GrowableOresBlocks.Extractor_Block));
        Iron_Furnace_BLOCK_ENTITY = create("iron_furnace_be", FabricBlockEntityTypeBuilder.create(IronFurnaceBlockEntity::new, GrowableOresBlocks.Iron_Furnace_Block));
    }



    private static <T extends class_2586> class_2591 create(String id, FabricBlockEntityTypeBuilder<T> builder) {
        Type<?> type = class_156.method_29187(class_1208.field_5727, id);
        return (class_2591) class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(GrowableOresExtension.MOD_ID,id), builder.build(null));
    }

    public static void registerMachineEnergyEntity() {
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), ALCHEMY_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), COAL_GENERATOR_BE);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), Macerator_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), Compressor_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), GENERATOR_WIND_MILL_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), GENERATOR_SOLAR_PANEL_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), MetalFormer_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), EnergyBox_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), ChargePad_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), MolecularTransformer_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), Extractor_BLOCK_ENTITY);
    }

    public static void registerMapleBlockEntityType() {
        GrowableOresExtension.LOGGER.debug("Registering MapleBlockEntityType for " + GrowableOresExtension.MOD_ID);
    }

}
