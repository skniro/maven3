package com.skniro.blackhold.datagen;

import com.skniro.blackhold.Furniture;
import com.skniro.blackhold.block.*;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.class_7225;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;

public class MapleSimplifiedChineseLanguageProvider extends FabricLanguageProvider {
    public MapleSimplifiedChineseLanguageProvider(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> registryLookup){
        super(dataGenerator, "zh_cn", registryLookup);
    }

    @Override
    public void generateTranslations(class_7225.class_7874 wrapperLookup, TranslationBuilder translationBuilder) {

        translationBuilder.add(Furniture.Maple_Group_Furniture,"Blackhold_HD");

        translationBuilder.add(FurnitureDrawBlocks.Oak_Allay_Draw, "橡木框黑洞HD限定版画像");
        translationBuilder.add(FurnitureDrawBlocks.Spruce_Allay_Draw, "云杉木框黑洞HD限定版画像");
        translationBuilder.add(FurnitureDrawBlocks.Birch_Allay_Draw, "白桦木框黑洞HD限定版画像");
        translationBuilder.add(FurnitureDrawBlocks.Jungle_Allay_Draw, "丛林木框黑洞HD限定版画像");
        translationBuilder.add(FurnitureDrawBlocks.Acacia_Allay_Draw, "金合欢木框黑洞HD限定版画像");
        translationBuilder.add(FurnitureDrawBlocks.DarkOak_Allay_Draw, "深色橡木框黑洞HD限定版画像");
        translationBuilder.add(FurnitureDrawBlocks.Mangrove_Allay_Draw, "红树木框黑洞HD限定版画像");
        translationBuilder.add(FurnitureDrawBlocks.Bamboo_Allay_Draw, "竹木框黑洞HD限定版画像");
        translationBuilder.add(FurnitureDrawBlocks.Cherry_Allay_Draw, "樱花木框黑洞HD限定版画像");
        translationBuilder.add(FurnitureDrawBlocks.Crimson_Allay_Draw, "绯红木框黑洞HD限定版画像");
        translationBuilder.add(FurnitureDrawBlocks.Warped_Allay_Draw, "诡异木框黑洞HD限定版画像");
        translationBuilder.add(FurnitureDrawBlocks.PaleOak_Allay_Draw, "淡色橡木框黑洞HD限定版画像");
    }
}
