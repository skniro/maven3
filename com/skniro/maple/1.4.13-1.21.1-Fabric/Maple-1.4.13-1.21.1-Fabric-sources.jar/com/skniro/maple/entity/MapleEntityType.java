package com.skniro.maple.entity;

import com.mojang.datafixers.types.Type;
import com.skniro.maple.Maple;
import com.skniro.maple.entity.furniture.ChairEntity;
import com.skniro.maple.entity.furniture.CushionEntity;
import net.minecraft.class_1208;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_156;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class MapleEntityType {
    public static final class_1299<ChairEntity> CHAIR_ENTITY =
            register("chair_entity",  class_1299.class_1300.method_5903(ChairEntity::new, class_1311.field_17715)
                    .method_17687(0.5f, 0.5f));

    public static final class_1299<CushionEntity> Cushion_ENTITY =
            register("cushion_entity",  class_1299.class_1300.method_5903(CushionEntity::new, class_1311.field_17715)
                    .method_17687(0.5f, 0.5f));

    private static <T extends class_1297> class_1299<T> register(String name, class_1299.class_1300<T> builder) {
        Type<?> type = class_156.method_29187(class_1208.field_5729, name);
        return (class_1299) class_2378.method_10230(class_7923.field_41177, class_2960.method_60655(Maple.MOD_ID, name), builder.method_5905(name));
    }

    public static void registerMapleEntityType() {
        Maple.LOGGER.debug("Registering MapleEntityType for " + Maple.MOD_ID);
    }
}
