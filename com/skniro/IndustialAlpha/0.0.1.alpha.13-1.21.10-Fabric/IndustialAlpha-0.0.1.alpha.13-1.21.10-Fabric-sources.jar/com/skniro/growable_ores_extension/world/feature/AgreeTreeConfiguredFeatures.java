package com.skniro.growable_ores_extension.world.feature;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.world.gen.trunk.RubberTrunkPlacer;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_4643;
import net.minecraft.class_4646;
import net.minecraft.class_4651;
import net.minecraft.class_5204;
import net.minecraft.class_5321;
import net.minecraft.class_6012;
import net.minecraft.class_6016;
import net.minecraft.class_7891;
import net.minecraft.class_7924;

public class AgreeTreeConfiguredFeatures {
    public static final class_5321<class_2975<?, ?>> Rubber_TREE = registerKey("rubber_tree");

    static class_6012.class_6006<class_2680> pool() {
        return class_6012.method_66215();
    }

    public static void bootstrap(class_7891<class_2975<?, ?>> featureRegisterable) {
        register(featureRegisterable, Rubber_TREE, class_3031.field_24134,
                new class_4643.class_4644(
                        class_4651.method_38432(GeneralBlocks.Rubber_LOG),
                        new RubberTrunkPlacer(4, 2, 0, GeneralBlocks.Rubber_Rubber_LOG.method_9564(), 1.3F),
                        class_4651.method_38432(GeneralBlocks.Rubber_LEAVES),
                        new class_4646(class_6016.method_34998(2), class_6016.method_34998(0), 3),
                        new class_5204(1, 0, 1)).method_23445());
    }




    public static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, class_2960.method_60655(GrowableOresExtension.MOD_ID, name));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_2975<?, ?>> context,
                                                                                   class_5321<class_2975<?, ?>> key, F feature, FC configuration) {
        context.method_46838(key, new class_2975<>(feature, configuration));
    }
}
