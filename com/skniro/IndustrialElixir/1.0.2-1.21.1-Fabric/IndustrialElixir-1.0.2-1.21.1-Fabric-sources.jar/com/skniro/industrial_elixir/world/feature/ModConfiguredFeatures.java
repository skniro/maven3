package com.skniro.industrial_elixir.world.feature;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.block.init.CoffeeBlock;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3124;
import net.minecraft.class_3175;
import net.minecraft.class_3481;
import net.minecraft.class_3798;
import net.minecraft.class_3819;
import net.minecraft.class_3825;
import net.minecraft.class_4651;
import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_7924;

public class ModConfiguredFeatures {
    public static final class_5321<class_2975<?, ?>> Deepslate_Lead_Ore_KEY = registerKey("deepslate_lead_ore");
    public static final class_5321<class_2975<?, ?>> Deepslate_Tin_Ore_KEY = registerKey("deepslate_tin_ore");
    public static final class_5321<class_2975<?, ?>> Deepslate_SACRED_Ore_KEY = registerKey("deepslate_sacred_ore");
    public static final class_5321<class_2975<?, ?>> Lead_Ore_KEY = registerKey("lead_ore");
    public static final class_5321<class_2975<?, ?>> Tin_Ore_KEY = registerKey("tin_ore");
    public static final class_5321<class_2975<?, ?>> SACRED_Ore_KEY = registerKey("sacred_ore");
    public static final class_5321<class_2975<?, ?>> PATCH_COFFEE = registerKey("patch_coffee");;

    public static void bootstrap(class_7891<class_2975<?, ?>> context) {
        class_3825 stoneReplaceables = new class_3819(class_2246.field_10340);
        class_3825 deepslateReplaceables = new class_3798(class_3481.field_28993);
        class_3825 endStoneReplaceables = new class_3819(class_2246.field_10471);

        List<class_3124.class_5876> deepslateleadOres =
                List.of(class_3124.method_33994(deepslateReplaceables, GeneralBlocks.Deepslate_Lead_Ore.method_9564()));
        List<class_3124.class_5876> deepslateTinOres =
                List.of(class_3124.method_33994(deepslateReplaceables, GeneralBlocks.Deepslate_Tin_Ore.method_9564()));
        List<class_3124.class_5876> deepslateSACREDOres =
                List.of(class_3124.method_33994(deepslateReplaceables, GeneralBlocks.Deepslate_SACRED_Ore.method_9564()));
        List<class_3124.class_5876> leadOres =
                List.of(class_3124.method_33994(stoneReplaceables, GeneralBlocks.Lead_Ore.method_9564()));
        List<class_3124.class_5876> TinOres =
                List.of(class_3124.method_33994(stoneReplaceables, GeneralBlocks.Tin_Ore.method_9564()));
        List<class_3124.class_5876> SACREDOres =
                List.of(class_3124.method_33994(stoneReplaceables, GeneralBlocks.SACRED_Ore.method_9564()));


        register(context, Deepslate_Lead_Ore_KEY, class_3031.field_13517, new class_3124(deepslateleadOres, 6));
        register(context, Deepslate_Tin_Ore_KEY, class_3031.field_13517, new class_3124(deepslateTinOres, 6));
        register(context, Deepslate_SACRED_Ore_KEY, class_3031.field_13517, new class_3124(deepslateSACREDOres, 4));
        register(context, Lead_Ore_KEY, class_3031.field_13517, new class_3124(leadOres, 6));
        register(context, Tin_Ore_KEY, class_3031.field_13517, new class_3124(TinOres, 6));
        register(context, SACRED_Ore_KEY, class_3031.field_13517, new class_3124(SACREDOres, 4));

        register(context, PATCH_COFFEE, class_3031.field_13518, new class_3175(class_4651.method_38433(GeneralBlocks.Coffee_Block.method_9564().method_11657(CoffeeBlock.AGE, 3))));
    }

    public static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, class_2960.method_60655(IndustrialElixir.MOD_ID, name));
    }
    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_2975<?, ?>> context,
                                                                                   class_5321<class_2975<?, ?>> key, F feature, FC configuration) {
        context.method_46838(key, new class_2975<>(feature, configuration));
    }
}

