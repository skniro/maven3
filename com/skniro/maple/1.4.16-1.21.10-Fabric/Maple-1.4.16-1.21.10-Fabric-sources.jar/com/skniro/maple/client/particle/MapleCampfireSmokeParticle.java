package com.skniro.maple.client.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_2400;
import net.minecraft.class_3940;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;

public class MapleCampfireSmokeParticle extends class_3940 {
    MapleCampfireSmokeParticle(class_638 world, double x, double y, double z, double velocityX, double velocityY, double velocityZ, boolean signal, class_1058 sprite) {
        super(world, x, y, z, sprite);
        this.method_3087(1.0F);
        this.method_3080(0.25F, 0.25F);
        if (signal) {
            this.field_3847 = this.field_3840.method_43048(50) + 280;
        } else {
            this.field_3847 = this.field_3840.method_43048(50) + 80;
        }

        this.field_3844 = 3.0E-6F;
        this.field_3852 = velocityX;
        this.field_3869 = velocityY + (double)(this.field_3840.method_43057() / 500.0F);
        this.field_3850 = velocityZ;
    }

    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        if (this.field_3866++ < this.field_3847 && !(this.field_62636 <= 0.0F)) {
            this.field_3852 += (double)(this.field_3840.method_43057() / 5000.0F * (float)(this.field_3840.method_43056() ? 1 : -1));
            this.field_3850 += (double)(this.field_3840.method_43057() / 5000.0F * (float)(this.field_3840.method_43056() ? 1 : -1));
            this.field_3869 -= (double)this.field_3844;
            this.method_3069(this.field_3852, this.field_3869, this.field_3850);
            if (this.field_3866 >= this.field_3847 - 60 && this.field_62636 > 0.01F) {
                this.field_62636 -= 0.015F;
            }

        } else {
            this.method_3085();
        }
    }

    public class_3940.class_11941 method_74255() {
        return class_11941.field_62641;
    }

    @Environment(EnvType.CLIENT)
    public static class SignalSmokeFactory implements class_707<class_2400> {
        private final class_4002 spriteProvider;

        public SignalSmokeFactory(class_4002 spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        public class_703 createParticle(class_2400 defaultParticleType, class_638 clientWorld, double d, double e, double f, double g, double h, double i, class_5819 random) {
            MapleCampfireSmokeParticle campfireSmokeParticle = new MapleCampfireSmokeParticle(clientWorld, d, e, f, g, h, i, true, this.spriteProvider.method_18139(random));
            campfireSmokeParticle.method_74308(0.95F);
            return campfireSmokeParticle;
        }
    }

    @Environment(EnvType.CLIENT)
    public static class CosySmokeFactory implements class_707<class_2400> {
        private final class_4002 spriteProvider;

        public CosySmokeFactory(class_4002 spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        public class_703 createParticle(class_2400 defaultParticleType, class_638 clientWorld, double d, double e, double f, double g, double h, double i, class_5819 random) {
            MapleCampfireSmokeParticle campfireSmokeParticle = new MapleCampfireSmokeParticle(clientWorld, d, e, f, g, h, i, false, this.spriteProvider.method_18139(random));
            campfireSmokeParticle.method_74308(0.7F);
            return campfireSmokeParticle;
        }
    }
}