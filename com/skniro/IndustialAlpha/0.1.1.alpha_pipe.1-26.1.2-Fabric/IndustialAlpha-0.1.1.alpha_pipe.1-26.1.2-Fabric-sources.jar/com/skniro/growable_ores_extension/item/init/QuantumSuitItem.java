package com.skniro.growable_ores_extension.item.init;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.api.item.TieredEnergyItem;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.base.SimpleEnergyItem;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Unit;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import org.jetbrains.annotations.Nullable;

import javax.management.Attribute;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

public class QuantumSuitItem extends Item implements SimpleEnergyItem, TieredEnergyItem {

    public static final long CAPACITY = 10_000_000;
    private ArmorType slotType;
    private EnergyTier energyTier;

    private final ImmutableMultimap<Holder<net.minecraft.world.entity.ai.attributes.Attribute>, AttributeModifier> noPowerAttributes;
    private final ImmutableMultimap<Holder<net.minecraft.world.entity.ai.attributes.Attribute>, AttributeModifier> hasPowerAttributes;
    private final ImmutableMultimap<Holder<net.minecraft.world.entity.ai.attributes.Attribute>, AttributeModifier> fullSuitAttributes;

    public QuantumSuitItem(Properties settings, ArmorMaterial material, ArmorType slotType, EnergyTier energyTier) {
        super(settings.stacksTo(1).humanoidArmor(material, slotType).component(DataComponents.UNBREAKABLE, Unit.INSTANCE).component(DataComponents.TOOLTIP_DISPLAY, UNBREAKABLE_HIDE));
        this.energyTier = energyTier;
        this.slotType = slotType;
        switch (slotType) {
            case HELMET, BOOTS -> {
                noPowerAttributes = createAttrs(0, 0, 0, 0);
                hasPowerAttributes = createAttrs(3, 3, 0.05, 0);
                fullSuitAttributes = createAttrs(5, 5, 0.1, 0);
            }
            case CHESTPLATE -> {
                noPowerAttributes = createAttrs(0, 0, 0, 0);
                hasPowerAttributes = createAttrs(6, 3, 0.1, 0);
                fullSuitAttributes = createAttrs(10, 5, 0.15, 0);
            }
            case LEGGINGS -> {
                noPowerAttributes = createAttrs(0, 0, 0, 0);
                hasPowerAttributes = createAttrs(8, 3, 0.05, 0.15);
                fullSuitAttributes = createAttrs(10, 5, 0.1, 0.15);
            }
            default -> throw new IllegalArgumentException("Invalid slot type");
        }

        EnergyStorage.ITEM.registerForItems((stack, context) -> SimpleEnergyItem.createStorage(context, this.getEnergyCapacity(stack), this.getEnergyMaxInput(stack), this.getEnergyMaxOutput(stack)), this);
    }

    private static ImmutableMultimap<Holder<net.minecraft.world.entity.ai.attributes.Attribute>, AttributeModifier> createAttrs(
            double armor, double toughness, double knockback, double speed
    ) {
        ImmutableMultimap.Builder<Holder<net.minecraft.world.entity.ai.attributes.Attribute>, AttributeModifier> builder = ImmutableMultimap.builder();

        if (armor > 0) {
            builder.put(Attributes.ARMOR,
                    new AttributeModifier(Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "armor"), armor, AttributeModifier.Operation.ADD_VALUE));
        }
        if (toughness > 0) {
            builder.put(Attributes.ARMOR_TOUGHNESS,
                    new AttributeModifier(Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "toughness"), toughness, AttributeModifier.Operation.ADD_VALUE));
        }
        if (knockback > 0) {
            builder.put(Attributes.KNOCKBACK_RESISTANCE,
                    new AttributeModifier(Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, "knockback"), knockback, AttributeModifier.Operation.ADD_VALUE));
        }
        if (speed > 0) {
            builder.put(Attributes.MOVEMENT_SPEED,
                    new AttributeModifier(Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID,"speed"), speed, AttributeModifier.Operation.ADD_VALUE));
        }

        return builder.build();
    }

    @Override
    public long getEnergyCapacity(ItemStack stack) {
        return CAPACITY;
    }

    @Override
    public long getEnergyMaxInput(ItemStack stack) {
        return energyTier.getMaxInput();
    }

    @Override
    public long getEnergyMaxOutput(ItemStack stack) {
        return 0;
    }

    @Override
    public int getBarWidth(ItemStack stack) {
        return getPowerForDurabilityBar(stack);
    }

    public boolean isBarVisible(ItemStack stack) {
        return true;
    }

    public static int getPowerForDurabilityBar(ItemStack stack) {
        Item var2 = stack.getItem();
        if (var2 instanceof QuantumSuitItem energyItem) {
            return Math.round((float)energyItem.getStoredEnergy(stack) * 100.0F / (float)energyItem.getEnergyCapacity(stack) * 13.0F) / 100;
        } else {
            throw new UnsupportedOperationException();
        }
    }

    public static int getColorForDurabilityBar(ItemStack stack) {
        return 16744454;
    }

    @Override
    public int getBarColor(ItemStack stack) {
        return 0x00FFFF;
    }

    public void inventoryTick(ItemStack stack, ServerLevel world, Entity entity, @Nullable EquipmentSlot slot) {
        if(entity instanceof Player player) {
            if (stack.getItem() instanceof SimpleEnergyItem storage) {
                boolean powered = storage != null && storage.getStoredEnergy(stack) > 0;

                if (slot == EquipmentSlot.HEAD) {
                    if (player.isUnderWater() && powered) {
                        player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 5, 1));
                    }
                    if (powered) {
                        player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 220, 1, false, false));
                    } else {
                        player.removeEffect(MobEffects.NIGHT_VISION);
                    }
                }

                if (slot == EquipmentSlot.CHEST) {
                    player.getAbilities().mayfly = powered;
                    if (player.isOnFire() && powered) player.removeAllEffects();
                }

                if (slot == EquipmentSlot.LEGS && powered && player.isSprinting() && storage != null) {
                    //storage.extract(10);
                }

                if (slot == EquipmentSlot.LEGS && powered && player.isSwimming()) {
                    player.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 5, 1, true, false));
                }

            }
        }
    }

    public void onUnequip(Player player) {
        ArmorType slot = slotType;

        if (slot == ArmorType.CHESTPLATE) player.getAbilities().mayfly = false;
        if (slot == ArmorType.HELMET) player.removeEffect(MobEffects.NIGHT_VISION);
    }

    @Override
    public EnergyTier getEnergyTier() {
        return energyTier;
    }

    public static TooltipDisplay UNBREAKABLE_HIDE = new TooltipDisplay(
            false, new LinkedHashSet<>(Set.of(DataComponents.UNBREAKABLE))
    );
}