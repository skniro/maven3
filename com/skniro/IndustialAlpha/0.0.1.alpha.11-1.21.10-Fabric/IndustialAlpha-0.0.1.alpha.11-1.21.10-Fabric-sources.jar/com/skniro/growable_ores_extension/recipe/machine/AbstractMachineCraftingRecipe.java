package com.skniro.growable_ores_extension.recipe.machine;


import com.skniro.growable_ores_extension.recipe.AlchemyCraftingRecipeInput;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_7225;
import net.minecraft.class_9887;
import net.minecraft.recipe.*;
import org.jetbrains.annotations.Nullable;


public abstract class AbstractMachineCraftingRecipe implements class_1860<AlchemyCraftingRecipeInput> {
    protected final class_1799 output;
    protected final class_1856 ingredient;
    protected final int requiredCount;
    @Nullable
    private class_9887 ingredientPlacement;


    public AbstractMachineCraftingRecipe(class_1856 ingredients, int requiredCount, class_1799 output) {
        this.output = output;
        this.ingredient = ingredients;
        this.requiredCount = requiredCount;
    }

    public AbstractMachineCraftingRecipe(class_1856 ingredients, class_1799 output) {
        this.output = output;
        this.ingredient = ingredients;
        this.requiredCount = 1;
    }

    public int requiredCount() {
        return requiredCount;
    }

    public class_1856 ingredient() {
        return this.ingredient;
    }

    public class_1799 output() {
        return this.output;
    }

    @Override
    public boolean matches(AlchemyCraftingRecipeInput input, class_1937 world) {
        if (world.method_8608()) {
            return false;
        }
        class_1799 stack = input.method_59984(1);
        return ingredient.method_8093(stack) && stack.method_7947() >= requiredCount;
    }

    @Override
    public class_1799 craft(AlchemyCraftingRecipeInput input, class_7225.class_7874 lookup) {
        return output.method_7972();
    }

    @Override
    public class_9887 method_61671() {
        if (this.ingredientPlacement == null) {
            this.ingredientPlacement = class_9887.method_61682(this.ingredient);
        }

        return this.ingredientPlacement;
    }


}









