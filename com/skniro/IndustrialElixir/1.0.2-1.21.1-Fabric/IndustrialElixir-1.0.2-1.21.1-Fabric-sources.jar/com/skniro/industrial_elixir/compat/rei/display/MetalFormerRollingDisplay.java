package com.skniro.industrial_elixir.compat.rei.display;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.recipe.machine.MetalFormerRollingCraftingRecipe;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2960;
import net.minecraft.class_8786;
import java.util.List;
import java.util.Optional;

public class MetalFormerRollingDisplay extends BasicDisplay {
    private int count;

    public static final CategoryIdentifier<MetalFormerRollingDisplay> MetalFormerRolling =
            CategoryIdentifier.of(IndustrialElixir.MOD_ID, "metalformer_rolling");

    public static final DisplaySerializer<MetalFormerRollingDisplay> SERIALIZER = BasicDisplay.Serializer.<MetalFormerRollingDisplay>of(
            (inputs, outputs, location, tag) -> new MetalFormerRollingDisplay(inputs, outputs, location, tag.method_10550("count")),
            (display, tag) -> tag.method_10569("count", display.getCount())
    );

    public MetalFormerRollingDisplay(MetalFormerRollingCraftingRecipe recipe) {
        this(List.of(EntryIngredients.ofIngredient(recipe.ingredient())),
                List.of(EntryIngredients.of(recipe.output())), Optional.empty(), recipe.requiredCount());
        this.count = recipe.requiredCount();
    }

    public MetalFormerRollingDisplay(List<EntryIngredient> inputs, List<EntryIngredient> outputs, Optional<class_2960> location, int count) {
        super(inputs, outputs, location);
        this.count = count;
    }

    public MetalFormerRollingDisplay(class_8786<MetalFormerRollingCraftingRecipe> recipe){
        super(List.of(EntryIngredients.ofIngredient(recipe.comp_1933().ingredient())),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.comp_1933().output()))));
        this.count = recipe.comp_1933().requiredCount();
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return MetalFormerRolling;
    }


    public int getCount() {
        return count;
    }
}