package com.skniro.maple.entity.furniture;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2945;
import net.minecraft.class_4048;
import org.joml.Vector3f;

public class CushionEntity extends class_1297 {
    public CushionEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {

    }

    @Override
    protected class_243 method_52533(class_1297 passenger, class_4048 dimensions, float scaleFactor)
    {
        return new class_243(0F, dimensions.comp_2186() * 0.50F * scaleFactor, 0F);
    }


    @Override
    protected void method_5749(class_2487 nbt) {

    }

    @Override
    protected void method_5652(class_2487 nbt) {

    }

    @Override
    protected void method_5793(class_1297 passenger) {
        super.method_5793(passenger);
        this.method_5768();
    }
}