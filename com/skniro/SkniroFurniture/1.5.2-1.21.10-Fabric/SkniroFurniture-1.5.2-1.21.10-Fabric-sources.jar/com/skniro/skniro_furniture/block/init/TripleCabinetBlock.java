package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_2237;

public class TripleCabinetBlock extends AbstractWallCabinetBlock {
    public static final MapCodec<TripleCabinetBlock> CODEC = method_54094(TripleCabinetBlock::new);

    public TripleCabinetBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

}
