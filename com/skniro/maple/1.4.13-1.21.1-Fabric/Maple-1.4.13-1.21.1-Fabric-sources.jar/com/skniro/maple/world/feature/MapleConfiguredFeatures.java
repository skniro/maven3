package com.skniro.maple.world.feature;

import com.skniro.maple.Maple;
import com.skniro.maple.block.MapleBlocks;
import com.skniro.maple.block.MapleNetherOresBlocks;
import com.skniro.maple.block.MapleOreBlocks;
import com.skniro.maple.block.init.MapleTeaBlock;
import com.skniro.maple.fluid.MapleFluidBlockOrItem;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3085;
import net.minecraft.class_3124;
import net.minecraft.class_3175;
import net.minecraft.class_3481;
import net.minecraft.class_3798;
import net.minecraft.class_3819;
import net.minecraft.class_3825;
import net.minecraft.class_4638;
import net.minecraft.class_4643;
import net.minecraft.class_4646;
import net.minecraft.class_4651;
import net.minecraft.class_5140;
import net.minecraft.class_5204;
import net.minecraft.class_5207;
import net.minecraft.class_5212;
import net.minecraft.class_5321;
import net.minecraft.class_6005;
import net.minecraft.class_6016;
import net.minecraft.class_6017;
import net.minecraft.class_6019;
import net.minecraft.class_6642;
import net.minecraft.class_6803;
import net.minecraft.class_6817;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.class_8178;
import net.minecraft.class_8180;
import net.minecraft.world.gen.feature.*;
import java.util.List;
import java.util.OptionalInt;


public class MapleConfiguredFeatures {
    public static final class_5321<class_2975<?, ?>> Maple_TREE =registerKey("maple_tree");
    public static final class_5321<class_2975<?, ?>> Red_Maple_TREE =registerKey("red_maple_tree");
    public static final class_5321<class_2975<?, ?>> CHERRY_TREE = registerKey("cherry_tree");
    public static final class_5321<class_2975<?, ?>> SAKURA_TREE = registerKey("sakura_tree");
    public static final class_5321<class_2975<?, ?>> MAGE_SAKURA_TREE = registerKey("mage_sakura_tree");
    public static final class_5321<class_2975<?, ?>> GINKGO_TREE = registerKey("ginkgo_tree");
    public static final class_5321<class_2975<?, ?>> SALT_ORE = registerKey("salt_ore");
    public static final class_5321<class_2975<?, ?>> LAKE_HOT_SPRING = registerKey("lake_hot_spring");
    public static final class_5321<class_2975<?, ?>> Nether_Coal_ORE_KEY = registerKey("coal_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Copper_KEY = registerKey("copper_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Diamond_KEY = registerKey("diamond_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Emerald_KEY = registerKey("emerald_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Gold_KEY = registerKey("gold_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Iron_KEY = registerKey("iron_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Lapis_KEY = registerKey("lapis_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Redstone_ORE_KEY = registerKey("redstone_ore");
    public static final class_5321<class_2975<?, ?>> Sakura_Carpet_KEY = registerKey("sakura_carpet");
    public static final class_5321<class_2975<?, ?>> Maple_Carpet_KEY = registerKey("maple_carpet");
    public static final class_5321<class_2975<?, ?>> Red_Maple_Carpet_KEY = registerKey("red_maple_carpet");
    public static final class_5321<class_2975<?, ?>> PATCH_TEA = registerKey("patch_tea");

    private static class_4643.class_4644 builder(class_2248 log, class_2248 leaves, int baseHeight, int firstRandomHeight, int secondRandomHeight, int radius) {
        return new class_4643.class_4644(class_4651.method_38432(log), new class_5140(baseHeight, firstRandomHeight, secondRandomHeight), class_4651.method_38432(leaves), new class_4646(class_6016.method_34998(radius), class_6016.method_34998(0), 3), new class_5204(1, 0, 1));
    }

    private static class_4643.class_4644 maple() {
        return MapleConfiguredFeatures.builder(MapleBlocks.MAPLE_LOG, MapleBlocks.MAPLE_LEAVES, 4, 2, 0, 2).method_27374();
    }

    private static class_4643.class_4644 redmaple() {
        return MapleConfiguredFeatures.builder(MapleBlocks.MAPLE_LOG, MapleBlocks.RED_MAPLE_LEAVES, 4, 3, 0, 2).method_27374();
    }

    private static class_4643.class_4644 cherry() {
        return new class_4643.class_4644(class_4651.method_38432(class_2246.field_42729), new class_8180(7, 1, 0, new class_6642(class_6005.<class_6017>method_34971().method_34975(class_6016.method_34998(1), 1).method_34975(class_6016.method_34998(2), 1).method_34975(class_6016.method_34998(3), 1).method_34974()), class_6019.method_35017(2, 4), class_6019.method_35017(-4, -3), class_6019.method_35017(-1, 0)), class_4651.method_38432(class_2246.field_42731), new class_8178(class_6016.method_34998(4), class_6016.method_34998(0), class_6016.method_34998(5), 0.25f, 0.5f, 0.16666667f, 0.33333334f), new class_5204(1, 0, 2)).method_27374();
    }

    private static class_4643.class_4644 sakura() {
        return MapleConfiguredFeatures.builder(class_2246.field_42729, MapleBlocks.SAKURA_LEAVES,4,2,0,2).method_27374();
    }

    private static class_4643.class_4644 sakura2() {
        return (new class_4643.class_4644(class_4651.method_38432(class_2246.field_42729), new class_5212(8, 20, 0), class_4651.method_38432(MapleBlocks.SAKURA_LEAVES), new class_5207(class_6016.method_34998(2),class_6016.method_34998(3), 3), new class_5204(0, 0, 0, OptionalInt.of(1)))).method_27374();
    }

    private static class_4643.class_4644 ginkgo() {
        return MapleConfiguredFeatures.builder(MapleBlocks.GINKGO_LOG, MapleBlocks.GINKGO_LEAVES,5,2,0,2).method_27374();
    }
    public static void bootstrap(class_7891<class_2975<?, ?>> featureRegisterable) {
        class_3825 stoneReplaceables = new class_3798(class_3481.field_28992);
        class_3825 deepslateReplaceables = new class_3798(class_3481.field_28993);
        class_3825 netherstoneReplaceables = new class_3819(class_2246.field_10515);

        List<class_3124.class_5876> overworldSaltOres =
                List.of(class_3124.method_33994(stoneReplaceables, MapleOreBlocks.Salt_Ore.method_9564()),
                        class_3124.method_33994(deepslateReplaceables, MapleOreBlocks.DEEPSLATE_Salt_Ore.method_9564()));
        List<class_3124.class_5876> netherCoalOres =
                List.of(class_3124.method_33994(netherstoneReplaceables, MapleNetherOresBlocks.Nether_Coal_Ore.method_9564()));
        List<class_3124.class_5876> netherCopperOres =
                List.of(class_3124.method_33994(netherstoneReplaceables, MapleNetherOresBlocks.Nether_Copper_Ore.method_9564()));
        List<class_3124.class_5876> netherDiamondOres =
                List.of(class_3124.method_33994(netherstoneReplaceables, MapleNetherOresBlocks.Nether_Diamond_Ore.method_9564()));
        List<class_3124.class_5876> netherEmeraldOres =
                List.of(class_3124.method_33994(netherstoneReplaceables, MapleNetherOresBlocks.Nether_Emerald_Ore.method_9564()));
        List<class_3124.class_5876> netherGoldOres =
                List.of(class_3124.method_33994(netherstoneReplaceables, MapleNetherOresBlocks.Nether_Gold_Ore.method_9564()));
        List<class_3124.class_5876> netherIronOres =
                List.of(class_3124.method_33994(netherstoneReplaceables, MapleNetherOresBlocks.Nether_Iron_Ore.method_9564()));
        List<class_3124.class_5876> netherLapisOres =
                List.of(class_3124.method_33994(netherstoneReplaceables, MapleNetherOresBlocks.Nether_Lapis_Ore.method_9564()));
        List<class_3124.class_5876> netherRedstoneOres =
                List.of(class_3124.method_33994(netherstoneReplaceables, MapleNetherOresBlocks.Nether_Redstone_Ore.method_9564()));

        //Lake
        register(featureRegisterable, LAKE_HOT_SPRING , class_3031.field_13573, new class_3085.class_6788(class_4651.method_38433(MapleFluidBlockOrItem.Hot_Spring_BLOCK.method_9564()), class_4651.method_38433(class_2246.field_10219.method_9564())));

        //Tree
        register(featureRegisterable, Red_Maple_TREE, class_3031.field_24134,
                MapleConfiguredFeatures.redmaple().method_23445());
        register(featureRegisterable, Maple_TREE, class_3031.field_24134,
                MapleConfiguredFeatures.maple().method_23445());
        register(featureRegisterable, CHERRY_TREE, class_3031.field_24134,
                MapleConfiguredFeatures.cherry().method_23445());
        register(featureRegisterable, SAKURA_TREE, class_3031.field_24134,
                MapleConfiguredFeatures.sakura().method_23445());
        register(featureRegisterable, MAGE_SAKURA_TREE, class_3031.field_24134,
                MapleConfiguredFeatures.sakura2().method_23445());
        register(featureRegisterable, GINKGO_TREE, class_3031.field_24134,
                MapleConfiguredFeatures.ginkgo().method_23445());

        //Ores
        register(featureRegisterable, SALT_ORE , class_3031.field_13517, new class_3124(overworldSaltOres, 12));


        register(featureRegisterable, Nether_Coal_ORE_KEY, class_3031.field_13517, new class_3124(netherCoalOres, 10));
        register(featureRegisterable, Nether_Copper_KEY, class_3031.field_13517, new class_3124(netherCopperOres, 8));
        register(featureRegisterable, Nether_Diamond_KEY, class_3031.field_13517, new class_3124(netherDiamondOres, 8));
        register(featureRegisterable, Nether_Emerald_KEY, class_3031.field_13517, new class_3124(netherEmeraldOres, 3));
        register(featureRegisterable, Nether_Gold_KEY, class_3031.field_13517, new class_3124(netherGoldOres, 8));
        register(featureRegisterable, Nether_Iron_KEY, class_3031.field_13517, new class_3124(netherIronOres, 8));
        register(featureRegisterable, Nether_Lapis_KEY, class_3031.field_13517, new class_3124(netherLapisOres, 8));
        register(featureRegisterable, Nether_Redstone_ORE_KEY, class_3031.field_13517, new class_3124(netherRedstoneOres, 8));

        //Leave carpet
        register(featureRegisterable, Red_Maple_Carpet_KEY, class_3031.field_21219, new class_4638(30, 6, 2, class_6817.method_40366(class_3031.field_13518, new class_3175(class_4651.method_38433(MapleBlocks.RED_MAPLE_CARPET.method_9564())))));
        register(featureRegisterable, Maple_Carpet_KEY, class_3031.field_21219, new class_4638(30, 6, 2, class_6817.method_40366(class_3031.field_13518, new class_3175(class_4651.method_38433(MapleBlocks.Maple_CARPET.method_9564())))));
        register(featureRegisterable, Sakura_Carpet_KEY, class_3031.field_21219, new class_4638(30, 6, 2, class_6817.method_40366(class_3031.field_13518, new class_3175(class_4651.method_38433(MapleBlocks.SAKURA_CARPET.method_9564())))));

        class_6803.method_39708(featureRegisterable, PATCH_TEA, class_3031.field_21220, class_6803.method_39705(class_3031.field_13518, new class_3175(class_4651.method_38433(MapleBlocks.Tea_Block.method_9564().method_11657(MapleTeaBlock.AGE, 3))), List.of(class_2246.field_10219)));
    }

    public static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, class_2960.method_60655(Maple.MOD_ID, name));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_2975<?, ?>> context,
                                                                                   class_5321<class_2975<?, ?>> key, F feature, FC configuration) {
        context.method_46838(key, new class_2975<>(feature, configuration));
    }

    public static void registerConfiguredFeatures() {
        Maple.LOGGER.debug("Registering the ModConfiguredFeatures for " + Maple.MOD_ID);
    }

}
