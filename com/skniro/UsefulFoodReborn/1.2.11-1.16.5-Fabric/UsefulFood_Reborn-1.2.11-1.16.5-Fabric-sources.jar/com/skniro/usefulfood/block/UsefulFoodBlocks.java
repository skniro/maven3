package com.skniro.usefulfood.block;

import com.skniro.usefulfood.UsefulFood;
import com.skniro.usefulfood.block.init.MagicCakeBlockState;
import com.skniro.usefulfood.block.init.SpecialCakeBlockState;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import java.util.logging.Logger;

public class UsefulFoodBlocks {
    public static final class_2248 AppleCake = registerBlock("applecake",new SpecialCakeBlockState(FabricBlockSettings.method_9630(class_2246.field_10183),18,0.6F), UsefulFood.UsefulFood_Group);
    public static final class_2248 ChocolateCake = registerBlock("chocolatecake",new SpecialCakeBlockState(FabricBlockSettings.method_9630(class_2246.field_10183),12,0.5F), UsefulFood.UsefulFood_Group);
    public static final class_2248 MagicCake = registerBlock("magiccake", new MagicCakeBlockState(FabricBlockSettings.method_9630(class_2246.field_10183), 48, 0.5F), UsefulFood.UsefulFood_Group);

    // 1.4
    public static final class_2248 CaramelCake = registerBlock("caramelcake",new SpecialCakeBlockState(FabricBlockSettings.method_9630(class_2246.field_10183),19,0.1F), UsefulFood.UsefulFood_Group);


    private static class_2248 registerBlock(String name, class_2248 block, class_1761 tab) {
        registerBlockItem(name, block, tab);
        return class_2378.method_10230(class_2378.field_11146, new class_2960(UsefulFood.MOD_ID, name), block);
    }

    private static class_2248 registerBlockWithoutItem(String name, class_2248 block) {
        return class_2378.method_10230(class_2378.field_11146, new class_2960(UsefulFood.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_1761 tab) {
        return class_2378.method_10230(class_2378.field_11142, new class_2960(UsefulFood.MOD_ID, name),
                new class_1747(block, new FabricItemSettings().method_7892(tab).method_7889(1)));
    }
    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + UsefulFood.MOD_ID);
    }
}

