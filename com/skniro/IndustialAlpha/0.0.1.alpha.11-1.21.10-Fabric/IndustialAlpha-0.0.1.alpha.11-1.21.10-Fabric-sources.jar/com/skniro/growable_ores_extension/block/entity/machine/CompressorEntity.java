package com.skniro.growable_ores_extension.block.entity.machine;

import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import com.skniro.growable_ores_extension.screen.machine.CompressorScreenHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3956;
import org.jetbrains.annotations.Nullable;

public class CompressorEntity extends AbstractMachineEntity {

    public CompressorEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.Compressor_BLOCK_ENTITY ,pos, state);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Compressor);
    }

    public class_3956<?> getCurrentRecipeType() {
        return AlchemyRecipeType.COMPRESSOR.type;
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new CompressorScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }
}
