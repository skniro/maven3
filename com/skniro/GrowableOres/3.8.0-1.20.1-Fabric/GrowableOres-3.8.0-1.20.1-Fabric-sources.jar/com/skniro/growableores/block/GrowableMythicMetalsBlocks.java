package com.skniro.growableores.block;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.init.GrowableOreCaneBlock;
import java.util.logging.Logger;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;

public class GrowableMythicMetalsBlocks {
    //Mythic Metals
    public static final class_2248 MM_Adamantite_Ingot_Cane = registerBlock("mm_adamantite_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Aquarium_Ingot_Cane = registerBlock("mm_aquarium_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Banglum_Ingot_Cane = registerBlock("mm_banglum_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Carmot_Ingot_Cane = registerBlock("mm_carmot_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Kyber_Ingot_Cane = registerBlock("mm_kyber_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Manganese_Ingot_Cane = registerBlock("mm_manganese_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Midas_Gold_Ingot_Cane = registerBlock("mm_midas_gold_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Morkite_Cane = registerBlock("mm_morkite_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Mythril_Ingot_Cane = registerBlock("mm_mythril_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Orichalcum_Ingot_Cane = registerBlock("mm_orichalcum_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Osmium_Ingot_Cane = registerBlock("mm_osmium_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Palladium_Ingot_Cane = registerBlock("mm_palladium_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Platinum_Ingot_Cane = registerBlock("mm_platinum_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Prometheum_Ingot_Cane = registerBlock("mm_prometheum_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Quadrillum_Ingot_Cane = registerBlock("mm_quadrillum_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Runite_Ingot_Cane = registerBlock("mm_runite_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Silver_Ingot_Cane = registerBlock("mm_silver_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Starrite_Cane = registerBlock("mm_starrite_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Stormyx_Ingot_Cane = registerBlock("mm_stormyx_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Tin_Ingot_Cane = registerBlock("mm_tin_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));
    public static final class_2248 MM_Unobtainium_Cane = registerBlock("mm_unobtainium_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971)));

    private static class_2248 registerBlock(String name, class_2248 block) {
        registerBlockItem(name, block);
        return net.minecraft.class_2378.method_10230(net.minecraft.class_7923.field_41175, net.minecraft.class_2960.method_43902(GrowableOres.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return net.minecraft.class_2378.method_10230(net.minecraft.class_7923.field_41178, net.minecraft.class_2960.method_43902(GrowableOres.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
    }
    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + GrowableOres.MOD_ID);
    }
}

