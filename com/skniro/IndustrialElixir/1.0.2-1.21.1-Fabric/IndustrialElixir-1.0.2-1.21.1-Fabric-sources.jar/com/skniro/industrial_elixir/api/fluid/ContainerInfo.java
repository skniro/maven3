package com.skniro.industrial_elixir.api.fluid;

import net.minecraft.class_1792;

public record ContainerInfo(class_1792 emptyItem, class_1792 fullItem) {}