package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import com.skniro.skniro_furniture.block.entity.PlateBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.util.*;
import org.jetbrains.annotations.Nullable;

public class PlateBlock extends class_2237 {
    private static final class_265 SHAPE =
            class_2248.method_9541(4, 0, 4, 12, 1, 12);
    public static final class_2754<class_2350> FACING;

    public PlateBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043));
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (state.method_26204() != newState.method_26204()) {
            class_2586 blockEntity = world.method_8321(pos);
            if (blockEntity instanceof PlateBlockEntity) {
                class_1264.method_5451(world, pos, ((PlateBlockEntity) blockEntity));
                world.method_8455(pos, this);
            }
            super.method_9536(state, world, pos, newState, moved);
        }
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_1799 stack = player.method_5998(hand);
        if(world.method_8321(pos) instanceof PlateBlockEntity BlockEntity) {
            if(BlockEntity.method_5442() && !stack.method_7960()) {
                BlockEntity.method_5447(0, stack.method_46651(1));
                world.method_8396(player, pos, class_3417.field_15197, class_3419.field_15245, 1f, 2f);
                stack.method_7934(1);

                BlockEntity.method_5431();
                world.method_8413(pos, state, state, 0);
            } else if(stack.method_7960() && !player.method_5715()) {
                class_1799 stackOnPedestal = BlockEntity.method_5438(0);
                player.method_6122(class_1268.field_5808, stackOnPedestal);
                world.method_8396(player, pos, class_3417.field_15197, class_3419.field_15245, 1f, 1f);
                BlockEntity.method_5448();
                BlockEntity.method_5431();
                world.method_8413(pos, state, state, 0);
            }
        }

        return class_1269.field_5812;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new PlateBlockEntity(pos, state);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    static {
        FACING = class_2741.field_12481;
    }
}
