package com.skniro.usefulfood.block.init;

import com.mojang.serialization.MapCodec;
import com.skniro.usefulfood.block.UsefulFoodJamBlocks;
import com.skniro.usefulfood.item.UsefulFoodItems;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import net.minecraft.util.*;
import org.jetbrains.annotations.Nullable;

public class GlassJarBlock extends class_2383 {
    private static final class_265 SHAPE = class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 9.5, 11.0);
    public static final class_2754<class_2350> FACING = class_2741.field_12481;
    public static final MapCodec<GlassJarBlock> CODEC = method_54094(GlassJarBlock::new);

    public GlassJarBlock(class_2251 settings) {
        super(settings);
    }


    @Override
    protected MapCodec<GlassJarBlock> method_53969() {
        return field_46280;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return (class_2680)state.method_11657(FACING, rotation.method_10503((class_2350)state.method_11654(FACING)));
    }

    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345((class_2350)state.method_11654(FACING)));
    }


    @Override
    public class_9062 method_55765(class_1799 itemStack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (world.field_9236) return class_9062.field_47728;

        class_1799 heldItem = player.method_5998(hand);

        if (heldItem.method_31574(UsefulFoodItems.MelonJam)) {
            replaceWith(world, pos, UsefulFoodJamBlocks.Melon_JAM_JAR.method_9564().method_11657(JamJarBlock.JAM_STAGE, 1));
            if (!player.method_7337()) heldItem.method_7934(1);
            world.method_8396(null, pos, class_3417.field_14779, class_3419.field_15245, 1.0F, 1.0F);
            return class_9062.field_47728;
        }

        if (heldItem.method_31574(UsefulFoodItems.AppleJam)) {
            replaceWith(world, pos, UsefulFoodJamBlocks.Apple_JAM_JAR.method_9564().method_11657(JamJarBlock.JAM_STAGE, 1));
            if (!player.method_7337()) heldItem.method_7934(1);
            world.method_8396(null, pos, class_3417.field_14779, class_3419.field_15245, 1.0F, 1.0F);
            return class_9062.field_47728;
        }

        if (heldItem.method_31574(UsefulFoodItems.Glow_Berries_Jam)) {
            replaceWith(world, pos, UsefulFoodJamBlocks.Glow_Berries_JAM_JAR.method_9564().method_11657(JamJarBlock.JAM_STAGE, 1));
            if (!player.method_7337()) heldItem.method_7934(1);
            world.method_8396(null, pos, class_3417.field_14779, class_3419.field_15245, 1.0F, 1.0F);
            return class_9062.field_47728;
        }

        if (heldItem.method_31574(UsefulFoodItems.Sweet_Berries_Jam)) {
            replaceWith(world, pos, UsefulFoodJamBlocks.Sweet_Berries_JAM_JAR.method_9564().method_11657(JamJarBlock.JAM_STAGE, 1));
            if (!player.method_7337()) heldItem.method_7934(1);
            world.method_8396(null, pos, class_3417.field_14779, class_3419.field_15245, 1.0F, 1.0F);
            return class_9062.field_47728;
        }

        if (heldItem.method_31574(UsefulFoodItems.Chorus_Jam)) {
            replaceWith(world, pos, UsefulFoodJamBlocks.Chorus_JAM_JAR.method_9564().method_11657(JamJarBlock.JAM_STAGE, 1));
            if (!player.method_7337()) heldItem.method_7934(1);
            world.method_8396(null, pos, class_3417.field_14779, class_3419.field_15245, 1.0F, 1.0F);
            return class_9062.field_47728;
        }


        return class_9062.field_47732;
    }

    private void replaceWith(class_1937 world, class_2338 pos, class_2680 newState) {
        world.method_8652(pos, newState, 3);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}
