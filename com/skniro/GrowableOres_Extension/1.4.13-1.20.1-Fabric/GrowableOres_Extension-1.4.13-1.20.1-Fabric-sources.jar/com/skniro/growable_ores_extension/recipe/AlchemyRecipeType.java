package com.skniro.growable_ores_extension.recipe;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

public interface AlchemyRecipeType<T extends class_1860<?>> {
    public static final class_1865<AlchemyCraftingRecipe> Cane_Converter_SERIALIZER = class_2378.method_10230(
            class_7923.field_41189, class_2960.method_43902(GrowableOresExtension.MOD_ID, "cane_converter"), new AlchemyCraftingRecipe.Serializer());
    public static final class_3956<AlchemyCraftingRecipe> Cane_Converter_TYPE = class_2378.method_10230(
            class_7923.field_41188, class_2960.method_43902(GrowableOresExtension.MOD_ID, "cane_converter"), new class_3956<>() {
                @Override
                public String toString() {
                    return "cane_converter";
                }
            });
    public static void registerRecipes() {
        GrowableOresExtension.LOGGER.info("Registering Custom Recipes for " + GrowableOresExtension.MOD_ID);
    }
}

