package com.skniro.growable_ores_extension.world;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_2893;

public class ModOreGeneration {
    public static void generateOres() {
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Lead_Ore_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Tin_Ore_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Uranium_Ore_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Deepslate_Lead_Ore_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Deepslate_Tin_Ore_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Deepslate_Uranium_Ore_PLACED_KEY);
    }
}