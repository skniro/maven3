package com.skniro.industrial_elixir.item.init;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.util.FluidStack;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.EmptyItemFluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.FullItemFluidStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_3611;
import net.minecraft.class_3612;

public class FluidCellItem extends class_1792 {
    public static final long CAPACITY_MB = 1000;
    private static final Map<class_3611, class_1792> FILLED_CELLS = new HashMap<>();
    private final class_3611 fluid;

    public FluidCellItem(class_1793 properties, class_3611 fluid) {
        super(properties);
        this.fluid = fluid;
        registerStorage();
    }

    private void registerStorage() {
        if (fluid == class_3612.field_15906) {
            FluidStorage.combinedItemApiProvider(this).register(this::createFillStorage);
        } else {
            FluidStorage.combinedItemApiProvider(this).register(this::createDrainStorage);
        }
    }

    public static void registerFluidCell(class_3611 fluid, class_1792 item) {
        FILLED_CELLS.put(fluid, item);
    }


    private EmptyItemFluidStorage createFillStorage(ContainerItemContext context) {
        class_1792 filled = getFilledCell(fluid);

        if (filled == GrowableOresItems.EMPTY_CELL) {
            return null;
        }

        return new EmptyItemFluidStorage(context, empty -> ItemVariant.of(filled), fluid, CAPACITY_MB);
    }

    private FullItemFluidStorage createDrainStorage(ContainerItemContext context) {
        return new FullItemFluidStorage(context, full -> ItemVariant.of(GrowableOresItems.EMPTY_CELL), FluidVariant.of(fluid), CAPACITY_MB);
    }

    public static class_1792 getFilledCell(class_3611 fluid) {
        return FILLED_CELLS.getOrDefault(fluid, GrowableOresItems.EMPTY_CELL);
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        if (fluid == class_3612.field_15906) {
            return super.method_7864(stack);
        }
        return class_2561.method_43470(FluidVariantAttributes.getName(FluidVariant.of(fluid)).getString()).method_10852(class_2561.method_43471(FurnitureStrings.Fluid_Cell));
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> textConsumer, class_1836 flag) {
        if (fluid == class_3612.field_15906) {
            textConsumer.add(class_2561.method_43470("Capacity: 1000 mB").method_27692(class_124.field_1080));
        }

        if (fluid != class_3612.field_15906) {
            textConsumer.add(FluidVariantAttributes.getName(FluidVariant.of(fluid)).method_27661().method_27692(class_124.field_1080));
            textConsumer.add(class_2561.method_43470("Stored: 1000 / 1000 mB").method_27692(class_124.field_1080));
        }
    }
}