package com.skniro.industrial_elixir.block.entity.machine;

import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.block.init.machine.HeatCentrifugeBlock;
import com.skniro.industrial_elixir.energy.api.base.SimpleSidedEnergyContainer;
import com.skniro.industrial_elixir.item.init.ItemUpgradeModule;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.machine.AbstractMachineCraftingRecipe;
import com.skniro.industrial_elixir.recipe.machine.HeatCentrifugeCraftingRecipe;
import com.skniro.industrial_elixir.screen.handler.machine.HeatCentrifugeScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3913;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_8786;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class HeatCentrifugeEntity extends AbstractMachineEntity {
    private static final int MIN_VOLTAGE = 48; // minimum working voltage (EU/t)
    private static final int PROCESS_ENERGY_PER_TICK = 49; // EU/t consumed while processing
    private static final int HEAT_KEEP_COST = 1; // EU/t to keep heat when redstone powered
    private static final int MAX_HEAT = 6000;
    private static final int HEAT_UP_INTERVAL = 1; // heat increases every tick while active
    private static final int COOL_DOWN_INTERVAL = 40;
    private static final int PROCESS_SECONDS = 25;
    private static final int PROCESS_TICKS = PROCESS_SECONDS * 20;

    private int heat = 0;
    private int heatTick = 0;

    private final class_3913 centrifugeData = new class_3913() {
        @Override
        public int method_17390(int index) {
            return switch (index) {
                case 0 -> HeatCentrifugeEntity.this.progress;
                case 1 -> HeatCentrifugeEntity.this.maxProgress;
                case 2 -> HeatCentrifugeEntity.this.heat;
                default -> 0;
            };
        }

        @Override
        public void method_17391(int index, int value) {
            switch (index) {
                case 0 -> HeatCentrifugeEntity.this.progress = value;
                case 1 -> HeatCentrifugeEntity.this.maxProgress = value;
                case 2 -> HeatCentrifugeEntity.this.heat = value;
            }
        }

        @Override
        public int method_17389() {
            return 3;
        }
    };

    public HeatCentrifugeEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.HEAT_CENTRIFUGE_BE, pos, state);
        // set machine defaults
        this.maxProgress = PROCESS_TICKS;
        this.energyContainer = new SimpleSidedEnergyContainer() {
            @Override
            public long getCapacity() {
                return 10000 + getEnergyStorageUpgrade();
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                return getEffectiveTier().getMaxInput();
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                return getEffectiveTier().getMaxOutput();
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(field_11867, method_11010(), method_11010(), 3);
            }
        };
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Heat_Centrifuge);
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return AlchemyRecipeType.HEAT_CENTRIFUGE.type;
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) {
            return;
        }

        // charge from battery slot
        charge(ENERGY_ITEM_SLOT);

        boolean hasRecipe = hasRecipe();
        boolean shouldKeepHeat = shouldKeepHeat(world, pos);

        // heat management
        if ((hasRecipe || shouldKeepHeat) && heat < MAX_HEAT) {
            heatTick++;
            if (heatTick >= HEAT_UP_INTERVAL) {
                heat++;
                heatTick = 0;
            }
        } else if (!hasRecipe && !shouldKeepHeat && heat > 0) {
            heatTick++;
            if (heatTick >= COOL_DOWN_INTERVAL) {
                heat--;
                heatTick = 0;
            }
        } else {
            heatTick = 0;
        }

        if (shouldKeepHeat && energyContainer.amount >= HEAT_KEEP_COST) {
            extractEnergy(HEAT_KEEP_COST);
        }

        // ensure working voltage: require effective tier input capacity >= MIN_VOLTAGE
        boolean hasMinVoltage = getEffectiveTier().getMaxInput() >= MIN_VOLTAGE;

        if (hasRecipe && hasMinVoltage && energyContainer.amount >= PROCESS_ENERGY_PER_TICK && heat >= MAX_HEAT) {
            progress++;
            extractEnergy(PROCESS_ENERGY_PER_TICK);
            if (progress >= maxProgress) {
                craftItem();
                progress = 0;
            }
        } else {
            progress = 0;
        }

        boolean isWorking = hasRecipe && hasMinVoltage && energyContainer.amount >= PROCESS_ENERGY_PER_TICK;
        if (state.method_11654(AbstractMachineblock.LIT) != isWorking) {
            world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, isWorking), 3);
        }
        method_31663(world, pos, state);
    }

    private boolean shouldKeepHeat(class_1937 world, class_2338 pos) {
        boolean powered = world.method_49803(pos);
        if (hasRedstoneInverterUpgrade()) {
            powered = !powered;
        }
        return powered && energyContainer.amount >= HEAT_KEEP_COST;
    }

    private boolean hasRedstoneInverterUpgrade() {
        for (int slot = UPGRADE_START; slot <= UPGRADE_END; slot++) {
            net.minecraft.class_1799 stack = inventory.get(slot);
            if (stack.method_7909() instanceof ItemUpgradeModule upgrade && upgrade.modifiesRedstoneInput(stack)) {
                return true;
            }
        }
        return false;
    }

    public EnergyTier getEffectiveTier() {
        int tierBoost = 0;
        for (int slot = UPGRADE_START; slot <= UPGRADE_END; slot++) {
            net.minecraft.class_1799 stack = inventory.get(slot);
            if (stack.method_7909() instanceof com.skniro.industrial_elixir.item.init.ItemUpgradeModule upgrade) {
                tierBoost += upgrade.getTierIncrease(stack);
            }
        }
        int newTier = Math.min(energyTier.ordinal() + tierBoost, EnergyTier.values().length - 1);
        return EnergyTier.values()[newTier];
    }

    private void extractEnergy(long amount) {
        try (Transaction transaction = Transaction.openOuter()) {
            energyContainer.getSideStorage(null).extract(amount, transaction);
            transaction.commit();
        }
    }

    @Override
    protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        output.method_10569("heat_centrifuge.heat", heat);
        output.method_10569("heat_centrifuge.heat_tick", heatTick);
    }

    @Override
    protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        super.method_11014(input, registries);
        heat = (input.method_10545("heat_centrifuge.heat") ? input.method_10550("heat_centrifuge.heat") : 0);
        heatTick = (input.method_10545("heat_centrifuge.heat_tick") ? input.method_10550("heat_centrifuge.heat_tick") : 0);
        maxProgress = PROCESS_TICKS;
    }

    public int getHeat() {
        return heat;
    }

    public int getScaledHeatWidth() {
        return heat * 54 / MAX_HEAT;
    }

    public int getScaledEnergyHeight() {
        long energy = energyContainer.amount;
        long capacity = energyContainer.getCapacity();
        return capacity != 0 && energy != 0 ? (int) (energy * 16 / capacity) : 0;
    }

    @Override
    protected void craftItem() {
        HeatCentrifugeCraftingRecipe recipe = (HeatCentrifugeCraftingRecipe) getCurrentRecipe().get().comp_1933();
        this.method_5434(INPUT_SLOT, recipe.requiredCount());
        insertOutput(OUTPUT_SLOT, recipe.output().method_7972());
        recipe.output2().ifPresent(output -> insertOutput(OUTPUT_SLOT_2, output.method_7972()));
        recipe.output3().ifPresent(output -> insertOutput(OUTPUT_SLOT_3, output.method_7972()));
    }

    private void insertOutput(int slot, class_1799 output) {
        if (output.method_7960()) {
            return;
        }
        if (this.method_5438(slot).method_7960()) {
            this.method_5447(slot, output.method_7972());
        } else {
            this.method_5438(slot).method_7933(output.method_7947());
        }
    }

    @Override
    public boolean method_5493(int slot, class_1799 stack, class_2350 side) {
        if ((slot != OUTPUT_SLOT && slot != OUTPUT_SLOT_2 && slot != OUTPUT_SLOT_3) || side == class_2350.field_11036) {
            return false;
        }

        if (side == class_2350.field_11033) {
            return true;
        }

        class_2350 localDir = this.field_11863.method_8320(this.method_11016()).method_11654(HeatCentrifugeBlock.FACING);
        return side == localDir.method_10153() || side == localDir.method_10170();
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return slot != OUTPUT_SLOT && slot != OUTPUT_SLOT_2 && slot != OUTPUT_SLOT_3;
    }

    @Override
    public int[] method_5494(class_2350 direction) {
        if (direction != class_2350.field_11033) {
            return new int[]{INPUT_SLOT, FLUID_ITEM_SLOT, ENERGY_ITEM_SLOT};
        } else {
            return new int[]{OUTPUT_SLOT, OUTPUT_SLOT_2, OUTPUT_SLOT_3};
        }
    }

    @Override
    public boolean hasRecipe() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> opt = getCurrentRecipe();
        if (opt.isEmpty()) return false;

        var recipeHolder = opt.get();
        var recipe = recipeHolder.comp_1933();
        HeatCentrifugeCraftingRecipe washingRecipe = (HeatCentrifugeCraftingRecipe) recipe;

        if (!canInsertIntoSlot(OUTPUT_SLOT, washingRecipe.output().method_7972())) return false;
        if (washingRecipe.output2().isPresent() && !canInsertIntoSlot(OUTPUT_SLOT_2, washingRecipe.output2().get().method_7972())) return false;
        if (washingRecipe.output3().isPresent() && !canInsertIntoSlot(OUTPUT_SLOT_3, washingRecipe.output3().get().method_7972())) return false;
        if (!hasEnoughEnergyToCraft()) return false;
        return true;
    }

    private boolean canInsertIntoSlot(int slot, class_1799 output) {
        if (output.method_7960()) {
            return true;
        }
        class_1799 stack = this.method_5438(slot);
        int maxCount = stack.method_7960() ? output.method_7914() : stack.method_7914();
        return (stack.method_7960() || class_1799.method_31577(stack, output))
                && maxCount >= stack.method_7947() + output.method_7947();
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new  HeatCentrifugeScreenHandler(syncId, playerInventory, this, centrifugeData);
    }
}




