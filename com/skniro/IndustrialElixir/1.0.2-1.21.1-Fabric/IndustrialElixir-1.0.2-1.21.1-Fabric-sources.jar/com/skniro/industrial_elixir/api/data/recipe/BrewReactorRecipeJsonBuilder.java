package com.skniro.industrial_elixir.api.data.recipe;

import com.skniro.industrial_elixir.recipe.machine.BrewReactorCraftingRecipe;
import org.jetbrains.annotations.Nullable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_161;
import net.minecraft.class_170;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2119;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_5797;
import net.minecraft.class_6862;
import net.minecraft.class_7871;
import net.minecraft.class_7923;
import net.minecraft.class_8782;
import net.minecraft.class_8790;

public class BrewReactorRecipeJsonBuilder implements class_5797 {
    private final class_7871<class_1792> itemLookup;
    private class_1856 ingredient;
    private class_1856 ingredient2;
    private final class_1799 result;
    private int requiredCount;
    private final Map<String, class_175<?>> criteria = new LinkedHashMap<>();

    @Nullable
    private String group;

    private BrewReactorRecipeJsonBuilder(class_7871<class_1792> itemLookup, class_1799 result) {
        this.itemLookup = itemLookup;
        this.result = result;
    }

    private class_2960 fluidId = null;
    private Integer fluidAmount = null;

    public static BrewReactorRecipeJsonBuilder create(class_7871<class_1792> itemLookup, class_1935 output, int count) {
        return new BrewReactorRecipeJsonBuilder(itemLookup, new class_1799(output.method_8389(), count));
    }

    public static BrewReactorRecipeJsonBuilder create(class_7871<class_1792> itemLookup, class_1935 output) {
        return create(itemLookup, output, 1);
    }

    public static BrewReactorRecipeJsonBuilder create(class_7871<class_1792> itemLookup, class_1799 output) {
        return new BrewReactorRecipeJsonBuilder(itemLookup, output);
    }

    public BrewReactorRecipeJsonBuilder input(class_1935 item) {
        return input(item, 1);
    }

    public BrewReactorRecipeJsonBuilder input(class_1935 item, int amount) {
        this.ingredient = class_1856.method_8091(item);
        this.requiredCount = amount;
        return this;
    }

    public BrewReactorRecipeJsonBuilder input2(class_1935 item) {
        this.ingredient2 = class_1856.method_8091(item);
        return this;
    }

    public BrewReactorRecipeJsonBuilder input2(class_6862<class_1792> tag) {
        this.ingredient2 = class_1856.method_8106(tag);
        return this;
    }
    public BrewReactorRecipeJsonBuilder fluid(class_2960 fluidId, int amount) {
        this.fluidId = fluidId;
        this.fluidAmount = amount;
        return this;
    }

    /**
     * Convenience overload to accept a vanilla Fluid instance (eg. Fluids.WATER.getSource()).
     * The fluid's registry id will be used as the recipe's fluid identifier.
     */
    public BrewReactorRecipeJsonBuilder fluid(class_3611 fluid, int amount) {
        class_2960 id = class_7923.field_41173.method_10221(fluid);
        this.fluidId = id;
        this.fluidAmount = amount;
        return this;
    }
    public BrewReactorRecipeJsonBuilder input(class_6862<class_1792> tag) {
        return input(tag, 1);
    }

    public BrewReactorRecipeJsonBuilder input(class_6862<class_1792> tag, int amount) {
        this.ingredient = class_1856.method_8106(tag);
        this.requiredCount = amount;
        return this;
    }


    public BrewReactorRecipeJsonBuilder method_33530(String name,
                                                   class_175<?> criterion) {
        this.criteria.put(name, criterion);
        return this;
    }

    public BrewReactorRecipeJsonBuilder method_33529(@Nullable String group) {
        this.group = group;
        return this;
    }

    @Override
    public class_1792 method_36441() {
        return this.result.method_7909();
    }

    @Override
    public void method_17972(class_8790 exporter, class_2960 recipeId) {
        class_2960 finalRecipeId = modifyRecipeKey(recipeId, exporter);
        // 如果调用方通过 input2 指定了第二输入则使用，否则不设置第二输入（传入 null，会在序列化器/codec 中被视为可选并省略字段）
        Optional<class_1856> ing2 = this.ingredient2 != null ? Optional.of(this.ingredient2) : Optional.empty();
        Optional<class_2960> fluidOpt = this.fluidId != null ? Optional.of(this.fluidId) : Optional.empty();
        Optional<Integer> amtOpt = this.fluidAmount != null ? Optional.of(this.fluidAmount) : Optional.empty();
        BrewReactorCraftingRecipe recipe = new BrewReactorCraftingRecipe(ingredient, ing2, requiredCount, result, fluidOpt, amtOpt);
        if (criteria.isEmpty()) {
            exporter.method_53819(finalRecipeId, recipe, null);
            return;
        }

        class_161.class_162 advancementBuilder = exporter.method_53818().method_705("has_the_recipe", class_2119.method_27847(recipeId)).method_703(class_170.class_171.method_753(recipeId)).method_704(class_8782.class_8797.field_1257);

        this.criteria.forEach(advancementBuilder::method_705);

        exporter.method_53819(finalRecipeId, recipe, advancementBuilder.method_695(finalRecipeId.method_45138("recipes/")));

    }

    private class_2960 modifyRecipeKey(class_2960 recipeId, class_8790 exporter) {
        return exporter.getRecipeIdentifier(recipeId.method_45138("brew_reactor/"));
    }
}
