package com.skniro.growable_ores_extension.block.entity;

import com.skniro.growable_ores_extension.api.ImplementedInventory;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import java.util.Optional;

public abstract class BasePowerBlockBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory {
    protected final EnergyTier energyTier;

    public BasePowerBlockBlockEntity(class_2591<?> blockEntityType, class_2338 pos, class_2680 state, EnergyTier energyTier) {
        super(blockEntityType, pos, state);
        this.energyTier = energyTier;
    };

    public EnergyTier getEnergyTier(){
        return energyTier;
    }

    public Optional<ImplementedInventory> getOptionalInventory() {
        if (this instanceof ImplementedInventory inventory) {
            return inventory == null ? Optional.empty() : Optional.of(inventory);
        } else {
            return Optional.empty();
        }
    }

}
