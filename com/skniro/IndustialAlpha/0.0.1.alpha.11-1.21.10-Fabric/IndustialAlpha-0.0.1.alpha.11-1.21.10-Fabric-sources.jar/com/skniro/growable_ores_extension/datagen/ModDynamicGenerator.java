package com.skniro.growable_ores_extension.datagen;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.init.ModDamageTypes;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

public class ModDynamicGenerator extends FabricDynamicRegistryProvider {
    public ModDynamicGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }
    @Override
    protected void configure(class_7225.class_7874 registries, Entries entries) {
        // HERE GOES FUTURE WORLD GEN!
        entries.addAll(registries.method_46762(class_7924.field_41239));
        entries.addAll(registries.method_46762(class_7924.field_41245));
        entries.addAll(registries.method_46762(class_7924.field_42534));
    }

    @Override
    public String method_10321() {
        return GrowableOresExtension.MOD_ID;
    }
}