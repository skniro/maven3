package com.skniro.growableores.util;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.*;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class GrowableOresItemGroups {
    public static final class_5321<class_1761> Growable_Ores_Group = class_5321.method_29179(class_7924.field_44688, class_2960.method_43902(GrowableOres.MOD_ID, "test_group"));

    public static void vanilla_item() {
        class_2378.method_39197(class_7923.field_44687, Growable_Ores_Group, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableVanillaOresBlocks.Iron_Cane))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores.test_group"))
                .method_47324()); // build() no longer registers by itself

        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            content.method_45421(GrowableVanillaOresBlocks.Coal_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Iron_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Diamond_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Copper_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Emerald_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Gold_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Lapis_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Nether_Quartz_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Redstone_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Blaze_Rod_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Ender_Pearl_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Netherite_Ingot_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Netherite_Scrap_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Clay_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Glowstone_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Slime_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Bone_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Nether_Star_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Egg_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Wool_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Gunpowder_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Feather_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Leather_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Oak_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Spruce_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Birch_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Jungle_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Acacia_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Dark_Oak_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Mangrove_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Bamboo_Block_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Cherry_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Crimson_Stem_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Warped_Stem_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Amethyst_Shard_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Prismarine_Crystals_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Prismarine_Shard_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Sand_Cane);
            content.method_45421(GrowableVanillaOresBlocks.String_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Honeycomb_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Echo_Shard_Cane);

        });
    }
    public static void ae_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //ae2
            content.method_45421(GrowableAEOresBlocks.certus_quartz_crystal_Cane);
            content.method_45421(GrowableAEOresBlocks.fluix_crystal_Cane);
        });
    }

    public static void techreborn_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Tech Reborn
            content.method_45421(GrowableTechRebornOresBlocks.cinnabar_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.galena_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.iridium_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.lead_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.peridot_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.pyrite_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.ruby_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.sapphire_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.sheldonite_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.silver_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.sphalerite_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.tin_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.tungsten_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.sodalite_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.bauxite_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.TR_Nickel_Cane);
        });
    }

    public static void betterend_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //BetterEnd
            content.method_45421(GrowableBetterEndOresBlocks.amber_Cane);
            content.method_45421(GrowableBetterEndOresBlocks.ender_Cane);
            content.method_45421(GrowableBetterEndOresBlocks.thallasium_Cane);
        });
    }

    public static void maple_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Maple
            content.method_45421(GrowableMapleOresBlocks.Salt_Cane);
        });
    }
    public static void powah_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Powah Rearchitected and Powah
            content.method_45421(GrowablePowahOresBlocks.Steel_Energized_Cane);
            content.method_45421(GrowablePowahOresBlocks.Uraninite_Ore_Dense_Cane);
            content.method_45421(GrowablePowahOresBlocks.Ender_Core_Cane);
            content.method_45421(GrowablePowahOresBlocks.Crystal_Spirited_Cane);
            content.method_45421(GrowablePowahOresBlocks.Crystal_Nitro_Cane);
            content.method_45421(GrowablePowahOresBlocks.Crystal_Niotic_Cane);
            content.method_45421(GrowablePowahOresBlocks.Crystal_Blazing_Cane);
        });
    }

    public static void ir_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Industrial Revolution
            content.method_45421(GrowableIndustrialRevolutionOresBlocks.IR_Lead_Cane);
            content.method_45421(GrowableIndustrialRevolutionOresBlocks.IR_nikolite_Cane );
            content.method_45421(GrowableIndustrialRevolutionOresBlocks.IR_silver_Cane);
            content.method_45421(GrowableIndustrialRevolutionOresBlocks.IR_tin_ore_Cane);
            content.method_45421(GrowableIndustrialRevolutionOresBlocks.IR_tungsten_Cane);
        });
    }
    public static void mi_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
    //Modern Industrialization
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_antimony_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_bauxite_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_iridium_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_lead_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_lignite_coal_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_monazite_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_nickel_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_platinum_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_quartz_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_salt_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_tin_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_titanium_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_tungsten_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_uranium_Cane);
        });
    }
    public static void ic_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //ic2 and ic2c
            content.method_45421(GrowableICOresBlocks.IC2_Aluminium_Cane);
            content.method_45421(GrowableICOresBlocks.IC2_silver_Cane);
            content.method_45421(GrowableICOresBlocks.IC2_Tin_Cane);
            content.method_45421(GrowableICOresBlocks.IC2_Uranium_Cane);
        });
    }
    public static void ad_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Ad Astra!
            content.method_45421(GrowableAdAstraOresBlocks.AD_Ostrum_Cane);
            content.method_45421(GrowableAdAstraOresBlocks.AD_Ice_Shard_Cane);
            content.method_45421(GrowableAdAstraOresBlocks.AD_Cheese_Cane);
            content.method_45421(GrowableAdAstraOresBlocks.AD_Desh_Cane);
            content.method_45421(GrowableAdAstraOresBlocks.AD_Calorite_Cane);
        });
    }
    public static void c_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Create
            content.method_45421(GrowableCreateOresBlocks.C_Andesite_Alloy_Cane);
            content.method_45421(GrowableCreateOresBlocks.C_Brass_Ingot_Cane);
            content.method_45421(GrowableCreateOresBlocks.C_Polished_Rose_Quartz_Cane);
            content.method_45421(GrowableCreateOresBlocks.C_Zinc_Cane);
        });
    }
    public static void tf_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Thermal Series
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Apatite_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Cinnabar_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Copper_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Lead_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Nickel_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Niter_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Ruby_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Sapphire_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Silver_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Sulfur_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Tin_Cane);
        });
    }


    public static void mek_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Mekanism
            content.method_45421(GrowableMekanismOresBlocks.MEK_Fluorite_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Lead_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Osmium_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Tin_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Uranium_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Steel_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Refined_Obsidian_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Refined_Glowstone_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Bronze_Cane);
        });
    }

    public static void bn_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //BetterNether
            content.method_45421(GrowableBetterNetherOresBlocks.BN_Cincinnasite_Cane);
            content.method_45421(GrowableBetterNetherOresBlocks.BN_Nether_Ruby_Cane);
        });
    }

    public static void ep_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //EnergizedPower
            content.method_45421(GrowableEnergizedPowerOresBlocks.EP_Advanced_Alloy_Cane);
            content.method_45421(GrowableEnergizedPowerOresBlocks.EP_Energized_Copper_Cane);
            content.method_45421(GrowableEnergizedPowerOresBlocks.EP_Energized_Gold_Cane);
            content.method_45421(GrowableEnergizedPowerOresBlocks.EP_Redstone_Alloy_Cane);
            content.method_45421(GrowableEnergizedPowerOresBlocks.EP_Steel_Cane);
            content.method_45421(GrowableEnergizedPowerOresBlocks.EP_Tin_Cane);
        });
    }

    public static void bop_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Biomes O' Plenty
            content.method_45421(GrowableBiomesOPlentyOresBlocks.BOP_Rose_Quartz_Chunk_Cane);
        });
    }

    public static void de_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Draconic Evolution
            content.method_45421(GrowableDraconicEvolutionOresBlocks.DE_Awakened_Draconium_Ingot_Cane);
            content.method_45421(GrowableDraconicEvolutionOresBlocks.DE_Draconium_Ingot_Cane);
        });
    }

    public static void er_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Extreme Reactors
            content.method_45421(GrowableExtremeReactorsOresBlocks.ER_Anglesite_Crystal_Cane);
            content.method_45421(GrowableExtremeReactorsOresBlocks.ER_Benitoite_Crystal_Cane);
            content.method_45421(GrowableExtremeReactorsOresBlocks.ER_Blutonium_Ingot_Cane);
            content.method_45421(GrowableExtremeReactorsOresBlocks.ER_Cyanite_Ingot_Cane);
            content.method_45421(GrowableExtremeReactorsOresBlocks.ER_Graphite_Ingot_Cane);
            content.method_45421(GrowableExtremeReactorsOresBlocks.ER_Inanite_Ingot_Cane);
            content.method_45421(GrowableExtremeReactorsOresBlocks.ER_Insanite_Ingot_Cane);
            content.method_45421(GrowableExtremeReactorsOresBlocks.ER_Ludicrite_Ingot_Cane);
            content.method_45421(GrowableExtremeReactorsOresBlocks.ER_Magentite_Ingot_Cane);
            content.method_45421(GrowableExtremeReactorsOresBlocks.ER_Ridiculite_Ingot_Cane);
            content.method_45421(GrowableExtremeReactorsOresBlocks.ER_Yellorium_Ingot_Cane);
        });
    }

    public static void galo_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Galosphere
            content.method_45421(GrowableGalosphereOresBlocks.Galo_Allurite_Shard_Cane);
            content.method_45421(GrowableGalosphereOresBlocks.Galo_Lumiere_Shard_Cane);
            content.method_45421(GrowableGalosphereOresBlocks.Galo_Silver_Ingot_Cane);
        });
    }

    public static void gobber_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Gobber2
            content.method_45421(GrowableGobberOresBlocks.Gobber_Gobber_Ingot_Cane);
            content.method_45421(GrowableGobberOresBlocks.Gobber_End_Gobber_Ingot_Cane);
            content.method_45421(GrowableGobberOresBlocks.Gobber_Nether_Gobber_Ingot_Cane);
        });
    }

    public static void gtceu_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //GregTechCEu Modern
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Aluminium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Americium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Annealed_Copper_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Antimony_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Battery_Alloy_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Beryllium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Bismuth_Bronze_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Bismuth_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Black_Bronze_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Brass_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Bronze_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Chromium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Cobalt_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Cupronickel_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Darmstadtium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Duranium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Electrum_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Enriched_Naquadah_Trinium_Europium_Duranide_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Epoxy_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Europium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Amethyst_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Apatite_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Certus_Quartz_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Coke_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Glass_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Grossular_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Lapis_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Lazurite_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Malachite_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Monazite_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Nether_Quartz_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Olivine_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Opal_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Pyrope_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Quartzite_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Realgar_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Red_Garnet_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Rock_Salt_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Ruby_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Rutile_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Salt_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Sapphire_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Sodalite_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Spessartine_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Uvarovite_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Yellow_Garnet_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Almandine_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Andradite_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Blue_Topaz_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Cinnabar_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Coal_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Diamond_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Emerald_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Exquisite_Green_Sapphire_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Gallium_Arsenide_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Gallium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Graphene_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Indium_Gallium_Phosphide_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Indium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Indium_Tin_Barium_Titanium_Cuprate_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Iridium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Lead_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Magnalium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Magnesium_Diboride_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Magnetic_Iron_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Magnetic_Neodymium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Magnetic_Samarium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Manganese_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Manganese_Phosphide_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Mercury_Barium_Calcium_Cuprate_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Molybdenum_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Naquadah_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Naquadria_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Neodymium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Neutronium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Nichrome_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Nickel_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Nickel_Zinc_Ferrite_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Niobium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Niobium_Nitride_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Niobium_Titanium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Osmiridium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Osmium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Palladium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Platinum_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Plutonium_241_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Plutonium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Polybenzimidazole_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Polycaprolactam_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Polyethylene_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Polyphenylene_Sulfide_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Polytetrafluoroethylene_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Polyvinyl_Chloride_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Raw_Rubber_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Reinforced_Epoxy_Resin_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Rhodium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Riched_Naquadah_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Rose_Gold_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Rubber_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Ruridit_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Ruthenium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Ruthenium_Trinium_Americium_Neutronate_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Samarium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Samarium_Iron_Arsenic_Oxide_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Silicon_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Silicone_Rubber_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Silver_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Soldering_Alloy_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Stainless_Steel_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Steel_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Sterling_Silver_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Styrene_Butadiene_Rubber_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Tantalum_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Thorium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Tin_Alloy_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Tin_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Titanium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Trinium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Tritanium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Tungsten_Carbide_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Tungsten_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Ultimet_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Uranium_235_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Uranium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Uranium_Rhodium_Dinaquadide_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Uranium_Triplatinum_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Vanadium_Gallium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Vanadium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Wrought_Iron_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Yttrium_Barium_Cuprate_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Yttrium_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Zinc_Ingot_Cane);
            content.method_45421(GrowableGregTechCEuModernOresBlocks.GTM_Invar_Ingot_Cane);
        });
    }

    public static void ma_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //ManaandArtifice
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Animus_Dust_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Arcane_Ash_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Bone_Ash_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Ironbark_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Living_Flame_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Mote_Air_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Mote_Arcane_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Mote_Earth_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Mote_Ender_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Mote_Fire_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Mote_Water_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Purified_Vinteum_Dust_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Purified_Vinteum_Ingot_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Resonating_Dust_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Superheated_Purified_Vinteum_Ingot_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Superheated_Vinteum_Ingot_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Vinteum_Dust_Cane);
            content.method_45421(GrowableManaandArtificeOresBlocks.MA_Vinteum_Ingot_Cane);
        });
    }

    public static void maa_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Mystical Agradditions
            content.method_45421(GrowableMysticalAgradditionsBlocks.MAA_Awakened_Draconium_Essence_Cane);
            content.method_45421(GrowableMysticalAgradditionsBlocks.MAA_Dragon_Egg_Essence_Cane);
            content.method_45421(GrowableMysticalAgradditionsBlocks.MAA_Insanium_Essence_Cane);
            content.method_45421(GrowableMysticalAgradditionsBlocks.MAA_Insanium_Ingot_Cane);
            content.method_45421(GrowableMysticalAgradditionsBlocks.MAA_Nether_Star_Essence_Cane);
            content.method_45421(GrowableMysticalAgradditionsBlocks.MAA_Neutronium_Essence_Cane);
            content.method_45421(GrowableMysticalAgradditionsBlocks.MAA_Nitro_Crystal_Essence_Cane);
        });
    }

    public static void mac_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Mystical Agriculture
            content.method_45421(GrowableMysticalAgricultureBlocks.MAC_Imperium_Ingot_Cane);
            content.method_45421(GrowableMysticalAgricultureBlocks.MAC_Inferium_Ingot_Cane);
            content.method_45421(GrowableMysticalAgricultureBlocks.MAC_Prosperity_Ingot_Cane);
            content.method_45421(GrowableMysticalAgricultureBlocks.MAC_Prudentium_Ingot_Cane);
            content.method_45421(GrowableMysticalAgricultureBlocks.MAC_Soulium_Ingot_Cane);
            content.method_45421(GrowableMysticalAgricultureBlocks.MAC_Supremium_Ingot_Cane);
            content.method_45421(GrowableMysticalAgricultureBlocks.MAC_Tertium_Ingot_Cane);
        });
    }

    public static void rc_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Railcraft
            content.method_45421(GrowableRailcraftOresBlocks.RC_Brass_Ingot_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Bronze_Ingot_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Charcoal_Dust_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Coal_Dust_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Ender_Dust_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Invar_Ingot_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Lead_Ingot_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Nickel_Ingot_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Obsidian_Dust_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Saltpeter_Dust_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Silver_Ingot_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Steel_Ingot_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Sulfur_Dust_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Tin_Ingot_Cane);
            content.method_45421(GrowableRailcraftOresBlocks.RC_Zinc_Ingot_Cane);
        });
    }

    public static void rft_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //RFTools
            content.method_45421(GrowableRFToolsOresBlocks.RFT_Dimensional_Shard_Cane);
        });
    }

    public static void tc_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Tinkers' Construct
            content.method_45421(GrowableTinkersConstructBlocks.TC_Amethyst_Bronze_Ingot_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Blazing_Bone_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Cheese_Ingot_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Cobalt_Ingot_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Earth_Slime_Crystal_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Ender_Slime_Crystal_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Hepatizon_Ingot_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Ichor_Slime_Crystal_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Knightslime_Ingot_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Manyullyn_Ingot_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Modifier_Crystal_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Necronium_Bone_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Necrotic_Bone_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Queens_Slime_Ingot_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Rose_Gold_Ingot_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Sky_Slime_Crystal_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Slimesteel_Ingot_Cane);
            content.method_45421(GrowableTinkersConstructBlocks.TC_Soulsteel_Ingot_Cane);
        });
    }

    public static void ed_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Electro Dynamics
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Aluminum_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Bronze_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Chromium_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Hsla_Steel_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Lead_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Lithium_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Molybdenum_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Silver_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Stainless_Steel_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Steel_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Superconductive_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Tin_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Titanium_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Titanium_Carbide_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Vanadium_Cane);
            content.method_45421(GrowableElectroDynamicsOresBlocks.ED_Ingot_Vanadium_Steel_Cane);

        });
    }

    public static void clm_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Cobblemon
            content.method_45421(GrowableCobblemonOresBlocks.CLM_Dusk_Stone_Cane);
            content.method_45421(GrowableCobblemonOresBlocks.CLM_Dawn_Stone_Cane);
            content.method_45421(GrowableCobblemonOresBlocks.CLM_Fire_Stone_Cane);
            content.method_45421(GrowableCobblemonOresBlocks.CLM_Sun_Stone_Cane);
            content.method_45421(GrowableCobblemonOresBlocks.CLM_Thunder_Stone_Cane);
            content.method_45421(GrowableCobblemonOresBlocks.CLM_Shiny_Stone_Cane);
            content.method_45421(GrowableCobblemonOresBlocks.CLM_Ice_Stone_Cane);
            content.method_45421(GrowableCobblemonOresBlocks.CLM_Moon_Stone_Cane);
            content.method_45421(GrowableCobblemonOresBlocks.CLM_Leaf_Stone_Cane);
            content.method_45421(GrowableCobblemonOresBlocks.CLM_Water_Stone_Cane);

        });
    }

    public static void oc_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Occultism
            content.method_45421(GrowableOccultismOresBlocks.OC_Otherworld_log_Cane);
            content.method_45421(GrowableOccultismOresBlocks.OC_Iesnium_Ingot_Cane);
            content.method_45421(GrowableOccultismOresBlocks.OC_Silver_Ingot_Cane);

        });
    }

    public static void aet_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Aether
            content.method_45421(GrowableAetherOresBlocks.AET_Ambrosium_Shard_Cane);
            content.method_45421(GrowableAetherOresBlocks.AET_Enchanted_Gravitite_Cane);
            content.method_45421(GrowableAetherOresBlocks.AET_Zanite_Gemstone_Cane);
            content.method_45421(GrowableAetherOresBlocks.AET_Skyroot_Stick_Cane);
            content.method_45421(GrowableAetherOresBlocks.AET_Golden_Amber_Cane);
        });
    }

    public static void mm_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Mythic Metals
            content.method_45421(GrowableMythicMetalsBlocks.MM_Adamantite_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Aquarium_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Banglum_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Carmot_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Kyber_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Manganese_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Midas_Gold_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Morkite_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Mythril_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Orichalcum_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Osmium_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Palladium_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Platinum_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Prometheum_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Quadrillum_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Runite_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Silver_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Starrite_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Stormyx_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Tin_Ingot_Cane);
            content.method_45421(GrowableMythicMetalsBlocks.MM_Unobtainium_Cane);
        });
    }
}
