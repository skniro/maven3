package com.skniro.blackhold.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

import static com.skniro.blackhold.datagen.MapleBlockTagGeneration.ModBlockTags.*;
import static net.minecraft.class_3481.*;


public class MapleBlockTagGeneration extends FabricTagProvider.BlockTagProvider {
    public MapleBlockTagGeneration(FabricDataOutput dataGenerator,CompletableFuture<class_7225.class_7874> completableFuture) {
        super(dataGenerator, completableFuture);
    }


    public static class ModBlockTags {

    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {

    }
}
