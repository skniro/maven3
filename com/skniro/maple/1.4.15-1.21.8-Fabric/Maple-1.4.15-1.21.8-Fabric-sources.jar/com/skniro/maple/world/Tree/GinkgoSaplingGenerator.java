package com.skniro.maple.world.Tree;

import com.skniro.maple.world.feature.MapleConfiguredFeatures;
import java.util.Optional;
import net.minecraft.class_8813;

public class GinkgoSaplingGenerator {
    public static final class_8813 GinkgoSapling =
            new class_8813("ginkgotreesapling", 0f, Optional.empty(),
                    Optional.empty(),
                    Optional.of(MapleConfiguredFeatures.GINKGO_TREE),
                    Optional.empty(),
                    Optional.empty(),
                    Optional.empty());
    }