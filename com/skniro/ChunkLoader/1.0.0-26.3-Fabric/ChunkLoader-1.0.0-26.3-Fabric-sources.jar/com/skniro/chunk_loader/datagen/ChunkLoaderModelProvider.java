package com.skniro.chunk_loader.datagen;

import com.skniro.chunk_loader.api.data.model.MapleModelDatagenHelper;
import com.skniro.chunk_loader.block.GrowableOresBlocks;
import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.minecraft.client.data.models.BlockModelGenerators;
import net.minecraft.client.data.models.ItemModelGenerators;

public class ChunkLoaderModelProvider extends FabricModelProvider {
    public ChunkLoaderModelProvider(FabricPackOutput dataGenerator){
        super(dataGenerator);
    }

    @Override
    public void generateBlockStateModels(BlockModelGenerators blockStateModelGenerator) {

        MapleModelDatagenHelper mapleModelDatagenHelper = new MapleModelDatagenHelper(blockStateModelGenerator);
        mapleModelDatagenHelper.registerMachineChunkLoader(GrowableOresBlocks.CHUNK_LOADER, true);
    }
    @Override
    public void generateItemModels(ItemModelGenerators itemModelGenerator) {

    }
}
