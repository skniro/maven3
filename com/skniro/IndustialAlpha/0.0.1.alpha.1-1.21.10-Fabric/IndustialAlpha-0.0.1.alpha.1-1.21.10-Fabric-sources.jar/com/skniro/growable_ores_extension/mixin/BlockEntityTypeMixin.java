package com.skniro.growable_ores_extension.mixin;

import net.minecraft.block.*;
import net.minecraft.class_2508;
import net.minecraft.class_2551;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7713;
import net.minecraft.class_7715;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2591.class)
public class BlockEntityTypeMixin {
    @Inject(method = "supports", at = @At("HEAD"), cancellable = true)
    private void supports(class_2680 state, CallbackInfoReturnable<Boolean> info) {
        if (class_2591.field_11911.equals(this) && (state.method_26204() instanceof class_2508 ||
                state.method_26204() instanceof class_2551)) {
            info.setReturnValue(true);
        }
        if (class_2591.field_40330.equals(this) && (state.method_26204() instanceof class_7713 ||
                state.method_26204() instanceof class_7715)) {
            info.setReturnValue(true);
        }
    }
}
