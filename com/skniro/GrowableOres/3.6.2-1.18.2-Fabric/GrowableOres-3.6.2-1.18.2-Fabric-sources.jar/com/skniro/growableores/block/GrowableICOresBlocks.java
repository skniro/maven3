package com.skniro.growableores.block;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.init.GrowableOreCaneBlock;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3614;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import java.util.logging.Logger;

public class GrowableICOresBlocks {
    //ic2 and ic2c
    public static final class_2248 IC2_Aluminium_Cane =registerBlock("ic_aluminium_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 IC2_silver_Cane =registerBlock("ic_silver_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 IC2_Tin_Cane =registerBlock("ic_tin_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 IC2_Uranium_Cane =registerBlock("ic_uranium_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);


    private static class_2248 registerBlock(String name, class_2248 block, class_1761 tab) {
        registerBlockItem(name, block, tab);
        return class_2378.method_10230(class_2378.field_11146, new class_2960(GrowableOres.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_1761 tab) {
        return class_2378.method_10230(class_2378.field_11142, new class_2960(GrowableOres.MOD_ID, name),
                new class_1747(block, new FabricItemSettings().method_7892(tab)));
    }
    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + GrowableOres.MOD_ID);
    }
}

