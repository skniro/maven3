package com.skniro.industrial_elixir.block.init.pipe;

import com.mojang.serialization.MapCodec;
import java.util.HashMap;
import java.util.Map;

import com.skniro.industrial_elixir.block.entity.pipe.PipeBlockEntity;
import com.skniro.industrial_elixir.block.entity.pipe.PipeExtractDirectionController;
import net.minecraft.class_1269;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.world.level.*;
import org.jetbrains.annotations.Nullable;

public abstract class PipeBlock extends class_2237 implements class_3737 {

    public static final class_2746 EAST;
    public static final class_2746 WEST;
    public static final class_2746 NORTH;
    public static final class_2746 SOUTH;
    public static final class_2746 UP;
    public static final class_2746 DOWN;
    public static final class_2746 WATERLOGGED;
    public static final class_2746 COVERED;

    public static final Map<class_2350, class_2746> PROPERTY_MAP;

    public PipeBlock(class_2251 settings) {
        super(settings);

        this.method_9590(this.method_9595().method_11664()
                .method_11657(EAST, false)
                .method_11657(WEST, false)
                .method_11657(NORTH, false)
                .method_11657(SOUTH, false)
                .method_11657(UP, false)
                .method_11657(DOWN, false)
                .method_11657(WATERLOGGED, false)
                .method_11657(COVERED, false)
        );
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        class_2586 be = world.method_8321(pos);
        if (!(be instanceof PipeExtractDirectionController controller)) return class_1269.field_5811;

        class_2350 side = hit.method_17780();
        if (player.method_5715()) {
            controller.clearPreferredExtractDirection();
        } else {
            controller.togglePreferredExtractDirection(side);
        }
        return class_1269.field_5812;
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return (world1, pos, state1, blockEntity) ->
                ((PipeBlockEntity) blockEntity).tick(world1, pos, state1);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        return (class_2680)this.method_9564().method_11657(WATERLOGGED, context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910);
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(WATERLOGGED)) {
            world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
        }

        return state;
    }

    @Override
    public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 block,
                               class_2338 fromPos, boolean notify) {

        class_2586 be = world.method_8321(pos);
        if (be instanceof PipeBlockEntity pipe) {
            pipe.neighborUpdate();
        }

        super.method_9612(state, world, pos, block, fromPos, notify);
    }


    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return state.method_11654(COVERED)
                ? class_259.method_1077()
                : PipeShapeUtil.getShape(state);
    }

    @Override
    public class_265 method_9571(class_2680 state, class_1922 world, class_2338 pos) {
        return PipeShapeUtil.getShape(state);
    }


    @Override
    public boolean method_10311(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        return !state.method_11654(COVERED) && class_3737.super.method_10311(world, pos, state, fluidState);
    }

    @Override
    public boolean method_10310(class_1657 player, class_1922 view, class_2338 pos, class_2680 state, class_3611 fluid) {
        return !state.method_11654(COVERED) && class_3737.super.method_10310(player, view, pos, state, fluid);
    }

    @Override
    public class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED)
                ? class_3612.field_15910.method_15729(false)
                : super.method_9545(state);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(EAST, WEST, NORTH, SOUTH, UP, DOWN, WATERLOGGED, COVERED);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        throw new IllegalStateException("PipeBlock does not support getCodec!");
    }

    // =========================
    // 静态
    // =========================

    static {
        EAST = class_2741.field_12487;
        WEST = class_2741.field_12527;
        NORTH = class_2741.field_12489;
        SOUTH = class_2741.field_12540;
        UP = class_2741.field_12519;
        DOWN = class_2741.field_12546;
        WATERLOGGED = class_2741.field_12508;
        COVERED = class_2746.method_11825("covered");

        PROPERTY_MAP = class_156.method_654(new HashMap<>(), map -> {
            map.put(class_2350.field_11034, EAST);
            map.put(class_2350.field_11039, WEST);
            map.put(class_2350.field_11043, NORTH);
            map.put(class_2350.field_11035, SOUTH);
            map.put(class_2350.field_11036, UP);
            map.put(class_2350.field_11033, DOWN);
        });
    }
}
