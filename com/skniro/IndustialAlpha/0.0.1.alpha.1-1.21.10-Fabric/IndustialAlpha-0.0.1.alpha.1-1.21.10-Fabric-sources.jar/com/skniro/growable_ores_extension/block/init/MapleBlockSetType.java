package com.skniro.growable_ores_extension.block.init;

import it.unimi.dsi.fastutil.objects.ObjectArraySet;
import java.util.Set;
import java.util.stream.Stream;
import net.minecraft.class_2498;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_8177;

public record MapleBlockSetType(String name, class_2498 soundType, class_3414 doorClose, class_3414 doorOpen, class_3414 trapdoorClose, class_3414 trapdoorOpen, class_3414 pressurePlateClickOff, class_3414 pressurePlateClickOn, class_3414 buttonClickOff, class_3414 buttonClickOn) {
    private static final Set<class_8177> VALUES = new ObjectArraySet<class_8177>();
    public static final class_8177 Rubber = register(new class_8177("rubber"));


    public MapleBlockSetType(String name) {
        this(name, class_2498.field_11547, class_3417.field_14541, class_3417.field_14664, class_3417.field_15080, class_3417.field_14932, class_3417.field_15002, class_3417.field_14961, class_3417.field_15105, class_3417.field_14699);
    }

    private static class_8177 register(class_8177 blockSetType) {
        VALUES.add(blockSetType);
        return blockSetType;
    }

    public static Stream<class_8177> stream() {
        return VALUES.stream();
    }
}
