package com.skniro.nether_ores_reborn;


import com.skniro.nether_ores_reborn.block.NetherOresBlocks;
import com.skniro.nether_ores_reborn.item.NetherOresItems;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_7706;




public class ModContent {


    public static void registerItem(){

        NetherOresItems.registerModItems();
    }
    public static void registerBlock(){
        NetherOresBlocks.registerNetherOresBlock();
    }

    public static void CreativeTab() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40743).register(content -> {
            content.method_45421(NetherOresBlocks.Nether_Coal_Ore);
            content.method_45421(NetherOresBlocks.Nether_Copper_Ore);
            content.method_45421(NetherOresBlocks.Nether_Diamond_Ore);
            content.method_45421(NetherOresBlocks.Nether_Emerald_Ore);
            content.method_45421(NetherOresBlocks.Nether_Gold_Ore);
            content.method_45421(NetherOresBlocks.Nether_Iron_Ore);
            content.method_45421(NetherOresBlocks.Nether_Lapis_Ore);
            content.method_45421(NetherOresBlocks.Nether_Redstone_Ore);

            content.method_45421(NetherOresBlocks.End_Coal_Ore);
            content.method_45421(NetherOresBlocks.End_Copper_Ore);
            content.method_45421(NetherOresBlocks.End_Diamond_Ore);
            content.method_45421(NetherOresBlocks.End_Emerald_Ore);
            content.method_45421(NetherOresBlocks.End_Gold_Ore);
            content.method_45421(NetherOresBlocks.End_Iron_Ore);
            content.method_45421(NetherOresBlocks.End_Lapis_Ore);
            content.method_45421(NetherOresBlocks.End_Redstone_Ore);
        });
    }
}
