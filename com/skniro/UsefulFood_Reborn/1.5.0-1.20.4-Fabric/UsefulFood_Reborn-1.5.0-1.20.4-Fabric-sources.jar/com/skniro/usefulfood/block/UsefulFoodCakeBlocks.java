package com.skniro.usefulfood.block;

import com.skniro.usefulfood.UsefulFood;
import com.skniro.usefulfood.block.init.*;
import com.skniro.usefulfood.block.init.candle.CandleAppleCakeBlock;
import com.skniro.usefulfood.block.init.candle.CandleCaramelCakeBlock;
import com.skniro.usefulfood.block.init.candle.CandleChocolateCakeBlock;
import com.skniro.usefulfood.block.init.candle.CandleMagicCakeBlock;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import java.util.function.ToIntFunction;
import java.util.logging.Logger;

public class UsefulFoodCakeBlocks {
    //Apple cake
    public static final class_2248 AppleCake = registerBlock("applecake",new AppleCakeBlockState(FabricBlockSettings.method_9630(class_2246.field_10183),18,0.6F),1, UsefulFood.UsefulFood_Group);
    public static final class_2248 Apple_CANDLE_CAKE = registerBlockWithoutItem("apple_candle_cake", new CandleAppleCakeBlock(class_2246.field_27099, class_4970.class_2251.method_9630(AppleCake) ));
    public static final class_2248 Apple_YELLOW_CANDLE_CAKE = registerBlockWithoutItem("apple_yellow_candle_cake", new CandleAppleCakeBlock(class_2246.field_27104, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_LIME_CANDLE_CAKE = registerBlockWithoutItem("apple_lime_candle_cake", new CandleAppleCakeBlock(class_2246.field_27105, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_PINK_CANDLE_CAKE = registerBlockWithoutItem("apple_pink_candle_cake", new CandleAppleCakeBlock(class_2246.field_27106, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_GRAY_CANDLE_CAKE = registerBlockWithoutItem("apple_gray_candle_cake", new CandleAppleCakeBlock(class_2246.field_27107, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_LIGHT_GRAY_CANDLE_CAKE = registerBlockWithoutItem("apple_light_gray_candle_cake", new CandleAppleCakeBlock(class_2246.field_27108, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_CYAN_CANDLE_CAKE = registerBlockWithoutItem("apple_cyan_candle_cake", new CandleAppleCakeBlock(class_2246.field_27109, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_PURPLE_CANDLE_CAKE = registerBlockWithoutItem("apple_purple_candle_cake", new CandleAppleCakeBlock(class_2246.field_27110, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_BLUE_CANDLE_CAKE = registerBlockWithoutItem("apple_blue_candle_cake", new CandleAppleCakeBlock(class_2246.field_27111, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_BROWN_CANDLE_CAKE = registerBlockWithoutItem("apple_brown_candle_cake", new CandleAppleCakeBlock(class_2246.field_27112, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_GREEN_CANDLE_CAKE = registerBlockWithoutItem("apple_green_candle_cake", new CandleAppleCakeBlock(class_2246.field_27113, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_RED_CANDLE_CAKE = registerBlockWithoutItem("apple_red_candle_cake", new CandleAppleCakeBlock(class_2246.field_27140, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_BLACK_CANDLE_CAKE = registerBlockWithoutItem("apple_black_candle_cake", new CandleAppleCakeBlock(class_2246.field_27141, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_WHITE_CANDLE_CAKE = registerBlockWithoutItem("apple_white_candle_cake", new CandleAppleCakeBlock(class_2246.field_27100, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_ORANGE_CANDLE_CAKE = registerBlockWithoutItem("apple_orange_candle_cake", new CandleAppleCakeBlock(class_2246.field_27101, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_MAGENTA_CANDLE_CAKE = registerBlockWithoutItem("apple_magenta_candle_cake", new CandleAppleCakeBlock(class_2246.field_27102, class_4970.class_2251.method_9630(AppleCake)));
    public static final class_2248 Apple_LIGHT_BLUE_CANDLE_CAKE = registerBlockWithoutItem("apple_light_blue_candle_cake", new CandleAppleCakeBlock(class_2246.field_27103, class_4970.class_2251.method_9630(AppleCake)));

    //Chocolate cake
    public static final class_2248 ChocolateCake = registerBlock("chocolatecake",new ChocolateCakeBlockState(FabricBlockSettings.method_9630(class_2246.field_10183),12,0.5F),1, UsefulFood.UsefulFood_Group);
    public static final class_2248 Chocolate_CANDLE_CAKE = registerBlockWithoutItem("chocolate_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27099, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_YELLOW_CANDLE_CAKE = registerBlockWithoutItem("chocolate_yellow_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27104, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_LIME_CANDLE_CAKE = registerBlockWithoutItem("chocolate_lime_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27105, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_PINK_CANDLE_CAKE = registerBlockWithoutItem("chocolate_pink_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27106, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_GRAY_CANDLE_CAKE = registerBlockWithoutItem("chocolate_gray_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27107, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_LIGHT_GRAY_CANDLE_CAKE = registerBlockWithoutItem("chocolate_light_gray_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27108, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_CYAN_CANDLE_CAKE = registerBlockWithoutItem("chocolate_cyan_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27109, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_PURPLE_CANDLE_CAKE = registerBlockWithoutItem("chocolate_purple_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27110, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_BLUE_CANDLE_CAKE = registerBlockWithoutItem("chocolate_blue_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27111, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_BROWN_CANDLE_CAKE = registerBlockWithoutItem("chocolate_brown_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27112, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_GREEN_CANDLE_CAKE = registerBlockWithoutItem("chocolate_green_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27113, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_RED_CANDLE_CAKE = registerBlockWithoutItem("chocolate_red_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27140, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_BLACK_CANDLE_CAKE = registerBlockWithoutItem("chocolate_black_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27141, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_WHITE_CANDLE_CAKE = registerBlockWithoutItem("chocolate_white_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27100, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_ORANGE_CANDLE_CAKE = registerBlockWithoutItem("chocolate_orange_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27101, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_MAGENTA_CANDLE_CAKE = registerBlockWithoutItem("chocolate_magenta_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27102, class_4970.class_2251.method_9630(ChocolateCake)));
    public static final class_2248 Chocolate_LIGHT_BLUE_CANDLE_CAKE = registerBlockWithoutItem("chocolate_light_blue_candle_cake", new CandleChocolateCakeBlock(class_2246.field_27103, class_4970.class_2251.method_9630(ChocolateCake)));


    //Magic cake
    public static final class_2248 MagicCake = registerBlock("magiccake", new MagicCakeBlockState(FabricBlockSettings.method_9630(class_2246.field_10183), 48, 0.5F),1, UsefulFood.UsefulFood_Group);
    public static final class_2248 Magic_CANDLE_CAKE = registerBlockWithoutItem("magic_candle_cake", new CandleMagicCakeBlock(class_2246.field_27099, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_YELLOW_CANDLE_CAKE = registerBlockWithoutItem("magic_yellow_candle_cake", new CandleMagicCakeBlock(class_2246.field_27104, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_LIME_CANDLE_CAKE = registerBlockWithoutItem("magic_lime_candle_cake", new CandleMagicCakeBlock(class_2246.field_27105, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_PINK_CANDLE_CAKE = registerBlockWithoutItem("magic_pink_candle_cake", new CandleMagicCakeBlock(class_2246.field_27106, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_GRAY_CANDLE_CAKE = registerBlockWithoutItem("magic_gray_candle_cake", new CandleMagicCakeBlock(class_2246.field_27107, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_LIGHT_GRAY_CANDLE_CAKE = registerBlockWithoutItem("magic_light_gray_candle_cake", new CandleMagicCakeBlock(class_2246.field_27108, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_CYAN_CANDLE_CAKE = registerBlockWithoutItem("magic_cyan_candle_cake", new CandleMagicCakeBlock(class_2246.field_27109, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_PURPLE_CANDLE_CAKE = registerBlockWithoutItem("magic_purple_candle_cake", new CandleMagicCakeBlock(class_2246.field_27110, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_BLUE_CANDLE_CAKE = registerBlockWithoutItem("magic_blue_candle_cake", new CandleMagicCakeBlock(class_2246.field_27111, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_BROWN_CANDLE_CAKE = registerBlockWithoutItem("magic_brown_candle_cake", new CandleMagicCakeBlock(class_2246.field_27112, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_GREEN_CANDLE_CAKE = registerBlockWithoutItem("magic_green_candle_cake", new CandleMagicCakeBlock(class_2246.field_27113, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_RED_CANDLE_CAKE = registerBlockWithoutItem("magic_red_candle_cake", new CandleMagicCakeBlock(class_2246.field_27140, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_BLACK_CANDLE_CAKE = registerBlockWithoutItem("magic_black_candle_cake", new CandleMagicCakeBlock(class_2246.field_27141, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_WHITE_CANDLE_CAKE = registerBlockWithoutItem("magic_white_candle_cake", new CandleMagicCakeBlock(class_2246.field_27100, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_ORANGE_CANDLE_CAKE = registerBlockWithoutItem("magic_orange_candle_cake", new CandleMagicCakeBlock(class_2246.field_27101, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_MAGENTA_CANDLE_CAKE = registerBlockWithoutItem("magic_magenta_candle_cake", new CandleMagicCakeBlock(class_2246.field_27102, class_4970.class_2251.method_9630(MagicCake)));
    public static final class_2248 Magic_LIGHT_BLUE_CANDLE_CAKE = registerBlockWithoutItem("magic_light_blue_candle_cake", new CandleMagicCakeBlock(class_2246.field_27103, class_4970.class_2251.method_9630(MagicCake)));

    // 1.4
    //Caramel cake
    public static final class_2248 CaramelCake = registerBlock("caramelcake",new CaramelCakeBlockState(FabricBlockSettings.method_9630(class_2246.field_10183),19,0.1F),1, UsefulFood.UsefulFood_Group);
    public static final class_2248 Caramel_CANDLE_CAKE = registerBlockWithoutItem("caramel_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27099, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_YELLOW_CANDLE_CAKE = registerBlockWithoutItem("caramel_yellow_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27104, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_LIME_CANDLE_CAKE = registerBlockWithoutItem("caramel_lime_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27105, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_PINK_CANDLE_CAKE = registerBlockWithoutItem("caramel_pink_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27106, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_GRAY_CANDLE_CAKE = registerBlockWithoutItem("caramel_gray_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27107, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_LIGHT_GRAY_CANDLE_CAKE = registerBlockWithoutItem("caramel_light_gray_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27108, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_CYAN_CANDLE_CAKE = registerBlockWithoutItem("caramel_cyan_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27109, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_PURPLE_CANDLE_CAKE = registerBlockWithoutItem("caramel_purple_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27110, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_BLUE_CANDLE_CAKE = registerBlockWithoutItem("caramel_blue_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27111, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_BROWN_CANDLE_CAKE = registerBlockWithoutItem("caramel_brown_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27112, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_GREEN_CANDLE_CAKE = registerBlockWithoutItem("caramel_green_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27113, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_RED_CANDLE_CAKE = registerBlockWithoutItem("caramel_red_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27140, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_BLACK_CANDLE_CAKE = registerBlockWithoutItem("caramel_black_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27141, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_WHITE_CANDLE_CAKE = registerBlockWithoutItem("caramel_white_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27100, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_ORANGE_CANDLE_CAKE = registerBlockWithoutItem("caramel_orange_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27101, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_MAGENTA_CANDLE_CAKE = registerBlockWithoutItem("caramel_magenta_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27102, class_4970.class_2251.method_9630(CaramelCake)));
    public static final class_2248 Caramel_LIGHT_BLUE_CANDLE_CAKE = registerBlockWithoutItem("caramel_light_blue_candle_cake", new CandleCaramelCakeBlock(class_2246.field_27103, class_4970.class_2251.method_9630(CaramelCake)));


    private static class_2248 registerBlock(String name, class_2248 block) {
        registerBlockItem(name, block);
        return class_2378.method_10230(class_7923.field_41175, new class_2960(UsefulFood.MOD_ID, name), block);
    }

    private static class_2248 registerBlock(String name, class_2248 block, int Maxcount, class_5321<class_1761> tab) {
        registerBlockItem(name, block, Maxcount, tab);
        return class_2378.method_10230(class_7923.field_41175, new class_2960(UsefulFood.MOD_ID, name), block);
    }

    private static class_2248 registerBlockWithoutItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, new class_2960(UsefulFood.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, int Maxcount, class_5321<class_1761> tab) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(UsefulFood.MOD_ID, name),
                new class_1747(block, new FabricItemSettings().method_7889(Maxcount)));
    }

    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(UsefulFood.MOD_ID, name),
                new class_1747(block, new FabricItemSettings()));
    }

    public static ToIntFunction<class_2680> createLightLevelFromLitBlockState(int litLevel) {
        return (state) -> {
            return (Boolean)state.method_11654(class_2741.field_12548) ? litLevel : 0;
        };
    }

    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + UsefulFood.MOD_ID);
    }
}

