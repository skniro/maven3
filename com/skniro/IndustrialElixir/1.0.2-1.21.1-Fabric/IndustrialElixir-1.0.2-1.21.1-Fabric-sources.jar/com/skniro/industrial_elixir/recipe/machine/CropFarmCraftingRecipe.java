package com.skniro.industrial_elixir.recipe.machine;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import com.skniro.industrial_elixir.recipe.ModRecipeSerializers;

public class CropFarmCraftingRecipe extends AbstractMachineCraftingRecipe {
    private final Optional<class_1799> output2;
    private final Optional<class_1799> output3;
    private final int processTime;

    public CropFarmCraftingRecipe(class_1856 ingredient, int requiredCount, class_1799 output,
                                  Optional<class_1799> output2, Optional<class_1799> output3,
                                  int processTime) {
        super(ingredient, requiredCount, output);
        this.output2 = output2;
        this.output3 = output3;
        this.processTime = processTime;
    }

    @Override
    public class_1865<? extends class_1860<AlchemyCraftingRecipeInput>> method_8119() {
        return AlchemyRecipeType.CROP_FARM.serializer;
    }

    @Override
    public class_3956<? extends class_1860<AlchemyCraftingRecipeInput>> method_17716() {
        return AlchemyRecipeType.CROP_FARM.type;
    }


    public Optional<class_1799> output2() {
        return output2;
    }

    public Optional<class_1799> output3() {
        return output3;
    }

    public int processTime() {
        return processTime;
    }

    public static final MapCodec<CropFarmCraftingRecipe> CODEC =
            RecordCodecBuilder.mapCodec(inst -> inst.group(
                    class_1856.field_46095.fieldOf("ingredient").forGetter(recipe -> recipe.ingredient),
                    Codec.INT.fieldOf("count").forGetter(recipe -> recipe.requiredCount),
                    class_1799.field_24671.fieldOf("result").forGetter(recipe -> recipe.output),
                    class_1799.field_24671.optionalFieldOf("result2").forGetter(recipe -> recipe.output2),
                    class_1799.field_24671.optionalFieldOf("result3").forGetter(recipe -> recipe.output3),
                    Codec.INT.fieldOf("process_time").forGetter(recipe -> recipe.processTime)
            ).apply(inst, CropFarmCraftingRecipe::new));

    public static final class_9139<class_9129, CropFarmCraftingRecipe> field_48356 =
            class_9139.method_58025(
                    class_1856.field_48355, AbstractMachineCraftingRecipe::ingredient,
                    class_9135.field_49675, AbstractMachineCraftingRecipe::requiredCount,
                    class_1799.field_48349, AbstractMachineCraftingRecipe::output,
                    class_9135.method_56382(class_1799.field_48349), CropFarmCraftingRecipe::output2,
                    class_9135.method_56382(class_1799.field_48349), CropFarmCraftingRecipe::output3,
                    class_9135.field_49675, CropFarmCraftingRecipe::processTime,
                    CropFarmCraftingRecipe::new);

    public static final class_1865<CropFarmCraftingRecipe> SERIALIZER =
            ModRecipeSerializers.of(CODEC, field_48356);
}
