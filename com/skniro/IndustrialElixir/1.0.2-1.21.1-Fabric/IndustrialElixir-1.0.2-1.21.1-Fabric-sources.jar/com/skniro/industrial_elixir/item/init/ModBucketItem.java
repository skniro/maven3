package com.skniro.industrial_elixir.item.init;

import com.skniro.industrial_elixir.block.init.ModStairBlock;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluids;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2263;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239.class_240;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3486;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3965;
import net.minecraft.class_5328;
import net.minecraft.class_5633;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.Nullable;

public class ModBucketItem extends class_1792 implements class_5633 {
    private final class_3611 content;

    public ModBucketItem(final class_3611 content, final class_1792.class_1793 properties) {
        super(properties);
        this.content = content;
    }

    @Override
    public class_1271<class_1799> method_7836(final class_1937 level, final class_1657 player, final class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);
        class_3965 hitResult = method_7872(level, player, this.content == class_3612.field_15906 ? net.minecraft.class_3959.class_242.field_1345 : net.minecraft.class_3959.class_242.field_1348);
        if (hitResult.method_17783() == class_240.field_1333) {
            return class_1271.method_22430(itemStack);
        } else if (hitResult.method_17783() != class_240.field_1332) {
            return class_1271.method_22430(itemStack);
        } else {
            class_2338 pos = hitResult.method_17777();
            class_2350 direction = hitResult.method_17780();
            class_2338 directionOffsetPos = pos.method_10093(direction);
            if (level.method_8505(player, pos) && player.method_7343(directionOffsetPos, direction, itemStack)) {
                if (this.content == class_3612.field_15906) {
                    class_2680 blockState = level.method_8320(pos);
                    class_2248 var15 = blockState.method_26204();
                    if (var15 instanceof class_2263) {
                        class_2263 bucketPickupBlock = (class_2263)var15;
                        class_1799 taken = bucketPickupBlock.method_9700(player, level, pos, blockState);
                        if (!taken.method_7960()) {
                            player.method_7259(class_3468.field_15372.method_14956(this));
                            bucketPickupBlock.method_32351().ifPresent((soundEvent) -> player.method_5783(soundEvent, 1.0F, 1.0F));
                            level.method_33596(player, class_5712.field_28167, pos);
                            class_1799 result = class_5328.method_30012(itemStack, player, taken);
                            if (!level.method_8608()) {
                                class_174.field_1208.method_8932((class_3222)player, taken);
                            }

                            return class_1271.method_29237(result, level.method_8608());
                        }
                    }

                    return class_1271.method_22431(itemStack);
                } else {
                    class_2680 clicked = level.method_8320(pos);
                    class_2338 placePos = clicked.method_26204() instanceof ModStairBlock && this.content == IndustrialElixirFluids.STILL_Hot_Spring ? pos : directionOffsetPos;
                    if (this.method_7731(player, level, placePos, hitResult)) {
                        this.method_7728(player, level, itemStack, placePos);
                        if (player instanceof class_3222) {
                            class_174.field_1191.method_23889((class_3222)player, placePos, itemStack);
                        }

                        player.method_7259(class_3468.field_15372.method_14956(this));
                        class_1799 emptyResult = class_5328.method_30012(itemStack, player, getEmptySuccessItem(itemStack, player));
                        return class_1271.method_29237(emptyResult, level.method_8608());
                    } else {
                        return class_1271.method_22431(itemStack);
                    }
                }
            } else {
                return class_1271.method_22431(itemStack);
            }
        }
    }

    public static class_1799 getEmptySuccessItem(final class_1799 itemStack, final class_1657 player) {
        return !player.method_56992() ? new class_1799(class_1802.field_8550) : itemStack;
    }

    @Override
    public void method_7728(final @Nullable class_1657 user, final class_1937 level, final class_1799 itemStack, final class_2338 pos) {
    }

    @Override
    public boolean method_7731(final @Nullable class_1657 user, final class_1937 level, final class_2338 pos, final @Nullable class_3965 hitResult) {
        class_3611 var6 = this.content;
        class_2680 blockState = level.method_8320(pos);
        if (!(var6 instanceof class_3609 flowingFluid)) {
            return false;
        } else {
            class_2248 block;
            boolean mayReplace;
            boolean shiftKeyDown;
            boolean var10000;
            label106: {
                block = blockState.method_26204();
                mayReplace = blockState.method_26188(this.content);
                shiftKeyDown = user != null && user.method_5715();
                if (!mayReplace) {
                    label103: {
                        if (block instanceof ModStairBlock) {
                            ModStairBlock container = (ModStairBlock)block;
                            if (container.method_10310(user, level, pos, blockState, this.content)) {
                                break label103;
                            }
                        }

                        var10000 = false;
                        break label106;
                    }
                }

                var10000 = true;
            }

            boolean placeLiquid = var10000;
            boolean canPlaceFluidInsideBlock = blockState.method_26215() || placeLiquid && (!shiftKeyDown || hitResult == null);
            if (!canPlaceFluidInsideBlock) {
                return hitResult != null && this.method_7731(user, level, hitResult.method_17777().method_10093(hitResult.method_17780()), (class_3965)null);
            } else if (level.method_8597().comp_644() && this.content.method_15791(class_3486.field_15517)) {
                int x = pos.method_10263();
                int y = pos.method_10264();
                int z = pos.method_10260();
                class_5819 random = level.method_8409();
                level.method_8396(user, pos, class_3417.field_15102, class_3419.field_15245, 0.5F, 2.6F + (random.method_43057() - random.method_43057()) * 0.8F);

                for(int i = 0; i < 8; ++i) {
                    level.method_8406(class_2398.field_11237, (double)((float)x + random.method_43057()), (double)((float)y + random.method_43057()), (double)((float)z + random.method_43057()), (double)0.0F, (double)0.0F, (double)0.0F);
                }

                return true;
            } else {
                if (block instanceof ModStairBlock) {
                    ModStairBlock container = (ModStairBlock)block;
                    if (this.content == IndustrialElixirFluids.STILL_Hot_Spring) {
                        container.method_10311(level, pos, blockState, flowingFluid.method_15729(false));
                        this.playEmptySound(user, level, pos);
                        return true;
                    }
                }

                if (!level.method_8608() && mayReplace && !blockState.method_51176()) {
                    level.method_22352(pos, true);
                }

                if (!level.method_8652(pos, this.content.method_15785().method_15759(), 11) && !blockState.method_26227().method_15771()) {
                    return false;
                } else {
                    this.playEmptySound(user, level, pos);
                    return true;
                }
            }
        }
    }

    protected void playEmptySound(final @Nullable class_1657 user, final class_1936 level, final class_2338 pos) {
        class_3414 soundEvent = this.content.method_15791(class_3486.field_15518) ? class_3417.field_15010 : class_3417.field_14834;
        level.method_8396(user, pos, soundEvent, class_3419.field_15245, 1.0F, 1.0F);
        level.method_33596(user, class_5712.field_28166, pos);
    }

    public class_3611 getContent() {
        return this.content;
    }
}