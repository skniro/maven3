package com.skniro.industrial_elixir.block.init.pipe;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2769;

public final class PipeShapeUtil {
    private static final Map<class_2680, class_265> SHAPE_CACHE = new IdentityHashMap();

    private static class_265 getStateShape(class_2680 state) {
        PipeBlock cableBlock = (PipeBlock)state.method_26204();
        //double size = cableBlock.type.cableThickness;
        class_265 baseShape = class_259.method_1081(10.0F/ 2.0 / 16.0, 10.0F/ 2.0 / 16.0, 10.0F/ 2.0 / 16.0, (double)1.0F - 10.0F/ 2.0 / 16.0, (double)1.0F - 10.0F/ 2.0 / 16.0, (double)1.0F - 10.0F/ 2.0 / 16.0);
        List<class_265> connections = new ArrayList();

        for(class_2350 dir : class_2350.values()) {
            if ((Boolean)state.method_11654((class_2769) PipeBlock.PROPERTY_MAP.get(dir))) {
                double[] mins = new double[]{10.0F/ 2.0 / 16.0, 10.0F/ 2.0 / 16.0, 10.0F/ 2.0 / 16.0};
                double[] maxs = new double[]{(double)1.0F - 10.0F/ 2.0 / 16.0, (double)1.0F - 10.0F/ 2.0 / 16.0, (double)1.0F - 10.0F/ 2.0 / 16.0};
                int axis = dir.method_10166().ordinal();
                if (dir.method_10171() == class_2352.field_11056) {
                    maxs[axis] = (double)1.0F;
                } else {
                    mins[axis] = (double)0.0F;
                }

                connections.add(class_259.method_1081(mins[0], mins[1], mins[2], maxs[0], maxs[1], maxs[2]));
            }
        }

        return class_259.method_17786(baseShape, (class_265[])connections.toArray(new class_265[0]));
    }

    public static class_265 getShape(class_2680 state) {
        return (class_265)SHAPE_CACHE.computeIfAbsent(state, PipeShapeUtil::getStateShape);
    }
}
