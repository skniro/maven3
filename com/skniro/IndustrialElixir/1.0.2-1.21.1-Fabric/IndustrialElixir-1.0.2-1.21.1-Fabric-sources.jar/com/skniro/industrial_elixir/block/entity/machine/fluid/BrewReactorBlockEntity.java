package com.skniro.industrial_elixir.block.entity.machine.fluid;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.fluid.BrewReactorBlock;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.machine.AbstractMachineCraftingRecipe;
import com.skniro.industrial_elixir.recipe.machine.BrewReactorCraftingRecipe;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.BrewReactorScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1264;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class BrewReactorBlockEntity extends AbstractFluidMachineEntity {

    public BrewReactorBlockEntity(class_2338 pos, class_2680 blockState) {
        super(AlchemyBlockEntityType.Brew_Reactor_BLOCK_ENTITY, pos, blockState);
        this.DEFAULT_MAX_PROGRESS = 100;
        this.maxProgress = 100;
    }

    // 40/20 = 2 EU/t
    @Override
    public long getCraftEnergyCost() {
        return 40;
    }

    @Override
    protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        SingleVariantStorage.writeNbt(fluidContainer, FluidVariant.CODEC, output, registries);
    }

    @Override
    protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        super.method_11014(input, registries);
        SingleVariantStorage.readNbt(fluidContainer, FluidVariant.CODEC, FluidVariant::blank, input, registries);
    }

    public void drops() {
        class_1264.method_17349(this.field_11863, this.field_11867, inventory);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.BrewReactor);
    }

    @Override
    public @Nullable class_1703 createMenu(int containerId, class_1661 inventory, class_1657 player) {
        return new BrewReactorScreenHandler(containerId, inventory, this, this.propertyDelegate);
    }

    @Override
    protected void craftItem() {
        java.util.Optional<class_8786<AbstractMachineCraftingRecipe>> recipe = getCurrentRecipe();
        net.minecraft.class_1799 output = recipe.get().comp_1933().output().method_7972();
        // consume primary input according to recipe
        this.method_5434(INPUT_SLOT, recipe.get().comp_1933().requiredCount());
        // consume one from the secondary input slot
        this.method_5434(SECOND_INPUT_SLOT, 1);
        if (this.method_5438(OUTPUT_SLOT).method_7960()) {
            this.method_5447(OUTPUT_SLOT, output.method_7972());
        } else {
            this.method_5438(OUTPUT_SLOT).method_7933(output.method_7947());
        }
        try (Transaction tx = Transaction.openOuter()) {
            fluidContainer.extract(fluidContainer.getResource(), FLUID_CRAFT_AMOUNT, tx);
            tx.commit();
        }
    }

    /* SIDED INVENTORY */
    @Override
    public boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 side) {
        if (side == null || side == class_2350.field_11033) return false;
        if (side == class_2350.field_11036) return slot == INPUT_SLOT;

        if (slot != INPUT_SLOT && slot != FLUID_ITEM_SLOT && slot != ENERGY_ITEM_SLOT) {
            return false;
        }

        class_2350 localDir = this.field_11863.method_8320(this.method_11016()).method_11654(BrewReactorBlock.FACING);
        return switch (slot) {
            case INPUT_SLOT, SECOND_INPUT_SLOT -> side != localDir.method_10153(); // If not Up/Down/Back, it must be Front/Left/Right
            case FLUID_ITEM_SLOT -> side == localDir.method_10170(); // Left
            case ENERGY_ITEM_SLOT -> side == localDir.method_10160(); // Right
            default -> false; // Fallback
        };
    }

    @Override
    public boolean method_5493(int slot, class_1799 stack, class_2350 side) {
        if (slot != OUTPUT_SLOT || side == class_2350.field_11036) {
            return false;
        }

        if (side == class_2350.field_11033) {
            return true;
        }

        class_2350 localDir = this.field_11863.method_8320(this.method_11016()).method_11654(BrewReactorBlock.FACING);
        return side == localDir.method_10153() || side == localDir.method_10170();
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return AlchemyRecipeType.BREW_REACTOR.type;
    }

    @Override
    public int[] method_5494(net.minecraft.class_2350 direction) {
        if (direction != net.minecraft.class_2350.field_11033) {
            return new int[]{INPUT_SLOT, SECOND_INPUT_SLOT};
        } else {
            return new int[]{OUTPUT_SLOT};
        }
    }

    @Override
    public Optional<class_8786<AbstractMachineCraftingRecipe>> getCurrentRecipe() {
        return this.method_10997().method_8503().method_3772()
                .method_8132((class_3956<AbstractMachineCraftingRecipe>) getCurrentRecipeType(),
                        new AlchemyCraftingRecipeInput(inventory.get(INPUT_SLOT), inventory.get(SECOND_INPUT_SLOT)), this.method_10997());
    }

    @Override
    public boolean hasRecipe() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> opt = getCurrentRecipe();
        if (opt.isEmpty()) return false;

        var recipeHolder = opt.get();
        var recipe = recipeHolder.comp_1933();
        net.minecraft.class_1799 output = recipe.output().method_7972();

        if (!canInsertAmountIntoOutputSlot(output.method_7947()) || !canInsertItemIntoOutputSlot(output)) return false;
        if (!hasEnoughEnergyToCraft()) return false;

        // If recipe is a BrewReactorCraftingRecipe and specifies a fluid, check fluid type and amount
        if (recipe instanceof BrewReactorCraftingRecipe brew) {
            java.util.Optional<net.minecraft.class_2960> fluidOpt = brew.requiredFluid();
            java.util.Optional<Integer> amtOpt = brew.requiredFluidAmount();
            if (fluidOpt != null && fluidOpt.isPresent()) {
                try {
                    // compare registry ids to avoid Holder vs Fluid type issues
                    var currentFluid = this.fluidContainer.getResource().getFluid();
                    var currentId = class_7923.field_41173.method_10221(currentFluid);
                    if (currentId == null || !fluidOpt.get().equals(currentId)) return false;
                    int required = (amtOpt != null && amtOpt.isPresent()) ? amtOpt.get() : AbstractFluidMachineEntity.FLUID_CRAFT_AMOUNT;
                    return this.fluidContainer.getAmount() >= required;
                } catch (Throwable t) {
                    return false;
                }
            }
        }

        return hasEnoughFluidToCraft();
    }
}