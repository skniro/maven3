package com.skniro.growable_ores_extension.block.init.machine;


import com.mojang.serialization.MapCodec;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.block.entity.machine.ExtractorEntity;
import com.skniro.growable_ores_extension.block.entity.machine.MaceratorEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class ExtractorBlock extends AbstractMachineblock {
    public ExtractorBlock(class_2251 settings) {
        super(settings, EnergyTier.TIER1);
    }
    public static final MapCodec<ExtractorBlock> field_46280 = method_54094(ExtractorBlock::new);

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ExtractorEntity(pos,state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, AlchemyBlockEntityType.Extractor_BLOCK_ENTITY, (world1, pos, state1, blockEntity) -> blockEntity.tick(world1, pos, state1));
    }

}
