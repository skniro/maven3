package com.skniro.growable_ores_extension.block.entity.container.fluid;

import com.skniro.growable_ores_extension.api.ImplementedInventory;
import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import com.skniro.growable_ores_extension.screen.handler.container.fluid.FluidTankScreenHandler;
import net.fabricmc.fabric.api.menu.v1.ExtendedMenuProvider;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.StoragePreconditions;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jetbrains.annotations.Nullable;

public class FluidTankBlockEntity extends BlockEntity implements ExtendedMenuProvider<BlockPos>, ImplementedInventory {
    public final NonNullList<ItemStack> inventory = NonNullList.withSize(4, ItemStack.EMPTY);
    protected final ContainerData propertyDelegate;
    public SingleVariantStorage<FluidVariant> fluidContainer = new SingleVariantStorage<FluidVariant>() {
        @Override
        protected FluidVariant getBlankVariant() {
            return FluidVariant.blank();
        }

        @Override
        protected long getCapacity(FluidVariant variant) {
            return (FluidConstants.BUCKET / 81) * 16; // 1 Bucket = 81000 Droplets = 1000mB || * 16 ==> 16,000mB = 16 Buckets
        }

        @Override
        protected void onFinalCommit() {
            setChanged(level, getBlockPos(), getBlockState());
            getLevel().sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    };

    public FluidTankBlockEntity(BlockPos pos, BlockState state) {
        super(AlchemyBlockEntityType.FLUID_TANK_BLOCK_ENTITY, pos, state);
        this.propertyDelegate = new ContainerData(){

            @Override
            public int get(int dataId) {
                return 0;
            }

            @Override
            public void set(int dataId, int value) {

            }

            @Override
            public int getCount() {
                return 0;
            }
        };
    }

    public void tick() {
    }

    public float getFillRatio() {
        if (fluidContainer.amount <= 0) return 0.0f;
        return Math.min(1.0f, (float) fluidContainer.amount / (float) fluidContainer.getCapacity());
    }

    public FluidVariant getFluidVariant() {
        return fluidContainer.variant;
    }

    public long getAmount() {
        return fluidContainer.amount;
    }

    public InteractionResult interactBucket(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        // Fill tank from filled bucket
        if (stack.is(Items.WATER_BUCKET) || stack.is(Items.LAVA_BUCKET)) {
            Fluid fluid = stack.is(Items.WATER_BUCKET) ? Fluids.WATER : Fluids.LAVA;
            FluidVariant toInsert = FluidVariant.of(fluid);
            if (!fluidContainer.variant.isBlank() && !fluidContainer.variant.equals(toInsert)) {
                return InteractionResult.PASS;
            }
            long inserted;
            try (Transaction tx = Transaction.openOuter()) {
                inserted = fluidContainer.insert(toInsert, FluidConstants.BUCKET, tx);
                if (inserted == FluidConstants.BUCKET) {
                    tx.commit();
                }
            }
            if (inserted == FluidConstants.BUCKET) {
                if (!player.isCreative()) {
                    player.setItemInHand(hand, new ItemStack(Items.BUCKET));
                }
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        }

        // Drain tank to empty bucket
        if (stack.is(Items.BUCKET) && fluidContainer.amount >= FluidConstants.BUCKET && !fluidContainer.variant.isBlank()) {
            ItemStack filled = new ItemStack(fluidContainer.variant.getFluid().getBucket());
            if (filled.isEmpty()) {
                return InteractionResult.PASS;
            }
            long extracted;
            try (Transaction tx = Transaction.openOuter()) {
                extracted = fluidContainer.extract(fluidContainer.variant, FluidConstants.BUCKET, tx);
                if (extracted == FluidConstants.BUCKET) {
                    tx.commit();
                }
            }
            if (extracted == FluidConstants.BUCKET) {
                if (!player.isCreative()) {
                    stack.shrink(1);
                    if (stack.isEmpty()) {
                        player.setItemInHand(hand, filled);
                    } else if (!player.getInventory().add(filled)) {
                        player.drop(filled, false);
                    }
                }
                return InteractionResult.SUCCESS;
            }
        }

        return InteractionResult.PASS;
    }

    @Override
    protected void saveAdditional(ValueOutput nbt) {
        super.saveAdditional(nbt);
        nbt.putLong("tank.amount", fluidContainer.amount);
        if (!fluidContainer.variant.isBlank()) {
            nbt.putInt("tank.fluid_id", BuiltInRegistries.FLUID.getId(fluidContainer.variant.getFluid()));
        } else {
            nbt.putInt("tank.fluid_id", -1);
        }
    }

    @Override
    protected void loadAdditional(ValueInput nbt) {
        super.loadAdditional(nbt);
        long amount = nbt.getLongOr("tank.amount", 0);
        int fluidId = nbt.getIntOr("tank.fluid_id", -1);
        if (amount <= 0 || fluidId < 0) {
            fluidContainer.variant = FluidVariant.blank();
            fluidContainer.amount = 0;
            return;
        }
        fluidContainer.variant = FluidVariant.of(BuiltInRegistries.FLUID.byId(fluidId));
        fluidContainer.amount = Math.min(amount, fluidContainer.getCapacity());
        StoragePreconditions.notBlankNotNegative(fluidContainer.variant, fluidContainer.amount);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registryLookup) {
        return saveWithoutMetadata(registryLookup);
    }

    @Override
    public BlockPos getScreenOpeningData(ServerPlayer player) {
        return this.worldPosition;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable(FurnitureStrings.Fluid_Tank);
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int syncId, Inventory playerInventory, Player player) {
        return new FluidTankScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    @Override
    public NonNullList<ItemStack> getItems() {
        return inventory;
    }
}
