package com.skniro.growable_ores_extension.block.entity.machine;

import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import com.skniro.growable_ores_extension.screen.handler.machine.CompressorScreenHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public class CompressorEntity extends AbstractMachineEntity {

    public CompressorEntity(BlockPos pos, BlockState state) {
        super(AlchemyBlockEntityType.Compressor_BLOCK_ENTITY ,pos, state);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable(FurnitureStrings.Compressor);
    }

    public RecipeType<?> getCurrentRecipeType() {
        return AlchemyRecipeType.COMPRESSOR.type;
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int syncId, Inventory playerInventory, Player player) {
        return new CompressorScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }
}
