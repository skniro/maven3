package com.skniro.industrial_elixir.api.renderer.chunk;

import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public class ChunkMapRenderer {

    public static final int GRID_SIZE = 5;

    private static final int CELL_SIZE = 14;
    private static final int CELL_GAP = 2;
    private static final int CELL_STRIDE = CELL_SIZE + CELL_GAP;


    /**
     * 绘制 Chunk 地图
     *
     * @param graphics GUI graphics
     * @param level 当前世界
     * @param center 中心Chunk
     * @param x 左上角
     * @param y 左上角
     * @param selectedMask 已选择chunk
     */
    public void render(
            class_332 graphics,
            class_1937 level,
            class_1923 center,
            int x,
            int y,
            int selectedMask,
            int mouseX,
            int mouseY
    ) {


        for (int i = 0; i < 25; i++) {

            int row = i / GRID_SIZE;
            int col = i % GRID_SIZE;


            int drawX =
                    x + col * CELL_STRIDE;

            int drawY =
                    y + row * CELL_STRIDE;


            class_1923 chunkPos =
                    new class_1923(
                            center.field_9181 + col - 2,
                            center.field_9180 + row - 2
                    );


            /*
             * 绘制Chunk纹理
             */
            class_2960 texture =
                    ChunkTextureCache.getTexture(
                            level,
                            chunkPos
                    );


            graphics.method_25290(
                    texture,
                    drawX,
                    drawY,
                    0,
                    0,
                    CELL_SIZE,
                    CELL_SIZE,
                    16,
                    16
            );



            boolean centerChunk =
                    i == 12;


            boolean selected =
                    centerChunk
                    ||
                    (selectedMask & (1 << i)) != 0;



            /*
             * 已加载覆盖层
             */
            if (selected) {

                int color =
                        centerChunk
                                ?
                                0x6600FF00
                                :
                                0x5500AA00;


                graphics.method_25294(
                        drawX,
                        drawY,
                        drawX + CELL_SIZE,
                        drawY + CELL_SIZE,
                        color
                );
            }



            /*
             * 鼠标边框
             */
            boolean hovered =
                    mouseX >= drawX
                    && mouseX < drawX + CELL_SIZE
                    && mouseY >= drawY
                    && mouseY < drawY + CELL_SIZE;


            int border =
                    hovered
                            ?
                            0xFFFFFFFF
                            :
                            0xFF555555;


            drawBorder(
                    graphics,
                    drawX,
                    drawY,
                    border
            );
        }
    }



    private void drawBorder(
            class_332 graphics,
            int x,
            int y,
            int color
    ) {


        graphics.method_25294(
                x,
                y,
                x + CELL_SIZE,
                y + 1,
                color
        );


        graphics.method_25294(
                x,
                y + CELL_SIZE - 1,
                x + CELL_SIZE,
                y + CELL_SIZE,
                color
        );


        graphics.method_25294(
                x,
                y,
                x + 1,
                y + CELL_SIZE,
                color
        );


        graphics.method_25294(
                x + CELL_SIZE - 1,
                y,
                x + CELL_SIZE,
                y + CELL_SIZE,
                color
        );
    }



    /**
     * 获取鼠标所在Chunk按钮
     *
     * @return 0-24，没有返回-1
     */
    public int getHoveredChunk(
            int mouseX,
            int mouseY,
            int x,
            int y
    ) {


        for (int i = 0; i < 25; i++) {

            int row = i / GRID_SIZE;
            int col = i % GRID_SIZE;


            int cx =
                    x + col * CELL_STRIDE;

            int cy =
                    y + row * CELL_STRIDE;


            if (mouseX >= cx
                    && mouseX < cx + CELL_SIZE
                    && mouseY >= cy
                    && mouseY < cy + CELL_SIZE) {

                return i;
            }
        }


        return -1;
    }
}