package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

public class TVBlock extends class_2237 {
    public MapCodec<TVBlock> CODEC = method_54094(TVBlock::new);
    public static final class_2754<class_2350> FACING;
    private static final class_265 NORTH_SHAPE;
    private static final class_265 SOUTH_SHAPE;
    private static final class_265 EAST_SHAPE;
    private static final class_265 WEST_SHAPE;
    public static final class_2746 LIT;

    public TVBlock(class_2251 settings) {
        super(settings);
        this.method_9590((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043).method_11657(LIT, false)));
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            boolean lit = state.method_11654(LIT);
            world.method_8652(pos, state.method_11657(LIT, !lit), 2);
        }
        return class_1269.field_5812;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2350 direction = state.method_11654(FACING);
        switch (direction){
            case field_11034:
                return EAST_SHAPE;
            case field_11035:
                return SOUTH_SHAPE;
            case field_11039:
                return WEST_SHAPE;
            case field_11043:
            default:
                return NORTH_SHAPE;
        }
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return (class_2680)state.method_11657(FACING, rotation.method_10503((class_2350)state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345((class_2350)state.method_11654(FACING)));
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, LIT);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return null;
    }

    static {
        FACING = class_2741.field_12481;
        LIT = class_2741.field_12548;
        NORTH_SHAPE = class_2248.method_9541(-7.0, 5.0, 11.0, 24.0, 23.0, 14.0);
        SOUTH_SHAPE = class_2248.method_9541(-8.0, 5.0, 2.0, 23.0, 23.0, 5.0);
        EAST_SHAPE = class_2248.method_9541(2.0, 5.0, -7.0, 5.0, 23.0, 24.0);
        WEST_SHAPE = class_2248.method_9541(11.0, 5.0, -8.0, 14.0, 23.0, 23.0);
    }
}
