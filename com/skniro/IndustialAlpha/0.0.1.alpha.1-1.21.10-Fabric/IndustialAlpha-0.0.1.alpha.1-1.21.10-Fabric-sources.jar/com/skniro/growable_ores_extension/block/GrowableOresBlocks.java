package com.skniro.growable_ores_extension.block;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.ModContent;
import com.skniro.growable_ores_extension.block.init.*;
import com.skniro.growable_ores_extension.util.GrowableOresItemGroups;
import techreborn.init.TRContent;

import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class GrowableOresBlocks {
    public static final class_2248 GrowableOres_Block =registerBlock("growableores_block", Alchemyblock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)), GrowableOresItemGroups.Growable_Ores_Group);

    public static final class_2248 GrowableBox_Block =registerBlock("growablebox_block", ShulkerBoxBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)), GrowableOresItemGroups.Growable_Ores_Group);

    public static final class_2248 Macerator_Block =registerBlock("macerator", MaceratorBlock::new, (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)), GrowableOresItemGroups.Growable_Ores_Group);

    public static final class_2248 Cable_Block =registerBlock("copper_cable",(settings)-> new CableBlock(ModContent.Cables.COPPER, "copper"), (class_4970.class_2251.method_9637().method_29292().method_9629(3.0F, 3.0F)), GrowableOresItemGroups.Growable_Ores_Group);

    public static final class_2248 COAL_GENERATOR = registerBlock("coal_generator",
            CoalGeneratorBlock::new, (class_4970.class_2251.method_9637().method_9632(2f).method_29292()), GrowableOresItemGroups.Growable_Ores_Group);

    private static class_2248 registerBlockWithoutItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(GrowableOresExtension.MOD_ID, name), block);
    }

    private static class_2248 registerCableBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings, class_5321<class_1761> tab) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GrowableOresExtension.MOD_ID, name))));
        registerBlockItem(name, block, tab);
        return class_2378.method_39197(class_7923.field_41175, class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)), block);
    }

    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings, class_5321<class_1761> tab) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GrowableOresExtension.MOD_ID, name))));
        registerBlockItem(name, block, tab);
        return class_2378.method_39197(class_7923.field_41175, class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_5321<class_1761> tab) {
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)))));
    }

    public static void registerGrowableOresBlocks() {
        GrowableOresExtension.LOGGER.info("Registering GrowableOres Blocks for " + GrowableOresExtension.MOD_ID);
    }
}
