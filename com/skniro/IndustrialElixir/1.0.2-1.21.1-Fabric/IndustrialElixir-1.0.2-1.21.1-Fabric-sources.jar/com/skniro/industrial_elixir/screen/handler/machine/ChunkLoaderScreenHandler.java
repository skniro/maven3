package com.skniro.industrial_elixir.screen.handler.machine;

import com.skniro.industrial_elixir.block.entity.machine.ChunkLoaderEntity;
import com.skniro.industrial_elixir.screen.AlchemyScreenHandlerType;
import com.skniro.industrial_elixir.screen.slot.BatteryFuelSlot;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3913;
import net.minecraft.class_3919;
import net.minecraft.world.inventory.*;

public class ChunkLoaderScreenHandler extends class_1703 {
    private final class_1263 inventory;
    public final ChunkLoaderEntity blockEntity;
    final class_3913 propertyDelegate;

    public ChunkLoaderScreenHandler(int syncId, class_1661 playerInventory, class_2338 pos) {
        this(syncId, playerInventory, playerInventory.field_7546.method_37908().method_8321(pos), new class_3919(2));
    }

    public ChunkLoaderScreenHandler(int syncId, class_1661 playerInventory, class_2586 entity, class_3913 delegate) {
        super(AlchemyScreenHandlerType.ChunkLoader, syncId);
        blockEntity = (ChunkLoaderEntity) entity;
        method_17359(blockEntity, 12);
        this.propertyDelegate = delegate;
        this.inventory = blockEntity;
        inventory.method_5435(playerInventory.field_7546);
        method_17360(propertyDelegate);
    }

    public int getScaledEnergyHeight() {
        long energy = blockEntity.energyContainer.amount;
        long capacity = blockEntity.energyContainer.getCapacity();
        int energyBarSize = 50;
        return Math.toIntExact(capacity != 0 && energy != 0 ? energy * energyBarSize / capacity : 0);
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (!player.method_37908().method_8608() && id >= 0 && id < 25 && id != 12) {
            blockEntity.toggleChunk(id);
        }
        return true;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int invSlot) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(invSlot);
        if (slot != null && slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();
            if (invSlot < this.inventory.method_5439()) {
                if (!this.method_7616(originalStack, this.inventory.method_5439(), this.field_7761.size(), true)) {
                    return class_1799.field_8037;
                }
            } else if (!this.method_7616(originalStack, 0, this.inventory.method_5439(), false)) {
                return class_1799.field_8037;
            }

            if (originalStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }
        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return this.inventory.method_5443(player);
    }
}
