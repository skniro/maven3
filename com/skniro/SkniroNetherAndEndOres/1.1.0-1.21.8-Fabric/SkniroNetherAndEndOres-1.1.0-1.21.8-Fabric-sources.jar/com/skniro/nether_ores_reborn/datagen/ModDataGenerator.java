package com.skniro.nether_ores_reborn.datagen;

import com.skniro.nether_ores_reborn.world.ModConfiguredFeatures;
import com.skniro.nether_ores_reborn.world.ModPlacedFeatures;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.class_7877;
import net.minecraft.class_7924;

public class ModDataGenerator implements DataGeneratorEntrypoint {
    @Override
    public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {
        FabricDataGenerator.Pack pack = fabricDataGenerator.createPack();
        pack.addProvider(ModWorldGenerator::new);
        pack.addProvider(NetherOresLootTableGenerator::new);
        pack.addProvider(NetherOresModelProvider::new);
        pack.addProvider(NetherOresRecipeProvider::new);
        pack.addProvider(NetherOresEnglishLanguageProvider::new);
        pack.addProvider(NetherOresSimplifiedChineseLanguageProvider::new);
        pack.addProvider(ModBlockTagGeneration::new);
    }

    @Override
    public void buildRegistry(class_7877 registryBuilder) {
        registryBuilder.method_46777(class_7924.field_41239, ModConfiguredFeatures::bootstrap);
        registryBuilder.method_46777(class_7924.field_41245, ModPlacedFeatures::bootstrap);
    }
}
