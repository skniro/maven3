package com.skniro.growable_ores_extension.datagen.recipe.machine;

import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.item.AdvancedItems;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_8790;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class MetalFormerRecipeGenerator extends FabricRecipeProvider {
    public MetalFormerRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {
                // Bronze
                createMetalFormerRolling(GrowableOresItems.BRONZE_INGOT, GrowableOresItems.BRONZE_PLATE).method_10431(field_53721);
                createMetalFormerRolling(GrowableOresItems.BRONZE_PLATE, GrowableOresItems.BRONZE_CASING,2).method_10431(field_53721);

                // Iron
                createMetalFormerRolling(class_1802.field_8620, GrowableOresItems.IRON_PLATE).method_10431(field_53721);
                createMetalFormerRolling(GrowableOresItems.IRON_PLATE, GrowableOresItems.IRON_CASING,2).method_10431(field_53721);

                // Gold
                createMetalFormerRolling(class_1802.field_8695, GrowableOresItems.GOLD_PLATE).method_10431(field_53721);
                createMetalFormerRolling(GrowableOresItems.GOLD_PLATE, GrowableOresItems.GOLD_CASING,2).method_10431(field_53721);

                // Copper
                createMetalFormerRolling(class_1802.field_27022, GrowableOresItems.COPPER_PLATE).method_10431(field_53721);
                createMetalFormerRolling(GrowableOresItems.COPPER_PLATE, GrowableOresItems.COPPER_CASING, 2).method_10431(field_53721);

                // Steel
                createMetalFormerRolling(GrowableOresItems.STEEL_INGOT, GrowableOresItems.STEEL_PLATE).method_10431(field_53721);
                createMetalFormerRolling(GrowableOresItems.STEEL_PLATE, GrowableOresItems.STEEL_CASING,2).method_10431(field_53721);

                // Lead
                createMetalFormerRolling(GrowableOresItems.LEAD_INGOT, GrowableOresItems.LEAD_PLATE).method_10431(field_53721);
                createMetalFormerRolling(GrowableOresItems.LEAD_PLATE, GrowableOresItems.LEAD_CASING,2).method_10431(field_53721);

                // Tin
                createMetalFormerRolling(GrowableOresItems.TIN_INGOT, GrowableOresItems.TIN_PLATE).method_10431(field_53721);
                createMetalFormerRolling(GrowableOresItems.TIN_PLATE, GrowableOresItems.TIN_CASING,2).method_10431(field_53721);

                createMetalFormerRolling(GrowableOresItems.TIN_PLATE, GrowableOresBlocks.TIN_CABLE,3).method_10431(field_53721);
                createMetalFormerRolling(GrowableOresItems.IRON_PLATE, GrowableOresBlocks.HV_CABLE,4).method_10431(field_53721);
                createMetalFormerRolling(GrowableOresItems.GOLD_PLATE, GrowableOresBlocks.GOLD_CABLE,4).method_10431(field_53721);
                createMetalFormerRolling(GrowableOresItems.COPPER_PLATE, GrowableOresBlocks.COPPER_CABLE,2).method_10431(field_53721);

                createMetalFormerExtruding(class_1802.field_27022, GrowableOresBlocks.COPPER_CABLE,3).method_10431(field_53721);
                createMetalFormerExtruding(GrowableOresItems.TIN_INGOT, GrowableOresBlocks.TIN_CABLE,3).method_10431(field_53721);
                createMetalFormerExtruding(class_1802.field_8695, GrowableOresBlocks.GOLD_CABLE,4).method_10431(field_53721);
                createMetalFormerExtruding(class_1802.field_8620, GrowableOresBlocks.HV_CABLE,4).method_10431(field_53721);
                createMetalFormerExtruding(GrowableOresItems.IRIDIUM_PLATE, AdvancedItems.Iridium_INGOT).method_10431(field_53721);
            }
        };
    }

    @Override
    public String method_10321() {
        return "MetalFormer";
    }
}
