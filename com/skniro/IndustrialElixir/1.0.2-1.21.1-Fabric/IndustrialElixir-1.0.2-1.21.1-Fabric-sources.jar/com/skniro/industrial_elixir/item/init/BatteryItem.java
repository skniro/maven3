package com.skniro.industrial_elixir.item.init;

import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.api.item.TieredEnergyItem;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.base.SimpleEnergyItem;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;


public class BatteryItem extends class_1792 implements SimpleEnergyItem, TieredEnergyItem {
    private EnergyTier energyTier;
    private long capacity;

    public BatteryItem(class_1793 settings, EnergyTier energyTier, long capacity) {
        super(settings.method_7889(1).method_7895(100));
        this.energyTier = energyTier;
        this.capacity = capacity;
        EnergyStorage.ITEM.registerForItems((stack, context) -> SimpleEnergyItem.createStorage(context, this.getEnergyCapacity(stack), this.getEnergyMaxInput(stack), this.getEnergyMaxOutput(stack)), this);
    }

    @Override
    public int method_31569(class_1799 stack) {
        return getPowerForDurabilityBar(stack);
    }

    public boolean method_31567(class_1799 stack) {
        return true;
    }

    public int method_31571(class_1799 stack) {
        return getColorForDurabilityBar(stack);
    }

    public long getEnergyCapacity(class_1799 stack) {
        return capacity;
    }

    @Override
    public long getEnergyMaxInput(class_1799 stack) {
        return energyTier.getMaxInput();
    }

    @Override
    public long getEnergyMaxOutput(class_1799 stack) {
        return energyTier.getMaxOutput();
    }

    public static int getPowerForDurabilityBar(class_1799 stack) {
        class_1792 var2 = stack.method_7909();
        if (var2 instanceof BatteryItem energyItem) {
            return Math.round((float)energyItem.getStoredEnergy(stack) * 100.0F / (float)energyItem.getEnergyCapacity(stack) * 13.0F) / 100;
        } else {
            throw new UnsupportedOperationException();
        }
    }

    @Override
    public void setStoredEnergy(class_1799 stack, long newAmount) {
        SimpleEnergyItem.setStoredEnergyUnchecked(stack, newAmount);

        if (stack.method_7909() instanceof BatteryItem battery) {
            battery.syncDamage(stack);
        }
    }

    public void syncDamage(class_1799 stack) {
        int maxDamage = stack.method_7936();
        if (maxDamage <= 0) {
            return;
        }

        float percent = (float) getStoredEnergy(stack) / getEnergyCapacity(stack);
        stack.method_7974(Math.round((1.0F - percent) * maxDamage));
    }

    public static int getColorForDurabilityBar(class_1799 stack) {
        return 16744454;
    }

    @Override
    public EnergyTier getEnergyTier() {
        return energyTier;
    }
}
