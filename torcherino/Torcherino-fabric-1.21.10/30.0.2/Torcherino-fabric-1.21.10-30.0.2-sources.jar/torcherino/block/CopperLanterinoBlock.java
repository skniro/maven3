package torcherino.block;

import com.google.common.collect.BiMap;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3619;
import net.minecraft.class_3749;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_5953;
import net.minecraft.class_5955;
import net.minecraft.class_9904;
import org.jetbrains.annotations.NotNull;
import torcherino.api.TierSupplier;
import torcherino.block.entity.TorcherinoBlockEntity;

public class CopperLanterinoBlock extends class_3749 implements class_2343, TierSupplier {
    private final class_2960 tierID;

    public CopperLanterinoBlock(class_2251 properties, class_2960 tier) {
        super(properties);
        this.tierID = tier;
    }

    private static boolean isEmittingStrongRedstonePower(class_1937 level, class_2338 pos, class_2350 direction) {
        return level.method_8320(pos).method_26203(level, pos, direction) > 0;
    }

    @Override
    public class_2960 getTier() {
        return tierID;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new TorcherinoBlockEntity(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
        return TorcherinoLogic.getTicker(level, state, type);
    }

    @Deprecated
    public class_3619 getPistonPushReaction() {
        return class_3619.field_15975;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_9615(class_2680 newState, class_1937 level, class_2338 pos, class_2680 state, boolean boolean_1) {
        this.method_9612(null, level, pos, null, null, false);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        class_1268 hand = class_1268.field_5808;
        return TorcherinoLogic.useWithoutItem(state, level, pos, player, hand, hit);
    }

    @Override
    protected @NotNull class_1269 method_55765(class_1799 itemStack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {

        class_1799 stack = player.method_5998(hand);
        class_1792 item = stack.method_7909();

        boolean handled = false;

        if (item == class_1802.field_20414) {
            if (!level.method_8608()) {
                BiMap<class_2248, class_2248> waxables = (BiMap<class_2248, class_2248>) class_5953.field_29560.get();
                class_2248 waxed = waxables.get(state.method_26204());
                if (waxed != null) {
                    swapPreserveTorcherinoBE((class_3218) level, pos, state, waxed.method_9564());
                    if (!player.method_31549().field_7477) stack.method_7934(1);
                    level.method_8444(player, 3003, pos, 0);
                    handled = true;
                }
            }
        }


        if (item instanceof class_1743) {
            if (!level.method_8608()) {
                BiMap<class_2248, class_2248> waxOffMap = (BiMap<class_2248, class_2248>) class_5953.field_29561.get();
                class_2248 unwaxed = waxOffMap.get(state.method_26204());
                if (unwaxed != null) {
                    swapPreserveTorcherinoBE((class_3218) level, pos, state, unwaxed.method_9564());
                    stack.method_7956(1, (class_3218) level, null, (p) -> {
                    });
                    level.method_8444(player, 3005, pos, 0);
                    handled = true;
                }

                BiMap<class_2248, class_2248> prevMap = (BiMap<class_2248, class_2248>) class_5955.field_29565.get();
                class_2248 prev = prevMap.get(state.method_26204());
                if (prev != null) {
                    swapPreserveTorcherinoBE((class_3218) level, pos, state, prev.method_9564());
                    stack.method_7956(1, (class_3218) level, null, (p) -> {
                    });
                    level.method_8444(player, 3004, pos, 0);
                    handled = true;
                }
            }
        }

        return handled ? class_1269.field_5812 : super.method_55765(itemStack, state, level, pos, player, hand, hit);
    }

    public static void swapPreserveTorcherinoBE(class_3218 level, class_2338 pos,
                                                class_2680 oldState, class_2680 newState) {
        class_2586 oldBE = level.method_8321(pos);
        TorcherinoBlockEntity.Data data = null;

        if (oldBE instanceof TorcherinoBlockEntity torcherino) {
            data = TorcherinoBlockEntity.Data.from(torcherino);
        }

        level.method_8652(pos, newState, class_2248.field_31036);
        class_2586 newBE = level.method_8321(pos);

        if (data != null && newBE instanceof TorcherinoBlockEntity torcherino) {
            torcherino.restore(data);
            torcherino.method_5431();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 neighborBlock, class_9904 orientation, boolean boolean_1) {
        TorcherinoLogic.neighborUpdate(state, level, pos, neighborBlock, orientation, boolean_1, (be) -> {
            if (state == null) {
                return;
            }
            if (state.method_11654(class_2741.field_16561).equals(true)) {
                be.setPoweredByRedstone(level.method_49807(pos.method_10084(), class_2350.field_11036));
            } else {
                boolean powered = isEmittingStrongRedstonePower(level, pos.method_10067(), class_2350.field_11039) ||
                        isEmittingStrongRedstonePower(level, pos.method_10078(), class_2350.field_11034) ||
                        isEmittingStrongRedstonePower(level, pos.method_10072(), class_2350.field_11035) ||
                        isEmittingStrongRedstonePower(level, pos.method_10095(), class_2350.field_11043);
                be.setPoweredByRedstone(powered);
            }
        });

    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, class_1309 placer, class_1799 stack) {
        TorcherinoLogic.onPlaced(level, pos, state, placer, stack, this);
    }
}
