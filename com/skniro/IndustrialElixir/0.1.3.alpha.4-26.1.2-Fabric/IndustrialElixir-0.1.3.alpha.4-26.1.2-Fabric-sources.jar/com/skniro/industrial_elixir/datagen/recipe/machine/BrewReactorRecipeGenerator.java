package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.industrial_elixir.api.data.recipe.CraftingDataHelper;
import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potions;

import java.util.concurrent.CompletableFuture;

public class BrewReactorRecipeGenerator extends CraftingDataHelper {
    public BrewReactorRecipeGenerator(FabricPackOutput output, CompletableFuture<HolderLookup.Provider> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator createRecipeProvider(HolderLookup.Provider wrapperLookup, RecipeOutput exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void buildRecipes() {
                createBrewReactor(potionTemplate(wrapperLookup, Potions.STRONG_HEALING)).input(Items.IRON_INGOT, 9)
                        .unlockedBy("has_base_item", has(Items.IRON_INGOT)).save(output);
            }
        };
    }

    @Override
    public String getName() {
        return "BrewReactor";
    }
}
