package com.skniro.industrial_elixir.block.entity.cable;

import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import net.minecraft.class_2350;

// CREDIT: https://github.com/techreborn/techreborn
// Under MIT-License: https://github.com/TechReborn/TechReborn/blob/26.1/LICENSE.md
record OfferedEnergyStorage(CableBlockEntity sourceCable, class_2350 direction, EnergyStorage storage) {
    void afterTransfer() {
        sourceCable.blockedSides |= 1 << direction.ordinal();
    }
}