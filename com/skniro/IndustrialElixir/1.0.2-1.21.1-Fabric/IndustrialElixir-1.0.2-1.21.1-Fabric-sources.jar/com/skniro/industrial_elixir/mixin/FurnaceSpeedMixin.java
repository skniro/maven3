package com.skniro.industrial_elixir.mixin;

import com.skniro.industrial_elixir.block.init.machine.IronFurnaceBlock;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2609;
import net.minecraft.class_2680;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2609.class)
public class FurnaceSpeedMixin {

    @Shadow
    int cookingProgress;

    @Inject(method = "serverTick", at = @At(value = "FIELD", target = "Lnet/minecraft/world/level/block/entity/AbstractFurnaceBlockEntity;cookingProgress:I", opcode = Opcodes.PUTFIELD, shift = At.Shift.AFTER))
    private static void icr$boostIronFurnace(
            class_1937 world, class_2338 pos, class_2680 state, class_2609 blockEntity, CallbackInfo ci) {

        if (state.method_26204() instanceof IronFurnaceBlock) {
            if (world.method_8510() % 5 == 0) {
                ((FurnaceSpeedMixin)(Object)blockEntity).cookingProgress++;
            }
        }
    }
}