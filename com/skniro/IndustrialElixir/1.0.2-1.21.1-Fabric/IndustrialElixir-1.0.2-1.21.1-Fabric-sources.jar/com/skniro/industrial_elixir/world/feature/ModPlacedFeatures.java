package com.skniro.industrial_elixir.world.feature;

import com.skniro.industrial_elixir.IndustrialElixir;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5843;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6817;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;

public class ModPlacedFeatures {
    public static final class_5321<class_6796> Deepslate_Lead_Ore_PLACED_KEY = registerKey("deepslate_lead_ore_placed");
    public static final class_5321<class_6796> Deepslate_Tin_Ore_PLACED_KEY = registerKey("deepslate_tin_ore_placed");
    public static final class_5321<class_6796> Deepslate_SACRED_Ore_PLACED_KEY = registerKey("deepslate_sacred_ore_placed");
    public static final class_5321<class_6796> Lead_Ore_PLACED_KEY = registerKey("lead_ore_placed");
    public static final class_5321<class_6796> Tin_Ore_PLACED_KEY = registerKey("tin_ore_placed");
    public static final class_5321<class_6796> SACRED_Ore_PLACED_KEY = registerKey("sacred_ore_placed");
    public static final class_5321<class_6796> PATCH_COFFEE_COMMON = registerKey("patch_coffee_common");
    public static final class_5321<class_6796> PATCH_COFFEE_RARE = registerKey("patch_coffee_rare");

    public static void bootstrap(class_7891<class_6796> context) {
        var configuredFeatureRegistryEntryLookup = context.method_46799(class_7924.field_41239);
        class_6880<class_2975<?, ?>> registryEntry2 = configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.PATCH_COFFEE);

        register(context, Deepslate_Lead_Ore_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Deepslate_Lead_Ore_KEY),
                modifiersWithCount(9, // Veins per Chunk
                        class_6795.method_39637(class_5843.method_33841(-64), class_5843.method_33841(0))));

        register(context,Deepslate_Tin_Ore_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Deepslate_Tin_Ore_KEY),
                modifiersWithCount(12, // Veins per Chunk
                        class_6795.method_39637(class_5843.method_33841(-64), class_5843.method_33841(0))));

        register(context, Deepslate_SACRED_Ore_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Deepslate_SACRED_Ore_KEY),
                modifiersWithCount(7, // Veins per Chunk
                        class_6795.method_39637(class_5843.method_33841(-64), class_5843.method_33841(0))));

        register(context, Lead_Ore_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Lead_Ore_KEY),
                modifiersWithCount(7, // Veins per Chunk
                        class_6795.method_39637(class_5843.method_33841(0), class_5843.method_33841(63))));

        register(context,Tin_Ore_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.Tin_Ore_KEY),
                modifiersWithCount(10, // Veins per Chunk
                        class_6795.method_39637(class_5843.method_33841(0), class_5843.method_33841(40))));

        register(context, SACRED_Ore_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.SACRED_Ore_KEY),
                modifiersWithCount(5, // Veins per Chunk
                        class_6795.method_39637(class_5843.method_33841(0), class_5843.method_33841(64))));

        register(context, PATCH_COFFEE_COMMON, registryEntry2, class_6799.method_39659(64), class_5450.method_39639(), class_6817.field_36080, class_6792.method_39614());
        register(context, PATCH_COFFEE_RARE, registryEntry2, class_6799.method_39659(768), class_5450.method_39639(), class_6817.field_36080, class_6792.method_39614());
    }

    public static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(IndustrialElixir.MOD_ID, name));
    }
    private static void register(class_7891<class_6796> context, class_5321<class_6796> key, class_6880<class_2975<?, ?>> configuration,
                                 List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(configuration, List.copyOf(modifiers)));
    }
    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_6796> context, class_5321<class_6796> key,
                                                                                   class_6880<class_2975<?, ?>> configuration,
                                                                                   class_6797... modifiers) {
        register(context, key, configuration, List.of(modifiers));
    }

    // Used here because the vanilla ones are private
    private static List<class_6797> modifiers(class_6797 countModifier, class_6797 heightModifier) {
        return List.of(countModifier, class_5450.method_39639(), heightModifier, class_6792.method_39614());
    }

    private static List<class_6797> modifiersWithCount(int count, class_6797 heightModifier) {
        return modifiers(class_6793.method_39623(count), heightModifier);
    }

    private static List<class_6797> modifiersWithRarity(int chance, class_6797 heightModifier) {
        return modifiers(class_6799.method_39659(chance), heightModifier);
    }
}
