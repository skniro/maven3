package com.skniro.growable_ores_extension.block.entity.pipe;

import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.block.init.machine.Alchemyblock;
import com.skniro.growable_ores_extension.block.init.pipe.PipeBlock;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;

public class PipeBlockEntity extends BlockEntity implements ItemOwner {

    private final List<PipeItem> items = new ArrayList<>();
    private final EnumSet<Direction> blocked = EnumSet.noneOf(Direction.class);

    public PipeBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    public boolean isBlocked(Direction dir) {
        return blocked.contains(dir);
    }

    public void setBlocked(Direction dir, boolean value) {
        if (value) {
            blocked.add(dir);
        } else {
            blocked.remove(dir);
        }
        setChanged();
    }

    public void tick(Level world, BlockPos pos, BlockState state) {
        updateConnections();
    }

    public List<PipeItem> getItems() {
        return new ArrayList<>(items);
    }

    public void neighborUpdate() {
        updateConnections();
    }

    private void updateConnections() {
        if (level == null || level.isClientSide()) {
            return;
        }

        BlockState state = getBlockState();
        BlockState newState = state;

        for (Direction dir : Direction.values()) {
            boolean connected = isConnectable(dir);
            newState = newState.setValue(PipeBlock.PROPERTY_MAP.get(dir), connected);
        }

        if (newState != state) {
            level.setBlockAndUpdate(worldPosition, newState);
        }
    }

    private boolean isConnectable(Direction dir) {
        if (isBlocked(dir)) return false;
        BlockPos target = worldPosition.relative(dir);
        BlockState neighborState = level.getBlockState(target);
        Block neighborBlock = neighborState.getBlock();

        if (neighborBlock instanceof PipeBlock) {
            return true;
        }

        Storage<ItemVariant> storage =
                ItemStorage.SIDED.find(level, target, dir.getOpposite());

        return storage != null;
    }

    void moveItems(Level world, BlockPos pos, BlockState state) {
        Iterator<PipeItem> it = items.iterator();

        while (it.hasNext()) {
            PipeItem item = it.next();

            if (isBlocked(item.direction)) {
                continue;
            }

            if (item.variant.isBlank() || item.amount <= 0) {
                it.remove();
                continue;
            }

            item.progress += 0.1;

            if (item.progress >= 1.0) {
                BlockPos target = pos.relative(item.direction);

                if (!tryMoveToNext(world, target, item)
                        && !tryInsert(world, target, item)) {

                    item.progress = 1.0;
                    continue;
                }

                it.remove();
            }
        }
    }

    private boolean tryMoveToNext(Level world, BlockPos pos, PipeItem item) {
        BlockEntity be = world.getBlockEntity(pos);

        if (be instanceof PipeBlockEntity pipe) {
            if (isBlocked(item.direction)) {
                return false;
            }
            Direction newDir = getNextDirection(world, pos, item);

            PipeItem newItem = new PipeItem(item.variant, item.amount, newDir);

            newItem.lastDirection = item.direction;

            pipe.items.add(newItem);

            return true;
        }

        return false;
    }

    private Direction getNextDirection(Level world, BlockPos pos, Direction from) {
        List<Direction> possible = new ArrayList<>();

        for (Direction dir : Direction.values()) {
            if (dir == from.getOpposite()) continue;
            if (isBlocked(dir)) {
                continue;
            }
            BlockState state = world.getBlockState(pos);
            if (state.getValue(PipeBlock.PROPERTY_MAP.get(dir))) {
                possible.add(dir);
            }
        }

        if (possible.isEmpty()) return from;

        return possible.get(world.getRandom().nextInt(possible.size()));
    }

    private boolean tryInsert(Level world, BlockPos pos, PipeItem item) {
        if (item.variant.isBlank() || item.amount <= 0) {
            return false;
        }

        if (isBlocked(item.direction)) {
            return false;
        }
        Storage<ItemVariant> storage =
                ItemStorage.SIDED.find(world, pos, item.direction.getOpposite());

        if (storage == null) return false;

        try (Transaction tx = Transaction.openOuter()) {
            long inserted = storage.insert(item.variant, item.amount, tx);

            if (inserted > 0) {
                item.amount -= inserted;

                if (item.amount <= 0) {
                    item.variant = ItemVariant.blank();
                }

                tx.commit();
                return true;
            }
        }

        return false;
    }

    private Direction getNextDirection(Level world, BlockPos pos, PipeItem item) {

        List<Direction> possible = new ArrayList<>();

        for (Direction dir : Direction.values()) {
            if (isBlocked(dir)) {
                continue;
            }
            // ❌ 禁止回头
            if (dir == item.lastDirection.getOpposite()) continue;

            BlockState state = world.getBlockState(pos);
            if (state.getValue(PipeBlock.PROPERTY_MAP.get(dir))) {
                possible.add(dir);
            }
        }

        // ❗ 如果没有路，只能回头（避免卡死）
        if (possible.isEmpty()) {
            return item.lastDirection.getOpposite();
        }

        return possible.get(world.getRandom().nextInt(possible.size()));
    }

    void extractItems(Level world, BlockPos pos, BlockState state) {

        if (!items.isEmpty()) return; // 一次只抽一个（简化）

        for (Direction dir : Direction.values()) {
            if (isBlocked(dir)) {
                continue;
            }
            BlockPos target = pos.relative(dir);

            Storage<ItemVariant> storage =
                    ItemStorage.SIDED.find(world, target, dir.getOpposite());

            if (storage == null) continue;

            try (Transaction tx = Transaction.openOuter()) {
                Iterator<StorageView<ItemVariant>> it = storage.iterator();
                StorageView<ItemVariant> view = null;

                while (it.hasNext()) {
                    StorageView<ItemVariant> next = it.next();
                    if (!next.isResourceBlank()) {
                        view = next;
                        break;
                    }
                }

                if (view == null) continue;

                long extracted = storage.extract(view.getResource(), 1, tx);

                if (extracted > 0) {
                    Direction outDir = dir.getOpposite();
                    items.add(new PipeItem(view.getResource(), extracted, outDir));

                    tx.commit();
                    return;
                }
            }
        }
    }

    @Override
    public Level level() {
        return this.level;
    }

    @Override
    public Vec3 position() {
        return this.getBlockPos().getCenter();
    }

    @Override
    public float getVisualRotationYInDegrees() {
        return 0;
    }


    public class PipeItem {
        public ItemVariant variant;
        public long amount;

        public Direction direction;
        public Direction lastDirection;

        public double progress;

        public PipeItem(ItemVariant variant, long amount, Direction dir) {
            this.variant = variant;
            this.amount = amount;
            this.direction = dir;
            this.lastDirection = dir; // 初始
            this.progress = 0.0;
        }
    }
}
