package com.skniro.industrial_elixir.networking;

import com.skniro.industrial_elixir.networking.packet.BoostJumpC2SPayload;
import com.skniro.industrial_elixir.networking.packet.JetpackInputC2SPayload;
import com.skniro.industrial_elixir.networking.packet.MetalFormerStateC2SPayload;
import com.skniro.industrial_elixir.networking.packet.ToggleHoverC2SPayload;
import com.skniro.industrial_elixir.networking.packet.ToggleNightVisionC2SPayload;
import com.skniro.industrial_elixir.networking.packet.VendorMachineSynPayload;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_9129;

public class ModMessages {
    public static void register() {
        registerS2CPackets(PayloadTypeRegistry.playS2C());
        registerC2SPackets(PayloadTypeRegistry.playC2S());
        NetworkUtilsImpl.getInstance().initialize();
    }

    public static void registerC2SPackets(PayloadTypeRegistry<class_9129> registry) {
        registry.register(MetalFormerStateC2SPayload.TYPE, MetalFormerStateC2SPayload.CODEC);
        registry.register(ToggleNightVisionC2SPayload.TYPE, ToggleNightVisionC2SPayload.CODEC);
        registry.register(BoostJumpC2SPayload.TYPE, BoostJumpC2SPayload.CODEC);
        registry.register(ToggleHoverC2SPayload.TYPE, ToggleHoverC2SPayload.CODEC);
        registry.register(JetpackInputC2SPayload.TYPE, JetpackInputC2SPayload.CODEC);
        //registry.register(VendorMachineSynPayload.TYPE, VendorMachineSynPayload.CODEC);
    }

    public static void registerS2CPackets(PayloadTypeRegistry<class_9129> registry) {
        registry.register(VendorMachineSynPayload.TYPE, VendorMachineSynPayload.CODEC);
    }
}