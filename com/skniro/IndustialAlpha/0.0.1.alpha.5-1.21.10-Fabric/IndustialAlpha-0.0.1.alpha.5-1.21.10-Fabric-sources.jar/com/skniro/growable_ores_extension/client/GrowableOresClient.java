package com.skniro.growable_ores_extension.client;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.block.renderer.AlchemyblockentityRenderer;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.*;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.energybox.ChargePadBlockScreen;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.energybox.EnergyBoxBlockScreen;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.machine.AlchemyBlockScreen;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.machine.CompressorBlockScreen;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.machine.MaceratorBlockScreen;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.machine.MetalFormerBlockScreen;
import com.skniro.growable_ores_extension.entity.MapleEntityType;
import com.skniro.growable_ores_extension.screen.AlchemyScreenHandlerType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_11515;
import net.minecraft.class_2960;
import net.minecraft.class_3929;
import net.minecraft.class_554;
import net.minecraft.class_5601;
import net.minecraft.class_5616;
import net.minecraft.class_881;

@Environment(EnvType.CLIENT)
public class GrowableOresClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_11515 renderLayer2 = class_11515.field_60924;
        BlockRenderLayerMap.putBlock(GeneralBlocks.Rubber_SAPLING, renderLayer2);
        BlockRenderLayerMap.putBlock(GeneralBlocks.Rubber_LEAVES, renderLayer2);

        class_3929.method_17542(AlchemyScreenHandlerType.ALCHEMY, AlchemyBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.COAL_GENERATOR_SCREEN_HANDLER, CoalGeneratorScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.Macerator, MaceratorBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.Compressor, CompressorBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.GENERATOR_Wind_Mill_SCREEN_HANDLER, GeneratorWindMillScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.MetalFormer, MetalFormerBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.ChargePad, ChargePadBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.EnergyBox, EnergyBoxBlockScreen::new);
        class_5616.method_32144(AlchemyBlockEntityType.ALCHEMY_BLOCK_ENTITY, AlchemyblockentityRenderer::new);

        registerClientEntityRenderer();
    }

    @Environment(EnvType.CLIENT)
    public static void registerClientEntityRenderer() {

        var rubber_boat = new class_5601(class_2960.method_60655(GrowableOresExtension.MOD_ID, "boat/rubber"), "main");
        EntityModelLayerRegistry.registerModelLayer(rubber_boat, class_554::method_31985);
        EntityRendererRegistry.register(MapleEntityType.RUBBER_BOAT, (dispatcher) -> new class_881(dispatcher, rubber_boat));

        var rubber_chest_boat = new class_5601(class_2960.method_60655(GrowableOresExtension.MOD_ID, "chest_boat/rubber"), "main");
        EntityModelLayerRegistry.registerModelLayer(rubber_chest_boat, class_554::method_62066);
        EntityRendererRegistry.register(MapleEntityType.RUBBER_CHEST_BOAT, (dispatcher) -> new class_881(dispatcher, rubber_chest_boat));
    }
}