package com.skniro.growable_ores_extension.block.entity.machine;

import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import com.skniro.growable_ores_extension.recipe.AlchemyCraftingRecipeInput;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import com.skniro.growable_ores_extension.recipe.machine.RecyclerCraftingRecipe;
import com.skniro.growable_ores_extension.screen.machine.CompressorScreenHandler;
import com.skniro.growable_ores_extension.screen.machine.ElectricFurnaceScreenHandler;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3861;
import net.minecraft.class_3956;
import net.minecraft.class_8786;
import net.minecraft.class_9696;

public class ElectricFurnaceEntity extends AbstractMachineEntity {
    private static final int INPUT_SLOT = 1;
    private static final int OUTPUT_SLOT = 2;

    public ElectricFurnaceEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.Electric_Furnace_BLOCK_ENTITY ,pos, state);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.ElectricFurnace);
    }

    public class_3956<?> getCurrentRecipeType() {
        return class_3956.field_17546;
    }

    @Override
    protected void craftItem() {
        Optional<class_8786<class_3861>> recipe = getRecipe();
        class_1799 output = recipe.get().comp_1933().method_59998(new class_9696(this.method_5438(INPUT_SLOT)), this.method_10997().method_30349()).method_7972();
        this.method_5434(INPUT_SLOT, 1);
        this.method_5447(OUTPUT_SLOT, new class_1799(output.method_7909(),
                this.method_5438(OUTPUT_SLOT).method_7947() + output.method_7947()));
    }

    protected Optional<class_8786<class_3861>> getRecipe() {
        if (this.method_10997() == null) return Optional.empty();
        class_1799 input = this.method_5438(INPUT_SLOT);
        return this.method_10997().method_8503().method_3772().method_8132(class_3956.field_17546, new class_9696(input), this.method_10997());
    }

    @Override
    public boolean hasRecipe() {
        Optional<class_8786<class_3861>> recipe = getRecipe();
        if(recipe.isEmpty()) {
            return false;
        }
        class_1799 output = recipe.get().comp_1933().method_59998(new class_9696(this.method_5438(INPUT_SLOT)), this.method_10997().method_30349()).method_7972();
        return canInsertAmountIntoOutputSlot(output.method_7947()) && canInsertItemIntoOutputSlot(output) && hasEnoughEnergyToCraft();
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new ElectricFurnaceScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }
}
