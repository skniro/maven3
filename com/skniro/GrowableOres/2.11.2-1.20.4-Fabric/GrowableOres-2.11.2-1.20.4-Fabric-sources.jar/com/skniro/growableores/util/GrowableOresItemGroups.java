package com.skniro.growableores.util;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.*;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class GrowableOresItemGroups {
    public static final class_5321<class_1761> Growable_Ores_Group = class_5321.method_29179(class_7924.field_44688, class_2960.method_43902(GrowableOres.MOD_ID, "test_group"));

    public static void vanilla_item() {
        class_2378.method_39197(class_7923.field_44687, Growable_Ores_Group, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableVanillaOresBlocks.Iron_Cane))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores.test_group"))
                .method_47324()); // build() no longer registers by itself

        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            content.method_45421(GrowableVanillaOresBlocks.Coal_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Iron_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Diamond_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Copper_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Emerald_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Gold_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Lapis_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Nether_Quartz_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Redstone_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Blaze_Rod_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Ender_Pearl_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Netherite_Ingot_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Netherite_Scrap_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Clay_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Glowstone_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Slime_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Bone_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Nether_Star_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Egg_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Wool_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Feather_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Gunpowder_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Leather_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Oak_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Spruce_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Birch_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Jungle_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Acacia_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Dark_Oak_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Mangrove_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Bamboo_Block_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Cherry_Log_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Crimson_Stem_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Warped_Stem_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Amethyst_Shard_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Prismarine_Crystals_Cane);
            content.method_45421(GrowableVanillaOresBlocks.Prismarine_Shard_Cane);

        });
    }
    public static void ae_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //ae2
            content.method_45421(GrowableAEOresBlocks.certus_quartz_crystal_Cane);
            content.method_45421(GrowableAEOresBlocks.fluix_crystal_Cane);
        });
    }

    public static void techreborn_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Tech Reborn
            content.method_45421(GrowableTechRebornOresBlocks.cinnabar_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.galena_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.iridium_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.lead_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.peridot_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.pyrite_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.ruby_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.sapphire_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.sheldonite_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.silver_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.sphalerite_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.tin_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.tungsten_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.sodalite_Cane);
            content.method_45421(GrowableTechRebornOresBlocks.bauxite_Cane);
        });
    }

    public static void betterend_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //BetterEnd
            content.method_45421(GrowableBetterEndOresBlocks.amber_Cane);
            content.method_45421(GrowableBetterEndOresBlocks.ender_Cane);
            content.method_45421(GrowableBetterEndOresBlocks.thallasium_Cane);
        });
    }

    public static void maple_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Maple
            content.method_45421(GrowableMapleOresBlocks.Salt_Cane);
        });
    }
    public static void powah_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Powah Rearchitected and Powah
            content.method_45421(GrowablePowahOresBlocks.Steel_Energized_Cane);
            content.method_45421(GrowablePowahOresBlocks.Uraninite_Ore_Dense_Cane);
            content.method_45421(GrowablePowahOresBlocks.Ender_Core_Cane);
            content.method_45421(GrowablePowahOresBlocks.Crystal_Spirited_Cane);
            content.method_45421(GrowablePowahOresBlocks.Crystal_Nitro_Cane);
            content.method_45421(GrowablePowahOresBlocks.Crystal_Niotic_Cane);
            content.method_45421(GrowablePowahOresBlocks.Crystal_Blazing_Cane);
        });
    }

    public static void ir_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Industrial Revolution
            content.method_45421(GrowableIndustrialRevolutionOresBlocks.IR_Lead_Cane);
            content.method_45421(GrowableIndustrialRevolutionOresBlocks.IR_nikolite_Cane );
            content.method_45421(GrowableIndustrialRevolutionOresBlocks.IR_silver_Cane);
            content.method_45421(GrowableIndustrialRevolutionOresBlocks.IR_tin_ore_Cane);
            content.method_45421(GrowableIndustrialRevolutionOresBlocks.IR_tungsten_Cane);
        });
    }
    public static void mi_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
    //Modern Industrialization
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_antimony_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_bauxite_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_iridium_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_lead_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_lignite_coal_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_monazite_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_nickel_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_platinum_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_quartz_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_salt_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_tin_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_titanium_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_tungsten_Cane);
            content.method_45421(GrowableModernIndustrializationOresBlocks.MI_uranium_Cane);
        });
    }
    public static void ic_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //ic2 and ic2c
            content.method_45421(GrowableICOresBlocks.IC2_Aluminium_Cane);
            content.method_45421(GrowableICOresBlocks.IC2_silver_Cane);
            content.method_45421(GrowableICOresBlocks.IC2_Tin_Cane);
            content.method_45421(GrowableICOresBlocks.IC2_Uranium_Cane);
        });
    }
    public static void ad_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Ad Astra!
            content.method_45421(GrowableAdAstraOresBlocks.AD_Ostrum_Cane);
            content.method_45421(GrowableAdAstraOresBlocks.AD_Ice_Shard_Cane);
            content.method_45421(GrowableAdAstraOresBlocks.AD_Cheese_Cane);
            content.method_45421(GrowableAdAstraOresBlocks.AD_Desh_Cane);
            content.method_45421(GrowableAdAstraOresBlocks.AD_Calorite_Cane);
        });
    }
    public static void c_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Create
            content.method_45421(GrowableCreateOresBlocks.C_Andesite_Alloy_Cane);
            content.method_45421(GrowableCreateOresBlocks.C_Brass_Ingot_Cane);
            content.method_45421(GrowableCreateOresBlocks.C_Polished_Rose_Quartz_Cane);
            content.method_45421(GrowableCreateOresBlocks.C_Zinc_Cane);
        });
    }
    public static void tf_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Thermal Series
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Apatite_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Cinnabar_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Copper_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Lead_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Nickel_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Niter_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Ruby_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Sapphire_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Silver_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Sulfur_Cane);
            content.method_45421(GrowableThermalSeriesOresBlocks.TF_Tin_Cane);
        });
    }


    public static void mek_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //Mekanism
            content.method_45421(GrowableMekanismOresBlocks.MEK_Fluorite_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Lead_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Osmium_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Tin_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Uranium_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Steel_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Refined_Obsidian_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Refined_Glowstone_Cane);
            content.method_45421(GrowableMekanismOresBlocks.MEK_Bronze_Cane);
        });
    }

    public static void bn_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //BetterNether
            content.method_45421(GrowableBetterNetherOresBlocks.BN_Cincinnasite_Cane);
            content.method_45421(GrowableBetterNetherOresBlocks.BN_Nether_Ruby_Cane);
        });
    }

    public static void ep_item() {
        ItemGroupEvents.modifyEntriesEvent(Growable_Ores_Group).register(content -> {
            //EnergizedPower
            content.method_45421(GrowableEnergizedPowerOresBlocks.EP_Advanced_Alloy_Cane);
            content.method_45421(GrowableEnergizedPowerOresBlocks.EP_Energized_Copper_Cane);
            content.method_45421(GrowableEnergizedPowerOresBlocks.EP_Energized_Gold_Cane);
            content.method_45421(GrowableEnergizedPowerOresBlocks.EP_Redstone_Alloy_Cane);
            content.method_45421(GrowableEnergizedPowerOresBlocks.EP_Steel_Cane);
            content.method_45421(GrowableEnergizedPowerOresBlocks.EP_Tin_Cane);
        });
    }
}
