package com.skniro.industrial_elixir.client;

import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.renderer.AlchemyblockentityRenderer;
import com.skniro.industrial_elixir.block.renderer.container.fluid.FluidTankRenderer;
import com.skniro.industrial_elixir.block.renderer.pipe.FluidPipeRenderer;
import com.skniro.industrial_elixir.block.renderer.pipe.WoodenPipeRenderer;
import com.skniro.industrial_elixir.client.particle.MapleCampfireSmokeParticle;
import com.skniro.industrial_elixir.client.particle.MapleParticleTypes;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluids;
import com.skniro.industrial_elixir.keybind.ModClientEvents;
import com.skniro.industrial_elixir.keybind.ModKeyMappings;
import com.skniro.industrial_elixir.screen.ingame.energybox.ChargePadBlockScreen;
import com.skniro.industrial_elixir.screen.ingame.energybox.EnergyBoxBlockScreen;
import com.skniro.industrial_elixir.screen.ingame.generator.heat.ElectricHeaterBlockScreen;
import com.skniro.industrial_elixir.screen.ingame.generator.heat.SolidFuelHeaterScreen;
import com.skniro.industrial_elixir.screen.ingame.machine.*;
import com.skniro.industrial_elixir.screen.ingame.machine.fluid.BrewReactorScreen;
import com.skniro.industrial_elixir.screen.ingame.machine.fluid.CoffeeMachineScreen;
import com.skniro.industrial_elixir.screen.ingame.machine.fluid.MatterGeneratorScreen;
import com.skniro.industrial_elixir.screen.ingame.machine.fluid.OreWashingScreen;
import com.skniro.industrial_elixir.screen.ingame.machine.fluid.ReplicatorScreen;
import com.skniro.industrial_elixir.screen.ingame.container.fluid.FluidTankScreen;
import com.skniro.industrial_elixir.screen.ingame.generator.CoalGeneratorScreen;
import com.skniro.industrial_elixir.screen.ingame.generator.fluid.FluidGeneratorScreen;
import com.skniro.industrial_elixir.screen.ingame.generator.GeneratorSolarPanelScreen;
import com.skniro.industrial_elixir.screen.ingame.generator.GeneratorWindMillScreen;
import com.skniro.industrial_elixir.screen.ingame.generator.NuclearReactorScreen;
import com.skniro.industrial_elixir.screen.ingame.generator.SacredGeneratorScreen;
import com.skniro.industrial_elixir.screen.AlchemyScreenHandlerType;
import com.skniro.growableoresir.client.GrowableOresClienttwo;
import com.skniro.industrial_elixir.screen.ingame.machine.heat.ModBlastFurnaceScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3929;
import net.minecraft.class_5616;
import net.minecraft.class_9779;

@Environment(EnvType.CLIENT)
public class IndustrialElixirOresClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModKeyMappings.registerKeys();
        ClientTickEvents.END_CLIENT_TICK.register(ModClientEvents::onEndTick);

        class_1921 renderLayer2 = class_1921.method_23581();
        BlockRenderLayerMap.INSTANCE.putBlock(GeneralBlocks.Rubber_SAPLING, renderLayer2);
        BlockRenderLayerMap.INSTANCE.putBlock(GeneralBlocks.Rubber_LEAVES, renderLayer2);
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableOresBlocks.GLASSFIBER_CABLE, renderLayer2);
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableOresBlocks.Pipe_Stone_Item_Block, renderLayer2);
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableOresBlocks.Pipe_Wooden_Iten_Block, renderLayer2);
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableOresBlocks.Pipe_Stone_Fluid_Block, renderLayer2);
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableOresBlocks.Pipe_Wooden_Fluid_Block, renderLayer2);
        BlockRenderLayerMap.INSTANCE.putBlock(GeneralBlocks.Reinforced_Glass, renderLayer2);
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableOresBlocks.VENDOR_MACHINE_Block, renderLayer2);

        class_1921 renderLayer3 = class_1921.method_23583();
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableOresBlocks.FLUID_TANK_BLOCK, renderLayer3);
        BlockRenderLayerMap.INSTANCE.putFluid(IndustrialElixirFluids.FLOWING_Hot_Spring, renderLayer3);
        BlockRenderLayerMap.INSTANCE.putFluid(IndustrialElixirFluids.STILL_Hot_Spring, renderLayer3);
        BlockRenderLayerMap.INSTANCE.putFluid(IndustrialElixirFluids.FLOWING_Fluid_AIR, renderLayer3);
        BlockRenderLayerMap.INSTANCE.putFluid(IndustrialElixirFluids.STILL_Fluid_AIR, renderLayer3);
        BlockRenderLayerMap.INSTANCE.putFluid(IndustrialElixirFluids.FLOWING_Fluid_UU, renderLayer3);
        BlockRenderLayerMap.INSTANCE.putFluid(IndustrialElixirFluids.STILL_Fluid_UU, renderLayer3);


        class_3929.method_17542(AlchemyScreenHandlerType.ALCHEMY, AlchemyBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.COAL_GENERATOR_SCREEN_HANDLER, CoalGeneratorScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.NuclearReactor, NuclearReactorScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.SACRED_GENERATOR, SacredGeneratorScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.Macerator, MaceratorBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.Compressor, CompressorBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.GENERATOR_Wind_Mill_SCREEN_HANDLER, GeneratorWindMillScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.GENERATOR_Solar_Panel_SCREEN_HANDLER, GeneratorSolarPanelScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.MetalFormer, MetalFormerBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.ChargePad, ChargePadBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.EnergyBox, EnergyBoxBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.MolecularTransformer, MolecularTransformerBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.Extractor, ExtractorBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.ElectricFurnace, ElectricFurnaceBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.InductionFurnace, InductionFurnaceBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.Cutting, CuttingBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.Recycler, RecyclerBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.BrewReactor, BrewReactorScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.OreWashing, OreWashingScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.FluidTank, FluidTankScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.ElectricHeater, ElectricHeaterBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.SolidFuelHeater, SolidFuelHeaterScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.ModBlastFurnace, ModBlastFurnaceScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.HeatCentrifuge, HeatCentrifugeBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.MatterGenerator, MatterGeneratorScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.PatternStorage, PatternStorageScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.Replicator, ReplicatorScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.FluidGenerator, FluidGeneratorScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.ChunkLoader, ChunkLoaderScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.CoffeeMachine, CoffeeMachineScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.CropFarm, CropFarmBlockScreen::new);
        class_3929.method_17542(AlchemyScreenHandlerType.VendorMachine, VendorMachineScreen::new);

        class_5616.method_32144(AlchemyBlockEntityType.ALCHEMY_BLOCK_ENTITY, AlchemyblockentityRenderer::new);
        class_5616.method_32144(AlchemyBlockEntityType.FLUID_TANK_BLOCK_ENTITY, FluidTankRenderer::new);

        HudRenderCallback.EVENT.register(this::renderHud);

        GrowableOresClienttwo.register();

        FluidRenderHandlerRegistry.INSTANCE.register(IndustrialElixirFluids.STILL_Hot_Spring, IndustrialElixirFluids.FLOWING_Hot_Spring,
                new SimpleFluidRenderHandler(
                        class_2960.method_60654("industrial_elixir:block/spring_still"),
                        class_2960.method_60654("industrial_elixir:block/spring_flow"),
                        0xEDDBDBDB
                ));

        final SimpleFluidRenderHandler Fluid_UU_MODEL = new SimpleFluidRenderHandler(
                SimpleFluidRenderHandler.WATER_STILL,
                SimpleFluidRenderHandler.WATER_FLOWING,
                SimpleFluidRenderHandler.WATER_OVERLAY,
                0xA1BFBFBF);

        final SimpleFluidRenderHandler Fluid_AIR_MODEL = new SimpleFluidRenderHandler(
                SimpleFluidRenderHandler.WATER_STILL,
                SimpleFluidRenderHandler.WATER_FLOWING,
                SimpleFluidRenderHandler.WATER_OVERLAY,
                0xA1C64CEB);


        ParticleFactoryRegistry.getInstance().register(MapleParticleTypes.HOT_SPRING, MapleCampfireSmokeParticle.CosySmokeFactory::new);

        FluidRenderHandlerRegistry.INSTANCE.register(IndustrialElixirFluids.STILL_Fluid_UU, IndustrialElixirFluids.FLOWING_Fluid_UU, Fluid_UU_MODEL);
        FluidRenderHandlerRegistry.INSTANCE.register(IndustrialElixirFluids.STILL_Fluid_AIR, IndustrialElixirFluids.FLOWING_Fluid_AIR, Fluid_AIR_MODEL);
    }

    private void renderHud(class_332 context, class_9779 tickCounter) {
        //WindowsWatermarkRenderer.render(context);
    }
}
