package com.skniro.growable_ores_extension.datagen;

import com.skniro.growable_ores_extension.api.data.model.MapleItemModelDatagenHelper;
import com.skniro.growable_ores_extension.api.data.model.MapleModelDatagenHelper;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.MapleSignBlocks;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.item.AdvancedItems;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.item.MapleArmorItems;
import com.skniro.growable_ores_extension.item.init.equipment.MapleEquipmentAssetKeys;
import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;
import net.minecraft.client.data.*;

public class GrowableModelProvider extends FabricModelProvider {
    public GrowableModelProvider(FabricDataOutput dataGenerator){
        super(dataGenerator);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        blockStateModelGenerator.method_25650(GeneralBlocks.Deepslate_Lead_Ore);
        blockStateModelGenerator.method_25650(GeneralBlocks.Deepslate_Tin_Ore);
        blockStateModelGenerator.method_25650(GeneralBlocks.Deepslate_Uranium_Ore);
        blockStateModelGenerator.method_25650(GeneralBlocks.Lead_Ore);
        blockStateModelGenerator.method_25650(GeneralBlocks.Tin_Ore);
        blockStateModelGenerator.method_25650(GeneralBlocks.Uranium_Ore);
        blockStateModelGenerator.method_25650(GeneralBlocks.Raw_Lead_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Raw_Tin_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Raw_Uranium_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Lead_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Tin_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Uranium_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Sliver_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Bronze_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Steel_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Machine);
        blockStateModelGenerator.method_25650(GeneralBlocks.Advanced_Machine);

        class_4910.class_4912 MaplePool = blockStateModelGenerator.method_25650(GeneralBlocks.Rubber_PLANKS);

        MaplePool.method_25725(GeneralBlocks.Rubber_STAIRS);
        MaplePool.method_25724(GeneralBlocks.Rubber_SLAB);
        MaplePool.method_25716(GeneralBlocks.Rubber_BUTTON);
        MaplePool.method_25723(GeneralBlocks.Rubber_PRESSURE_PLATE);
        MaplePool.method_25721(GeneralBlocks.Rubber_FENCE);
        MaplePool.method_25722(GeneralBlocks.Rubber_FENCE_GATE);

        blockStateModelGenerator.method_25676(GeneralBlocks.Rubber_LOG).method_25730(GeneralBlocks.Rubber_LOG).method_25728(GeneralBlocks.Rubber_WOOD);
        blockStateModelGenerator.method_25676(GeneralBlocks.STRIPPED_Rubber_LOG).method_25730(GeneralBlocks.STRIPPED_Rubber_LOG).method_25728(GeneralBlocks.STRIPPED_Rubber_WOOD);

        blockStateModelGenerator.method_25658(GeneralBlocks.Rubber_DOOR);
        blockStateModelGenerator.method_25671(GeneralBlocks.Rubber_TRAPDOOR);
        blockStateModelGenerator.method_65407(GeneralBlocks.Rubber_SAPLING, GeneralBlocks.POTTED_Rubber_SAPLING, class_4910.class_4913.field_22840);
        blockStateModelGenerator.method_25641(GeneralBlocks.Rubber_LEAVES);
        blockStateModelGenerator.method_72719(GeneralBlocks.Rubber_SHELF, GeneralBlocks.STRIPPED_Rubber_WOOD);

        MapleModelDatagenHelper mapleModelDatagenHelper = new MapleModelDatagenHelper(blockStateModelGenerator);

        mapleModelDatagenHelper.registerModLogs(GeneralBlocks.Rubber_Rubber_LOG);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.COAL_GENERATOR, true);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.Macerator_Block, true);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.Compressor_Block, true);
        mapleModelDatagenHelper.registerMachineSameNorthSouth(GrowableOresBlocks.GENERATOR_Wind_Mill, false);
        mapleModelDatagenHelper.registerMachineDiffBottom(GrowableOresBlocks.MetalFormerBlock, true);
        mapleModelDatagenHelper.registerMachineDiffBottomBack(GrowableOresBlocks.EnergyBox, false);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.CESU, false);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.MFE, false);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.MFSU, false);
        mapleModelDatagenHelper.registerMachineDiffBottomBack(GrowableOresBlocks.ChargePad, true);
        mapleModelDatagenHelper.registerMachineDiffBottomBack(GrowableOresBlocks.CESU_CHARGE_PAD, false);
        mapleModelDatagenHelper.registerMachineDiffBottomBack(GrowableOresBlocks.MFE_CHARGE_PAD, false);
        mapleModelDatagenHelper.registerMachineDiffBottomBack(GrowableOresBlocks.MFSU_CHARGE_PAD, false);

        mapleModelDatagenHelper.registerMachineSameSide(GrowableOresBlocks.GENERATOR_SolarPanel);
        mapleModelDatagenHelper.registerMachineSameSide(GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL);
        mapleModelDatagenHelper.registerMachineSameSide(GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL);
        mapleModelDatagenHelper.registerMachineSameSide(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL);
        mapleModelDatagenHelper.registerMachineSameSide(GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL);

        mapleModelDatagenHelper.registerMachineExtractor(GrowableOresBlocks.Extractor_Block, true);

    }
    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        itemModelGenerator.method_65442(GrowableOresItems.Rubber, class_4943.field_22938);
        //Sign
        itemModelGenerator.method_65442(class_1792.method_7867(MapleSignBlocks.Rubber_SIGN), class_4943.field_22938);
        itemModelGenerator.method_65442(class_1792.method_7867(MapleSignBlocks.Rubber_HANGING_SIGN), class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.RUBBER_BOAT, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.RUBBER_CHEST_BOAT, class_4943.field_22938);

        itemModelGenerator.method_65442(GrowableOresItems.ENERGY_STORAGE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.OVERCLOCKER, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.TRANSFORMER, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.REDSTONE_INVERTER, class_4943.field_22938);

        itemModelGenerator.method_65442(GrowableOresItems.Raw_Lead, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.Raw_Tin, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.Raw_Uranium, class_4943.field_22938);

        itemModelGenerator.method_65442(GrowableOresItems.CRUSHED_COPPER, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.CRUSHED_GOLD, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.CRUSHED_IRON, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.CRUSHED_LEAD, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.CRUSHED_SILVER, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.CRUSHED_TIN, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.CRUSHED_URANIUM, class_4943.field_22938);

        itemModelGenerator.method_65442(GrowableOresItems.PURIFIED_COPPER, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.PURIFIED_GOLD, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.PURIFIED_IRON, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.PURIFIED_LEAD, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.PURIFIED_SILVER, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.PURIFIED_TIN, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.PURIFIED_URANIUM, class_4943.field_22938);

        itemModelGenerator.method_65442(GrowableOresItems.BRONZE_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.CLAY_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.COAL_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.COAL_FUEL_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.COPPER_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.DIAMOND_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.ENERGIUM_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.GOLD_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.IRON_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.LAPIS_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.LEAD_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.LITHIUM_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.OBSIDIAN_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SILICON_DIOXIDE_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SILVER_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.STONE_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SULFUR_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.TIN_DUST, class_4943.field_22938);

        itemModelGenerator.method_65442(GrowableOresItems.SMALL_BRONZE_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SMALL_COPPER_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SMALL_GOLD_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SMALL_IRON_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SMALL_LAPIS_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SMALL_LEAD_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SMALL_LITHIUM_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SMALL_OBSIDIAN_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SMALL_SILVER_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SMALL_SULFUR_DUST, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SMALL_TIN_DUST, class_4943.field_22938);

        itemModelGenerator.method_65442(GrowableOresItems.BRONZE_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.LEAD_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.SILVER_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.STEEL_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.TIN_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.REFINED_IRON_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.URANIUM_INGOT, class_4943.field_22938);

        itemModelGenerator.method_65442(GrowableOresItems.BRONZE_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.COPPER_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.GOLD_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.IRON_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.LAPIS_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.LEAD_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.OBSIDIAN_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.STEEL_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.TIN_PLATE, class_4943.field_22938);

        itemModelGenerator.method_65442(GrowableOresItems.DENSE_BRONZE_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.DENSE_COPPER_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.DENSE_GOLD_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.DENSE_IRON_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.DENSE_LAPIS_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.DENSE_LEAD_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.DENSE_OBSIDIAN_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.DENSE_STEEL_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.DENSE_TIN_PLATE, class_4943.field_22938);

        itemModelGenerator.method_65442(GrowableOresItems.BRONZE_CASING, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.COPPER_CASING, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.GOLD_CASING, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.IRON_CASING, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.LEAD_CASING, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.STEEL_CASING, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.TIN_CASING, class_4943.field_22938);

        itemModelGenerator.method_65429(MapleArmorItems.Quantum_HELMET, MapleEquipmentAssetKeys.QUANTUM, class_2960.method_60654("helmet"), false);
        itemModelGenerator.method_65429(MapleArmorItems.Quantum_CHESTPLATE, MapleEquipmentAssetKeys.QUANTUM,class_2960.method_60654("chestplate"), false);
        itemModelGenerator.method_65429(MapleArmorItems.Quantum_LEGGINGS, MapleEquipmentAssetKeys.QUANTUM,class_2960.method_60654("leggings"), false);
        itemModelGenerator.method_65429(MapleArmorItems.Quantum_BOOTS, MapleEquipmentAssetKeys.QUANTUM,class_2960.method_60654("boots"), false);

        itemModelGenerator.method_65442(AdvancedItems.IRRADIANT_URANIUM_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(AdvancedItems.IRRADIANT_GLASS_PANE, class_4943.field_22938);
        itemModelGenerator.method_65442(AdvancedItems.SUNNARIUM, class_4943.field_22938);
        itemModelGenerator.method_65442(AdvancedItems.ENRICHED_SUNNARIUM, class_4943.field_22938);
        itemModelGenerator.method_65442(AdvancedItems.SUNNARIUM_ALLOY, class_4943.field_22938);
        itemModelGenerator.method_65442(AdvancedItems.ENRICHED_SUNNARIUM_ALLOY, class_4943.field_22938);
        itemModelGenerator.method_65442(AdvancedItems.IRIDIUM_IRON_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(AdvancedItems.REINFORCED_IRIDIUM_IRON_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(AdvancedItems.IRRADIANT_REINFORCED_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(AdvancedItems.SUNNARIUM_Part, class_4943.field_22938);
        itemModelGenerator.method_65442(AdvancedItems.Iridium_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(AdvancedItems.Quantum_Core, class_4943.field_22938);
        itemModelGenerator.method_65442(AdvancedItems.MT_Core, class_4943.field_22938);

        itemModelGenerator.method_65442(GrowableOresItems.CARBON_FIBRE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.CARBON_MESH, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.CARBON_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.COAL_BALL, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.COAL_BLOCK, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.COAL_CHUNK, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.INDUSTRIAL_DIAMOND, class_4943.field_22938);

        itemModelGenerator.method_65442(GrowableOresItems.IRIDIUM_SHARD, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.IRIDIUM_ORE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.ALLOY_INGOT, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.ALLOY_PLATE, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.Sticky_Resin, class_4943.field_22938);
        itemModelGenerator.method_65442(GrowableOresItems.IRIDIUM_PLATE, class_4943.field_22938);

        itemModelGenerator.method_65442(MapleArmorItems.CUTTING, class_4943.field_22938);
        itemModelGenerator.method_65442(MapleArmorItems.ROLLING, class_4943.field_22938);

        MapleItemModelDatagenHelper mapleItemModelDatagenHelper = new MapleItemModelDatagenHelper(itemModelGenerator);
        mapleItemModelDatagenHelper.registerDurabilityItem(GrowableOresItems.RE_BATTERY);
        mapleItemModelDatagenHelper.registerDurabilityItem(GrowableOresItems.ADVANCED_RE_BATTERY);
        mapleItemModelDatagenHelper.registerDurabilityItem(GrowableOresItems.ENERGY_CRYSTAL);
        mapleItemModelDatagenHelper.registerDurabilityItem(GrowableOresItems.LAPOTRON_CRYSTAL);

    }
}
