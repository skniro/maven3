package com.skniro.industrial_elixir.item.init;

import com.google.common.collect.ImmutableMultimap;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.api.item.TieredEnergyItem;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.base.SimpleEnergyItem;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_9300;
import net.minecraft.class_9334;

public class QuantumSuitItem extends class_1738 implements SimpleEnergyItem, TieredEnergyItem {

    public static final long CAPACITY = 10_000_000;

    // Energy costs
    private static final long AIR_REFILL_COST = 1_000;
    private static final long HUNGER_REFILL_COST = 10_000;
    private static final long POISON_REMOVE_COST = 10_000;
    private static final long WITHER_REMOVE_COST = 25_000;
    private static final long NIGHT_VISION_COST = 25_000;
    private static final long BOOST_JUMP_COST = 1_000;
    private static final double BOOST_JUMP_VELOCITY = 1.6;

    private static final int AIR_REFILL_THRESHOLD = 180; // 6 bubbles
    private static final int HUNGER_REFILL_THRESHOLD = 14; // 7 shanks
    private static final int HUNGER_REFILL_AMOUNT = 3;

    // Sprint speed modifier ID for Quantum Leggings
    private static final class_2960 LEGGINGS_SPRINT_SPEED_ID = class_2960.method_60655(IndustrialElixir.MOD_ID, "leggings_sprint_speed");

    // Damage absorption
    private static final long DAMAGE_BASE_COST = 900;
    private static final long DAMAGE_PER_POINT_COST = 30;
    private static final int MAX_ABSORBABLE_DAMAGE = 1333;
    private static final float[] DAMAGE_REDUCTION = {0.15f, 0.44f, 0.30f, 0.15f}; // Helmet, Chestplate, Leggings, Boots

    // Re-entrancy guard for damage absorption
    private static final Set<UUID> absorbingDamage = ConcurrentHashMap.newKeySet();

    // Night vision toggle state per player UUID (server-only)
    private static final Map<UUID, Boolean> nightVisionToggled = new ConcurrentHashMap<>();
    private static final Map<UUID, Boolean> nightVisionPaid = new ConcurrentHashMap<>();

    private class_1738.class_8051 slotType;
    private EnergyTier energyTier;

    private final ImmutableMultimap<class_6880<net.minecraft.class_1320>, class_1322> noPowerAttributes;
    private final ImmutableMultimap<class_6880<net.minecraft.class_1320>, class_1322> hasPowerAttributes;
    private final ImmutableMultimap<class_6880<net.minecraft.class_1320>, class_1322> fullSuitAttributes;

    public QuantumSuitItem(class_1793 settings, class_6880<class_1741> material, class_1738.class_8051 slotType, EnergyTier energyTier) {
        super(material, slotType, settings.method_7889(1).method_57349(class_9334.field_49630, new class_9300(false)));
        this.energyTier = energyTier;
        this.slotType = slotType;
        switch (slotType) {
            case field_41934, field_41937 -> {
                noPowerAttributes = createAttrs(0, 0, 0, 0);
                hasPowerAttributes = createAttrs(3, 3, 0.05, 0);
                fullSuitAttributes = createAttrs(5, 5, 0.1, 0);
            }
            case field_41935 -> {
                noPowerAttributes = createAttrs(0, 0, 0, 0);
                hasPowerAttributes = createAttrs(6, 3, 0.1, 0);
                fullSuitAttributes = createAttrs(10, 5, 0.15, 0);
            }
            case field_41936 -> {
                noPowerAttributes = createAttrs(0, 0, 0, 0);
                hasPowerAttributes = createAttrs(8, 3, 0.05, 0.15);
                fullSuitAttributes = createAttrs(10, 5, 0.1, 0.15);
            }
            default -> throw new IllegalArgumentException("Invalid slot type");
        }

        EnergyStorage.ITEM.registerForItems((stack, context) -> SimpleEnergyItem.createStorage(context, this.getEnergyCapacity(stack), this.getEnergyMaxInput(stack), this.getEnergyMaxOutput(stack)), this);
    }

    private static ImmutableMultimap<class_6880<net.minecraft.class_1320>, class_1322> createAttrs(
            double armor, double toughness, double knockback, double speed
    ) {
        ImmutableMultimap.Builder<class_6880<net.minecraft.class_1320>, class_1322> builder = ImmutableMultimap.builder();
        if (armor > 0) {
            builder.put(class_5134.field_23724,
                    new class_1322(class_2960.method_60655(IndustrialElixir.MOD_ID, "armor"), armor, class_1322.class_1323.field_6328));
        }
        if (toughness > 0) {
            builder.put(class_5134.field_23725,
                    new class_1322(class_2960.method_60655(IndustrialElixir.MOD_ID, "toughness"), toughness, class_1322.class_1323.field_6328));
        }
        if (knockback > 0) {
            builder.put(class_5134.field_23718,
                    new class_1322(class_2960.method_60655(IndustrialElixir.MOD_ID, "knockback"), knockback, class_1322.class_1323.field_6328));
        }
        if (speed > 0) {
            builder.put(class_5134.field_23719,
                    new class_1322(class_2960.method_60655(IndustrialElixir.MOD_ID, "speed"), speed, class_1322.class_1323.field_6328));
        }
        return builder.build();
    }

    @Override
    public long getEnergyCapacity(class_1799 stack) { return CAPACITY; }

    @Override
    public long getEnergyMaxInput(class_1799 stack) { return energyTier.getMaxInput(); }

    @Override
    public long getEnergyMaxOutput(class_1799 stack) { return 0; }

    @Override
    public int method_31569(class_1799 stack) { return getPowerForDurabilityBar(stack); }

    public boolean method_31567(class_1799 stack) { return true; }

    public static int getPowerForDurabilityBar(class_1799 stack) {
        class_1792 var2 = stack.method_7909();
        if (var2 instanceof QuantumSuitItem energyItem) {
            return Math.round((float) energyItem.getStoredEnergy(stack) * 100.0F / (float) energyItem.getEnergyCapacity(stack) * 13.0F) / 100;
        } else {
            throw new UnsupportedOperationException();
        }
    }

    public static int getColorForDurabilityBar(class_1799 stack) { return 16744454; }

    @Override
    public int method_31571(class_1799 stack) { return 0x00FFFF; }

    // ===============================================
    // Toggle API (called from network packet handler)
    // ===============================================

    public static void toggleNightVision(UUID playerId) {
        boolean wasOn = nightVisionToggled.getOrDefault(playerId, false);
        if (wasOn) {
            nightVisionToggled.remove(playerId);
            nightVisionPaid.remove(playerId);
        } else {
            nightVisionToggled.put(playerId, true);
            // Energy will be charged on next tick in handleNightVision
        }
    }

    public static boolean isNightVisionToggled(UUID playerId) {
        return nightVisionToggled.getOrDefault(playerId, false);
    }

    // ===============================================
    // Main tick logic
    // ===============================================

    @Override
    public void method_7888(class_1799 stack, class_1937 level, class_1297 entity, int slotId, boolean selected) {
        if (!(entity instanceof class_1657 player)) return;
        // 26.1 handed inventoryTick a ServerLevel, so the ability logic only ran server-side.
        if (level.method_8608()) return;
        // 26.1 hands the equipment slot straight to inventoryTick; 1.21.1 only passes an inventory
        // index, so resolve the slot the piece is worn in and skip anything merely carried around.
        class_1304 slot = player.method_32326(stack);
        if (player.method_6118(slot) != stack) return;
        SimpleEnergyItem storage = (SimpleEnergyItem) stack.method_7909();
        boolean powered = storage.getStoredEnergy(stack) > 0;

        if (slot == class_1304.field_6169) {
            handleWaterBreathing(player, stack, storage, powered);
            handleHungerRefill(player, stack, storage, powered);
            handleDebuffRemoval(player, stack, storage, powered);
            handleNightVision(player, stack, storage, powered);
        }

        if (slot == class_1304.field_6174) {
            handleChestplateTick(player, powered);
        }

        if (slot == class_1304.field_6172 && powered) {
            handleSprintSpeed(player, powered);
            if (player.method_5681()) {
                player.method_6092(new class_1293(class_1294.field_5900, 5, 1, true, false));
            }
        }
    }

    // ===============================================
    // Helmet abilities
    // ===============================================

    private void handleWaterBreathing(class_1657 player, class_1799 stack, SimpleEnergyItem storage, boolean powered) {
        if (!player.method_5869() || !powered) return;

        int air = player.method_5669();
        if (air <= AIR_REFILL_THRESHOLD) {
            if (storage.tryUseEnergy(stack, AIR_REFILL_COST)) {
                player.method_5855(player.method_5748());
            }
        }
    }

    private void handleHungerRefill(class_1657 player, class_1799 stack, SimpleEnergyItem storage, boolean powered) {
        if (!powered) return;

        if (player.method_7344().method_7586() <= HUNGER_REFILL_THRESHOLD) {
            if (storage.tryUseEnergy(stack, HUNGER_REFILL_COST)) {
                int currentFood = player.method_7344().method_7586();
                int newFood = Math.min(20, currentFood + HUNGER_REFILL_AMOUNT);
                player.method_7344().method_7580(newFood);
                player.method_7344().method_7581(Math.min(newFood, player.method_7344().method_7589() + 0.6f));
            }
        }
    }

    private void handleDebuffRemoval(class_1657 player, class_1799 stack, SimpleEnergyItem storage, boolean powered) {
        if (!powered) return;

        // Remove Poison
        class_1293 poison = player.method_6112(class_1294.field_5899);
        if (poison != null) {
            int levels = poison.method_5578() + 1;
            long cost = POISON_REMOVE_COST * levels;
            if (storage.tryUseEnergy(stack, cost)) {
                player.method_6016(class_1294.field_5899);
            }
        }

        // Remove Wither
        class_1293 wither = player.method_6112(class_1294.field_5920);
        if (wither != null) {
            int levels = wither.method_5578() + 1;
            long cost = WITHER_REMOVE_COST * levels;
            if (storage.tryUseEnergy(stack, cost)) {
                player.method_6016(class_1294.field_5920);
            }
        }
    }

    private void handleNightVision(class_1657 player, class_1799 stack, SimpleEnergyItem storage, boolean powered) {
        boolean toggled = isNightVisionToggled(player.method_5667());
        boolean paid = nightVisionPaid.getOrDefault(player.method_5667(), false);

        if (toggled) {
            if (!powered) {
                // Out of power — disable everything
                player.method_6016(class_1294.field_5925);
                nightVisionToggled.remove(player.method_5667());
                nightVisionPaid.remove(player.method_5667());
                return;
            }

            if (!paid) {
                // Just toggled on — charge activation cost
                if (storage.tryUseEnergy(stack, NIGHT_VISION_COST)) {
                    nightVisionPaid.put(player.method_5667(), true);
                } else {
                    // Not enough energy — keep toggle on but don't activate yet
                    return;
                }
            }

            // Night vision active — refresh effect
            player.method_6092(new class_1293(class_1294.field_5925, 220, 1, false, false));
        } else {
            // Toggled off — remove everything
            player.method_6016(class_1294.field_5925);
            nightVisionPaid.remove(player.method_5667());
        }
    }

    // ===============================================
    // Leggings abilities
    // ===============================================

    private static final Set<class_2248> ICE_BLOCKS = Set.of(
            class_2246.field_10295, class_2246.field_10225, class_2246.field_10384, class_2246.field_10110
    );

    private static boolean isOnIce(class_1657 player) {
        class_2680 below = player.method_25936();
        return ICE_BLOCKS.contains(below.method_26204());
    }

    private void handleSprintSpeed(class_1657 player, boolean powered) {
        var attr = player.method_5996(class_5134.field_23719);
        if (attr == null) return;

        // Remove existing modifier first
        attr.method_6200(LEGGINGS_SPRINT_SPEED_ID);

        if (powered && player.method_5624()) {
            double multiplier = isOnIce(player) ? 9.0 : 3.0;
            // vanilla base speed is 0.1, sprint applies 1.3x on top
            // set base attribute = 0.1 * multiplier, so sprint = 0.1 * multiplier * 1.3
            double newBase = 0.1 * multiplier;
            attr.method_26835(new class_1322(
                    LEGGINGS_SPRINT_SPEED_ID,
                    newBase - 0.1,
                    class_1322.class_1323.field_6328
            ));
        }
    }

    // ===============================================
    // Jetpack (Chestplate) — delegated to JetpackHelper
    // ===============================================

    public static long getFlightCostPerTick() { return JetpackHelper.FLIGHT_COST_PER_TICK; }
    public static long getHoverCostPerTick() { return JetpackHelper.HOVER_COST_PER_TICK; }

    public static void toggleHover(UUID playerId) { JetpackHelper.toggleHover(playerId); }
    public static boolean isHoverToggled(UUID playerId) { return JetpackHelper.isHoverToggled(playerId); }
    public static void updateJetpackInput(UUID pid, boolean j, boolean f, float s) { JetpackHelper.updateInput(pid, j, f, s); }

    private void handleChestplateTick(class_1657 player, boolean powered) {
        if (player.method_5809()) player.method_5646();
        JetpackHelper.onChestplateTick(player, powered, getFlightCostPerTick(), getHoverCostPerTick());
    }

    // ===============================================
    // Damage absorption (all pieces)
    // ===============================================

    private static final class_1304[] QUANTUM_SLOTS = {
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166
    };

    public static boolean hasFullQuantumSet(class_1657 player) {
        for (int i = 0; i < QUANTUM_SLOTS.length; i++) {
            class_1799 stack = player.method_6118(QUANTUM_SLOTS[i]);
            if (!(stack.method_7909() instanceof QuantumSuitItem suitItem)
                    || suitItem.getSlotType() != getArmorTypeForSlot(QUANTUM_SLOTS[i]))
                return false;
        }
        return true;
    }

    private static class_1738.class_8051 getArmorTypeForSlot(class_1304 slot) {
        return switch (slot) {
            case field_6169 -> class_1738.class_8051.field_41934;
            case field_6174 -> class_1738.class_8051.field_41935;
            case field_6172 -> class_1738.class_8051.field_41936;
            case field_6166 -> class_1738.class_8051.field_41937;
            default -> null;
        };
    }

    public static boolean tryNegateFallDamage(class_1657 player) {
        class_1799 boots = player.method_6118(class_1304.field_6166);
        if (!(boots.method_7909() instanceof QuantumSuitItem suitItem)
                || suitItem.getSlotType() != class_1738.class_8051.field_41937) return false;

        SimpleEnergyItem storage = (SimpleEnergyItem) boots.method_7909();
        long stored = storage.getStoredEnergy(boots);
        int fallDist = (int) Math.ceil(player.field_6017);
        long cost = Math.max(0, (long) (fallDist - 12) * 900);
        if (stored >= cost) {
            storage.tryUseEnergy(boots, cost);
            return true;
        }
        return false;
    }

    public static boolean absorbDamage(class_1657 player, float amount, class_1282 source) {
        // Guard against re-entrancy
        UUID id = player.method_5667();
        if (absorbingDamage.contains(id)) return true;
        if (amount <= 0) return true;

        int totalDamage = Math.min((int) amount, MAX_ABSORBABLE_DAMAGE);

        // Check each quantum armor piece and deduct energy
        float totalReduction = 0f;
        boolean anyPieceAbsorbed = false;

        for (int i = 0; i < QUANTUM_SLOTS.length; i++) {
            class_1799 stack = player.method_6118(QUANTUM_SLOTS[i]);
            if (!(stack.method_7909() instanceof QuantumSuitItem suitItem)
                    || suitItem.getSlotType() != getArmorTypeForSlot(QUANTUM_SLOTS[i]))
                continue;

            // Cost: 900 base + 30 per damage point
            long cost = DAMAGE_BASE_COST + DAMAGE_PER_POINT_COST * totalDamage;
            SimpleEnergyItem storage = (SimpleEnergyItem) stack.method_7909();
            if (storage.tryUseEnergy(stack, cost)) {
                totalReduction += DAMAGE_REDUCTION[i];
                anyPieceAbsorbed = true;
            }
        }

        if (!anyPieceAbsorbed) return true; // no absorption — let damage through

        // Apply reduced damage
        float remaining = amount * (1.0f - Math.min(totalReduction, 1.0f));
        if (remaining <= 0.01f) return false; // fully absorbed

        // Apply remaining damage directly (bypass re-entrancy)
        absorbingDamage.add(id);
        try {
            player.method_6033(Math.max(0f, player.method_6032() - remaining));
        } finally {
            absorbingDamage.remove(id);
        }
        return false; // cancelled original damage
    }

    // ===============================================
    // Cleanup on unequip
    // ===============================================

    public void onUnequip(class_1657 player) {
        class_1738.class_8051 slot = slotType;
        if (slot == class_1738.class_8051.field_41935) {
            JetpackHelper.onUnequip(player.method_5667());
        }
        if (slot == class_1738.class_8051.field_41934) {
            player.method_6016(class_1294.field_5925);
            nightVisionToggled.remove(player.method_5667());
            nightVisionPaid.remove(player.method_5667());
        }
        if (slot == class_1738.class_8051.field_41936) {
            var attr = player.method_5996(class_5134.field_23719);
            if (attr != null) attr.method_6200(LEGGINGS_SPRINT_SPEED_ID);
        }
    }

    @Override
    public EnergyTier getEnergyTier() { return energyTier; }

    public class_1738.class_8051 getSlotType() { return slotType; }

    // ===============================================
    // Boost Jump (Quantum Boots)
    // ===============================================

    public static void performBoostJump(class_1657 player) {
        class_1799 boots = player.method_6118(class_1304.field_6166);
        if (!(boots.method_7909() instanceof QuantumSuitItem suitItem)
                || suitItem.getSlotType() != class_1738.class_8051.field_41937) return;

        SimpleEnergyItem storage = (SimpleEnergyItem) boots.method_7909();
        if (storage.getStoredEnergy(boots) < BOOST_JUMP_COST) return;
        if (!player.method_24828()) return;

        if (storage.tryUseEnergy(boots, BOOST_JUMP_COST)) {
            player.method_18800(player.method_18798().method_10216(), BOOST_JUMP_VELOCITY, player.method_18798().method_10215());
            player.field_6037 = true;
        }
    }
}
