package com.skniro.skniro_furniture.datagen;

import com.skniro.skniro_furniture.Furniture;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricAdvancementProvider;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.advancements.AdvancementType;
import net.minecraft.advancements.predicates.ItemPredicate;
import net.minecraft.advancements.triggers.Criterion;
import net.minecraft.advancements.triggers.InventoryChangeTrigger;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public class ExampleModAdvancementProvider extends FabricAdvancementProvider {
	protected ExampleModAdvancementProvider(FabricPackOutput output, CompletableFuture<HolderLookup.Provider> registryLookup) {
		super(output, registryLookup);
	}

	private static Identifier id(String name) {
		return Identifier.fromNamespaceAndPath(Furniture.MOD_ID, name);
	}

	private static TagKey<Item> tag(String name) {
		return TagKey.create(Registries.ITEM, id(name));
	}

	private static ItemLike item(HolderGetter<Item> items, String name) {
		return items.getOrThrow(ResourceKey.create(Registries.ITEM, id(name))).value();
	}

	private static Criterion<InventoryChangeTrigger.TriggerInstance> hasTag(HolderGetter<Item> items, String name) {
		return InventoryChangeTrigger.TriggerInstance.hasItems(ItemPredicate.Builder.item().of(items, tag(name)).build());
	}

	private static Advancement.Builder advancement(HolderGetter<Item> items, String name,
			AdvancementHolder parent, AdvancementType frame, String iconName) {
		// Only the root advancement carries a background image for the tab.
		Identifier background = parent == null ? id("block/bookshelf") : null;
		Advancement.Builder builder = Advancement.Builder.advancement()
				.display(
						item(items, iconName),
						Component.translatable("advancements." + Furniture.MOD_ID + "." + name + ".title"),
						Component.translatable("advancements." + Furniture.MOD_ID + "." + name + ".description"),
						background,
						frame,
						true,
						true,
						false);
		if (parent != null) {
			builder.parent(parent);
		}
		return builder;
	}

	private static AdvancementHolder save(Consumer<AdvancementHolder> consumer, Advancement.Builder builder, String name) {
		return builder.save(consumer, Furniture.MOD_ID + ":" + name);
	}

	@Override
	public void generateAdvancement(HolderLookup.Provider wrapperLookup, Consumer<AdvancementHolder> consumer) {
		HolderLookup.RegistryLookup<Item> items = wrapperLookup.lookupOrThrow(Registries.ITEM);

		AdvancementHolder furnishing = save(consumer,
				advancement(items, "furnishing", null, AdvancementType.TASK, "acacia_plank_chair")
						.addCriterion("get_furniture", hasTag(items, "furniture")),
				"furnishing");

		save(consumer,
				advancement(items, "take_a_seat", furnishing, AdvancementType.TASK, "acacia_plank_chair")
						.addCriterion("get_chair", hasTag(items, "chairs")),
				"take_a_seat");

		save(consumer,
				advancement(items, "sweet_dreams", furnishing, AdvancementType.TASK, "acacia_red_wood_bed")
						.addCriterion("get_bed", hasTag(items, "beds")),
				"sweet_dreams");

		save(consumer,
				advancement(items, "coffee_break", furnishing, AdvancementType.TASK, "acacia_plank_coffee_table")
						.addCriterion("get_coffee_table", hasTag(items, "coffee_tables")),
				"coffee_break");

		AdvancementHolder movieNight = save(consumer,
				advancement(items, "movie_night", furnishing, AdvancementType.TASK, "acacia_planks_tv")
						.addCriterion("get_tv", hasTag(items, "tvs")),
				"movie_night");

		save(consumer,
				advancement(items, "cozy_living_room", movieNight, AdvancementType.GOAL, "black_sofa")
						.addCriterion("get_sofa", hasTag(items, "sofas"))
						.addCriterion("get_tv", hasTag(items, "tvs")),
				"cozy_living_room");

		AdvancementHolder chefsKitchen = save(consumer,
				advancement(items, "chefs_kitchen", furnishing, AdvancementType.TASK, "acacia_planks_oven")
						.addCriterion("get_oven", hasTag(items, "ovens")),
				"chefs_kitchen");

		AdvancementHolder keepItFresh = save(consumer,
				advancement(items, "keep_it_fresh", chefsKitchen, AdvancementType.TASK, "black_fridge")
						.addCriterion("get_fridge", hasTag(items, "fridges")),
				"keep_it_fresh");

		save(consumer,
				advancement(items, "kitchen_master", keepItFresh, AdvancementType.GOAL, "acacia_planks_kitchen_sink")
						.addCriterion("get_oven", hasTag(items, "ovens"))
						.addCriterion("get_fridge", hasTag(items, "fridges"))
						.addCriterion("get_sink", hasTag(items, "sinks"))
						.addCriterion("get_counter", hasTag(items, "counters")),
				"kitchen_master");

		AdvancementHolder storageSolutions = save(consumer,
				advancement(items, "storage_solutions", furnishing, AdvancementType.TASK, "acacia_plank_double_glass_doors_triple_cabinet")
						.addCriterion("get_cabinet", hasTag(items, "cabinets")),
				"storage_solutions");

		save(consumer,
				advancement(items, "full_of_drawers", storageSolutions, AdvancementType.TASK, "acacia_allay_draw")
						.addCriterion("get_drawer", hasTag(items, "drawers")),
				"full_of_drawers");

		save(consumer,
				advancement(items, "let_there_be_light", furnishing, AdvancementType.TASK, "black_ceiling_lamp")
						.addCriterion("get_lamp", hasTag(items, "lamps")),
				"let_there_be_light");

		AdvancementHolder homeSweetHome = save(consumer,
				advancement(items, "home_sweet_home", furnishing, AdvancementType.TASK, "acacia_black_cushion")
						.addCriterion("get_cushion", hasTag(items, "cushions")),
				"home_sweet_home");

		save(consumer,
				advancement(items, "cuddly_friend", homeSweetHome, AdvancementType.TASK, "teddy_bear_normal")
						.addCriterion("get_teddy", hasTag(items, "teddy_bears")),
				"cuddly_friend");

		AdvancementHolder openTheDoor = save(consumer,
				advancement(items, "open_the_door", furnishing, AdvancementType.TASK, "acacia_black_glass_sliding_door")
						.addCriterion("get_door", hasTag(items, "doors")),
				"open_the_door");

		save(consumer,
				advancement(items, "room_with_a_view", openTheDoor, AdvancementType.TASK, "acacia_plank_window")
						.addCriterion("get_window", hasTag(items, "windows")),
				"room_with_a_view");

		save(consumer,
				advancement(items, "reading_corner", furnishing, AdvancementType.TASK, "acacia_bookshelf")
						.addCriterion("get_bookshelf", hasTag(items, "bookshelves")),
				"reading_corner");

		save(consumer,
				advancement(items, "interior_designer", furnishing, AdvancementType.CHALLENGE, "acacia_planks_book_desk")
						.addCriterion("get_chair", hasTag(items, "chairs"))
						.addCriterion("get_bed", hasTag(items, "beds"))
						.addCriterion("get_table", hasTag(items, "tables"))
						.addCriterion("get_sofa", hasTag(items, "sofas"))
						.addCriterion("get_tv", hasTag(items, "tvs"))
						.addCriterion("get_oven", hasTag(items, "ovens"))
						.addCriterion("get_fridge", hasTag(items, "fridges"))
						.addCriterion("get_cabinet", hasTag(items, "cabinets"))
						.addCriterion("get_lamp", hasTag(items, "lamps"))
						.addCriterion("get_cushion", hasTag(items, "cushions"))
						.addCriterion("get_door", hasTag(items, "doors"))
						.addCriterion("get_window", hasTag(items, "windows")),
				"interior_designer");
	}
}
