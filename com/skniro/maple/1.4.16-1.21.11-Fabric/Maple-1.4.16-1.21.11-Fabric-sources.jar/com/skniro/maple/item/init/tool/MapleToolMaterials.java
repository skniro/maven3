package com.skniro.maple.item.init.tool;


import com.skniro.maple.tag.MapleItemTags;
import net.minecraft.class_3481;
import net.minecraft.class_9886;

public class MapleToolMaterials{
    public static final class_9886 Cherry = new class_9886(class_3481.field_49925, 3231, 12.0F, 3.0F, 22, MapleItemTags.CHERRY_TOOL_MATERIALS);
}
