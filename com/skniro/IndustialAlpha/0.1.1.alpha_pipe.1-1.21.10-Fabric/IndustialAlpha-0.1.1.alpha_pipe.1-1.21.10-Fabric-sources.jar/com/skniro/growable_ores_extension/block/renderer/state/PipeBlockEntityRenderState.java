package com.skniro.growable_ores_extension.block.renderer.state;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10444;
import net.minecraft.class_11954;
import net.minecraft.class_243;

public class PipeBlockEntityRenderState extends class_11954 {
    public final List<PipeItemRender> items = new ArrayList<>();

    public static class PipeItemRender {
        public final class_10444 item = new class_10444();
        public class_243 offset = class_243.field_1353;
        public int lightmapCoordinates;
    }
}
