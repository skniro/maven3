package com.skniro.industrial_elixir.screen.ingame.generator.fluid;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.renderer.GuiFluidTankRenderer;
import com.skniro.industrial_elixir.screen.handler.generator.fluid.FluidGeneratorScreenHandler;
import com.skniro.industrial_elixir.util.MouseUtil;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.util.List;
import java.util.Optional;

public class FluidGeneratorScreen extends class_465<FluidGeneratorScreenHandler> {
    private static final class_2960 TEXTURE =
            class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/generator/fluid_generator.png");
    private GuiFluidTankRenderer fluidRenderer;

    public FluidGeneratorScreen(FluidGeneratorScreenHandler menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25269 = 45;
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
        field_25268 = 4;
        fluidRenderer = new GuiFluidTankRenderer(field_2797.blockEntity.fluidContainer.getCapacity(), false, 16, 50);
    }

    public List<class_2561> getTooltips() {
               return List.of(class_2561.method_43470(field_2797.blockEntity.energyContainer.getSideStorage(null).getAmount()+" / "+ field_2797.blockEntity.energyContainer.getSideStorage(null).getCapacity()+" EP"));
    }

    private boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, int width, int height) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, width, height);
    }

    private void renderEnergyAreaTooltips(class_332 context, int pMouseX, int pMouseY, int x, int y) {
        if(isMouseAboveArea(pMouseX, pMouseY, x, y, 76, 34, 31, 16)) {
            context.method_51437(Screens.getTextRenderer(this), getTooltips(),
                    Optional.empty(), pMouseX, pMouseY);
        }
    }

    private void renderEnergyArea(class_332 context, int x, int y) {
        context.method_25290(TEXTURE, x + 76, y + 34, 176, 14, getScaledEnergyHeight(), 16,256,256);
    }

    public int getScaledEnergyHeight() {
        long energy = field_2797.blockEntity.energyContainer.amount;
        long capacity = field_2797.blockEntity.energyContainer.getCapacity();
        int energyBarSize = 31;

        return Math.toIntExact(capacity != 0 && energy != 0 ? energy * energyBarSize / capacity : 0);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        super.method_2388(context, mouseX, mouseY);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        renderEnergyAreaTooltips(context, mouseX, mouseY, field_2776, field_2800);

        if (MouseUtil.isMouseOver(mouseX, mouseY, x + 8, y + 5, fluidRenderer.getWidth(), fluidRenderer.getHeight())) {
            context.method_51437(this.field_22793, fluidRenderer.getTooltip(field_2797.blockEntity.fluidContainer), Optional.empty(), mouseX, mouseY);
        }
    }

    @Override
    protected void method_2389(class_332 context, float a, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        context.method_25290(TEXTURE, x, y, 0, 0, field_2792, field_2779, 256, 256);
        fluidRenderer.render(context, x + 8, y + 5, field_2797.blockEntity.fluidContainer);
        renderEnergyArea(context, x, y);
    }
}
