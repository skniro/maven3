package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;

public class TripleCabinetBlock extends AbstractWallCabinetBlock {

    public TripleCabinetBlock(class_2251 settings) {
        super(settings);
    }

}
