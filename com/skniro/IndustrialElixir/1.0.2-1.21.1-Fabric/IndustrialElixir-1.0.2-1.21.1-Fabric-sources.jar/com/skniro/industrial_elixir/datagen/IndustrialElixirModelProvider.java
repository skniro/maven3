package com.skniro.industrial_elixir.datagen;

import com.skniro.industrial_elixir.api.data.family.GrowableOresBlockFamilies;
import com.skniro.industrial_elixir.api.data.model.MapleItemModelDatagenHelper;
import com.skniro.industrial_elixir.api.data.model.MapleModelDatagenHelper;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.block.MapleSignBlocks;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluidItems;
import com.skniro.industrial_elixir.item.AdvancedItems;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.item.MapleArmorItems;
import com.skniro.industrial_elixir.item.MapleFoodComponents;
import com.skniro.industrial_elixir.item.init.equipment.MapleEquipmentAssetKeys;
import com.skniro.growableoresir.block.GrowableICOresBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_1738;
import net.minecraft.class_2246;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;


public class IndustrialElixirModelProvider extends FabricModelProvider {
    public IndustrialElixirModelProvider(FabricDataOutput dataGenerator){
        super(dataGenerator);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        blockStateModelGenerator.method_25650(GeneralBlocks.Deepslate_Lead_Ore);
        blockStateModelGenerator.method_25650(GeneralBlocks.Deepslate_Tin_Ore);
        blockStateModelGenerator.method_25650(GeneralBlocks.Deepslate_SACRED_Ore);
        blockStateModelGenerator.method_25650(GeneralBlocks.Lead_Ore);
        blockStateModelGenerator.method_25650(GeneralBlocks.Tin_Ore);
        blockStateModelGenerator.method_25650(GeneralBlocks.SACRED_Ore);
        blockStateModelGenerator.method_25650(GeneralBlocks.Raw_Lead_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Raw_Tin_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Raw_SACRED_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Lead_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Tin_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.SACRED_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Silver_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Bronze_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Steel_Block);
        blockStateModelGenerator.method_25650(GeneralBlocks.Machine);
        blockStateModelGenerator.method_25650(GeneralBlocks.Advanced_Machine);
        blockStateModelGenerator.method_25650(GeneralBlocks.Super_Machine);

        class_4910.class_4912 MaplePool = blockStateModelGenerator.method_25650(GeneralBlocks.Rubber_PLANKS)
                .method_33522(GrowableOresBlockFamilies.RUBBER_PLANKS);

        blockStateModelGenerator.method_25676(GeneralBlocks.Rubber_LOG).method_25730(GeneralBlocks.Rubber_LOG).method_25728(GeneralBlocks.Rubber_WOOD);
        blockStateModelGenerator.method_25676(GeneralBlocks.STRIPPED_Rubber_LOG).method_25730(GeneralBlocks.STRIPPED_Rubber_LOG).method_25728(GeneralBlocks.STRIPPED_Rubber_WOOD);

        blockStateModelGenerator.method_25545(GeneralBlocks.Rubber_SAPLING, GeneralBlocks.POTTED_Rubber_SAPLING, class_4910.class_4913.field_22840);
        blockStateModelGenerator.method_25641(GeneralBlocks.Rubber_LEAVES);

        blockStateModelGenerator.method_46190(GeneralBlocks.STRIPPED_Rubber_LOG, MapleSignBlocks.Rubber_HANGING_SIGN, MapleSignBlocks.Rubber_WALL_HANGING_SIGN);

        //PLASTER
        blockStateModelGenerator.method_25650(GeneralBlocks.GREEN_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.ORANGE_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.MAGENTA_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.LIGHT_BLUE_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.YELLOW_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.LIME_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.PINK_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.GRAY_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.LIGHT_GRAY_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.CYAN_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.PURPLE_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.BLUE_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.BROWN_PLASTER);
        blockStateModelGenerator.method_25650(GeneralBlocks.RED_PLASTER);


        blockStateModelGenerator.method_25650(GeneralBlocks.Reinforced_Stone);
        blockStateModelGenerator.method_25650(GeneralBlocks.Reinforced_Glass);
        blockStateModelGenerator.method_25658(GeneralBlocks.Reinforced_DOOR);

        blockStateModelGenerator.method_25708(GrowableOresBlocks.VENDOR_MACHINE_Block);

        blockStateModelGenerator.method_25708(GeneralBlocks.COFFEE_BLACK);
        blockStateModelGenerator.method_25708(GeneralBlocks.CAPPUCCINO);
        blockStateModelGenerator.method_25708(GeneralBlocks.MOCHA);
        blockStateModelGenerator.method_25708(GeneralBlocks.LATTE);
        blockStateModelGenerator.method_25708(GeneralBlocks.HOT_COCOA);

        MapleModelDatagenHelper mapleModelDatagenHelper = new MapleModelDatagenHelper(blockStateModelGenerator);

        mapleModelDatagenHelper.registerModLogs(GeneralBlocks.Rubber_Rubber_LOG);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.COAL_GENERATOR, true);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.NUCLEAR_REACTOR, true);
        mapleModelDatagenHelper.registerMachineDiffBottom(GrowableOresBlocks.Macerator_Block, true);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.Compressor_Block, true);
        mapleModelDatagenHelper.registerMachineSameNorthSouth(GrowableOresBlocks.GENERATOR_Wind_Mill, false);
        mapleModelDatagenHelper.registerMachineDiffBottom(GrowableOresBlocks.MetalFormerBlock, true);
        mapleModelDatagenHelper.registerMachineDiffBottomBack(GrowableOresBlocks.EnergyBox, false);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.CESU, false);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.MFE, false);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.MFSU, false);
        mapleModelDatagenHelper.registerMachineDiffBottomBack(GrowableOresBlocks.ChargePad, true);
        mapleModelDatagenHelper.registerMachineDiffBottomBack(GrowableOresBlocks.CESU_CHARGE_PAD, false);
        mapleModelDatagenHelper.registerMachineDiffBottomBack(GrowableOresBlocks.MFE_CHARGE_PAD, false);
        mapleModelDatagenHelper.registerMachineDiffBottomBack(GrowableOresBlocks.MFSU_CHARGE_PAD, false);
        mapleModelDatagenHelper.registerMachineDiffBottomBack(GrowableOresBlocks.Iron_Furnace_Block, true);

        mapleModelDatagenHelper.registerMachineSameSide(GrowableOresBlocks.GENERATOR_SolarPanel);
        mapleModelDatagenHelper.registerMachineSameSide(GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL);
        mapleModelDatagenHelper.registerMachineSameSide(GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL);
        mapleModelDatagenHelper.registerMachineSameSide(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL);
        mapleModelDatagenHelper.registerMachineSameSide(GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL);

        mapleModelDatagenHelper.registerMachineExtractor(GrowableOresBlocks.Extractor_Block, true);

        mapleModelDatagenHelper.registerMachineTransformer(GrowableOresBlocks.LV_TRANSFORMER, true);
        mapleModelDatagenHelper.registerMachineTransformer(GrowableOresBlocks.MV_TRANSFORMER, true);
        mapleModelDatagenHelper.registerMachineTransformer(GrowableOresBlocks.HV_TRANSFORMER, true);
        mapleModelDatagenHelper.registerMachineTransformer(GrowableOresBlocks.EV_TRANSFORMER, true);

        mapleModelDatagenHelper.registerMachineDiffBottom(GrowableOresBlocks.ElectricFurnace_Block, true);
        mapleModelDatagenHelper.registerMachineExtractor(GrowableOresBlocks.INDUCTION_FURNACE, true);
        mapleModelDatagenHelper.registerMachineDiffBottom(GrowableOresBlocks.RECYCLER_Block, true);
        mapleModelDatagenHelper.registerMachineExtractor(GrowableOresBlocks.CUTTING_Block, true);

        blockStateModelGenerator.method_25548(GrowableICOresBlocks.IER_Bronze_Cane, class_4910.class_4913.field_22839);
        blockStateModelGenerator.method_25548(GrowableICOresBlocks.IER_silver_Cane, class_4910.class_4913.field_22839);
        blockStateModelGenerator.method_25548(GrowableICOresBlocks.IER_Tin_Cane, class_4910.class_4913.field_22839);
        blockStateModelGenerator.method_25548(GrowableICOresBlocks.IER_SACRED_Cane, class_4910.class_4913.field_22839);
        blockStateModelGenerator.method_25548(GrowableICOresBlocks.IER_steel_Cane, class_4910.class_4913.field_22839);
        blockStateModelGenerator.method_25548(GrowableICOresBlocks.IER_LEAD_Cane, class_4910.class_4913.field_22839);

        class_4910.class_4912 blue = blockStateModelGenerator.method_25650(class_2246.field_10445);
        blue.method_25725(GeneralBlocks.COBBLESTONE_STAIRS);

        mapleModelDatagenHelper.registerMachineExtractor(GrowableOresBlocks.MolecularTransformerBlock, true);
        mapleModelDatagenHelper.registerMachineDiffBottom(GrowableOresBlocks.Brew_Reactor_BLOCK, true);
        mapleModelDatagenHelper.registerMachineExtractor(GrowableOresBlocks.Ore_Washing_Block, true);
        mapleModelDatagenHelper.registerMachineSameNorthSouth(GrowableOresBlocks.FLUID_TANK_BLOCK, false);
        mapleModelDatagenHelper.registerMachineElectricHeater(GrowableOresBlocks.Electric_Heater_Block, true);
        mapleModelDatagenHelper.registerMachineBlastFurnace(GrowableOresBlocks.BLAST_FURNACE_BLOCK, true);
        mapleModelDatagenHelper.registerMachineHeatCentrifuge(GrowableOresBlocks.HEAT_CENTRIFUGE, true);
        mapleModelDatagenHelper.registerMachineDiffBottom(GrowableOresBlocks.SACRED_GENERATOR, true);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.MATTER_GENERATOR, true);
        mapleModelDatagenHelper.registerMachineDiffBottom(GrowableOresBlocks.FLUID_GENERATOR, true);
        mapleModelDatagenHelper.registerMachineChunkLoader(GrowableOresBlocks.CHUNK_LOADER, true);
        mapleModelDatagenHelper.registerMachineDiffBottom(GrowableOresBlocks.PATTERN_STORAGE, true);
        mapleModelDatagenHelper.registerBaseMachineBlock(GrowableOresBlocks.Replicator, true);
        mapleModelDatagenHelper.registerMachineSolidHeater(GrowableOresBlocks.SOLID_FUEL_HEATER_GENERATOR, true);

        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.CROP_FARM_Block, true);
        mapleModelDatagenHelper.registerMachine(GrowableOresBlocks.COFFEE_MACHINE_Block, true);

        mapleModelDatagenHelper.registerModSweetBerryBush(MapleFoodComponents.Coffee_Beans, GeneralBlocks.Coffee_Block);
    }
    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        itemModelGenerator.method_25733(GrowableOresItems.Rubber, class_4943.field_22938);
        //Sign
        //itemModelGenerator.register(Item.fromBlock(MapleSignBlocks.Rubber_SIGN), Models.GENERATED);
       // itemModelGenerator.register(Item.fromBlock(MapleSignBlocks.Rubber_HANGING_SIGN), Models.GENERATED);
        itemModelGenerator.method_25733(GrowableOresItems.RUBBER_BOAT, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.RUBBER_CHEST_BOAT, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.ENERGY_STORAGE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.OVERCLOCKER, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.TRANSFORMER, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.REDSTONE_INVERTER, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SACRED_ESSENCE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SACRED_SHARD, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SACRED_CORE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.EMPTY_VESSEL, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.IMPURE_SACRED_STONE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.COOLANT_CELL_10K, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.COOLANT_CELL_30K, class_4943.field_22938);;
        itemModelGenerator.method_25733(GrowableOresItems.COOLANT_CELL_60K, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.HEAT_VENT, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.ADVANCED_HEAT_VENT, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.OVERCLOCKED_HEAT_VENT, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.REACTOR_PLATING, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.NEUTRON_REFLECTOR, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.HEAT_EXCHANGER, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.Raw_Lead, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.Raw_Tin, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.Raw_SACRED, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.CRUSHED_COPPER, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.CRUSHED_GOLD, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.CRUSHED_IRON, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.CRUSHED_LEAD, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.CRUSHED_SILVER, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.CRUSHED_TIN, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.CRUSHED_SACRED, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.PURIFIED_COPPER, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.PURIFIED_GOLD, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.PURIFIED_IRON, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.PURIFIED_LEAD, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.PURIFIED_SILVER, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.PURIFIED_TIN, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.PURIFIED_SACRED, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.BRONZE_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.CLAY_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.COAL_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.COPPER_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.DIAMOND_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.ENERGIUM_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.GOLD_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.IRON_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.LAPIS_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.LEAD_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.LITHIUM_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.OBSIDIAN_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SILICON_DIOXIDE_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SILVER_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.STONE_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SULFUR_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.TIN_DUST, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.SMALL_BRONZE_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SMALL_COPPER_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SMALL_GOLD_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SMALL_IRON_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SMALL_LAPIS_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SMALL_LEAD_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SMALL_LITHIUM_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SMALL_OBSIDIAN_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SMALL_SILVER_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SMALL_SULFUR_DUST, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SMALL_TIN_DUST, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.BRONZE_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.LEAD_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SILVER_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.STEEL_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.TIN_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.SACRED_INGOT, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.BRONZE_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.COPPER_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.GOLD_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.IRON_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.LAPIS_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.LEAD_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.OBSIDIAN_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.STEEL_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.TIN_PLATE, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.DENSE_BRONZE_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.DENSE_COPPER_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.DENSE_GOLD_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.DENSE_IRON_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.DENSE_LAPIS_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.DENSE_LEAD_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.DENSE_OBSIDIAN_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.DENSE_STEEL_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.DENSE_TIN_PLATE, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.BRONZE_CASING, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.COPPER_CASING, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.GOLD_CASING, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.IRON_CASING, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.LEAD_CASING, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.STEEL_CASING, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.TIN_CASING, class_4943.field_22938);

        itemModelGenerator.method_48523((class_1738) MapleArmorItems.Quantum_HELMET);
        itemModelGenerator.method_48523((class_1738) MapleArmorItems.Quantum_CHESTPLATE);
        itemModelGenerator.method_48523((class_1738) MapleArmorItems.Quantum_LEGGINGS);
        itemModelGenerator.method_48523((class_1738) MapleArmorItems.Quantum_BOOTS);

        itemModelGenerator.method_25733(AdvancedItems.IRRADIANT_SACRED_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(AdvancedItems.IRRADIANT_GLASS_PANE, class_4943.field_22938);
        itemModelGenerator.method_25733(AdvancedItems.LUMINITE, class_4943.field_22938);
        itemModelGenerator.method_25733(AdvancedItems.ENRICHED_LUMINITE, class_4943.field_22938);
        itemModelGenerator.method_25733(AdvancedItems.LUMINITE_ALLOY, class_4943.field_22938);
        itemModelGenerator.method_25733(AdvancedItems.ENRICHED_LUMINITE_ALLOY, class_4943.field_22938);
        itemModelGenerator.method_25733(AdvancedItems.IRIDIUM_AMETHYST_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(AdvancedItems.REINFORCED_IRIDIUM_AMETHYST_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(AdvancedItems.IRRADIANT_REINFORCED_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(AdvancedItems.LUMINITE_Part, class_4943.field_22938);
        itemModelGenerator.method_25733(AdvancedItems.Iridium_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(AdvancedItems.Quantum_Core, class_4943.field_22938);
        itemModelGenerator.method_25733(AdvancedItems.MT_Core, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.CARBON_FIBRE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.CARBON_MESH, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.CARBON_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.COAL_BALL, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.COAL_BLOCK, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.COAL_CHUNK, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.INDUSTRIAL_DIAMOND, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.IRIDIUM_SHARD, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.IRIDIUM_ORE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.ALLOY_INGOT, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.ALLOY_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.Sticky_Resin, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.IRIDIUM_PLATE, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.Circuit, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.Advanced_Circuit, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.Coil, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.Electric_Motor, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.Scrap, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.Scrap_box, class_4943.field_22938);

        itemModelGenerator.method_25733(MapleArmorItems.CUTTING, class_4943.field_22938);
        itemModelGenerator.method_25733(MapleArmorItems.ROLLING, class_4943.field_22938);

        itemModelGenerator.method_48523((class_1738) MapleArmorItems.BRONZE_BOOTS);
        itemModelGenerator.method_48523((class_1738) MapleArmorItems.BRONZE_CHESTPLATE);
        itemModelGenerator.method_48523((class_1738) MapleArmorItems.BRONZE_HELMET);
        itemModelGenerator.method_48523((class_1738) MapleArmorItems.BRONZE_LEGGINGS);

        itemModelGenerator.method_25733(MapleArmorItems.BRONZE_PICKAXE, class_4943.field_22939);
        itemModelGenerator.method_25733(MapleArmorItems.BRONZE_AXE, class_4943.field_22939);
        itemModelGenerator.method_25733(MapleArmorItems.BRONZE_SHOVEL, class_4943.field_22939);
        itemModelGenerator.method_25733(MapleArmorItems.BRONZE_SWORD, class_4943.field_22939);
        itemModelGenerator.method_25733(MapleArmorItems.BRONZE_HOE, class_4943.field_22939);

        itemModelGenerator.method_48523((class_1738) MapleArmorItems.Electric_Jetpack);

        itemModelGenerator.method_25733(GrowableOresItems.EMPTY_CELL, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.WATER_CELL, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.LAVA_CELL, class_4943.field_22938);

        itemModelGenerator.method_25733(GrowableOresItems.SLAG, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.ASHES, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.PATTERN_STORAGE_CRYSTAL, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.RAW_PATTERN_STORAGE_CRYSTAL, class_4943.field_22938);
        itemModelGenerator.method_25733(GrowableOresItems.HEAT_CONDUCTOR, class_4943.field_22938);

        itemModelGenerator.method_25733(IndustrialElixirFluidItems.Hot_Spring_CELL, class_4943.field_22938);
        itemModelGenerator.method_25733(IndustrialElixirFluidItems.Hot_Spring_BUCKET, class_4943.field_22938);

        MapleItemModelDatagenHelper mapleItemModelDatagenHelper = new MapleItemModelDatagenHelper(itemModelGenerator);
        mapleItemModelDatagenHelper.registerDurabilityItem(GrowableOresItems.RE_BATTERY);
        mapleItemModelDatagenHelper.registerDurabilityItem(GrowableOresItems.ADVANCED_RE_BATTERY);
        mapleItemModelDatagenHelper.registerDurabilityItem(GrowableOresItems.ENERGY_CRYSTAL);
        mapleItemModelDatagenHelper.registerDurabilityItem(GrowableOresItems.LAPOTRON_CRYSTAL);

        itemModelGenerator.method_25733(IndustrialElixirFluidItems.UU_CELL, class_4943.field_22938);
        itemModelGenerator.method_25733(IndustrialElixirFluidItems.AIR_CELL, class_4943.field_22938);
        itemModelGenerator.method_25733(IndustrialElixirFluidItems.Fluid_UU_BUCKET, class_4943.field_22938);
        itemModelGenerator.method_25733(IndustrialElixirFluidItems.Fluid_AIR_BUCKET, class_4943.field_22938);
    }
}
