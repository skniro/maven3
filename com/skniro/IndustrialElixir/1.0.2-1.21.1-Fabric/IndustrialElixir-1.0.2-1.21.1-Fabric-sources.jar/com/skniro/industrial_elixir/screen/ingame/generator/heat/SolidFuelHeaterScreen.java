package com.skniro.industrial_elixir.screen.ingame.generator.heat;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.screen.handler.generator.heat.SolidFuelHeaterScreenHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_465;

@Environment(EnvType.CLIENT)
public class SolidFuelHeaterScreen extends class_465<SolidFuelHeaterScreenHandler> {
    private static final class_2960 TEXTURE =
            class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/generator/heat/solid_fuel_heater.png");
    private static final class_2960 LIT_PROGRESS_TEXTURE = class_2960.method_60654("container/furnace/lit_progress");

    public SolidFuelHeaterScreen(SolidFuelHeaterScreenHandler menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
        field_25268 = 4;
        field_25269 = 145;
        field_25270 = 72;
    }

    private void renderHeatAreaTooltips(class_332 context) {
        context.method_51439(field_22793, field_2797.getHeatTooltips(), 47, 62,  -12566464, false);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        context.method_51439(field_22793, this.field_22785, this.field_25267, this.field_25268, -12566464, false);
        context.method_51439(field_22793, this.field_29347, this.field_25269, this.field_25270, -12566464, false);
        renderHeatAreaTooltips(context);
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTicks, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        graphics.method_25290(TEXTURE, x, y, 0, 0, field_2792, field_2779, 256, 256);

        // Burn progress flame icon
        renderBurnProgress(graphics, x, y);

        // Heat bar
        int heatHeight = field_2797.getScaledHeatHeight();
        if (heatHeight > 0) {
            graphics.method_25290(TEXTURE,
                    x + 146, y + 62 - heatHeight, 176, 52 - heatHeight, 12, heatHeight, 256, 256);
        }
    }

    private void renderBurnProgress(class_332 context, int x, int y) {
        if(field_2797.isBurning()) {
            int l = class_3532.method_15386(this.field_2797.getFuelProgress() * 13.0f) + 1;
            context.method_52708(LIT_PROGRESS_TEXTURE, 14, 14, 0, 14 - l, x + 80, y + 18 + 14 - l, 14, l);
        }
    }
}
