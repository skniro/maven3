package com.skniro.growable_ores_extension.screen.slot;

import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.api.item.TieredEnergyItem;
import net.minecraft.class_10192;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_9334;

public class HelmetSlot extends BatteryChargeSlot {
    public HelmetSlot(class_1263 inventory, int index, int x, int y, EnergyTier energyTier) {
        super(inventory, index, x, y, energyTier);
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        class_10192 equippable = stack.method_58694(class_9334.field_54196);
        if (equippable == null) return false;
        if (equippable.comp_3174() != class_1304.field_6169) return false;
        if (stack.method_7909() instanceof TieredEnergyItem tiered) {return tiered.getEnergyTier().ordinal() >= this.energyTier.ordinal();}
        return false;
    }

}
