package torcherino.client.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_10799;
import net.minecraft.class_11908;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import torcherino.Torcherino;
import torcherino.TorcherinoImpl;
import torcherino.api.Tier;
import torcherino.api.TorcherinoAPI;
import torcherino.client.screen.widgets.GradatedSliderWidget;
import torcherino.client.screen.widgets.StateButtonWidget;
import torcherino.platform.NetworkUtils;

public final class TorcherinoScreen extends class_437 {
    private static final class_2960 SCREEN_TEXTURE = class_2960.method_60655(TorcherinoImpl.MOD_ID, "textures/screens/torcherino.png");
    private static final int screenWidth = 245;
    private static final int screenHeight = 123;

    private final class_2338 blockPos;
    private final Tier tier;
    private final class_2561 cached_title;
    private int xRange, zRange, yRange, speed, redstoneMode, left, top;

    public TorcherinoScreen(class_2561 title, int xRange, int zRange, int yRange, int speed, int redstoneMode, class_2338 pos, class_2960 tierID) {
        super(title);
        this.tier = TorcherinoAPI.INSTANCE.getTier(tierID);
        this.blockPos = pos;
        this.xRange = xRange;
        this.zRange = zRange;
        this.yRange = yRange;
        this.speed = speed == 0 ? 1 : speed;
        this.redstoneMode = redstoneMode;
        this.cached_title = title;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    protected void method_25426() {
        left = (field_22789 - screenWidth) / 2;
        top = (field_22790 - screenHeight) / 2;
        this.method_37063(new GradatedSliderWidget(left + 8, top + 20, 205, (double) (speed - 1) / (tier.maxSpeed() - 1), tier.maxSpeed()) {
            @Override
            protected void method_25346() {
                this.method_25355(class_2561.method_43469("gui.torcherino.speed", 100 * TorcherinoScreen.this.speed));
            }

            @Override
            protected void method_25344() {
                TorcherinoScreen.this.speed = 1 + (int) Math.round(field_22753 * (TorcherinoScreen.this.tier.maxSpeed() - 1));
                field_22753 = (double) (speed - 1) / (tier.maxSpeed() - 1);
            }
        });
        this.method_37063(new GradatedSliderWidget(left + 8, top + 45, 205, (double) xRange / tier.xzRange(), tier.xzRange()) {
            @Override
            protected void method_25346() {
                this.method_25355(class_2561.method_43469("gui.torcherino.x_range", TorcherinoScreen.this.xRange * 2 + 1));
            }

            @Override
            protected void method_25344() {
                TorcherinoScreen.this.xRange = (int) Math.round(field_22753 * TorcherinoScreen.this.tier.xzRange());
                field_22753 = (double) xRange / tier.xzRange();
            }
        });
        this.method_37063(new GradatedSliderWidget(left + 8, top + 70, 205, (double) zRange / tier.xzRange(), tier.xzRange()) {
            @Override
            protected void method_25346() {
                this.method_25355(class_2561.method_43469("gui.torcherino.z_range", TorcherinoScreen.this.zRange * 2 + 1));
            }

            @Override
            protected void method_25344() {
                TorcherinoScreen.this.zRange = (int) Math.round(field_22753 * TorcherinoScreen.this.tier.xzRange());
                field_22753 = (double) zRange / tier.xzRange();
            }
        });
        this.method_37063(new GradatedSliderWidget(left + 8, top + 95, 205, (double) yRange / tier.yRange(), tier.yRange()) {
            @Override
            protected void method_25346() {
                this.method_25355(class_2561.method_43469("gui.torcherino.y_range", TorcherinoScreen.this.yRange * 2 + 1));
            }

            @Override
            protected void method_25344() {
                TorcherinoScreen.this.yRange = (int) Math.round(field_22753 * TorcherinoScreen.this.tier.yRange());
                field_22753 = (double) yRange / tier.yRange();
            }
        });
        this.method_37063(new StateButtonWidget(this, left + 217, top + 20, field_22793) {
            class_1799 buttonIcon;

            @Override
            protected void initialize() {
                this.setButtonMessage();
                this.setButtonIcon();
            }

            private void setButtonMessage() {
                String translationKey = switch (TorcherinoScreen.this.redstoneMode) {
                    case 0 -> "gui.torcherino.mode.normal";
                    case 1 -> "gui.torcherino.mode.inverted";
                    case 2 -> "gui.torcherino.mode.ignored";
                    case 3 -> "gui.torcherino.mode.off";
                    default -> "gui.torcherino.mode.error";
                };
                this.setNarrationMessage(class_2561.method_43469("gui.torcherino.mode", class_2561.method_43471(translationKey)));
            }

            private void setButtonIcon() {
                switch (TorcherinoScreen.this.redstoneMode) {
                    case 0 -> this.buttonIcon = new class_1799(class_1802.field_8725);
                    case 1 -> this.buttonIcon = new class_1799(class_1802.field_8530);
                    case 2 -> this.buttonIcon = new class_1799(class_1802.field_8054);
                    case 3 -> this.buttonIcon = new class_1799(class_1802.field_8230);
                    default -> this.buttonIcon = new class_1799(class_1802.field_8732);
                }
            }

            @Override
            protected void nextState() {
                TorcherinoScreen.this.redstoneMode = (TorcherinoScreen.this.redstoneMode + 1) % 4;
                this.initialize();
            }

            @Override
            protected class_1799 getButtonIcon() {
                return buttonIcon;
            }
        });
    }

    @Override
    public void method_25420(class_332 context, int x, int y, float partialTicks) {
        this.method_52752(context);
        this.renderBg(context, x, y, partialTicks);
    }


    protected void renderBg(class_332 context, int x, int y, float partialTicks) {
        context.method_25290(class_10799.field_56883, SCREEN_TEXTURE, left, top, 0,0, screenWidth,screenHeight, 256, 256);
        context.method_51439(field_22793, cached_title, (int) ((field_22789 - field_22793.method_27525(cached_title)) / 2.0f), top + 6, -12566464,false);
    }

    @Override
    public void method_25394(class_332 context, int x, int y, float partialTicks) {
        super.method_25394(context, x, y, partialTicks);
    }

    @Override
    public boolean method_25404(class_11908 keyCode) {
        if (keyCode.method_74231() || field_22787.field_1690.field_1822.method_1417(keyCode)) {
            this.method_25419();
            return true;
        }
        return super.method_25404(keyCode);
    }

    @Override
    public void method_25419() {
        NetworkUtils.getInstance().c2s_updateTorcherinoValues(blockPos, xRange, zRange, yRange, speed, redstoneMode);
        super.method_25419();
    }
}
