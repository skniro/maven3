package com.skniro.industrial_elixir.item.init;

import com.google.common.collect.ImmutableMultimap;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.api.item.TieredEnergyItem;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.base.SimpleEnergyItem;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Unit;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class QuantumSuitItem extends Item implements SimpleEnergyItem, TieredEnergyItem {

    public static final long CAPACITY = 10_000_000;

    // Energy costs
    private static final long AIR_REFILL_COST = 1_000;
    private static final long HUNGER_REFILL_COST = 10_000;
    private static final long POISON_REMOVE_COST = 10_000;
    private static final long WITHER_REMOVE_COST = 25_000;
    private static final long NIGHT_VISION_COST = 25_000;

    private static final int AIR_REFILL_THRESHOLD = 180; // 6 bubbles
    private static final int HUNGER_REFILL_THRESHOLD = 14; // 7 shanks
    private static final int HUNGER_REFILL_AMOUNT = 3;

    // Night vision toggle state per player UUID (server-only)
    private static final Map<UUID, Boolean> nightVisionToggled = new ConcurrentHashMap<>();
    // Night vision energy paid tracking (prevents double-charging)
    private static final Map<UUID, Boolean> nightVisionPaid = new ConcurrentHashMap<>();

    private ArmorType slotType;
    private EnergyTier energyTier;

    private final ImmutableMultimap<Holder<net.minecraft.world.entity.ai.attributes.Attribute>, AttributeModifier> noPowerAttributes;
    private final ImmutableMultimap<Holder<net.minecraft.world.entity.ai.attributes.Attribute>, AttributeModifier> hasPowerAttributes;
    private final ImmutableMultimap<Holder<net.minecraft.world.entity.ai.attributes.Attribute>, AttributeModifier> fullSuitAttributes;

    public QuantumSuitItem(Properties settings, ArmorMaterial material, ArmorType slotType, EnergyTier energyTier) {
        super(settings.stacksTo(1).humanoidArmor(material, slotType).component(DataComponents.UNBREAKABLE, Unit.INSTANCE).component(DataComponents.TOOLTIP_DISPLAY, UNBREAKABLE_HIDE));
        this.energyTier = energyTier;
        this.slotType = slotType;
        switch (slotType) {
            case HELMET, BOOTS -> {
                noPowerAttributes = createAttrs(0, 0, 0, 0);
                hasPowerAttributes = createAttrs(3, 3, 0.05, 0);
                fullSuitAttributes = createAttrs(5, 5, 0.1, 0);
            }
            case CHESTPLATE -> {
                noPowerAttributes = createAttrs(0, 0, 0, 0);
                hasPowerAttributes = createAttrs(6, 3, 0.1, 0);
                fullSuitAttributes = createAttrs(10, 5, 0.15, 0);
            }
            case LEGGINGS -> {
                noPowerAttributes = createAttrs(0, 0, 0, 0);
                hasPowerAttributes = createAttrs(8, 3, 0.05, 0.15);
                fullSuitAttributes = createAttrs(10, 5, 0.1, 0.15);
            }
            default -> throw new IllegalArgumentException("Invalid slot type");
        }

        EnergyStorage.ITEM.registerForItems((stack, context) -> SimpleEnergyItem.createStorage(context, this.getEnergyCapacity(stack), this.getEnergyMaxInput(stack), this.getEnergyMaxOutput(stack)), this);
    }

    private static ImmutableMultimap<Holder<net.minecraft.world.entity.ai.attributes.Attribute>, AttributeModifier> createAttrs(
            double armor, double toughness, double knockback, double speed
    ) {
        ImmutableMultimap.Builder<Holder<net.minecraft.world.entity.ai.attributes.Attribute>, AttributeModifier> builder = ImmutableMultimap.builder();
        if (armor > 0) {
            builder.put(Attributes.ARMOR,
                    new AttributeModifier(Identifier.fromNamespaceAndPath(IndustrialElixir.MOD_ID, "armor"), armor, AttributeModifier.Operation.ADD_VALUE));
        }
        if (toughness > 0) {
            builder.put(Attributes.ARMOR_TOUGHNESS,
                    new AttributeModifier(Identifier.fromNamespaceAndPath(IndustrialElixir.MOD_ID, "toughness"), toughness, AttributeModifier.Operation.ADD_VALUE));
        }
        if (knockback > 0) {
            builder.put(Attributes.KNOCKBACK_RESISTANCE,
                    new AttributeModifier(Identifier.fromNamespaceAndPath(IndustrialElixir.MOD_ID, "knockback"), knockback, AttributeModifier.Operation.ADD_VALUE));
        }
        if (speed > 0) {
            builder.put(Attributes.MOVEMENT_SPEED,
                    new AttributeModifier(Identifier.fromNamespaceAndPath(IndustrialElixir.MOD_ID, "speed"), speed, AttributeModifier.Operation.ADD_VALUE));
        }
        return builder.build();
    }

    @Override
    public long getEnergyCapacity(ItemStack stack) { return CAPACITY; }

    @Override
    public long getEnergyMaxInput(ItemStack stack) { return energyTier.getMaxInput(); }

    @Override
    public long getEnergyMaxOutput(ItemStack stack) { return 0; }

    @Override
    public int getBarWidth(ItemStack stack) { return getPowerForDurabilityBar(stack); }

    public boolean isBarVisible(ItemStack stack) { return true; }

    public static int getPowerForDurabilityBar(ItemStack stack) {
        Item var2 = stack.getItem();
        if (var2 instanceof QuantumSuitItem energyItem) {
            return Math.round((float) energyItem.getStoredEnergy(stack) * 100.0F / (float) energyItem.getEnergyCapacity(stack) * 13.0F) / 100;
        } else {
            throw new UnsupportedOperationException();
        }
    }

    public static int getColorForDurabilityBar(ItemStack stack) { return 16744454; }

    @Override
    public int getBarColor(ItemStack stack) { return 0x00FFFF; }

    // ===============================================
    // Toggle API (called from network packet handler)
    // ===============================================

    public static void toggleNightVision(UUID playerId) {
        boolean wasOn = nightVisionToggled.getOrDefault(playerId, false);
        if (wasOn) {
            nightVisionToggled.remove(playerId);
            nightVisionPaid.remove(playerId);
        } else {
            nightVisionToggled.put(playerId, true);
            // Energy will be charged on next tick in handleNightVision
        }
    }

    public static boolean isNightVisionToggled(UUID playerId) {
        return nightVisionToggled.getOrDefault(playerId, false);
    }

    // ===============================================
    // Main tick logic
    // ===============================================

    public void inventoryTick(ItemStack stack, ServerLevel world, Entity entity, @Nullable EquipmentSlot slot) {
        if (!(entity instanceof Player player)) return;
        SimpleEnergyItem storage = (SimpleEnergyItem) stack.getItem();
        boolean powered = storage.getStoredEnergy(stack) > 0;

        if (slot == EquipmentSlot.HEAD) {
            handleWaterBreathing(player, stack, storage, powered);
            handleHungerRefill(player, stack, storage, powered);
            handleDebuffRemoval(player, stack, storage, powered);
            handleNightVision(player, stack, storage, powered);
        }

        if (slot == EquipmentSlot.CHEST) {
            player.getAbilities().mayfly = powered;
            if (player.isOnFire() && powered) player.clearFire();
        }

        if (slot == EquipmentSlot.LEGS && powered) {
            if (player.isSprinting()) {
                // Sprint speed bonus (energy drain commented out for now)
            }
            if (player.isSwimming()) {
                player.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 5, 1, true, false));
            }
        }
    }

    // ===============================================
    // Helmet abilities
    // ===============================================

    private void handleWaterBreathing(Player player, ItemStack stack, SimpleEnergyItem storage, boolean powered) {
        if (!player.isUnderWater() || !powered) return;

        int air = player.getAirSupply();
        if (air <= AIR_REFILL_THRESHOLD) {
            if (storage.tryUseEnergy(stack, AIR_REFILL_COST)) {
                player.setAirSupply(player.getMaxAirSupply());
            }
        }
    }

    private void handleHungerRefill(Player player, ItemStack stack, SimpleEnergyItem storage, boolean powered) {
        if (!powered) return;

        if (player.getFoodData().getFoodLevel() <= HUNGER_REFILL_THRESHOLD) {
            if (storage.tryUseEnergy(stack, HUNGER_REFILL_COST)) {
                int currentFood = player.getFoodData().getFoodLevel();
                int newFood = Math.min(20, currentFood + HUNGER_REFILL_AMOUNT);
                player.getFoodData().setFoodLevel(newFood);
                player.getFoodData().setSaturation(Math.min(newFood, player.getFoodData().getSaturationLevel() + 0.6f));
            }
        }
    }

    private void handleDebuffRemoval(Player player, ItemStack stack, SimpleEnergyItem storage, boolean powered) {
        if (!powered) return;

        // Remove Poison
        MobEffectInstance poison = player.getEffect(MobEffects.POISON);
        if (poison != null) {
            int levels = poison.getAmplifier() + 1;
            long cost = POISON_REMOVE_COST * levels;
            if (storage.tryUseEnergy(stack, cost)) {
                player.removeEffect(MobEffects.POISON);
            }
        }

        // Remove Wither
        MobEffectInstance wither = player.getEffect(MobEffects.WITHER);
        if (wither != null) {
            int levels = wither.getAmplifier() + 1;
            long cost = WITHER_REMOVE_COST * levels;
            if (storage.tryUseEnergy(stack, cost)) {
                player.removeEffect(MobEffects.WITHER);
            }
        }
    }

    private void handleNightVision(Player player, ItemStack stack, SimpleEnergyItem storage, boolean powered) {
        boolean toggled = isNightVisionToggled(player.getUUID());
        boolean paid = nightVisionPaid.getOrDefault(player.getUUID(), false);

        if (toggled) {
            if (!powered) {
                // Out of power — disable everything
                player.removeEffect(MobEffects.NIGHT_VISION);
                nightVisionToggled.remove(player.getUUID());
                nightVisionPaid.remove(player.getUUID());
                return;
            }

            if (!paid) {
                // Just toggled on — charge activation cost
                if (storage.tryUseEnergy(stack, NIGHT_VISION_COST)) {
                    nightVisionPaid.put(player.getUUID(), true);
                } else {
                    // Not enough energy — keep toggle on but don't activate yet
                    return;
                }
            }

            // Night vision active — refresh effect
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 220, 1, false, false));
        } else {
            // Toggled off — remove everything
            player.removeEffect(MobEffects.NIGHT_VISION);
            nightVisionPaid.remove(player.getUUID());
        }
    }

    // ===============================================
    // Cleanup on unequip
    // ===============================================

    public void onUnequip(Player player) {
        ArmorType slot = slotType;
        if (slot == ArmorType.CHESTPLATE) player.getAbilities().mayfly = false;
        if (slot == ArmorType.HELMET) {
            player.removeEffect(MobEffects.NIGHT_VISION);
            nightVisionToggled.remove(player.getUUID());
            nightVisionPaid.remove(player.getUUID());
        }
    }

    @Override
    public EnergyTier getEnergyTier() { return energyTier; }

    public static TooltipDisplay UNBREAKABLE_HIDE = new TooltipDisplay(
            false, new LinkedHashSet<>(Set.of(DataComponents.UNBREAKABLE))
    );
}
