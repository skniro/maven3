package com.skniro.industrial_elixir.api.data.recipe;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.fabricmc.fabric.api.recipe.v1.ingredient.DefaultCustomIngredients;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_1856;
import net.minecraft.class_2487;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9326;
import net.minecraft.class_9334;
import java.util.concurrent.CompletableFuture;

public abstract class CraftingDataHelper extends FabricRecipeProvider {

    /**
     * 26.1's RecipeProvider kept the resolved lookup in a {@code wrapperLookup} field;
     * 1.21.1 hands the future to {@code run(...)} only, so keep it here instead.
     */
    protected final CompletableFuture<class_7225.class_7874> registriesFuture;

    public CraftingDataHelper(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
        this.registriesFuture = registriesFuture;
    }

    public final class_1856 potion1(class_1842 potion) {
        class_2487 nbt = new class_2487();
        nbt.method_10582("Potion", class_7923.field_41179.method_10221(potion).toString());
        return DefaultCustomIngredients.customData(class_1856.method_8091(class_1802.field_8574), nbt);
    }

    public final class_1799 potion(class_7225.class_7874 registries, class_6880<class_1842> potion) {
        class_6880<class_1842> boundPotion;
        if (potion.method_40230().isPresent()) {
            boundPotion = registries.method_46762(class_7924.field_41215).method_46747(potion.method_40230().get());
        } else {
            boundPotion = potion;
        }
        return class_1844.method_57400(class_1802.field_8574, boundPotion);
    }

    public final class_1799 potionTemplate(class_7225.class_7874 registries, class_6880<class_1842> potion, int count) {
        class_6880<class_1842> boundPotion;
        if (potion.method_40230().isPresent()) {
            boundPotion = registries.method_46762(class_7924.field_41215).method_46747(potion.method_40230().get());
        } else {
            boundPotion = potion;
        }

        class_7225.class_7226<net.minecraft.class_1792> itemLookup = registries.method_46762(class_7924.field_41197);
        class_6880<net.minecraft.class_1792> potionItem = itemLookup.method_46747(class_1802.field_8574.method_40131().method_40237());
        class_9326 patch = class_9326.method_57841()
                .method_57854(class_9334.field_49651, new class_1844(boundPotion))
                .method_57852();
        return new class_1799(potionItem, count, patch);
    }

    public final class_1799 potionTemplate(class_7225.class_7874 registries, class_6880<class_1842> potion) {
        return potionTemplate(registries, potion, 1);
    }

}
