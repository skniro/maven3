package com.skniro.growable_ores_extension.screen;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class AlchemyScreenHandlerType <T extends class_1703>{
    public static final class_3917<AlchemyBlockScreenHandler> ALCHEMY =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "cane_converter_screen_handler"),
                    new ExtendedScreenHandlerType<>(AlchemyBlockScreenHandler::new, class_2338.field_48404));

    public static final class_3917<CoalGeneratorScreenHandler> COAL_GENERATOR_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "coal_generator_screen_handler"),
                    new ExtendedScreenHandlerType<>(CoalGeneratorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<MaceratorScreenHandler> Macerator =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "macerato_screen_handler"),
                    new ExtendedScreenHandlerType<>(MaceratorScreenHandler::new, class_2338.field_48404));

    public static void registeralchemyscreenhandlertype () {

    }
}
