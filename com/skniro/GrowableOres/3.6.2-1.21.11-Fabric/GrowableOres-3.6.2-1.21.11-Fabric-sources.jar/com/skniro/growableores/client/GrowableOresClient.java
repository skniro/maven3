package com.skniro.growableores.client;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.class_11515;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

@Environment(EnvType.CLIENT)
public class GrowableOresClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_7923.field_41175.forEach(block -> {
            class_2960 blockId = class_7923.field_41175.method_10221(block);
            if (blockId.method_12836().equals(GrowableOres.MOD_ID)) {
                BlockRenderLayerMap.putBlock(block, class_11515.field_60925);
            }
        });
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Coal_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Iron_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Diamond_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Copper_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Emerald_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Gold_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Lapis_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Nether_Quartz_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Redstone_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Blaze_Rod_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Ender_Pearl_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Netherite_Ingot_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Clay_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Slime_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Nether_Star_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Glowstone_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Bone_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Egg_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Wool_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Feather_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableVanillaOresBlocks.Gunpowder_Cane, class_11515.field_60925);

        //ae2
        BlockRenderLayerMap.putBlock(GrowableAEOresBlocks.certus_quartz_crystal_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableAEOresBlocks.fluix_crystal_Cane, class_11515.field_60925);

        //Tech Reborn
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.cinnabar_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.galena_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.iridium_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.lead_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.peridot_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.pyrite_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.ruby_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.sapphire_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.sheldonite_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.silver_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.sphalerite_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.tin_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.tungsten_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.sodalite_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableTechRebornOresBlocks.bauxite_Cane, class_11515.field_60925);


        //BetterEnd
        BlockRenderLayerMap.putBlock(GrowableBetterEndOresBlocks.amber_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableBetterEndOresBlocks.ender_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableBetterEndOresBlocks.thallasium_Cane, class_11515.field_60925);


        //Maple
        BlockRenderLayerMap.putBlock(GrowableMapleOresBlocks.Salt_Cane, class_11515.field_60925);

        //Powah Rearchitected and Powah
        BlockRenderLayerMap.putBlock(GrowablePowahOresBlocks.Steel_Energized_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowablePowahOresBlocks.Uraninite_Ore_Dense_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowablePowahOresBlocks.Ender_Core_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowablePowahOresBlocks.Crystal_Spirited_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowablePowahOresBlocks.Crystal_Nitro_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowablePowahOresBlocks.Crystal_Niotic_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowablePowahOresBlocks.Crystal_Blazing_Cane, class_11515.field_60925);

        //Industrial Revolution
        BlockRenderLayerMap.putBlock(GrowableIndustrialRevolutionOresBlocks.IR_Lead_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableIndustrialRevolutionOresBlocks.IR_nikolite_Cane , class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableIndustrialRevolutionOresBlocks.IR_silver_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableIndustrialRevolutionOresBlocks.IR_tin_ore_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableIndustrialRevolutionOresBlocks.IR_tungsten_Cane, class_11515.field_60925);

        //Modern Industrialization
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_antimony_Cane , class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_bauxite_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_iridium_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_lead_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_lignite_coal_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_monazite_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_nickel_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_platinum_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_quartz_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_salt_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_tin_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_titanium_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_tungsten_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableModernIndustrializationOresBlocks.MI_uranium_Cane, class_11515.field_60925);

        //ic2 and ic2c
        BlockRenderLayerMap.putBlock(GrowableICOresBlocks.IC2_Aluminium_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableICOresBlocks.IC2_silver_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableICOresBlocks.IC2_Tin_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableICOresBlocks.IC2_Uranium_Cane, class_11515.field_60925);

        //Ad Astra!
        BlockRenderLayerMap.putBlock(GrowableAdAstraOresBlocks.AD_Ostrum_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableAdAstraOresBlocks.AD_Ice_Shard_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableAdAstraOresBlocks.AD_Cheese_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableAdAstraOresBlocks.AD_Desh_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableAdAstraOresBlocks.AD_Calorite_Cane, class_11515.field_60925);

        //Create
        BlockRenderLayerMap.putBlock(GrowableCreateOresBlocks.C_Andesite_Alloy_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableCreateOresBlocks.C_Brass_Ingot_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableCreateOresBlocks.C_Polished_Rose_Quartz_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableCreateOresBlocks.C_Zinc_Cane, class_11515.field_60925);

        //Thermal Series
        BlockRenderLayerMap.putBlock(GrowableThermalSeriesOresBlocks.TF_Apatite_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableThermalSeriesOresBlocks.TF_Cinnabar_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableThermalSeriesOresBlocks.TF_Copper_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableThermalSeriesOresBlocks.TF_Lead_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableThermalSeriesOresBlocks.TF_Nickel_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableThermalSeriesOresBlocks.TF_Niter_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableThermalSeriesOresBlocks.TF_Ruby_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableThermalSeriesOresBlocks.TF_Sapphire_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableThermalSeriesOresBlocks.TF_Silver_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableThermalSeriesOresBlocks.TF_Sulfur_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableThermalSeriesOresBlocks.TF_Tin_Cane, class_11515.field_60925);

        //Mekanism
        BlockRenderLayerMap.putBlock(GrowableMekanismOresBlocks.MEK_Fluorite_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableMekanismOresBlocks.MEK_Lead_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableMekanismOresBlocks.MEK_Osmium_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableMekanismOresBlocks.MEK_Tin_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableMekanismOresBlocks.MEK_Uranium_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableMekanismOresBlocks.MEK_Steel_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableMekanismOresBlocks.MEK_Refined_Obsidian_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableMekanismOresBlocks.MEK_Refined_Glowstone_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableMekanismOresBlocks.MEK_Bronze_Cane, class_11515.field_60925);

        //BetterNether
        BlockRenderLayerMap.putBlock(GrowableBetterNetherOresBlocks.BN_Cincinnasite_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableBetterNetherOresBlocks.BN_Nether_Ruby_Cane, class_11515.field_60925);

        //EnergizedPower
        BlockRenderLayerMap.putBlock(GrowableEnergizedPowerOresBlocks.EP_Advanced_Alloy_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableEnergizedPowerOresBlocks.EP_Energized_Copper_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableEnergizedPowerOresBlocks.EP_Energized_Gold_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableEnergizedPowerOresBlocks.EP_Redstone_Alloy_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableEnergizedPowerOresBlocks.EP_Steel_Cane, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(GrowableEnergizedPowerOresBlocks.EP_Tin_Cane, class_11515.field_60925);


    }
}
