package com.skniro.industrial_elixir.block.init.pipe;

import com.mojang.serialization.MapCodec;
import com.skniro.industrial_elixir.block.entity.pipe.WoodFluidPipeBlockEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class WoodFluidPipeBlock extends WoodPipeBlock {
    public WoodFluidPipeBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new WoodFluidPipeBlockEntity(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return (world1, pos, state1, blockEntity) -> ((WoodFluidPipeBlockEntity) blockEntity).tick(world1, pos, state1);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        throw new IllegalStateException("PipeBlock does not support getCodec!");
    }
}
