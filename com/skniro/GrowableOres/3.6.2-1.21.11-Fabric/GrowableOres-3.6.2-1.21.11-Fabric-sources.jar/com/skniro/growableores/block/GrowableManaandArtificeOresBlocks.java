package com.skniro.growableores.block;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.init.GrowableOreCaneBlock;
import com.skniro.growableores.util.GrowableOresItemGroups;
import java.util.function.Function;
import java.util.logging.Logger;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class GrowableManaandArtificeOresBlocks {
    //ManaandArtifice
    public static final class_2248 MA_Animus_Dust_Cane = registerBlock("ma_animus_dust_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Arcane_Ash_Cane = registerBlock("ma_arcane_ash_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Bone_Ash_Cane = registerBlock("ma_bone_ash_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Ironbark_Cane = registerBlock("ma_ironbark_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Living_Flame_Cane = registerBlock("ma_living_flame_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Mote_Air_Cane = registerBlock("ma_mote_air_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Mote_Arcane_Cane = registerBlock("ma_mote_arcane_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Mote_Earth_Cane = registerBlock("ma_mote_earth_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Mote_Ender_Cane = registerBlock("ma_mote_ender_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Mote_Fire_Cane = registerBlock("ma_mote_fire_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Mote_Water_Cane = registerBlock("ma_mote_water_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Purified_Vinteum_Dust_Cane = registerBlock("ma_purified_vinteum_dust_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Purified_Vinteum_Ingot_Cane = registerBlock("ma_purified_vinteum_ingot_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Resonating_Dust_Cane = registerBlock("ma_resonating_dust_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Superheated_Purified_Vinteum_Ingot_Cane = registerBlock("ma_superheated_purified_vinteum_ingot_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Superheated_Vinteum_Ingot_Cane = registerBlock("ma_superheated_vinteum_ingot_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Vinteum_Dust_Cane = registerBlock("ma_vinteum_dust_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 MA_Vinteum_Ingot_Cane = registerBlock("ma_vinteum_ingot_cane", GrowableOreCaneBlock::new ,class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535).method_50012(class_3619.field_15971),GrowableOresItemGroups.Growable_Ores_Group);

    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings, class_5321<class_1761> tab) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GrowableOres.MOD_ID, name))));
        registerBlockItem(name, block, tab);
        return class_2378.method_39197(class_7923.field_41175, class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GrowableOres.MOD_ID, name)), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_5321<class_1761> tab) {
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOres.MOD_ID, name)),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOres.MOD_ID, name)))));
    }
    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + GrowableOres.MOD_ID);
    }
}

