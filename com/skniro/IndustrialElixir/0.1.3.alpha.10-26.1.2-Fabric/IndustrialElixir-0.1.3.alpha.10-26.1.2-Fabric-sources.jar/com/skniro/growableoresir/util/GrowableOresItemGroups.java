package com.skniro.growableoresir.util;

import com.skniro.industrial_elixir.item.ModCreativeTab;
import com.skniro.growableoresir.block.GrowableICOresBlocks;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;

public class GrowableOresItemGroups {
    public static void ic_item() {
        CreativeModeTabEvents.modifyOutputEvent(ModCreativeTab.Materials).register(content -> {
            content.accept(GrowableICOresBlocks.IC2_Bronze_Cane);
            content.accept(GrowableICOresBlocks.IC2_silver_Cane);
            content.accept(GrowableICOresBlocks.IC2_Tin_Cane);
            content.accept(GrowableICOresBlocks.IC2_Uranium_Cane);
            content.accept(GrowableICOresBlocks.IC2_steel_Cane);
            content.accept(GrowableICOresBlocks.IC2_LEAD_Cane);
        });
    }
}
