package com.skniro.blackhold.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11515;

@Environment(EnvType.CLIENT)
public class MapleClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

        class_11515 renderLayer2 = class_11515.field_60927;

        class_11515 renderLayer3 = class_11515.field_60925;



        class_11515 renderLayer4 = class_11515.field_60926;
    }
}
