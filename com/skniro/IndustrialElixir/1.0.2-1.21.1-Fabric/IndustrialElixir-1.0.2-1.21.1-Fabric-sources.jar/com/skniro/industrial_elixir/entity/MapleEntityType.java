package com.skniro.industrial_elixir.entity;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1690;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7264;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class MapleEntityType {
    public static final class_1299<class_1690> RUBBER_BOAT = register("rubber_boat", class_1299.class_1300.<class_1690>method_5903((type, world) ->
            new RubberBoat(type, world, () -> GrowableOresItems.RUBBER_BOAT), class_1311.field_17715).method_17687(1.375F, 0.5625F).method_55687(0.5625F).method_27299(10));

    public static final class_1299<class_7264> RUBBER_CHEST_BOAT = register("rubber_chest_boat", class_1299.class_1300.<class_7264>method_5903((type, world) ->
            new RubberChestBoat(type, world, () -> GrowableOresItems.RUBBER_CHEST_BOAT), class_1311.field_17715).method_17687(1.375F, 0.5625F).method_55687(0.5625F).method_27299(10));

    private static <T extends class_1297> class_1299<T> register(String name, class_1299.class_1300<T> builder) {
        return class_2378.method_39197(class_7923.field_41177, keyOf(name), builder.method_5905(name));
    }

    private static class_5321<class_1299<?>> keyOf(String name) {
        return class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(IndustrialElixir.MOD_ID, name));
    }

    public static void registerMapleEntityType() {
        IndustrialElixir.LOGGER.debug("Registering MapleEntityType for " + IndustrialElixir.MOD_ID);
    }
}
