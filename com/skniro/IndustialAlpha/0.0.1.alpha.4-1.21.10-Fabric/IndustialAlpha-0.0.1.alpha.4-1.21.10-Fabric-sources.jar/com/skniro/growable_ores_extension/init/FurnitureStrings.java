package com.skniro.growable_ores_extension.init;

public class FurnitureStrings {
    public static final String Macerator = "gui.growable_ores_extension.macerator";
    public static final String CaneConverter = "gui.growableores.cane_converter";
    public static final String GeneratorWindMill = "gui.growableores.generator_wind_mill";
    public static final String Compressor = "gui.growable_ores_extension.compressor";
}
