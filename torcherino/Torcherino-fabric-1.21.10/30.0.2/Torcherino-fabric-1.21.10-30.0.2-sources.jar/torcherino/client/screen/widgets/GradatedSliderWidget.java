package torcherino.client.screen.widgets;

import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_3532;
import net.minecraft.class_357;
import org.lwjgl.glfw.GLFW;

public abstract class GradatedSliderWidget extends class_357 {
    private final float nudgeAmount;

    protected GradatedSliderWidget(int x, int y, int width, double progress, int permutations) {
        super(x, y, width, 20, class_2561.method_43473(), progress);
        nudgeAmount = 1.0F / permutations;
        this.method_25346();
    }

    @Override
    public boolean method_25404(class_11908 keyCode) {
        boolean pressedLeft = keyCode.method_74232();
        if (pressedLeft || keyCode.method_74233()) {
            this.method_25347(this.field_22753 + (pressedLeft ? -nudgeAmount : nudgeAmount));
        }
        return false;
    }

    private void method_25347(double newValue) {
        double currentValue = this.field_22753;
        field_22753 = class_3532.method_15350(newValue, 0, 1);
        if (currentValue != this.field_22753) {
            this.method_25344();
        }
        this.method_25346();
    }
}
