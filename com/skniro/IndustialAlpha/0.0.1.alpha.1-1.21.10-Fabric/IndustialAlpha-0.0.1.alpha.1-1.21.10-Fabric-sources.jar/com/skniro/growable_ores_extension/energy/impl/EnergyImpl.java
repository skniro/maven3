package com.skniro.growable_ores_extension.energy.impl;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.base.SimpleEnergyItem;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9135;
import net.minecraft.class_9331;
import org.jetbrains.annotations.ApiStatus;


@ApiStatus.Internal
public class EnergyImpl {
	public static final class_9331<Long> ENERGY_COMPONENT = class_9331.<Long>method_57873()
			.method_57881(nonNegativeLong())
			.method_57882(class_9135.field_48551)
			.method_57880();

	public static void init() {
		class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(GrowableOresExtension.MOD_ID, "energy"), ENERGY_COMPONENT);
		EnergyStorage.ITEM.registerFallback((stack, ctx) -> {
			if (stack.method_7909() instanceof SimpleEnergyItem energyItem) {
				return SimpleEnergyItem.createStorage(ctx, energyItem.getEnergyCapacity(stack), energyItem.getEnergyMaxInput(stack), energyItem.getEnergyMaxOutput(stack));
			} else {
				return null;
			}
		});
	}

	private static Codec<Long> nonNegativeLong() {
		return Codec.LONG.validate((Long value) -> {
			if (value >= 0) {
				return DataResult.success(value);
			}

			return DataResult.error(() -> "Energy value must be non-negative: " + value);
		});
	}
}
