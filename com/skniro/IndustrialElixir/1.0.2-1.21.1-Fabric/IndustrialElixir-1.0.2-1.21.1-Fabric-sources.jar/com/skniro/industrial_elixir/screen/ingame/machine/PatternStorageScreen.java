package com.skniro.industrial_elixir.screen.ingame.machine;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.block.entity.machine.PatternStorageBlockEntity;
import com.skniro.industrial_elixir.screen.handler.machine.PatternStorageScreenHandler;
import com.skniro.industrial_elixir.util.MouseUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_7923;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class PatternStorageScreen extends class_465<PatternStorageScreenHandler> {
    private static final class_2960 TEXTURE =
            class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/machine/pattern_storage.png");

    private class_4185 copyButton;

    public PatternStorageScreen(PatternStorageScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
        field_25269 = 8;
        field_25270 = 72;

        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        this.copyButton = class_4185.method_46430(class_2561.method_43471("gui.industrial_elixir.pattern_storage.copy"),
                this::onCopyButtonPressed)
                .method_46434(x + 87, y + 18, 40, 14)
                .method_46431();
        this.method_37063(this.copyButton);
    }

    private void onCopyButtonPressed(class_4185 button) {
        if (this.field_22787 != null && this.field_22787.field_1761 != null) {
            this.field_22787.field_1761.method_2900(
                    this.field_2797.field_7763, PatternStorageScreenHandler.COPY_BUTTON_ID);
        }
    }

    @Override
    protected void method_37432() {
        super.method_37432();
        class_1799 sourceCrystal = this.field_2797.blockEntity.inventory.get(1);
        class_1799 targetCrystal = this.field_2797.blockEntity.inventory.get(10);
        boolean canCopy = PatternStorageBlockEntity.hasPatternData(sourceCrystal)
                && !targetCrystal.method_7960()
                && !PatternStorageBlockEntity.hasPatternData(targetCrystal);
        this.copyButton.field_22763 = canCopy;
    }

    public List<class_2561> getEnergyTooltip() {
        return List.of(class_2561.method_43470(
                NumberFormat.getNumberInstance(Locale.US).format(field_2797.blockEntity.energyContainer.amount)
                + " / "
                + NumberFormat.getNumberInstance(Locale.US).format(field_2797.blockEntity.energyContainer.getCapacity())
                + " E"));
    }

    private void renderEnergyTooltip(class_332 context, int pMouseX, int pMouseY, int x, int y) {
        if (MouseUtil.isMouseOver(pMouseX, pMouseY, x + 130, y + 44, 13, 16)) {
            context.method_51437(Screens.getTextRenderer(this), getEnergyTooltip(),
                    Optional.empty(), pMouseX, pMouseY);
        }
    }

    private void renderEnergyArea(class_332 context, int x, int y) {
        context.method_25290(TEXTURE, x + 130, y + 44, 176, 0, 13, field_2797.getScaledEnergyHeight(), 256, 256);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        renderEnergyTooltip(context, mouseX, mouseY, x, y);
        renderScanResultTooltip(context, mouseX, mouseY, x, y);

        context.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, -12566464, false);
        context.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, -12566464, false);

        renderScanResult(context, x, y);
    }

    private void renderScanResult(class_332 context, int x, int y) {
        PatternStorageBlockEntity be = this.field_2797.blockEntity;
        class_2960 scannedId = be.getScannedItemId();

        if (scannedId != null) {
            class_1792 item = class_7923.field_41178.method_17966(scannedId).orElse(null);
            if (item != null) {
                class_1799 stack = new class_1799(item);
                context.method_51427(stack, x + 103, y + 34);
            }

            String uuText = "UU: " + be.getUUCost() + " mB";
            String energyText = "EU: " + NumberFormat.getNumberInstance(Locale.US).format(be.getEnergyCost());

            context.method_51433(this.field_22793, uuText, x + 80, y + 54, 0x8888FF, false);
            context.method_51433(this.field_22793, energyText, x + 80, y + 64, 0xFF4444, false);
        }
    }

    private void renderScanResultTooltip(class_332 context, int mouseX, int mouseY, int x, int y) {
        PatternStorageBlockEntity be = this.field_2797.blockEntity;
        class_2960 scannedId = be.getScannedItemId();

/*        if (scannedId != null && MouseUtil.isMouseOver(mouseX, mouseY, x + 103, y + 34, 16, 16)) {
            Item item = BuiltInRegistries.ITEM.getOptional(scannedId).orElse(null);
            if (item != null) {
                context.renderTooltip(Screens.getTextRenderer(this),
                        List.of(Component.literal(item.getDescriptionId().toString())),
                        Optional.empty(), mouseX - x, mouseY - y);
            }
        }*/

   /*     if (scannedId != null && MouseUtil.isMouseOver(mouseX, mouseY, x + 80, y + 54, 80, 8)) {
            context.renderTooltip(this.font,
                    List.of(Component.translatable("gui.industrial_elixir.pattern_storage.uu_tooltip")), Optional.empty(), mouseX - x, mouseY - y);
        }

        if (scannedId != null && MouseUtil.isMouseOver(mouseX, mouseY, x + 80, y + 64, 80, 8)) {
            context.renderTooltip(this.font,
                    List.of(Component.translatable("gui.industrial_elixir.pattern_storage.energy_tooltip")), Optional.empty(), mouseX - x, mouseY - y);
        }*/
    }

    @Override
    protected void method_2389(class_332 context, float partialTicks, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        context.method_25290(TEXTURE, x, y, 0, 0, field_2792, field_2779, 256, 256);
        renderProgressArrow(context, x, y);
        renderEnergyArea(context, x, y);
        renderScanResultArea(context, x, y);
    }

    private void renderProgressArrow(class_332 context, int x, int y) {
        if (field_2797.isCrafting()) {
            context.method_25290(TEXTURE, x + 45, y + 35, 190, 0, field_2797.getScaledProgress(), 15, 256, 256);
        }
    }

    private void renderScanResultArea(class_332 context, int x, int y) {
        PatternStorageBlockEntity be = this.field_2797.blockEntity;
        if (be.getScannedItemId() != null) {
            context.method_25290(TEXTURE, x + 98, y + 29, 176, 28, 26, 26, 256, 256);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }
}
