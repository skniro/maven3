package com.skniro.usefulfood.datagen;

import com.google.common.collect.Lists;
import com.skniro.usefulfood.block.UsefulFoodCakeBlocks;
import com.skniro.usefulfood.block.UsefulFoodJamBlocks;
import com.skniro.usefulfood.item.UsefulFoodItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.fabricmc.fabric.api.tag.FabricTagKey;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.minecraft.class_156;
import net.minecraft.class_1802;
import net.minecraft.class_1865;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2446;
import net.minecraft.class_3489;
import net.minecraft.class_3862;
import net.minecraft.class_3920;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class UsefulFoodRecipeGenerator extends FabricRecipeProvider {
    public UsefulFoodRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected class_2446 method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new class_2446(wrapperLookup, exporter) {
            @Override
            public void method_10419() {
                method_62750(class_7800.field_40640,UsefulFoodItems.MilkBottle,1).method_10449(class_1802.field_8469,1).method_10454(class_1802.field_8103).method_10442("has_base_item", method_10426(class_1802.field_8103)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.ChocolateMilkBottle).method_10454(class_1802.field_8116).method_10454(class_1802.field_8469).method_10454(UsefulFoodItems.MilkBottle).method_10442("has_base_item", method_10426(UsefulFoodItems.MilkBottle)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Cheese).method_10454(UsefulFoodItems.HotMilkBottle).method_10442("has_base_item", method_10426(UsefulFoodItems.HotMilkBottle)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.SugarCube).method_10449(class_1802.field_8479,2).method_10442("has_base_item", method_10426(class_1802.field_8479)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.caramelapple).method_10454(class_1802.field_8279).method_10454(class_1802.field_8600).method_10454(UsefulFoodItems.caramel).method_10442("has_base_item", method_10426(UsefulFoodItems.caramel)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.PumpkinSoup).method_10454(class_1802.field_8428).method_10454(class_1802.field_17518).method_10442("has_base_item", method_10426(class_1802.field_8428)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Salad).method_10454(class_1802.field_8880).method_10454(class_1802.field_8491).method_10454(class_1802.field_8317).method_10454(class_1802.field_8428).method_10442("has_base_item", method_10426(class_1802.field_8428)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Marshmallow).method_10449(class_1802.field_8479,3).method_10454(class_1802.field_8428).method_10454(class_1802.field_8705).method_10454(class_1802.field_8600).method_10442("has_base_item", method_10426(class_1802.field_8428)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.VanillaIceCream).method_10454(class_1802.field_8543).method_10454(class_1802.field_8479).method_10454(class_1802.field_8428).method_10454(UsefulFoodItems.MilkBottle).method_10442("has_base_item", method_10426(class_1802.field_8428)).method_10431(field_53721);
                method_62750(class_7800.field_40640,UsefulFoodItems.BreadSlice,5).method_10454(class_1802.field_8229).method_10442("has_base_item", method_10426(class_1802.field_8229)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.PorkWich).method_10449(UsefulFoodItems.BreadSlice,2).method_10454(class_1802.field_8261).method_10442("has_base_item", method_10426(UsefulFoodItems.BreadSlice)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Steakwich).method_10449(UsefulFoodItems.BreadSlice,2).method_10454(class_1802.field_8176).method_10442("has_base_item", method_10426(UsefulFoodItems.BreadSlice)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Chickenwich).method_10449(UsefulFoodItems.BreadSlice,2).method_10454(class_1802.field_8544).method_10442("has_base_item", method_10426(UsefulFoodItems.BreadSlice)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Eggwich).method_10449(UsefulFoodItems.BreadSlice,2).method_10454(UsefulFoodItems.FriedEgg).method_10442("has_base_item", method_10426(UsefulFoodItems.BreadSlice)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Biscuit).method_10449(class_1802.field_8861,2).method_10442("has_base_item",method_10426(class_1802.field_8861)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.MuttonSandwich).method_10454(class_1802.field_8347).method_10449(UsefulFoodItems.BreadSlice,2).method_10442("has_base_item", method_10426(UsefulFoodItems.BreadSlice)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.SquidSandwich).method_10454(UsefulFoodItems.SquidTentacleCooked).method_10449(UsefulFoodItems.BreadSlice,2).method_10442("has_base_item", method_10426(UsefulFoodItems.BreadSlice)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.MagicAppleJuice).method_10449(class_1802.field_8463,2).method_10454(class_1802.field_8367).method_10454(class_1802.field_8469).method_10442("has_base_item", method_10426(class_1802.field_8463)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.MelonJuice).method_10449(class_1802.field_8497,3).method_10454(class_1802.field_8469).method_10442("has_base_item", method_10426(class_1802.field_8497)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.AppleJuice).method_10449(class_1802.field_8279,3).method_10454(class_1802.field_8469).method_10442("has_base_item", method_10426(class_1802.field_8279)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.CarrotJuice).method_10449(class_1802.field_8179,3).method_10454(class_1802.field_8469).method_10442("has_base_item", method_10426(class_1802.field_8179)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.CarrotSoup).method_10449(class_1802.field_8179,2).method_10454(class_1802.field_8428).method_10442("has_base_item", method_10426(class_1802.field_8428)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.PumpkinBread).method_10454(class_1802.field_17518).method_10454(class_1802.field_8861).method_10442("has_base_item", method_10426(class_1802.field_8861)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.SugarBiscuit).method_10454(class_1802.field_8479).method_10454(UsefulFoodItems.Biscuit).method_10442("has_base_item", method_10426(class_1802.field_8479)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.AppleJamBiscuit).method_10454(UsefulFoodItems.Biscuit).method_10454(UsefulFoodItems.AppleJam).method_10442("has_base_item", method_10426(UsefulFoodItems.Biscuit)).method_10431(field_53721);
                method_62750(class_7800.field_40640,UsefulFoodItems.ChocoBiscuit,2).method_10449(UsefulFoodItems.Biscuit,2).method_10454(UsefulFoodItems.hotchocolatebottle).method_10442("has_base_item", method_10426(UsefulFoodItems.Biscuit)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.CarrotPie).method_10454(class_1802.field_8803).method_10454(class_1802.field_8179).method_10454(class_1802.field_8479).method_10454(class_1802.field_8861).method_10442("has_base_item", method_10426(class_1802.field_8479)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.chocolateicecream).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(UsefulFoodItems.ChocolateCandy).method_10442("has_base_item", method_10426(UsefulFoodItems.ChocolateCandy)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.MagicIceCream).method_10449(class_1802.field_8597,2).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(class_1802.field_8463).method_10442("has_base_item", method_10426(UsefulFoodItems.VanillaIceCream)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.SquidSushi).method_10454(UsefulFoodItems.SquidTentacleRaw).method_10454(class_1802.field_17524).method_10442("has_base_item",method_10426(class_1802.field_17524)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.CactusJuice).method_10449(class_1802.field_17520,3).method_10454(class_1802.field_8469).method_10442("has_base_item", method_10426(class_1802.field_17520)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Spaghetti).method_10454(class_1802.field_8428).method_10454(class_1802.field_8705).method_10454(class_1802.field_8803).method_10454(class_1802.field_8861).method_10442("has_base_item", method_10426(class_1802.field_8861)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.AppleIceCream).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(class_1802.field_8279).method_10442("has_base_item", method_10426(class_1802.field_8279)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.MelonIceCream).method_10454(UsefulFoodItems.VanillaIceCream).method_10449(class_1802.field_8497,3).method_10442("has_base_item", method_10426(class_1802.field_8497)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.ChocolateApple).method_10454(UsefulFoodItems.hotchocolatebottle).method_10454(class_1802.field_8279).method_10454(class_1802.field_8600).method_10442("has_base_item", method_10426(class_1802.field_8279)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.CaramelBiscuit).method_10454(UsefulFoodItems.caramel).method_10454(UsefulFoodItems.Biscuit).method_10442("has_base_item", method_10426(UsefulFoodItems.Biscuit)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.CheeseSandwich).method_10449(UsefulFoodItems.BreadSlice,2).method_10454(UsefulFoodItems.Cheese).method_10442("has_base_item",method_10426(UsefulFoodItems.Cheese)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.CaramelIceCream).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(UsefulFoodItems.caramel).method_10442("has_base_item",method_10426(UsefulFoodItems.caramel)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Cereal).method_10454(class_1802.field_8861).method_10454(class_1802.field_8428).method_10454(class_1802.field_8479).method_10454(UsefulFoodItems.MilkBottle).method_10442("has_base_item",method_10426(UsefulFoodItems.MilkBottle)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.ChocolateCereal).method_10454(class_1802.field_8861).method_10454(class_1802.field_8428).method_10454(class_1802.field_8479).method_10454(UsefulFoodItems.MilkBottle).method_10454(class_1802.field_8116).method_10442("has_base_item",method_10426(UsefulFoodItems.MilkBottle)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Oatmeal).method_10449(class_1802.field_8317,6).method_10454(class_1802.field_8428).method_10442("has_base_item",method_10426(class_1802.field_8428)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Jelly).method_10454(class_1802.field_8777).method_10454(class_1802.field_8479).method_10454(class_1802.field_8428).method_10442("has_base_item",method_10426(class_1802.field_8428)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.AppleJelly).method_10454(UsefulFoodItems.Jelly).method_10454(class_1802.field_8279).method_10442("has_base_item",method_10426(UsefulFoodItems.Jelly)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.MelonJelly).method_10454(UsefulFoodItems.Jelly).method_10454(class_1802.field_8497).method_10442("has_base_item",method_10426(UsefulFoodItems.Jelly)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Donut).method_10454(UsefulFoodItems.MilkBottle).method_10449(class_1802.field_8861,2).method_10454(class_1802.field_8116).method_10454(class_1802.field_8479).method_10442("has_base_item",method_10426(class_1802.field_8479)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Oreo).method_10449(UsefulFoodItems.ChocoBiscuit,2).method_10449(class_1802.field_8479,2).method_10454(UsefulFoodItems.MilkBottle).method_10442("has_base_item",method_10426(UsefulFoodItems.MilkBottle)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.CaramelToast).method_10454(UsefulFoodItems.BreadSlice).method_10454(UsefulFoodItems.caramel).method_10442("has_base_item",method_10426(UsefulFoodItems.caramel)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.SugarToast).method_10454(UsefulFoodItems.BreadSlice).method_10454(class_1802.field_8479).method_10442("has_base_item",method_10426(class_1802.field_8479)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.SugarPancake).method_10454(UsefulFoodItems.PanCake).method_10454(class_1802.field_8479).method_10442("has_base_item",method_10426(class_1802.field_8479)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.AppleJamPanCake).method_10454(UsefulFoodItems.PanCake).method_10454(UsefulFoodItems.AppleJam).method_10442("has_base_item",method_10426(UsefulFoodItems.PanCake)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.AppleJamToast).method_10454(UsefulFoodItems.BreadSlice).method_10454(UsefulFoodItems.AppleJam).method_10442("has_base_item",method_10426(UsefulFoodItems.AppleJam)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.AppleJam).method_10454(class_1802.field_8428).method_10454(class_1802.field_8479).method_10454(class_1802.field_8279).method_10442("has_base_item",method_10426(class_1802.field_8279)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.CaramelPanCake).method_10454(UsefulFoodItems.caramel).method_10454(UsefulFoodItems.PanCake).method_10442("has_base_item",method_10426(UsefulFoodItems.PanCake)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.ChocolatePanCake).method_10454(UsefulFoodItems.ChocolateCandy).method_10454(UsefulFoodItems.PanCake).method_10442("has_base_item",method_10426(UsefulFoodItems.PanCake)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.MelonJamPanCake).method_10454(UsefulFoodItems.MelonJam).method_10454(UsefulFoodItems.PanCake).method_10442("has_base_item",method_10426(UsefulFoodItems.PanCake)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.MelonJamToast).method_10454(UsefulFoodItems.MelonJam).method_10454(UsefulFoodItems.BreadSlice).method_10442("has_base_item",method_10426(UsefulFoodItems.BreadSlice)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.MelonJamBiscuit).method_10454(UsefulFoodItems.MelonJam).method_10454(UsefulFoodItems.Biscuit).method_10442("has_base_item",method_10426(UsefulFoodItems.Biscuit)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.MelonJam).method_10454(class_1802.field_8497).method_10454(class_1802.field_8428).method_10454(class_1802.field_8479).method_10442("has_base_item",method_10426(class_1802.field_8479)).method_10431(field_53721);

                method_62749(class_7800.field_40640,UsefulFoodItems.Chorus_Jelly).method_10454(UsefulFoodItems.Jelly).method_10454(class_1802.field_8233).method_10442("has_base_item",method_10426(UsefulFoodItems.Jelly)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Glow_Berries_Jelly).method_10454(UsefulFoodItems.Jelly).method_10454(class_1802.field_28659).method_10442("has_base_item",method_10426(UsefulFoodItems.Jelly)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Sweet_Berries_Jelly).method_10454(UsefulFoodItems.Jelly).method_10454(class_1802.field_16998).method_10442("has_base_item",method_10426(UsefulFoodItems.Jelly)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Chorus_Ice_Cream).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(class_1802.field_8233).method_10442("has_base_item", method_10426(class_1802.field_8233)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Glow_Berries_Ice_Cream).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(class_1802.field_28659).method_10442("has_base_item", method_10426(class_1802.field_28659)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Sweet_Berries_Ice_Cream).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(class_1802.field_16998).method_10442("has_base_item", method_10426(class_1802.field_16998)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Chorus_Juice).method_10449(class_1802.field_8233,3).method_10454(class_1802.field_8469).method_10442("has_base_item", method_10426(class_1802.field_8233)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Glow_Berries_Juice).method_10449(class_1802.field_28659,3).method_10454(class_1802.field_8469).method_10442("has_base_item", method_10426(class_1802.field_28659)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Sweet_Berries_Juice).method_10449(class_1802.field_16998,3).method_10454(class_1802.field_8469).method_10442("has_base_item", method_10426(class_1802.field_16998)).method_10431(field_53721);

                method_62749(class_7800.field_40640,UsefulFoodItems.Glow_Berries_JamPanCake).method_10454(UsefulFoodItems.Glow_Berries_Jam).method_10454(UsefulFoodItems.PanCake).method_10442("has_base_item",method_10426(UsefulFoodItems.PanCake)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Glow_Berries_JamToast).method_10454(UsefulFoodItems.Glow_Berries_Jam).method_10454(UsefulFoodItems.BreadSlice).method_10442("has_base_item",method_10426(UsefulFoodItems.BreadSlice)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Glow_Berries_JamBiscuit).method_10454(UsefulFoodItems.Glow_Berries_Jam).method_10454(UsefulFoodItems.Biscuit).method_10442("has_base_item",method_10426(UsefulFoodItems.Biscuit)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Glow_Berries_Jam).method_10454(class_1802.field_28659).method_10454(class_1802.field_8428).method_10454(class_1802.field_8479).method_10442("has_base_item",method_10426(class_1802.field_8479)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Sweet_Berries_JamPanCake).method_10454(UsefulFoodItems.Sweet_Berries_Jam).method_10454(UsefulFoodItems.PanCake).method_10442("has_base_item",method_10426(UsefulFoodItems.PanCake)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Sweet_Berries_JamToast).method_10454(UsefulFoodItems.Sweet_Berries_Jam).method_10454(UsefulFoodItems.BreadSlice).method_10442("has_base_item",method_10426(UsefulFoodItems.BreadSlice)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Sweet_Berries_JamBiscuit).method_10454(UsefulFoodItems.Sweet_Berries_Jam).method_10454(UsefulFoodItems.Biscuit).method_10442("has_base_item",method_10426(UsefulFoodItems.Biscuit)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Sweet_Berries_Jam).method_10454(class_1802.field_16998).method_10454(class_1802.field_8428).method_10454(class_1802.field_8479).method_10442("has_base_item",method_10426(class_1802.field_8479)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Chorus_JamPanCake).method_10454(UsefulFoodItems.Chorus_Jam).method_10454(UsefulFoodItems.PanCake).method_10442("has_base_item",method_10426(UsefulFoodItems.PanCake)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Chorus_JamToast).method_10454(UsefulFoodItems.Chorus_Jam).method_10454(UsefulFoodItems.BreadSlice).method_10442("has_base_item",method_10426(UsefulFoodItems.BreadSlice)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Chorus_JamBiscuit).method_10454(UsefulFoodItems.Chorus_Jam).method_10454(UsefulFoodItems.Biscuit).method_10442("has_base_item",method_10426(UsefulFoodItems.Biscuit)).method_10431(field_53721);
                method_62749(class_7800.field_40640,UsefulFoodItems.Chorus_Jam).method_10454(class_1802.field_8233).method_10454(class_1802.field_8428).method_10454(class_1802.field_8479).method_10442("has_base_item",method_10426(class_1802.field_8479)).method_10431(field_53721);

                method_62749(class_7800.field_40640, UsefulFoodJamBlocks.Chorus_JAM_JAR).method_10449(UsefulFoodItems.Chorus_Jam,3).method_10454(UsefulFoodJamBlocks.GLASS_JAR).method_10442("has_base_item",method_10426(UsefulFoodItems.Chorus_Jam)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodJamBlocks.Sweet_Berries_JAM_JAR).method_10449(UsefulFoodItems.Sweet_Berries_Jam,3).method_10454(UsefulFoodJamBlocks.GLASS_JAR).method_10442("has_base_item",method_10426(UsefulFoodItems.Sweet_Berries_Jam)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodJamBlocks.Glow_Berries_JAM_JAR).method_10449(UsefulFoodItems.Glow_Berries_Jam,3).method_10454(UsefulFoodJamBlocks.GLASS_JAR).method_10442("has_base_item",method_10426(UsefulFoodItems.Glow_Berries_Jam)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodJamBlocks.Apple_JAM_JAR).method_10449(UsefulFoodItems.AppleJam,3).method_10454(UsefulFoodJamBlocks.GLASS_JAR).method_10442("has_base_item",method_10426(UsefulFoodItems.Chorus_Jam)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodJamBlocks.Melon_JAM_JAR).method_10449(UsefulFoodItems.MelonJam,3).method_10454(UsefulFoodJamBlocks.GLASS_JAR).method_10442("has_base_item",method_10426(UsefulFoodItems.Sweet_Berries_Jam)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodJamBlocks.GLASS_JAR).method_10454(class_2246.field_10033).method_10446(class_3489.field_15534).method_10442("has_base_item",method_10426(class_2246.field_10033)).method_10431(field_53721);

                //Reborn 1.5.0
                method_62749(class_7800.field_40640, UsefulFoodItems.Cod_Roe_Sushi).method_10454(class_1802.field_8429).method_10454(class_1802.field_17524).method_10442("has_base_item",method_10426(class_1802.field_8378)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodItems.Baked_Sushi).method_10446(ConventionalItemTags.COOKED_FISH_FOODS).method_10454(class_1802.field_8551).method_10442("has_base_item",method_10420(ConventionalItemTags.COOKED_FISH_FOODS)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodItems.Salmon_Sushi).method_10454(class_1802.field_8209).method_10454(class_1802.field_8551).method_10442("has_base_item",method_10426(class_1802.field_8209)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodItems.Fishwich).method_10449(UsefulFoodItems.BreadSlice,2).method_10446(ConventionalItemTags.COOKED_FISH_FOODS).method_10442("has_base_item",method_10420(ConventionalItemTags.COOKED_FISH_FOODS)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodItems.FishSoup).method_10454(class_1802.field_8179).method_10454(class_1802.field_8428).method_10454(class_1802.field_8567).method_10446(ConventionalItemTags.COOKED_FISH_FOODS).method_10442("has_base_item",method_10420(ConventionalItemTags.COOKED_FISH_FOODS)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodItems.ChocolateToast).method_10454(UsefulFoodItems.BreadSlice).method_10454(UsefulFoodItems.ChocolateCandy).method_10442("has_base_item",method_10426(UsefulFoodItems.ChocolateCandy)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodItems.FishnChips).method_10454(UsefulFoodItems.FrenchFries).method_10446(ConventionalItemTags.COOKED_FISH_FOODS).method_10442("has_base_item",method_10420(ConventionalItemTags.COOKED_FISH_FOODS)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodItems.ChocolateCandy).method_10454(class_1802.field_8116).method_10446(ConventionalItemTags.MILK_DRINKS).method_10454(class_1802.field_8479).method_10442("has_base_item",method_10426(class_1802.field_8116)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodItems.PanCakeDough).method_10454(class_1802.field_8479).method_10454(class_1802.field_8861).method_10454(class_1802.field_8803).method_10446(ConventionalItemTags.MILK_DRINKS).method_10442("has_base_item",method_10426(class_1802.field_8479)).method_10431(field_53721);
                method_62749(class_7800.field_40640, UsefulFoodItems.Tea).method_10454(class_1802.field_8469).method_10446(UsefulFoodItemTagGeneration.ModItemTags.C_Lily_Pads).method_10442("has_base_item",method_10426(class_1802.field_8469)).method_10431(field_53721);

                method_62746(class_7800.field_40640, UsefulFoodItems.Trailmix).method_10439("#WP").method_10439("WMW").method_10439(" B ").method_10434('#', class_1802.field_8309).method_10434('W', class_1802.field_8317).method_10434('P', class_1802.field_46249).method_10434('M', class_1802.field_46250).method_10434('B', class_1802.field_8428).method_10429("has_base_item",method_10426(class_1802.field_8309)).method_10431(field_53721);
                method_62746(class_7800.field_40640, UsefulFoodItems.FruitSalad).method_10439("#MS").method_10439(" B ").method_10434('#', class_1802.field_8279).method_10434('M', class_1802.field_8497).method_10434('S', class_1802.field_16998).method_10434('B', class_1802.field_8428).method_10429("has_base_item",method_10426(class_1802.field_8497)).method_10431(field_53721);
                method_62746(class_7800.field_40640, UsefulFoodItems.MagicFruitSalad).method_10439("#GK").method_10439(" B ").method_10434('#', class_1802.field_8463).method_10434('G', class_1802.field_8597).method_10434('K', class_1802.field_28659).method_10434('B', class_1802.field_8428).method_10429("has_base_item",method_10426(class_1802.field_8597)).method_10431(field_53721);
                method_62746(class_7800.field_40640, UsefulFoodCakeBlocks.MagicCake).method_10439("MMM").method_10439("GEG").method_10439("WWW").method_10433('M', ConventionalItemTags.MILK_DRINKS).method_10434('G', class_1802.field_8463).method_10434('E', class_1802.field_8367).method_10434('W', class_1802.field_8861).method_10429("has_base_item",method_10426(class_1802.field_8463)).method_10431(field_53721);
                method_62746(class_7800.field_40640, UsefulFoodCakeBlocks.AppleCake).method_10439("MMM").method_10439("AAA").method_10439("WWW").method_10433('M', ConventionalItemTags.MILK_DRINKS).method_10434('A', class_1802.field_8279).method_10434('W', class_1802.field_8861).method_10429("has_base_item",method_10426(class_1802.field_8279)).method_10431(field_53721);
                method_62746(class_7800.field_40640, UsefulFoodCakeBlocks.CaramelCake).method_10439("MMM").method_10439("CCC").method_10439("WWW").method_10433('M', ConventionalItemTags.MILK_DRINKS).method_10434('C', UsefulFoodItems.caramel).method_10434('W', class_1802.field_8861).method_10429("has_base_item",method_10426(UsefulFoodItems.caramel)).method_10431(field_53721);
                method_62746(class_7800.field_40640, UsefulFoodCakeBlocks.ChocolateCake).method_10439("MMM").method_10439("CCC").method_10439("WWW").method_10433('M', ConventionalItemTags.MILK_DRINKS).method_10434('C', class_1802.field_8116).method_10434('W', class_1802.field_8861).method_10429("has_base_item",method_10426(class_1802.field_8116)).method_10431(field_53721);

                method_62750(class_7800.field_40640,UsefulFoodItems.Waffle,8).method_10449(class_1802.field_8861, 2).method_10454(class_1802.field_8479).method_10454(class_1802.field_8803).method_10446(ConventionalItemTags.MILK_DRINKS).method_10442("has_base_item", method_10426(class_1802.field_8861)).method_10431(field_53721);
                method_62750(class_7800.field_40640,UsefulFoodItems.Waffle_Vanilla_IceCream,2).method_10454(class_1802.field_8543).method_10454(class_1802.field_8479).method_10454(UsefulFoodItems.Waffle).method_10446(ConventionalItemTags.MILK_DRINKS).method_10442("has_base_item", method_10426(UsefulFoodItems.Waffle)).method_10431(field_53721);
                method_62750(class_7800.field_40640,UsefulFoodItems.Waffle_Chorus_Ice_Cream, 2).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(class_1802.field_8233).method_10454(UsefulFoodItems.Waffle).method_10442("has_base_item", method_10426(class_1802.field_8233)).method_10431(field_53721);
                method_62750(class_7800.field_40640,UsefulFoodItems.Waffle_Glow_Berries_Ice_Cream, 2).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(class_1802.field_28659).method_10454(UsefulFoodItems.Waffle).method_10442("has_base_item", method_10426(class_1802.field_28659)).method_10431(field_53721);
                method_62750(class_7800.field_40640,UsefulFoodItems.Waffle_Sweet_Berries_Ice_Cream, 2).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(class_1802.field_16998).method_10454(UsefulFoodItems.Waffle).method_10442("has_base_item", method_10426(class_1802.field_16998)).method_10431(field_53721);
                method_62750(class_7800.field_40640,UsefulFoodItems.Waffle_chocolate_icecream, 2).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(UsefulFoodItems.ChocolateCandy).method_10454(UsefulFoodItems.Waffle).method_10442("has_base_item", method_10426(UsefulFoodItems.ChocolateCandy)).method_10431(field_53721);
                method_62750(class_7800.field_40640,UsefulFoodItems.Waffle_Magic_IceCream, 2).method_10449(class_1802.field_8597,2).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(class_1802.field_8463).method_10454(UsefulFoodItems.Waffle).method_10442("has_base_item", method_10426(UsefulFoodItems.VanillaIceCream)).method_10431(field_53721);
                method_62750(class_7800.field_40640,UsefulFoodItems.Waffle_Apple_IceCream, 2).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(class_1802.field_8279).method_10454(UsefulFoodItems.Waffle).method_10442("has_base_item", method_10426(class_1802.field_8279)).method_10431(field_53721);
                method_62750(class_7800.field_40640,UsefulFoodItems.Waffle_Melon_IceCream, 2).method_10454(UsefulFoodItems.VanillaIceCream).method_10449(class_1802.field_8497,3).method_10454(UsefulFoodItems.Waffle).method_10442("has_base_item", method_10426(class_1802.field_8497)).method_10431(field_53721);
                method_62750(class_7800.field_40640,UsefulFoodItems.Waffle_Caramel_IceCream, 2).method_10454(UsefulFoodItems.VanillaIceCream).method_10454(UsefulFoodItems.caramel).method_10454(UsefulFoodItems.Waffle).method_10442("has_base_item",method_10426(UsefulFoodItems.caramel)).method_10431(field_53721);

                //Smelting
                method_36233(List.of(UsefulFoodItems.SugarCube), class_7800.field_40640,UsefulFoodItems.caramel, 0.45F, 300, "caramel");
                method_36233(SEED, class_7800.field_40640,UsefulFoodItems.RoastedSeeds, 0.45F, 300, "food");
                method_36233(List.of(class_1802.field_8803), class_7800.field_40640,UsefulFoodItems.FriedEgg, 0.10F, 200, "friedegg");
                method_36233(List.of(UsefulFoodItems.Marshmallow), class_7800.field_40640,UsefulFoodItems.CookMarshmallow, 0.60F, 600, "cookedmarshmallow");
                method_36233(List.of(UsefulFoodItems.SquidTentacleRaw), class_7800.field_40640,UsefulFoodItems.SquidTentacleCooked, 0.35F, 200, "cookedsquidtentacle");
                method_36233(List.of(UsefulFoodItems.ChocolateMilkBottle),class_7800.field_40640, UsefulFoodItems.hotchocolatebottle, 0.30F, 200, "hotchocolatemilkbottle");
                method_36233(List.of(UsefulFoodItems.MilkBottle), class_7800.field_40640,UsefulFoodItems.HotMilkBottle, 0.35F, 200, "hotmilkbottle");
                method_36233(List.of(class_1802.field_8512), class_7800.field_40640,UsefulFoodItems.FrenchFries, 0.45F, 300, "frenchfries");
                method_36233(List.of(UsefulFoodItems.PanCakeDough), class_7800.field_40640, UsefulFoodItems.PanCake, 0.45F, 300, "pancake");

                //Campfire
                offerCampfireCooking(List.of(UsefulFoodItems.SquidTentacleRaw), class_7800.field_40640,UsefulFoodItems.SquidTentacleCooked, 0.35F, 600, "cookedsquidtentacle");
                offerCampfireCooking(SEED, class_7800.field_40640,UsefulFoodItems.RoastedSeeds, 0.45F, 600, "food");
                offerCampfireCooking(List.of(class_1802.field_8803), class_7800.field_40640,UsefulFoodItems.FriedEgg, 0.10F, 300, "friedegg");
                offerCampfireCooking(List.of(UsefulFoodItems.SugarCube), class_7800.field_40640,UsefulFoodItems.caramel, 0.45F, 300, "caramel");
                offerCampfireCooking(List.of(UsefulFoodItems.Marshmallow), class_7800.field_40640,UsefulFoodItems.CookMarshmallow, 0.60F, 600, "cookedmarshmallow");
                offerCampfireCooking(List.of(UsefulFoodItems.ChocolateMilkBottle),class_7800.field_40640, UsefulFoodItems.hotchocolatebottle, 0.30F, 200, "hotchocolatemilkbottle");
                offerCampfireCooking(List.of(UsefulFoodItems.MilkBottle), class_7800.field_40640,UsefulFoodItems.HotMilkBottle, 0.35F, 400, "hotmilkbottle");
                offerCampfireCooking(List.of(class_1802.field_8512), class_7800.field_40640,UsefulFoodItems.FrenchFries, 0.45F, 600, "frenchfries");
                offerCampfireCooking(List.of(UsefulFoodItems.PanCakeDough), class_7800.field_40640, UsefulFoodItems.PanCake, 0.45F, 600, "pancake");

                //Smoking
                offerSmoking(List.of(UsefulFoodItems.SquidTentacleRaw), class_7800.field_40640,UsefulFoodItems.SquidTentacleCooked, 0.35F, 100, "cookedsquidtentacle");
                offerSmoking(List.of(class_1802.field_8803), class_7800.field_40640,UsefulFoodItems.FriedEgg, 0.10F, 100, "friedegg");
                offerSmoking(SEED, class_7800.field_40640,UsefulFoodItems.RoastedSeeds, 0.45F, 100, "food");
                offerSmoking(List.of(UsefulFoodItems.SugarCube), class_7800.field_40640,UsefulFoodItems.caramel, 0.45F, 100, "caramel");
                offerSmoking(List.of(UsefulFoodItems.Marshmallow), class_7800.field_40640,UsefulFoodItems.CookMarshmallow, 0.60F, 100, "cookedmarshmallow");
                offerSmoking(List.of(UsefulFoodItems.ChocolateMilkBottle),class_7800.field_40640, UsefulFoodItems.hotchocolatebottle, 0.30F, 100, "cookedmarshmallow");
                offerSmoking(List.of(UsefulFoodItems.MilkBottle), class_7800.field_40640,UsefulFoodItems.HotMilkBottle, 0.35F, 50, "hotchocolatemilkbottle");
                offerSmoking(List.of(class_1802.field_8512), class_7800.field_40640,UsefulFoodItems.FrenchFries, 0.45F, 100, "frenchfries");
                offerSmoking(List.of(UsefulFoodItems.PanCakeDough), class_7800.field_40640, UsefulFoodItems.PanCake, 0.45F, 100, "pancake");

            }

            public static final List<class_1935> SEED = class_156.method_654(Lists.newArrayList(), list -> {
                list.add(class_1802.field_46249);
                list.add(class_1802.field_46250);
                list.add(class_1802.field_8317);
                list.add(class_1802.field_8309);
            });

            public void offerCampfireCooking(List<class_1935> inputs, class_7800 category, class_1935 output, float experience, int cookingTime, String group) {
                this.method_36232(class_1865.field_17347, class_3920::new, inputs, category, output, experience, cookingTime, group, "_from_campfire_cooking");
            }

            public void offerSmoking(List<class_1935> inputs, class_7800 category, class_1935 output, float experience, int cookingTime, String group) {
                this.method_36232(class_1865.field_17085, class_3862::new, inputs, category, output, experience, cookingTime, group, "_from_smoking");
            }

        };
    }

    @Override
    public String method_10321() {
        return "";
    }
}
