package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

public class KitchenCounterBlock extends class_2383 {
    public static final class_2746 LEFT = class_2746.method_11825("left");
    public static final class_2746 RIGHT = class_2746.method_11825("right");

    public static final MapCodec<KitchenCounterBlock> CODEC = method_54094(KitchenCounterBlock::new);

    private static final class_265 SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0);

    public KitchenCounterBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(LEFT,false).method_11657(RIGHT,false));
    }

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }

    @Override
    public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify) {
        super.method_9612(state, world, pos, sourceBlock, sourcePos, notify);

        if (world.method_8608()) return;

        class_2350 direction = (class_2350) state.method_11654(field_11177);
        class_2680 blockState = world.method_8320(pos.method_10093(direction));
        if (isCounter(blockState)) {
            class_2350 direction2 = (class_2350) blockState.method_11654(field_11177);
            if (direction2.method_10166() != ((class_2350) state.method_11654(field_11177)).method_10166() && isDifferentOrientation(state, world, pos, direction2.method_10153())) {
                boolean leftConnected = isLeftConnected(world, pos, direction);
                boolean rightConnected = isRightConnected(world, pos, direction);

                class_2680 newState = state.method_11657(LEFT, leftConnected).method_11657(RIGHT, rightConnected);
                if (!newState.equals(state)) {
                    world.method_8652(pos, newState, class_2248.field_31028);
                }
            }
        }
    }

    public static boolean isCounter(class_2680 state) {
        return state.method_26204() instanceof KitchenCounterBlock;
    }

    private static boolean isDifferentOrientation(class_2680 state, class_1922 world, class_2338 pos, class_2350 dir) {
        class_2680 blockState = world.method_8320(pos.method_10093(dir));
        return !isCounter(blockState) || blockState.method_11654(field_11177) != state.method_11654(field_11177);
    }

    private boolean isLeftConnected(class_1937 world, class_2338 pos, class_2350 facing) {
        class_2680 neighborState = world.method_8320(pos.method_10093(facing.method_10160()));
        return neighborState.method_26204() == this && neighborState.method_11654(field_11177) == facing;
    }

    private boolean isRightConnected(class_1937 world, class_2338 pos, class_2350 facing) {
        class_2680 neighborState = world.method_8320(pos.method_10093(facing.method_10170()));
        return neighborState.method_26204() == this && neighborState.method_11654(field_11177) == facing;
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2350 facing = context.method_8042().method_10153();

        return this.method_9564().method_11657(field_11177, facing);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, LEFT, RIGHT);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }
}
