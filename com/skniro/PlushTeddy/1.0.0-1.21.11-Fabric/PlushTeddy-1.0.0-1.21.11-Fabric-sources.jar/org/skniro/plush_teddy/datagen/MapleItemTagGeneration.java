package org.skniro.plush_teddy.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.registry.*;


import java.util.concurrent.CompletableFuture;


public class MapleItemTagGeneration extends FabricTagProvider<class_1792> {
    public MapleItemTagGeneration(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(dataGenerator, class_7924.field_41197, completableFuture);
    }

    public static class ModItemTags {
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {

    }


}
