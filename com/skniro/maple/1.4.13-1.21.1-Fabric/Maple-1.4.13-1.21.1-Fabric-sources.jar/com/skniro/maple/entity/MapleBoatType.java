package com.skniro.maple.entity;

import net.minecraft.class_1690;

public class MapleBoatType {
    static {
        class_1690.class_1692.values();
    }
    public static class_1690.class_1692 MAPLE;
    public static class_1690.class_1692 GINKGO;
}
