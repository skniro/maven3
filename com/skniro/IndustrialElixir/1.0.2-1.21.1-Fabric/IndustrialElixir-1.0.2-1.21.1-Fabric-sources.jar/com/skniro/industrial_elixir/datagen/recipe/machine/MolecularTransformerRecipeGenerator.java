package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.item.AdvancedItems;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class MolecularTransformerRecipeGenerator extends FabricRecipeProvider {
    public MolecularTransformerRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                // Bronze
                createMolecularTransformer(GrowableOresItems.TIN_INGOT, GrowableOresItems.SILVER_INGOT, 500000).method_10431(output);
                createMolecularTransformer(class_1802.field_8791, class_1802.field_8137,250000000).method_10431(output);
                createMolecularTransformer(class_1802.field_8328, class_1802.field_8054, 2,70000).method_10431(output);
                createMolecularTransformer(class_1802.field_8601, AdvancedItems.LUMINITE_Part,1000000).method_10431(output);
                createMolecularTransformer(class_1802.field_8620, GrowableOresItems.IRIDIUM_ORE,9000000).method_10431(output);
                createMolecularTransformer(class_1802.field_19058, class_1802.field_8793,500000).method_10431(output);
                createMolecularTransformer(class_1802.field_19055, class_1802.field_8055,500000).method_10431(output);
                createMolecularTransformer(GrowableOresItems.INDUSTRIAL_DIAMOND, class_1802.field_8477,1000000).method_10431(output);
                createMolecularTransformer(class_1802.field_8665, class_1802.field_8713,60000).method_10431(output);
                createMolecularTransformer(class_1802.field_8713, GrowableOresItems.INDUSTRIAL_DIAMOND,9000000).method_10431(output);
                createMolecularTransformer(GrowableOresItems.SILVER_INGOT, class_1802.field_8695,500000).method_10431(output);
                createMolecularTransformer(class_1802.field_8831, class_1802.field_19060,50000).method_10431(output);
                createMolecularTransformer(class_1802.field_8858, class_1802.field_8110,50000).method_10431(output);
                createMolecularTransformer(class_1802.field_19048, class_1802.field_8801,500000).method_10431(output);
            }
        };
    }

    @Override
    public String method_10321() {
        return "MolecularTransformer";
    }
}
