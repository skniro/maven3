package com.skniro.industrial_elixir.block.entity.machine;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.screen.handler.machine.MaceratorScreenHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3956;
import org.jetbrains.annotations.Nullable;

public class MaceratorEntity extends AbstractMachineEntity {

    public MaceratorEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.Macerator_BLOCK_ENTITY ,pos, state);
        this.DEFAULT_MAX_PROGRESS = 400;
        this.maxProgress = 400;
    }

    // 40/20 = 2 EU/t
    @Override
    public long getCraftEnergyCost() {
        return 40;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Macerator);
    }

    public class_3956<?> getCurrentRecipeType() {
        return AlchemyRecipeType.MACERATOR.type;
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new MaceratorScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }
}
