package com.skniro.maple.entity.projectile.thrown;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1545;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3966;
import net.minecraft.class_5454;
import net.minecraft.class_6024;
import org.jetbrains.annotations.Nullable;

public class MapletransSnowballEntity extends MapleSnowballEntity {
    public MapletransSnowballEntity(class_1937 world, class_1309 owner, class_1799 stack) {
        super(world, owner,stack);
    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {
        super.method_7454(entityHitResult);
        class_1297 entity = entityHitResult.method_17782();
        int i = entity instanceof class_1545 ? 4 : 0;
        entity.method_64419(this.method_48923().method_48811(this, this.method_24921()), i);
        entity.method_5784(class_1313.field_6308, new class_243(5.0, 0.0, 5.0));
        if (entity instanceof class_3222) {
            class_3222 serverPlayerEntity = (class_3222) entity;
            if (serverPlayerEntity.field_13987.method_48106() && serverPlayerEntity.method_37908() == this.method_37908() && !serverPlayerEntity.method_6113()) {

                if (entity.method_5765()) {
                    serverPlayerEntity.method_33567(this.method_23317(), this.method_23318(), this.method_23321());
                } else {
                    entity.method_5859(this.method_23317(), this.method_23318(), this.method_23321());
                }
                entity.method_38785();
            } else if (entity != null) {
                entity.method_5859(this.method_23317(), this.method_23318(), this.method_23321());
                entity.method_38785();
            }
            this.method_31472();
        }
    }

    @Override
    protected void method_7488(class_239 hitResult) {
        super.method_7488(hitResult);
        if (!this.method_37908().field_9236) {
            this.method_37908().method_8421(this, class_6024.field_30028);
            this.method_31472();
        }
    }

    @Nullable
    public class_1297 method_5731(class_5454 teleportTarget) {
        class_1297 entity = this.method_24921();
        if (entity != null && entity.method_37908().method_27983() != teleportTarget.comp_2820().method_27983()) {
            this.method_7432((class_1297)null);
        }

        return super.method_5731(teleportTarget);
    }
}
