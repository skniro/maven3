package com.skniro.maple.block.renderer.state;

import net.minecraft.class_10444;
import net.minecraft.class_11954;


public class MapleJuicerBlockEntityRenderState extends class_11954 {
    public final class_10444 item = new class_10444();
}