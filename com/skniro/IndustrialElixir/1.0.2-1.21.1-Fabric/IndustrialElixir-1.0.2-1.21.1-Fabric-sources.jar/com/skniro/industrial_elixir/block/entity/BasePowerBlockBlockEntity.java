package com.skniro.industrial_elixir.block.entity;

import com.skniro.industrial_elixir.api.block.ImplementedInventory;
import com.skniro.industrial_elixir.api.block.MachineEnergyProvider;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.EnergyStorageUtil;
import com.skniro.industrial_elixir.energy.api.base.SimpleSidedEnergyContainer;
import com.skniro.industrial_elixir.item.init.ItemUpgradeModule;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public abstract class BasePowerBlockBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory, MachineEnergyProvider {
    public class_2371<class_1799> inventory = class_2371.method_10213(13, class_1799.field_8037);
    private float rotation = 0;
    protected static final int FLUID_ITEM_SLOT = 0;
    protected static final int INPUT_SLOT = 1;
    protected static final int OUTPUT_SLOT = 2;
    protected static final int ENERGY_ITEM_SLOT = 3;
    protected static final int UPGRADE_START = 4;
    protected static final int UPGRADE_END = 7;
    protected static final int EMPTY_FLUID_ITEM_SLOT = 8;
    // Additional second input slot (used by machines that need two inputs, e.g. Brew Reactor)
    protected static final int SECOND_INPUT_SLOT = 9;
    protected static final int OUTPUT_SLOT_2 = 10;
    protected static final int OUTPUT_SLOT_3 = 11;
    protected static final int THIRD_INPUT_SLOT = 12;
    protected static final int ENERGY_CRAFTING_AMOUNT = 32;
    protected final EnergyTier energyTier;
    public SimpleSidedEnergyContainer energyContainer;


    public BasePowerBlockBlockEntity(class_2591<?> blockEntityType, class_2338 pos, class_2680 state) {
        super(blockEntityType, pos, state);
        this.energyTier = ((AbstractMachineblock)method_11010().method_26204()).getEnergyTier();

        energyContainer = new SimpleSidedEnergyContainer() {
            @Override
            public long getCapacity() {
                return getMachineCapacity();
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                return getEffectiveTier().getMaxInput();
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                return getEffectiveTier().getMaxOutput();
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(pos, method_11010(), method_11010(), 3);

/*            if(!world.isClient()) {
                for(ServerPlayerEntity player : PlayerLookup.tracking((ServerWorld) world, getPos())) {
                    ServerPlayNetworking.send(player, new EnergySyncS2CPayload(amount, getPos()));
                }
            }*/
            }
        };
    };

    // 获取有效的 EnergyTier（支持 Transformer 升级）
    public EnergyTier getEffectiveTier() {
        int tierBoost = 0;
        for (int i = UPGRADE_START; i <= UPGRADE_END; i++) {
            class_1799 stack = inventory.get(i);
            if (!stack.method_7960() && stack.method_7909() instanceof ItemUpgradeModule u) {
                tierBoost += u.getTierIncrease(stack);
            }
        }
        int newTier = Math.min(energyTier.ordinal() + tierBoost, EnergyTier.values().length - 1);
        return EnergyTier.values()[newTier];
    }

    // 计算处理速度倍率
    public double getProcessTimeMultiplier() {
        double multiplier = 1.0;
        for (int i = UPGRADE_START; i <= UPGRADE_END; i++) {
            class_1799 stack = inventory.get(i);
            if (!stack.method_7960() && stack.method_7909() instanceof ItemUpgradeModule u) {
                multiplier = u.getProcessTimeMultiplier(stack);
            }
        }
        return multiplier;
    }

    // 计算能耗倍率
    public double getEnergyDemandMultiplier() {
        double multiplier = 1.0;
        for (int i = UPGRADE_START; i <= UPGRADE_END; i++) {
            class_1799 stack = inventory.get(i);
            if (!stack.method_7960() && stack.method_7909() instanceof ItemUpgradeModule u) {
                multiplier = u.getEnergyDemandMultiplier(stack);
            }
        }
        return multiplier;
    }

    // 计算额外储能
    public int getEnergyStorageUpgrade() {
        int total = 0;
        for (int i = UPGRADE_START; i <= UPGRADE_END; i++) {
            class_1799 stack = inventory.get(i);
            if (!stack.method_7960() && stack.method_7909() instanceof ItemUpgradeModule u) {
                total += u.getExtraEnergyStorage(stack);
            }
        }
        return total;
    }


    public void charge(int slot) {
        if (this.field_11863 != null) {
            if (!this.field_11863.method_8608()) {
                long chargeEnergy = Math.min(this.getFreeSpace(), energyTier.getMaxInput());
                if (chargeEnergy > 0L) {
                    if (!this.getOptionalInventory().isEmpty()) {
                        class_1263 inventory = this.getOptionalInventory().get();
                        EnergyStorageUtil.move(ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(slot)).find(EnergyStorage.ITEM), this.getSideEnergyStorage(null), Long.MAX_VALUE, null);
                    }
                }
            }
        }
    }


    public long getFreeSpace() {
        return this.energyContainer.getCapacity() - energyContainer.amount;
    }

    public Optional<ImplementedInventory> getOptionalInventory() {
        if (this instanceof ImplementedInventory inventory) {
            return inventory == null ? Optional.empty() : Optional.of(inventory);
        } else {
            return Optional.empty();
        }
    }

    public EnergyStorage getSideEnergyStorage(@Nullable class_2350 side) {
        return this.energyContainer.getSideStorage(side);
    }

    public void pushEnergyToNeighbours() {
        if (energyContainer.amount <= 0) return;
        for (class_2350 dir : class_2350.values()) {
            EnergyStorage target = EnergyStorage.SIDED.find(field_11863, field_11867.method_10093(dir), dir.method_10153());
            if (target == null) continue;
            EnergyStorageUtil.move(energyContainer.getSideStorage(dir), target, getEffectiveTier().getMaxOutput(), null);
        }
    }

    public EnergyTier getEnergyTier(){
        return energyTier;
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }

    @Override
    public void method_5431() {
        field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        super.method_5431();
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }

    public class_1937 level() {
        return this.field_11863;
    }

    public class_243 position() {
        return this.method_11016().method_46558();
    }

    public float getVisualRotationYInDegrees() {
        return this.method_11010().method_11654(AbstractMachineblock.FACING).method_10153().method_10164();
    }

    @Override
    public long getMachineCapacity(){
        if(method_11010().method_26204() instanceof AbstractMachineblock) {
            return ((AbstractMachineblock) method_11010().method_26204()).getMaxCapacity();
        }
        return 0;
    };

    public long getCraftEnergyCost(){
        return 0;
    }
}
