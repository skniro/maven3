package com.skniro.maple;

import com.skniro.maple.block.MapleFurnitureBlocks;
import com.skniro.maple.conifg.Configuration;
import com.skniro.maple.conifg.MapleConfig;
import com.skniro.maple.item.MapleItems;
import com.skniro.maple.world.biome.MapleGroveBiome;
import com.skniro.maple.world.biome.MapleSakuraBiome;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import terrablender.api.Regions;
import terrablender.api.TerraBlenderApi;

import static com.skniro.maple.block.MapleBlocks.MAPLE_LOG;

public class Maple implements ModInitializer, TerraBlenderApi {
    public static final String MOD_ID = "maple";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final ModContainer MOD_CONTAINER = FabricLoader.getInstance().getModContainer(MOD_ID).orElseThrow();


    public static final class_5321<class_1761> Maple_Group = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(MOD_ID, "maple_group"));
    public static final class_5321<class_1761> Maple_Group_Food = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(MOD_ID, "test_group"));
    public static final class_5321<class_1761> Maple_Group_Furniture = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(MOD_ID, "maple_group_furniture"));


    @Override
    public void onInitialize() {
        new Configuration(MapleConfig.class, MOD_ID);
        class_2378.method_39197(class_7923.field_44687, Maple_Group, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(MAPLE_LOG))
                .method_47321(class_2561.method_43471("itemGroup.maple.maple_group"))
                .method_47324()); // build() no longer registers by itself
        class_2378.method_39197(class_7923.field_44687, Maple_Group_Food, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(MapleItems.MapleSyrup))
                .method_47321(class_2561.method_43471("itemGroup.maple.maple_group_food"))
                .method_47324()); // build() no longer registers by itself
        class_2378.method_39197(class_7923.field_44687, Maple_Group_Furniture, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(MapleFurnitureBlocks.CUSHION_MAPLE_YELLOW))
                .method_47321(class_2561.method_43471("itemGroup.maple.maple_group_furniture"))
                .method_47324());
        MapleContent.registerItem();
        MapleContent.registerBlock();
        MapleContent.registerFluid();
        MapleContent.CreativeTab();
        MapleContent.generateWorldGen();
        MapleContent.registerOthers();
        MapleContent.registerCommand();
        MapleContent.registerMapleLootTable();
        MapleContent.registerMapleCompostableItems();
        MapleContent.registerScreenType();
        MapleContent.registerRecipeType();
        //MapleContent.datafix(MOD_CONTAINER);
    }

    @Override
    public void onTerraBlenderInitialized() {
        Regions.register(new MapleGroveBiome(class_2960.method_60655(Maple.MOD_ID, "overworld_1"), 2));
        Regions.register(new MapleSakuraBiome(class_2960.method_60655(Maple.MOD_ID, "overworld_2"), 2));
    }

    public static class_2960 asResource(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }

}
