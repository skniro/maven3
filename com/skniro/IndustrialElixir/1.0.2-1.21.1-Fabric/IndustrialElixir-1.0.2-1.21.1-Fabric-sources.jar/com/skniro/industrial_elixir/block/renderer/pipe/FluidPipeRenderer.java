package com.skniro.industrial_elixir.block.renderer.pipe;

import com.skniro.industrial_elixir.block.entity.pipe.FluidPipeBlockEntity;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_918;

public class FluidPipeRenderer implements class_827<FluidPipeBlockEntity> {

    public FluidPipeRenderer(class_5614.class_5615 context) {
    }

    @Override
    public void render(FluidPipeBlockEntity entity, float partialTick, class_4587 matrices, class_4597 buffer, int packedLight, int packedOverlay) {
        class_918 itemRenderer = class_310.method_1551().method_1480();
        class_1937 level = entity.method_10997();
        int light = getLightLevel(level, entity.method_11016());

        for (FluidPipeBlockEntity.PipeFluid fluid : entity.getFluids()) {
            if (fluid.variant.isBlank() || fluid.amount <= 0) {
                continue;
            }

            double offsetX = fluid.direction.method_10148() * fluid.progress;
            double offsetY = fluid.direction.method_10164() * fluid.progress;
            double offsetZ = fluid.direction.method_10165() * fluid.progress;

            matrices.method_22903();
            matrices.method_22904(0.5 + offsetX, 0.5 + offsetY, 0.5 + offsetZ);
            matrices.method_22905(0.33f, 0.33f, 0.33f);
            itemRenderer.method_23178(getFluidDisplayStack(fluid.variant.getFluid()), class_811.field_4318,
                    light, class_4608.field_21444, matrices, buffer, level, 0);
            matrices.method_22909();
        }
    }

    private int getLightLevel(class_1937 world, class_2338 pos) {
        if (world == null) {
            return class_765.field_32767;
        }
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, Math.max(sLight, 15));
    }

    private static class_1799 getFluidDisplayStack(class_3611 fluid) {
        if (fluid.method_15780(class_3612.field_15910) || fluid.method_15780(class_3612.field_15909)) {
            return new class_1799(class_1802.field_8869);
        }
        if (fluid.method_15780(class_3612.field_15908) || fluid.method_15780(class_3612.field_15907)) {
            return new class_1799(class_1802.field_8393);
        }
        return new class_1799(class_1802.field_8685);
    }
}
