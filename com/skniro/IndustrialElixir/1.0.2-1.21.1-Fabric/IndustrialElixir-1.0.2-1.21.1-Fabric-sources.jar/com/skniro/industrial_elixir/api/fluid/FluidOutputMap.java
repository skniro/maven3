package com.skniro.industrial_elixir.api.fluid;

import com.skniro.industrial_elixir.fluid.IndustrialElixirFluidBlocks;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluidItems;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluids;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_3611;
import net.minecraft.class_3612;

public class FluidOutputMap {

    public static final Map<class_3611, List<ContainerInfo>> FLUID_CONTAINERS = Map.of(
            class_3612.field_15910,
            List.of(
                    new ContainerInfo(
                            class_1802.field_8550,
                            class_1802.field_8705
                    ),
                    new ContainerInfo(
                            GrowableOresItems.EMPTY_CELL,
                            GrowableOresItems.WATER_CELL
                    )
            ),

            class_3612.field_15908,
            List.of(
                    new ContainerInfo(
                            class_1802.field_8550,
                            class_1802.field_8187
                    ),
                    new ContainerInfo(
                            GrowableOresItems.EMPTY_CELL,
                            GrowableOresItems.LAVA_CELL
                    )
            ),

            IndustrialElixirFluids.STILL_Fluid_UU,
            List.of(
                    new ContainerInfo(
                            class_1802.field_8550,
                            IndustrialElixirFluidItems.Fluid_UU_BUCKET
                    ),
                    new ContainerInfo(
                            GrowableOresItems.EMPTY_CELL,
                            IndustrialElixirFluidItems.UU_CELL
                    )
            ),

            IndustrialElixirFluids.STILL_Fluid_AIR,
            List.of(
                    new ContainerInfo(
                            class_1802.field_8550,
                            IndustrialElixirFluidItems.Fluid_AIR_BUCKET
                    ),
                    new ContainerInfo(
                            GrowableOresItems.EMPTY_CELL,
                            IndustrialElixirFluidItems.AIR_CELL
                    )
            ),

            IndustrialElixirFluids.STILL_Hot_Spring,
            List.of(
                    new ContainerInfo(
                            class_1802.field_8550,
                            IndustrialElixirFluidItems.Hot_Spring_BUCKET
                    ),
                    new ContainerInfo(
                            GrowableOresItems.EMPTY_CELL,
                            IndustrialElixirFluidItems.Hot_Spring_CELL
                    )
            )
    );

    public static ContainerInfo getContainerInfo(class_3611 fluid, class_1792 emptyContainer) {
        List<ContainerInfo> infos = FLUID_CONTAINERS.get(fluid);

        if (infos == null) {
            return null;
        }

        for (ContainerInfo info : infos) {
            if (info.emptyItem() == emptyContainer) {
                return info;
            }
        }

        return null;
    }
}
