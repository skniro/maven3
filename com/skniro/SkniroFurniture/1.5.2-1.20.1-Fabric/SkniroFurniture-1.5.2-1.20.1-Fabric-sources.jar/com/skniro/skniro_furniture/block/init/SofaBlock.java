package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import com.skniro.skniro_furniture.entity.MapleEntityType;
import com.skniro.skniro_furniture.entity.furniture.SofaEntity;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2383;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3730;
import net.minecraft.class_3965;

public class SofaBlock extends class_2383 {
    public static final class_2746 LEFT = class_2746.method_11825("left");
    public static final class_2746 RIGHT = class_2746.method_11825("right");

    private static final class_265 SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0);

    public SofaBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(LEFT,false).method_11657(RIGHT,false));
    }


    @Override
    public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify) {
        super.method_9612(state, world, pos, sourceBlock, sourcePos, notify);

        if (world.method_8608()) return;

        class_2350 direction = state.method_11654(field_11177);
        boolean leftConnected = isLeftConnected(world, pos, direction);
        boolean rightConnected = isRightConnected(world, pos, direction);

        class_2680 newState = state.method_11657(LEFT, leftConnected).method_11657(RIGHT, rightConnected);
        if (!newState.equals(state)) {
            world.method_8652(pos, newState, class_2248.field_31028);
        }
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if(!level.method_8608()) {
            class_1297 entity = null;
            List<SofaEntity> entities = level.method_18023(MapleEntityType.SOFA_ENTITY, new class_238(pos), chair -> true);
            if(entities.isEmpty()) {
                entity = MapleEntityType.SOFA_ENTITY.method_47821(((class_3218) level), pos, class_3730.field_16461);
            } else {
                entity = entities.get(0);
            }
            player.method_5804(entity);
        }
        return class_1269.field_5812;
    }


    public static boolean isSofa(class_2680 state) {
        return state.method_26204() instanceof SofaBlock;
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        super.method_9567(world, pos, state, placer, itemStack);
        method_9612(state, world, pos, null, null, false);
    }

    private boolean isLeftConnected(class_1937 world, class_2338 pos, class_2350 facing) {
        class_2680 neighborState = world.method_8320(pos.method_10093(facing.method_10160()));
        return neighborState.method_26204() == this && neighborState.method_11654(field_11177) == facing;
    }

    private boolean isRightConnected(class_1937 world, class_2338 pos, class_2350 facing) {
        class_2680 neighborState = world.method_8320(pos.method_10093(facing.method_10170()));
        return neighborState.method_26204() == this && neighborState.method_11654(field_11177) == facing;
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2350 facing = context.method_8042().method_10153();

        return this.method_9564().method_11657(field_11177, facing);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, LEFT, RIGHT);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }
}
