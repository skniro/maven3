package com.skniro.maple.block;

import com.skniro.maple.Maple;
import com.skniro.maple.block.entity.MapleSignTypes;
import net.minecraft.block.*;
import net.minecraft.class_1761;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2508;
import net.minecraft.class_2551;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_4719;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7713;
import net.minecraft.class_7715;
import net.minecraft.class_7923;

public class MapleSignBlocks {
    public static final class_2248 CHERRY_SIGN = registerBlockWithoutItem("cherry_sign", new class_2508(class_4719.field_42837, class_4970.class_2251.method_9637().method_31710(MapleBlocks.CHERRY_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013()),Maple.Maple_Group);
    public static final class_2248 CHERRY_WALL_SIGN = registerBlockWithoutItem("cherry_wall_sign", new class_2551(class_4719.field_42837, class_4970.class_2251.method_9637().method_31710(MapleBlocks.CHERRY_LOG.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_16228(CHERRY_SIGN)),Maple.Maple_Group);
    public static final class_2248 Maple_SIGN = registerBlockWithoutItem("maple_sign",new class_2508(MapleSignTypes.MAPLE, class_4970.class_2251.method_9637().method_31710(MapleBlocks.MAPLE_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013()),Maple.Maple_Group);
    public static final class_2248 Maple_WALL_SIGN = registerBlockWithoutItem("maple_wall_sign",new class_2551(MapleSignTypes.MAPLE, class_4970.class_2251.method_9637().method_31710(MapleBlocks.MAPLE_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_16228(Maple_SIGN)),Maple.Maple_Group);
    public static final class_2248 BAMBOO_SIGN = registerBlockWithoutItem("bamboo_sign", new class_2508(class_4719.field_40350, class_4970.class_2251.method_9637().method_31710(MapleBlocks.BAMBOO_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013()),Maple.Maple_Group);
    public static final class_2248 BAMBOO_WALL_SIGN = registerBlockWithoutItem("bamboo_wall_sign",new class_2551(class_4719.field_40350, class_4970.class_2251.method_9637().method_31710(MapleBlocks.BAMBOO_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_16228(BAMBOO_SIGN)),Maple.Maple_Group);
    public static final class_2248 GINKGO_SIGN = registerBlockWithoutItem("ginkgo_sign", new class_2508(MapleSignTypes.GINKGO, class_4970.class_2251.method_9637().method_31710(MapleBlocks.GINKGO_LEAVES.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013()),Maple.Maple_Group);
    public static final class_2248 GINKGO_WALL_SIGN = registerBlockWithoutItem("ginkgo_wall_sign",new class_2551(MapleSignTypes.GINKGO, class_4970.class_2251.method_9637().method_31710(MapleBlocks.GINKGO_LEAVES.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_16228(GINKGO_SIGN)),Maple.Maple_Group);
    public static final class_2248 GINKGO_HANGING_SIGN = registerBlockWithoutItem("ginkgo_hanging_sign", new class_7713(MapleSignTypes.GINKGO, class_4970.class_2251.method_9637().method_31710(MapleBlocks.GINKGO_LEAVES.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013()),Maple.Maple_Group);
    public static final class_2248 GINKGO_WALL_HANGING_SIGN = registerBlockWithoutItem("ginkgo_wall_hanging_sign", new class_7715(MapleSignTypes.GINKGO, class_4970.class_2251.method_9637().method_31710(MapleBlocks.GINKGO_LEAVES.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_16228(GINKGO_HANGING_SIGN)),Maple.Maple_Group);
    public static final class_2248 Maple_HANGING_SIGN = registerBlockWithoutItem("maple_hanging_sign", new class_7713(MapleSignTypes.MAPLE, class_4970.class_2251.method_9637().method_31710(MapleBlocks.MAPLE_LEAVES.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013()),Maple.Maple_Group);
    public static final class_2248 Maple_WALL_HANGING_SIGN = registerBlockWithoutItem("maple_wall_hanging_sign", new class_7715(MapleSignTypes.MAPLE, class_4970.class_2251.method_9637().method_31710(MapleBlocks.MAPLE_LEAVES.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_16228(Maple_HANGING_SIGN)), Maple.Maple_Group);



    private static class_2248 registerBlockWithoutItem(String name, class_2248 block, class_5321<class_1761> group) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(Maple.MOD_ID, name), block);
    }

    public static void registerMapleSignBlocks() {
        Maple.LOGGER.debug("Registering MapleSignBlocks for " + Maple.MOD_ID);
    }
}
