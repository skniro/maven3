package com.skniro.industrial_elixir.datagen.recipe.material;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.item.MapleArmorItems;
import com.skniro.industrial_elixir.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CookingBookCategory;

import java.util.List;
import java.util.concurrent.CompletableFuture;

public class MaterialRecipeGenerator extends FabricRecipeProvider {
    public MaterialRecipeGenerator(FabricPackOutput output, CompletableFuture<HolderLookup.Provider> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator createRecipeProvider(HolderLookup.Provider wrapperLookup, RecipeOutput exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void buildRecipes() {
                shaped(RecipeCategory.MISC, GrowableOresItems.ENERGIUM_DUST)
                        .define('R', Items.REDSTONE).define('D', GrowableOresItems.DIAMOND_DUST)
                        .pattern("RDR").pattern("DRD").pattern("RDR")
                        .unlockedBy("has_item", this.has(Items.REDSTONE)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.BRONZE_DUST)
                        .requires(GrowableOresItems.SMALL_BRONZE_DUST,9)
                        .unlockedBy("has_item", this.has(GrowableOresItems.SMALL_BRONZE_DUST)).save(this.output,"small_bronze_dust_to_bronze_dust");

                shapeless(RecipeCategory.MISC, GrowableOresItems.COPPER_DUST)
                        .requires(GrowableOresItems.SMALL_COPPER_DUST,9)
                        .unlockedBy("has_item", this.has(GrowableOresItems.SMALL_BRONZE_DUST)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.BRONZE_DUST, 4)
                        .define('R', ModItemTags.DUST_TIN).define('D', ModItemTags.DUST_COPPER)
                        .pattern("RD ").pattern("DD ").pattern("   ")
                        .unlockedBy("has_item_tags", this.has(ModItemTags.DUST_COPPER)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.GOLD_DUST)
                        .requires(GrowableOresItems.SMALL_GOLD_DUST,9)
                        .unlockedBy("has_item", this.has(GrowableOresItems.SMALL_GOLD_DUST)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.IRON_DUST)
                        .requires(GrowableOresItems.SMALL_IRON_DUST,9)
                        .unlockedBy("has_item", this.has(GrowableOresItems.SMALL_IRON_DUST)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.LAPIS_DUST)
                        .requires(GrowableOresItems.SMALL_LAPIS_DUST,9)
                        .unlockedBy("has_item", this.has(GrowableOresItems.SMALL_LAPIS_DUST)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.LEAD_DUST)
                        .requires(GrowableOresItems.SMALL_LEAD_DUST,9)
                        .unlockedBy("has_item", this.has(GrowableOresItems.SMALL_LEAD_DUST)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.LITHIUM_DUST)
                        .requires(GrowableOresItems.SMALL_LITHIUM_DUST,9)
                        .unlockedBy("has_item", this.has(GrowableOresItems.SMALL_LITHIUM_DUST)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.OBSIDIAN_DUST)
                        .requires(GrowableOresItems.SMALL_OBSIDIAN_DUST,9)
                        .unlockedBy("has_item", this.has(GrowableOresItems.SMALL_OBSIDIAN_DUST)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.SILVER_DUST)
                        .requires(GrowableOresItems.SMALL_SILVER_DUST,9)
                        .unlockedBy("has_item", this.has(GrowableOresItems.SMALL_SILVER_DUST)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.SULFUR_DUST)
                        .requires(GrowableOresItems.SMALL_SULFUR_DUST,9)
                        .unlockedBy("has_item", this.has(GrowableOresItems.SMALL_SULFUR_DUST)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.TIN_DUST)
                        .requires(GrowableOresItems.SMALL_TIN_DUST,9)
                        .unlockedBy("has_item", this.has(GrowableOresItems.SMALL_TIN_DUST)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.ALLOY_INGOT)
                        .define('I', GrowableOresItems.IRON_PLATE).define('B', GrowableOresItems.BRONZE_PLATE).define('T', GrowableOresItems.TIN_PLATE)
                        .pattern("III").pattern("BBB").pattern("TTT")
                        .unlockedBy("has_item", this.has(GrowableOresItems.BRONZE_PLATE)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.BRONZE_INGOT, 9)
                        .requires(GeneralBlocks.Bronze_Block)
                        .unlockedBy("has_item", this.has(GeneralBlocks.Bronze_Block)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.LEAD_INGOT, 9)
                        .requires(GeneralBlocks.Lead_Block)
                        .unlockedBy("has_item", this.has(GeneralBlocks.Lead_Block)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.SILVER_INGOT, 9)
                        .requires(GeneralBlocks.Silver_Block)
                        .unlockedBy("has_item", this.has(GeneralBlocks.Silver_Block)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.STEEL_INGOT, 9)
                        .requires(GeneralBlocks.Steel_Block)
                        .unlockedBy("has_item", this.has(GeneralBlocks.Steel_Block)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.URANIUM_INGOT, 9)
                        .requires(GeneralBlocks.Uranium_Block)
                        .unlockedBy("has_item", this.has(GeneralBlocks.Uranium_Block)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.TIN_INGOT, 9)
                        .requires(GeneralBlocks.Tin_Block)
                        .unlockedBy("has_item", this.has(GeneralBlocks.Tin_Block)).save(this.output);

                oreSmelting(List.of(GrowableOresItems.Sticky_Resin), RecipeCategory.MISC, CookingBookCategory.MISC, GrowableOresItems.Rubber, 0.45F, 300, "sticky_resin");

                shaped(RecipeCategory.MISC, GrowableOresItems.Circuit)
                        .define('I', GrowableOresItems.IRON_PLATE).define('B', GrowableOresBlocks.INSULATED_COPPER_CABLE).define('T', Items.REDSTONE)
                        .pattern("BBB").pattern("TIT").pattern("BBB")
                        .unlockedBy("has_item", this.has(GrowableOresItems.IRON_PLATE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.Advanced_Circuit)
                        .define('I', GrowableOresItems.Circuit).define('B', Items.GLOWSTONE_DUST).define('T', Items.REDSTONE).define('L', Items.LAPIS_LAZULI)
                        .pattern("TBT").pattern("LIL").pattern("TBT")
                        .unlockedBy("has_item", this.has(GrowableOresItems.Circuit)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.IRIDIUM_PLATE)
                        .define('I', Items.DIAMOND).define('B', GrowableOresItems.ALLOY_PLATE).define('T', GrowableOresItems.IRIDIUM_ORE)
                        .pattern("TBT").pattern("BIB").pattern("TBT")
                        .unlockedBy("has_item", this.has(GrowableOresItems.ALLOY_PLATE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.CARBON_FIBRE)
                        .define('I', GrowableOresItems.COAL_DUST)
                        .pattern("II ").pattern("II ").pattern("   ")
                        .unlockedBy("has_item", this.has(GrowableOresItems.COAL_DUST)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.CARBON_MESH)
                        .define('I', GrowableOresItems.CARBON_FIBRE)
                        .pattern("II ").pattern("   ").pattern("   ")
                        .unlockedBy("has_item", this.has(GrowableOresItems.CARBON_FIBRE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.COAL_BALL)
                        .define('I', GrowableOresItems.COAL_DUST).define('B', Items.FLINT)
                        .pattern("III").pattern("IBI").pattern("III")
                        .unlockedBy("has_item", this.has(GrowableOresItems.COAL_DUST)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.COAL_CHUNK)
                        .define('I', GrowableOresItems.COAL_BALL).define('B', Items.IRON_BLOCK)
                        .pattern("III").pattern("IBI").pattern("III")
                        .unlockedBy("has_item", this.has(GrowableOresItems.COAL_BALL)).save(this.output);


                shaped(RecipeCategory.MISC, GrowableOresItems.RE_BATTERY)
                        .define('T', GrowableOresBlocks.INSULATED_TIN_CABLE).define('I', GrowableOresItems.IRON_CASING).define('B', Items.REDSTONE)
                        .pattern(" T ").pattern("IBI").pattern("IBI")
                        .unlockedBy("has_item", this.has(GrowableOresItems.IRON_CASING)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.ADVANCED_RE_BATTERY)
                        .define('T', GrowableOresBlocks.INSULATED_COPPER_CABLE).define('I', GrowableOresItems.BRONZE_CASING).define('B', GrowableOresItems.SULFUR_DUST).define('C', GrowableOresItems.LEAD_DUST)
                        .pattern("TIT").pattern("IBI").pattern("ICI")
                        .unlockedBy("has_item", this.has(GrowableOresItems.BRONZE_CASING)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.LAPOTRON_CRYSTAL)
                        .define('T', GrowableOresItems.Advanced_Circuit).define('I', GrowableOresItems.LAPIS_DUST).define('B', GrowableOresItems.ENERGY_CRYSTAL)
                        .pattern("ITI").pattern("IBI").pattern("ITI")
                        .unlockedBy("has_item", this.has(GrowableOresItems.ENERGY_CRYSTAL)).save(this.output);

                shaped(RecipeCategory.MISC, MapleArmorItems.ROLLING)
                        .define('T', Items.IRON_INGOT).define('I', Items.STICK)
                        .pattern("TT ").pattern("TII").pattern("TT ")
                        .unlockedBy("has_item", this.has(Items.IRON_INGOT)).save(this.output);

                shaped(RecipeCategory.MISC, MapleArmorItems.ROLLING)
                        .define('T', Items.IRON_INGOT).define('I', Items.STICK)
                        .pattern(" TT").pattern("IIT").pattern(" TT")
                        .unlockedBy("has_item", this.has(Items.IRON_INGOT)).save(this.output, "right_side_tool_rolling");

                shaped(RecipeCategory.MISC, MapleArmorItems.CUTTING)
                        .define('T', Items.IRON_INGOT).define('I', GrowableOresItems.IRON_PLATE)
                        .pattern("I I").pattern(" I ").pattern("T T")
                        .unlockedBy("has_item", this.has(Items.IRON_INGOT)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.Coil)
                        .define('T', Items.IRON_INGOT).define('I', GrowableOresBlocks.COPPER_CABLE)
                        .pattern("III").pattern("ITI").pattern("III")
                        .unlockedBy("has_item", this.has(Items.IRON_INGOT)).save(this.output);

                shaped(RecipeCategory.MISC, GeneralBlocks.Machine)
                        .define('I', GrowableOresItems.IRON_PLATE)
                        .pattern("III").pattern("I I").pattern("III")
                        .unlockedBy("has_item", this.has(GrowableOresItems.IRON_PLATE)).save(this.output);

                shaped(RecipeCategory.MISC, GeneralBlocks.Advanced_Machine)
                        .define('I', GrowableOresItems.STEEL_PLATE).define('M', GeneralBlocks.Machine).define('C', GrowableOresItems.CARBON_PLATE).define('A', GrowableOresItems.ALLOY_PLATE)
                        .pattern("ICI").pattern("AMA").pattern("ICI")
                        .unlockedBy("has_item", this.has(GrowableOresItems.IRON_PLATE)).save(this.output);

                shaped(RecipeCategory.MISC, GrowableOresItems.Electric_Motor)
                        .define('I', GrowableOresItems.Coil).define('C', GrowableOresItems.IRON_CASING).define('M', Items.IRON_INGOT)
                        .pattern(" C ").pattern("IMI").pattern(" C ")
                        .unlockedBy("has_item", this.has(Items.IRON_INGOT)).save(this.output);

                shapeless(RecipeCategory.MISC, GrowableOresItems.Scrap_box)
                        .requires(GrowableOresItems.Scrap,9)
                        .unlockedBy("has_item", this.has(GrowableOresItems.Scrap)).save(this.output);

                oreSmelting(List.of(GrowableOresItems.CRUSHED_COPPER, GrowableOresItems.PURIFIED_COPPER, GrowableOresItems.COPPER_DUST), RecipeCategory.MISC, CookingBookCategory.MISC, Items.COPPER_INGOT, 0.45F, 300, "copper_ingot");
                oreSmelting(List.of(GrowableOresItems.BRONZE_DUST), RecipeCategory.MISC, CookingBookCategory.MISC, GrowableOresItems.BRONZE_INGOT, 0.45F, 300, "bronze_ingot");
                oreSmelting(List.of(GeneralBlocks.Uranium_Ore, GeneralBlocks.Deepslate_Uranium_Ore, GrowableOresItems.CRUSHED_URANIUM, GrowableOresItems.PURIFIED_URANIUM), RecipeCategory.MISC, CookingBookCategory.MISC, GrowableOresItems.URANIUM_INGOT, 0.45F, 300, "uranium_ingot");
                oreSmelting(List.of(GrowableOresItems.TIN_DUST, GeneralBlocks.Tin_Ore, GeneralBlocks.Deepslate_Tin_Ore, GrowableOresItems.CRUSHED_TIN, GrowableOresItems.PURIFIED_TIN), RecipeCategory.MISC, CookingBookCategory.MISC, GrowableOresItems.TIN_INGOT, 0.45F, 300, "tin_ingot");
                oreSmelting(List.of(GrowableOresItems.LEAD_DUST, GeneralBlocks.Lead_Ore, GeneralBlocks.Deepslate_Lead_Ore, GrowableOresItems.CRUSHED_LEAD, GrowableOresItems.PURIFIED_LEAD), RecipeCategory.MISC, CookingBookCategory.MISC, GrowableOresItems.LEAD_INGOT, 0.45F, 300, "lead_ingot");
                oreSmelting(List.of(GrowableOresItems.CRUSHED_SILVER, GrowableOresItems.PURIFIED_SILVER, GrowableOresItems.SILVER_DUST), RecipeCategory.MISC, CookingBookCategory.MISC, GrowableOresItems.SILVER_INGOT, 0.45F, 300, "silver_ingot");
                oreSmelting(List.of(GrowableOresItems.CRUSHED_IRON, GrowableOresItems.PURIFIED_IRON, GrowableOresItems.IRON_DUST), RecipeCategory.MISC, CookingBookCategory.MISC, Items.IRON_INGOT, 0.45F, 300, "iron_ingot");
                oreSmelting(List.of(GrowableOresItems.CRUSHED_GOLD, GrowableOresItems.PURIFIED_GOLD, GrowableOresItems.GOLD_DUST), RecipeCategory.MISC, CookingBookCategory.MISC, Items.GOLD_INGOT, 0.45F, 300, "gold_ingot");
            }
        };
    }

    @Override
    public String getName() {
        return "Material";
    }
}