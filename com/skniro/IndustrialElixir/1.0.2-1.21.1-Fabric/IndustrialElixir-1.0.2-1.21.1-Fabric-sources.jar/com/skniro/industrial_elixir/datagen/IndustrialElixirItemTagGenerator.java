package com.skniro.industrial_elixir.datagen;

import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class IndustrialElixirItemTagGenerator extends FabricTagProvider.ItemTagProvider {
   public IndustrialElixirItemTagGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
   }
   @Override
   protected void method_10514(class_7225.class_7874 arg) {
      getOrCreateTagBuilder(ModItemTags.BATTERY)
              .add(GrowableOresItems.RE_BATTERY)
              .add(GrowableOresItems.ADVANCED_RE_BATTERY)
              .add(GrowableOresItems.ENERGY_CRYSTAL)
              .add(GrowableOresItems.LAPOTRON_CRYSTAL);
      getOrCreateTagBuilder(class_3489.field_15558)
              .add(class_1792.method_7867(GeneralBlocks.Rubber_LEAVES))
              .setReplace(false);
      getOrCreateTagBuilder(class_3489.field_15528)
              .add(class_1792.method_7867(GeneralBlocks.Rubber_SAPLING))
              .setReplace(false);
      getOrCreateTagBuilder(class_3489.field_23212)
              .add(class_1792.method_7867(GeneralBlocks.Rubber_LOG))
              .add(class_1792.method_7867(GeneralBlocks.Rubber_Rubber_LOG))
              .add(class_1792.method_7867(GeneralBlocks.Rubber_WOOD))
              .add(class_1792.method_7867(GeneralBlocks.STRIPPED_Rubber_LOG))
              .add(class_1792.method_7867(GeneralBlocks.STRIPPED_Rubber_WOOD))
              .setReplace(false);
      getOrCreateTagBuilder(class_3489.field_15555)
              .add(class_1792.method_7867(GeneralBlocks.Rubber_BUTTON))
              .setReplace(false);
      getOrCreateTagBuilder(class_3489.field_15552)
              .add(class_1792.method_7867(GeneralBlocks.Rubber_DOOR))
              .setReplace(false);
      getOrCreateTagBuilder(class_3489.field_15550)
              .add(class_1792.method_7867(GeneralBlocks.Rubber_TRAPDOOR))
              .setReplace(false);
      getOrCreateTagBuilder(class_3489.field_15540)
              .add(class_1792.method_7867(GeneralBlocks.Rubber_PRESSURE_PLATE))
              .setReplace(false);
      getOrCreateTagBuilder(class_3489.field_15534)
              .add(class_1792.method_7867(GeneralBlocks.Rubber_SLAB))
              .setReplace(false);
      getOrCreateTagBuilder(class_3489.field_15557)
              .add(class_1792.method_7867(GeneralBlocks.Rubber_STAIRS))
              .setReplace(false);
      getOrCreateTagBuilder(class_3489.field_15537)
              .add(class_1792.method_7867(GeneralBlocks.Rubber_PLANKS))
              .setReplace(false);
      getOrCreateTagBuilder(class_3489.field_16585)
              .add(class_1792.method_7867(GeneralBlocks.Rubber_FENCE))
              .setReplace(false);
      getOrCreateTagBuilder(ModItemTags.SACRED_ORES)
              .add(class_1792.method_7867(GeneralBlocks.SACRED_Ore))
              .add(class_1792.method_7867(GeneralBlocks.Deepslate_SACRED_Ore))
              .setReplace(false);
      getOrCreateTagBuilder(ModItemTags.TIN_ORES)
              .add(class_1792.method_7867(GeneralBlocks.Tin_Ore))
              .add(class_1792.method_7867(GeneralBlocks.Deepslate_Tin_Ore))
              .setReplace(false);
      getOrCreateTagBuilder(ModItemTags.LEAD_ORES)
              .add(class_1792.method_7867(GeneralBlocks.Lead_Ore))
              .add(class_1792.method_7867(GeneralBlocks.Deepslate_Lead_Ore))
              .setReplace(false);
      getOrCreateTagBuilder(ModItemTags.DUST_TIN)
              .add(GrowableOresItems.TIN_DUST)
              .add(GrowableOresItems.PURIFIED_TIN)
              .add(GrowableOresItems.CRUSHED_TIN)
              .setReplace(false);
      getOrCreateTagBuilder(ModItemTags.DUST_COPPER)
              .add(GrowableOresItems.COPPER_DUST)
              .add(GrowableOresItems.PURIFIED_COPPER)
              .add(GrowableOresItems.CRUSHED_COPPER)
              .setReplace(false);
      getOrCreateTagBuilder(ModItemTags.REPAIRS_BRONZE_ARMOR)
              .add(GrowableOresItems.BRONZE_INGOT);
      getOrCreateTagBuilder(ModItemTags.BRONZE_TOOL_MATERIALS)
              .add(GrowableOresItems.BRONZE_INGOT);
      getOrCreateTagBuilder(ModItemTags.Diamond)
              .add(GrowableOresItems.INDUSTRIAL_DIAMOND)
              .add(class_1802.field_8477);
      getOrCreateTagBuilder(class_3489.field_15553)
              .add(class_1792.method_7867(GeneralBlocks.Reinforced_DOOR))
              .setReplace(false);
      getOrCreateTagBuilder(class_3489.field_15526)
              .add(class_1792.method_7867(GeneralBlocks.COBBLESTONE_STAIRS))
              .setReplace(false);
   }
}