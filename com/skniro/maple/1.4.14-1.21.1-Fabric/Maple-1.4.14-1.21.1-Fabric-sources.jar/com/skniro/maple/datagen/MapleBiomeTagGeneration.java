package com.skniro.maple.datagen;

import com.skniro.maple.Maple;
import com.skniro.maple.world.biome.MapleBiomeKeys;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6908;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;



public class MapleBiomeTagGeneration extends FabricTagProvider<class_1959> {


    public MapleBiomeTagGeneration(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, class_7924.field_41236, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        method_10512(class_6908.field_36517)
                .method_46835(MapleBiomeKeys.Maple_Grove);
        method_10512(class_6908.field_36512)
                .method_46835(MapleBiomeKeys.Sakura);
        method_10512(class_6908.field_37393)
                .method_46835(MapleBiomeKeys.Sakura)
                .method_46835(MapleBiomeKeys.Maple_Grove);

        // generate tags under data/maple/tags/worldgen/biome/has_structure/
        class_6862<class_1959> villageSakura = class_6862.method_40092(class_7924.field_41236, class_2960.method_60655(Maple.MOD_ID, "has_structure/village_sakura"));
        method_10512(villageSakura).method_46835(class_5321.method_29179(class_7924.field_41236, class_2960.method_60655("minecraft", "cherry_grove")));

        class_6862<class_1959> hotSpringBaths = class_6862.method_40092(class_7924.field_41236, class_2960.method_60655(Maple.MOD_ID, "has_structure/hot_spring_baths"));
        method_10512(hotSpringBaths).method_46835(MapleBiomeKeys.Sakura);
    }
}
