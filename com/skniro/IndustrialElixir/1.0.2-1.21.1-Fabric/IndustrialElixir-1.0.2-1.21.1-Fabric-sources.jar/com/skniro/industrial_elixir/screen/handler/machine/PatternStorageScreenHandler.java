package com.skniro.industrial_elixir.screen.handler.machine;

import com.skniro.industrial_elixir.block.entity.machine.PatternStorageBlockEntity;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.screen.AlchemyScreenHandlerType;
import com.skniro.industrial_elixir.screen.slot.BatteryFuelSlot;
import com.skniro.industrial_elixir.screen.slot.UpgradeSlot;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3913;
import net.minecraft.class_3919;

public class PatternStorageScreenHandler extends class_1703 {
    final class_1263 inventory;
    final class_3913 propertyDelegate;
    public final PatternStorageBlockEntity blockEntity;

    // Button ID for copy action
    public static final int COPY_BUTTON_ID = 0;

    // Client-side constructor
    public PatternStorageScreenHandler(int syncId, class_1661 playerInventory, class_2338 pos) {
        this(syncId, playerInventory, playerInventory.field_7546.method_37908().method_8321(pos), new class_3919(2));
    }

    // Server-side constructor
    public PatternStorageScreenHandler(int syncId, class_1661 playerInventory, class_2586 blockEntity, class_3913 delegate) {
        super(AlchemyScreenHandlerType.PatternStorage, syncId);
        method_17359((class_1263) blockEntity, 12);
        this.inventory = (class_1263) blockEntity;
        this.blockEntity = (PatternStorageBlockEntity) blockEntity;
        inventory.method_5435(playerInventory.field_7546);
        this.propertyDelegate = delegate;

        // Slot 1: Crystal input (left side - blank crystal goes here)
        this.method_7621(new class_1735(inventory, 1, 74, 34) {
            @Override
            public boolean method_7680(class_1799 stack) {
                return stack.method_31574(GrowableOresItems.PATTERN_STORAGE_CRYSTAL);
            }
        });

        // Slot 9: Item to scan (center)
        this.method_7621(new class_1735(inventory, 9, 23, 34) {
            @Override
            public boolean method_7680(class_1799 stack) {
                return !stack.method_31574(GrowableOresItems.PATTERN_STORAGE_CRYSTAL);
            }
        });

        // Slot 3: Energy / Battery (bottom-right area)
        this.method_7621(new BatteryFuelSlot(inventory, 3, 131, 63, this.blockEntity.getEnergyTier()));

        // Slot 10: Copy target crystal (right side, for copying patterns)
        this.method_7621(new class_1735(inventory, 10, 111, 34) {
            @Override
            public boolean method_7680(class_1799 stack) {
                return stack.method_31574(GrowableOresItems.PATTERN_STORAGE_CRYSTAL)
                        && !PatternStorageBlockEntity.hasPatternData(stack);
            }
            @Override
            public int method_7675() {
                return 1;
            }
        });

        addUpgradeSlots();
        addPlayerInventory(playerInventory);
        addPlayerHotbar(playerInventory);
        method_17360(propertyDelegate);
    }

    private void addUpgradeSlots() {
        this.method_7621(new UpgradeSlot(inventory, 4, 151, 9));
        this.method_7621(new UpgradeSlot(inventory, 5, 151, 27));
        this.method_7621(new UpgradeSlot(inventory, 6, 151, 45));
        this.method_7621(new UpgradeSlot(inventory, 7, 151, 63));
    }

    public boolean isCrafting() {
        return propertyDelegate.method_17390(0) > 0;
    }

    public int getScaledProgress() {
        int progress = this.propertyDelegate.method_17390(0);
        int maxProgress = this.propertyDelegate.method_17390(1);
        int progressArrowSize = 23;
        return maxProgress != 0 && progress != 0 ? progress * progressArrowSize / maxProgress : 0;
    }

    public int getScaledEnergyHeight() {
        long energy = blockEntity.energyContainer.amount;
        long capacity = blockEntity.energyContainer.getCapacity();
        int energyBarSize = 16;
        return Math.toIntExact(capacity != 0 && energy != 0 ? energy * energyBarSize / capacity : 0);
    }

    // Button handling for copy action
    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (id == COPY_BUTTON_ID) {
            if (!player.method_37908().method_8608()) {
                this.blockEntity.copyPattern();
            }
            return true;
        }
        return super.method_7604(player, id);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int invSlot) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(invSlot);
        if (slot != null && slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();
            if (invSlot < this.inventory.method_5439()) {
                if (!this.method_7616(originalStack, this.inventory.method_5439(), this.field_7761.size(), true)) {
                    return class_1799.field_8037;
                }
            } else if (!this.method_7616(originalStack, 0, this.inventory.method_5439(), false)) {
                return class_1799.field_8037;
            }

            if (originalStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }

        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return this.inventory.method_5443(player);
    }

    private void addPlayerInventory(class_1661 playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.method_7621(new class_1735(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }
    }

    private void addPlayerHotbar(class_1661 playerInventory) {
        for (int i = 0; i < 9; ++i) {
            this.method_7621(new class_1735(playerInventory, i, 8 + i * 18, 142));
        }
    }
}
