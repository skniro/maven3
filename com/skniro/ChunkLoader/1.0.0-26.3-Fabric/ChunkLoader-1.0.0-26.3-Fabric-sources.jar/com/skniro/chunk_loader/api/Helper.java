package com.skniro.chunk_loader.api;

import com.skniro.chunk_loader.SkniroChunkLoader;
import net.minecraft.resources.Identifier;

public class Helper {

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(SkniroChunkLoader.MOD_ID, path);
    }
}
