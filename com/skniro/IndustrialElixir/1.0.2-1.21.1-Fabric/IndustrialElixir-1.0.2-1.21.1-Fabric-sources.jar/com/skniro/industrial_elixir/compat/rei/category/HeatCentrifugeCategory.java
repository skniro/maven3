package com.skniro.industrial_elixir.compat.rei.category;

import com.skniro.industrial_elixir.api.Helper;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.compat.rei.display.HeatCentrifugeDisplay;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import me.shedaniel.math.Point;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.gui.Renderer;
import me.shedaniel.rei.api.client.gui.widgets.Widget;
import me.shedaniel.rei.api.client.gui.widgets.Widgets;
import me.shedaniel.rei.api.client.registry.display.DisplayCategory;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import java.util.LinkedList;
import java.util.List;

public class HeatCentrifugeCategory implements DisplayCategory<HeatCentrifugeDisplay> {
    public static final class_2960 TEXTURE = Helper.id("textures/gui/container/machine/heatcentrifuge.png");

    @Override
    public CategoryIdentifier<? extends HeatCentrifugeDisplay> getCategoryIdentifier() {
        return HeatCentrifugeDisplay.HEAT_CENTRIFUGE;
    }

    @Override
    public class_2561 getTitle() {
        return class_2561.method_43471(FurnitureStrings.Heat_Centrifuge);
    }

    @Override
    public Renderer getIcon() {
        return EntryStacks.of(GrowableOresBlocks.HEAT_CENTRIFUGE.method_8389().method_7854());
    }

    @Override
    public List<Widget> setupDisplay(HeatCentrifugeDisplay display, Rectangle bounds) {
        Point startPoint = new Point(bounds.getCenterX() - 87, bounds.getCenterY() - 35);
        List<Widget> widgets = new LinkedList<>();

        widgets.add(Widgets.createTexturedWidget(TEXTURE, new Rectangle(startPoint.x, startPoint.y, 175, 82)));

        widgets.add(Widgets.createTexturedWidget(TEXTURE,
                new Rectangle(startPoint.x + 129, startPoint.y + 45, 13, 16),
                176, 0));

        widgets.add(Widgets.createSlot(new Point(startPoint.x + 52, startPoint.y + 33))
                .entries(display.getInputEntries().get(0)).markInput());

        widgets.add(Widgets.createSlot(new Point(startPoint.x + 104, startPoint.y + 16))
                .entries(display.getOutputEntries().get(0)).disableBackground().markOutput());

        if (display.getOutputEntries().size() > 1) {
            widgets.add(Widgets.createSlot(new Point(startPoint.x + 104, startPoint.y + 34))
                    .entries(display.getOutputEntries().get(1)).disableBackground().markOutput());
        }

        if (display.getOutputEntries().size() > 2) {
            widgets.add(Widgets.createSlot(new Point(startPoint.x + 104, startPoint.y + 52))
                    .entries(display.getOutputEntries().get(2)).disableBackground().markOutput());
        }

        widgets.add(Widgets.createDrawableWidget((context, mouseX, mouseY, delta) -> {
            long ticks = System.currentTimeMillis() / 50;
            int totalTicks = 72;
            int arrowWidth = 26;
            int currentTick = (int) (ticks % totalTicks);
            int progress = currentTick * arrowWidth / totalTicks;
            context.method_25290(TEXTURE, startPoint.x + 70, startPoint.y + 34, 189, 0, progress, 16, 256, 256);

            int count = display.getCount();
            if (count > 1) {
                class_327 font = class_310.method_1551().field_1772;
                String text = String.valueOf(count);
                context.method_51433(font, text, startPoint.x + 52 + 16 - font.method_1727(text) - 1, startPoint.y + 34 + 16 - 8 - 1, 0xFFFFFFFF, true);
            }
        }));

        return widgets;
    }

    @Override
    public int getDisplayHeight() {
        return 90;
    }
}
