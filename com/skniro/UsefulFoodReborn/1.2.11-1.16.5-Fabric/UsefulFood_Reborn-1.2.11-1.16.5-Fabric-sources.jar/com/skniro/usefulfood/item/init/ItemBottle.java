package com.skniro.usefulfood.item.init;

import com.skniro.usefulfood.item.UsefulFoodItems;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1839;
import net.minecraft.class_1937;

public class ItemBottle
        extends class_1792 {
    private static final int MAX_USE_TIME = 32;

    public ItemBottle(class_1793 settings) {
        super(settings);
    }


    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        class_1799 itemStack = super.method_7861(stack, world, user);
        return user instanceof class_1657 && ((class_1657)user).field_7503.field_7477 ? itemStack : new class_1799(class_1802.field_8469);
    }

    @Override
    public int method_7881(class_1799 stack) {
        return MAX_USE_TIME;
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8946;
    }

}
