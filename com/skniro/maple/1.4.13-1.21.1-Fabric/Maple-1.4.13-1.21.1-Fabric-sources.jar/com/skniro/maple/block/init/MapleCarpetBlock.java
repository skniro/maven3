package com.skniro.maple.block.init;

import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3486;
import net.minecraft.class_3726;
import net.minecraft.class_4538;


public class MapleCarpetBlock extends class_2248 {
    protected static final class_265 SHAPE = class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 1.0D, 16.0D);
    public static final class_2753 FACING = class_2741.field_12481;;

    public MapleCarpetBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 view, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        if (!state.method_26184(world, pos)) {
            return class_2246.field_10124.method_9564();
        }
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2680 down = world.method_8320(pos.method_10074());

        return down.method_26225() || down.method_26227().method_15767(class_3486.field_15517);
    }
}
