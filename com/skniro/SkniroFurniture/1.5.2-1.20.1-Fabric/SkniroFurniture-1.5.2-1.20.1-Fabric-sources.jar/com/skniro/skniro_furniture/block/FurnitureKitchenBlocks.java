package com.skniro.skniro_furniture.block;

import com.skniro.skniro_furniture.Furniture;
import com.skniro.skniro_furniture.block.init.*;
import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public class FurnitureKitchenBlocks {
    public static final class_2248 WHITE_OVEN = registerBlock("white_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 ORANGE_OVEN = registerBlock("orange_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 MAGENTA_OVEN = registerBlock("magenta_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_BLUE_OVEN = registerBlock("light_blue_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 YELLOW_OVEN = registerBlock("yellow_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIME_OVEN = registerBlock("lime_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PINK_OVEN = registerBlock("pink_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GRAY_OVEN = registerBlock("gray_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_GRAY_OVEN = registerBlock("light_gray_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 CYAN_OVEN = registerBlock("cyan_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PURPLE_OVEN = registerBlock("purple_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLUE_OVEN = registerBlock("blue_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BROWN_OVEN = registerBlock("brown_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GREEN_OVEN = registerBlock("green_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 RED_OVEN = registerBlock("red_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLACK_OVEN = registerBlock("black_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));

    public static final class_2248 OAK_PLANKS_OVEN = registerBlock("oak_planks_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 OAK_WOOD_OVEN = registerBlock("oak_wood_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 SPRUCE_PLANKS_OVEN = registerBlock("spruce_planks_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_9975).method_22488()));
    public static final class_2248 SPRUCE_WOOD_OVEN = registerBlock("spruce_wood_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_9975).method_22488()));
    public static final class_2248 BIRCH_PLANKS_OVEN = registerBlock("birch_planks_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10148).method_22488()));
    public static final class_2248 BIRCH_WOOD_OVEN = registerBlock("birch_wood_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10148).method_22488()));
    public static final class_2248 JUNGLE_PLANKS_OVEN = registerBlock("jungle_planks_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10334).method_22488()));
    public static final class_2248 JUNGLE_WOOD_OVEN = registerBlock("jungle_wood_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10334).method_22488()));
    public static final class_2248 ACACIA_PLANKS_OVEN = registerBlock("acacia_planks_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10218).method_22488()));
    public static final class_2248 ACACIA_WOOD_OVEN = registerBlock("acacia_wood_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10218).method_22488()));
    public static final class_2248 DARK_OAK_PLANKS_OVEN = registerBlock("dark_oak_planks_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10075).method_22488()));
    public static final class_2248 DARK_OAK_WOOD_OVEN = registerBlock("dark_oak_wood_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_10075).method_22488()));
    public static final class_2248 MANGROVE_PLANKS_OVEN = registerBlock("mangrove_planks_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_37577).method_22488()));
    public static final class_2248 MANGROVE_WOOD_OVEN = registerBlock("mangrove_wood_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_37577).method_22488()));
    public static final class_2248 CHERRY_PLANKS_OVEN = registerBlock("cherry_planks_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_42751).method_22488()));
    public static final class_2248 CHERRY_WOOD_OVEN = registerBlock("cherry_wood_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_42751).method_22488()));
    public static final class_2248 CRIMSON_PLANKS_OVEN = registerBlock("crimson_planks_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_22126).method_22488()));
    public static final class_2248 CRIMSON_HYPHAE_OVEN = registerBlock("crimson_wood_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_22126).method_22488()));
    public static final class_2248 WARPED_PLANKS_OVEN = registerBlock("warped_planks_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_22127).method_22488()));
    public static final class_2248 WARPED_HYPHAE_OVEN = registerBlock("warped_wood_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_22127).method_22488()));
    public static final class_2248 BAMBOO_PLANKS_OVEN = registerBlock("bamboo_planks_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_40294).method_22488()));
    public static final class_2248 BAMBOO_BLOCK_OVEN = registerBlock("bamboo_wood_oven", new OvenBlock(class_4970.class_2251.method_9630(class_2246.field_40294).method_22488()));

    public static final class_2248 WHITE_KITCHEN_COUNTER = registerBlock("white_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 ORANGE_KITCHEN_COUNTER = registerBlock("orange_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 MAGENTA_KITCHEN_COUNTER = registerBlock("magenta_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_BLUE_KITCHEN_COUNTER = registerBlock("light_blue_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 YELLOW_KITCHEN_COUNTER = registerBlock("yellow_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIME_KITCHEN_COUNTER = registerBlock("lime_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PINK_KITCHEN_COUNTER = registerBlock("pink_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GRAY_KITCHEN_COUNTER = registerBlock("gray_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_GRAY_KITCHEN_COUNTER = registerBlock("light_gray_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 CYAN_KITCHEN_COUNTER = registerBlock("cyan_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PURPLE_KITCHEN_COUNTER = registerBlock("purple_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLUE_KITCHEN_COUNTER = registerBlock("blue_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BROWN_KITCHEN_COUNTER = registerBlock("brown_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GREEN_KITCHEN_COUNTER = registerBlock("green_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 RED_KITCHEN_COUNTER = registerBlock("red_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLACK_KITCHEN_COUNTER = registerBlock("black_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));

    public static final class_2248 OAK_PLANKS_KITCHEN_COUNTER = registerBlock("oak_planks_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 OAK_WOOD_KITCHEN_COUNTER = registerBlock("oak_wood_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 SPRUCE_PLANKS_KITCHEN_COUNTER = registerBlock("spruce_planks_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_9975).method_22488()));
    public static final class_2248 SPRUCE_WOOD_KITCHEN_COUNTER = registerBlock("spruce_wood_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_9975).method_22488()));
    public static final class_2248 BIRCH_PLANKS_KITCHEN_COUNTER = registerBlock("birch_planks_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10148).method_22488()));
    public static final class_2248 BIRCH_WOOD_KITCHEN_COUNTER = registerBlock("birch_wood_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10148).method_22488()));
    public static final class_2248 JUNGLE_PLANKS_KITCHEN_COUNTER = registerBlock("jungle_planks_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10334).method_22488()));
    public static final class_2248 JUNGLE_WOOD_KITCHEN_COUNTER = registerBlock("jungle_wood_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10334).method_22488()));
    public static final class_2248 ACACIA_PLANKS_KITCHEN_COUNTER = registerBlock("acacia_planks_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10218).method_22488()));
    public static final class_2248 ACACIA_WOOD_KITCHEN_COUNTER = registerBlock("acacia_wood_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10218).method_22488()));
    public static final class_2248 DARK_OAK_PLANKS_KITCHEN_COUNTER = registerBlock("dark_oak_planks_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10075).method_22488()));
    public static final class_2248 DARK_OAK_WOOD_KITCHEN_COUNTER = registerBlock("dark_oak_wood_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_10075).method_22488()));
    public static final class_2248 MANGROVE_PLANKS_KITCHEN_COUNTER = registerBlock("mangrove_planks_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_37577).method_22488()));
    public static final class_2248 MANGROVE_WOOD_KITCHEN_COUNTER = registerBlock("mangrove_wood_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_37577).method_22488()));
    public static final class_2248 CHERRY_PLANKS_KITCHEN_COUNTER = registerBlock("cherry_planks_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_42751).method_22488()));
    public static final class_2248 CHERRY_WOOD_KITCHEN_COUNTER = registerBlock("cherry_wood_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_42751).method_22488()));
    public static final class_2248 CRIMSON_PLANKS_KITCHEN_COUNTER = registerBlock("crimson_planks_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_22126).method_22488()));
    public static final class_2248 CRIMSON_HYPHAE_KITCHEN_COUNTER = registerBlock("crimson_wood_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_22126).method_22488()));
    public static final class_2248 WARPED_PLANKS_KITCHEN_COUNTER = registerBlock("warped_planks_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_22127).method_22488()));
    public static final class_2248 WARPED_HYPHAE_KITCHEN_COUNTER = registerBlock("warped_wood_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_22127).method_22488()));
    public static final class_2248 BAMBOO_PLANKS_KITCHEN_COUNTER = registerBlock("bamboo_planks_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_40294).method_22488()));
    public static final class_2248 BAMBOO_BLOCK_KITCHEN_COUNTER = registerBlock("bamboo_wood_kitchen_counter", new KitchenCounterBlock(class_4970.class_2251.method_9630(class_2246.field_40294).method_22488()));


    //Counter Drawer
    public static final class_2248 WHITE_KITCHEN_COUNTER_DRAWER = registerBlock("white_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 ORANGE_KITCHEN_COUNTER_DRAWER = registerBlock("orange_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 MAGENTA_KITCHEN_COUNTER_DRAWER = registerBlock("magenta_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_BLUE_KITCHEN_COUNTER_DRAWER = registerBlock("light_blue_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 YELLOW_KITCHEN_COUNTER_DRAWER = registerBlock("yellow_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIME_KITCHEN_COUNTER_DRAWER = registerBlock("lime_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PINK_KITCHEN_COUNTER_DRAWER = registerBlock("pink_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GRAY_KITCHEN_COUNTER_DRAWER = registerBlock("gray_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_GRAY_KITCHEN_COUNTER_DRAWER = registerBlock("light_gray_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 CYAN_KITCHEN_COUNTER_DRAWER = registerBlock("cyan_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PURPLE_KITCHEN_COUNTER_DRAWER = registerBlock("purple_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLUE_KITCHEN_COUNTER_DRAWER = registerBlock("blue_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BROWN_KITCHEN_COUNTER_DRAWER = registerBlock("brown_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GREEN_KITCHEN_COUNTER_DRAWER = registerBlock("green_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 RED_KITCHEN_COUNTER_DRAWER = registerBlock("red_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLACK_KITCHEN_COUNTER_DRAWER = registerBlock("black_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));

    public static final class_2248 OAK_PLANKS_KITCHEN_COUNTER_DRAWER = registerBlock("oak_planks_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 OAK_WOOD_KITCHEN_COUNTER_DRAWER = registerBlock("oak_wood_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 SPRUCE_PLANKS_KITCHEN_COUNTER_DRAWER = registerBlock("spruce_planks_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_9975).method_22488()));
    public static final class_2248 SPRUCE_WOOD_KITCHEN_COUNTER_DRAWER = registerBlock("spruce_wood_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_9975).method_22488()));
    public static final class_2248 BIRCH_PLANKS_KITCHEN_COUNTER_DRAWER = registerBlock("birch_planks_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10148).method_22488()));
    public static final class_2248 BIRCH_WOOD_KITCHEN_COUNTER_DRAWER = registerBlock("birch_wood_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10148).method_22488()));
    public static final class_2248 JUNGLE_PLANKS_KITCHEN_COUNTER_DRAWER = registerBlock("jungle_planks_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10334).method_22488()));
    public static final class_2248 JUNGLE_WOOD_KITCHEN_COUNTER_DRAWER = registerBlock("jungle_wood_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10334).method_22488()));
    public static final class_2248 ACACIA_PLANKS_KITCHEN_COUNTER_DRAWER = registerBlock("acacia_planks_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10218).method_22488()));
    public static final class_2248 ACACIA_WOOD_KITCHEN_COUNTER_DRAWER = registerBlock("acacia_wood_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10218).method_22488()));
    public static final class_2248 DARK_OAK_PLANKS_KITCHEN_COUNTER_DRAWER = registerBlock("dark_oak_planks_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10075).method_22488()));
    public static final class_2248 DARK_OAK_WOOD_KITCHEN_COUNTER_DRAWER = registerBlock("dark_oak_wood_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_10075).method_22488()));
    public static final class_2248 MANGROVE_PLANKS_KITCHEN_COUNTER_DRAWER = registerBlock("mangrove_planks_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_37577).method_22488()));
    public static final class_2248 MANGROVE_WOOD_KITCHEN_COUNTER_DRAWER = registerBlock("mangrove_wood_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_37577).method_22488()));
    public static final class_2248 CHERRY_PLANKS_KITCHEN_COUNTER_DRAWER = registerBlock("cherry_planks_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_42751).method_22488()));
    public static final class_2248 CHERRY_WOOD_KITCHEN_COUNTER_DRAWER = registerBlock("cherry_wood_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_42751).method_22488()));
    public static final class_2248 CRIMSON_PLANKS_KITCHEN_COUNTER_DRAWER = registerBlock("crimson_planks_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_22126).method_22488()));
    public static final class_2248 CRIMSON_HYPHAE_KITCHEN_COUNTER_DRAWER = registerBlock("crimson_wood_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_22126).method_22488()));
    public static final class_2248 WARPED_PLANKS_KITCHEN_COUNTER_DRAWER = registerBlock("warped_planks_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_22127).method_22488()));
    public static final class_2248 WARPED_HYPHAE_KITCHEN_COUNTER_DRAWER = registerBlock("warped_wood_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_22127).method_22488()));
    public static final class_2248 BAMBOO_PLANKS_KITCHEN_COUNTER_DRAWER = registerBlock("bamboo_planks_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_40294).method_22488()));
    public static final class_2248 BAMBOO_BLOCK_KITCHEN_COUNTER_DRAWER = registerBlock("bamboo_wood_kitchen_counter_drawer", new KitchenCounterDrawerBlock(class_4970.class_2251.method_9630(class_2246.field_40294).method_22488()));

    public static final class_2248 WHITE_KITCHEN_CABINET = registerBlock("white_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 ORANGE_KITCHEN_CABINET = registerBlock("orange_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 MAGENTA_KITCHEN_CABINET = registerBlock("magenta_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_BLUE_KITCHEN_CABINET = registerBlock("light_blue_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 YELLOW_KITCHEN_CABINET = registerBlock("yellow_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIME_KITCHEN_CABINET = registerBlock("lime_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PINK_KITCHEN_CABINET = registerBlock("pink_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GRAY_KITCHEN_CABINET = registerBlock("gray_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_GRAY_KITCHEN_CABINET = registerBlock("light_gray_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 CYAN_KITCHEN_CABINET = registerBlock("cyan_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PURPLE_KITCHEN_CABINET = registerBlock("purple_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLUE_KITCHEN_CABINET = registerBlock("blue_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BROWN_KITCHEN_CABINET = registerBlock("brown_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GREEN_KITCHEN_CABINET = registerBlock("green_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 RED_KITCHEN_CABINET = registerBlock("red_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLACK_KITCHEN_CABINET = registerBlock("black_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));

    public static final class_2248 OAK_PLANKS_KITCHEN_CABINET = registerBlock("oak_planks_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 OAK_WOOD_KITCHEN_CABINET = registerBlock("oak_wood_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 SPRUCE_PLANKS_KITCHEN_CABINET = registerBlock("spruce_planks_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_9975).method_22488()));
    public static final class_2248 SPRUCE_WOOD_KITCHEN_CABINET = registerBlock("spruce_wood_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_9975).method_22488()));
    public static final class_2248 BIRCH_PLANKS_KITCHEN_CABINET = registerBlock("birch_planks_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10148).method_22488()));
    public static final class_2248 BIRCH_WOOD_KITCHEN_CABINET = registerBlock("birch_wood_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10148).method_22488()));
    public static final class_2248 JUNGLE_PLANKS_KITCHEN_CABINET = registerBlock("jungle_planks_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10334).method_22488()));
    public static final class_2248 JUNGLE_WOOD_KITCHEN_CABINET = registerBlock("jungle_wood_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10334).method_22488()));
    public static final class_2248 ACACIA_PLANKS_KITCHEN_CABINET = registerBlock("acacia_planks_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10218).method_22488()));
    public static final class_2248 ACACIA_WOOD_KITCHEN_CABINET = registerBlock("acacia_wood_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10218).method_22488()));
    public static final class_2248 DARK_OAK_PLANKS_KITCHEN_CABINET = registerBlock("dark_oak_planks_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10075).method_22488()));
    public static final class_2248 DARK_OAK_WOOD_KITCHEN_CABINET = registerBlock("dark_oak_wood_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_10075).method_22488()));
    public static final class_2248 MANGROVE_PLANKS_KITCHEN_CABINET = registerBlock("mangrove_planks_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_37577).method_22488()));
    public static final class_2248 MANGROVE_WOOD_KITCHEN_CABINET = registerBlock("mangrove_wood_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_37577).method_22488()));
    public static final class_2248 CHERRY_PLANKS_KITCHEN_CABINET = registerBlock("cherry_planks_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_42751).method_22488()));
    public static final class_2248 CHERRY_WOOD_KITCHEN_CABINET = registerBlock("cherry_wood_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_42751).method_22488()));
    public static final class_2248 CRIMSON_PLANKS_KITCHEN_CABINET = registerBlock("crimson_planks_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_22126).method_22488()));
    public static final class_2248 CRIMSON_HYPHAE_KITCHEN_CABINET = registerBlock("crimson_wood_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_22126).method_22488()));
    public static final class_2248 WARPED_PLANKS_KITCHEN_CABINET = registerBlock("warped_planks_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_22127).method_22488()));
    public static final class_2248 WARPED_HYPHAE_KITCHEN_CABINET = registerBlock("warped_wood_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_22127).method_22488()));
    public static final class_2248 BAMBOO_PLANKS_KITCHEN_CABINET = registerBlock("bamboo_planks_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_40294).method_22488()));
    public static final class_2248 BAMBOO_BLOCK_KITCHEN_CABINET = registerBlock("bamboo_wood_kitchen_cabinet", new KitchenCabinetBlock(class_4970.class_2251.method_9630(class_2246.field_40294).method_22488()));

    public static final class_2248 WHITE_Fridge = registerBlock("white_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 ORANGE_Fridge = registerBlock("orange_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 MAGENTA_Fridge = registerBlock("magenta_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_BLUE_Fridge = registerBlock("light_blue_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 YELLOW_Fridge = registerBlock("yellow_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIME_Fridge = registerBlock("lime_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PINK_Fridge = registerBlock("pink_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GRAY_Fridge = registerBlock("gray_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_GRAY_Fridge = registerBlock("light_gray_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 CYAN_Fridge = registerBlock("cyan_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PURPLE_Fridge = registerBlock("purple_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLUE_Fridge = registerBlock("blue_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BROWN_Fridge = registerBlock("brown_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GREEN_Fridge = registerBlock("green_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 RED_Fridge = registerBlock("red_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLACK_Fridge = registerBlock("black_fridge", new FridgeBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));

    public static final class_2248 WHITE_KITCHEN_SINK = registerBlock("white_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 ORANGE_KITCHEN_SINK = registerBlock("orange_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 MAGENTA_KITCHEN_SINK = registerBlock("magenta_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_BLUE_KITCHEN_SINK = registerBlock("light_blue_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 YELLOW_KITCHEN_SINK = registerBlock("yellow_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIME_KITCHEN_SINK = registerBlock("lime_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PINK_KITCHEN_SINK = registerBlock("pink_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GRAY_KITCHEN_SINK = registerBlock("gray_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_GRAY_KITCHEN_SINK = registerBlock("light_gray_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 CYAN_KITCHEN_SINK = registerBlock("cyan_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PURPLE_KITCHEN_SINK = registerBlock("purple_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLUE_KITCHEN_SINK = registerBlock("blue_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BROWN_KITCHEN_SINK = registerBlock("brown_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GREEN_KITCHEN_SINK = registerBlock("green_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 RED_KITCHEN_SINK = registerBlock("red_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLACK_KITCHEN_SINK = registerBlock("black_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));

    public static final class_2248 OAK_PLANKS_KITCHEN_SINK = registerBlock("oak_planks_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 OAK_WOOD_KITCHEN_SINK = registerBlock("oak_wood_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 SPRUCE_PLANKS_KITCHEN_SINK = registerBlock("spruce_planks_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_9975).method_22488()));
    public static final class_2248 SPRUCE_WOOD_KITCHEN_SINK = registerBlock("spruce_wood_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_9975).method_22488()));
    public static final class_2248 BIRCH_PLANKS_KITCHEN_SINK = registerBlock("birch_planks_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10148).method_22488()));
    public static final class_2248 BIRCH_WOOD_KITCHEN_SINK = registerBlock("birch_wood_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10148).method_22488()));
    public static final class_2248 JUNGLE_PLANKS_KITCHEN_SINK = registerBlock("jungle_planks_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10334).method_22488()));
    public static final class_2248 JUNGLE_WOOD_KITCHEN_SINK = registerBlock("jungle_wood_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10334).method_22488()));
    public static final class_2248 ACACIA_PLANKS_KITCHEN_SINK = registerBlock("acacia_planks_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10218).method_22488()));
    public static final class_2248 ACACIA_WOOD_KITCHEN_SINK = registerBlock("acacia_wood_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10218).method_22488()));
    public static final class_2248 DARK_OAK_PLANKS_KITCHEN_SINK = registerBlock("dark_oak_planks_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10075).method_22488()));
    public static final class_2248 DARK_OAK_WOOD_KITCHEN_SINK = registerBlock("dark_oak_wood_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_10075).method_22488()));
    public static final class_2248 MANGROVE_PLANKS_KITCHEN_SINK = registerBlock("mangrove_planks_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_37577).method_22488()));
    public static final class_2248 MANGROVE_WOOD_KITCHEN_SINK = registerBlock("mangrove_wood_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_37577).method_22488()));
    public static final class_2248 CHERRY_PLANKS_KITCHEN_SINK = registerBlock("cherry_planks_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_42751).method_22488()));
    public static final class_2248 CHERRY_WOOD_KITCHEN_SINK = registerBlock("cherry_wood_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_42751).method_22488()));
    public static final class_2248 CRIMSON_PLANKS_KITCHEN_SINK = registerBlock("crimson_planks_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_22126).method_22488()));
    public static final class_2248 CRIMSON_HYPHAE_KITCHEN_SINK = registerBlock("crimson_wood_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_22126).method_22488()));
    public static final class_2248 WARPED_PLANKS_KITCHEN_SINK = registerBlock("warped_planks_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_22127).method_22488()));
    public static final class_2248 WARPED_HYPHAE_KITCHEN_SINK = registerBlock("warped_wood_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_22127).method_22488()));
    public static final class_2248 BAMBOO_PLANKS_KITCHEN_SINK = registerBlock("bamboo_planks_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_40294).method_22488()));
    public static final class_2248 BAMBOO_BLOCK_KITCHEN_SINK = registerBlock("bamboo_wood_kitchen_sink", new KitchenSinkBlock(class_4970.class_2251.method_9630(class_2246.field_40294).method_22488()));

    //Plate
    public static final class_2248 OAK_WOOD_Plate = registerBlock("oak_wood_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 OAK_PLANKS_Plate = registerBlock("oak_plank_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 SPRUCE_WOOD_Plate = registerBlock("spruce_wood_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_9975).method_22488()));
    public static final class_2248 SPRUCE_PLANKS_Plate = registerBlock("spruce_plank_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_9975).method_22488()));
    public static final class_2248 BIRCH_WOOD_Plate = registerBlock("birch_wood_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10148).method_22488()));
    public static final class_2248 BIRCH_PLANKS_Plate = registerBlock("birch_plank_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10148).method_22488()));
    public static final class_2248 JUNGLE_WOOD_Plate = registerBlock("jungle_wood_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10334).method_22488()));
    public static final class_2248 JUNGLE_PLANKS_Plate = registerBlock("jungle_plank_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10334).method_22488()));
    public static final class_2248 ACACIA_WOOD_Plate = registerBlock("acacia_wood_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10218).method_22488()));
    public static final class_2248 ACACIA_PLANKS_Plate = registerBlock("acacia_plank_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10218).method_22488()));
    public static final class_2248 DARK_OAK_WOOD_Plate = registerBlock("dark_oak_wood_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10075).method_22488()));
    public static final class_2248 DARK_OAK_PLANKS_Plate = registerBlock("dark_oak_plank_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10075).method_22488()));
    public static final class_2248 MANGROVE_WOOD_Plate = registerBlock("mangrove_wood_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_37577).method_22488()));
    public static final class_2248 MANGROVE_PLANKS_Plate = registerBlock("mangrove_plank_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_37577).method_22488()));
    public static final class_2248 CHERRY_WOOD_Plate = registerBlock("cherry_wood_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_42751).method_22488()));
    public static final class_2248 CHERRY_PLANKS_Plate = registerBlock("cherry_plank_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_42751).method_22488()));
    public static final class_2248 CRIMSON_HYPHAE_Plate = registerBlock("crimson_wood_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_22126).method_22488()));
    public static final class_2248 CRIMSON_PLANKS_Plate = registerBlock("crimson_plank_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_22126).method_22488()));
    public static final class_2248 WARPED_HYPHAE_Plate = registerBlock("warped_wood_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_22127).method_22488()));
    public static final class_2248 WARPED_PLANKS_Plate = registerBlock("warped_plank_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_22127).method_22488()));
    public static final class_2248 BAMBOO_BLOCK_Plate = registerBlock("bamboo_wood_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_40294).method_22488()));
    public static final class_2248 BAMBOO_PLANKS_Plate = registerBlock("bamboo_plank_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_40294).method_22488()));

    public static final class_2248 WHITE_Plate = registerBlock("white_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 ORANGE_Plate = registerBlock("orange_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 MAGENTA_Plate = registerBlock("magenta_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_BLUE_Plate = registerBlock("light_blue_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 YELLOW_Plate = registerBlock("yellow_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIME_Plate = registerBlock("lime_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PINK_Plate = registerBlock("pink_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GRAY_Plate = registerBlock("gray_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 LIGHT_GRAY_Plate = registerBlock("light_gray_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 CYAN_Plate = registerBlock("cyan_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 PURPLE_Plate = registerBlock("purple_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLUE_Plate = registerBlock("blue_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BROWN_Plate = registerBlock("brown_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 GREEN_Plate = registerBlock("green_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 RED_Plate = registerBlock("red_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));
    public static final class_2248 BLACK_Plate = registerBlock("black_plate", new PlateBlock(class_4970.class_2251.method_9630(class_2246.field_10153).method_22488()));

    private static class_2248 registerBlockWithoutItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_43902(Furniture.MOD_ID, name), block);
    }

    private static class_2248 registerBlock(String name, class_2248 block) {
        registerBlockItem(name, block);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_43902(Furniture.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_43902(Furniture.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
    }

    public static void registerKitchenBlocks() {
        Furniture.LOGGER.debug("Registering Kitchen Blocks for " + Furniture.MOD_ID);
    }
}
