package com.skniro.maple.datagen;

import com.google.common.collect.Lists;
import com.skniro.maple.Maple;
import com.skniro.maple.block.MapleBlocks;
import com.skniro.maple.item.MapleArmorItems;
import com.skniro.maple.item.MapleFoodComponents;
import com.skniro.maple.item.MapleItems;
import com.skniro.maple.tag.MapleItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_156;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2446;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2960;
import net.minecraft.class_3981;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import net.minecraft.data.server.recipe.*;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class MapleRecipeGeneration extends FabricRecipeProvider {
    public MapleRecipeGeneration(FabricDataOutput generator, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(generator, registryLookup);
    }


    public static final List<class_1935> STRIPPED_MAPLE = class_156.method_654(Lists.newArrayList(), list -> {
        list.add(MapleBlocks.STRIPPED_MAPLE_LOG);
        list.add(MapleBlocks.STRIPPED_MAPLE_WOOD);
    });
    public static final List<class_1935> Green_Tea = class_156.method_654(Lists.newArrayList(), list -> {
        list.add(MapleFoodComponents.Green_Tea_Leaves);
    });

    public static final List<class_1935> Cherry_INGOT = class_156.method_654(Lists.newArrayList(), list -> {
        list.add(MapleArmorItems.Cherry_PICKAXE);
        list.add(MapleArmorItems.Cherry_SHOVEL);
        list.add(MapleArmorItems.Cherry_AXE);
        list.add(MapleArmorItems.Cherry_HOE);
        list.add(MapleArmorItems.Cherry_SWORD);
        list.add(MapleArmorItems.Cherry_HELMET);
        list.add(MapleArmorItems.Cherry_CHESTPLATE);
        list.add(MapleArmorItems.Cherry_LEGGINGS);
        list.add(MapleArmorItems.Cherry_BOOTS);

    });

    @Override
    public void method_10419(class_8790 exporter) {
        class_2450.method_10448(class_7800.field_40640 ,MapleFoodComponents.MILK_BOTTOM,3).method_10454(class_1802.field_8103).method_10449(class_1802.field_8469,3).method_10442(method_32807(MapleFoodComponents.MILK_BOTTOM),
                method_10426(MapleFoodComponents.MILK_BOTTOM)).method_10442(method_32807(class_1802.field_8103),
                method_10426(class_1802.field_8103)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleItems.Flour,2).method_10454(class_1802.field_8861).method_10442(FabricRecipeProvider.method_32807(MapleItems.Flour),
                FabricRecipeProvider.method_10426(MapleItems.Flour)).method_10442(FabricRecipeProvider.method_32807(class_1802.field_8861),
                FabricRecipeProvider.method_10426(class_1802.field_8861)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleBlocks.SAKURA_SAPLING,2).method_10454(class_1802.field_8330).method_10442(FabricRecipeProvider.method_32807(MapleBlocks.SAKURA_SAPLING),
                FabricRecipeProvider.method_10426(MapleBlocks.SAKURA_SAPLING)).method_10442(FabricRecipeProvider.method_32807(class_1802.field_8330),
                FabricRecipeProvider.method_10426(class_1802.field_8330)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleFoodComponents.Anko_Dango,1)
                .method_10454(class_1802.field_8479)
                .method_10454(class_1802.field_8479)
                .method_10454(MapleFoodComponents.Mochi)
                .method_10454(MapleItems.SOYBEAN)
                .method_10454(class_1802.field_8648)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.Anko_Dango),
                FabricRecipeProvider.method_10426(MapleFoodComponents.Anko_Dango)).method_10442(FabricRecipeProvider.method_32807(class_1802.field_8479),
                FabricRecipeProvider.method_10426(class_1802.field_8479)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleFoodComponents.Mochi,2)
                .method_10454(MapleFoodComponents.Cooked_Rice)
                .method_10454(MapleFoodComponents.Cooked_Rice)
                .method_10454(MapleFoodComponents.Cooked_Rice)
                .method_10454(MapleFoodComponents.Cooked_Rice)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.Mochi),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.Mochi))
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.Cooked_Rice),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.Cooked_Rice)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleFoodComponents.SakuraMochi,2)
                .method_10454(MapleFoodComponents.Mochi)
                .method_10454(MapleBlocks.SAKURA_LEAVES)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.Mochi),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.Mochi))
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.Cooked_Rice),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.Cooked_Rice)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleItems.Cream,3)
                .method_10454(MapleFoodComponents.MILK_BOTTOM)
                .method_10454(MapleFoodComponents.MILK_BOTTOM)
                .method_10442(FabricRecipeProvider.method_32807(MapleItems.Cream),
                        FabricRecipeProvider.method_10426(MapleItems.Cream))
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.MILK_BOTTOM),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.MILK_BOTTOM)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleFoodComponents.Cooked_Rice,2)
                .method_10454(MapleItems.Rice)
                .method_10454(MapleItems.Rice)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.Cooked_Rice),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.Cooked_Rice))
                .method_10442(FabricRecipeProvider.method_32807(MapleItems.Rice),
                        FabricRecipeProvider.method_10426(MapleItems.Rice)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleFoodComponents.Kinako_Dango,1)
                .method_10454(class_1802.field_8479)
                .method_10454(MapleFoodComponents.Mochi)
                .method_10454(MapleItems.SOYBEAN)
                .method_10454(class_1802.field_8648)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.Kinako_Dango),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.Kinako_Dango))
                .method_10442(FabricRecipeProvider.method_32807(class_1802.field_8479),
                        FabricRecipeProvider.method_10426(class_1802.field_8479)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleFoodComponents.Zunda_Dango,1)
                .method_10454(class_1802.field_8479)
                .method_10454(MapleFoodComponents.Mochi)
                .method_10454(MapleItems.SOYBEAN)
                .method_10454(MapleItems.SOYBEAN)
                .method_10454(class_1802.field_8648)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.Zunda_Dango),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.Zunda_Dango))
                .method_10442(FabricRecipeProvider.method_32807(class_1802.field_8479),
                        FabricRecipeProvider.method_10426(class_1802.field_8479)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleFoodComponents.Sanshoku_Dango,1)
                .method_10454(class_1802.field_8479)
                .method_10454(MapleFoodComponents.Mochi)
                .method_10454(class_1802.field_8602)
                .method_10454(MapleBlocks.SAKURA_LEAVES)
                .method_10454(class_1802.field_8648)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.Sanshoku_Dango),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.Sanshoku_Dango))
                .method_10442(FabricRecipeProvider.method_32807(class_1802.field_8479),
                        FabricRecipeProvider.method_10426(class_1802.field_8479)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleFoodComponents.TOFU,1)
                .method_10454(MapleItems.SOYBEAN)
                .method_10454(MapleItems.SOYBEAN)
                .method_10454(class_1802.field_8705)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.TOFU),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.TOFU))
                .method_10442(FabricRecipeProvider.method_32807(MapleItems.SOYBEAN),
                        FabricRecipeProvider.method_10426(MapleItems.SOYBEAN)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleFoodComponents.MILK_ICECREAM,2)
                .method_10454(MapleItems.Cream)
                .method_10454(MapleFoodComponents.MILK_BOTTOM)
                .method_10454(class_1802.field_8705)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.MILK_ICECREAM),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.MILK_ICECREAM))
                .method_10442(FabricRecipeProvider.method_32807(MapleItems.Cream),
                        FabricRecipeProvider.method_10426(MapleItems.Cream))
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.MILK_BOTTOM),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.MILK_BOTTOM)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 ,MapleFoodComponents.Beef_Rice,1)
                .method_10454(MapleFoodComponents.Cooked_Rice)
                .method_10454(class_1802.field_8046)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.Cooked_Rice),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.Cooked_Rice))
                .method_10442(FabricRecipeProvider.method_32807(class_1802.field_8046),
                        FabricRecipeProvider.method_10426(class_1802.field_8046))
                .method_10431(exporter);

        class_2450.method_10448(class_7800.field_40635 ,MapleBlocks.Maple_CARPET,2)
                .method_10449(MapleBlocks.MAPLE_LEAVES,2)
                .method_10442(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_LEAVES),
                        FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_LEAVES))
                .method_10431(exporter);

        class_2450.method_10448(class_7800.field_40635 ,MapleBlocks.RED_MAPLE_CARPET,2)
                .method_10449(MapleBlocks.RED_MAPLE_LEAVES,2)
                .method_10442(FabricRecipeProvider.method_32807(MapleBlocks.RED_MAPLE_LEAVES),
                        FabricRecipeProvider.method_10426(MapleBlocks.RED_MAPLE_LEAVES))
                .method_10431(exporter);

        class_2450.method_10448(class_7800.field_40635 ,MapleBlocks.GINKGO_CARPET,2)
                .method_10449(MapleBlocks.GINKGO_LEAVES,2)
                .method_10442(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_LEAVES),
                        FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_LEAVES))
                .method_10431(exporter);

        class_2450.method_10448(class_7800.field_40635 ,MapleBlocks.SAKURA_CARPET,2)
                .method_10449(MapleBlocks.SAKURA_LEAVES,2)
                .method_10442(FabricRecipeProvider.method_32807(MapleBlocks.SAKURA_LEAVES),
                        FabricRecipeProvider.method_10426(MapleBlocks.SAKURA_LEAVES))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', class_2246.field_10102)
                .method_10434('i', class_2246.field_41072)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10102),
                        FabricRecipeProvider.method_10426(class_2246.field_10102))
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_41072),
                        FabricRecipeProvider.method_10426(class_2246.field_41072))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.GREEN_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8408)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8408),
                        FabricRecipeProvider.method_10426(class_1802.field_8408))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.ORANGE_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8492)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8492),
                        FabricRecipeProvider.method_10426(class_1802.field_8492))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.MAGENTA_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8669)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8669),
                        FabricRecipeProvider.method_10426(class_1802.field_8669))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.LIGHT_BLUE_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8273)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8273),
                        FabricRecipeProvider.method_10426(class_1802.field_8273))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.YELLOW_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8192)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8192),
                        FabricRecipeProvider.method_10426(class_1802.field_8192))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.LIME_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8131)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8131),
                        FabricRecipeProvider.method_10426(class_1802.field_8131))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.PINK_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8330)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8330),
                        FabricRecipeProvider.method_10426(class_1802.field_8330))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.GRAY_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8298)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8298),
                        FabricRecipeProvider.method_10426(class_1802.field_8298))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.LIGHT_GRAY_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8851)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8851),
                        FabricRecipeProvider.method_10426(class_1802.field_8851))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.CYAN_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8632)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8632),
                        FabricRecipeProvider.method_10426(class_1802.field_8632))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.PURPLE_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8296)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8296),
                        FabricRecipeProvider.method_10426(class_1802.field_8296))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.BLUE_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8345)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8345),
                        FabricRecipeProvider.method_10426(class_1802.field_8345))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.BROWN_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8099)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8099),
                        FabricRecipeProvider.method_10426(class_1802.field_8099))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634 ,MapleBlocks.RED_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8408)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.PLASTER),
                        FabricRecipeProvider.method_10426(MapleBlocks.PLASTER))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8264),
                        FabricRecipeProvider.method_10426(class_1802.field_8264))
                .method_10431(exporter);

        class_2447.method_10437(class_7800.field_40634 ,MapleBlocks.Iron_Sea_Lantern).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', class_2246.field_10174)
                .method_10434('i', class_1802.field_8675)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10174),
                        FabricRecipeProvider.method_10426(class_2246.field_10174))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8675),
                        FabricRecipeProvider.method_10426(class_1802.field_8675))
                .method_10431(exporter);

        class_2447.method_10437(class_7800.field_40634 ,MapleBlocks.Gold_Sea_Lantern).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', class_2246.field_10174)
                .method_10434('i', class_1802.field_8397)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10174),
                        FabricRecipeProvider.method_10426(class_2246.field_10174))
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8397),
                        FabricRecipeProvider.method_10426(class_1802.field_8397))
                .method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 , MapleFoodComponents.Red_Tea,1)
                .method_10449(MapleFoodComponents.Red_Tea_Leaves,2)
                .method_10454(class_1802.field_8469)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.Red_Tea_Leaves),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.Red_Tea_Leaves))
                .method_10442(FabricRecipeProvider.method_32807(class_1802.field_8469),
                        FabricRecipeProvider.method_10426(class_1802.field_8469)).method_10431(exporter);

        class_2450.method_10448(class_7800.field_40640 , MapleFoodComponents.Green_Tea,1)
                .method_10449(MapleFoodComponents.Green_Tea_Leaves,2)
                .method_10454(class_1802.field_8469)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.Green_Tea_Leaves),
                        FabricRecipeProvider.method_10426(MapleFoodComponents.Green_Tea_Leaves))
                .method_10442(FabricRecipeProvider.method_32807(class_1802.field_8469),
                        FabricRecipeProvider.method_10426(class_1802.field_8469)).method_10431(exporter);

        class_2446.method_36233(exporter, STRIPPED_MAPLE, class_7800.field_40640 , MapleItems.MapleSyrup, 0.45F, 300, "maple_syrup");
        class_2446.method_36233(exporter, Green_Tea, class_7800.field_40640 , MapleFoodComponents.Red_Tea_Leaves, 0.45F, 300, "red_tea");

        class_2447.method_10437(class_7800.field_40639, MapleArmorItems.Cherry_BOOTS).method_10439("X X").method_10439("X X")
                .method_10434('X', MapleArmorItems.Cherry_INGOT)
                .method_10429(FabricRecipeProvider.method_32807(MapleArmorItems.Cherry_INGOT),
                        FabricRecipeProvider.method_10426(MapleArmorItems.Cherry_INGOT))
                .method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, MapleArmorItems.Cherry_CHESTPLATE).method_10439("X X").method_10439("XXX").method_10439("XXX")
                .method_10434('X', MapleArmorItems.Cherry_INGOT)
                .method_10429(FabricRecipeProvider.method_32807(MapleArmorItems.Cherry_INGOT), FabricRecipeProvider.method_10426(MapleArmorItems.Cherry_INGOT))
                .method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, MapleArmorItems.Cherry_HELMET).method_10439("XXX").method_10439("X X")
                .method_10434('X', MapleArmorItems.Cherry_INGOT)
                .method_10429(FabricRecipeProvider.method_32807(MapleArmorItems.Cherry_INGOT), FabricRecipeProvider.method_10426(MapleArmorItems.Cherry_INGOT))
                .method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, MapleArmorItems.Cherry_LEGGINGS).method_10439("XXX").method_10439("X X").method_10439("X X")
                .method_10434('X', MapleArmorItems.Cherry_INGOT)
                .method_10429(FabricRecipeProvider.method_32807(MapleArmorItems.Cherry_INGOT), FabricRecipeProvider.method_10426(MapleArmorItems.Cherry_INGOT))
                .method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, MapleArmorItems.Cherry_SWORD).method_10439("X").method_10439("X").method_10439("#")
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', MapleArmorItems.Cherry_INGOT)
                .method_10429(FabricRecipeProvider.method_32807(MapleArmorItems.Cherry_INGOT), FabricRecipeProvider.method_10426(MapleArmorItems.Cherry_INGOT))
                .method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, MapleArmorItems.Cherry_HOE).method_10439("XX").method_10439(" #").method_10439(" #")
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', MapleArmorItems.Cherry_INGOT)
                .method_10429(FabricRecipeProvider.method_32807(MapleArmorItems.Cherry_INGOT), FabricRecipeProvider.method_10426(MapleArmorItems.Cherry_INGOT))
                .method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, MapleArmorItems.Cherry_PICKAXE).method_10439("XXX").method_10439(" # ").method_10439(" # ")
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', MapleArmorItems.Cherry_INGOT)
                .method_10429(FabricRecipeProvider.method_32807(MapleArmorItems.Cherry_INGOT), FabricRecipeProvider.method_10426(MapleArmorItems.Cherry_INGOT))
                .method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, MapleArmorItems.Cherry_AXE).method_10439("XX").method_10439("X#").method_10439(" #")
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', MapleArmorItems.Cherry_INGOT)
                .method_10429(FabricRecipeProvider.method_32807(MapleArmorItems.Cherry_INGOT), FabricRecipeProvider.method_10426(MapleArmorItems.Cherry_INGOT))
                .method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, MapleArmorItems.Cherry_SHOVEL).method_10439("X").method_10439("#").method_10439("#")
                .method_10434('#', class_1802.field_8600)
                .method_10434('X', MapleArmorItems.Cherry_INGOT)
                .method_10429(FabricRecipeProvider.method_32807(MapleArmorItems.Cherry_INGOT), FabricRecipeProvider.method_10426(MapleArmorItems.Cherry_INGOT))
                .method_10431(exporter);

        class_2446.method_36233(exporter, Cherry_INGOT, class_7800.field_40642, MapleArmorItems.Cherry_INGOT, 0.1F, 200, "cherry_ingot_smelting");
        class_2446.method_36234(exporter, Cherry_INGOT, class_7800.field_40642, MapleArmorItems.Cherry_INGOT, 0.1F, 200, "cherry_ingot_blasting");


        // cherry nugget / ingot recipes (convert from JSON -> datagen)
        class_2450.method_10448(class_7800.field_40642, MapleArmorItems.Cherry_NUGGET, 9)
                .method_10454(MapleArmorItems.Cherry_INGOT)
                .method_10442(FabricRecipeProvider.method_32807(MapleArmorItems.Cherry_INGOT), FabricRecipeProvider.method_10426(MapleArmorItems.Cherry_INGOT))
                .method_36443(exporter, "cherry_armor_tool/cherry_nugget");

        class_2447.method_10437(class_7800.field_40642, MapleArmorItems.Cherry_INGOT)
                .method_10439("###").method_10439("###").method_10439("###")
                .method_10434('#', MapleArmorItems.Cherry_NUGGET)
                .method_10429(FabricRecipeProvider.method_32807(MapleArmorItems.Cherry_NUGGET), FabricRecipeProvider.method_10426(MapleArmorItems.Cherry_NUGGET))
                .method_36443(exporter, "cherry_armor_tool/cherry_ingot_from_nuggets");

        class_2450.method_10447(class_7800.field_40642, MapleArmorItems.Cherry_INGOT)
                .method_10454(class_1802.field_8620).method_10454(class_1802.field_8620).method_10454(class_1802.field_8620).method_10454(class_1802.field_8620)
                .method_10454(class_1802.field_8695).method_10454(class_1802.field_8695).method_10454(class_1802.field_8695).method_10454(class_1802.field_8695)
                .method_10454(MapleBlocks.MAPLE_LEAVES)
                .method_10442(FabricRecipeProvider.method_32807(class_1802.field_8620), FabricRecipeProvider.method_10426(class_1802.field_8620))
                .method_36443(exporter, "cherry_armor_tool/cherry_ingot");


        class_2447.method_10436(class_7800.field_40634, MapleBlocks.WHITE_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10107)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10107),
                        FabricRecipeProvider.method_10426(class_2246.field_10107))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.ORANGE_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10210)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10210),
                        FabricRecipeProvider.method_10426(class_2246.field_10210))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.MAGENTA_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10585)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10585),
                        FabricRecipeProvider.method_10426(class_2246.field_10585))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.LIGHT_BLUE_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10242)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10242),
                        FabricRecipeProvider.method_10426(class_2246.field_10242))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.YELLOW_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10542)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10542),
                        FabricRecipeProvider.method_10426(class_2246.field_10542))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.LIME_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10421)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10421),
                        FabricRecipeProvider.method_10426(class_2246.field_10421))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.PINK_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10434)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10434),
                        FabricRecipeProvider.method_10426(class_2246.field_10434))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GRAY_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10038)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10038),
                        FabricRecipeProvider.method_10426(class_2246.field_10038))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.LIGHT_GRAY_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10172)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10172),
                        FabricRecipeProvider.method_10426(class_2246.field_10172))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.CYAN_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10308)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10308),
                        FabricRecipeProvider.method_10426(class_2246.field_10308))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.PURPLE_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10206)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10206),
                        FabricRecipeProvider.method_10426(class_2246.field_10206))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.BLUE_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10011)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10011),
                        FabricRecipeProvider.method_10426(class_2246.field_10011))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.BROWN_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10439)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10439),
                        FabricRecipeProvider.method_10426(class_2246.field_10439))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GREEN_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10367)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10367),
                        FabricRecipeProvider.method_10426(class_2246.field_10367))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.RED_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10058)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10058),
                        FabricRecipeProvider.method_10426(class_2246.field_10058))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.BLACK_CONCRETE_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10458)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10458),
                        FabricRecipeProvider.method_10426(class_2246.field_10458))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.WHITE_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10107)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10107),
                        FabricRecipeProvider.method_10426(class_2246.field_10107))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.ORANGE_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10210)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10210),
                        FabricRecipeProvider.method_10426(class_2246.field_10210))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.MAGENTA_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10585)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10585),
                        FabricRecipeProvider.method_10426(class_2246.field_10585))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.LIGHT_BLUE_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10242)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10242),
                        FabricRecipeProvider.method_10426(class_2246.field_10242))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.YELLOW_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10542)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10542),
                        FabricRecipeProvider.method_10426(class_2246.field_10542))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.LIME_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10421)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10421),
                        FabricRecipeProvider.method_10426(class_2246.field_10421))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.PINK_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10434)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10434),
                        FabricRecipeProvider.method_10426(class_2246.field_10434))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GRAY_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10038)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10038),
                        FabricRecipeProvider.method_10426(class_2246.field_10038))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.LIGHT_GRAY_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10172)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10172),
                        FabricRecipeProvider.method_10426(class_2246.field_10172))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.CYAN_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10308)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10308),
                        FabricRecipeProvider.method_10426(class_2246.field_10308))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.PURPLE_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10206)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10206),
                        FabricRecipeProvider.method_10426(class_2246.field_10206))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.BLUE_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10011)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10011),
                        FabricRecipeProvider.method_10426(class_2246.field_10011))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.BROWN_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10439)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10439),
                        FabricRecipeProvider.method_10426(class_2246.field_10439))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GREEN_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10367)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10367),
                        FabricRecipeProvider.method_10426(class_2246.field_10367))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.RED_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10058)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10058),
                        FabricRecipeProvider.method_10426(class_2246.field_10058))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.BLACK_CONCRETE_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10458)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10458),
                        FabricRecipeProvider.method_10426(class_2246.field_10458))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10033)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10033),
                        FabricRecipeProvider.method_10426(class_2246.field_10033))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.WHITE_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10087)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10087),
                        FabricRecipeProvider.method_10426(class_2246.field_10087))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.ORANGE_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10227)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10227),
                        FabricRecipeProvider.method_10426(class_2246.field_10227))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.MAGENTA_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10574)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10574),
                        FabricRecipeProvider.method_10426(class_2246.field_10574))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.LIGHT_BLUE_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10271)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10271),
                        FabricRecipeProvider.method_10426(class_2246.field_10271))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.YELLOW_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10049)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10049),
                        FabricRecipeProvider.method_10426(class_2246.field_10049))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.LIME_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10157)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10157),
                        FabricRecipeProvider.method_10426(class_2246.field_10157))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.PINK_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10317)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10317),
                        FabricRecipeProvider.method_10426(class_2246.field_10317))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GRAY_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10555)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10555),
                        FabricRecipeProvider.method_10426(class_2246.field_10555))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.LIGHT_GRAY_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_9996)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_9996),
                        FabricRecipeProvider.method_10426(class_2246.field_9996))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.CYAN_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10248)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10248),
                        FabricRecipeProvider.method_10426(class_2246.field_10248))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.PURPLE_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10399)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10399),
                        FabricRecipeProvider.method_10426(class_2246.field_10399))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.BLUE_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10060)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10060),
                        FabricRecipeProvider.method_10426(class_2246.field_10060))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.BROWN_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10073)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10073),
                        FabricRecipeProvider.method_10426(class_2246.field_10073))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GREEN_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10357)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10357),
                        FabricRecipeProvider.method_10426(class_2246.field_10357))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.RED_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_10272)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10272),
                        FabricRecipeProvider.method_10426(class_2246.field_10272))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.BLACK_STAINED_GLASS_SLAB, 6)
                .method_10439("###")
                .method_10434('#', class_2246.field_9997)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_9997),
                        FabricRecipeProvider.method_10426(class_2246.field_9997))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10033)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10033),
                        FabricRecipeProvider.method_10426(class_2246.field_10033))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.WHITE_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10087)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10087),
                        FabricRecipeProvider.method_10426(class_2246.field_10087))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.ORANGE_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10227)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10227),
                        FabricRecipeProvider.method_10426(class_2246.field_10227))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.MAGENTA_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10574)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10574),
                        FabricRecipeProvider.method_10426(class_2246.field_10574))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.LIGHT_BLUE_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10271)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10271),
                        FabricRecipeProvider.method_10426(class_2246.field_10271))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.YELLOW_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10049)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10049),
                        FabricRecipeProvider.method_10426(class_2246.field_10049))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.LIME_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10157)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10157),
                        FabricRecipeProvider.method_10426(class_2246.field_10157))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.PINK_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10317)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10317),
                        FabricRecipeProvider.method_10426(class_2246.field_10317))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GRAY_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10555)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10555),
                        FabricRecipeProvider.method_10426(class_2246.field_10555))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.LIGHT_GRAY_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_9996)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_9996),
                        FabricRecipeProvider.method_10426(class_2246.field_9996))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.CYAN_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10248)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10248),
                        FabricRecipeProvider.method_10426(class_2246.field_10248))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.PURPLE_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10399)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10399),
                        FabricRecipeProvider.method_10426(class_2246.field_10399))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.BLUE_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10060)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10060),
                        FabricRecipeProvider.method_10426(class_2246.field_10060))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.BROWN_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10073)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10073),
                        FabricRecipeProvider.method_10426(class_2246.field_10073))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GREEN_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10357)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10357),
                        FabricRecipeProvider.method_10426(class_2246.field_10357))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.RED_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_10272)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10272),
                        FabricRecipeProvider.method_10426(class_2246.field_10272))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.BLACK_STAINED_GLASS_STAIRS, 4)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', class_2246.field_9997)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_9997),
                        FabricRecipeProvider.method_10426(class_2246.field_9997))
                .method_10431(exporter);


        class_3981.method_17969(class_1856.method_8091(class_2246.field_10033), class_7800.field_40634, MapleBlocks.GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10033), FabricRecipeProvider.method_10426(class_2246.field_10033)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID,"cutting/glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10033), class_7800.field_40634, MapleBlocks.GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10033), FabricRecipeProvider.method_10426(class_2246.field_10033)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10087), class_7800.field_40634, MapleBlocks.WHITE_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10087), FabricRecipeProvider.method_10426(class_2246.field_10087)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID,"cutting/white_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10087), class_7800.field_40634, MapleBlocks.WHITE_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10087), FabricRecipeProvider.method_10426(class_2246.field_10087)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/white_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10227), class_7800.field_40634, MapleBlocks.ORANGE_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10227), FabricRecipeProvider.method_10426(class_2246.field_10227)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/orange_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10227), class_7800.field_40634, MapleBlocks.ORANGE_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10227), FabricRecipeProvider.method_10426(class_2246.field_10227)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/orange_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10574), class_7800.field_40634, MapleBlocks.MAGENTA_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10574), FabricRecipeProvider.method_10426(class_2246.field_10574)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/magenta_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10574), class_7800.field_40634, MapleBlocks.MAGENTA_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10574), FabricRecipeProvider.method_10426(class_2246.field_10574)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/magenta_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10271), class_7800.field_40634, MapleBlocks.LIGHT_BLUE_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10271), FabricRecipeProvider.method_10426(class_2246.field_10271)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/light_blue_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10271), class_7800.field_40634, MapleBlocks.LIGHT_BLUE_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10271), FabricRecipeProvider.method_10426(class_2246.field_10271)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/light_blue_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10049), class_7800.field_40634, MapleBlocks.YELLOW_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10049), FabricRecipeProvider.method_10426(class_2246.field_10049)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/yellow_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10049), class_7800.field_40634, MapleBlocks.YELLOW_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10049), FabricRecipeProvider.method_10426(class_2246.field_10049)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/yellow_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10157), class_7800.field_40634, MapleBlocks.LIME_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10157), FabricRecipeProvider.method_10426(class_2246.field_10157)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/lime_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10157), class_7800.field_40634, MapleBlocks.LIME_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10157), FabricRecipeProvider.method_10426(class_2246.field_10157)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/lime_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10317), class_7800.field_40634, MapleBlocks.PINK_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10317), FabricRecipeProvider.method_10426(class_2246.field_10317)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/pink_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10317), class_7800.field_40634, MapleBlocks.PINK_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10317), FabricRecipeProvider.method_10426(class_2246.field_10317)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/pink_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10555), class_7800.field_40634, MapleBlocks.GRAY_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10555), FabricRecipeProvider.method_10426(class_2246.field_10555)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/gray_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10555), class_7800.field_40634, MapleBlocks.GRAY_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10555), FabricRecipeProvider.method_10426(class_2246.field_10555)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/gray_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_9996), class_7800.field_40634, MapleBlocks.LIGHT_GRAY_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_9996), FabricRecipeProvider.method_10426(class_2246.field_9996)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/light_gray_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_9996), class_7800.field_40634, MapleBlocks.LIGHT_GRAY_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_9996), FabricRecipeProvider.method_10426(class_2246.field_9996)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/light_gray_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10248), class_7800.field_40634, MapleBlocks.CYAN_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10248), FabricRecipeProvider.method_10426(class_2246.field_10248)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/cyan_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10248), class_7800.field_40634, MapleBlocks.CYAN_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10248), FabricRecipeProvider.method_10426(class_2246.field_10248)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/cyan_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10399), class_7800.field_40634, MapleBlocks.PURPLE_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10399), FabricRecipeProvider.method_10426(class_2246.field_10399)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/purple_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10399), class_7800.field_40634, MapleBlocks.PURPLE_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10399), FabricRecipeProvider.method_10426(class_2246.field_10399)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/purple_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10060), class_7800.field_40634, MapleBlocks.BLUE_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10060), FabricRecipeProvider.method_10426(class_2246.field_10060)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/blue_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10060), class_7800.field_40634, MapleBlocks.BLUE_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10060), FabricRecipeProvider.method_10426(class_2246.field_10060)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/blue_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10073), class_7800.field_40634, MapleBlocks.BROWN_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10073), FabricRecipeProvider.method_10426(class_2246.field_10073)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/brown_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10073), class_7800.field_40634, MapleBlocks.BROWN_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10073), FabricRecipeProvider.method_10426(class_2246.field_10073)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/brown_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10357), class_7800.field_40634, MapleBlocks.GREEN_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10357), FabricRecipeProvider.method_10426(class_2246.field_10357)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/green_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10357), class_7800.field_40634, MapleBlocks.GREEN_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10357), FabricRecipeProvider.method_10426(class_2246.field_10357)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/green_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10272), class_7800.field_40634, MapleBlocks.RED_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10272), FabricRecipeProvider.method_10426(class_2246.field_10272)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/red_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10272), class_7800.field_40634, MapleBlocks.RED_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10272), FabricRecipeProvider.method_10426(class_2246.field_10272)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/red_stained_glass_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_9997), class_7800.field_40634, MapleBlocks.BLACK_STAINED_GLASS_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_9997), FabricRecipeProvider.method_10426(class_2246.field_9997)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/black_stained_glass_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_9997), class_7800.field_40634, MapleBlocks.BLACK_STAINED_GLASS_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_9997), FabricRecipeProvider.method_10426(class_2246.field_9997)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/black_stained_glass_slab")));

        //CONCRETE Stonecutting Recipes
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10107), class_7800.field_40634, MapleBlocks.WHITE_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10107), FabricRecipeProvider.method_10426(class_2246.field_10107)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/white_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10107), class_7800.field_40634, MapleBlocks.WHITE_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10107), FabricRecipeProvider.method_10426(class_2246.field_10107)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/white_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10210), class_7800.field_40634, MapleBlocks.ORANGE_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10210), FabricRecipeProvider.method_10426(class_2246.field_10210)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/orange_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10210), class_7800.field_40634, MapleBlocks.ORANGE_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10210), FabricRecipeProvider.method_10426(class_2246.field_10210)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/orange_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10585), class_7800.field_40634, MapleBlocks.MAGENTA_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10585), FabricRecipeProvider.method_10426(class_2246.field_10585)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/magenta_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10585), class_7800.field_40634, MapleBlocks.MAGENTA_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10585), FabricRecipeProvider.method_10426(class_2246.field_10585)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/magenta_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10242), class_7800.field_40634, MapleBlocks.LIGHT_BLUE_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10242), FabricRecipeProvider.method_10426(class_2246.field_10242)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/light_blue_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10242), class_7800.field_40634, MapleBlocks.LIGHT_BLUE_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10242), FabricRecipeProvider.method_10426(class_2246.field_10242)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/light_blue_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10542), class_7800.field_40634, MapleBlocks.YELLOW_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10542), FabricRecipeProvider.method_10426(class_2246.field_10542)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/yellow_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10542), class_7800.field_40634, MapleBlocks.YELLOW_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10542), FabricRecipeProvider.method_10426(class_2246.field_10542)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/yellow_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10421), class_7800.field_40634, MapleBlocks.LIME_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10421), FabricRecipeProvider.method_10426(class_2246.field_10421)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/lime_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10421), class_7800.field_40634, MapleBlocks.LIME_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10421), FabricRecipeProvider.method_10426(class_2246.field_10421)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/lime_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10434), class_7800.field_40634, MapleBlocks.PINK_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10434), FabricRecipeProvider.method_10426(class_2246.field_10434)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/pink_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10434), class_7800.field_40634, MapleBlocks.PINK_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10434), FabricRecipeProvider.method_10426(class_2246.field_10434)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/pink_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10038), class_7800.field_40634, MapleBlocks.GRAY_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10038), FabricRecipeProvider.method_10426(class_2246.field_10038)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/gray_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10038), class_7800.field_40634, MapleBlocks.GRAY_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10038), FabricRecipeProvider.method_10426(class_2246.field_10038)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/gray_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10172), class_7800.field_40634, MapleBlocks.LIGHT_GRAY_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10172), FabricRecipeProvider.method_10426(class_2246.field_10172)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/light_gray_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10172), class_7800.field_40634, MapleBlocks.LIGHT_GRAY_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10172), FabricRecipeProvider.method_10426(class_2246.field_10172)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/light_gray_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10308), class_7800.field_40634, MapleBlocks.CYAN_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10308), FabricRecipeProvider.method_10426(class_2246.field_10308)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/cyan_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10308), class_7800.field_40634, MapleBlocks.CYAN_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10308), FabricRecipeProvider.method_10426(class_2246.field_10308)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/cyan_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10206), class_7800.field_40634, MapleBlocks.PURPLE_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10206), FabricRecipeProvider.method_10426(class_2246.field_10206)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/purple_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10206), class_7800.field_40634, MapleBlocks.PURPLE_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10206), FabricRecipeProvider.method_10426(class_2246.field_10206)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/purple_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10011), class_7800.field_40634, MapleBlocks.BLUE_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10011), FabricRecipeProvider.method_10426(class_2246.field_10011)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/blue_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10011), class_7800.field_40634, MapleBlocks.BLUE_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10011), FabricRecipeProvider.method_10426(class_2246.field_10011)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/blue_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10439), class_7800.field_40634, MapleBlocks.BROWN_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10439), FabricRecipeProvider.method_10426(class_2246.field_10439)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/brown_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10439), class_7800.field_40634, MapleBlocks.BROWN_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10439), FabricRecipeProvider.method_10426(class_2246.field_10439)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/brown_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10367), class_7800.field_40634, MapleBlocks.GREEN_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10367), FabricRecipeProvider.method_10426(class_2246.field_10367)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/green_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10367), class_7800.field_40634, MapleBlocks.GREEN_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10367), FabricRecipeProvider.method_10426(class_2246.field_10367)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/green_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10058), class_7800.field_40634, MapleBlocks.RED_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10058), FabricRecipeProvider.method_10426(class_2246.field_10058)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/red_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10058), class_7800.field_40634, MapleBlocks.RED_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10058), FabricRecipeProvider.method_10426(class_2246.field_10058)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/red_concrete_slab")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10458), class_7800.field_40634, MapleBlocks.BLACK_CONCRETE_STAIRS, 1).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10458), FabricRecipeProvider.method_10426(class_2246.field_10458)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/black_concrete_stairs")));
        class_3981.method_17969(class_1856.method_8091(class_2246.field_10458), class_7800.field_40634, MapleBlocks.BLACK_CONCRETE_SLAB, 2).method_17970(FabricRecipeProvider.method_32807(class_2246.field_10458), FabricRecipeProvider.method_10426(class_2246.field_10458)).method_36443(exporter, String.valueOf(class_2960.method_60655(Maple.MOD_ID, "cutting/black_concrete_slab")));
        // Additional datagen conversions for recipes currently in resources

        // snowball variants
        class_2447.method_10436(class_7800.field_40642, MapleItems.SNOWBALL_STONE, 32)
                .method_10439("###").method_10439("#G#").method_10439("###")
                .method_10434('#', class_2246.field_10491)
                .method_10434('G', class_1802.field_20391)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10491), FabricRecipeProvider.method_10426(class_2246.field_10491))
                .method_36443(exporter, "snowball/snowball_stone");

        class_2447.method_10436(class_7800.field_40642, MapleItems.SNOWBALL_ICE, 32)
                .method_10439("###").method_10439("#G#").method_10439("###")
                .method_10434('#', class_2246.field_10491)
                .method_10434('G', class_1802.field_8426)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10491), FabricRecipeProvider.method_10426(class_2246.field_10491))
                .method_36443(exporter, "snowball/snowball_ice");

        class_2447.method_10436(class_7800.field_40642, MapleItems.SNOWBALL_ICE, 32)
                .method_10439("###").method_10439("#G#").method_10439("###")
                .method_10434('#', class_2246.field_10491)
                .method_10434('G', class_1802.field_8426)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10491), FabricRecipeProvider.method_10426(class_2246.field_10491))
                .method_36443(exporter, "snowball/snowball_ice2");

        class_2447.method_10436(class_7800.field_40642, MapleItems.SNOWBALL_ICE, 32)
                .method_10439("###").method_10439("#G#").method_10439("###")
                .method_10434('#', class_2246.field_10491)
                .method_10434('G', class_1802.field_8426)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10491), FabricRecipeProvider.method_10426(class_2246.field_10491))
                .method_36443(exporter, "snowball/snowball_ice3");

        class_2447.method_10436(class_7800.field_40642, MapleItems.SNOWBALL_IRON, 32)
                .method_10439("###").method_10439("#G#").method_10439("###")
                .method_10434('#', class_2246.field_10491)
                .method_10434('G', class_1802.field_8620)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10491), FabricRecipeProvider.method_10426(class_2246.field_10491))
                .method_36443(exporter, "snowball/snowball_iron");

        class_2447.method_10436(class_7800.field_40642, MapleItems.SNOWBALL_Gold, 32)
                .method_10439("###").method_10439("#G#").method_10439("###")
                .method_10434('#', class_2246.field_10491)
                .method_10434('G', class_1802.field_8397)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10491), FabricRecipeProvider.method_10426(class_2246.field_10491))
                .method_36443(exporter, "snowball/snowball_gold");

        class_2447.method_10436(class_7800.field_40642, MapleItems.SNOWBALL_Diamond, 32)
                .method_10439("###").method_10439("#G#").method_10439("###")
                .method_10434('#', class_2246.field_10491)
                .method_10434('G', class_1802.field_8477)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10491), FabricRecipeProvider.method_10426(class_2246.field_10491))
                .method_36443(exporter, "snowball/snowball_diamond");

        class_2447.method_10436(class_7800.field_40642, MapleItems.SNOWBALL_Compression, 32)
                .method_10439("###").method_10439("#G#").method_10439("###")
                .method_10434('#', class_2246.field_10491)
                .method_10434('G', class_1802.field_8705)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10491), FabricRecipeProvider.method_10426(class_2246.field_10491))
                .method_36443(exporter, "snowball/snowball_compression");

        class_2447.method_10436(class_7800.field_40642, MapleItems.SNOWBALL_Teleporting, 32)
                .method_10439("###").method_10439("#G#").method_10439("###")
                .method_10434('#', class_2246.field_10491)
                .method_10434('G', class_1802.field_8634)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10491), FabricRecipeProvider.method_10426(class_2246.field_10491))
                .method_36443(exporter, "snowball/snowball_teleporting");

        class_2447.method_10436(class_7800.field_40642, MapleItems.SNOWBALL_Confusion, 32)
                .method_10439("###").method_10439("#G#").method_10439("###")
                .method_10434('#', class_2246.field_10491)
                .method_10434('G', class_1802.field_17517)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10491), FabricRecipeProvider.method_10426(class_2246.field_10491))
                .method_36443(exporter, "snowball/snowball_confusion");

        class_2447.method_10436(class_7800.field_40642, MapleItems.SNOWBALL_Poison, 32)
                .method_10439("###").method_10439("#G#").method_10439("###")
                .method_10434('#', class_2246.field_10491)
                .method_10434('G', class_1802.field_8680)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10491), FabricRecipeProvider.method_10426(class_2246.field_10491))
                .method_36443(exporter, "snowball/snowball_posion");

        class_2447.method_10436(class_7800.field_40642, MapleItems.SNOWBALL_Instant_Health, 32)
                .method_10439("###").method_10439("#G#").method_10439("###")
                .method_10434('#', class_2246.field_10491)
                .method_10434('G', class_1802.field_8497)
                .method_10429(FabricRecipeProvider.method_32807(class_2246.field_10491), FabricRecipeProvider.method_10426(class_2246.field_10491))
                .method_36443(exporter, "snowball/snowball_instant_health");

        // hanging signs
        class_2447.method_10436(class_7800.field_40642, MapleItems.Maple_HANGING_SIGN, 6)
                .method_10439("X X").method_10439("###").method_10439("###")
                .method_10434('X', class_1802.field_23983)
                .method_10434('#', MapleBlocks.STRIPPED_MAPLE_LOG)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.STRIPPED_MAPLE_LOG), FabricRecipeProvider.method_10426(MapleBlocks.STRIPPED_MAPLE_LOG))
                .method_36443(exporter, "hanging_sign/maple_hanging_sign");

        class_2447.method_10436(class_7800.field_40642, MapleItems.GINKGO_HANGING_SIGN, 6)
                .method_10439("X X").method_10439("###").method_10439("###")
                .method_10434('X', class_1802.field_23983)
                .method_10434('#', MapleBlocks.STRIPPED_GINKGO_LOG)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.STRIPPED_GINKGO_LOG), FabricRecipeProvider.method_10426(MapleBlocks.STRIPPED_GINKGO_LOG))
                .method_36443(exporter, "hanging_sign/ginkgo_hanging_sign");

        // tatami
        class_2447.method_10436(class_7800.field_40634, MapleBlocks.TATAMI, 4)
                .method_10439("###").method_10439("GGG")
                .method_10434('#', class_1802.field_8602)
                .method_10434('G', class_1802.field_8861)
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_8861), FabricRecipeProvider.method_10426(class_1802.field_8861))
                .method_36443(exporter, "tatami/tatami");

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.TATAMI_SLAB, 6)
                .method_10439("###")
                .method_10434('#', MapleBlocks.TATAMI)
                .method_10429(FabricRecipeProvider.method_32807(MapleBlocks.TATAMI), FabricRecipeProvider.method_10426(MapleBlocks.TATAMI))
                .method_36443(exporter, "tatami/tatami_slab");

        // ginkgo sapling
        class_2450.method_10447(class_7800.field_40634, MapleBlocks.GINKGO_SAPLING)
                .method_10454(class_1802.field_17535)
                .method_10454(class_1802.field_8192)
                .method_10442(FabricRecipeProvider.method_32807(class_1802.field_17535), FabricRecipeProvider.method_10426(class_1802.field_17535))
                .method_36443(exporter, "sapling/ginkgo_sapling");

        // maple wood family (maple + ginkgo) common recipes
        // planks from logs
        class_2450.method_10448(class_7800.field_40634, MapleBlocks.MAPLE_PLANKS, 4)
                .method_10446(MapleItemTagGeneration.ModItemTags.MAPLE_LOGS)
                .method_10442(String.valueOf(FabricRecipeProvider.method_10420(MapleItemTagGeneration.ModItemTags.MAPLE_LOGS)), FabricRecipeProvider.method_10420(MapleItemTagGeneration.ModItemTags.MAPLE_LOGS))
                .method_36443(exporter, "maple/maple_planks");

        class_2450.method_10448(class_7800.field_40634, MapleBlocks.GINKGO_PLANKS, 4)
                .method_10446(MapleItemTagGeneration.ModItemTags.GINKGO_LOGS)
                .method_10442(String.valueOf(FabricRecipeProvider.method_10420(MapleItemTagGeneration.ModItemTags.GINKGO_LOGS)), FabricRecipeProvider.method_10420(MapleItemTagGeneration.ModItemTags.GINKGO_LOGS))
                .method_36443(exporter, "ginkgo/ginkgo_planks");

        // slabs & stairs & trapdoor
        class_2447.method_10436(class_7800.field_40634, MapleBlocks.MAPLE_SLAB, 6).method_10439("###").method_10434('#', MapleBlocks.MAPLE_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_PLANKS)).method_36443(exporter, "maple/maple_slab");
        class_2447.method_10436(class_7800.field_40634, MapleBlocks.MAPLE_STAIRS, 4).method_10439("#  ").method_10439("## ").method_10439("###").method_10434('#', MapleBlocks.MAPLE_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_PLANKS)).method_36443(exporter, "maple/maple_stairs");
        class_2447.method_10436(class_7800.field_40636, MapleBlocks.MAPLE_TRAPDOOR, 2).method_10439("###").method_10439("###").method_10434('#', MapleBlocks.MAPLE_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_PLANKS)).method_36443(exporter, "maple/maple_trapdoor");

        class_2447.method_10436(class_7800.field_40642, MapleItems.MAPLE_SIGN, 3).method_10439("###").method_10439("###").method_10439(" X ").method_10434('#', MapleBlocks.MAPLE_PLANKS).method_10434('X', class_1802.field_8600).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_PLANKS)).method_36443(exporter, "maple/maple_sign");

        class_2447.method_10436(class_7800.field_40636, MapleItems.MAPLE_DOOR, 3).method_10439("##").method_10439("##").method_10439("##").method_10434('#', MapleBlocks.MAPLE_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_PLANKS)).method_36443(exporter, "maple/maple_door");

        class_2447.method_10437(class_7800.field_40636, MapleBlocks.MAPLE_BUTTON).method_10439("#").method_10434('#', MapleBlocks.MAPLE_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_PLANKS)).method_36443(exporter, "maple/maple_button");

        class_2447.method_10437(class_7800.field_40636, MapleBlocks.MAPLE_PRESSURE_PLATE).method_10439("##").method_10434('#', MapleBlocks.MAPLE_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_PLANKS)).method_36443(exporter, "maple/maple_pressure_plate");

        class_2447.method_10436(class_7800.field_40635, MapleBlocks.MAPLE_FENCE, 3).method_10439("# #").method_10439("###").method_10434('#', MapleBlocks.MAPLE_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_PLANKS)).method_36443(exporter, "maple/maple_fence");

        class_2447.method_10437(class_7800.field_40635, MapleBlocks.MAPLE_FENCE_GATE).method_10439("# #").method_10439("# #").method_10434('#', MapleBlocks.MAPLE_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_PLANKS)).method_36443(exporter, "maple/maple_fence_gate");

        class_2447.method_10437(class_7800.field_40642, MapleItems.MAPLE_BOAT).method_10439("# #").method_10439("###").method_10434('#', MapleBlocks.MAPLE_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_PLANKS)).method_36443(exporter, "maple/maple_boat");
        class_2447.method_10437(class_7800.field_40642, MapleItems.MAPLE_CHEST_BOAT).method_10439("# #").method_10439("###").method_10434('#', MapleBlocks.MAPLE_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_PLANKS)).method_36443(exporter, "maple/maple_chest_boat");

        // cherry ingot variant using sakura leaves
        class_2450.method_10447(class_7800.field_40642, MapleArmorItems.Cherry_INGOT)
                .method_10454(class_1802.field_8620).method_10454(class_1802.field_8620).method_10454(class_1802.field_8620).method_10454(class_1802.field_8620)
                .method_10454(class_1802.field_8695).method_10454(class_1802.field_8695).method_10454(class_1802.field_8695).method_10454(class_1802.field_8695)
                .method_10454(MapleBlocks.SAKURA_LEAVES)
                .method_10442(FabricRecipeProvider.method_32807(class_1802.field_8620), FabricRecipeProvider.method_10426(class_1802.field_8620))
                .method_36443(exporter, "cherry_armor_tool/cherry_ingot_sakura");

        // cheese
        class_2450.method_10447(class_7800.field_40642, MapleFoodComponents.Cheese)
                .method_10454(MapleFoodComponents.MILK_BOTTOM)
                .method_10442(FabricRecipeProvider.method_32807(MapleFoodComponents.MILK_BOTTOM), FabricRecipeProvider.method_10426(MapleFoodComponents.MILK_BOTTOM))
                .method_36443(exporter, "food/cheese");

        // maple wood conversions
        class_2447.method_10436(class_7800.field_40634, MapleBlocks.MAPLE_WOOD, 3).method_10439("##").method_10439("##").method_10434('#', MapleBlocks.MAPLE_LOG).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.MAPLE_LOG), FabricRecipeProvider.method_10426(MapleBlocks.MAPLE_LOG)).method_36443(exporter, "maple/maple_wood");
        class_2447.method_10436(class_7800.field_40634, MapleBlocks.STRIPPED_MAPLE_WOOD, 3).method_10439("##").method_10439("##").method_10434('#', MapleBlocks.STRIPPED_MAPLE_LOG).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.STRIPPED_MAPLE_LOG), FabricRecipeProvider.method_10426(MapleBlocks.STRIPPED_MAPLE_LOG)).method_36443(exporter, "maple/stripped_maple_wood");

        // ginkgo wood conversions & family
        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GINKGO_WOOD, 3).method_10439("##").method_10439("##").method_10434('#', MapleBlocks.GINKGO_LOG).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_LOG), FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_LOG)).method_36443(exporter, "ginkgo/ginkgo_wood");
        class_2447.method_10436(class_7800.field_40634, MapleBlocks.STRIPPED_GINKGO_WOOD, 3).method_10439("##").method_10439("##").method_10434('#', MapleBlocks.STRIPPED_GINKGO_LOG).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.STRIPPED_GINKGO_LOG), FabricRecipeProvider.method_10426(MapleBlocks.STRIPPED_GINKGO_LOG)).method_36443(exporter, "ginkgo/stripped_ginkgo_wood");

        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GINKGO_SLAB, 6).method_10439("###").method_10434('#', MapleBlocks.GINKGO_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_PLANKS)).method_36443(exporter, "ginkgo/ginkgo_slab");
        class_2447.method_10436(class_7800.field_40634, MapleBlocks.GINKGO_STAIRS, 4).method_10439("#  ").method_10439("## ").method_10439("###").method_10434('#', MapleBlocks.GINKGO_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_PLANKS)).method_36443(exporter, "ginkgo/ginkgo_stairs");
        class_2447.method_10436(class_7800.field_40636, MapleBlocks.GINKGO_TRAPDOOR, 2).method_10439("###").method_10439("###").method_10434('#', MapleBlocks.GINKGO_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_PLANKS)).method_36443(exporter, "ginkgo/ginkgo_trapdoor");

        class_2447.method_10436(class_7800.field_40642, MapleItems.GINKGO_SIGN, 3).method_10439("###").method_10439("###").method_10439(" X ").method_10434('#', MapleBlocks.GINKGO_PLANKS).method_10434('X', class_1802.field_8600).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_PLANKS)).method_36443(exporter, "ginkgo/ginkgo_sign");
        class_2447.method_10437(class_7800.field_40636, MapleBlocks.GINKGO_BUTTON).method_10439("#").method_10434('#', MapleBlocks.GINKGO_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_PLANKS)).method_36443(exporter, "ginkgo/ginkgo_button");
        class_2447.method_10437(class_7800.field_40636, MapleBlocks.GINKGO_PRESSURE_PLATE).method_10439("##").method_10434('#', MapleBlocks.GINKGO_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_PLANKS)).method_36443(exporter, "ginkgo/ginkgo_pressure_plate");

        class_2447.method_10436(class_7800.field_40635, MapleBlocks.GINKGO_FENCE, 3).method_10439("# #").method_10439("###").method_10434('#', MapleBlocks.GINKGO_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_PLANKS)).method_36443(exporter, "ginkgo/ginkgo_fence");
        class_2447.method_10437(class_7800.field_40635, MapleBlocks.GINKGO_FENCE_GATE).method_10439("# #").method_10439("# #").method_10434('#', MapleBlocks.GINKGO_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_PLANKS)).method_36443(exporter, "ginkgo/ginkgo_fence_gate");

        class_2447.method_10436(class_7800.field_40636, MapleItems.GINKGO_DOOR, 3).method_10439("##").method_10439("##").method_10439("##").method_10434('#', MapleBlocks.GINKGO_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_PLANKS)).method_36443(exporter, "ginkgo/ginkgo_door");
        class_2447.method_10437(class_7800.field_40642, MapleItems.GINKGO_BOAT).method_10439("# #").method_10439("###").method_10434('#', MapleBlocks.GINKGO_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_PLANKS)).method_36443(exporter, "ginkgo/ginkgo_boat");
        class_2447.method_10437(class_7800.field_40642, MapleItems.GINKGO_CHEST_BOAT).method_10439("# #").method_10439("###").method_10434('#', MapleBlocks.GINKGO_PLANKS).method_10429(FabricRecipeProvider.method_32807(MapleBlocks.GINKGO_PLANKS), FabricRecipeProvider.method_10426(MapleBlocks.GINKGO_PLANKS)).method_36443(exporter, "ginkgo/ginkgo_chest_boat");

    }
}
