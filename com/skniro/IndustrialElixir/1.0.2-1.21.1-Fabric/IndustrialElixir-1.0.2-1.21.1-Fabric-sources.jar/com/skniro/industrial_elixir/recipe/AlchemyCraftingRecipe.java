package com.skniro.industrial_elixir.recipe;


import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.recipe.machine.AbstractMachineCraftingRecipe;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import org.jetbrains.annotations.Nullable;
import com.skniro.industrial_elixir.recipe.ModRecipeSerializers;


public class AlchemyCraftingRecipe extends AbstractMachineCraftingRecipe {
    final class_1799 output;
    final class_1856 ingredient;


    public AlchemyCraftingRecipe(class_1856 ingredients, class_1799 output) {
        super(ingredients, output);
        this.output = output;
        this.ingredient = ingredients;
    }

    public class_1856 ingredient() {
        return this.ingredient;
    }

    public class_1799 output() {
        return this.output;
    }

    @Override
    public boolean matches(AlchemyCraftingRecipeInput input, class_1937 world) {
        if (world.method_8608()) {
            return false;
        }
        return this.ingredient.method_8093(input.method_59984(0));
    }

    @Override
    public class_1799 assemble(AlchemyCraftingRecipeInput input, net.minecraft.class_7225.class_7874 registries) {
        return output.method_7972();
    }

    @Override
    public boolean method_49188() {
        return false;
    }

    @Override
    public String method_8112() {
        return "";
    }

    @Override
    public class_1865<? extends class_1860<AlchemyCraftingRecipeInput>> method_8119() {
        return AlchemyRecipeType.CANE_CONVERTER.serializer;
    }

    @Override
    public class_3956<? extends class_1860<AlchemyCraftingRecipeInput>> method_17716() {
        return AlchemyRecipeType.CANE_CONVERTER.type;
    }

    public static final MapCodec<AlchemyCraftingRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
            class_1856.field_46095.fieldOf("ingredient").forGetter((recipe) -> {
                return recipe.ingredient;
            }),
            class_1799.field_24671.fieldOf("result").forGetter((recipe) -> {
                return recipe.output;
            })
    ).apply(inst, AlchemyCraftingRecipe::new));

    public static final class_9139<class_9129, AlchemyCraftingRecipe> field_48356 =
            class_9139.method_56435(
                    class_1856.field_48355, AlchemyCraftingRecipe::ingredient,
                    class_1799.field_48349, AlchemyCraftingRecipe::output,
                    AlchemyCraftingRecipe::new);

    public static final class_1865<AlchemyCraftingRecipe> SERIALIZER =
            ModRecipeSerializers.of(CODEC, field_48356);

    public MapCodec<AlchemyCraftingRecipe> codec() {
        return CODEC;
    }

    public class_9139<class_9129, AlchemyCraftingRecipe> streamCodec() {
        return field_48356;
    }

}









