package com.skniro.growable_ores_extension.block.entity;


import com.skniro.growable_ores_extension.block.init.MapleBlockSetType;
import com.skniro.growable_ores_extension.mixin.SignTypeAccessor;
import net.minecraft.class_4719;

public class MapleSignTypes {
    public static final class_4719 Rubber =
            SignTypeAccessor.registerNew(SignTypeAccessor.newSignType("maple_rubber", MapleBlockSetType.Rubber));
}