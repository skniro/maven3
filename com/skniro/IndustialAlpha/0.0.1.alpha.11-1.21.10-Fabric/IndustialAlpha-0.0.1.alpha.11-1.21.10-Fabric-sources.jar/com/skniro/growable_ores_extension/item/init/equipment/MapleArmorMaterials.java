package com.skniro.growable_ores_extension.item.init.equipment;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_156;
import net.minecraft.class_1741;
import net.minecraft.class_3417;
import net.minecraft.class_8051;

public interface MapleArmorMaterials
{
    public static final class_1741 QUANTUM = new class_1741(
            37, class_156.method_654(new EnumMap<>(class_8051.class), map -> {
                map.put(class_8051.field_41937, 4);
                map.put(class_8051.field_41936, 7);
                map.put(class_8051.field_41935, 10);
                map.put(class_8051.field_41934, 4);
                map.put(class_8051.field_48838, 15);
            }), 25, class_3417.field_21866, 5.0F, 0.1F,null, MapleEquipmentAssetKeys.QUANTUM
    );
}
