package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import com.skniro.skniro_furniture.block.entity.GlassTableBlockEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3218;
import net.minecraft.class_3468;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class GlassTableBlock extends AbstractWallCabinetBlock {
    public static final MapCodec<GlassTableBlock> CODEC = method_54094(GlassTableBlock::new);
    private static final class_265 SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0);

    public GlassTableBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends AbstractWallCabinetBlock> method_53969() {
        return field_46280;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world instanceof class_3218 serverWorld) {
            class_2586 var8 = world.method_8321(pos);
            if (var8 instanceof GlassTableBlockEntity GlassTableBlockEntity) {
                player.method_17355(GlassTableBlockEntity);
                player.method_7281(class_3468.field_17271);
            }
        }

        return class_1269.field_5812;
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof GlassTableBlockEntity) {
            ((GlassTableBlockEntity)blockEntity).tick();
        }

    }


    @Override
    @Nullable
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new GlassTableBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}