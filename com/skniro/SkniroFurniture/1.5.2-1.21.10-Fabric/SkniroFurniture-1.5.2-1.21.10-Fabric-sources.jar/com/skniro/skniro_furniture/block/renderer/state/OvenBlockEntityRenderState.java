package com.skniro.skniro_furniture.block.renderer.state;


import net.minecraft.class_10444;
import net.minecraft.class_11954;

public class OvenBlockEntityRenderState extends class_11954 {
    public final class_10444 item = new class_10444();
}