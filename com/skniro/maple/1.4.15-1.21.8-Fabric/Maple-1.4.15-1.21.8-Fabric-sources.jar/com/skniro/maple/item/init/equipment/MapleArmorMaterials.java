package com.skniro.maple.item.init.equipment;

import com.skniro.maple.tag.MapleItemTags;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_156;
import net.minecraft.class_1741;
import net.minecraft.class_3417;
import net.minecraft.class_8051;

public interface MapleArmorMaterials
{
    class_1741 Cherry = new class_1741(5, (Map)class_156.method_654(new EnumMap(class_8051.class), (map) -> {
        map.put(class_8051.field_41937, 3);
        map.put(class_8051.field_41936, 6);
        map.put(class_8051.field_41935, 8);
        map.put(class_8051.field_41934, 3);
        map.put(class_8051.field_48838, 11);
    }), 25, class_3417.field_21866, 3.0F, 0.1F, MapleItemTags.CHERRY_TOOL_MATERIALS, MapleEquipmentAssetKeys.Cherry);

    public static final int Cherry_DURABILITY_MULTIPLIER = 37;
}
