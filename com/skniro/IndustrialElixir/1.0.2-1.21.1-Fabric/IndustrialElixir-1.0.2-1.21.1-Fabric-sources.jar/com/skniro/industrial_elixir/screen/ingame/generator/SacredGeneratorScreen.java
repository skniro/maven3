package com.skniro.industrial_elixir.screen.ingame.generator;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.screen.handler.generator.SacredGeneratorScreenHandler;
import com.skniro.industrial_elixir.util.MouseUtil;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.util.List;
import java.util.Optional;

public class SacredGeneratorScreen extends class_465<SacredGeneratorScreenHandler> {
    private static final class_2960 TEXTURE = class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/generator/guinsacredgenerator.png");
    private static final int STATUS_BAR_Y = 96;
    private static final int OUTPUT_BAR_X = 68;

    public SacredGeneratorScreen(SacredGeneratorScreenHandler menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
        this.field_25269 = 122;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
        field_25268 = 5;
    }

    private void renderHeatAreaTooltips(class_332 context) {
        var storage = field_2797.blockEntity.heatContainer.getSideStorage(null);
        long amount = storage.getAmount();
        long capacity = storage.getCapacity();
        int percent = capacity == 0 ? 0 : (int)((amount * 100.0f) / capacity);
        context.method_51433(field_22793, percent + "%", 8, 61, -12566464, false);
    }
/*    private void renderHeatAreaTooltips(GuiGraphics context) {
        context.drawString(font, menu.blockEntity.heatContainer.getSideStorage(null).getAmount() + "/" + menu.blockEntity.heatContainer.getSideStorage(null).getCapacity() + "E", 8, 59, -12566464, false);
    }*/

    private void renderEnergyOutputTooltips(class_332 context) {
        context.method_51433(field_22793, field_2797.getGeneration() + "EP/t", 8, 44, -12566464, false);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        context.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, -12566464, false);
        context.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, -12566464, false);
        renderHeatAreaTooltips(context);
        renderEnergyOutputTooltips(context);
    }

    @Override
    protected void method_2389(class_332 context, float partialTicks, int mouseX, int mouseY) {
        context.method_25290(TEXTURE, field_2776, field_2800, 0, 0, field_2792, field_2779, 256, 256);
    }
}

