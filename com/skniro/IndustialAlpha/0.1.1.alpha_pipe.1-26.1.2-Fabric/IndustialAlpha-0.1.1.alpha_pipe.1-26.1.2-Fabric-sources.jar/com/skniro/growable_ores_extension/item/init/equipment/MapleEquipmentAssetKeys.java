package com.skniro.growable_ores_extension.item.init.equipment;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

public interface MapleEquipmentAssetKeys {
    ResourceKey<EquipmentAsset> QUANTUM = register("quantum");
    ResourceKey<EquipmentAsset> BRONZE = register("bronze");

    static ResourceKey<EquipmentAsset> register(String name) {
        return ResourceKey.create(EquipmentAssets.ROOT_ID, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID,name));
    }

    public static void registerMapleArmorAssetsKeys() {
        GrowableOresExtension.LOGGER.info("Registering Maple armor assets Keys for " + GrowableOresExtension.MOD_ID);
    }
}