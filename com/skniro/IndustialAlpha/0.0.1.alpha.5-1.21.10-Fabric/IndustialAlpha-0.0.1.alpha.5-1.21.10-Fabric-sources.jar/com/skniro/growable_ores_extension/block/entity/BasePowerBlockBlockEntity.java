package com.skniro.growable_ores_extension.block.entity;

import com.skniro.growable_ores_extension.api.energytier.EnergyTier;

public class BasePowerBlockBlockEntity {

}
