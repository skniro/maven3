package com.skniro.growable_ores_extension.block.networking;

import com.google.common.base.Suppliers;
import com.skniro.growable_ores_extension.block.entity.machine.MetalFormerBlockEntity;
import com.skniro.growable_ores_extension.block.networking.packet.MetalFormerStateC2SPayload;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2586;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.function.Supplier;

public class NetworkUtilsImpl {
    private static final Supplier<NetworkUtilsImpl> instance = Suppliers.memoize(NetworkUtilsImpl::new);

    public static NetworkUtilsImpl getInstance() {
        return instance.get();
    }

    public void initialize() {
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            ClientNetworking.initialize();
        }

        ServerPlayNetworking.registerGlobalReceiver(
                MetalFormerStateC2SPayload.TYPE,
                (payload, context) -> {
                    class_3222 player = context.player();
                    class_3218 world = player.method_51469();
                    context.server().execute(() -> {
                        class_2586 be = world.method_8321(payload.pos());
                        if (be instanceof MetalFormerBlockEntity machine) {
                            machine.setState(MetalFormerBlockEntity.MetalFormerState.values()[payload.state()]);
                            machine.method_5431();
                        }
                    });
                }
        );
    }

    private static class ClientNetworking {
        private static void initialize() {

        }
    }
}