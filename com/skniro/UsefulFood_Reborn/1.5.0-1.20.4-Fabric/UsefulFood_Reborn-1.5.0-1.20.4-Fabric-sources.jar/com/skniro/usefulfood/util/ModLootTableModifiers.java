package com.skniro.usefulfood.util;

import com.skniro.usefulfood.item.UsefulFoodItems;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.class_141;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;

public class ModLootTableModifiers {
    private static final class_2960 squid_entities_ID
            = new class_2960("minecraft", "entities/squid");
    private static final class_2960 glow_squid_entities_ID
            = new class_2960("minecraft", "entities/glow_squid");


    public static void modifyLootTables() {
        LootTableEvents.MODIFY.register((resourceManager, lootManager, id, tableBuilder, source) -> {
            if(squid_entities_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(1f)) // Drops 100% of the time
                        .method_351(class_77.method_411(UsefulFoodItems.SquidTentacleRaw))
                        .apply(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)).method_515());
                tableBuilder.pool(poolBuilder.method_355());
            }
                if(glow_squid_entities_ID.equals(id)) {
                    class_55.class_56 poolBuilder = class_55.method_347()
                            .method_352(class_44.method_32448(1))
                            .method_356(class_219.method_932(1f)) // Drops 100% of the time
                            .method_351(class_77.method_411(UsefulFoodItems.SquidTentacleRaw))
                            .apply(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)).method_515());
                    tableBuilder.pool(poolBuilder.method_355());
                }
        });
    }
}