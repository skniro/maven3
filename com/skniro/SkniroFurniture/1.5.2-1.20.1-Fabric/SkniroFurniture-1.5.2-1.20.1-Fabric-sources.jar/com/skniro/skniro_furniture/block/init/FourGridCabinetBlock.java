package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;

public class FourGridCabinetBlock extends AbstractWallCabinetBlock {
    public FourGridCabinetBlock(class_2251 settings) {
        super(settings);
    }

}
