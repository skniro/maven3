package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluidItems;
import com.skniro.industrial_elixir.item.AdvancedItems;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class CompressorRecipeGenerator extends FabricRecipeProvider {
    public CompressorRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                createCompressor(class_1802.field_8773).input(class_1802.field_8620, 9)
                        .method_33530("has_base_item", has(class_1802.field_8620)).method_10431(output);
                createCompressor(GrowableOresItems.IRON_PLATE).input(GrowableOresItems.IRON_DUST, 1)
                        .method_33530("has_base_item", has(GrowableOresItems.IRON_DUST)).method_10431(output);
                createCompressor(GrowableOresItems.DENSE_IRON_PLATE).input(GrowableOresItems.IRON_PLATE, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.IRON_PLATE)).method_10431(output);
                createCompressor(GrowableOresItems.IRON_DUST).input(GrowableOresItems.SMALL_IRON_DUST, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.SMALL_IRON_DUST)).method_10431(output);

                createCompressor(GeneralBlocks.Tin_Block).input(GrowableOresItems.TIN_INGOT, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.TIN_INGOT)).method_10431(output);
                createCompressor(GrowableOresItems.TIN_PLATE).input(GrowableOresItems.TIN_DUST, 1)
                        .method_33530("has_base_item", has(GrowableOresItems.TIN_DUST)).method_10431(output);
                createCompressor(GrowableOresItems.DENSE_TIN_PLATE).input(GrowableOresItems.TIN_PLATE, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.TIN_PLATE)).method_10431(output);
                createCompressor(GrowableOresItems.TIN_DUST).input(GrowableOresItems.SMALL_TIN_DUST, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.SMALL_TIN_DUST)).method_10431(output);

                createCompressor(class_1802.field_27071).input(class_1802.field_27022, 9)
                        .method_33530("has_base_item", has(class_1802.field_27022)).method_10431(output);
                createCompressor(GrowableOresItems.COPPER_PLATE).input(GrowableOresItems.COPPER_DUST, 1)
                        .method_33530("has_base_item", has(GrowableOresItems.COPPER_DUST)).method_10431(output);
                createCompressor(GrowableOresItems.DENSE_COPPER_PLATE).input(GrowableOresItems.COPPER_PLATE, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.COPPER_PLATE)).method_10431(output);
                createCompressor(GrowableOresItems.COPPER_DUST).input(GrowableOresItems.SMALL_COPPER_DUST, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.SMALL_COPPER_DUST)).method_10431(output);

                createCompressor(class_1802.field_8494).input(class_1802.field_8695, 9)
                        .method_33530("has_base_item", has(class_1802.field_8695)).method_10431(output);
                createCompressor(GrowableOresItems.GOLD_PLATE).input(GrowableOresItems.GOLD_DUST, 1)
                        .method_33530("has_base_item", has(GrowableOresItems.GOLD_DUST)).method_10431(output);
                createCompressor(GrowableOresItems.DENSE_GOLD_PLATE).input(GrowableOresItems.GOLD_PLATE, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.GOLD_PLATE)).method_10431(output);
                createCompressor(GrowableOresItems.GOLD_DUST).input(GrowableOresItems.SMALL_GOLD_DUST, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.SMALL_GOLD_DUST)).method_10431(output);

                createCompressor(GeneralBlocks.Silver_Block).input(GrowableOresItems.SILVER_INGOT, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.SILVER_INGOT)).method_10431(output);
                createCompressor(GrowableOresItems.SILVER_DUST).input(GrowableOresItems.SMALL_SILVER_DUST, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.SMALL_SILVER_DUST)).method_10431(output);

                createCompressor(GeneralBlocks.Lead_Block).input(GrowableOresItems.LEAD_INGOT, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.LEAD_INGOT)).method_10431(output);
                createCompressor(GrowableOresItems.LEAD_PLATE).input(GrowableOresItems.LEAD_DUST, 1)
                        .method_33530("has_base_item", has(GrowableOresItems.LEAD_DUST)).method_10431(output);
                createCompressor(GrowableOresItems.DENSE_LEAD_PLATE).input(GrowableOresItems.LEAD_PLATE, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.LEAD_PLATE)).method_10431(output);
                createCompressor(GrowableOresItems.LEAD_DUST).input(GrowableOresItems.SMALL_LEAD_DUST, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.SMALL_LEAD_DUST)).method_10431(output);

                createCompressor(GeneralBlocks.Bronze_Block).input(GrowableOresItems.BRONZE_INGOT, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.BRONZE_INGOT)).method_10431(output);
                createCompressor(GrowableOresItems.BRONZE_PLATE).input(GrowableOresItems.BRONZE_DUST, 1)
                        .method_33530("has_base_item", has(GrowableOresItems.BRONZE_DUST)).method_10431(output);
                createCompressor(GrowableOresItems.DENSE_BRONZE_PLATE).input(GrowableOresItems.BRONZE_PLATE, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.BRONZE_PLATE)).method_10431(output);
                createCompressor(GrowableOresItems.BRONZE_DUST).input(GrowableOresItems.SMALL_BRONZE_DUST, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.SMALL_BRONZE_DUST)).method_10431(output);

                createCompressor(GeneralBlocks.Steel_Block).input(GrowableOresItems.STEEL_INGOT, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.STEEL_INGOT)).method_10431(output);
                createCompressor(GrowableOresItems.DENSE_STEEL_PLATE).input(GrowableOresItems.STEEL_PLATE, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.STEEL_PLATE)).method_10431(output);

                createCompressor(class_1802.field_8793).input(class_1802.field_8725, 9)
                        .method_33530("has_base_item", has(class_1802.field_8725)).method_10431(output);

                createCompressor(class_1802.field_8055).input(class_1802.field_8759, 9)
                        .method_33530("has_base_item", has(class_1802.field_8759)).method_10431(output);
                createCompressor(GrowableOresItems.LAPIS_PLATE).input(GrowableOresItems.LAPIS_DUST, 1)
                        .method_33530("has_base_item", has(GrowableOresItems.LAPIS_DUST)).method_10431(output);
                createCompressor(GrowableOresItems.DENSE_LAPIS_PLATE).input(GrowableOresItems.LAPIS_PLATE, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.LAPIS_PLATE)).method_10431(output);
                createCompressor(GrowableOresItems.LAPIS_DUST).input(GrowableOresItems.SMALL_LAPIS_DUST, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.SMALL_LAPIS_DUST)).method_10431(output);

                createCompressor(GrowableOresItems.ALLOY_PLATE).input(GrowableOresItems.ALLOY_INGOT, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.ALLOY_INGOT)).method_10431(output);

                createCompressor(GrowableOresItems.ENERGY_CRYSTAL).input(GrowableOresItems.ENERGIUM_DUST, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.ENERGIUM_DUST)).method_10431(output);
                createCompressor(GrowableOresItems.COAL_BLOCK).input(GrowableOresItems.COAL_BALL)
                        .method_33530("has_base_item", has(GrowableOresItems.COAL_BALL)).method_10431(output);
                createCompressor(GrowableOresItems.CARBON_PLATE).input(GrowableOresItems.CARBON_MESH)
                        .method_33530("has_base_item", has(GrowableOresItems.CARBON_MESH)).method_10431(output);


                createCompressor(class_1802.field_20398).input(class_1802.field_8729, 4)
                        .method_33530("has_base_item", has(class_1802.field_8729)).method_10431(output);
                createCompressor(GrowableOresItems.OBSIDIAN_DUST).input(GrowableOresItems.SMALL_OBSIDIAN_DUST, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.SMALL_OBSIDIAN_DUST)).method_10431(output);
                createCompressor(GrowableOresItems.OBSIDIAN_PLATE).input(GrowableOresItems.OBSIDIAN_DUST)
                        .method_33530("has_base_item", has(GrowableOresItems.OBSIDIAN_DUST)).method_10431(output);
                createCompressor(GrowableOresItems.DENSE_OBSIDIAN_PLATE).input(GrowableOresItems.OBSIDIAN_PLATE, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.OBSIDIAN_PLATE)).method_10431(output);
                createCompressor(class_1802.field_20390).input(class_1802.field_8621, 4)
                        .method_33530("has_base_item", has(class_1802.field_8729)).method_10431(output);
                createCompressor(class_1802.field_20384).input(class_1802.field_8858, 4)
                        .method_33530("has_base_item", has(class_1802.field_8858)).method_10431(output);
                createCompressor(class_1802.field_8894).input(class_1802.field_8183, 5)
                        .method_33530("has_base_item", has(class_1802.field_8183)).method_10431(output);
                createCompressor(class_1802.field_8801).input(class_1802.field_8601, 4)
                        .method_33530("has_base_item", has(class_1802.field_8601)).method_10431(output);
                createCompressor(class_1802.field_8246).input(class_1802.field_8543, 4)
                        .method_33530("has_base_item", has(class_1802.field_8543)).method_10431(output);
                createCompressor(class_1802.field_8477).input(GrowableOresItems.COAL_CHUNK)
                        .method_33530("has_base_item", has(GrowableOresItems.COAL_CHUNK)).method_10431(output);
                createCompressor(class_1802.field_8426).input(class_1802.field_8246)
                        .method_33530("has_base_item", has(class_1802.field_8246)).method_10431(output);
                createCompressor(class_1802.field_8081).input(class_1802.field_8426,2)
                        .method_33530("has_base_item", has(class_1802.field_8426)).method_10431(output);
                createCompressor(class_1802.field_19060).input(class_1802.field_8696,4)
                        .method_33530("has_base_item", has(class_1802.field_8696)).method_10431(output);

                createCompressor(GrowableOresItems.IRIDIUM_ORE).input(GrowableOresItems.IRIDIUM_SHARD, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.IRIDIUM_SHARD)).method_10431(output);
                createCompressor(AdvancedItems.Iridium_INGOT).input(GrowableOresItems.IRIDIUM_ORE)
                        .method_33530("has_base_item", has(GrowableOresItems.IRIDIUM_ORE)).method_10431(output);

                createCompressor(GrowableOresItems.LITHIUM_DUST).input(GrowableOresItems.SMALL_LITHIUM_DUST, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.SMALL_LITHIUM_DUST)).method_10431(output);

                createCompressor(GrowableOresItems.SULFUR_DUST).input(GrowableOresItems.SMALL_SULFUR_DUST, 9)
                        .method_33530("has_base_item", has(GrowableOresItems.SMALL_SULFUR_DUST)).method_10431(output);

                createCompressor(GrowableOresItems.SACRED_INGOT).input(GrowableOresItems.CRUSHED_SACRED)
                        .method_33530("has_base_item", has(GrowableOresItems.CRUSHED_SACRED)).method_10431(output);
                createCompressor(GrowableOresItems.SACRED_INGOT).input(GrowableOresItems.CRUSHED_SACRED)
                        .method_33530("has_base_item", has(GrowableOresItems.CRUSHED_SACRED)).method_36443(output,"crushed_sacred_to_sacred_ingot");
                createCompressor(IndustrialElixirFluidItems.AIR_CELL).input(GrowableOresItems.EMPTY_CELL)
                        .method_33530("has_base_item", has(GrowableOresItems.EMPTY_CELL)).method_10431(output);
            }
        };
    }

    @Override
    public String method_10321() {
        return "Compressor";
    }
}
