package com.skniro.industrial_elixir.networking.packet;

import com.skniro.industrial_elixir.IndustrialElixir;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record JetpackInputC2SPayload(boolean jumpHeld, boolean forwardHeld, float strafe) implements class_8710 {

    public static final class_2960 ID = class_2960.method_60655(IndustrialElixir.MOD_ID, "jetpack_input");
    public static final class_9154<JetpackInputC2SPayload> TYPE = new class_9154<>(ID);
    public static final class_9139<class_9129, JetpackInputC2SPayload> CODEC =
            class_9139.method_56436(
                    net.minecraft.class_9135.field_48547, JetpackInputC2SPayload::jumpHeld,
                    net.minecraft.class_9135.field_48547, JetpackInputC2SPayload::forwardHeld,
                    net.minecraft.class_9135.field_48552, JetpackInputC2SPayload::strafe,
                    JetpackInputC2SPayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
