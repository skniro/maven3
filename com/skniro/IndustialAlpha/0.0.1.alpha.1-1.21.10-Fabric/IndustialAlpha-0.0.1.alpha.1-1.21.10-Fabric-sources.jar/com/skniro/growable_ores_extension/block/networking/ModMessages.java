package com.skniro.growable_ores_extension.block.networking;

import com.skniro.growable_ores_extension.GrowableOresExtension;

import com.skniro.growable_ores_extension.block.networking.packet.EnergySyncS2CPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_9129;

public class ModMessages {
    public static void register() {
        registerS2CPackets(PayloadTypeRegistry.playS2C());
        registerC2SPackets(PayloadTypeRegistry.playC2S());
    }

    public static void registerC2SPackets(PayloadTypeRegistry<class_9129> registry) {
    }

    public static void registerS2CPackets(PayloadTypeRegistry<class_9129> registry) {
        registry.register(EnergySyncS2CPayload.TYPE, EnergySyncS2CPayload.CODEC);
    }
}