package com.skniro.chunk_loader.block.entity;

import com.mojang.datafixers.types.Type;
import com.skniro.chunk_loader.SkniroChunkLoader;
import com.skniro.chunk_loader.block.GrowableOresBlocks;
import com.skniro.chunk_loader.block.entity.machine.*;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.datafix.fixes.References;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;


public class AlchemyBlockEntityType {
    public static final BlockEntityType<ChunkLoaderEntity> CHUNK_LOADER_BE;

    static {
        CHUNK_LOADER_BE = create("chunk_loader_be", FabricBlockEntityTypeBuilder.create(ChunkLoaderEntity::new, GrowableOresBlocks.CHUNK_LOADER));
    }


    private static <T extends BlockEntity> BlockEntityType create(String id, FabricBlockEntityTypeBuilder<T> builder) {
        Type<?> type = Util.fetchChoiceType(References.BLOCK_ENTITY, id);
        return (BlockEntityType) Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, Identifier.fromNamespaceAndPath(SkniroChunkLoader.MOD_ID, id), builder.build(null));
    }

    public static void registerMapleBlockEntityType() {
        SkniroChunkLoader.LOGGER.debug("Registering MapleBlockEntityType for " + SkniroChunkLoader.MOD_ID);
    }
}