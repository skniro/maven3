package com.skniro.blackhold.datagen;

import com.skniro.blackhold.Furniture;
import com.skniro.blackhold.block.*;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.class_7225;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;

public class MapleEnglishLanguageProvider extends FabricLanguageProvider {
    public MapleEnglishLanguageProvider(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> registryLookup){
        super(dataGenerator,"en_us", registryLookup);
    }

    @Override
    public void generateTranslations(class_7225.class_7874 wrapperLookup, TranslationBuilder translationBuilder) {
        translationBuilder.add(Furniture.Maple_Group_Furniture,"Blackhold_HD");

        translationBuilder.add(FurnitureDrawBlocks.Oak_Allay_Draw, "Oak Blackhold Draw");
        translationBuilder.add(FurnitureDrawBlocks.Spruce_Allay_Draw, "Spruce Blackhold Draw");
        translationBuilder.add(FurnitureDrawBlocks.Birch_Allay_Draw, "Birch Blackhold Draw");
        translationBuilder.add(FurnitureDrawBlocks.Jungle_Allay_Draw, "Jungle Blackhold Draw");
        translationBuilder.add(FurnitureDrawBlocks.Acacia_Allay_Draw, "Acacia Blackhold Draw");
        translationBuilder.add(FurnitureDrawBlocks.DarkOak_Allay_Draw, "Dark Oak Blackhold Draw");
        translationBuilder.add(FurnitureDrawBlocks.Mangrove_Allay_Draw, "Mangrove Blackhold Draw");
        translationBuilder.add(FurnitureDrawBlocks.Bamboo_Allay_Draw, "Bamboo Blackhold Draw");
        translationBuilder.add(FurnitureDrawBlocks.Cherry_Allay_Draw, "Cherry Blackhold Draw");
        translationBuilder.add(FurnitureDrawBlocks.Crimson_Allay_Draw, "Crimson Blackhold Draw");
        translationBuilder.add(FurnitureDrawBlocks.Warped_Allay_Draw, "Warped Blackhold Draw");
        translationBuilder.add(FurnitureDrawBlocks.PaleOak_Allay_Draw, "Pale Oak Blackhold Draw");
    }
}
