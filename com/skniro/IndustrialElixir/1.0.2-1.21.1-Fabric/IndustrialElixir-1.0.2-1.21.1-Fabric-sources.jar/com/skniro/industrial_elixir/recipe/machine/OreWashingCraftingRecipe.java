package com.skniro.industrial_elixir.recipe.machine;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import com.skniro.industrial_elixir.recipe.ModRecipeSerializers;

public class OreWashingCraftingRecipe extends AbstractMachineCraftingRecipe {
    private final Optional<class_1799> output2;
    private final Optional<class_1799> output3;
    private final class_2960 requiredFluid;
    private final int requiredFluidAmount;

    public OreWashingCraftingRecipe(class_1856 ingredient, int requiredCount, class_1799 output,
                                    Optional<class_1799> output2, Optional<class_1799> output3,
                                    class_2960 requiredFluid, int requiredFluidAmount) {
        super(ingredient, requiredCount, output);
        this.output2 = output2 != null ? output2 : Optional.empty();
        this.output3 = output3 != null ? output3 : Optional.empty();
        this.requiredFluid = requiredFluid;
        this.requiredFluidAmount = requiredFluidAmount;
    }

    @Override
    public class_1865<? extends class_1860<AlchemyCraftingRecipeInput>> method_8119() {
        return AlchemyRecipeType.ORE_WASHING.serializer;
    }

    @Override
    public class_3956<? extends class_1860<AlchemyCraftingRecipeInput>> method_17716() {
        return AlchemyRecipeType.ORE_WASHING.type;
    }


    public Optional<class_1799> output2() {
        return output2;
    }

    public Optional<class_1799> output3() {
        return output3;
    }

    public class_2960 requiredFluid() {
        return requiredFluid;
    }

    public int requiredFluidAmount() {
        return requiredFluidAmount;
    }

    public static final MapCodec<OreWashingCraftingRecipe> CODEC =
            RecordCodecBuilder.mapCodec(inst -> inst.group(
                    class_1856.field_46095.fieldOf("ingredient").forGetter(recipe -> recipe.ingredient),
                    Codec.INT.fieldOf("count").forGetter(recipe -> recipe.requiredCount),
                    class_1799.field_24671.fieldOf("result").forGetter(recipe -> recipe.output),
                    class_1799.field_24671.optionalFieldOf("result2").forGetter(recipe -> recipe.output2),
                    class_1799.field_24671.optionalFieldOf("result3").forGetter(recipe -> recipe.output3),
                    class_2960.field_25139.fieldOf("fluid").forGetter(recipe -> recipe.requiredFluid),
                    Codec.INT.fieldOf("fluid_amount").forGetter(recipe -> recipe.requiredFluidAmount)
            ).apply(inst, OreWashingCraftingRecipe::new));

    /**
     * 1.21.1's {@link class_9139#method_56434} only goes up to six components, so the
     * first six fields are packed into a small carrier record and the fluid amount
     * is appended afterwards.
     */
    private record Base(class_1856 ingredient, int requiredCount, class_1799 output,
                        Optional<class_1799> output2, Optional<class_1799> output3,
                        class_2960 requiredFluid) {
    }

    private static final class_9139<class_9129, Base> BASE_STREAM_CODEC =
            class_9139.method_58025(
                    class_1856.field_48355, Base::ingredient,
                    class_9135.field_49675, Base::requiredCount,
                    class_1799.field_48349, Base::output,
                    class_9135.method_56382(class_1799.field_48349), Base::output2,
                    class_9135.method_56382(class_1799.field_48349), Base::output3,
                    class_2960.field_48267, Base::requiredFluid,
                    Base::new);

    public static final class_9139<class_9129, OreWashingCraftingRecipe> field_48356 =
            class_9139.method_56435(
                    BASE_STREAM_CODEC,
                    recipe -> new Base(recipe.ingredient, recipe.requiredCount, recipe.output,
                            recipe.output2, recipe.output3, recipe.requiredFluid),
                    class_9135.field_49675, OreWashingCraftingRecipe::requiredFluidAmount,
                    (base, amount) -> new OreWashingCraftingRecipe(base.ingredient(), base.requiredCount(),
                            base.output(), base.output2(), base.output3(), base.requiredFluid(), amount));

    public static final class_1865<OreWashingCraftingRecipe> SERIALIZER =
            ModRecipeSerializers.of(CODEC, field_48356);
}
