package com.skniro.skniro_furniture.block.entity;

import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public class TVBlockEntity extends class_2586 {

    public TVBlockEntity(class_2338 pos, class_2680 state) {
        super( FurnitureBlockEntityType.TV_BLOCK_ENTITY, pos, state);
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}
