package com.skniro.nether_ores_reborn.world;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_2893;

public class ModOreGeneration {
    public static void generateOres() {
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Coal_ORE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Nether_Copper_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Nether_Diamond_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Nether_Emerald_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Nether_Gold_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Nether_Iron_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Nether_Lapis_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Nether_Redstone_PLACED_KEY);

        BiomeModifications.addFeature(BiomeSelectors.foundInTheEnd(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.End_Coal_ORE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheEnd(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.End_Copper_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheEnd(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.End_Diamond_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheEnd(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.End_Emerald_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheEnd(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.End_Gold_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheEnd(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.End_Iron_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheEnd(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.End_Lapis_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheEnd(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.End_Redstone_PLACED_KEY);
    }
}