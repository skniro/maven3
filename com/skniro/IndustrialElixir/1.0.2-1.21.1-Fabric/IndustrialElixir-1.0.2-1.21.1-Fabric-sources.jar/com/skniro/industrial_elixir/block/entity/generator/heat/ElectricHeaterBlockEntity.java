package com.skniro.industrial_elixir.block.entity.generator.heat;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.entity.machine.AbstractMachineEntity;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.energy.heat.api.HeatStorage;
import com.skniro.industrial_elixir.energy.heat.api.HeatStorageUtil;
import com.skniro.industrial_elixir.energy.heat.api.base.SimpleSidedHeatContainer;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.screen.handler.generator.heat.ElectricHeaterScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1262;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public class ElectricHeaterBlockEntity extends AbstractMachineEntity {
    private final class_2371<class_1799> inventory = class_2371.method_10213(21, class_1799.field_8037);
    public SimpleSidedHeatContainer heatContainer;
    private static final int COIL_SLOT_START = 11;
    private static final int COIL_SLOT_END = 20;
    private static final long EU_PER_COIL = 10;
    private static final long HEAT_PER_COIL = 10;

    public ElectricHeaterBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.ELECTRIC_HEATER_BLOCK_ENTITY, pos, state);;
        heatContainer = new SimpleSidedHeatContainer() {

            @Override
            public long getCapacity() {
                return 100;
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                if (side == null) return 100;
                return 0;
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                if (side == null) return 100;
                return side == method_11010().method_11654(AbstractMachineblock.FACING) ? 100 : 0;
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(pos, method_11010(), method_11010(), 3);
            }
        };
    }

    @Override
    public void tick(class_1937 level, class_2338 pos, class_2680 state) {
        if (level.method_8608()) return;
        boolean heating = canProduceHeat();
        produceHeat();
        if (state.method_11654(AbstractMachineblock.LIT) != heating) {
            level.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, heating), 3);
        }
        pushHeatToNeighbours();
        charge(ENERGY_ITEM_SLOT);
        method_5431();
    }

    private boolean canProduceHeat() {
        int coilCount = 0;
        for (int i = COIL_SLOT_START; i <= COIL_SLOT_END; i++) if (inventory.get(i).method_31574(GrowableOresItems.Coil)) coilCount += inventory.get(i).method_7947();
        return coilCount > 0 && energyContainer.getSideStorage(null).getAmount() >= coilCount * EU_PER_COIL;
    }

    private void produceHeat() {
        int coilCount = 0;
        for (int i = COIL_SLOT_START; i <= COIL_SLOT_END; i++) if (inventory.get(i).method_31574(GrowableOresItems.Coil)) coilCount += inventory.get(i).method_7947();
        if (coilCount > 0) {
            long required = coilCount * EU_PER_COIL;
            if (energyContainer.getSideStorage(null).getAmount() >= required) {
                try (Transaction tx = Transaction.openOuter()) {
                    if (energyContainer.getSideStorage(null).extract(required, tx) == required) {
                        long heat = coilCount * HEAT_PER_COIL;
                        if (heatContainer.getSideStorage(null).insert(heat, tx) == heat) {
                            tx.commit();
                        }
                    }
                }
            }
        }
    }

    private void pushHeatToNeighbours() {
        if (heatContainer.amount <= 0) return;
        class_2350 direction = method_11010().method_11654(AbstractMachineblock.FACING);
        HeatStorage target = HeatStorage.SIDED.find(field_11863, field_11867.method_10093(direction), direction.method_10153());
        if (target == null) return;
        HeatStorageUtil.move(this.heatContainer.getSideStorage(direction), target, heatContainer.getSideStorage(null).getAmount(), null);
    }

    public long getHeatProduction() {
        int coilCount = 0;
        for (int i = COIL_SLOT_START; i <= COIL_SLOT_END; i++) {
            if (inventory.get(i).method_31574(GrowableOresItems.Coil)) {
                coilCount += inventory.get(i).method_7947();
            }
        }

        long required = coilCount * EU_PER_COIL;

        if (energyContainer.getSideStorage(null).getAmount() < required) {
            return 0;
        }

        return coilCount * HEAT_PER_COIL;
    }

    @Override
    protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        class_1262.method_5426(output, inventory, registries);
    }

    @Override
    protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        super.method_11014(input, registries);
        class_1262.method_5429(input, inventory, registries);
    }

    public HeatStorage getHeatStorage() {
        return heatContainer.getSideStorage(null);
    }

    @Override
    public class_2371<class_1799> getItems() {
        return this.inventory;
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Electric_Heater);
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new ElectricHeaterScreenHandler(syncId, playerInventory, this, this.propertyDelegate);
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return null;
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}
