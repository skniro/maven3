package com.skniro.usefulfood.client;

import com.skniro.usefulfood.block.UsefulFoodJamBlocks;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.class_1921;

@Environment(EnvType.CLIENT)
public class UsefulFoodClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_1921 renderLayer4 = class_1921.method_23583();
        BlockRenderLayerMap.INSTANCE.putBlock(UsefulFoodJamBlocks.Apple_JAM_JAR, renderLayer4);
        BlockRenderLayerMap.INSTANCE.putBlock(UsefulFoodJamBlocks.GLASS_JAR, renderLayer4);
        BlockRenderLayerMap.INSTANCE.putBlock(UsefulFoodJamBlocks.Melon_JAM_JAR, renderLayer4);
        BlockRenderLayerMap.INSTANCE.putBlock(UsefulFoodJamBlocks.Chorus_JAM_JAR, renderLayer4);
        BlockRenderLayerMap.INSTANCE.putBlock(UsefulFoodJamBlocks.Sweet_Berries_JAM_JAR, renderLayer4);
        BlockRenderLayerMap.INSTANCE.putBlock(UsefulFoodJamBlocks.Glow_Berries_JAM_JAR, renderLayer4);

    }
}
