package com.skniro.industrial_elixir.recipe.machine;


import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_7225;


public abstract class AbstractMachineCraftingRecipe implements class_1860<AlchemyCraftingRecipeInput> {
    protected final class_1799 output;
    protected final class_1856 ingredient;
    protected final int requiredCount;


    public AbstractMachineCraftingRecipe(class_1856 ingredients, int requiredCount, class_1799 output) {
        this.output = output;
        this.ingredient = ingredients;
        this.requiredCount = requiredCount;
    }

    public AbstractMachineCraftingRecipe(class_1856 ingredients, class_1799 output) {
        this.output = output;
        this.ingredient = ingredients;
        this.requiredCount = 1;
    }

    public int requiredCount() {
        return requiredCount;
    }

    public class_1856 ingredient() {
        return this.ingredient;
    }

    public class_1799 output() {
        return this.output;
    }

    @Override
    public boolean matches(AlchemyCraftingRecipeInput input, class_1937 world) {
        if (world.method_8608()) {
            return false;
        }
        class_1799 stack = input.method_59984(0);
        return ingredient.method_8093(stack) && stack.method_7947() >= requiredCount;
    }

    @Override
    public class_1799 assemble(AlchemyCraftingRecipeInput input, class_7225.class_7874 registries) {
        return output.method_7972();
    }

    @Override
    public boolean method_8113(int width, int height) {
        return true;
    }

    @Override
    public class_1799 method_8110(class_7225.class_7874 registries) {
        return output.method_7972();
    }

    @Override
    public boolean method_49188() {
        return false;
    }

    @Override
    public String method_8112() {
        return "";
    }
}









