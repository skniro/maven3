package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_2237;

public class FourGridCabinetBlock extends AbstractWallCabinetBlock {
    public static final MapCodec<FourGridCabinetBlock> CODEC = method_54094(FourGridCabinetBlock::new);
    public FourGridCabinetBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }
}
