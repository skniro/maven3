package com.skniro.growable_ores_extension.block.entity;

import com.mojang.datafixers.types.Type;
import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import net.minecraft.class_1208;
import net.minecraft.class_156;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;


public class AlchemyBlockEntityType {
    public static final class_2591<Alchemyblockentity> ALCHEMY_BLOCK_ENTITY;

    static {
        ALCHEMY_BLOCK_ENTITY = create("alchemy_block", class_2591.class_2592.method_20528(Alchemyblockentity::new, GrowableOresBlocks.GrowableOres_Block));

    }

    private static <T extends class_2586> class_2591<T> create(String id, class_2591.class_2592<T> builder) {
        Type<?> type = class_156.method_29187(class_1208.field_5727, id);
        return (class_2591) class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(GrowableOresExtension.MOD_ID,id), builder.method_11034(null));
    }

    public static void registerMapleBlockEntityType() {
        GrowableOresExtension.LOGGER.debug("Registering MapleBlockEntityType for " + GrowableOresExtension.MOD_ID);
    }

}
