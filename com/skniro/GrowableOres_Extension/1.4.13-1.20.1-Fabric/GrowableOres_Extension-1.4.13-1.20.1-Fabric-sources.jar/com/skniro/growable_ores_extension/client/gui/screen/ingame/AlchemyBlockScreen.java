package com.skniro.growable_ores_extension.client.gui.screen.ingame;

import com.mojang.blaze3d.systems.RenderSystem;
import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.screen.AlchemyBlockScreenHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_757;

@Environment(EnvType.CLIENT)
public class AlchemyBlockScreen extends class_465<AlchemyBlockScreenHandler> {
    private static final class_2960 TEXTURE = class_2960.method_43902(GrowableOresExtension.MOD_ID, "textures/gui/container/cane_converter.png");

    public AlchemyBlockScreen(AlchemyBlockScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        RenderSystem.setShader(class_757::method_34539);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, TEXTURE);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        context.method_25302(TEXTURE, x, y, 0, 0, field_2792, field_2779);

        renderProgressArrow(context, x, y);
    }

    private void renderProgressArrow(class_332 context, int x, int y) {
        if(field_2797.isCrafting()) {
            context.method_25302(TEXTURE, x + 73, y + 34, 176, 12, field_2797.getScaledProgress(),45);
        }
        /*if(handler.hasFuel()){
            drawTexture(matrices, x + 18, y + 33 + 14 - handler.getScaledFuelProgress(), 176,
                    14 - handler.getScaledFuelProgress(), 14, handler.getScaledFuelProgress());
        }*/
    }

    @Override
    public void method_25394(class_332 context , int mouseX, int mouseY, float delta) {
        method_25420(context);
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }
}

