package com.skniro.growable_ores_extension.world.gen;

import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.init.LogCropBlock;
import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_3746;
import net.minecraft.class_4643;
import net.minecraft.class_4647;
import net.minecraft.class_5140;
import net.minecraft.class_5819;

public class RubberTrunkPlacer extends class_5140 {
    private class_2680 blockState;
    private final float extraChance;

    public RubberTrunkPlacer(int baseHeight, int firstRandomHeight, int secondRandomHeight, class_2680 blockState, float extraChance) {
        super(baseHeight, firstRandomHeight, secondRandomHeight);
        this.blockState = blockState;
        this.extraChance = extraChance;
    }

    @Override
    public List<class_4647.class_5208> method_26991(class_3746 world, BiConsumer<class_2338, class_2680> replacer, class_5819 random, int height, class_2338 startPos, class_4643 config) {
        int specialHeight = random.method_43048(height);
        for (int i = 0; i < height; i++) {
            class_2338 pos = startPos.method_10086(i);
            if (i == specialHeight) {
                replacer.accept(pos, blockState.method_11657(class_2465.field_11459, class_2350.class_2351.field_11052).method_11657(LogCropBlock.AGE, 2));
                continue;
            }

            if (random.method_43057() < extraChance) {
                replacer.accept(pos, blockState.method_11657(class_2465.field_11459, class_2350.class_2351.field_11052).method_11657(LogCropBlock.AGE, 2));
            } else {
                replacer.accept(pos, GeneralBlocks.Rubber_LOG.method_9564().method_11657(class_2465.field_11459, class_2350.class_2351.field_11052));
            }
        }
        return List.of(new class_4647.class_5208(startPos.method_10086(height), 0, false));
    }
}