package com.skniro.industrial_elixir.block.entity.machine;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.screen.handler.machine.VendorMachineScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1728;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_1915;
import net.minecraft.class_1916;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3943;
import net.minecraft.class_7225;
import net.minecraft.class_9306;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Supplier;

public class VendorMachineBlockEntity extends class_2586 implements class_1915, ExtendedScreenHandlerFactory<class_2338> {
    private final class_1916 offers = new class_1916();
    @Nullable
    private class_1657 tradingPlayer;

    public VendorMachineBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.VENDOR_MACHINE_BLOCK_ENTITY, pos, state);
    }

    private static final int TRADE_COUNT = 20;

    private record WeightedTrade(Supplier<class_1914> trade, int weight) {}

    private static List<WeightedTrade> WEIGHTED_POOL = null;

    private void initOffers() {
        if (WEIGHTED_POOL == null) {
            WEIGHTED_POOL = createWeightedPool();
        }
        offers.clear();
        List<WeightedTrade> available = new ArrayList<>(WEIGHTED_POOL);
        Random rand = new Random(field_11867.method_10063());

        for (int pick = 0; pick < TRADE_COUNT && !available.isEmpty(); pick++) {
            int totalWeight = 0;
            for (WeightedTrade wt : available) {
                totalWeight += wt.weight;
            }
            int roll = rand.nextInt(totalWeight);
            int cumulative = 0;
            for (int i = 0; i < available.size(); i++) {
                cumulative += available.get(i).weight;
                if (roll < cumulative) {
                    offers.add(available.get(i).trade.get());
                    available.remove(i);
                    break;
                }
            }
        }
    }

    private static List<WeightedTrade> createWeightedPool() {
        List<WeightedTrade> pool = new ArrayList<>();

        // ==================== 电池 / 能源 ====================
        pool.add(wt(() -> makeOffer(em(8), items(GrowableOresItems.RE_BATTERY, 1)), 5));
        pool.add(wt(() -> makeOffer(em(20), items(GrowableOresItems.ADVANCED_RE_BATTERY, 1)), 3));
        pool.add(wt(() -> makeOffer(em(40), items(GrowableOresItems.ENERGY_CRYSTAL, 1)), 2));
        pool.add(wt(() -> makeOffer(em(64), items(GrowableOresItems.LAPOTRON_CRYSTAL, 1)), 1));


        // ==================== 橡胶 / 交通工具 ====================
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.Rubber, 4)), 25));
        pool.add(wt(() -> makeOffer(em(16), items(GrowableOresItems.RUBBER_BOAT, 1)), 8));
        pool.add(wt(() -> makeOffer(em(20), items(GrowableOresItems.RUBBER_CHEST_BOAT, 1)), 5));


        // ==================== 升级模块 ====================
        pool.add(wt(() -> makeOffer(em(8), items(GrowableOresItems.OVERCLOCKER, 1)), 8));
        pool.add(wt(() -> makeOffer(em(10), items(GrowableOresItems.ENERGY_STORAGE, 1)), 7));
        pool.add(wt(() -> makeOffer(em(8), items(GrowableOresItems.TRANSFORMER, 1)), 8));
        pool.add(wt(() -> makeOffer(em(6), items(GrowableOresItems.REDSTONE_INVERTER, 1)), 10));


        // ==================== 反应堆组件 ====================
        pool.add(wt(() -> makeOffer(em(20), items(GrowableOresItems.SACRED_ESSENCE, 1)), 3));
        pool.add(wt(() -> makeOffer(em(12), items(GrowableOresItems.SACRED_SHARD, 1)), 5));
        pool.add(wt(() -> makeOffer(em(32), items(GrowableOresItems.SACRED_CORE, 1)), 1));

        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.COOLANT_CELL_10K, 1)), 15));
        pool.add(wt(() -> makeOffer(em(4), items(GrowableOresItems.COOLANT_CELL_30K, 1)), 10));
        pool.add(wt(() -> makeOffer(em(8), items(GrowableOresItems.COOLANT_CELL_60K, 1)), 5));

        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.HEAT_VENT, 1)), 15));
        pool.add(wt(() -> makeOffer(em(4), items(GrowableOresItems.ADVANCED_HEAT_VENT, 1)), 10));
        pool.add(wt(() -> makeOffer(em(8), items(GrowableOresItems.OVERCLOCKED_HEAT_VENT, 1)), 5));

        // ==================== 原矿 ====================
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.Raw_Lead, 4)), 25));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.Raw_Tin, 4)), 25));
        pool.add(wt(() -> makeOffer(em(4), items(GrowableOresItems.Raw_SACRED, 1)), 8));


        // ==================== Crushed Ore ====================
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.CRUSHED_COPPER, 4)), 25));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.CRUSHED_GOLD, 3)), 20));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.CRUSHED_IRON, 4)), 25));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.CRUSHED_LEAD, 4)), 25));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.CRUSHED_SILVER, 3)), 15));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.CRUSHED_TIN, 4)), 25));
        pool.add(wt(() -> makeOffer(em(4), items(GrowableOresItems.CRUSHED_SACRED, 1)), 8));


        // ==================== Purified Ore ====================
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.PURIFIED_COPPER, 3)), 18));
        pool.add(wt(() -> makeOffer(em(3), items(GrowableOresItems.PURIFIED_GOLD, 2)), 12));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.PURIFIED_IRON, 3)), 18));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.PURIFIED_LEAD, 3)), 18));
        pool.add(wt(() -> makeOffer(em(4), items(GrowableOresItems.PURIFIED_SILVER, 2)), 10));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.PURIFIED_TIN, 3)), 18));
        pool.add(wt(() -> makeOffer(em(6), items(GrowableOresItems.PURIFIED_SACRED, 1)), 5));


        // ==================== Dust ====================
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.BRONZE_DUST, 4)), 25));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.CLAY_DUST, 8)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.COAL_DUST, 6)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.COPPER_DUST, 4)), 25));
        pool.add(wt(() -> makeOffer(em(3), items(GrowableOresItems.DIAMOND_DUST, 1)), 8));
        pool.add(wt(() -> makeOffer(em(5), items(GrowableOresItems.ENERGIUM_DUST, 1)), 5));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.GOLD_DUST, 3)), 15));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.IRON_DUST, 4)), 25));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.LAPIS_DUST, 4)), 25));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.LEAD_DUST, 4)), 25));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.LITHIUM_DUST, 2)), 15));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.OBSIDIAN_DUST, 3)), 20));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SILICON_DIOXIDE_DUST, 4)), 25));
        pool.add(wt(() -> makeOffer(em(3), items(GrowableOresItems.SILVER_DUST, 2)), 10));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.STONE_DUST, 8)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SULFUR_DUST, 4)), 20));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.TIN_DUST, 4)), 25));


        // ==================== Small Dust ====================
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SMALL_BRONZE_DUST, 8)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SMALL_COPPER_DUST, 8)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SMALL_GOLD_DUST, 6)), 25));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SMALL_IRON_DUST, 8)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SMALL_LAPIS_DUST, 8)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SMALL_LEAD_DUST, 8)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SMALL_LITHIUM_DUST, 4)), 20));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SMALL_OBSIDIAN_DUST, 6)), 25));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.SMALL_SILVER_DUST, 4)), 15));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SMALL_SULFUR_DUST, 6)), 25));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SMALL_TIN_DUST, 8)), 30));


        // ==================== 锭 ====================
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.BRONZE_INGOT, 1)), 15));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.LEAD_INGOT, 1)), 15));
        pool.add(wt(() -> makeOffer(em(3), items(GrowableOresItems.SILVER_INGOT, 1)), 10));
        pool.add(wt(() -> makeOffer(em(4), items(GrowableOresItems.STEEL_INGOT, 1)), 8));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.TIN_INGOT, 1)), 15));
        pool.add(wt(() -> makeOffer(em(8), items(GrowableOresItems.SACRED_INGOT, 1)), 3));


        // ==================== Plate ====================
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.BRONZE_PLATE, 1)), 15));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.COPPER_PLATE, 1)), 15));
        pool.add(wt(() -> makeOffer(em(3), items(GrowableOresItems.GOLD_PLATE, 1)), 10));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.IRON_PLATE, 1)), 15));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.LAPIS_PLATE, 1)), 15));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.LEAD_PLATE, 1)), 15));
        pool.add(wt(() -> makeOffer(em(3), items(GrowableOresItems.OBSIDIAN_PLATE, 1)), 10));
        pool.add(wt(() -> makeOffer(em(4), items(GrowableOresItems.STEEL_PLATE, 1)), 8));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.TIN_PLATE, 1)), 15));


        // ==================== Dense Plate ====================
        pool.add(wt(() -> makeOffer(em(5), items(GrowableOresItems.DENSE_BRONZE_PLATE, 1)), 8));
        pool.add(wt(() -> makeOffer(em(5), items(GrowableOresItems.DENSE_COPPER_PLATE, 1)), 8));
        pool.add(wt(() -> makeOffer(em(7), items(GrowableOresItems.DENSE_GOLD_PLATE, 1)), 5));
        pool.add(wt(() -> makeOffer(em(5), items(GrowableOresItems.DENSE_IRON_PLATE, 1)), 8));
        pool.add(wt(() -> makeOffer(em(5), items(GrowableOresItems.DENSE_LAPIS_PLATE, 1)), 8));
        pool.add(wt(() -> makeOffer(em(5), items(GrowableOresItems.DENSE_LEAD_PLATE, 1)), 8));
        pool.add(wt(() -> makeOffer(em(8), items(GrowableOresItems.DENSE_OBSIDIAN_PLATE, 1)), 5));
        pool.add(wt(() -> makeOffer(em(10), items(GrowableOresItems.DENSE_STEEL_PLATE, 1)), 3));
        pool.add(wt(() -> makeOffer(em(5), items(GrowableOresItems.DENSE_TIN_PLATE, 1)), 8));


        // ==================== Casing ====================
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.BRONZE_CASING, 1)), 15));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.COPPER_CASING, 1)), 15));
        pool.add(wt(() -> makeOffer(em(3), items(GrowableOresItems.GOLD_CASING, 1)), 10));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.IRON_CASING, 1)), 15));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.LEAD_CASING, 1)), 15));
        pool.add(wt(() -> makeOffer(em(4), items(GrowableOresItems.STEEL_CASING, 1)), 8));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.TIN_CASING, 1)), 15));


        // ==================== 碳材料 ====================
        pool.add(wt(() -> makeOffer(em(3), items(GrowableOresItems.CARBON_FIBRE, 1)), 10));
        pool.add(wt(() -> makeOffer(em(3), items(GrowableOresItems.CARBON_MESH, 1)), 10));
        pool.add(wt(() -> makeOffer(em(5), items(GrowableOresItems.CARBON_PLATE, 1)), 8));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.COAL_BALL, 2)), 20));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.COAL_BLOCK, 1)), 15));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.COAL_CHUNK, 1)), 15));
        pool.add(wt(() -> makeOffer(em(5), items(GrowableOresItems.INDUSTRIAL_DIAMOND, 1)), 5));


        // ==================== 铱 ====================
        pool.add(wt(() -> makeOffer(em(12), items(GrowableOresItems.IRIDIUM_SHARD, 1)), 3));
        pool.add(wt(() -> makeOffer(em(8), items(GrowableOresItems.IRIDIUM_ORE, 1)), 4));
        pool.add(wt(() -> makeOffer(em(16), items(GrowableOresItems.IRIDIUM_PLATE, 1)), 2));


        // ==================== 合金 ====================
        pool.add(wt(() -> makeOffer(em(6), items(GrowableOresItems.ALLOY_INGOT, 1)), 5));
        pool.add(wt(() -> makeOffer(em(10), items(GrowableOresItems.ALLOY_PLATE, 1)), 3));


        // ==================== 其他材料 ====================
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.Sticky_Resin, 2)), 20));
        pool.add(wt(() -> makeOffer(em(3), items(GrowableOresItems.Circuit, 1)), 10));
        pool.add(wt(() -> makeOffer(em(6), items(GrowableOresItems.Advanced_Circuit, 1)), 5));
        pool.add(wt(() -> makeOffer(em(3), items(GrowableOresItems.Coil, 1)), 10));
        pool.add(wt(() -> makeOffer(em(4), items(GrowableOresItems.Electric_Motor, 1)), 8));


        // ==================== Scrap ====================
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.Scrap, 4)), 30));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.Scrap_box, 1)), 20));


        // ==================== Fluid Cell ====================
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.EMPTY_CELL, 4)), 25));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.WATER_CELL, 2)), 20));
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.LAVA_CELL, 1)), 15));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.EMPTY_VESSEL, 4)), 25));


        // ==================== 其他反应材料 ====================
        pool.add(wt(() -> makeOffer(em(2), items(GrowableOresItems.IMPURE_SACRED_STONE, 1)), 10));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.SLAG, 4)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(GrowableOresItems.ASHES, 8)), 30));


        // ==================== Pattern Storage Crystal ====================
        pool.add(wt(() -> makeOffer(em(8), items(GrowableOresItems.RAW_PATTERN_STORAGE_CRYSTAL, 1)), 5));
        pool.add(wt(() -> makeOffer(em(16), items(GrowableOresItems.PATTERN_STORAGE_CRYSTAL, 1)), 2));


        // ==================== Heat Conductor ====================
        pool.add(wt(() -> makeOffer(em(3), items(GrowableOresItems.HEAT_CONDUCTOR, 1)), 8));

        // ========== COMMON（权重 30）：基础物资 ==========
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8620, 4)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_27022, 8)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8713, 16)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8107, 16)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8606, 16)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8276, 12)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8861, 20)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8179, 20)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8567, 20)), 30));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8186, 24)), 30));


        // ========== COMMON：卖出 ==========
        pool.add(wt(() -> makeOffer(items(class_1802.field_8713, 32), em(1)), 30));
        pool.add(wt(() -> makeOffer(items(class_1802.field_8620, 8), em(1)), 30));
        pool.add(wt(() -> makeOffer(items(class_1802.field_8861, 20), em(1)), 30));
        pool.add(wt(() -> makeOffer(items(class_1802.field_8179, 20), em(1)), 30));
        pool.add(wt(() -> makeOffer(items(class_1802.field_8567, 20), em(1)), 30));
        pool.add(wt(() -> makeOffer(items(class_1802.field_8511, 32), em(1)), 30));
        pool.add(wt(() -> makeOffer(items(class_1802.field_8606, 24), em(1)), 30));
        pool.add(wt(() -> makeOffer(items(class_1802.field_8276, 20), em(1)), 30));


        // ========== UNCOMMON（权重 20）：中等价值 ==========
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8695, 2)), 20));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8725, 8)), 20));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8759, 8)), 20));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8745, 4)), 20));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_17531, 12)), 20));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8054, 4)), 20));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8803, 16)), 20));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8794, 8)), 20));


        // ========== UNCOMMON：卖出 ==========
        pool.add(wt(() -> makeOffer(items(class_1802.field_8695, 4), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(class_1802.field_8054, 8), em(1)), 20));

        // ========== RARE（权重 10）：稀有物资 ==========
        pool.add(wt(() -> makeOffer(em(16), items(class_1802.field_8477, 1)), 10));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8155, 4)), 10));
        pool.add(wt(() -> makeOffer(em(2), items(class_1802.field_8281, 8)), 10));
        pool.add(wt(() -> makeOffer(em(1), items(class_1802.field_8601, 4)), 10));
        pool.add(wt(() -> makeOffer(em(3), items(class_1802.field_8777, 4)), 10));
        pool.add(wt(() -> makeOffer(em(4), items(class_1802.field_8634, 1)), 10));
        pool.add(wt(() -> makeOffer(em(4), items(class_1802.field_8894, 1)), 10));


        // ========== LEGENDARY（权重 3）：极稀有 ==========
        pool.add(wt(() -> makeOffer(em(32), items(class_1802.field_22020, 1)), 3));

        pool.add(wt(() -> makeOffer(em(64), items(class_1802.field_8207, 1)), 3));



        // ========== 橡胶 / 基础材料 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.Rubber, 16), em(1)), 30));


        // ========== 原矿 / 粗加工材料 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.Raw_Lead, 16), em(1)), 25));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.Raw_Tin, 16), em(1)), 25));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.Raw_SACRED, 8), em(1)), 10));


        // ========== Crushed Ore：粉碎矿物 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.CRUSHED_COPPER, 12), em(1)), 25));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.CRUSHED_IRON, 12), em(1)), 25));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.CRUSHED_GOLD, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.CRUSHED_LEAD, 12), em(1)), 25));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.CRUSHED_TIN, 12), em(1)), 25));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.CRUSHED_SILVER, 8), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.CRUSHED_SACRED, 4), em(1)), 8));


        // ========== Purified Ore：纯化矿物 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.PURIFIED_COPPER, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.PURIFIED_IRON, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.PURIFIED_GOLD, 6), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.PURIFIED_LEAD, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.PURIFIED_TIN, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.PURIFIED_SILVER, 4), em(1)), 10));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.PURIFIED_SACRED, 2), em(1)), 5));


        // ========== Dust：普通粉末 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.BRONZE_DUST, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.CLAY_DUST, 16), em(1)), 30));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.COAL_DUST, 12), em(1)), 30));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.COPPER_DUST, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.GOLD_DUST, 6), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.IRON_DUST, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.LAPIS_DUST, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.LEAD_DUST, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.LITHIUM_DUST, 6), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.OBSIDIAN_DUST, 8), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SILICON_DIOXIDE_DUST, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SILVER_DUST, 4), em(1)), 10));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.STONE_DUST, 16), em(1)), 30));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SULFUR_DUST, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.TIN_DUST, 8), em(1)), 20));


        // ========== Small Dust：小型粉末 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SMALL_BRONZE_DUST, 16), em(1)), 25));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SMALL_COPPER_DUST, 16), em(1)), 25));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SMALL_GOLD_DUST, 12), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SMALL_IRON_DUST, 16), em(1)), 25));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SMALL_LAPIS_DUST, 16), em(1)), 25));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SMALL_LEAD_DUST, 16), em(1)), 25));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SMALL_LITHIUM_DUST, 8), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SMALL_OBSIDIAN_DUST, 12), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SMALL_SILVER_DUST, 8), em(1)), 10));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SMALL_SULFUR_DUST, 12), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SMALL_TIN_DUST, 16), em(1)), 25));


        // ========== Ingot：金属锭 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.BRONZE_INGOT, 8), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.LEAD_INGOT, 8), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SILVER_INGOT, 4), em(1)), 10));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.STEEL_INGOT, 4), em(1)), 8));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.TIN_INGOT, 8), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SACRED_INGOT, 2), em(1)), 3));


        // ========== Plate：金属板 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.BRONZE_PLATE, 6), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.COPPER_PLATE, 6), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.GOLD_PLATE, 4), em(1)), 10));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.IRON_PLATE, 6), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.LAPIS_PLATE, 6), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.LEAD_PLATE, 6), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.OBSIDIAN_PLATE, 4), em(1)), 8));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.STEEL_PLATE, 3), em(1)), 5));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.TIN_PLATE, 6), em(1)), 15));


        // ========== Dense Plate：致密板 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.DENSE_BRONZE_PLATE, 3), em(1)), 8));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.DENSE_COPPER_PLATE, 3), em(1)), 8));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.DENSE_GOLD_PLATE, 2), em(1)), 5));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.DENSE_IRON_PLATE, 3), em(1)), 8));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.DENSE_LAPIS_PLATE, 3), em(1)), 8));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.DENSE_LEAD_PLATE, 3), em(1)), 8));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.DENSE_OBSIDIAN_PLATE, 2), em(1)), 5));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.DENSE_STEEL_PLATE, 2), em(1)), 3));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.DENSE_TIN_PLATE, 3), em(1)), 8));


        // ========== Casing：机器外壳 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.BRONZE_CASING, 6), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.COPPER_CASING, 6), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.GOLD_CASING, 4), em(1)), 10));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.IRON_CASING, 6), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.LEAD_CASING, 6), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.STEEL_CASING, 3), em(1)), 8));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.TIN_CASING, 6), em(1)), 15));


        // ========== Carbon：碳材料 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.CARBON_FIBRE, 4), em(1)), 10));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.CARBON_MESH, 4), em(1)), 10));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.CARBON_PLATE, 3), em(1)), 8));


        // ========== Coal Processing：煤炭加工 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.COAL_BALL, 8), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.COAL_BLOCK, 2), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.COAL_CHUNK, 4), em(1)), 15));


        // ========== Diamond Processing：工业钻石 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.INDUSTRIAL_DIAMOND, 2), em(1)), 5));


        // ========== Iridium：铱 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.IRIDIUM_SHARD, 2), em(1)), 3));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.IRIDIUM_ORE, 2), em(1)), 4));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.IRIDIUM_PLATE, 1), em(1)), 2));


        // ========== Alloy：合金 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.ALLOY_INGOT, 2), em(1)), 5));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.ALLOY_PLATE, 1), em(1)), 3));


        // ========== Sticky Resin：粘性树脂 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.Sticky_Resin, 8), em(1)), 20));


        // ========== Circuit：电路 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.Circuit, 3), em(1)), 10));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.Advanced_Circuit, 2), em(1)), 5));


        // ========== Electric Components：电子组件 ==========

        pool.add(wt(() -> makeOffer(items(GrowableOresItems.Coil, 4), em(1)), 10));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.Electric_Motor, 2), em(1)), 8));


        // ========== Scrap：废料 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.Scrap, 16), em(1)), 30));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.Scrap_box, 4), em(1)), 20));


        // ========== Fluid Cell：流体单元 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.EMPTY_CELL, 8), em(1)), 25));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.WATER_CELL, 4), em(1)), 20));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.LAVA_CELL, 2), em(1)), 15));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.EMPTY_VESSEL, 8), em(1)), 25));


        // ========== Sacred Materials：神圣材料 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.IMPURE_SACRED_STONE, 4), em(1)), 10));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.SLAG, 16), em(1)), 30));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.ASHES, 16), em(1)), 30));


        // ========== Pattern Storage Crystal：存储水晶 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.RAW_PATTERN_STORAGE_CRYSTAL, 2), em(1)), 5));
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.PATTERN_STORAGE_CRYSTAL, 1), em(2)), 2));


        // ========== Heat Conductor：热传导材料 ==========
        pool.add(wt(() -> makeOffer(items(GrowableOresItems.HEAT_CONDUCTOR, 3), em(1)), 8));

        return pool;
    }

    private static class_1799 em(int count) {
        return new class_1799(class_1802.field_8687, count);
    }

    private static class_1799 items(net.minecraft.class_1935 item, int count) {
        return new class_1799(item, count);
    }

    private static WeightedTrade wt(Supplier<class_1914> trade, int weight) {
        return new WeightedTrade(trade, weight);
    }

    private static class_1914 makeOffer(class_1799 cost, class_1799 result) {
        return new class_1914(
                new class_9306(cost.method_7909(), cost.method_7947()),
                Optional.empty(),
                result,
                Integer.MAX_VALUE, 0, 0f
        );
    }

    // Merchant
    @Override
    public void method_8259(@Nullable class_1657 player) {
        this.tradingPlayer = player;
    }

    @Nullable
    @Override
    public class_1657 method_8257() {
        return this.tradingPlayer;
    }

    @Override
    public class_1916 method_8264() {
        return this.offers;
    }

    protected void updateTrades(class_3218 level){
        initOffers();
    };

    @Override
    public void method_8261(class_1916 offers) {
        this.offers.addAll(offers);
        if (tradingPlayer instanceof class_3222 sp) {
            sendOffers(sp);
        }
    }

    private void sendOffers(class_3222 player) {
        if (player.field_7512 instanceof class_1728 menu) {
            player.field_13987.method_14364(new class_3943(menu.field_7763, this.offers, 1, 0, false, false)
            );
        }
    }

    @Override
    public void method_8262(class_1914 offer) {
        offer.method_19275();
    }

    @Override
    public void method_8258(class_1799 stack) {
    }

    @Override
    public int method_19269() {
        return 0;
    }

    @Override
    public void method_19271(int xp) {
    }

    @Override
    public boolean method_38069() {
        return this.field_11863 == null || this.field_11863.method_8608();
    }

    @Override
    public class_3414 method_18010() {
        return class_3417.field_14815;
    }

    @Override
    public boolean method_19270() {
        return false;
    }

    @Override
    public boolean method_20708() {
        return false;
    }

    public boolean stillValid(class_1657 player) {
        if (this.field_11863 == null || this.field_11863.method_8321(this.field_11867) != this) {
            return false;
        }
        return player.method_5649((double) this.field_11867.method_10263() + 0.5,
                (double) this.field_11867.method_10264() + 0.5,
                (double) this.field_11867.method_10260() + 0.5) <= 64.0;
    }

    // ExtendedMenuProvider
    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.VendorMachine);
    }

    @Override
    protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        output.method_10566("vendor_machine.offers", class_1916.field_48850.encodeStart(class_2509.field_11560, this.offers).getOrThrow());
    }

    @Override
    protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        super.method_11014(input, registries);
        this.offers.clear();
        class_1916.field_48850.parse(class_2509.field_11560, input.method_10580("vendor_machine.offers")).result().ifPresent(this.offers::addAll);
        if (this.offers.isEmpty()) {
            initOffers();
        }
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_58692(registryLookup);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        if (player instanceof class_3222 serverPlayer) {
            serverPlayer.field_13987.method_14364(
                    new class_3943(syncId, this.offers, 1, 0, false, false
                    )
            );
        }
        return new VendorMachineScreenHandler(syncId, playerInventory, this, this);
    }
}
