package com.skniro.growable_ores_extension.block.init.generator;


import com.mojang.serialization.MapCodec;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.block.entity.generator.GeneratorSolarPanelBlockEntity;
import com.skniro.growable_ores_extension.block.init.machine.AbstractMachineblock;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class GeneratorSolarPanelBlock extends AbstractMachineblock {
    private final int DayPower, NightPower;

    public GeneratorSolarPanelBlock(class_2251 settings, EnergyTier energyTier, int DayPower, int NightPower, long capacity) {
        super(settings, energyTier, capacity);
        this.DayPower = DayPower;
        this.NightPower = NightPower;
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        throw new IllegalStateException("Block does not support getCodec!");
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new GeneratorSolarPanelBlockEntity(pos, state);
    }

/*    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity placer, ItemStack itemStack) {
        BlockEntity be = world.getBlockEntity(pos);
        if (be instanceof GeneratorSolarPanelBlockEntity generator) {
            generator.setPower(DayPower, NightPower);
        }
    }*/

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, AlchemyBlockEntityType.GENERATOR_SOLAR_PANEL_BLOCK_ENTITY, (world1, pos, state1, blockEntity) -> blockEntity.tick(world1, pos, state1));
    }

    public int getDayPower(){
        return DayPower;
    }

    public int getNightPower(){
        return NightPower;
    }

}
