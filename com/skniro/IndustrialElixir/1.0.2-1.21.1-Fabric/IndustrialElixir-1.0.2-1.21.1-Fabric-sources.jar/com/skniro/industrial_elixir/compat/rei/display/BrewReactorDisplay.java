package com.skniro.industrial_elixir.compat.rei.display;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.recipe.machine.BrewReactorCraftingRecipe;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;

import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2960;
import net.minecraft.class_8786;
import java.util.List;
import java.util.Optional;

public class BrewReactorDisplay extends BasicDisplay {

    private int count;
    private Optional<class_2960> fluid;
    private Optional<Integer> fluidamt;

    public static final CategoryIdentifier<BrewReactorDisplay>
            BREW_REACTOR = CategoryIdentifier.of(IndustrialElixir.MOD_ID, "brew_reactor");

    public static final DisplaySerializer<BrewReactorDisplay> SERIALIZER = BasicDisplay.Serializer.<BrewReactorDisplay>of(
            (inputs, outputs, location, tag) -> new BrewReactorDisplay(inputs, outputs, location, tag.method_10550("count"),
                    tag.method_10545("fluid") ? Optional.of(class_2960.method_60654(tag.method_10558("fluid"))) : Optional.empty(),
                    tag.method_10545("fluid_amount") ? Optional.of(tag.method_10550("fluid_amount")) : Optional.empty()),
            (display, tag) -> {
                tag.method_10569("count", display.getCount());
                display.getFluid().ifPresent(fluid -> tag.method_10582("fluid", fluid.toString()));
                display.getFluidAmount().ifPresent(amount -> tag.method_10569("fluid_amount", amount));
            }
    );



    public BrewReactorDisplay(BrewReactorCraftingRecipe recipe) {
        this(recipe.ingredient2() != null ?
                        List.of(EntryIngredients.ofIngredient(recipe.ingredient()),
                                EntryIngredients.ofIngredient(recipe.ingredient2())) :
                        List.of(EntryIngredients.ofIngredient(recipe.ingredient())),
                List.of(EntryIngredients.of(recipe.output())),
                Optional.empty(),
                recipe.requiredCount(),
                recipe.requiredFluid(),
                recipe.requiredFluidAmount()
        );
    }

    public BrewReactorDisplay(List<EntryIngredient> inputs, List<EntryIngredient> outputs, Optional<class_2960> location, int count, Optional<class_2960> fluid, Optional<Integer> fluidamt) {
        super(inputs, outputs, location);
        this.count = count;
        this.fluid = fluid;
        this.fluidamt = fluidamt;
    }

    public BrewReactorDisplay(class_8786<BrewReactorCraftingRecipe> recipe) {
        super(
                recipe.comp_1933().ingredient2() != null ?
                        List.of(EntryIngredients.ofIngredient(recipe.comp_1933().ingredient()),
                                EntryIngredients.ofIngredient(recipe.comp_1933().ingredient2())) :
                        List.of(EntryIngredients.ofIngredient(recipe.comp_1933().ingredient())),

                List.of(EntryIngredient.of(EntryStacks.of(recipe.comp_1933().output()))));
        this.count = recipe.comp_1933().requiredCount();
        this.fluid = recipe.comp_1933().requiredFluid();
        this.fluidamt = recipe.comp_1933().requiredFluidAmount();
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return BREW_REACTOR;
    }


    public int getCount() {
        return count;
    }

    public Optional<class_2960> getFluid() {
        return fluid;
    }

    public Optional<Integer> getFluidAmount() {
        return fluidamt;
    }
}