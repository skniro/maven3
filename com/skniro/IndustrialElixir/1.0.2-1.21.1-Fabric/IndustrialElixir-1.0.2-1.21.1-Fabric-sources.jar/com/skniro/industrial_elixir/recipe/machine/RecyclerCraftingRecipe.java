package com.skniro.industrial_elixir.recipe.machine;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.ModRecipeSerializers;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class RecyclerCraftingRecipe implements class_1860<AlchemyCraftingRecipeInput> {
    private final class_1799 output;

    public RecyclerCraftingRecipe(class_1799 output) {
        this.output = output;
    }

    public class_1799 output() {
        return output;
    }

    @Override
    public boolean matches(AlchemyCraftingRecipeInput input, class_1937 world) {
        if (world.method_8608()) {
            return false;
        }
        class_1799 stack = input.method_59984(0);
        return !stack.method_7960();
    }

    @Override
    public boolean method_49188() {
        return false;
    }

    @Override
    public String method_8112() {
        return "";
    }

    @Override
    public class_1799 assemble(AlchemyCraftingRecipeInput input, net.minecraft.class_7225.class_7874 registries) {
        return output.method_7972();
    }

    @Override
    public boolean method_8113(int width, int height) {
        return true;
    }

    @Override
    public class_1799 method_8110(net.minecraft.class_7225.class_7874 registries) {
        return output.method_7972();
    }

    @Override
    public class_1865<? extends class_1860<AlchemyCraftingRecipeInput>> method_8119() {
        return AlchemyRecipeType.RECYCLER.serializer;
    }

    @Override
    public class_3956<? extends class_1860<AlchemyCraftingRecipeInput>> method_17716() {
        return AlchemyRecipeType.RECYCLER.type;
    }

        public static final MapCodec<RecyclerCraftingRecipe> CODEC =
                RecordCodecBuilder.mapCodec(inst -> inst.group(
                        class_1799.field_24671.fieldOf("result")
                                .forGetter(RecyclerCraftingRecipe::output)
                ).apply(inst, RecyclerCraftingRecipe::new));

        public static final class_9139<class_9129, RecyclerCraftingRecipe> field_48356 =
                class_9139.method_56434(
                        class_1799.field_48349,
                        RecyclerCraftingRecipe::output,
                        RecyclerCraftingRecipe::new
                );


    public static final class_1865<RecyclerCraftingRecipe> SERIALIZER =
            ModRecipeSerializers.of(CODEC, field_48356);

        public MapCodec<RecyclerCraftingRecipe> codec() {
            return CODEC;
        }

        public class_9139<class_9129, RecyclerCraftingRecipe> streamCodec() {
            return field_48356;
        }

}
