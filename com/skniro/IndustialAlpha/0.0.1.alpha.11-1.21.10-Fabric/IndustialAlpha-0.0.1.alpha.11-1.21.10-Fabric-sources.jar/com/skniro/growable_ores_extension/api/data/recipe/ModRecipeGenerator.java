package com.skniro.growable_ores_extension.api.data.recipe;

import com.skniro.growable_ores_extension.item.MapleArmorItems;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_2446;
import net.minecraft.class_2447;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_7871;
import net.minecraft.class_7924;
import net.minecraft.class_8790;

public class ModRecipeGenerator extends class_2446 {
    private final class_7871<class_1792> itemLookup;

    protected ModRecipeGenerator(class_7225.class_7874 registries, class_8790 exporter) {
        super(registries, exporter);
        this.itemLookup = registries.method_46762(class_7924.field_41197);
    }

    @Override
    public void method_10419() {
    }

    public ExtractorRecipeJsonBuilder createExtractor(class_1935 output, int count) {
        return ExtractorRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public ExtractorRecipeJsonBuilder createExtractor(class_1935 output) {
        return ExtractorRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public MaceratorRecipeJsonBuilder createMacerator(class_1935 output, int count) {
        return MaceratorRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public MaceratorRecipeJsonBuilder createMacerator(class_1935 output) {
        return MaceratorRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public CompressorRecipeJsonBuilder createCompressor(class_1935 output, int count) {
        return CompressorRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public CompressorRecipeJsonBuilder createCompressor(class_1935 output) {
        return CompressorRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public MetalFormerRollingRecipeJsonBuilder createMetalFormerRolling(class_1935 input, class_1935 output) {
        return createMetalFormerRolling(input, output, 1);
    }

    public MetalFormerRollingRecipeJsonBuilder createMetalFormerRolling(class_1935 input, class_1935 output, int count) {
        return createMetalFormerRolling(input, 1, output, count);
    }

    public MetalFormerRollingRecipeJsonBuilder createMetalFormerRolling(class_1935 input, int inputCount, class_1935 output, int count) {
        MetalFormerRollingRecipeJsonBuilder builder = MetalFormerRollingRecipeJsonBuilder.create(this.itemLookup, output, count).input(input, inputCount).method_33530(method_32807(input), method_10426(input));
        createWorkbenchRolling(input, output, count);
        return builder;
    }

    private void createWorkbenchCutting(class_1935 input, class_1935 output, int count) {
        method_62750(class_7800.field_40642, output, count).method_10454(MapleArmorItems.CUTTING).method_10454(input).method_10442(method_32807(input), method_10426(input)).method_10431(field_53721);
    }

    public MetalFormerCuttingRecipeJsonBuilder createMetalFormerCutting(class_1935 input, class_1935 output) {
        return createMetalFormerCutting(input, output, 1);
    }

    public MetalFormerCuttingRecipeJsonBuilder createMetalFormerCutting(class_1935 input, class_1935 output, int count) {
        return createMetalFormerCutting(input, 1, output, count);
    }

    public MetalFormerCuttingRecipeJsonBuilder createMetalFormerCutting(class_1935 input, int inputCount, class_1935 output, int count) {
        MetalFormerCuttingRecipeJsonBuilder builder = MetalFormerCuttingRecipeJsonBuilder.create(this.itemLookup, output, count).input(input, inputCount).method_33530(method_32807(input), method_10426(input));
        createWorkbenchCutting(input, output, count);
        return builder;
    }

    private void createWorkbenchRolling(class_1935 input, class_1935 output, int count) {
        method_62750(class_7800.field_40642, output, count).method_10454(MapleArmorItems.ROLLING).method_10454(input).method_10442(method_32807(input), method_10426(input)).method_10431(field_53721);
    }

    public MetalFormerExtrudingRecipeJsonBuilder createMetalFormerExtruding(class_1935 input, int inputCount, class_1935 output, int count) {
        return MetalFormerExtrudingRecipeJsonBuilder.create(this.itemLookup, output, count).input(input, inputCount).method_33530(method_32807(input), method_10426(input));
    }

    public MetalFormerExtrudingRecipeJsonBuilder createMetalFormerExtruding(class_1935 input, int inputCount, class_1935 output) {
        return createMetalFormerExtruding(input, inputCount, output, 1);
    }

    public MetalFormerExtrudingRecipeJsonBuilder createMetalFormerExtruding(class_1935 input, class_1935 output) {
        return createMetalFormerExtruding(input, 1, output);
    }

    public MetalFormerExtrudingRecipeJsonBuilder createMetalFormerExtruding(class_1935 input, class_1935 output, int count) {
        return createMetalFormerExtruding(input, 1, output, count);
    }

    public MolecularTransformerRecipeJsonBuilder createMolecularTransformer(class_1935 input, int inputCount, class_1935 output, int count, long requiredEnergy) {
        return MolecularTransformerRecipeJsonBuilder.create(this.itemLookup, output, count, requiredEnergy).input(input, inputCount).method_33530(method_32807(input), method_10426(input));
    }

    public MolecularTransformerRecipeJsonBuilder createMolecularTransformer(class_1935 input, class_1935 output, int count, long requiredEnergy) {
        return createMolecularTransformer(input, 1, output, count, requiredEnergy);
    }

    public MolecularTransformerRecipeJsonBuilder createMolecularTransformer(class_1935 input, class_1935 output, long requiredEnergy) {
        return createMolecularTransformer(input, 1, output, 1, requiredEnergy);
    }

    public MolecularTransformerRecipeJsonBuilder createMolecularTransformer(class_1935 input, int inputCount, class_1935 output, long requiredEnergy) {
        return createMolecularTransformer(input, inputCount, output, 1, requiredEnergy);
    }

    public class_2447 method_62747(class_7800 category, class_1935 output, int count) {
        return class_2447.method_10436(this.itemLookup, category, output, count);
    }
}