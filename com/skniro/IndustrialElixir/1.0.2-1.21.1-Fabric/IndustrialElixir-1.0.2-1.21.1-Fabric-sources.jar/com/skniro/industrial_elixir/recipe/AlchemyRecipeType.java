package com.skniro.industrial_elixir.recipe;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.recipe.machine.*;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

public interface AlchemyRecipeType<T extends class_1860<?>> {
    public static final RecipeRegistration<AlchemyCraftingRecipe> CANE_CONVERTER =
            register("cane_converter", AlchemyCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<MaceratorCraftingRecipe> MACERATOR =
            register("macerator", MaceratorCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<CompressorCraftingRecipe> COMPRESSOR =
            register("compressor", CompressorCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<MetalFormerRollingCraftingRecipe> METALFORMER_ROLLING =
            register("metal_former_rolling", MetalFormerRollingCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<MetalFormerCuttingCraftingRecipe> METALFORMER_CUTTING =
            register("metal_former_cutting", MetalFormerCuttingCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<MetalFormerExtrudingCraftingRecipe> METALFORMER_EXTRUDING =
            register("metal_former_extruding", MetalFormerExtrudingCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<MolecularTransformerCraftingRecipe> MOLECULAR_TRANSFORMER =
            register("molecular_transformer", MolecularTransformerCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<ExtractorCraftingRecipe> EXTRACTOR =
            register("extractor", ExtractorCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<CuttingCraftingRecipe> CUTTING =
            register("cutting", CuttingCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<RecyclerCraftingRecipe> RECYCLER =
            register("recycler", RecyclerCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<BrewReactorCraftingRecipe> BREW_REACTOR =
            register("brew_reactor", BrewReactorCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<OreWashingCraftingRecipe> ORE_WASHING =
            register("ore_washing", OreWashingCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<ModBlastFurnaceCraftingRecipe> MOD_BLAST_FURNACE =
            register("mod_blast_furnace", ModBlastFurnaceCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<HeatCentrifugeCraftingRecipe> HEAT_CENTRIFUGE =
            register("heat_centrifuge", HeatCentrifugeCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<PatternStorageCraftingRecipe> PATTERN_STORAGE =
            register("pattern_storage", PatternStorageCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<CoffeeMachineCraftingRecipe> COFFEE_MACHINE =
            register("coffee_machine", CoffeeMachineCraftingRecipe.SERIALIZER);
    public static final RecipeRegistration<CropFarmCraftingRecipe> CROP_FARM =
            register("crop_farm", CropFarmCraftingRecipe.SERIALIZER);


    public static <R extends class_1860<?>> RecipeRegistration<R> register(String idName, class_1865<R> serializer) {
        class_2960 id = class_2960.method_60655(IndustrialElixir.MOD_ID, idName);

        class_3956<R> type = class_2378.method_10230(class_7923.field_41188, id, new class_3956<R>() {
            @Override
            public String toString() {
                return idName;
            }
        });
        class_1865<R> ser = class_2378.method_10230(class_7923.field_41189, id, serializer);

        return new RecipeRegistration<>(type, ser);
    }

    public static class RecipeRegistration<R extends class_1860<?>> {
        public final class_3956<R> type;
        public final class_1865<R> serializer;

        public RecipeRegistration(class_3956<R> type, class_1865<R> serializer) {
            this.type = type;
            this.serializer = serializer;
        }
    }

    public static void registerRecipes() {
        IndustrialElixir.LOGGER.info("Registering Custom Recipes for " + IndustrialElixir.MOD_ID);
    }
}

