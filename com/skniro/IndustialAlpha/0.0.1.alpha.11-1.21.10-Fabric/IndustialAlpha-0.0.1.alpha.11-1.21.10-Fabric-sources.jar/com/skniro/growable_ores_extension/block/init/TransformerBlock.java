package com.skniro.growable_ores_extension.block.init;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

public class TransformerBlock extends class_2248 {
    public static final MapCodec<TransformerBlock> CODEC = method_54094(TransformerBlock::new);
    private static final class_265 SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0);
    public static final class_2754<class_2350> FACING = class_2741.field_12481;
    public static final class_2746 LIT = class_2741.field_12548;

    public TransformerBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return field_46280;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }
/*
    @Override
    @Nullable
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new BlockEntity(pos, state);
    }
*/

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{FACING, LIT});
    }
}