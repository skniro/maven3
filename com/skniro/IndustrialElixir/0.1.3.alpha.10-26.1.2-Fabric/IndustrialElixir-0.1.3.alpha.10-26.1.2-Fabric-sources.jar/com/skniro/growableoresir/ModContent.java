package com.skniro.growableoresir;


import com.skniro.growableoresir.block.*;
import com.skniro.growableoresir.conifg.GrowableOresConfig;
import com.skniro.growableoresir.item.GrowableOresItems;
import com.skniro.growableoresir.util.GrowableOresItemGroups;
import net.fabricmc.loader.api.FabricLoader;


public class ModContent {


    public static void registerItem(){
        GrowableOresItems.shield_item();
    }
    public static void registerBlock(){
        GrowableOresItemGroups.ic_item();
        GrowableICOresBlocks.registerModBlocks();
    }

    public static void CreativeTab() {
    }
}
