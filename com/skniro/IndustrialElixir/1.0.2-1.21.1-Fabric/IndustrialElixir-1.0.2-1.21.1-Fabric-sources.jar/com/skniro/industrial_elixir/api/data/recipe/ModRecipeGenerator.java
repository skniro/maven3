package com.skniro.industrial_elixir.api.data.recipe;

import com.skniro.industrial_elixir.item.MapleArmorItems;
import java.util.List;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1874;
import net.minecraft.class_1935;
import net.minecraft.class_2066;
import net.minecraft.class_2096;
import net.minecraft.class_2446;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_5794;
import net.minecraft.class_6862;
import net.minecraft.class_7699;
import net.minecraft.class_7709;
import net.minecraft.class_7800;
import net.minecraft.class_7871;
import net.minecraft.class_8790;

import static net.minecraft.class_2446.method_32807;

/**
 * Recipe builder factory shared by the datagen generators.
 *
 * <p>26.1 made this a {@code RecipeProvider} subclass; 1.21.1 keeps the
 * providers separate, so this is now a plain helper that carries the item
 * lookup and the recipe output for the duration of one generator run.</p>
 */
public class ModRecipeGenerator {
    private final class_7871<class_1792> itemLookup;
    protected final class_8790 output;

    protected ModRecipeGenerator(class_7871<class_1792> itemLookup, class_8790 output) {
        this.itemLookup = itemLookup;
        this.output = output;
    }

    public void buildRecipes() {
    }

    /*
     * 26.1 made these RecipeProvider helpers instance methods; 1.21.1 only has them as
     * statics taking the RecipeOutput first, so re-expose them here for the generators.
     */

    public class_175<class_2066.class_2068> has(class_1935 item) {
        return class_2446.method_10426(item);
    }

    public class_175<class_2066.class_2068> has(class_6862<class_1792> tag) {
        return class_2446.method_10420(tag);
    }

    public class_175<class_2066.class_2068> has(class_2096.class_2100 count, class_1935 item) {
        return class_2446.method_35914(count, item);
    }

    public class_1856 tag(class_6862<class_1792> tag) {
        return class_1856.method_8106(tag);
    }

    public void woodFromLogs(class_1935 wood, class_1935 log) {
        class_2446.method_24476(this.output, wood, log);
    }

    public void woodenBoat(class_1935 boat, class_1935 planks) {
        class_2446.method_24478(this.output, boat, planks);
    }

    public void chestBoat(class_1935 chestBoat, class_1935 boat) {
        class_2446.method_42754(this.output, chestBoat, boat);
    }

    public void hangingSign(class_1935 hangingSign, class_1935 strippedLog) {
        class_2446.method_46208(this.output, hangingSign, strippedLog);
    }

    public void shelf(class_1935 shelf, class_1935 strippedLog) {
        shaped(class_7800.field_40635, shelf, 6).method_10434('#', strippedLog)
                .method_10439("###").method_10439("   ").method_10439("###").method_10435("shelf")
                .method_10429(method_32807(strippedLog), this.has(strippedLog)).method_10431(this.output);
    }

    public void generateRecipes(class_5794 family, class_7699 enabledFeatures) {
        class_2446.method_33535(this.output, family, enabledFeatures);
    }

    public void oreSmelting(List<class_1935> ingredients, class_7800 category, class_7709 bookCategory, class_1935 result, float experience, int cookingTime, String group) {
        class_2446.method_36233(this.output, ingredients, category, result, experience, cookingTime, group);
    }

    public <T extends class_1874> void simpleCookingRecipe(String source, class_1865<T> serializer, class_1874.class_3958<T> factory, int cookingTime, class_1935 base, class_1935 result, float experience) {
        class_2446.method_36448(this.output, source, serializer, factory, cookingTime, base, result, experience);
    }

    public ExtractorRecipeJsonBuilder createExtractor(class_1935 output, int count) {
        return ExtractorRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public ExtractorRecipeJsonBuilder createExtractor(class_1935 output) {
        return ExtractorRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public MaceratorRecipeJsonBuilder createMacerator(class_1935 output, int count) {
        return MaceratorRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public MaceratorRecipeJsonBuilder createMacerator(class_1935 output) {
        return MaceratorRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public CompressorRecipeJsonBuilder createCompressor(class_1935 output, int count) {
        return CompressorRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public CompressorRecipeJsonBuilder createCompressor(class_1935 output) {
        return CompressorRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public MetalFormerRollingRecipeJsonBuilder createMetalFormerRolling(class_1935 input, class_1935 output) {
        return createMetalFormerRolling(input, output, 1);
    }

    public MetalFormerRollingRecipeJsonBuilder createMetalFormerRolling(class_1935 input, class_1935 output, int count) {
        return createMetalFormerRolling(input, 1, output, count);
    }

    public MetalFormerRollingRecipeJsonBuilder createMetalFormerRolling(class_1935 input, int inputCount, class_1935 output, int count) {
        MetalFormerRollingRecipeJsonBuilder builder = MetalFormerRollingRecipeJsonBuilder.create(this.itemLookup, output, count).input(input, inputCount).method_33530(method_32807(input), has(input));
        createWorkbenchRolling(input, output, count);
        return builder;
    }

    private void createWorkbenchCutting(class_1935 input, class_1935 outputItem, int count) {
        shapeless(class_7800.field_40642, outputItem, count).method_10454(MapleArmorItems.CUTTING).method_10454(input).method_10442(method_32807(input), has(input)).method_10431(this.output);
    }

    public MetalFormerCuttingRecipeJsonBuilder createMetalFormerCutting(class_1935 input, class_1935 output) {
        return createMetalFormerCutting(input, output, 1);
    }

    public MetalFormerCuttingRecipeJsonBuilder createMetalFormerCutting(class_1935 input, class_1935 output, int count) {
        return createMetalFormerCutting(input, 1, output, count);
    }

    public MetalFormerCuttingRecipeJsonBuilder createMetalFormerCutting(class_1935 input, int inputCount, class_1935 output, int count) {
        MetalFormerCuttingRecipeJsonBuilder builder = MetalFormerCuttingRecipeJsonBuilder.create(this.itemLookup, output, count).input(input, inputCount).method_33530(method_32807(input), has(input));
        createWorkbenchCutting(input, output, count);
        return builder;
    }

    private void createWorkbenchRolling(class_1935 input, class_1935 outputItem, int count) {
        shapeless(class_7800.field_40642, outputItem, count).method_10454(MapleArmorItems.ROLLING).method_10454(input).method_10442(method_32807(input), has(input)).method_10431(this.output);
    }

    public MetalFormerExtrudingRecipeJsonBuilder createMetalFormerExtruding(class_1935 input, int inputCount, class_1935 output, int count) {
        return MetalFormerExtrudingRecipeJsonBuilder.create(this.itemLookup, output, count).input(input, inputCount).method_33530(method_32807(input), has(input));
    }

    public MetalFormerExtrudingRecipeJsonBuilder createMetalFormerExtruding(class_1935 input, int inputCount, class_1935 output) {
        return createMetalFormerExtruding(input, inputCount, output, 1);
    }

    public MetalFormerExtrudingRecipeJsonBuilder createMetalFormerExtruding(class_1935 input, class_1935 output) {
        return createMetalFormerExtruding(input, 1, output);
    }

    public MetalFormerExtrudingRecipeJsonBuilder createMetalFormerExtruding(class_1935 input, class_1935 output, int count) {
        return createMetalFormerExtruding(input, 1, output, count);
    }

    public MolecularTransformerRecipeJsonBuilder createMolecularTransformer(class_1935 input, int inputCount, class_1935 output, int count, long requiredEnergy) {
        return MolecularTransformerRecipeJsonBuilder.create(this.itemLookup, output, count, requiredEnergy).input(input, inputCount).method_33530(method_32807(input), has(input));
    }

    public MolecularTransformerRecipeJsonBuilder createMolecularTransformer(class_1935 input, class_1935 output, int count, long requiredEnergy) {
        return createMolecularTransformer(input, 1, output, count, requiredEnergy);
    }

    public MolecularTransformerRecipeJsonBuilder createMolecularTransformer(class_1935 input, class_1935 output, long requiredEnergy) {
        return createMolecularTransformer(input, 1, output, 1, requiredEnergy);
    }

    public MolecularTransformerRecipeJsonBuilder createMolecularTransformer(class_1935 input, int inputCount, class_1935 output, long requiredEnergy) {
        return createMolecularTransformer(input, inputCount, output, 1, requiredEnergy);
    }

    public class_2447 shaped(class_7800 category, class_1935 output) {
        return class_2447.method_10437(category, output);
    }

    public class_2447 shaped(class_7800 category, class_1935 output, int count) {
        return class_2447.method_10436(category, output, count);
    }

    public class_2450 shapeless(class_7800 category, class_1935 output) {
        return class_2450.method_10447(category, output);
    }

    public class_2450 shapeless(class_7800 category, class_1935 output, int count) {
        return class_2450.method_10448(category, output, count);
    }

    public CuttingRecipeJsonBuilder createCutting(class_1935 input, class_1935 output) {
        return createCutting(input, output, 1);
    }

    public CuttingRecipeJsonBuilder createCutting(class_1935 input, int inputCount, class_1935 output) {
        return createCutting(input, inputCount, output, 1);
    }

    public CuttingRecipeJsonBuilder createCutting(class_1935 input, class_1935 output, int count) {
        return createCutting(input, 1, output, count);
    }

    public CuttingRecipeJsonBuilder createCutting(class_1935 input, int inputCount, class_1935 output, int count) {
        CuttingRecipeJsonBuilder builder = CuttingRecipeJsonBuilder.create(this.itemLookup, output, count).input(input, inputCount).method_33530(method_32807(input), has(input));
        return builder;
    }

    public BrewReactorRecipeJsonBuilder createBrewReactor(class_1935 output, int count) {
        return BrewReactorRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public BrewReactorRecipeJsonBuilder createBrewReactor(class_1935 output) {
        return BrewReactorRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public BrewReactorRecipeJsonBuilder createBrewReactor(class_1799 output) {
        return BrewReactorRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public CoffeeMachineRecipeJsonBuilder createCoffeeMachine(class_1935 output, int count) {
        return CoffeeMachineRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public CoffeeMachineRecipeJsonBuilder createCoffeeMachine(class_1935 output) {
        return CoffeeMachineRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public CoffeeMachineRecipeJsonBuilder createCoffeeMachine(class_1799 output) {
        return CoffeeMachineRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public CropFarmRecipeJsonBuilder createCropFarm(class_1935 output, int count) {
        return CropFarmRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public CropFarmRecipeJsonBuilder createCropFarm(class_1935 output) {
        return CropFarmRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public OreWashingRecipeJsonBuilder createOreWashing(class_1935 output, int count) {
        return OreWashingRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public OreWashingRecipeJsonBuilder createOreWashing(class_1935 output) {
        return OreWashingRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public HeatCentrifugeRecipeJsonBuilder createHeatCentrifuge(class_1935 output, int count) {
        return HeatCentrifugeRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public HeatCentrifugeRecipeJsonBuilder createHeatCentrifuge(class_1935 output) {
        return HeatCentrifugeRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public ModBlastFurnaceRecipeJsonBuilder createBlastFurnace(class_1935 output, int count) {
        return ModBlastFurnaceRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public ModBlastFurnaceRecipeJsonBuilder createBlastFurnace(class_1935 output) {
        return ModBlastFurnaceRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public void addWoodSet(class_8790 exporter, class_1935 log, class_1935 strippedLog, class_1935 wood, class_1935 strippedWood, class_1935 planks, String name) {
        createCutting(log, planks, 6).method_36443(exporter, name + "_log_to_planks");
        createCutting(strippedLog, planks, 6).method_36443(exporter, name + "_stripped_log_to_planks");
        createCutting(wood, planks, 6).method_36443(exporter, name + "_wood_to_planks");
        createCutting(strippedWood, planks, 6).method_36443(exporter, name + "_stripped_wood_to_planks");
    }
}
