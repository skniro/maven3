package torcherino.platform;

import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2586;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.server.MinecraftServer;
import java.util.Collection;
import java.util.Collections;

public class NetworkManager {
	public static void sendToAll(class_8710 payload, MinecraftServer server) {
		send(payload, PlayerLookup.all(server));
	}

	public static void sendToPlayer(class_8710 payload, class_3222 serverPlayerEntity) {
		send(payload, Collections.singletonList(serverPlayerEntity));
	}

	public static void sendToWorld(class_8710 payload, class_3218 world) {
		send(payload, PlayerLookup.world(world));
	}


	public static void sendToTracking(class_8710 payload, class_2586 blockEntity) {
		send(payload, PlayerLookup.tracking(blockEntity));
	}

	public static void send(class_8710 payload, Collection<class_3222> players) {
		for (class_3222 player : players) {
			ServerPlayNetworking.send(player, payload);
		}
	}
}
