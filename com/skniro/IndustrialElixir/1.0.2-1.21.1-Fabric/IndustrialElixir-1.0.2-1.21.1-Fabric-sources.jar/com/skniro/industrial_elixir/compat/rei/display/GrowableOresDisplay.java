package com.skniro.industrial_elixir.compat.rei.display;

import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipe;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2960;
import net.minecraft.class_8786;
import java.util.List;
import java.util.Optional;

public class GrowableOresDisplay extends BasicDisplay {
    public static final CategoryIdentifier<GrowableOresDisplay> GrowableOres =
            CategoryIdentifier.of(IndustrialElixir.MOD_ID, "cane_converter");

    public static final DisplaySerializer<GrowableOresDisplay> SERIALIZER = BasicDisplay.Serializer.<GrowableOresDisplay>ofSimple(
            (inputs, outputs, location) -> new GrowableOresDisplay(inputs, outputs, location)
    );

    public GrowableOresDisplay(AlchemyCraftingRecipe recipe) {
        this(List.of(EntryIngredients.ofIngredient(recipe.ingredient())),
                List.of(EntryIngredients.of(recipe.output())), Optional.empty());
    }

    public GrowableOresDisplay(List<EntryIngredient> inputs, List<EntryIngredient> outputs, Optional<class_2960> location) {
        super(inputs, outputs, location);
    }

    public GrowableOresDisplay(class_8786<AlchemyCraftingRecipe> recipe){
        super(List.of(EntryIngredients.ofIngredient(recipe.comp_1933().ingredient())),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.comp_1933().output()))));
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return GrowableOres;
    }

}