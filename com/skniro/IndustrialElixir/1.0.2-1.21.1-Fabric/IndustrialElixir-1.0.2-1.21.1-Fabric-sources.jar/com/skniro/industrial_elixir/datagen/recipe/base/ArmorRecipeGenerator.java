package com.skniro.industrial_elixir.datagen.recipe.base;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.item.MapleArmorItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2454;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class ArmorRecipeGenerator extends FabricRecipeProvider {
    public ArmorRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                shaped(class_7800.field_40638, MapleArmorItems.BRONZE_PICKAXE)
                        .method_10439("###")
                        .method_10439(" I ")
                        .method_10439(" I ")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10434('I', class_1802.field_8600)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                has(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(output);

                shaped(class_7800.field_40639, MapleArmorItems.BRONZE_SWORD)
                        .method_10439("#")
                        .method_10439("#")
                        .method_10439("|")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10434('|', class_1802.field_8600)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                has(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(output);

                shaped(class_7800.field_40638, MapleArmorItems.BRONZE_AXE)
                        .method_10439("##")
                        .method_10439("#|")
                        .method_10439(" |")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10434('|', class_1802.field_8600)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                has(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(output);

                shaped(class_7800.field_40638, MapleArmorItems.BRONZE_SHOVEL)
                        .method_10439("#")
                        .method_10439("|")
                        .method_10439("|")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10434('|', class_1802.field_8600)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                has(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(output);

                shaped(class_7800.field_40638, MapleArmorItems.BRONZE_HOE)
                        .method_10439("##")
                        .method_10439(" |")
                        .method_10439(" |")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10434('|', class_1802.field_8600)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                has(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(output);

                shaped(class_7800.field_40639, MapleArmorItems.BRONZE_HELMET)
                        .method_10439("###")
                        .method_10439("# #")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                has(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(output);

                shaped(class_7800.field_40639, MapleArmorItems.BRONZE_CHESTPLATE)
                        .method_10439("# #")
                        .method_10439("###")
                        .method_10439("###")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                has(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(output);

                shaped(class_7800.field_40639, MapleArmorItems.BRONZE_LEGGINGS)
                        .method_10439("###")
                        .method_10439("# #")
                        .method_10439("# #")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                has(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(output);

                shaped(class_7800.field_40639, MapleArmorItems.BRONZE_BOOTS)
                        .method_10439("# #")
                        .method_10439("# #")
                        .method_10434('#', GrowableOresItems.BRONZE_INGOT)
                        .method_10429(method_32807(GrowableOresItems.BRONZE_INGOT),
                                has(GrowableOresItems.BRONZE_INGOT))
                        .method_10431(output);

                class_2454.method_17802(
                                class_1856.method_8091(
                                        MapleArmorItems.BRONZE_PICKAXE,
                                        MapleArmorItems.BRONZE_AXE,
                                        MapleArmorItems.BRONZE_SHOVEL,
                                        MapleArmorItems.BRONZE_SWORD,
                                        MapleArmorItems.BRONZE_HOE,
                                        MapleArmorItems.BRONZE_HELMET,
                                        MapleArmorItems.BRONZE_CHESTPLATE,
                                        MapleArmorItems.BRONZE_LEGGINGS,
                                        MapleArmorItems.BRONZE_BOOTS
                                ),
                                class_7800.field_40642, GrowableOresItems.BRONZE_INGOT, 0.1F, 200)
                        .method_10469("has_bronze_pickaxe", this.has(MapleArmorItems.BRONZE_PICKAXE))
                        .method_10469("has_bronze_axe", this.has(MapleArmorItems.BRONZE_AXE))
                        .method_10469("has_bronze_shovel", this.has(MapleArmorItems.BRONZE_SHOVEL))
                        .method_10469("has_bronze_sword", this.has(MapleArmorItems.BRONZE_SWORD))
                        .method_10469("has_bronze_hoe", this.has(MapleArmorItems.BRONZE_HOE))
                        .method_10469("has_bronze_helmet", this.has(MapleArmorItems.BRONZE_HELMET))
                        .method_10469("has_bronze_chestplate", this.has(MapleArmorItems.BRONZE_CHESTPLATE))
                        .method_10469("has_bronze_leggings", this.has(MapleArmorItems.BRONZE_LEGGINGS))
                        .method_10469("has_bronze_boots", this.has(MapleArmorItems.BRONZE_BOOTS))
                        .method_36443(this.output, method_36451(GrowableOresItems.BRONZE_INGOT));

                shaped(class_7800.field_40639, MapleArmorItems.Quantum_HELMET)
                        .method_10439("CCC")
                        .method_10439("#L#")
                        .method_10439("ARA")
                        .method_10434('C', GrowableOresItems.CARBON_PLATE)
                        .method_10434('#', GrowableOresItems.IRIDIUM_PLATE)
                        .method_10434('L', GrowableOresItems.LAPOTRON_CRYSTAL)
                        .method_10434('A', GrowableOresItems.Advanced_Circuit)
                        .method_10434('R', GeneralBlocks.Reinforced_Glass)
                        .method_10429(method_32807(GrowableOresItems.Advanced_Circuit),
                                has(GrowableOresItems.Advanced_Circuit))
                        .method_10431(output);

                shaped(class_7800.field_40639, MapleArmorItems.Quantum_CHESTPLATE)
                        .method_10439("CCC")
                        .method_10439("#L#")
                        .method_10439("#A#")
                        .method_10434('C', GrowableOresItems.CARBON_PLATE)
                        .method_10434('#', GrowableOresItems.IRIDIUM_PLATE)
                        .method_10434('L', GrowableOresItems.LAPOTRON_CRYSTAL)
                        .method_10434('A', GrowableOresItems.ALLOY_PLATE)
                        .method_10429(method_32807(GrowableOresItems.CARBON_PLATE),
                                has(GrowableOresItems.CARBON_PLATE))
                        .method_10431(output);

                shaped(class_7800.field_40639, MapleArmorItems.Quantum_LEGGINGS)
                        .method_10439("MLM")
                        .method_10439("#C#")
                        .method_10439("GCG")
                        .method_10434('M', GeneralBlocks.Machine)
                        .method_10434('G', class_1802.field_8601)
                        .method_10434('C', GrowableOresItems.CARBON_PLATE)
                        .method_10434('#', GrowableOresItems.IRIDIUM_PLATE)
                        .method_10434('L', GrowableOresItems.LAPOTRON_CRYSTAL)
                        .method_10429(method_32807(GrowableOresItems.CARBON_PLATE),
                                has(GrowableOresItems.CARBON_PLATE))
                        .method_10431(output);

                shaped(class_7800.field_40639, MapleArmorItems.Quantum_BOOTS)
                        .method_10439("CCC")
                        .method_10439("#R#")
                        .method_10439("RLR")
                        .method_10434('R', GrowableOresItems.Rubber)
                        .method_10434('C', GrowableOresItems.CARBON_PLATE)
                        .method_10434('#', GrowableOresItems.IRIDIUM_PLATE)
                        .method_10434('L', GrowableOresItems.LAPOTRON_CRYSTAL)
                        .method_10429(method_32807(GrowableOresItems.CARBON_PLATE),
                                has(GrowableOresItems.CARBON_PLATE))
                        .method_10431(output);

                shaped(class_7800.field_40639, MapleArmorItems.Electric_Jetpack)
                        .method_10439("I#I")
                        .method_10439("ILI")
                        .method_10439("G G")
                        .method_10434('I', GrowableOresItems.IRON_CASING)
                        .method_10434('#', GrowableOresItems.Advanced_Circuit)
                        .method_10434('L', GrowableOresBlocks.EnergyBox)
                        .method_10434('G', class_1802.field_8601)
                        .method_10429(method_32807(GrowableOresItems.IRON_CASING),
                                has(GrowableOresItems.IRON_CASING))
                        .method_10431(output);
            }
        };
    }


    @Override
    public String method_10321() {
        return "Armor";
    }
}