package com.skniro.industrial_elixir.block.init.energybox;


import com.mojang.serialization.MapCodec;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.entity.energybox.BaseEnergyBoxBlockEntity;
import com.skniro.industrial_elixir.block.entity.energybox.EnergyBoxBlockEntity;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class EnergyBoxBlock extends AbstractMachineblock {

    public EnergyBoxBlock(class_2251 settings, int capacity, EnergyTier energyTier) {
        super(settings, energyTier, capacity);
    }

/*    public static final MapCodec<EnergyBoxBlock> CODEC = RecordCodecBuilder.mapCodec(instance ->
            instance.group(
                    createSettingsCodec(),
                    Codec.INT.fieldOf("capacity").forGetter(block -> block.capacity),
                    EnergyTier.CODEC.fieldOf("energy_tier").forGetter(block -> block.energyTier)
            ).apply(instance, EnergyBoxBlock::new)
    );*/

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        throw new IllegalStateException("Block does not support getCodec!");
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new EnergyBoxBlockEntity(pos, state);
    }


    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            class_2586 blockEntity = world.method_8321(pos);
            if (blockEntity instanceof BaseEnergyBoxBlockEntity) {
                class_1264.method_5451(world, pos, (class_1263) blockEntity);
                world.method_8455(pos,this);
            }
        }
        super.method_9536(state, world, pos, newState, moved);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, AlchemyBlockEntityType.EnergyBox_BLOCK_ENTITY, (world1, pos, state1, blockEntity) -> blockEntity.tick(world1, pos, state1));
    }

}
