package com.skniro.growable_ores_extension.block.renderer;


import com.skniro.growable_ores_extension.block.entity.Alchemyblockentity;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_918;
public class AlchemyblockentityRenderer implements class_827<Alchemyblockentity> {
    public AlchemyblockentityRenderer(class_5614.class_5615 context) {
    }
    @Override
    public void render(Alchemyblockentity entity, float tickDelta, class_4587 matrices,
                       class_4597 vertexConsumers, int light, int overlay) {
        class_918 itemRenderer = class_310.method_1551().method_1480();
        class_1799 stack = entity.getRenderStack();
        class_2350 direction = entity.method_11010().method_11654(class_2741.field_12481);
        matrices.method_22903();
        switch (direction) {
            case field_11043 -> matrices.method_46416(0.5f, 0.5f, -0.01f);
            case field_11035 -> matrices.method_46416(0.5f, 0.5f, 1.01f);
            case field_11039 -> matrices.method_46416(-0.01f, 0.5f, 0.5f);
            case field_11034 -> matrices.method_46416(1.01f, 0.5f, 0.5f);
        }
        matrices.method_22905(0.35f, 0.35f, 0.35f);
        switch (direction) {
            case field_11043 -> matrices.method_22907(class_7833.field_40716.rotationDegrees(0));
            case field_11035 -> matrices.method_22907(class_7833.field_40716.rotationDegrees(180));
            case field_11039 -> matrices.method_22907(class_7833.field_40716.rotationDegrees(90));
            case field_11034 -> matrices.method_22907(class_7833.field_40716.rotationDegrees(270));
        }
        itemRenderer.method_23178(stack, class_811.field_4317, getLightLevel(entity.method_10997(),
                entity.method_11016()), class_4608.field_21444, matrices, vertexConsumers, entity.method_10997(), 1);
        matrices.method_22909();
    }
    private int getLightLevel(class_1937 world, class_2338 pos) {
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, Math.max(sLight, 15));
    }
}