package com.skniro.industrial_elixir.compat.jei;

import com.skniro.growableoresir.GrowableOres;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.compat.jei.category.*;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.machine.MaceratorCraftingRecipe;
import com.skniro.industrial_elixir.screen.ingame.machine.*;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.constants.RecipeTypes;
import mezz.jei.api.recipe.types.IRecipeType;
import mezz.jei.api.registration.*;
import mezz.jei.api.runtime.IJeiRuntime;
import net.fabricmc.fabric.api.recipe.v1.sync.SynchronizedRecipes;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeManager;

import java.util.ArrayList;

public class IndustrialElixirJEIPlugin implements IModPlugin {
    public static SynchronizedRecipes recipeMap = null;

    @Override
    public Identifier getPluginUid() {
        return Identifier.fromNamespaceAndPath(IndustrialElixir.MOD_ID,"jei_plugin");
    }

    @Override
    public void registerCategories(IRecipeCategoryRegistration registration) {
        registration.addRecipeCategories(
                new MaceratorCategory(registration.getJeiHelpers().getGuiHelper()),
                new CompressorCategory(registration.getJeiHelpers().getGuiHelper()),
                new MetalFormerRollingCategory(registration.getJeiHelpers().getGuiHelper()),
                new MetalFormerCuttingCategory(registration.getJeiHelpers().getGuiHelper()),
                new MetalFormerExtrudingCategory(registration.getJeiHelpers().getGuiHelper()),
                new MolecularTransformerCategory(registration.getJeiHelpers().getGuiHelper()),
                new ExtractorCategory(registration.getJeiHelpers().getGuiHelper()),
                new GrowableOresCategory(registration.getJeiHelpers().getGuiHelper()),
                new RecyclerCategory(registration.getJeiHelpers().getGuiHelper()),
                new BlockCutterCategory(registration.getJeiHelpers().getGuiHelper())
        );
    }

    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        registration.addRecipes(
                MaceratorCategory.TYPE,
                new ArrayList<>(recipeMap.getAllOfType(AlchemyRecipeType.MACERATOR.type))
        );

        registration.addRecipes(
                CompressorCategory.TYPE,
                new ArrayList<>(recipeMap.getAllOfType(AlchemyRecipeType.COMPRESSOR.type))
        );

        registration.addRecipes(
                MetalFormerRollingCategory.TYPE,
                new ArrayList<>(recipeMap.getAllOfType(AlchemyRecipeType.METALFORMER_ROLLING.type))
        );

        registration.addRecipes(
                MetalFormerCuttingCategory.TYPE,
                new ArrayList<>(recipeMap.getAllOfType(AlchemyRecipeType.METALFORMER_CUTTING.type))
        );

        registration.addRecipes(
                MetalFormerExtrudingCategory.TYPE,
                new ArrayList<>(recipeMap.getAllOfType(AlchemyRecipeType.METALFORMER_EXTRUDING.type))
        );

        registration.addRecipes(
                MolecularTransformerCategory.TYPE,
                new ArrayList<>(recipeMap.getAllOfType(AlchemyRecipeType.MOLECULAR_TRANSFORMER.type))
        );

        registration.addRecipes(
                ExtractorCategory.TYPE,
                new ArrayList<>(recipeMap.getAllOfType(AlchemyRecipeType.EXTRACTOR.type))
        );

        registration.addRecipes(
                GrowableOresCategory.TYPE,
                new ArrayList<>(recipeMap.getAllOfType(AlchemyRecipeType.CANE_CONVERTER.type))
        );

        registration.addRecipes(
                RecyclerCategory.TYPE,
                new ArrayList<>(recipeMap.getAllOfType(AlchemyRecipeType.RECYCLER.type))
        );

        registration.addRecipes(
                BlockCutterCategory.TYPE,
                new ArrayList<>(recipeMap.getAllOfType(AlchemyRecipeType.CUTTING.type))
        );
    }

    @Override
    public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
        registration.addCraftingStation(RecipeTypes.SMELTING, new ItemStack(GrowableOresBlocks.Iron_Furnace_Block));
        registration.addCraftingStation(MaceratorCategory.TYPE, new ItemStack(GrowableOresBlocks.Macerator_Block));
        registration.addCraftingStation(CompressorCategory.TYPE, new ItemStack(GrowableOresBlocks.Compressor_Block));
        registration.addCraftingStation(MetalFormerRollingCategory.TYPE, new ItemStack(GrowableOresBlocks.MetalFormerBlock));
        registration.addCraftingStation(MetalFormerCuttingCategory.TYPE, new ItemStack(GrowableOresBlocks.MetalFormerBlock));
        registration.addCraftingStation(MetalFormerExtrudingCategory.TYPE, new ItemStack(GrowableOresBlocks.MetalFormerBlock));
        registration.addCraftingStation(ExtractorCategory.TYPE, new ItemStack(GrowableOresBlocks.Extractor_Block));
        registration.addCraftingStation(MolecularTransformerCategory.TYPE, new ItemStack(GrowableOresBlocks.MolecularTransformerBlock));
        registration.addCraftingStation(GrowableOresCategory.TYPE, new ItemStack(GrowableOresBlocks.GrowableOres_Block));
        registration.addCraftingStation(RecyclerCategory.TYPE, new ItemStack(GrowableOresBlocks.RECYCLER_Block));
        registration.addCraftingStation(BlockCutterCategory.TYPE, new ItemStack(GrowableOresBlocks.CUTTING_Block));

    }

    @Override
    public void registerGuiHandlers(IGuiHandlerRegistration registration) {
        registration.addRecipeClickArea(MaceratorBlockScreen.class, 78, 30, 20, 25, MaceratorCategory.TYPE);
        registration.addRecipeClickArea(CompressorBlockScreen.class, 78, 30, 20, 25, CompressorCategory.TYPE);
        registration.addRecipeClickArea(MetalFormerBlockScreen.class, 78, 30, 20, 25, MetalFormerRollingCategory.TYPE);
        registration.addRecipeClickArea(MetalFormerBlockScreen.class, 78, 30, 20, 25, MetalFormerCuttingCategory.TYPE);
        registration.addRecipeClickArea(MetalFormerBlockScreen.class, 78, 30, 20, 25, MetalFormerExtrudingCategory.TYPE);
        registration.addRecipeClickArea(MolecularTransformerBlockScreen.class, 78, 30, 20, 25, MolecularTransformerCategory.TYPE);
        registration.addRecipeClickArea(ExtractorBlockScreen.class, 78, 30, 20, 25, ExtractorCategory.TYPE);
        registration.addRecipeClickArea(AlchemyBlockScreen.class, 78, 30, 20, 25, GrowableOresCategory.TYPE);
        registration.addRecipeClickArea(RecyclerBlockScreen.class, 78, 30, 20, 25, RecyclerCategory.TYPE);
        registration.addRecipeClickArea(CuttingBlockScreen.class, 78, 30, 20, 25, BlockCutterCategory.TYPE);
        registration.addRecipeClickArea(ElectricFurnaceBlockScreen.class, 78, 30, 20, 25, RecipeTypes.SMELTING);
    }
}
