package com.skniro.growable_ores_extension.api;

import com.skniro.growable_ores_extension.recipe.machine.AbstractMachineCraftingRecipe;
import net.minecraft.world.item.crafting.RecipeType;

@FunctionalInterface
public interface MachineRecipeProvider {

    RecipeType<?> getCurrentRecipeType();

}