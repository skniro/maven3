package com.skniro.industrial_elixir.world.gen;

import com.skniro.industrial_elixir.world.feature.ModPlacedFeatures;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_2893;

public class ModOreGeneration {
    public static void generateOres() {
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Lead_Ore_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Tin_Ore_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.SACRED_Ore_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Deepslate_Lead_Ore_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Deepslate_Tin_Ore_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, ModPlacedFeatures.Deepslate_SACRED_Ore_PLACED_KEY);
    }
}