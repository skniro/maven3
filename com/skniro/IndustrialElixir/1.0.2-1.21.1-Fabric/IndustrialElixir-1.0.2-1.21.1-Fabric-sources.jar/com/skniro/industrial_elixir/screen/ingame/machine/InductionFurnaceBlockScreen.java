package com.skniro.industrial_elixir.screen.ingame.machine;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.screen.handler.machine.InductionFurnaceScreenHandler;
import com.skniro.industrial_elixir.util.MouseUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.util.List;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class InductionFurnaceBlockScreen extends class_465<InductionFurnaceScreenHandler> {
    private static final class_2960 TEXTURE = class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/machine/inductionfurnace.png");

    public InductionFurnaceBlockScreen(InductionFurnaceScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
    }

    private void renderHeatAreaTooltips(class_332 context) {
        context.method_51439(field_22793, class_2561.method_43470("Heat: " + field_2797.getHeat() + "%"), 88, 68, -12566464, false);
    }

    private void renderEnergyAreaTooltips(class_332 context, int pMouseX, int pMouseY, int x, int y) {
        if (isMouseAboveArea(pMouseX, pMouseY, x, y, 15, 32, 13, 13)) {
            context.method_51437(Screens.getTextRenderer(this),
                    List.of(class_2561.method_43470(field_2797.blockEntity.energyContainer.getSideStorage(null).getAmount() + " / " + field_2797.blockEntity.energyContainer.getSideStorage(null).getCapacity() + " E")),
                    Optional.empty(), pMouseX, pMouseY);
        }
    }

    private void renderEnergyArea(class_332 context, int x, int y) {
        context.method_25290(TEXTURE, x + 15, y + 32, 176, 0, 13, field_2797.getScaledEnergyHeight(),256,256);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        renderEnergyAreaTooltips(context, mouseX, mouseY, x, y);
        renderHeatAreaTooltips(context);
        context.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, -12566464, false);
        context.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, -12566464, false);
    }

    @Override
    protected void method_2389(class_332 context, float partialTicks, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        context.method_25290(TEXTURE, x, y, 0, 0, field_2792, field_2779, 256, 256);

        if (field_2797.isCrafting()) {
            int progress = field_2797.getScaledProgress();
            context.method_25290(TEXTURE, x + 73, y + 34, 190, 0, progress, 15, 256, 256);
        }

        renderEnergyArea(context, x, y);

/*        int heatWidth = menu.getScaledHeatWidth();
        if (heatWidth > 0) {
            context.fill(x + 62, y + 72, x + 62 + heatWidth, y + 77, 0xFFFF6A00);
        }*/
    }

    private boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, int width, int height) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, width, height);
    }
}
