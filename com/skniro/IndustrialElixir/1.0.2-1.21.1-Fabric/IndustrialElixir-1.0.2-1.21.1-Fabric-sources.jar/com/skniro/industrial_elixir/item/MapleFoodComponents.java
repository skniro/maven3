package com.skniro.industrial_elixir.item;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import java.util.function.Function;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class MapleFoodComponents {
    public static final class_1792 Coffee_Beans = registerItem("coffee_beans",
            createBlockItemWithUniqueName(GeneralBlocks.Coffee_Block),
            new class_1792
                    .class_1793() .method_19265
                            (new class_4174
                                    .class_4175()
                                    .method_19238(1)
                                    .method_19237(0.1f)
                                    .method_19240()
                                    .method_19242()
                            )
                    .method_7889(64)
    );

    public static final class_1792 Coffee_Black = registerItem(
            "coffee_black",
            createBlockItemWithUniqueName(GeneralBlocks.COFFEE_BLACK),
            new class_1792.class_1793()
                    .method_19265(
                            new class_4174.class_4175()
                                    .method_19238(4)
                                    .method_19237(0.6F)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904, 2400, 1), 1.0F)
                                    .method_19239(new class_1293(class_1294.field_5917, 1200, 0), 1.0F)
                                    .method_19242()
                    )
                    .method_7889(1)
    );

    public static final class_1792 Cappuccino = registerItem(
            "cappuccino",
            createBlockItemWithUniqueName(GeneralBlocks.CAPPUCCINO),
            new class_1792.class_1793()
                    .method_19265(
                            new class_4174.class_4175()
                                    .method_19238(9)
                                    .method_19237(1.2F)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904, 1800, 1), 1.0F)
                                    .method_19239(new class_1293(class_1294.field_5924, 300, 0), 1.0F)
                                    .method_19242()
                    )
                    .method_7889(1)
    );

    public static final class_1792 Latte = registerItem(
            "latte",
            createBlockItemWithUniqueName(GeneralBlocks.LATTE),
            new class_1792.class_1793()
                    .method_19265(
                            new class_4174.class_4175()
                                    .method_19238(7)
                                    .method_19237(1.0F)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904, 1200, 0), 1.0F)
                                    .method_19242()
                    )
                    .method_7889(1)
    );

    public static final class_1792 Mocha = registerItem(
            "mocha",
            createBlockItemWithUniqueName(GeneralBlocks.MOCHA),
            new class_1792.class_1793()
                    .method_19265(
                            new class_4174.class_4175()
                                    .method_19238(10)
                                    .method_19237(1.3F)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5904, 2400, 1), 1.0F)
                                    .method_19239(new class_1293(class_1294.field_5924, 600, 0), 1.0F)
                                    .method_19242()
                    )
                    .method_7889(1)
    );

    public static final class_1792 Hot_Cocoa = registerItem(
            "hot_cocoa",
            createBlockItemWithUniqueName(GeneralBlocks.HOT_COCOA),
            new class_1792.class_1793()
                    .method_19265(
                            new class_4174.class_4175()
                                    .method_19238(6)
                                    .method_19237(1.0F)
                                    .method_19240()
                                    .method_19239(new class_1293(class_1294.field_5907, 400, 0), 1.0F)
                                    .method_19239(new class_1293(class_1294.field_5924, 600, 0), 1.0F)
                                    .method_19242()
                    )
                    .method_7889(1)
    );



    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings);
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(IndustrialElixir.MOD_ID, name)), item);
    }

    private static Function<class_1792.class_1793, class_1792> createBlockItemWithUniqueName(class_2248 block) {
        return (settings) -> new class_1747(block, settings);
    }


    public static void registerMapleFoodItems() {
        IndustrialElixir.LOGGER.info("Registering Maple Food Items for " + IndustrialElixir.MOD_ID);
    }
}
