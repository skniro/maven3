package com.skniro.industrial_elixir.recipe.machine;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.ModRecipeSerializers;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class MaceratorCraftingRecipe extends AbstractMachineCraftingRecipe {

    public MaceratorCraftingRecipe(class_1856 ingredients, class_1799 output) {
        super(ingredients, output);
    }

    @Override
    public class_1865<? extends class_1860<AlchemyCraftingRecipeInput>> method_8119() {
        return AlchemyRecipeType.MACERATOR.serializer;
    }

    @Override
    public class_3956<? extends class_1860<AlchemyCraftingRecipeInput>> method_17716() {
        return AlchemyRecipeType.MACERATOR.type;
    }


    public static final MapCodec<MaceratorCraftingRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
            class_1856.field_46095.fieldOf("ingredient").forGetter((recipe) -> {
                return recipe.ingredient;
            }),
            class_1799.field_24671.fieldOf("result").forGetter((recipe) -> {
                return recipe.output;
            })
    ).apply(inst, MaceratorCraftingRecipe::new));

    public static final class_9139<class_9129, MaceratorCraftingRecipe> field_48356 =
            class_9139.method_56435(
                    class_1856.field_48355, AbstractMachineCraftingRecipe::ingredient,
                    class_1799.field_48349, AbstractMachineCraftingRecipe::output,
                    MaceratorCraftingRecipe::new);

    public static final class_1865<MaceratorCraftingRecipe> SERIALIZER =
            ModRecipeSerializers.of(CODEC, field_48356);


    public MapCodec<MaceratorCraftingRecipe> codec() {
        return CODEC;
    }

    public class_9139<class_9129, MaceratorCraftingRecipe> streamCodec() {
        return field_48356;
    }

}
