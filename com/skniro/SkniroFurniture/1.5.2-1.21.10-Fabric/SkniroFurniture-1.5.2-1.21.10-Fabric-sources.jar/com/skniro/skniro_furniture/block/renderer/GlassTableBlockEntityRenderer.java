package com.skniro.skniro_furniture.block.renderer;

import com.skniro.skniro_furniture.block.entity.CabinetBlockEntity;
import com.skniro.skniro_furniture.block.entity.GlassTableBlockEntity;
import com.skniro.skniro_furniture.block.init.FourGridCabinetBlock;
import com.skniro.skniro_furniture.block.init.GlassTableBlock;
import com.skniro.skniro_furniture.block.init.TripleCabinetBlock;
import com.skniro.skniro_furniture.block.renderer.state.CabinetBlockEntityRendererState;
import com.skniro.skniro_furniture.block.renderer.state.GlassTableBlockEntityRendererState;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_11566;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_12075;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_918;

public class GlassTableBlockEntityRenderer implements class_827<GlassTableBlockEntity, GlassTableBlockEntityRendererState> {
    private final class_10442 itemModelManager;

    public GlassTableBlockEntityRenderer(class_5614.class_5615 context) {
        this.itemModelManager = context.comp_4536();
    }

    @Override
    public void updateRenderState(GlassTableBlockEntity entity, GlassTableBlockEntityRendererState state, float tickProgress, class_243 cameraPos, @Nullable class_11683.class_11792 crumblingOverlay) {
        class_827.super.method_74331(entity, state, tickProgress, cameraPos, crumblingOverlay);
        state.stack = entity.inventory;
        state.world = entity.method_10997();
        state.field_62673 = entity.method_11016();
        state.field_62674 = entity.method_11010();
        if (state.field_62674.method_26204() instanceof GlassTableBlock) {
            int j = (int)entity.method_11016().method_10063();
            state.triplecabinetItemStates = new ArrayList();
            for (int i = 0; i < 9; i++) {
                class_10444 itemRenderState = new class_10444();
                this.itemModelManager.method_65598(itemRenderState, (class_1799)entity.method_5438(i), class_811.field_4319, entity.method_10997(), (class_11566)null, i+j);
                state.triplecabinetItemStates.add(itemRenderState);
            }
        }
    }

    @Override
    public void render(GlassTableBlockEntityRendererState state, class_4587 matrices, class_11659 queue, class_12075 cameraRenderState) {
        class_918 itemRenderer = class_310.method_1551().method_1480();
        class_2350 direction = state.field_62674.method_11654(class_2741.field_12481);

        matrices.method_22903();
        if (state.field_62674.method_26204() instanceof GlassTableBlock) {
            switch (direction) {
                case field_11043 -> {}
                case field_11035 -> {
                    matrices.method_46416(1, 0, 1);
                    matrices.method_22907(class_7833.field_40716.rotationDegrees(180));
                }
                case field_11039 -> {
                    matrices.method_46416(0, 0, 1);
                    matrices.method_22907(class_7833.field_40716.rotationDegrees(90));
                }
                case field_11034 -> {
                    matrices.method_46416(1, 0, 0);
                    matrices.method_22907(class_7833.field_40716.rotationDegrees(270));
                }
            }

            matrices.method_46416(0.25f, 0.93f, 0.25f);
            matrices.method_22905(0.23f, 0.23f, 0.23f);

            List<class_10444> list = state.triplecabinetItemStates;

            for (int i = 0; i < 9; i++) {
                class_10444 itemRenderState = (class_10444)list.get(i);
                class_1799 stack = state.stack.get(i);
                if (!stack.method_7960()) {
                    matrices.method_22903();
                    float x = (i % 3) * 1.1f;
                    float z = (i / 3) * 1.1f;
                    matrices.method_46416(x, 0, z);
                    itemRenderState.method_65604(matrices, queue, getLightLevel(state.world, state.field_62673), class_4608.field_21444,0);
                    matrices.method_22909();
                }
            }

            matrices.method_22909();
        }
    }

    private int getLightLevel(class_1937 world, class_2338 pos) {
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, Math.max(sLight, 15));
    }

    @Override
    public GlassTableBlockEntityRendererState method_74335() {
        return new GlassTableBlockEntityRendererState();
    }
}
