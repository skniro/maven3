package com.skniro.maple.block.entity;

import com.skniro.maple.block.init.MapleBlockSetType;
import com.skniro.maple.mixin.SignTypeAccessor;
import net.minecraft.class_4719;

public class MapleSignTypes {
    public static final class_4719 MAPLE =
            SignTypeAccessor.registerNew(SignTypeAccessor.newSignType("maple_maple", MapleBlockSetType.MAPLE));

    public static final class_4719 GINKGO =
            SignTypeAccessor.registerNew(SignTypeAccessor.newSignType("maple_ginkgo", MapleBlockSetType.GINKGO));
}
