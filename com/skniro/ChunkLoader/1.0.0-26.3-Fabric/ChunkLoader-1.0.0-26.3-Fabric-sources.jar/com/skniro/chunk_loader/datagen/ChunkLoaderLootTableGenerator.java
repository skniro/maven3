package com.skniro.chunk_loader.datagen;


import com.skniro.chunk_loader.block.GrowableOresBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootSubProvider;
import net.minecraft.core.HolderLookup;

import java.util.concurrent.CompletableFuture;


public class ChunkLoaderLootTableGenerator extends FabricBlockLootSubProvider {
    protected ChunkLoaderLootTableGenerator(FabricPackOutput dataOutput, CompletableFuture<HolderLookup.Provider> registryLookup) {
        super(dataOutput, registryLookup);
    }
    public static final float[] NORMAL_LEAVES_SAPLING_CHANCES = new float[]{0.048F, 0.0425F, 0.062333336F, 0.1F};


    @Override
    public void generate() {
        dropSelf(GrowableOresBlocks.CHUNK_LOADER);

    }
}
