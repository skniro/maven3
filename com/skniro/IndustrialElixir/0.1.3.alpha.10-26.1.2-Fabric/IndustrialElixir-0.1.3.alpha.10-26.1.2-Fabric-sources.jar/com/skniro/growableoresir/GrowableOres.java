package com.skniro.growableoresir;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.growableoresir.conifg.Configuration;
import com.skniro.growableoresir.conifg.GrowableOresConfig;
import net.fabricmc.api.ModInitializer;


public class GrowableOres implements ModInitializer {
    @Override
    public void onInitialize() {
        new Configuration(GrowableOresConfig.class, IndustrialElixir.MOD_ID);
        ModContent.registerItem();
        ModContent.registerBlock();
        ModContent.CreativeTab();
    }
}
