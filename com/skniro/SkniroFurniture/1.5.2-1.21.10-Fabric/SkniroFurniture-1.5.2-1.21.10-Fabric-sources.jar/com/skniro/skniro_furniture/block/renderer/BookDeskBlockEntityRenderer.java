package com.skniro.skniro_furniture.block.renderer;

import com.skniro.skniro_furniture.block.entity.BookDeskBlockEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_11701;
import net.minecraft.class_11967;
import net.minecraft.class_12075;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_3715;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_557;
import net.minecraft.class_5602;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.minecraft.class_828;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class BookDeskBlockEntityRenderer implements class_827<BookDeskBlockEntity, class_11967> {
    private final class_11701 spriteHolder;
    private final class_557 book;
    private final class_557.class_11650 bookModelState = new class_557.class_11650(0.0F, 0.1F, 0.9F, 1.2F);

    public BookDeskBlockEntityRenderer(class_5614.class_5615 ctx) {
        this.spriteHolder = ctx.comp_4541();
        this.book = new class_557(ctx.method_32140(class_5602.field_27685));
    }

    @Override
    public class_11967 method_74335() {
        return new class_11967();
    }

    @Override
    public void updateRenderState(BookDeskBlockEntity bookDeskBlockEntity, class_11967 lecternBlockEntityRenderState, float f, class_243 vec3d, @Nullable class_11683.class_11792 crumblingOverlayCommand) {
        class_827.super.method_74331(bookDeskBlockEntity, lecternBlockEntityRenderState, f, vec3d, crumblingOverlayCommand);
        lecternBlockEntityRenderState.field_62727 = bookDeskBlockEntity.method_11010().method_11654(class_3715.field_17366);
        lecternBlockEntityRenderState.field_62728 = bookDeskBlockEntity.method_11010().method_11654(class_3715.field_16404).method_10170().method_10144();
    }

    @Override
    public void render(class_11967 lecternBlockEntityRenderState, class_4587 matrixStack, class_11659 orderedRenderCommandQueue, class_12075 cameraRenderState) {
        if (lecternBlockEntityRenderState.field_62727) {
            matrixStack.method_22903();
            matrixStack.method_46416(0.5F, 1.1625F, 0.5F);
            matrixStack.method_46416(0.0F, 0.0F, 0.0F);
            matrixStack.method_22907(class_7833.field_40716.rotationDegrees(-lecternBlockEntityRenderState.field_62728));
            matrixStack.method_22907(class_7833.field_40718.rotationDegrees(90F));
            matrixStack.method_22907(class_7833.field_40714.rotationDegrees(180F));
            matrixStack.method_46416(-0.15F, 0.0F, 0.0F);
            orderedRenderCommandQueue.method_73490(this.book, this.bookModelState, matrixStack, class_828.field_4369.method_24146(class_1921::method_23572), lecternBlockEntityRenderState.field_62676, class_4608.field_21444, -1, this.spriteHolder.method_73030(class_828.field_4369), 0, lecternBlockEntityRenderState.field_62677);
            matrixStack.method_22909();
        }
    }
}