package com.skniro.maple.block.init;

import com.mojang.serialization.MapCodec;
import com.skniro.maple.item.MapleFoodComponents;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5712;
import net.minecraft.class_5712.class_7397;
import net.minecraft.class_5819;
import net.minecraft.class_9062;

public class MapleTeaBlock extends class_2261 implements class_2256 {
    public static final MapCodec<MapleTeaBlock> CODEC = method_54094(MapleTeaBlock::new);
    private static final float field_31260 = 0.003F;
    public static final int MAX_AGE = 3;
    public static final class_2758 AGE;
    private static final class_265 SMALL_SHAPE;
    private static final class_265 LARGE_SHAPE;

    public MapleTeaBlock(class_2251 settings) {
        super(settings);
        this.method_9590((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(AGE, 0));
    }

    @Override
    protected MapCodec<? extends class_2261> method_53969() {
        return field_46280;
    }

    public class_1799 getPickStack(class_1922 world, class_2338 pos, class_2680 state) {
        return new class_1799(MapleFoodComponents.Green_Tea_Leaves);
    }

    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        if ((Integer)state.method_11654(AGE) == 0) {
            return SMALL_SHAPE;
        } else {
            return (Integer)state.method_11654(AGE) < 3 ? LARGE_SHAPE : super.method_9530(state, world, pos, context);
        }
    }

    public boolean method_9542(class_2680 state) {
        return (Integer)state.method_11654(AGE) < 3;
    }

    public void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        int i = (Integer)state.method_11654(AGE);
        if (i < 3 && random.method_43048(5) == 0 && world.method_22335(pos.method_10084(), 0) >= 9) {
            class_2680 blockState = (class_2680)state.method_11657(AGE, i + 1);
            world.method_8652(pos, blockState, 2);
            world.method_43276(class_5712.field_28733, pos, class_7397.method_43287(blockState));
        }

    }

    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        if (entity instanceof class_1309 && entity.method_5864() != class_1299.field_17943 && entity.method_5864() != class_1299.field_20346) {
            entity.method_5844(state, new class_243(0.800000011920929, 0.75, 0.800000011920929));
            if (!world.field_9236 && (Integer)state.method_11654(AGE) > 0 && (entity.field_6038 != entity.method_23317() || entity.field_5989 != entity.method_23321())) {
                double d = Math.abs(entity.method_23317() - entity.field_6038);
                double e = Math.abs(entity.method_23321() - entity.field_5989);
                if (d >= 0.003000000026077032 || e >= 0.003000000026077032) {
                    entity.method_5643(world.method_48963().method_48835(), 1.0F);
                }
            }

        }
    }

    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        int i = (Integer)state.method_11654(AGE);
        boolean bl = i == 3;
        if (i > 1) {
            int j = 1 + world.field_9229.method_43048(2);
            method_9577(world, pos, new class_1799(MapleFoodComponents.Green_Tea_Leaves, j + (bl ? 1 : 0)));
            world.method_8396((class_1657)null, pos, class_3417.field_17617, class_3419.field_15245, 1.0F, 0.8F + world.field_9229.method_43057() * 0.4F);
            class_2680 blockState = (class_2680)state.method_11657(AGE, 1);
            world.method_8652(pos, blockState, 2);
            world.method_43276(class_5712.field_28733, pos, class_7397.method_43286(player, blockState));
            return class_1269.method_29236(world.field_9236);
        } else {
            return super.method_55766(state, world, pos, player, hit);
        }
    }

    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        int i = (Integer)state.method_11654(AGE);
        boolean bl = i == 3;
        if (!bl && player.method_5998(hand).method_31574(class_1802.field_8324)) {
            return class_9062.field_47731;
        }
        return super.method_55765(stack,state, world, pos, player, hand, hit);
    }


    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{AGE});
    }

    public boolean isFertilizable(class_4538 world, class_2338 pos, class_2680 state, boolean isClient) {
        return (Integer)state.method_11654(AGE) < 3;
    }

    @Override
    public boolean method_9651(class_4538 world, class_2338 pos, class_2680 state) {
        return false;
    }

    public boolean method_9650(class_1937 world, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    public void method_9652(class_3218 world, class_5819 random, class_2338 pos, class_2680 state) {
        int i = Math.min(3, (Integer)state.method_11654(AGE) + 1);
        world.method_8652(pos, (class_2680)state.method_11657(AGE, i), 2);
    }

    static {
        AGE = class_2741.field_12497;
        SMALL_SHAPE = class_2248.method_9541(3.0, 0.0, 3.0, 13.0, 8.0, 13.0);
        LARGE_SHAPE = class_2248.method_9541(1.0, 0.0, 1.0, 15.0, 16.0, 15.0);
    }
}