package com.skniro.industrial_elixir.block.entity.machine.fluid;

import com.skniro.industrial_elixir.block.entity.machine.AbstractMachineEntity;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.item.init.FluidCellItem;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.machine.AbstractMachineCraftingRecipe;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.FullItemFluidStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.CombinedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public abstract class AbstractFluidMachineEntity extends AbstractMachineEntity {
    public static int FLUID_CRAFT_AMOUNT = 1000;
    public SingleVariantStorage<FluidVariant> fluidContainer = new SingleVariantStorage<FluidVariant>() {
        @Override
        protected FluidVariant getBlankVariant() {
            return FluidVariant.blank();
        }

        @Override
        protected long getCapacity(FluidVariant variant) {
            return (FluidConstants.BUCKET / 81) * 16; // 1 Bucket = 81000 Droplets = 1000mB || * 16 ==> 16,000mB = 16 Buckets
        }

        @Override
        protected void onFinalCommit() {
            method_31663(field_11863, method_11016(), method_11010());
            method_10997().method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    };

    public AbstractFluidMachineEntity(class_2591 entityType, class_2338 pos, class_2680 state) {
        super(entityType, pos, state);
    }

    public FluidVariant getFluid() {
        return this.fluidContainer.variant;
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if(world.method_8608()) {
            return;
        }

        charge(ENERGY_ITEM_SLOT);

        if (hasFluidStackInFluidSlot()) {
            fillUpFluidTank();
        }


        if(hasRecipe() && canInsertIntoOutputSlot()) {
            increaseCraftingProgress();
            useEnergyForCrafting();
            method_31663(world, pos, state);

            if (hasCraftingFinished()) {
                craftItem();
                extractFluidForCrafting();
                resetProgress();
            }

        } else {
            resetProgress();
        }

        boolean isWorking = hasRecipe() && hasEnoughEnergyToCraft() && hasEnoughFluidToCraft();
        if (state.method_11654(AbstractMachineblock.LIT) != isWorking) {
            world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, isWorking), 3);
        }
    }

    public boolean hasFluidStackInFluidSlot() {
        return FluidStorage.ITEM.find(inventory.get(FLUID_ITEM_SLOT), ContainerItemContext.withConstant(inventory.get(FLUID_ITEM_SLOT))) != null
                && FluidStorage.ITEM.find(inventory.get(FLUID_ITEM_SLOT), ContainerItemContext.withConstant(inventory.get(FLUID_ITEM_SLOT))).supportsExtraction()
                && FluidStorage.ITEM.find(inventory.get(FLUID_ITEM_SLOT), ContainerItemContext.withConstant(inventory.get(FLUID_ITEM_SLOT))) instanceof CombinedStorage<?, ?> combinedStorage
                && combinedStorage.parts.get(0) instanceof FullItemFluidStorage;
    }

    public void extractFluidForCrafting() {
        FluidVariant variant = fluidContainer.getResource();

        if (variant.isBlank()) {
            return;
        }

        if (fluidContainer.getAmount() < FLUID_CRAFT_AMOUNT) {
            return;
        }

        try (Transaction transaction = Transaction.openOuter()) {
            long extracted = fluidContainer.extract(variant, FLUID_CRAFT_AMOUNT, transaction
            );

            if (extracted == FLUID_CRAFT_AMOUNT) {
                transaction.commit();
            }
        }
    }

    public boolean hasRecipe() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> recipe = getCurrentRecipe();
        if(recipe.isEmpty()) {
            return false;
        }

        class_1799 output = recipe.get().comp_1933().output().method_7972();
        return canInsertAmountIntoOutputSlot(output.method_7947()) && canInsertItemIntoOutputSlot(output) && hasEnoughEnergyToCraft() && hasEnoughFluidToCraft();
    }

    public Optional<class_8786<AbstractMachineCraftingRecipe>> getCurrentRecipe() {
        return this.method_10997().method_8503().method_3772()
                .method_8132((class_3956<AbstractMachineCraftingRecipe>) getCurrentRecipeType(), new AlchemyCraftingRecipeInput(inventory.get(INPUT_SLOT)), this.method_10997());
    }

    public boolean hasEnoughFluidToCraft() {
        return fluidContainer.getAmount() >= FLUID_CRAFT_AMOUNT;
    }

    public void fillUpFluidTank() {
        class_1799 inputStack = inventory.get(FLUID_ITEM_SLOT);
        var itemStorage = FluidStorage.ITEM.find(inputStack, ContainerItemContext.withConstant(inputStack));
        if (itemStorage == null || !itemStorage.supportsExtraction()
                || !(itemStorage instanceof CombinedStorage<?, ?> combinedStorage)
                || !(combinedStorage.parts.get(0) instanceof FullItemFluidStorage fluidStorage)) {
            return;
        }

        class_1799 craftRemainder = inputStack.method_7909() instanceof FluidCellItem
                ? new class_1799(GrowableOresItems.EMPTY_CELL)
                : (inputStack.method_7909().method_7857()
                ? new class_1799(inputStack.method_7909().method_7858())
                : new class_1799(class_1802.field_8550));

        if (!canAcceptFluid(fluidStorage) || !canStoreCraftRemainder(inputStack, craftRemainder)) {
            return;
        }

        try (Transaction transaction = Transaction.openOuter()) {
            long inserted = this.fluidContainer.insert(fluidStorage.getResource(), 1000, transaction);
            if (inserted != 1000) {
                return;
            }

            if (inputStack.method_7909() instanceof FluidCellItem) {
                inputStack.method_7934(1);
                storeCraftRemainder(craftRemainder);
            } else {
                inventory.set(FLUID_ITEM_SLOT, craftRemainder);
            }
            transaction.commit();
        }
    }

    private boolean canAcceptFluid(FullItemFluidStorage fluidStorage) {
        return (fluidContainer.getResource() == fluidStorage.getResource() || fluidContainer.isResourceBlank())
                && fluidContainer.getAmount() + 1000 <= fluidContainer.getCapacity();
    }

    private boolean canStoreCraftRemainder(class_1799 inputStack, class_1799 craftRemainder) {
        if (!(inputStack.method_7909() instanceof FluidCellItem)) {
            return true;
        }

        class_1799 remainderSlot = inventory.get(EMPTY_FLUID_ITEM_SLOT);
        return remainderSlot.method_7960()
                || (class_1799.method_31577(remainderSlot, craftRemainder)
                && remainderSlot.method_7947() + craftRemainder.method_7947() <= remainderSlot.method_7914());
    }

    private void storeCraftRemainder(class_1799 craftRemainder) {
        class_1799 remainderSlot = inventory.get(EMPTY_FLUID_ITEM_SLOT);
        if (remainderSlot.method_7960()) {
            inventory.set(EMPTY_FLUID_ITEM_SLOT, craftRemainder.method_7972());
        } else {
            remainderSlot.method_7933(craftRemainder.method_7947());
        }
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_58692(registryLookup);
    }
}
