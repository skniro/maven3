package com.skniro.growable_ores_extension.block.init;

import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import net.minecraft.state.property.*;

public class LogCropBlock extends class_2248 {
    public static final class_2758 AGE;
    private static final class_265 SHAPE;
    public final class_1792 fruitItem;
    public static final class_2754<class_2350.class_2351> AXIS;

    public LogCropBlock(class_2251 settings, class_1792 fruitItem) {
        super(settings.method_22488());
        this.method_9590(this.field_10647.method_11664().method_11657(AXIS, class_2350.class_2351.field_11052).method_11657(AGE, 0));
        this.fruitItem = fruitItem;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
            return SHAPE;
    }

    public boolean method_9542(class_2680 state) {
        return (Integer)state.method_11654(AGE) < 2;
    }


    @Override
    public void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        int i = (Integer)state.method_11654(AGE);
        if (i < 2 && random.method_43048(40) == 0 && world.method_22335(pos.method_10084(), 0) >= 9) {
            class_2680 blockState = (class_2680)state.method_11657(AGE, i + 1);
            world.method_8652(pos, blockState, 2);
            world.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43287(blockState));
        }
    }


    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        int i = (Integer)state.method_11654(AGE);
        boolean bl = i == 2;
        if (i > 1) {
            int j = 1;
            method_9577(world, pos, new class_1799(fruitItem, j ));
            world.method_8396((class_1657)null, pos, class_3417.field_17617, class_3419.field_15245, 1.0F, 0.8F + world.field_9229.method_43057() * 0.4F);
            class_2680 blockState = (class_2680)state.method_11657(AGE, 0);
            world.method_8652(pos, blockState, 2);
            world.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43286(player, blockState));
            return class_1269.field_5812;
        } else {
            return super.method_55766(state, world, pos, player, hit);
        }
    }



    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{AGE, AXIS});
    }

    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return changeRotation(state, rotation);
    }

    public static class_2680 changeRotation(class_2680 state, class_2470 rotation) {
        switch (rotation) {
            case field_11465:
            case field_11463:
                switch ((class_2350.class_2351)state.method_11654(AXIS)) {
                    case field_11048 -> {
                        return (class_2680)state.method_11657(AXIS, class_2350.class_2351.field_11051);
                    }
                    case field_11051 -> {
                        return (class_2680)state.method_11657(AXIS, class_2350.class_2351.field_11048);
                    }
                    default -> {
                        return state;
                    }
                }
            default:
                return state;
        }
    }

    public boolean canGrow(class_1937 world, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    public void grow(class_3218 world, class_5819 random, class_2338 pos, class_2680 state) {
        int i = Math.min(2, (Integer)state.method_11654(AGE) + 1);
        world.method_8652(pos, (class_2680)state.method_11657(AGE, i), 2);
    }

    public class_2680 method_9605(class_1750 ctx) {
        return (class_2680)this.method_9564().method_11657(AXIS, ctx.method_8038().method_10166());
    }

    static {
        AGE = class_2741.field_12556;
        AXIS = class_2741.field_12496;
        SHAPE = class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
    }
}
