package com.skniro.industrial_elixir.block.init;


import com.mojang.serialization.MapCodec;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import com.skniro.industrial_elixir.ModContent;
import com.skniro.industrial_elixir.block.entity.cable.CableBlockEntity;
import com.skniro.industrial_elixir.block.entity.cable.CableElectrocutionEvent;
import com.skniro.industrial_elixir.init.ModDamageTypes;
import org.jetbrains.annotations.Nullable;

// CREDIT: https://github.com/techreborn/techreborn
// Under MIT-License: https://github.com/TechReborn/TechReborn/blob/26.1/LICENSE.md

public class CableBlock extends class_2237 implements class_3737 {
    public static final class_2746 EAST;
    public static final class_2746 WEST;
    public static final class_2746 NORTH;
    public static final class_2746 SOUTH;
    public static final class_2746 UP;
    public static final class_2746 DOWN;
    public static final class_2746 WATERLOGGED;
    public static final class_2746 COVERED;
    public static final Map<class_2350, class_2746> PROPERTY_MAP;
    public final ModContent.Cables type;

    public CableBlock(class_2251 settings,ModContent.Cables type, String name) {
        super(settings);
        this.type = type;
        this.method_9590((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)((class_2680)this.method_9595().method_11664()).method_11657(EAST, false)).method_11657(WEST, false)).method_11657(NORTH, false)).method_11657(SOUTH, false)).method_11657(UP, false)).method_11657(DOWN, false)).method_11657(WATERLOGGED, false)).method_11657(COVERED, false));
        //BlockWrenchEventHandler.wrenchableBlocks.add(this);
    }

    protected MapCodec<? extends class_2237> method_53969() {
        throw new IllegalStateException("CableBlock does not support getCodec!");
    }

    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new CableBlockEntity(pos, state, this.type);
    }

    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return (world1, pos, state1, blockEntity) -> ((CableBlockEntity)blockEntity).tick(world1, pos, state1, (CableBlockEntity)blockEntity);
    }

    public class_1269 method_55766(class_2680 state, class_1937 worldIn, class_2338 pos, class_1657 playerIn, class_3965 hitResult) {
        class_1799 stack = playerIn.method_5998(class_1268.field_5808);
        class_2586 blockEntity = worldIn.method_8321(pos);
        if (blockEntity == null) {
            return class_1269.field_5814;
        } else if (stack.method_7960()) {
            return super.method_55766(state, worldIn, pos, playerIn, hitResult);
        }
        return super.method_55766(state, worldIn, pos, playerIn, hitResult);

    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{EAST, WEST, NORTH, SOUTH, UP, DOWN, WATERLOGGED, COVERED});
    }

    public class_2680 method_9605(class_1750 context) {
        return (class_2680)this.method_9564().method_11657(WATERLOGGED, context.method_8045().method_8316(context.method_8037()).method_15772() == class_3612.field_15910);
    }

    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        if ((Boolean)state.method_11654(WATERLOGGED)) {
            world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
        }

        return state;
    }

    public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 block, class_2338 fromPos, boolean notify) {
        class_2586 var8 = world.method_8321(pos);
        if (var8 instanceof CableBlockEntity cable) {
            cable.neighborUpdate();
        }

        super.method_9612(state, world, pos, block, fromPos, notify);
    }

    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 shapeContext) {
        return (Boolean)state.method_11654(COVERED) ? class_259.method_1077() : CableShapeUtil.getShape(state);
    }

    public class_265 method_9571(class_2680 state, class_1922 world, class_2338 pos) {
        return CableShapeUtil.getShape(state);
    }

    protected void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        super.method_9548(state, world, pos, entity);
        if (this.type.canKill) {
            if (entity instanceof class_1309) {
                class_2586 blockEntity = world.method_8321(pos);
                if (blockEntity != null) {
                    if (blockEntity instanceof CableBlockEntity) {
                        CableBlockEntity blockEntityCable = (CableBlockEntity)blockEntity;
                        if (blockEntityCable.getEnergy() > 0L) {
                            if (((CableElectrocutionEvent)CableElectrocutionEvent.EVENT.invoker()).electrocute((class_1309)entity, this.type, pos, world, blockEntityCable)) {

                                if (this.type == ModContent.Cables.HV) {
                                    entity.method_5639(1.0F);
                                }

                                if (!world.method_8608()) {
                                    entity.method_5643(ModDamageTypes.create(world, ModDamageTypes.ELECTRIC_SHOCK), 1.0F);
                                }

                                blockEntityCable.setEnergy(0L);



                                //world.playSound((Entity)null, entity.getX(), entity.getY(), entity.getZ(), ModSounds.CABLE_SHOCK, SoundCategory.BLOCKS, 0.6F, 1.0F);



                                world.method_8406(class_2398.field_11205, entity.method_23317(), entity.method_23318(), entity.method_23321(), (double)0.0F, (double)0.0F, (double)0.0F);


                            }
                        }
                    }
                }
            }
        }
    }

    public boolean method_10311(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        return !(Boolean)state.method_11654(COVERED) && class_3737.super.method_10311(world, pos, state, fluidState);
    }

    public boolean method_10310(class_1657 player, class_1922 view, class_2338 pos, class_2680 state, class_3611 fluid) {
        return !(Boolean)state.method_11654(COVERED) && class_3737.super.method_10310(player, view, pos, state, fluid);
    }

    public class_3610 method_9545(class_2680 state) {
        return (Boolean)state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    static {
        EAST = class_2741.field_12487;
        WEST = class_2741.field_12527;
        NORTH = class_2741.field_12489;
        SOUTH = class_2741.field_12540;
        UP = class_2741.field_12519;
        DOWN = class_2741.field_12546;
        WATERLOGGED = class_2741.field_12508;
        COVERED = class_2746.method_11825("covered");
        PROPERTY_MAP = (Map) class_156.method_654(new HashMap(), (map) -> {
            map.put(class_2350.field_11034, EAST);
            map.put(class_2350.field_11039, WEST);
            map.put(class_2350.field_11043, NORTH);
            map.put(class_2350.field_11035, SOUTH);
            map.put(class_2350.field_11036, UP);
            map.put(class_2350.field_11033, DOWN);
        });
    }
}