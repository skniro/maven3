package com.skniro.growable_ores_extension.compat.display;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.growable_ores_extension.compat.category.MolecularTransformerCategory;
import com.skniro.growable_ores_extension.recipe.machine.MolecularTransformerCraftingRecipe;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2960;
import net.minecraft.class_8786;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import java.util.List;
import java.util.Optional;

public class MolecularTransformerDisplay extends BasicDisplay {
    private int count;
    private long energy;
    public static final DisplaySerializer<MolecularTransformerDisplay> SERIALIZER = DisplaySerializer.of(
            RecordCodecBuilder.mapCodec(instance -> instance.group(
                    EntryIngredient.codec().listOf().fieldOf("inputs").forGetter(MolecularTransformerDisplay::getInputEntries),
                    EntryIngredient.codec().listOf().fieldOf("outputs").forGetter(MolecularTransformerDisplay::getOutputEntries),
                    class_2960.field_25139.optionalFieldOf("location").forGetter(MolecularTransformerDisplay::getDisplayLocation),
                    Codec.INT.fieldOf("count").forGetter(MolecularTransformerDisplay::getCount),
                    Codec.LONG.fieldOf("energy").forGetter(MolecularTransformerDisplay::getEnergy)
            ).apply(instance, MolecularTransformerDisplay::new)),
            class_9139.method_56906(
                    EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
                    MolecularTransformerDisplay::getInputEntries,
                    EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
                    MolecularTransformerDisplay::getOutputEntries,
                    class_9135.method_56382(class_2960.field_48267),
                    MolecularTransformerDisplay::getDisplayLocation,
                    class_9135.field_49675,
                    MolecularTransformerDisplay::getCount,
                    class_9135.field_54505,
                    MolecularTransformerDisplay::getEnergy,
                    MolecularTransformerDisplay::new
            )
    );

    public MolecularTransformerDisplay(MolecularTransformerCraftingRecipe recipe) {
        this(List.of(EntryIngredients.ofIngredient(recipe.ingredient())),
                List.of(EntryIngredients.of(recipe.output())), Optional.empty(), recipe.requiredCount(), recipe.getEnergyRequired());
        this.count = recipe.requiredCount();
        this.energy = recipe.getEnergyRequired();
    }

    public MolecularTransformerDisplay(List<EntryIngredient> inputs, List<EntryIngredient> outputs, Optional<class_2960> location, int count, long energy) {
        super(inputs, outputs, location);
        this.count = count;
        this.energy = energy;
    }

    public MolecularTransformerDisplay(class_8786<MolecularTransformerCraftingRecipe> recipe){
        super(List.of(EntryIngredients.ofIngredient(recipe.comp_1933().ingredient())),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.comp_1933().output()))));
        this.count = recipe.comp_1933().requiredCount();
        this.energy = recipe.comp_1933().getEnergyRequired();
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return MolecularTransformerCategory.MolecularTransformer;
    }

    @Override
    public DisplaySerializer<? extends Display> getSerializer() {
        return SERIALIZER;
    }

    public int getCount() {
        return count;
    }

    public long getEnergy() {
        return energy;
    }
}