package com.skniro.growable_ores_extension.client.gui.screen.ingame.energybox;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.screen.EnergyBoxScreenHandler;
import com.skniro.growable_ores_extension.util.MouseUtil;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_10799;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.util.List;
import java.util.Optional;

public class EnergyBoxBlockScreen extends class_465<EnergyBoxScreenHandler> {
    private static final class_2960 GUI_TEXTURE =
            class_2960.method_60655(GrowableOresExtension.MOD_ID, "textures/gui/container/energybox/energy_box.png");

    public EnergyBoxBlockScreen(EnergyBoxScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        // Center title
        field_25267 = (field_22789 - field_2792) / 2;

    }

    public List<class_2561> getTooltips() {
        return List.of(class_2561.method_43470(field_2797.blockEntity.energyContainer.getSideStorage(null).getAmount()+" / "+ field_2797.blockEntity.energyContainer.getSideStorage(null).getCapacity()+" E"));
    }

    private void renderEnergyAreaTooltips(class_332 context, int pMouseX, int pMouseY, int x, int y) {
        if(isMouseAboveArea(pMouseX, pMouseY, x, y, 75, 34, 31, 16)) {
            context.method_64038(Screens.getTextRenderer(this), getTooltips(),
                    Optional.empty(), pMouseX - x, pMouseY - y);
        }
    }

    private void renderEnergyArea(class_332 context, int x, int y) {
        context.method_25290(class_10799.field_56883, GUI_TEXTURE, x + 79, y + 33, 176, 13, getScaledEnergyHeight(), 16,256,256);
    }

    public int getScaledEnergyHeight() {
        long energy = field_2797.blockEntity.energyContainer.amount;
        long capacity = field_2797.blockEntity.energyContainer.getCapacity();
        int energyBarSize = 31;

        return Math.toIntExact(capacity != 0 && energy != 0 ? energy * energyBarSize / capacity : 0);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        renderEnergyAreaTooltips(context, mouseX, mouseY, x, y);
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        context.method_25290(class_10799.field_56883, GUI_TEXTURE, x, y, 0, 0, field_2792, field_2779,256,256);

        renderEnergyArea(context, x, y);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }

    private boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, int width, int height) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, width, height);
    }
}