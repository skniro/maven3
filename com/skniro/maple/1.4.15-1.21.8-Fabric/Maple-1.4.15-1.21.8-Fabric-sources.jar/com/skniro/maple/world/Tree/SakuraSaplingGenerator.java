package com.skniro.maple.world.Tree;

import com.skniro.maple.world.feature.MapleConfiguredFeatures;
import java.util.Optional;
import net.minecraft.class_8813;

public class SakuraSaplingGenerator {
    public static final class_8813 SakuraSapling =
            new class_8813("sakuratreesapling", 0.1f, Optional.empty(),
                    Optional.empty(),
                    Optional.of(MapleConfiguredFeatures.SAKURA_TREE),
                    Optional.of(MapleConfiguredFeatures.MAGE_SAKURA_TREE),
                    Optional.empty(),
                    Optional.empty());
}