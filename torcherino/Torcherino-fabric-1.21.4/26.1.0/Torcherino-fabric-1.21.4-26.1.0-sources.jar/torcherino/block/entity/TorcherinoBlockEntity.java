package torcherino.block.entity;

import net.minecraft.class_1275;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3738;
import net.minecraft.class_5558;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import torcherino.api.Tier;
import torcherino.api.TierSupplier;
import torcherino.api.TorcherinoAPI;
import torcherino.config.Config;
import torcherino.platform.NetworkUtils;

public class TorcherinoBlockEntity extends class_2586 implements class_1275, TierSupplier {
    public static int randomTicks;
    private class_2561 customName;
    private int xRange, yRange, zRange, speed, redstoneMode;
    private Iterable<class_2338> area;
    private boolean active;
    private class_2960 tierID;
    private String uuid = "";

    public TorcherinoBlockEntity(class_2338 pos, class_2680 state) {
        super(class_7923.field_41181.method_10223(class_2960.method_60655("torcherino", "torcherino")).get().comp_349(), pos, state);
    }

    public static void tick(class_1937 level, class_2338 pos, class_2680 state, TorcherinoBlockEntity entity) {
        if (!entity.active || entity.speed == 0 || (entity.xRange == 0 && entity.yRange == 0 && entity.zRange == 0)) {
            return;
        }
        if (!Config.INSTANCE.online_mode.equals("") && !NetworkUtils.getInstance().s_isPlayerOnline(entity.getOwner())) {
            return;
        }
        // todo: get on load and then when updated
        if (level instanceof class_3218 serverlevel) {
            randomTicks = serverlevel.method_64395().method_8356(class_1928.field_19399);
        }
        entity.area.forEach(entity::tickBlock);
    }

    @Override
    public boolean method_16914() {
        return customName != null;
    }

    @Override
    public class_2561 method_5797() {
        return customName;
    }

    public void setCustomName(class_2561 name) {
        customName = name;
    }

    private String getOwner() {
        return uuid;
    }

    public void setOwner(String s) {
        uuid = s;
    }

    @Override
    public @NotNull class_2561 method_5477() {
        return method_16914() ? customName : class_2561.method_43471(method_11010().method_26204().method_63499());
    }

    @Override
    public void method_31662(@NotNull class_1937 level) {
        super.method_31662(level);
        if (!level.method_8608()) {
            level.method_8503().method_63588(new class_3738(level.method_8503().method_3780(), () -> method_11010().method_26181(level, field_11867, null, null, false)));
        }
    }

    private void tickBlock(class_2338 pos) {
        class_2680 blockState = field_11863.method_8320(pos);
        class_2248 block = blockState.method_26204();
        if (TorcherinoAPI.INSTANCE.isBlockBlacklisted(block)) {
            return;
        }
        if (field_11863 instanceof class_3218 && blockState.method_26229() && field_11863.method_54719().method_54751() &&
                field_11863.method_8409().method_43048(class_3532.method_15340(4096 / (speed * Config.INSTANCE.random_tick_rate), 1, 4096)) < randomTicks) {
            blockState.method_26199((class_3218) field_11863, pos, field_11863.method_8409());
        }
        if (!(block instanceof class_2343 entityBlock)) {
            return;
        }
        class_2586 blockEntity = field_11863.method_8321(pos);
        if (blockEntity != null) {
            //noinspection unchecked
            class_5558<class_2586> ticker = (class_5558<class_2586>) entityBlock.method_31645(field_11863, blockState, blockEntity.method_11017());
            if (blockEntity.method_11015() || TorcherinoAPI.INSTANCE.isBlockEntityBlacklisted(blockEntity.method_11017()) || ticker == null) {
                return;
            }
            for (int i = 0; i < speed; i++) {
                if (blockEntity.method_11015()) {
                    break;
                }
                ticker.tick(field_11863, pos, blockState, blockEntity);
            }
        }
    }

    public boolean readClientData(int xRange, int zRange, int yRange, int speed, int redstoneMode) {
        Tier tier = TorcherinoAPI.INSTANCE.getTiers().get(getTier());
        if (this.valueInRange(xRange, 0, tier.xzRange()) &&
                this.valueInRange(zRange, 0, tier.xzRange()) &&
                this.valueInRange(yRange, 0, tier.yRange()) &&
                this.valueInRange(speed, 0, tier.maxSpeed()) &&
                this.valueInRange(redstoneMode, 0, 3)) {
            this.xRange = xRange;
            this.zRange = zRange;
            this.yRange = yRange;
            this.speed = speed;
            this.redstoneMode = redstoneMode;
            area = class_2338.method_10094(field_11867.method_10263() - xRange, field_11867.method_10264() - yRange, field_11867.method_10260() - zRange,
                    field_11867.method_10263() + xRange, field_11867.method_10264() + yRange, field_11867.method_10260() + zRange);
            this.method_11010().method_26181(field_11863, field_11867, null, null, false);
            return true;
        }
        return false;
    }

    private boolean valueInRange(int value, int min, int max) {
        return value >= min && value <= max;
    }

    @Override
    public class_2960 getTier() {
        if (tierID == null) {
            class_2248 block = this.method_11010().method_26204();
            if (block instanceof TierSupplier supplier) {
                tierID = supplier.getTier();
            }
        }
        return tierID;
    }

    public void setPoweredByRedstone(boolean powered) {
        switch (redstoneMode) {
            case 0 -> active = !powered;
            case 1 -> active = powered;
            case 2 -> active = true;
            case 3 -> active = false;
        }
    }

    @Override
    public void method_11007(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11007(tag, provider);
        if (this.method_16914()) {
            tag.method_10582("CustomName", class_2561.class_2562.method_10867(method_5797(), provider));
        }
        tag.method_10569("XRange", xRange);
        tag.method_10569("ZRange", zRange);
        tag.method_10569("YRange", yRange);
        tag.method_10569("Speed", speed);
        tag.method_10569("RedstoneMode", redstoneMode);
        tag.method_10556("Active", active);
        tag.method_10582("Owner", getOwner() == null ? "" : getOwner());
    }

    @Override
    public void method_11014(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11014(tag, provider);
        if (tag.method_10573("CustomName", 8)) {
            this.setCustomName(class_2561.class_2562.method_10877(tag.method_10558("CustomName"), provider));
        }
        xRange = tag.method_10550("XRange");
        zRange = tag.method_10550("ZRange");
        yRange = tag.method_10550("YRange");
        speed = tag.method_10550("Speed");
        redstoneMode = tag.method_10550("RedstoneMode");
        active = tag.method_10577("Active");
        uuid = tag.method_10558("Owner");

        area = class_2338.method_10094(field_11867.method_10263() - xRange, field_11867.method_10264() - yRange, field_11867.method_10260() - zRange,
                field_11867.method_10263() + xRange, field_11867.method_10264() + yRange, field_11867.method_10260() + zRange);
    }

    public void openTorcherinoScreen(class_3222 player) {
        NetworkUtils.getInstance().s2c_openTorcherinoScreen(player, field_11867, this.method_5477(), xRange, zRange, yRange, speed, redstoneMode);
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

}
