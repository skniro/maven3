package com.skniro.usefulfood.block.init;

import com.skniro.usefulfood.block.init.candle.CandleAppleCakeBlock;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3489;
import net.minecraft.class_3965;
import net.minecraft.class_5544;
import net.minecraft.class_5712;

public class AppleCakeBlockState extends SpecialCakeBlockState {
    public AppleCakeBlockState(class_2251 settings, int foodlevel, float saturation) {
        super(settings, foodlevel, saturation);
    }


    @Override
    public class_1269 method_55765(class_1799 itemStack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_2248 block;
        class_1792 item = itemStack.method_7909();
        if (itemStack.method_31573(class_3489.field_26989) && state.method_11654(BITES) == 0 && (block = method_9503(item)) instanceof class_5544) {
            if (!player.method_7337()) {
                itemStack.method_7934(1);
            }
            world.method_8396(null, pos, class_3417.field_26947, class_3419.field_15245, 1.0f, 1.0f);
            world.method_8501(pos, CandleAppleCakeBlock.getCandleCakeFromCandle(block));
            world.method_33596((class_1297)player, class_5712.field_28733, pos);
            player.method_7259(class_3468.field_15372.method_14956(item));
            return class_1269.field_5812;
        } else {
            return class_1269.field_52423;
        }
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world.field_9236) {
            if (tryEat(world, pos, state, player).method_23665()) {
                return class_1269.field_5812;
            }
            if (player.method_5998(class_1268.field_5808).method_7960()) {
                return class_1269.field_21466;
            }
        }
        return tryEat(world, pos, state, player);
    }
}
