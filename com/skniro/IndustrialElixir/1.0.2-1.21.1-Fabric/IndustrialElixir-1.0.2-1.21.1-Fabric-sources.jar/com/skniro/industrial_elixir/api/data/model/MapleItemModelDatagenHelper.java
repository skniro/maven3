package com.skniro.industrial_elixir.api.data.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_4915;
import net.minecraft.class_4941;
import net.minecraft.class_4943;
import net.minecraft.class_4944;

public class MapleItemModelDatagenHelper {
    private final class_4915 generator;

    public MapleItemModelDatagenHelper(class_4915 generator) {
        this.generator = generator;
    }

    public final void registerDurabilityItem(class_1792 item) {
        // Generate the charge level models: <item>_0 (empty) .. <item>_4 (full).
        for (int i = 0; i <= 4; i++) {
            generator.method_25734(item, "_" + i, class_4943.field_22938);
        }

        class_2960 level0 = class_4941.method_25841(item, "_0");
        class_2960 level1 = class_4941.method_25841(item, "_1");
        class_2960 level2 = class_4941.method_25841(item, "_2");
        class_2960 level3 = class_4941.method_25841(item, "_3");
        class_2960 level4 = class_4941.method_25841(item, "_4");

        // The base model uses the full texture and switches to lower charge
        // models via durability-based overrides. The "damage" predicate is the
        // fraction of consumed durability (0.0 = full, 1.0 = empty).
        JsonObject root = new JsonObject();
        root.addProperty("parent", "minecraft:item/generated");

        JsonObject textures = new JsonObject();
        textures.addProperty("layer0", class_4944.method_25863(item, "_4").toString());
        root.add("textures", textures);

        JsonArray overrides = new JsonArray();
        overrides.add(createOverride(level0, 1.0F));
        overrides.add(createOverride(level1, 0.75F));
        overrides.add(createOverride(level2, 0.5F));
        overrides.add(createOverride(level3, 0.25F));
        root.add("overrides", overrides);

        generator.field_22844.accept(class_4941.method_25840(item), () -> root);
    }

    private static JsonObject createOverride(class_2960 model, float damage) {
        JsonObject override = new JsonObject();
        JsonObject predicate = new JsonObject();
        predicate.addProperty("damage", damage);
        override.add("predicate", predicate);
        override.addProperty("model", model.toString());
        return override;
    }
}
