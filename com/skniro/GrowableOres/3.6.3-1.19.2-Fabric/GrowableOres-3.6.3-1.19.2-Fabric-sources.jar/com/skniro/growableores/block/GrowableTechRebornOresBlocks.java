package com.skniro.growableores.block;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.init.GrowableOreCaneBlock;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3614;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import java.util.logging.Logger;

public class GrowableTechRebornOresBlocks {
    //TechReborn
    public static final class_2248 cinnabar_Cane =registerBlock("cinnabar_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 galena_Cane =registerBlock("galena_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 iridium_Cane =registerBlock("iridium_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 lead_Cane =registerBlock("lead_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 peridot_Cane =registerBlock("peridot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 pyrite_Cane =registerBlock("pyrite_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 ruby_Cane =registerBlock("ruby_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 sapphire_Cane =registerBlock("sapphire_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 sheldonite_Cane =registerBlock("sheldonite_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 silver_Cane =registerBlock("silver_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 sodalite_Cane =registerBlock("sodalite_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 sphalerite_Cane =registerBlock("sphalerite_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 tin_Cane =registerBlock("tin_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 tungsten_Cane =registerBlock("tungsten_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 bauxite_Cane =registerBlock("bauxite_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);


    private static class_2248 registerBlock(String name, class_2248 block, class_1761 tab) {
        registerBlockItem(name, block, tab);
        return class_2378.method_10230(class_2378.field_11146, new class_2960(GrowableOres.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_1761 tab) {
        return class_2378.method_10230(class_2378.field_11142, new class_2960(GrowableOres.MOD_ID, name),
                new class_1747(block, new FabricItemSettings().method_7892(tab)));
    }
    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + GrowableOres.MOD_ID);
    }
}

