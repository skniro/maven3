package com.skniro.growableores.datagen;

import com.skniro.growableores.GrowableOres;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_7923;


public class GrowableModelProvider extends FabricModelProvider {
    public GrowableModelProvider(FabricDataOutput dataGenerator){
        super(dataGenerator);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        class_7923.field_41175.forEach(block -> {
            class_2960 blockId = class_7923.field_41175.method_10221(block);
            if (blockId.method_12836().equals(GrowableOres.MOD_ID)) {
                blockStateModelGenerator.method_25548(block, class_4910.class_4913.field_22839);
            }
        });
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {

    }
}
