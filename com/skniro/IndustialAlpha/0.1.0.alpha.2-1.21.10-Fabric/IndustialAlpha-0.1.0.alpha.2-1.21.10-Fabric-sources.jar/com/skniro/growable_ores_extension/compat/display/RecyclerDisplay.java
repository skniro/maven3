package com.skniro.growable_ores_extension.compat.display;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.compat.category.RecyclerCategory;
import com.skniro.growable_ores_extension.recipe.machine.RecyclerCraftingRecipe;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RecyclerDisplay extends BasicDisplay {
    private int count;

    public static final CategoryIdentifier<RecyclerDisplay> Recycler =
            CategoryIdentifier.of(GrowableOresExtension.MOD_ID, "recycler");

    public static final DisplaySerializer<RecyclerDisplay> SERIALIZER = DisplaySerializer.of(
            RecordCodecBuilder.mapCodec(instance -> instance.group(
                    EntryIngredient.codec().listOf().fieldOf("outputs").forGetter(BasicDisplay::getOutputEntries),
                    class_2960.field_25139.optionalFieldOf("location").forGetter(BasicDisplay::getDisplayLocation)
            ).apply(instance, RecyclerDisplay::new)),
            class_9139.method_56435(
                    EntryIngredient.streamCodec().method_56433(class_9135.method_56363()),
                    BasicDisplay::getOutputEntries,
                    class_9135.method_56382(class_2960.field_48267),
                    BasicDisplay::getDisplayLocation,
                    RecyclerDisplay::new
            )
    );

    public RecyclerDisplay(RecyclerCraftingRecipe recipe) {
        super(List.of(EntryIngredients.ofItemStacks(getAllItems())),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.output()))));
    }

    public RecyclerDisplay(List<EntryIngredient> outputs, Optional<class_2960> location) {
        super(List.of(EntryIngredients.ofItemStacks(getAllItems())), outputs, location);
    }

    public RecyclerDisplay(class_8786<RecyclerCraftingRecipe> recipe){
        super(List.of(EntryIngredients.ofItemStacks(getAllItems())),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.comp_1933().output()))));
    }

    private static List<class_1799> getAllItems() {
        List<class_1799> list = new ArrayList<>();
        for (class_1792 item : class_7923.field_41178) {
            list.add(new class_1799(item));
        }
        return list;
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return RecyclerDisplay.Recycler;
    }

    @Override
    public DisplaySerializer<? extends Display> getSerializer() {
        return SERIALIZER;
    }
}