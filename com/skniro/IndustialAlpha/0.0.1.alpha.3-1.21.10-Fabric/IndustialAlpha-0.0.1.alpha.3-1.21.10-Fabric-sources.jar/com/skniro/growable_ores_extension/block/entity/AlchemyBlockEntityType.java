package com.skniro.growable_ores_extension.block.entity;

import com.mojang.datafixers.types.Type;
import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.entity.cable.CableBlockEntity;
import com.skniro.growable_ores_extension.block.entity.generator.CoalGeneratorBlockEntity;
import com.skniro.growable_ores_extension.block.entity.generator.GeneratorWindMillBlockEntity;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_1208;
import net.minecraft.class_156;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;


public class AlchemyBlockEntityType {
    public static final class_2591<Alchemyblockentity> ALCHEMY_BLOCK_ENTITY;
    public static final class_2591<CableBlockEntity> CABLE;
    public static final class_2591<CoalGeneratorBlockEntity> COAL_GENERATOR_BE;
    public static final class_2591<MaceratorEntity> Macerator_BLOCK_ENTITY;
    public static final class_2591<GeneratorWindMillBlockEntity> GENERATOR_WIND_MILL_BLOCK_ENTITY;

    static {
        ALCHEMY_BLOCK_ENTITY = create("alchemy_block", FabricBlockEntityTypeBuilder.create(Alchemyblockentity::new, GrowableOresBlocks.GrowableOres_Block));
        CABLE = create("cable", FabricBlockEntityTypeBuilder.create(CableBlockEntity::new , GrowableOresBlocks.Cable_Block));
        COAL_GENERATOR_BE = create("coal_generator_be", FabricBlockEntityTypeBuilder.create(CoalGeneratorBlockEntity::new , GrowableOresBlocks.COAL_GENERATOR));
        Macerator_BLOCK_ENTITY = create("macerator_block", FabricBlockEntityTypeBuilder.create(MaceratorEntity::new, GrowableOresBlocks.Macerator_Block));
        GENERATOR_WIND_MILL_BLOCK_ENTITY = create("generator_wind_mill_be", FabricBlockEntityTypeBuilder.create(GeneratorWindMillBlockEntity::new, GrowableOresBlocks.GENERATOR_Wind_Mill));
    }



    private static <T extends class_2586> class_2591 create(String id, FabricBlockEntityTypeBuilder<T> builder) {
        Type<?> type = class_156.method_29187(class_1208.field_5727, id);
        return (class_2591) class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(GrowableOresExtension.MOD_ID,id), builder.build(null));
    }

    public static void registerMachineEnergyEntity() {
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), ALCHEMY_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), COAL_GENERATOR_BE);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), Macerator_BLOCK_ENTITY);
        EnergyStorage.SIDED.registerForBlockEntity((blockEntity, direction) -> blockEntity.energyContainer.getSideStorage(direction), GENERATOR_WIND_MILL_BLOCK_ENTITY);
    }

    public static void registerMapleBlockEntityType() {
        GrowableOresExtension.LOGGER.debug("Registering MapleBlockEntityType for " + GrowableOresExtension.MOD_ID);
    }

}
