package com.skniro.industrial_elixir.block.entity.machine;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.machine.AbstractMachineCraftingRecipe;
import com.skniro.industrial_elixir.recipe.machine.CropFarmCraftingRecipe;
import com.skniro.industrial_elixir.screen.handler.machine.CropFarmScreenHandler;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3956;
import net.minecraft.class_8786;

public class CropFarmBlockEntity extends AbstractMachineEntity {

    public CropFarmBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.CROP_FARM_BLOCK_ENTITY, pos, state);
        this.inventory = class_2371.method_10213(12, class_1799.field_8037);
    }

    // 200/20 = 10 EU/t
    @Override
    public long getCraftEnergyCost() {
        return 200;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.CropFarm);
    }

    @Override
    public @Nullable class_1703 createMenu(int syncId, class_1661 inventory, class_1657 player) {
        return new CropFarmScreenHandler(syncId, inventory, this, propertyDelegate);
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return AlchemyRecipeType.CROP_FARM.type;
    }

    @Override
    public Optional<class_8786<AbstractMachineCraftingRecipe>> getCurrentRecipe() {
        return this.method_10997().method_8503().method_3772()
                .method_8132((class_3956<AbstractMachineCraftingRecipe>) getCurrentRecipeType(),
                        new AlchemyCraftingRecipeInput(inventory.get(INPUT_SLOT)), this.method_10997());
    }

    @Override
    public boolean hasRecipe() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> opt = getCurrentRecipe();
        if (opt.isEmpty()) return false;

        var recipeHolder = opt.get();
        var recipe = recipeHolder.comp_1933();
        CropFarmCraftingRecipe cropRecipe = (CropFarmCraftingRecipe) recipe;

        // Set maxProgress from the recipe
        this.maxProgress = cropRecipe.processTime();

        class_1799 output = cropRecipe.output().method_7972();
        if (!canInsertIntoSlot(OUTPUT_SLOT, output)) return false;

        if (cropRecipe.output2().isPresent() && !canInsertIntoSlot(OUTPUT_SLOT_2, cropRecipe.output2().get().method_7972())) return false;
        if (cropRecipe.output3().isPresent() && !canInsertIntoSlot(OUTPUT_SLOT_3, cropRecipe.output3().get().method_7972())) return false;

        return true;
    }

    @Override
    protected boolean hasEnoughEnergyToCraft() {
        long baseUse = getCraftEnergyCost() / 20;
        long effectiveUse = (long)(baseUse * getEnergyDemandMultiplier());
        return this.energyContainer.amount >= effectiveUse;
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) return;

        charge(ENERGY_ITEM_SLOT);

        boolean hasInput = hasRecipe();
        boolean hasEnergy = hasEnoughEnergyToCraft();
        boolean canOutput = canInsertIntoOutputSlot();

        if (hasInput && hasEnergy && canOutput) {
            increaseCraftingProgress();
            useEnergyForCrafting();
            method_31663(world, pos, state);

            if (hasCraftingFinished()) {
                craftItem();
                resetProgress();
            }
        } else if (!hasInput || !canOutput) {
            resetProgress();
        }

        boolean isWorking = hasInput && hasEnergy;
        if (state.method_11654(AbstractMachineblock.LIT) != isWorking) {
            world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, isWorking), 3);
        }
    }

    @Override
    protected void craftItem() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> recipe = getCurrentRecipe();
        if (recipe.isEmpty()) return;

        CropFarmCraftingRecipe cropRecipe = (CropFarmCraftingRecipe) recipe.get().comp_1933();

        method_5431();

        insertOutput(OUTPUT_SLOT, cropRecipe.output().method_7972());
        cropRecipe.output2().ifPresent(output -> insertOutput(OUTPUT_SLOT_2, output.method_7972()));
        cropRecipe.output3().ifPresent(output -> insertOutput(OUTPUT_SLOT_3, output.method_7972()));
    }

    private void insertOutput(int slot, class_1799 output) {
        if (output.method_7960()) return;
        if (this.method_5438(slot).method_7960()) {
            this.method_5447(slot, output.method_7972());
        } else {
            this.method_5438(slot).method_7933(output.method_7947());
        }
    }

    private boolean canInsertIntoSlot(int slot, class_1799 output) {
        if (output.method_7960()) return true;
        class_1799 stack = this.method_5438(slot);
        int maxCount = stack.method_7960() ? output.method_7914() : stack.method_7914();
        return (stack.method_7960() || class_1799.method_31577(stack, output))
                && maxCount >= stack.method_7947() + output.method_7947();
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return slot != OUTPUT_SLOT && slot != OUTPUT_SLOT_2 && slot != OUTPUT_SLOT_3;
    }

    /* SIDED INVENTORY */
    @Override
    public int[] method_5494(class_2350 direction) {
        if (direction != class_2350.field_11033) {
            return new int[]{INPUT_SLOT, ENERGY_ITEM_SLOT};
        } else {
            return new int[]{OUTPUT_SLOT, OUTPUT_SLOT_2, OUTPUT_SLOT_3};
        }
    }
}
