package com.skniro.industrial_elixir.api.item.replicator;

import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

/**
 * Registry for per-item energy and UU matter costs used by the Pattern Storage scanner
 * and Replicator. Each entry maps an Item to its replication cost.
 * <p>
 * Call {@link #register(class_1792, int, long)} to add or override cost values.
 * The map is queried by {@link com.skniro.industrial_elixir.block.entity.machine.PatternStorageBlockEntity}
 * when scanning items.
 */
public class ReplicatorValueMap {
    private static final Map<class_1792, ReplicatorCost> COSTS = new HashMap<>();

    /**
     * Register a custom replication cost for an item.
     *
     * @param item       the item to register
     * @param uuCost     UU matter cost in mB per replication
     * @param energyCost energy cost in EU per replication
     */
    public static void register(class_1792 item, int uuCost, long energyCost) {
        COSTS.put(item, new ReplicatorCost(uuCost, energyCost));
    }

    /**
     * Get the registered replication cost for an item, or null if not registered.
     */
    public static ReplicatorCost get(class_1792 item) {
        return COSTS.get(item);
    }

    /**
     * Check if an item has a registered replication cost.
     */
    public static boolean contains(class_1792 item) {
        return COSTS.containsKey(item);
    }

    /**
     * Get an unmodifiable view of all registered costs.
     */
    public static Map<class_1792, ReplicatorCost> getAll() {
        return Collections.unmodifiableMap(COSTS);
    }

    /**
     * Register default vanilla item costs.
     * Called during mod initialization.
     */
    public static void registerDefaults() {
        // --- Common resources ---
        register(class_1802.field_8831, 0,7000);
        register(class_1802.field_20412, 0, 500);
        register(class_1802.field_20391, 0, 6000);
        register(class_1802.field_8858, 0, 7000);
        register(class_1802.field_8110, 0, 15000);
        register(class_1802.field_8270, 26, 0);
        register(class_1802.field_8280, 0, 10000);
        // --- Wood ---
        register(class_1802.field_8118, 12, 0);
        register(class_1802.field_8113, 12, 0);
        register(class_1802.field_8191, 12, 0);
        register(class_1802.field_8842, 12, 0);
        register(class_1802.field_8651, 12, 0);
        register(class_1802.field_8404, 12, 0);
        register(class_1802.field_37507, 12, 0);
        register(class_1802.field_42687, 12, 0);
        register(class_1802.field_40213, 12, 0);
        register(class_1802.field_22031, 12, 0);
        register(class_1802.field_22032, 12, 0);
        register(class_1802.field_8684, 44, 0);
        register(class_1802.field_8170, 44, 0);
        register(class_1802.field_8125, 44, 0);
        register(class_1802.field_8820, 44, 0);
        register(class_1802.field_8652, 44, 0);
        register(class_1802.field_37512, 44, 0);
        register(class_1802.field_42692, 44, 0);
        register(class_1802.field_21981, 44, 0);
        register(class_1802.field_21982, 44, 0);
        register(class_1802.field_17535, 80, 0);
        register(class_1802.field_17536, 80, 0);
        register(class_1802.field_17537, 80, 0);
        register(class_1802.field_17538, 80, 0);
        register(class_1802.field_17539, 80, 0);
        register(class_1802.field_17540, 80, 0);
        register(class_1802.field_37508, 80, 0);
        register(class_1802.field_42688, 80, 0);
        register(class_1802.field_21987, 80, 0);
        register(class_1802.field_21988, 80, 0);

        register(class_1802.field_8491, 370, 0);
        register(class_1802.field_8880, 370, 0);
        register(class_1802.field_17499, 370, 0);
        register(class_1802.field_17500, 370, 0);
        register(class_1802.field_17501, 370, 0);
        register(class_1802.field_17502, 370, 0);
        register(class_1802.field_17509, 370, 0);
        register(class_1802.field_17510, 370, 0);
        register(class_1802.field_17511, 370, 0);
        register(class_1802.field_17512, 370, 0);
        register(class_1802.field_17513, 370, 0);
        register(class_1802.field_17514, 370, 0);
        register(class_1802.field_17515, 370, 0);
        register(class_1802.field_42695, 370, 0);

        register(class_1802.field_17525, 370, 0);
        register(class_1802.field_17526, 370, 0);
        register(class_1802.field_17527, 370, 0);
        register(class_1802.field_17529, 370, 0);

        register(class_1802.field_42696, 370, 0);

        // --- Ores ---
        register(class_1802.field_8713, 0, 50000);
        register(class_1802.field_8599, 1, 0);
        register(class_1802.field_8775, 10, 0);
        register(class_1802.field_27018, 5, 0);
        register(class_1802.field_8477, 24, 0);
        register(class_1802.field_8603, 216, 0);
        register(class_1802.field_8687, 40, 0);
        register(class_1802.field_8759, 8, 0);
        register(class_1802.field_8055, 68, 0);
        register(class_1802.field_8725, 2, 0);
        register(class_1802.field_8793, 11, 0);
        register(class_1802.field_8155, 2, 0);
        register(class_1802.field_22020, 400, 0);
        register(class_1802.field_22021, 150, 0);
        register(class_1802.field_22019, 100, 0);
        register(class_1802.field_8797, 0, 400000);

        register(class_1802.field_8620, 2, 0);
        register(class_1802.field_8675, 0, 0);
        register(class_1802.field_8773, 18, 0);
        register(class_1802.field_33400, 1, 0);
        register(class_1802.field_33505, 9, 0);
        register(class_1802.field_8599, 1, 0);
        register(class_1802.field_29020, 2, 0);

        register(class_1802.field_8695, 20, 0);
        register(class_1802.field_8397, 2, 0);
        register(class_1802.field_8494, 180, 0);
        register(class_1802.field_33402, 10, 0);
        register(class_1802.field_33507, 90, 0);
        register(class_1802.field_29019, 20, 0);
        register(class_1802.field_23140, 5, 0);

        register(class_1802.field_27022, 10, 0);
        register(class_1802.field_27071, 90, 0);
        register(class_1802.field_33401, 5, 0);
        register(class_1802.field_33506, 45, 0);
        register(class_1802.field_29211, 10, 0);

        register(class_1802.field_29212, 0, 80000);

        register(class_1802.field_29022, 48, 0);

        register(class_1802.field_8733, 360, 0);
        register(class_1802.field_29216, 80, 0);

        register(class_1802.field_29021, 136, 0);

        register(class_1802.field_29023, 4, 0);

        register(class_1802.field_20402, 8, 0);
        register(class_1802.field_20386, 8, 0);
        register(class_1802.field_8430, 6, 0);
        register(class_1802.field_8217, 4, 0);
        register(class_1802.field_8084, 8, 0);
        register(class_1802.field_23830, 8, 0);
        register(class_1802.field_8746, 8, 0);

        register(class_1802.field_27063, 32, 0);
        register(class_1802.field_27064, 128, 0);
        register(class_1802.field_27065, 0, 5000000);
        register(class_1802.field_27066, 40, 0);
        register(class_1802.field_27067, 64, 0);
        register(class_1802.field_27068, 96, 0);
        register(class_1802.field_27069, 128, 0);

        register(class_1802.field_8434, 24, 0);
        register(class_1802.field_8662, 12, 0);

        register(class_1802.field_38746, 0, 3000000);


        // --- Food ---
        register(class_1802.field_8279, 10, 0);
        register(class_1802.field_8229, 20, 0);
        register(class_1802.field_8176, 40, 0);
        register(class_1802.field_8463, 180, 0);
        register(class_1802.field_8367, 288, 0);

        // 生肉
        register(class_1802.field_8046, 20, 0);
        register(class_1802.field_8389, 16, 0);
        register(class_1802.field_8726, 12, 0);
        register(class_1802.field_8748, 14, 0);
        register(class_1802.field_8504, 12, 0);
        register(class_1802.field_8429, 12, 0);
        register(class_1802.field_8209, 14, 0);
        register(class_1802.field_8846, 16, 0);
        register(class_1802.field_8323, 20, 0);

// 熟肉
        register(class_1802.field_8261, 32, 0);
        register(class_1802.field_8544, 24, 0);
        register(class_1802.field_8347, 28, 0);
        register(class_1802.field_8752, 24, 0);
        register(class_1802.field_8373, 24, 0);
        register(class_1802.field_8509, 28, 0);

// 蔬菜水果
        register(class_1802.field_8567, 8, 0);
        register(class_1802.field_8512, 18, 0);
        register(class_1802.field_8635, 4, 0);
        register(class_1802.field_8179, 8, 0);
        register(class_1802.field_8071, 120, 0);
        register(class_1802.field_8186, 6, 0);
        register(class_1802.field_8497, 4, 0);
        register(class_1802.field_16998, 6, 0);
        register(class_1802.field_28659, 8, 0);
        register(class_1802.field_8233, 40, 0);

// 作物
        register(class_1802.field_8861, 8, 0);
        register(class_1802.field_8551, 4, 0);
        register(class_1802.field_17532, 2, 0);

// 汤和炖菜
        register(class_1802.field_8208, 40, 0);
        register(class_1802.field_8515, 36, 0);
        register(class_1802.field_8308, 80, 0);
        register(class_1802.field_8766, 120, 0);

// 点心
        register(class_1802.field_8423, 8, 0);
        register(class_1802.field_17534, 120, 0);
        register(class_1802.field_8741, 48, 0);

// 蜂蜜
        register(class_1802.field_20417, 24, 0);
        register(class_1802.field_20414, 16, 0);

// 其他
        register(class_1802.field_8511, 2, 0);
        register(class_1802.field_8680, 8, 0);

// 种子（可食用）
        register(class_1802.field_46250, 2, 0);
        register(class_1802.field_46249, 2, 0);

        register(GrowableOresItems.IRIDIUM_SHARD, 13, 0);
        register(GrowableOresItems.IRIDIUM_ORE, 120, 0);
        register(GrowableOresItems.IRIDIUM_PLATE, 520, 0);

        register(GrowableOresItems.IMPURE_SACRED_STONE, 31, 0);

        register(class_1802.field_8777, 133, 0);


        register(class_1792.method_7867(GrowableOresBlocks.MFSU), 11630, 0);;

        register(class_1802.field_8407, 3074, 0);

        register(GrowableOresItems.Scrap, 1, 0);;

        register(GrowableOresItems.Sticky_Resin, 6331, 0);
        register(GrowableOresItems.Rubber, 101, 0);
        register(class_1792.method_7867(GeneralBlocks.Rubber_SAPLING), 3572, 0);

        register(GrowableOresItems.Raw_SACRED, 16, 0);

        register(GrowableOresItems.SACRED_ESSENCE, 98, 0);


        // --- Obsidian / Bedrock ---
        register(class_1802.field_8281, 64, 0);
        register(class_1802.field_22421, 96, 0);
        register(class_1802.field_23141, 768, 0);
        register(class_1802.field_8301, 256, 0);
        register(class_1802.field_8466, 320, 0);

        // --- Nether ---
        register(class_1802.field_8894, 64, 300000);
        register(class_1802.field_8183, 32, 0);

        register(class_1802.field_8070, 256, 1200000);

        register(class_1802.field_8790, 24, 0);

        register(class_1802.field_8135, 534, 0);
        register(class_1802.field_8354, 384, 0);

        register(class_1802.field_8601, 39, 0);
        register(class_1802.field_8801, 159, 0);

        register(class_1802.field_22017, 64, 0);

        register(class_1802.field_8067, 12, 0);
        register(class_1802.field_21999, 8, 0);

        register(class_1802.field_23843, 4, 0);
        register(class_1802.field_23847, 32, 500000);

        register(class_1802.field_21989, 8, 0);
        register(class_1802.field_21990, 8, 0);

        register(class_1802.field_21991, 4, 0);
        register(class_1802.field_21992, 8, 0);
        register(class_1802.field_23070, 8, 0);

        // --- The End ---
        register(class_1802.field_8634, 64, 300000);
        register(class_1802.field_8449, 96, 0);

        register(class_1802.field_20399, 8, 0);
        register(class_1802.field_20400, 32, 0);

        register(class_1802.field_8882, 32, 0);

        register(class_1802.field_8710, 48, 0);
        register(class_1802.field_8358, 24, 0);

        register(class_1802.field_20393, 128, 0);
        register(class_1802.field_8490, 128, 0);
        register(class_1802.field_8644, 96, 0);
        register(class_1802.field_8202, 64, 0);

        register(class_1802.field_8815, 256, 1200000);
        register(class_1802.field_8545, 576, 0);

        register(class_1802.field_8613, 50, 800000);

        register(class_1802.field_8833, 30, 8000000);

        register(class_1802.field_8712, 200, 15000000);
        register(class_1802.field_8840, 1000, 50000000);

        register(class_1802.field_8056, 80, 0);
    }
}
