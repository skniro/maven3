package com.skniro.growable_ores_extension.init;

public class FurnitureStrings {
    public static final String Macerator = "gui.growable_ores_extension.macerator";
    public static final String CaneConverter = "gui.growableores.cane_converter";
    public static final String GeneratorWindMill = "gui.growableores.generator_wind_mill";
    public static final String Compressor = "gui.growable_ores_extension.compressor";
    public static final String MetalFormer = "gui.growable_ores_extension.metal_former";
    public static final String Extractor = "gui.growable_ores_extension.extractor";
    public static final String Charge_Pad = "gui.growable_ores_extension.charge_pad";
    public static final String Charge_Pad_CESU = "gui.growable_ores_extension.charge_pad_cesu";
    public static final String Charge_Pad_MFE = "gui.growable_ores_extension.charge_pad_mfe";
    public static final String Charge_Pad_MFSU = "gui.growable_ores_extension.charge_pad_mfsu";
    public static final String Energy_Box = "gui.growable_ores_extension.energy_box";
    public static final String Energy_Box_CESU = "gui.growable_ores_extension.energy_box_cesu";
    public static final String Energy_Box_MFE = "gui.growable_ores_extension.energy_box_mfe";
    public static final String Energy_Box_MFSU = "gui.growable_ores_extension.energy_box_mfsu";
}
