package com.skniro.maple.datagen;

import com.skniro.maple.Maple;
import com.skniro.maple.block.MapleBlocks;
import com.skniro.maple.block.MapleOreBlocks;
import com.skniro.maple.block.MapleSignBlocks;
import com.skniro.maple.item.MapleArmorItems;
import com.skniro.maple.item.MapleItems;
import com.skniro.maple.tag.MapleItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

import static com.skniro.maple.datagen.MapleItemTagGeneration.ModItemTags.C_CHERRY_LOGS;
import static net.minecraft.class_3489.*;


public class MapleItemTagGeneration extends FabricTagProvider.ItemTagProvider{
    public MapleItemTagGeneration(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(dataGenerator, completableFuture);
    }

    public static class ModItemTags {
        public static final class_6862<class_1792> C_SAPLING = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "saplings"));
        public static final class_6862<class_1792> C_MAPLE_LOGS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "maple_logs"));
        public static final class_6862<class_1792> C_CHERRY_LOGS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "cherry_logs"));
        public static final class_6862<class_1792> MAPLE_LOGS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(Maple.MOD_ID, "maple_logs"));
        public static final class_6862<class_1792> GINKGO_LOGS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(Maple.MOD_ID, "ginkgo_logs"));
        // minecraft namespace tags used by the game that we need to extend
        public static final class_6862<class_1792> NEEDS_IRON_TOOL_ITEM = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("minecraft", "needs_iron_tool"));
        public static final class_6862<class_1792> LOGS_THAT_BURN_ITEM = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("minecraft", "logs_that_burn"));
        public static final class_6862<class_1792> STANDING_SIGNS_ITEM = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("minecraft", "standing_signs"));
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        valueLookupBuilder(MapleItemTags.REPAIRS_CHERRY_ARMOR)
                .method_71554(MapleArmorItems.Cherry_INGOT);
        valueLookupBuilder(MapleItemTags.CHERRY_TOOL_MATERIALS)
                .method_71554(MapleArmorItems.Cherry_INGOT);
        valueLookupBuilder(field_15558)
                .method_71554(class_1792.method_7867(MapleBlocks.MAPLE_LEAVES))
                .method_71554(class_1792.method_7867(MapleBlocks.GINKGO_LEAVES))
                .method_71554(class_1792.method_7867(MapleBlocks.SAKURA_LEAVES))
                .method_71554(class_1792.method_7867(MapleBlocks.RED_MAPLE_LEAVES));
        valueLookupBuilder(ModItemTags.MAPLE_LOGS)
                .method_71554(class_1792.method_7867(MapleBlocks.MAPLE_LOG))
                .method_71554(class_1792.method_7867(MapleBlocks.MAPLE_WOOD))
                .method_71554(class_1792.method_7867(MapleBlocks.STRIPPED_MAPLE_LOG))
                .method_71554(class_1792.method_7867(MapleBlocks.STRIPPED_MAPLE_WOOD));
        valueLookupBuilder(ModItemTags.GINKGO_LOGS)
                .method_71554(class_1792.method_7867(MapleBlocks.GINKGO_LOG))
                .method_71554(class_1792.method_7867(MapleBlocks.GINKGO_WOOD))
                .method_71554(class_1792.method_7867(MapleBlocks.STRIPPED_GINKGO_LOG))
                .method_71554(class_1792.method_7867(MapleBlocks.STRIPPED_GINKGO_WOOD));
        valueLookupBuilder(field_15528)
                .method_71554(class_1792.method_7867(MapleBlocks.MAPLE_SAPLING))
                .method_71554(class_1792.method_7867(MapleBlocks.CHERRY_SAPLING))
                .method_71554(class_1792.method_7867(MapleBlocks.GINKGO_SAPLING))
                .method_71554(class_1792.method_7867(MapleBlocks.SAKURA_SAPLING))
                .method_71554(class_1792.method_7867(MapleBlocks.RED_MAPLE_SAPLING))
                .setReplace(false);
        valueLookupBuilder(C_CHERRY_LOGS)
                .method_71554(class_1792.method_7867(MapleBlocks.CHERRY_LOG));
        valueLookupBuilder(class_3489.field_41890)
                .method_71558(MapleArmorItems.Cherry_HELMET, MapleArmorItems.Cherry_CHESTPLATE, MapleArmorItems.Cherry_LEGGINGS, MapleArmorItems.Cherry_BOOTS)
                .setReplace(false);
        valueLookupBuilder(field_48294)
                .method_71554(MapleArmorItems.Cherry_BOOTS)
                .setReplace(false);
        valueLookupBuilder(field_48295)
                .method_71554(MapleArmorItems.Cherry_LEGGINGS)
                .setReplace(false);
        valueLookupBuilder(field_48296)
                .method_71554(MapleArmorItems.Cherry_CHESTPLATE)
                .setReplace(false);
        valueLookupBuilder(field_48297)
                .method_71554(MapleArmorItems.Cherry_HELMET)
                .setReplace(false);
        valueLookupBuilder(field_42611)
                .method_71554(MapleArmorItems.Cherry_SWORD)
                .setReplace(false);
        valueLookupBuilder(field_42612)
                .method_71554(MapleArmorItems.Cherry_AXE)
                .setReplace(false);
        valueLookupBuilder(field_42613)
                .method_71554(MapleArmorItems.Cherry_HOE)
                .setReplace(false);
        valueLookupBuilder(field_42614)
                .method_71554(MapleArmorItems.Cherry_PICKAXE)
                .setReplace(false);
        valueLookupBuilder(field_42615)
                .method_71554(MapleArmorItems.Cherry_SHOVEL)
                .setReplace(false);
        // minecraft:item/villager_plantable_seeds -> maple:rice
        valueLookupBuilder(field_44591)
                .method_71554(MapleItems.Rice)
                .setReplace(false);
        // minecraft:item/standing_signs -> maple signs
        valueLookupBuilder(ModItemTags.STANDING_SIGNS_ITEM)
                .method_71554(class_1792.method_7867(MapleSignBlocks.Maple_SIGN))
                .method_71554(class_1792.method_7867(MapleSignBlocks.GINKGO_SIGN))
                .setReplace(false);
        // minecraft:item/needs_iron_tool -> item forms of ore blocks
        valueLookupBuilder(ModItemTags.NEEDS_IRON_TOOL_ITEM)
                .method_71554(class_1792.method_7867(MapleOreBlocks.DEEPSLATE_Salt_Ore))
                .method_71554(class_1792.method_7867(MapleOreBlocks.Salt_Ore))
                .setReplace(false);
        // minecraft:item/logs_that_burn -> maple/ginkgo log items
        valueLookupBuilder(ModItemTags.LOGS_THAT_BURN_ITEM)
                .method_71554(class_1792.method_7867(MapleBlocks.MAPLE_LOG))
                .method_71554(class_1792.method_7867(MapleBlocks.MAPLE_WOOD))
                .method_71554(class_1792.method_7867(MapleBlocks.STRIPPED_MAPLE_LOG))
                .method_71554(class_1792.method_7867(MapleBlocks.STRIPPED_MAPLE_WOOD))
                .method_71554(class_1792.method_7867(MapleBlocks.GINKGO_LOG))
                .method_71554(class_1792.method_7867(MapleBlocks.GINKGO_WOOD))
                .method_71554(class_1792.method_7867(MapleBlocks.STRIPPED_GINKGO_LOG))
                .method_71554(class_1792.method_7867(MapleBlocks.STRIPPED_GINKGO_WOOD))
                .setReplace(false);
    }


}
