package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.block.*;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2750;
import net.minecraft.class_2754;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_8177;
import org.jetbrains.annotations.Nullable;

public class WindowBlock extends class_2383 {
    public static final MapCodec<WindowBlock> CODEC = RecordCodecBuilder.mapCodec((instance) -> {
        return instance.group(method_54096(),class_8177.field_46534.fieldOf("block_set_type").forGetter((block) -> {
            return block.blockSetType;
        })).apply(instance, WindowBlock::new);
    });
    public static final class_2754<class_2350> FACING;
    public static final class_2754<class_2750> HINGE;
    public static final class_2746 OPEN;
    public static final class_2746 POWERED;
    public static final class_265 WEST_OPEN_SHAPE;
    public static final class_265 EAST_OPEN_SHAPE;
    public static final class_265 NORTH_OPEN_SHAPE;
    public static final class_265 SOUTH_OPEN_SHAPE;

    public static final class_265 WEST_CLOSED_SHAPE;
    public static final class_265 EAST_CLOSED_SHAPE;
    public static final class_265 NORTH_CLOSED_SHAPE;
    public static final class_265 SOUTH_CLOSED_SHAPE;
    private final class_8177 blockSetType;

    public WindowBlock(class_2251 settings, class_8177 blockSetType) {
        super(settings.method_9626(blockSetType.comp_1290()));
        this.blockSetType = blockSetType;
        this.method_9590(this.field_10647.method_11664()
                .method_11657(field_11177, class_2350.field_11043)
                .method_11657(OPEN, false)
                .method_11657(HINGE, class_2750.field_12588)
                .method_11657(POWERED, false));
    }


    public class_8177 getBlockSetType() {
        return this.blockSetType;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2350 direction = state.method_11654(field_11177);
        boolean closed = !state.method_11654(OPEN);
        boolean bl2 = state.method_11654(HINGE) == class_2750.field_12586;
        switch (direction) {
            case field_11034:
                return closed ? EAST_CLOSED_SHAPE : (bl2 ? WEST_OPEN_SHAPE : EAST_OPEN_SHAPE);
            case field_11035:
                return closed ? SOUTH_CLOSED_SHAPE : (bl2 ? NORTH_OPEN_SHAPE :SOUTH_OPEN_SHAPE);
            case field_11039:
                return closed ? WEST_CLOSED_SHAPE : (bl2 ? EAST_OPEN_SHAPE :WEST_OPEN_SHAPE);
            case field_11043:
            default:
                return closed ? NORTH_CLOSED_SHAPE : (bl2 ? SOUTH_OPEN_SHAPE : NORTH_OPEN_SHAPE);
        }
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2338 blockPos = ctx.method_8037();
        class_1937 world = ctx.method_8045();
        boolean powered = world.method_49803(blockPos);
        return this.method_9564()
                .method_11657(field_11177, ctx.method_8042())
                .method_11657(POWERED, powered)
                .method_11657(HINGE, this.getHinge(ctx))
                .method_11657(OPEN, powered);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!this.blockSetType.comp_1471()) {
            return class_1269.field_5811;
        }

        state = state.method_28493(OPEN);
        world.method_8652(pos, state, 10);
        this.playOpenCloseSound(player, world, pos, state.method_11654(OPEN));
        world.method_33596(player, state.method_11654(OPEN) ? class_5712.field_28168 : class_5712.field_28169, pos);

        return class_1269.field_5812;
    }

    private class_2750 getHinge(class_1750 ctx) {
        class_1922 blockView = ctx.method_8045();
        class_2338 blockPos = ctx.method_8037();
        class_2350 direction = ctx.method_8042();
        class_2338 blockPos2 = blockPos.method_10084();
        class_2350 direction2 = direction.method_10160();
        class_2338 blockPos3 = blockPos.method_10093(direction2);
        class_2680 blockState = blockView.method_8320(blockPos3);
        class_2338 blockPos4 = blockPos2.method_10093(direction2);
        class_2680 blockState2 = blockView.method_8320(blockPos4);
        class_2350 direction3 = direction.method_10170();
        class_2338 blockPos5 = blockPos.method_10093(direction3);
        class_2680 blockState3 = blockView.method_8320(blockPos5);
        class_2338 blockPos6 = blockPos2.method_10093(direction3);
        class_2680 blockState4 = blockView.method_8320(blockPos6);
        int i = (blockState.method_26234(blockView, blockPos3) ? -1 : 0) + (blockState2.method_26234(blockView, blockPos4) ? -1 : 0) + (blockState3.method_26234(blockView, blockPos5) ? 1 : 0) + (blockState4.method_26234(blockView, blockPos6) ? 1 : 0);
        if (i <= 0) {
            if (i >= 0) {
                int j = direction.method_10148();
                int k = direction.method_10165();
                class_243 vec3d = ctx.method_17698();
                double d = vec3d.field_1352 - (double)blockPos.method_10263();
                double e = vec3d.field_1350 - (double)blockPos.method_10260();
                return (j >= 0 || !(e < 0.5)) && (j <= 0 || !(e > 0.5)) && (k >= 0 || !(d > 0.5)) && (k <= 0 || !(d < 0.5)) ? class_2750.field_12588 : class_2750.field_12586;
            } else {
                return class_2750.field_12588;
            }
        } else {
            return class_2750.field_12586;
        }
    }

    private void playOpenCloseSound(@Nullable class_1297 entity, class_1937 world, class_2338 pos, boolean open) {
        world.method_45445(entity, pos, open ? this.blockSetType.comp_1292() : this.blockSetType.comp_1291(), class_3419.field_15245, 1.0F, world.method_8409().method_43057() * 0.1F + 0.9F);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, OPEN, HINGE, POWERED);
    }

    static {
        field_11177 = class_2383.field_11177;
        OPEN = class_2741.field_12537;
        HINGE = class_2741.field_12520;
        POWERED = class_2741.field_12484;


        WEST_CLOSED_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 1.5, 16.0, 16.0);
        EAST_CLOSED_SHAPE = class_2248.method_9541(14.5, 0.0, 0.0, 16.0, 16.0, 16.0);
        NORTH_CLOSED_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 1.5);
        SOUTH_CLOSED_SHAPE = class_2248.method_9541(0.0, 0.0, 14.5, 16.0, 16.0, 16.0);

        WEST_OPEN_SHAPE = class_2248.method_9541(0.0, 0.0, 14.5, 16.0, 16.0, 16.0);
        EAST_OPEN_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 1.5);
        NORTH_OPEN_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 1.5, 16.0, 16.0);
        SOUTH_OPEN_SHAPE = class_2248.method_9541(14.5, 0.0, 0.0, 16.0, 16.0, 16.0);
    }

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }
}

