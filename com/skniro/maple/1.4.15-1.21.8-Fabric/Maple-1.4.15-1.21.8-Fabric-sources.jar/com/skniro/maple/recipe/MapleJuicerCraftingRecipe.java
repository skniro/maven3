package com.skniro.maple.recipe;


import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_10355;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9695;
import net.minecraft.class_9887;
import net.minecraft.recipe.*;
import org.jetbrains.annotations.Nullable;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;


public class MapleJuicerCraftingRecipe implements class_1860<class_9695> {
    private final class_1799 output;
    final List<class_1856>  recipeItems;
    @Nullable
    private class_9887 ingredientPlacement;

    public MapleJuicerCraftingRecipe(List<class_1856> recipeItems, class_1799 output) {
        this.output = output;
        this.recipeItems = recipeItems;
    }

    @Override
    public boolean method_8115(class_9695 inventory, class_1937 world) {
        for (int i = 0; i < recipeItems.size(); i++) {
            if (!recipeItems.get(i).method_8093(inventory.method_59984(i))) {
                return false;
            }
        }
        return true;
    }

    @Override
    public class_1799 method_8116(class_9695 inventory, class_7225.class_7874 lookup) {
        return output;
    }


    @Override
    public class_9887 method_61671() {
        if (this.ingredientPlacement == null) {
            this.ingredientPlacement = class_9887.method_61686(this.recipeItems);
        }

        return this.ingredientPlacement;
    }

    @Override
    public class_10355 method_64668() {
        return null;
    }


    public class_1799 getResult(class_7225.class_7874 lookup) {
        return output;
    }


    public class_2371<class_1856> getIngredients() {
        class_2371<class_1856> list = class_2371.method_37434(2);
        list.addAll(recipeItems);
        return list;
    }

    @Override
    public class_1865<? extends class_1860<class_9695>> method_8119() {
        return MapleRecipeType.Maple_JUIER_SERIALIZER;
    }

    @Override
    public class_3956<? extends class_1860<class_9695>> method_17716() {
        return MapleRecipeType.Maple_JUIER_TYPE;
    }

    public static class Serializer implements class_1865<MapleJuicerCraftingRecipe> {
        public static final Serializer INSTANCE = new Serializer();
        public static final MapCodec<MapleJuicerCraftingRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
                class_1856.field_46095.listOf().fieldOf("ingredient").forGetter((recipe) -> {
                    return recipe.recipeItems;
                }),
                class_1799.field_24671.fieldOf("result").forGetter((recipe) -> {
                    return recipe.output;
                })
        ).apply(inst, MapleJuicerCraftingRecipe::new));


        public static final class_9139<class_9129, MapleJuicerCraftingRecipe> PACKET_CODEC = class_9139.method_56437(MapleJuicerCraftingRecipe.Serializer::write, MapleJuicerCraftingRecipe.Serializer::read);

        public Serializer() {
        }

        public MapCodec<MapleJuicerCraftingRecipe> method_53736() {
            return CODEC;
        }

        public class_9139<class_9129, MapleJuicerCraftingRecipe> method_56104() {
            return PACKET_CODEC;
        }

        private static MapleJuicerCraftingRecipe read(class_9129 buf) {
            int i = buf.method_10816();
            class_2371<class_1856> defaultedList = class_2371.method_10213(i, class_1856.method_8101(class_1799.field_8037.method_7909()));
            defaultedList.replaceAll((empty) -> {
                return (class_1856)class_1856.field_48355.decode(buf);
            });
            class_1799 itemStack = (class_1799)class_1799.field_48349.decode(buf);
            return new MapleJuicerCraftingRecipe(defaultedList, itemStack);
        }

        private static void write(class_9129 buf, MapleJuicerCraftingRecipe recipe) {
            buf.method_10804(recipe.recipeItems.size());
            Iterator var2 = recipe.recipeItems.iterator();

            while(var2.hasNext()) {
                class_1856 ingredient = (class_1856)var2.next();
                class_1856.field_48355.encode(buf, ingredient);
            }

            class_1799.field_48349.encode(buf, recipe.output);
        }
    }
}




