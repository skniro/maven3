package com.skniro.growable_ores_extension.block.renderer.state;

import com.llamalad7.mixinextras.lib.antlr.runtime.atn.BlockStartState;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;


public class AlchemyBlockEntityRenderState extends BlockEntityRenderState {
    public final ItemStackRenderState item = new ItemStackRenderState();
    public BlockState blockState;
}