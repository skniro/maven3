package com.skniro.maple.block;

import com.skniro.maple.Maple;
import com.skniro.maple.block.entity.MapleSignTypes;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2508;
import net.minecraft.class_2551;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_4719;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7713;
import net.minecraft.class_7715;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.item.*;
import java.util.function.Function;

public class MapleSignBlocks {
    public static final class_2248 CHERRY_SIGN = registerBlockWithoutItem("cherry_sign",(settings)->  new class_2508(class_4719.field_42837, settings),class_4970.class_2251.method_9637().method_31710(MapleBlocks.CHERRY_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013());
    public static final class_2248 CHERRY_WALL_SIGN = registerBlockWithoutItem("cherry_wall_sign",(settings)->  new class_2551(class_4719.field_42837, settings),class_4970.class_2251.method_9637().method_31710(MapleBlocks.CHERRY_LOG.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_63502((CHERRY_SIGN.method_26162())));
    public static final class_2248 Maple_SIGN = registerBlockWithoutItem("maple_sign",(settings)-> new class_2508(MapleSignTypes.MAPLE, settings),class_4970.class_2251.method_9637().method_31710(MapleBlocks.MAPLE_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013());
    public static final class_2248 Maple_WALL_SIGN = registerBlockWithoutItem("maple_wall_sign",(settings)-> new class_2551(MapleSignTypes.MAPLE, settings),class_4970.class_2251.method_9637().method_31710(MapleBlocks.MAPLE_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_63502((Maple_SIGN.method_26162())));
    public static final class_2248 BAMBOO_SIGN = registerBlockWithoutItem("bamboo_sign",(settings)->  new class_2508(class_4719.field_40350, settings),class_4970.class_2251.method_9637().method_31710(MapleBlocks.BAMBOO_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013());
    public static final class_2248 BAMBOO_WALL_SIGN = registerBlockWithoutItem("bamboo_wall_sign",(settings)-> new class_2551(class_4719.field_40350, settings),class_4970.class_2251.method_9637().method_31710(MapleBlocks.BAMBOO_PLANKS.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_63502((BAMBOO_SIGN.method_26162())));
    public static final class_2248 GINKGO_SIGN = registerBlockWithoutItem("ginkgo_sign",(settings)->  new class_2508(MapleSignTypes.GINKGO, settings),class_4970.class_2251.method_9637().method_31710(MapleBlocks.GINKGO_LEAVES.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013());
    public static final class_2248 GINKGO_WALL_SIGN = registerBlockWithoutItem("ginkgo_wall_sign",(settings)-> new class_2551(MapleSignTypes.GINKGO, settings),class_4970.class_2251.method_9637().method_31710(MapleBlocks.GINKGO_LEAVES.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_63502((GINKGO_SIGN.method_26162())));
    public static final class_2248 GINKGO_HANGING_SIGN = registerBlockWithoutItem("ginkgo_hanging_sign",(settings)-> new class_7713(MapleSignTypes.GINKGO, settings),class_4970.class_2251.method_9637().method_31710(MapleBlocks.GINKGO_LEAVES.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013());
    public static final class_2248 GINKGO_WALL_HANGING_SIGN = registerBlockWithoutItem("ginkgo_wall_hanging_sign",(settings)->  new class_7715(MapleSignTypes.GINKGO, settings),class_4970.class_2251.method_9637().method_31710(MapleBlocks.GINKGO_LEAVES.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_63502(GINKGO_HANGING_SIGN.method_26162()));
    public static final class_2248 Maple_HANGING_SIGN = registerBlockWithoutItem("maple_hanging_sign",(settings)-> new class_7713(MapleSignTypes.MAPLE, settings),class_4970.class_2251.method_9637().method_31710(MapleBlocks.MAPLE_LEAVES.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013());
    public static final class_2248 Maple_WALL_HANGING_SIGN = registerBlockWithoutItem("maple_wall_hanging_sign",(settings)->  new class_7715(MapleSignTypes.MAPLE, settings),class_4970.class_2251.method_9637().method_31710(MapleBlocks.MAPLE_LEAVES.method_26403()).method_51369().method_51368(class_2766.field_12651).method_9634().method_9632(1.0F).method_50013().method_63502((Maple_HANGING_SIGN.method_26162())));


    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings, class_5321<class_1761> tab) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(keyOf(name)));
        registerBlockItem(name, block, tab);
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }


    private static class_1792 registerBlockItem(String name, class_2248 block, class_5321<class_1761> tab) {
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Maple.MOD_ID, name)),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Maple.MOD_ID, name)))));
    }

    private static class_2248 registerBlockWithoutItem(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(keyOf(name)));
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }

    private static class_5321<class_2248> keyOf(String name) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(Maple.MOD_ID, name));
    }

    public static void registerMapleSignBlocks() {
        Maple.LOGGER.debug("Registering MapleSignBlocks for " + Maple.MOD_ID);
    }
}
