package com.skniro.growable_ores_extension.item;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;

public class AdvancedItems {
    public static final Item IRRADIANT_URANIUM_INGOT = registerItem("irradiant_uranium", Item::new, new Item.Properties());
    public static final Item IRRADIANT_GLASS_PANE = registerItem("irradiant_glass_pane", Item::new, new Item.Properties());
    public static final Item SUNNARIUM = registerItem("sunnarium", Item::new, new Item.Properties());
    public static final Item ENRICHED_SUNNARIUM = registerItem("enriched_sunnarium", Item::new, new Item.Properties());
    public static final Item SUNNARIUM_ALLOY = registerItem("sunnarium_alloy", Item::new, new Item.Properties());
    public static final Item ENRICHED_SUNNARIUM_ALLOY = registerItem("enriched_sunnarium_alloy", Item::new, new Item.Properties());
    public static final Item IRIDIUM_IRON_PLATE = registerItem("iridium_iron_plate", Item::new, new Item.Properties());
    public static final Item REINFORCED_IRIDIUM_IRON_PLATE = registerItem("reinforced_iridiumiron_plate", Item::new, new Item.Properties());
    public static final Item IRRADIANT_REINFORCED_PLATE = registerItem("irradiant_reinforced_plate", Item::new, new Item.Properties());
    public static final Item SUNNARIUM_Part = registerItem("sunnarium_part", Item::new, new Item.Properties());
    public static final Item Iridium_INGOT = registerItem("iridium_ingot", Item::new, new Item.Properties());
    public static final Item Quantum_Core = registerItem("quantum_core", Item::new, new Item.Properties());
    public static final Item MT_Core = registerItem("mt_core", Item::new, new Item.Properties());

    public static final Item PIPE_PLUG = registerItem("pipe_plug", Item::new, new Item.Properties());

    private static Item registerItem(String name, Function<Item.Properties, Item> factory, Item.Properties settings) {
        Item item = factory.apply(settings.setId(ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, name))));
        return Registry.register(BuiltInRegistries.ITEM, ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(GrowableOresExtension.MOD_ID, name)), item);
    }

    public static void registerAdvancedItem(){
        GrowableOresExtension.LOGGER.debug("register Advanced Item.");
    }
}
