package com.skniro.growable_ores_extension.compat;

import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.machine.MaceratorBlockScreen;
import com.skniro.growable_ores_extension.compat.display.MaceratorDisplay;
import com.skniro.growable_ores_extension.recipe.machine.MaceratorCraftingRecipe;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.plugins.REIClientPlugin;
import me.shedaniel.rei.api.client.registry.category.CategoryRegistry;
import me.shedaniel.rei.api.client.registry.display.DisplayRegistry;
import me.shedaniel.rei.api.client.registry.screen.ScreenRegistry;
import me.shedaniel.rei.api.common.util.EntryStacks;

public class IndustrialModREIClient implements REIClientPlugin {

    @Override
    public String getPluginProviderName() {
        return "IndustrialAlphaClient";
    }

    @Override
    public void registerCategories(CategoryRegistry registry) {
        registry.add(new MaceratorCategory());
        registry.addWorkstations(MaceratorCategory.MACERATOR, EntryStacks.of(GrowableOresBlocks.Macerator_Block));
    }

    @Override
    public void registerDisplays(DisplayRegistry registry) {
        registry.beginFiller(MaceratorCraftingRecipe.class)
                .fill(MaceratorDisplay::new);
    }

    @Override
    public void registerScreens(ScreenRegistry registry) {
        registry.registerClickArea(screen -> new Rectangle(((screen.field_22789 - 176) / 2) + 78,
                ((screen.field_22790 - 166) / 2) + 30, 20, 25), MaceratorBlockScreen.class,
                MaceratorCategory.MACERATOR);
    }
}