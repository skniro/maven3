package com.skniro.industrial_elixir.fluid;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.fluid.init.MapleHotSpringFluidBlock;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.item.init.FluidCellItem;
import com.skniro.industrial_elixir.item.init.ModBucketItem;
import java.util.function.Function;
import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class IndustrialElixirFluidItems {
    public static final class_1792 Fluid_UU_BUCKET = registerItem("fluid_uu_bucket",
            (settings)->  new class_1755(IndustrialElixirFluids.STILL_Fluid_UU, settings), new class_1792.class_1793().method_7896(class_1802.field_8550).method_7889(1));
    public static final class_1792 Fluid_AIR_BUCKET = registerItem("fluid_air_bucket",
            (settings)->  new class_1755(IndustrialElixirFluids.STILL_Fluid_AIR, settings), new class_1792.class_1793().method_7896(class_1802.field_8550).method_7889(1));
    public static final class_1792 UU_CELL = registerItem("uu_cell",
            (properties)-> new FluidCellItem(properties, IndustrialElixirFluids.STILL_Fluid_UU), new class_1792.class_1793().method_7896(GrowableOresItems.EMPTY_CELL).method_7889(16));
    public static final class_1792 AIR_CELL = registerItem("air_cell",
            (properties)-> new FluidCellItem(properties, IndustrialElixirFluids.STILL_Fluid_AIR), new class_1792.class_1793().method_7896(GrowableOresItems.EMPTY_CELL).method_7889(16));
    public static final class_1792 Hot_Spring_BUCKET = registerItem("hot_spring_bucket",
            (settings)->  new ModBucketItem(IndustrialElixirFluids.STILL_Hot_Spring, settings), new class_1792.class_1793().method_7896(class_1802.field_8550).method_7889(1));
    public static final class_1792 Hot_Spring_CELL = registerItem("hot_spring_cell",
            (settings)->  new FluidCellItem(settings, IndustrialElixirFluids.STILL_Hot_Spring), new class_1792.class_1793().method_7896(GrowableOresItems.EMPTY_CELL).method_7889(16));

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings);
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(IndustrialElixir.MOD_ID, name)), item);
    }

    public static void registerFluidItems() {
        IndustrialElixir.LOGGER.info("Registering Industrial Elixir Fluid Items for " + IndustrialElixir.MOD_ID);
    }
}
