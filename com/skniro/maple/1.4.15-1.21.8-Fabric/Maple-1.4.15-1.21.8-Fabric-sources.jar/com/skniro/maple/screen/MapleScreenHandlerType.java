package com.skniro.maple.screen;

import com.skniro.maple.Maple;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class MapleScreenHandlerType<T extends class_1703>{
    public static final class_3917<MapleJuicerBlockScreenHandler> Maple_JUICER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Maple.MOD_ID, "maple_juicer_screen_handler"),
                    new ExtendedScreenHandlerType<>(MapleJuicerBlockScreenHandler::new, class_2338.field_48404));

    public static void registerMapleScreenHandlerType () {
        Maple.LOGGER.debug("Registering Maple Screen Handler Type for " + Maple.MOD_ID);
    }
}
