package com.skniro.growable_ores_extension.item;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.block.MapleSignBlocks;
import com.skniro.growable_ores_extension.item.init.QuantumSuitItem;
import com.skniro.growable_ores_extension.item.init.RollingCuttingToolItem;
import com.skniro.growable_ores_extension.item.init.equipment.MapleArmorMaterials;
import com.skniro.growable_ores_extension.item.init.tool.MapleToolMaterials;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1821;
import net.minecraft.class_1822;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7707;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8051;
import net.minecraft.item.*;
import java.util.function.Function;

public class MapleArmorItems {
    //Tool
    public static final class_1792 BRONZE_HELMET = registerItem("bronze_helmet", class_1792::new,(new class_1792.class_1793()).method_66332(MapleArmorMaterials.BRONZE, class_8051.field_41934));
    public static final class_1792 BRONZE_CHESTPLATE = registerItem("bronze_chestplate", class_1792::new,(new class_1792.class_1793()).method_66332(MapleArmorMaterials.BRONZE, class_8051.field_41935));
    public static final class_1792 BRONZE_LEGGINGS = registerItem("bronze_leggings", class_1792::new,(new class_1792.class_1793()).method_66332(MapleArmorMaterials.BRONZE, class_8051.field_41936));
    public static final class_1792 BRONZE_BOOTS = registerItem("bronze_boots", class_1792::new,(new class_1792.class_1793()).method_66332(MapleArmorMaterials.BRONZE, class_8051.field_41937));

    public static final class_1792 BRONZE_SWORD = registerItem("bronze_sword", class_1792::new,(new class_1792.class_1793()).method_66333(MapleToolMaterials.BRONZE, 3.0F, -2.4F));
    public static final class_1792 BRONZE_SHOVEL = registerItem("bronze_shovel", (settings) -> new class_1821(MapleToolMaterials.BRONZE, 1.5F, -3.0F, settings), new class_1792.class_1793());
    public static final class_1792 BRONZE_PICKAXE = registerItem("bronze_pickaxe", (settings) ->new class_1792(settings.method_66330(MapleToolMaterials.BRONZE, 1.0F, -2.8F)), new class_1792.class_1793());
    public static final class_1792 BRONZE_AXE = registerItem("bronze_axe", (settings) -> new class_1743(MapleToolMaterials.BRONZE, 6.0F, -3.1F, settings), new class_1792.class_1793());
    public static final class_1792 BRONZE_HOE = registerItem("bronze_hoe", (settings) -> new class_1794(MapleToolMaterials.BRONZE, -2.0F, -1.0F, settings), new class_1792.class_1793());

    public static final class_1792 Rubber_SIGN = registerItem("rubber_sign",
            (settings)-> new class_1822(MapleSignBlocks.Rubber_SIGN, MapleSignBlocks.Rubber_WALL_SIGN, settings), new class_1792.class_1793().method_7889(16));

    public static final class_1792 Rubber_HANGING_SIGN = registerItem("rubber_hanging_sign", (settings)-> new class_7707(
            MapleSignBlocks.Rubber_HANGING_SIGN, MapleSignBlocks.Rubber_WALL_HANGING_SIGN, settings), new class_1792.class_1793().method_7889(16));

    public static final class_1792 ROLLING = registerItem("tool_rolling", RollingCuttingToolItem::new, new class_1792.class_1793());
    public static final class_1792 CUTTING = registerItem("tool_cutting", RollingCuttingToolItem::new, new class_1792.class_1793());

    //Armor
    public static final class_1792 Quantum_HELMET = registerItem("quantum_helmet", (settings)-> new QuantumSuitItem(settings, MapleArmorMaterials.QUANTUM, class_8051.field_41934, EnergyTier.TIER5), new class_1792.class_1793());
    public static final class_1792 Quantum_CHESTPLATE = registerItem("quantum_chestplate", (settings)-> new QuantumSuitItem(settings, MapleArmorMaterials.QUANTUM, class_8051.field_41935, EnergyTier.TIER5), new class_1792.class_1793());
    public static final class_1792 Quantum_LEGGINGS = registerItem("quantum_leggings", (settings)-> new QuantumSuitItem(settings, MapleArmorMaterials.QUANTUM, class_8051.field_41936, EnergyTier.TIER5), new class_1792.class_1793());
    public static final class_1792 Quantum_BOOTS = registerItem("quantum_boots", (settings)-> new QuantumSuitItem(settings, MapleArmorMaterials.QUANTUM, class_8051.field_41937, EnergyTier.TIER5), new class_1792.class_1793());

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings.method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name))));
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)), item);
    }

    public static void registerMapleArmorItems() {
        GrowableOresExtension.LOGGER.info("Registering Maple armor items for " + GrowableOresExtension.MOD_ID);
    }
}
