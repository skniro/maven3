package com.skniro.maple.datagen;

import com.google.common.collect.Lists;
import com.skniro.maple.block.MapleBlocks;
import com.skniro.maple.item.MapleFoodComponents;
import com.skniro.maple.item.MapleItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_156;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2446;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class MapleRecipeGeneration extends FabricRecipeProvider {
    public MapleRecipeGeneration(FabricDataOutput generator, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(generator, registryLookup);
    }


    public static final List<class_1935> STRIPPED_MAPLE = class_156.method_654(Lists.newArrayList(), list -> {
        list.add(MapleBlocks.STRIPPED_MAPLE_LOG);
        list.add(MapleBlocks.STRIPPED_MAPLE_WOOD);
    });
    public static final List<class_1935> Green_Tea = class_156.method_654(Lists.newArrayList(), list -> {
        list.add(MapleFoodComponents.Green_Tea_Leaves);
    });

    @Override
    protected class_2446 method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new class_2446(wrapperLookup, exporter) {
            @Override
            public void method_10419() {
        method_62750(class_7800.field_40640 ,MapleFoodComponents.MILK_BOTTOM,3).method_10454(class_1802.field_8103).method_10449(class_1802.field_8469,3).method_10442(method_32807(MapleFoodComponents.MILK_BOTTOM),
                method_10426(MapleFoodComponents.MILK_BOTTOM)).method_10442(method_32807(class_1802.field_8103),
                method_10426(class_1802.field_8103)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleItems.Flour,2).method_10454(class_1802.field_8861).method_10442(method_32807(MapleItems.Flour),
                method_10426(MapleItems.Flour)).method_10442(method_32807(class_1802.field_8861),
                method_10426(class_1802.field_8861)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleBlocks.SAKURA_SAPLING,2).method_10454(class_1802.field_8330).method_10442(method_32807(MapleBlocks.SAKURA_SAPLING),
                method_10426(MapleBlocks.SAKURA_SAPLING)).method_10442(method_32807(class_1802.field_8330),
                method_10426(class_1802.field_8330)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleFoodComponents.Anko_Dango,1)
                .method_10454(class_1802.field_8479)
                .method_10454(class_1802.field_8479)
                .method_10454(MapleFoodComponents.Mochi)
                .method_10454(MapleItems.SOYBEAN)
                .method_10454(class_1802.field_8648)
                .method_10442(method_32807(MapleFoodComponents.Anko_Dango),
                method_10426(MapleFoodComponents.Anko_Dango)).method_10442(method_32807(class_1802.field_8479),
                method_10426(class_1802.field_8479)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleFoodComponents.Mochi,2)
                .method_10454(MapleFoodComponents.Cooked_Rice)
                .method_10454(MapleFoodComponents.Cooked_Rice)
                .method_10454(MapleFoodComponents.Cooked_Rice)
                .method_10454(MapleFoodComponents.Cooked_Rice)
                .method_10442(method_32807(MapleFoodComponents.Mochi),
                        method_10426(MapleFoodComponents.Mochi))
                .method_10442(method_32807(MapleFoodComponents.Cooked_Rice),
                        method_10426(MapleFoodComponents.Cooked_Rice)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleFoodComponents.SakuraMochi,2)
                .method_10454(MapleFoodComponents.Mochi)
                .method_10454(MapleBlocks.SAKURA_LEAVES)
                .method_10442(method_32807(MapleFoodComponents.Mochi),
                        method_10426(MapleFoodComponents.Mochi))
                .method_10442(method_32807(MapleFoodComponents.Cooked_Rice),
                        method_10426(MapleFoodComponents.Cooked_Rice)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleItems.Cream,3)
                .method_10454(MapleFoodComponents.MILK_BOTTOM)
                .method_10454(MapleFoodComponents.MILK_BOTTOM)
                .method_10442(method_32807(MapleItems.Cream),
                        method_10426(MapleItems.Cream))
                .method_10442(method_32807(MapleFoodComponents.MILK_BOTTOM),
                        method_10426(MapleFoodComponents.MILK_BOTTOM)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleFoodComponents.Cooked_Rice,2)
                .method_10454(MapleItems.Rice)
                .method_10454(MapleItems.Rice)
                .method_10442(method_32807(MapleFoodComponents.Cooked_Rice),
                        method_10426(MapleFoodComponents.Cooked_Rice))
                .method_10442(method_32807(MapleItems.Rice),
                        method_10426(MapleItems.Rice)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleFoodComponents.Kinako_Dango,1)
                .method_10454(class_1802.field_8479)
                .method_10454(MapleFoodComponents.Mochi)
                .method_10454(MapleItems.SOYBEAN)
                .method_10454(class_1802.field_8648)
                .method_10442(method_32807(MapleFoodComponents.Kinako_Dango),
                        method_10426(MapleFoodComponents.Kinako_Dango))
                .method_10442(method_32807(class_1802.field_8479),
                        method_10426(class_1802.field_8479)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleFoodComponents.Zunda_Dango,1)
                .method_10454(class_1802.field_8479)
                .method_10454(MapleFoodComponents.Mochi)
                .method_10454(MapleItems.SOYBEAN)
                .method_10454(MapleItems.SOYBEAN)
                .method_10454(class_1802.field_8648)
                .method_10442(method_32807(MapleFoodComponents.Zunda_Dango),
                        method_10426(MapleFoodComponents.Zunda_Dango))
                .method_10442(method_32807(class_1802.field_8479),
                        method_10426(class_1802.field_8479)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleFoodComponents.Sanshoku_Dango,1)
                .method_10454(class_1802.field_8479)
                .method_10454(MapleFoodComponents.Mochi)
                .method_10454(class_1802.field_8602)
                .method_10454(MapleBlocks.SAKURA_LEAVES)
                .method_10454(class_1802.field_8648)
                .method_10442(method_32807(MapleFoodComponents.Sanshoku_Dango),
                        method_10426(MapleFoodComponents.Sanshoku_Dango))
                .method_10442(method_32807(class_1802.field_8479),
                        method_10426(class_1802.field_8479)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleFoodComponents.TOFU,1)
                .method_10454(MapleItems.SOYBEAN)
                .method_10454(MapleItems.SOYBEAN)
                .method_10454(class_1802.field_8705)
                .method_10442(method_32807(MapleFoodComponents.TOFU),
                        method_10426(MapleFoodComponents.TOFU))
                .method_10442(method_32807(MapleItems.SOYBEAN),
                        method_10426(MapleItems.SOYBEAN)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleFoodComponents.MILK_ICECREAM,2)
                .method_10454(MapleItems.Cream)
                .method_10454(MapleFoodComponents.MILK_BOTTOM)
                .method_10454(class_1802.field_8705)
                .method_10442(method_32807(MapleFoodComponents.MILK_ICECREAM),
                        method_10426(MapleFoodComponents.MILK_ICECREAM))
                .method_10442(method_32807(MapleItems.Cream),
                        method_10426(MapleItems.Cream))
                .method_10442(method_32807(MapleFoodComponents.MILK_BOTTOM),
                        method_10426(MapleFoodComponents.MILK_BOTTOM)).method_10431(field_53721);

        method_62750(class_7800.field_40640 ,MapleFoodComponents.Beef_Rice,1)
                .method_10454(MapleFoodComponents.Cooked_Rice)
                .method_10454(class_1802.field_8046)
                .method_10442(method_32807(MapleFoodComponents.Cooked_Rice),
                        method_10426(MapleFoodComponents.Cooked_Rice))
                .method_10442(method_32807(class_1802.field_8046),
                        method_10426(class_1802.field_8046))
                .method_10431(field_53721);

        method_62750(class_7800.field_40635 ,MapleBlocks.Maple_CARPET,2)
                .method_10449(MapleBlocks.MAPLE_LEAVES,2)
                .method_10442(method_32807(MapleBlocks.MAPLE_LEAVES),
                        method_10426(MapleBlocks.MAPLE_LEAVES))
                .method_10431(field_53721);

        method_62750(class_7800.field_40635 ,MapleBlocks.RED_MAPLE_CARPET,2)
                .method_10449(MapleBlocks.RED_MAPLE_LEAVES,2)
                .method_10442(method_32807(MapleBlocks.RED_MAPLE_LEAVES),
                        method_10426(MapleBlocks.RED_MAPLE_LEAVES))
                .method_10431(field_53721);

        method_62750(class_7800.field_40635 ,MapleBlocks.GINKGO_CARPET,2)
                .method_10449(MapleBlocks.GINKGO_LEAVES,2)
                .method_10442(method_32807(MapleBlocks.GINKGO_LEAVES),
                        method_10426(MapleBlocks.GINKGO_LEAVES))
                .method_10431(field_53721);

        method_62750(class_7800.field_40635 ,MapleBlocks.SAKURA_CARPET,2)
                .method_10449(MapleBlocks.SAKURA_LEAVES,2)
                .method_10442(method_32807(MapleBlocks.SAKURA_LEAVES),
                        method_10426(MapleBlocks.SAKURA_LEAVES))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634, MapleBlocks.PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', class_2246.field_10102)
                .method_10434('i', class_2246.field_41072)
                .method_10429(method_32807(class_2246.field_10102),
                        method_10426(class_2246.field_10102))
                .method_10429(method_32807(class_2246.field_41072),
                        method_10426(class_2246.field_41072))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.GREEN_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8408)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8408),
                        method_10426(class_1802.field_8408))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.ORANGE_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8492)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8492),
                        method_10426(class_1802.field_8492))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.MAGENTA_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8669)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8669),
                        method_10426(class_1802.field_8669))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.LIGHT_BLUE_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8273)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8273),
                        method_10426(class_1802.field_8273))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.YELLOW_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8192)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8192),
                        method_10426(class_1802.field_8192))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.LIME_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8131)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8131),
                        method_10426(class_1802.field_8131))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.PINK_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8330)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8330),
                        method_10426(class_1802.field_8330))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.GRAY_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8298)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8298),
                        method_10426(class_1802.field_8298))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.LIGHT_GRAY_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8851)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8851),
                        method_10426(class_1802.field_8851))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.CYAN_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8632)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8632),
                        method_10426(class_1802.field_8632))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.PURPLE_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8296)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8296),
                        method_10426(class_1802.field_8296))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.BLUE_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8345)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8345),
                        method_10426(class_1802.field_8345))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.BROWN_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8099)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8099),
                        method_10426(class_1802.field_8099))
                .method_10431(field_53721);

        method_62747(class_7800.field_40634 ,MapleBlocks.RED_PLASTER,8).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', MapleBlocks.PLASTER)
                .method_10434('i', class_1802.field_8408)
                .method_10429(method_32807(MapleBlocks.PLASTER),
                        method_10426(MapleBlocks.PLASTER))
                .method_10429(method_32807(class_1802.field_8264),
                        method_10426(class_1802.field_8264))
                .method_10431(field_53721);

        method_62746(class_7800.field_40634 ,MapleBlocks.Iron_Sea_Lantern).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', class_2246.field_10174)
                .method_10434('i', class_1802.field_8675)
                .method_10429(method_32807(class_2246.field_10174),
                        method_10426(class_2246.field_10174))
                .method_10429(method_32807(class_1802.field_8675),
                        method_10426(class_1802.field_8675))
                .method_10431(field_53721);

        method_62746(class_7800.field_40634 ,MapleBlocks.Gold_Sea_Lantern).method_10439("bbb").method_10439("bib").method_10439("bbb")
                .method_10434('b', class_2246.field_10174)
                .method_10434('i', class_1802.field_8397)
                .method_10429(method_32807(class_2246.field_10174),
                        method_10426(class_2246.field_10174))
                .method_10429(method_32807(class_1802.field_8397),
                        method_10426(class_1802.field_8397))
                .method_10431(field_53721);

        method_62750(class_7800.field_40640 , MapleFoodComponents.Red_Tea,1)
                .method_10449(MapleFoodComponents.Red_Tea_Leaves,2)
                .method_10454(class_1802.field_8469)
                .method_10442(method_32807(MapleFoodComponents.Red_Tea_Leaves),
                        method_10426(MapleFoodComponents.Red_Tea_Leaves))
                .method_10442(method_32807(class_1802.field_8469),
                        method_10426(class_1802.field_8469)).method_10431(field_53721);

        method_62750(class_7800.field_40640 , MapleFoodComponents.Green_Tea,1)
                .method_10449(MapleFoodComponents.Green_Tea_Leaves,2)
                .method_10454(class_1802.field_8469)
                .method_10442(method_32807(MapleFoodComponents.Green_Tea_Leaves),
                        method_10426(MapleFoodComponents.Green_Tea_Leaves))
                .method_10442(method_32807(class_1802.field_8469),
                        method_10426(class_1802.field_8469)).method_10431(field_53721);

                method_36233(STRIPPED_MAPLE, class_7800.field_40640 , MapleItems.MapleSyrup, 0.45F, 300, "maple_syrup");
                method_36233(Green_Tea, class_7800.field_40640 , MapleFoodComponents.Red_Tea_Leaves, 0.45F, 300, "red_tea");
            }
        };
    }

    @Override
    public String method_10321() {
        return "";
    }
}