package com.skniro.usefulfood.datagen;

import com.skniro.usefulfood.block.UsefulFoodCakeBlocks;
import com.skniro.usefulfood.block.UsefulFoodJamBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_2246;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;


public class UsefulFoodLootTableGenerator extends FabricBlockLootTableProvider {
    public UsefulFoodLootTableGenerator(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataGenerator, registryLookup);
    }
    public static final float[] field_40605 = new float[]{0.048F, 0.0425F, 0.062333336F, 0.1F};

    @Override
    public void method_10379() {
        method_46025(UsefulFoodJamBlocks.Apple_JAM_JAR);
        method_46025(UsefulFoodJamBlocks.Chorus_JAM_JAR);
        method_46025(UsefulFoodJamBlocks.Melon_JAM_JAR);
        method_46025(UsefulFoodJamBlocks.Sweet_Berries_JAM_JAR);
        method_46025(UsefulFoodJamBlocks.Glow_Berries_JAM_JAR);
        method_46025(UsefulFoodJamBlocks.GLASS_JAR);

        method_45988(UsefulFoodCakeBlocks.AppleCake, method_45975());
        method_45988(UsefulFoodCakeBlocks.Apple_CANDLE_CAKE, method_46021(class_2246.field_27099));
        method_45988(UsefulFoodCakeBlocks.Apple_WHITE_CANDLE_CAKE, method_46021(class_2246.field_27100));
        method_45988(UsefulFoodCakeBlocks.Apple_ORANGE_CANDLE_CAKE, method_46021(class_2246.field_27101));
        method_45988(UsefulFoodCakeBlocks.Apple_MAGENTA_CANDLE_CAKE, method_46021(class_2246.field_27102));
        method_45988(UsefulFoodCakeBlocks.Apple_LIGHT_BLUE_CANDLE_CAKE, method_46021(class_2246.field_27103));
        method_45988(UsefulFoodCakeBlocks.Apple_YELLOW_CANDLE_CAKE, method_46021(class_2246.field_27104));
        method_45988(UsefulFoodCakeBlocks.Apple_LIME_CANDLE_CAKE, method_46021(class_2246.field_27105));
        method_45988(UsefulFoodCakeBlocks.Apple_PINK_CANDLE_CAKE, method_46021(class_2246.field_27106));
        method_45988(UsefulFoodCakeBlocks.Apple_GRAY_CANDLE_CAKE, method_46021(class_2246.field_27107));
        method_45988(UsefulFoodCakeBlocks.Apple_LIGHT_GRAY_CANDLE_CAKE, method_46021(class_2246.field_27108));
        method_45988(UsefulFoodCakeBlocks.Apple_CYAN_CANDLE_CAKE, method_46021(class_2246.field_27109));
        method_45988(UsefulFoodCakeBlocks.Apple_PURPLE_CANDLE_CAKE, method_46021(class_2246.field_27110));
        method_45988(UsefulFoodCakeBlocks.Apple_BLUE_CANDLE_CAKE, method_46021(class_2246.field_27111));
        method_45988(UsefulFoodCakeBlocks.Apple_BROWN_CANDLE_CAKE, method_46021(class_2246.field_27112));
        method_45988(UsefulFoodCakeBlocks.Apple_GREEN_CANDLE_CAKE, method_46021(class_2246.field_27113));
        method_45988(UsefulFoodCakeBlocks.Apple_RED_CANDLE_CAKE, method_46021(class_2246.field_27140));
        method_45988(UsefulFoodCakeBlocks.Apple_BLACK_CANDLE_CAKE, method_46021(class_2246.field_27141));

        method_45988(UsefulFoodCakeBlocks.ChocolateCake, method_45975());
        method_45988(UsefulFoodCakeBlocks.Chocolate_CANDLE_CAKE, method_46021(class_2246.field_27099));
        method_45988(UsefulFoodCakeBlocks.Chocolate_WHITE_CANDLE_CAKE, method_46021(class_2246.field_27100));
        method_45988(UsefulFoodCakeBlocks.Chocolate_ORANGE_CANDLE_CAKE, method_46021(class_2246.field_27101));
        method_45988(UsefulFoodCakeBlocks.Chocolate_MAGENTA_CANDLE_CAKE, method_46021(class_2246.field_27102));
        method_45988(UsefulFoodCakeBlocks.Chocolate_LIGHT_BLUE_CANDLE_CAKE, method_46021(class_2246.field_27103));
        method_45988(UsefulFoodCakeBlocks.Chocolate_YELLOW_CANDLE_CAKE, method_46021(class_2246.field_27104));
        method_45988(UsefulFoodCakeBlocks.Chocolate_LIME_CANDLE_CAKE, method_46021(class_2246.field_27105));
        method_45988(UsefulFoodCakeBlocks.Chocolate_PINK_CANDLE_CAKE, method_46021(class_2246.field_27106));
        method_45988(UsefulFoodCakeBlocks.Chocolate_GRAY_CANDLE_CAKE, method_46021(class_2246.field_27107));
        method_45988(UsefulFoodCakeBlocks.Chocolate_LIGHT_GRAY_CANDLE_CAKE, method_46021(class_2246.field_27108));
        method_45988(UsefulFoodCakeBlocks.Chocolate_CYAN_CANDLE_CAKE, method_46021(class_2246.field_27109));
        method_45988(UsefulFoodCakeBlocks.Chocolate_PURPLE_CANDLE_CAKE, method_46021(class_2246.field_27110));
        method_45988(UsefulFoodCakeBlocks.Chocolate_BLUE_CANDLE_CAKE, method_46021(class_2246.field_27111));
        method_45988(UsefulFoodCakeBlocks.Chocolate_BROWN_CANDLE_CAKE, method_46021(class_2246.field_27112));
        method_45988(UsefulFoodCakeBlocks.Chocolate_GREEN_CANDLE_CAKE, method_46021(class_2246.field_27113));
        method_45988(UsefulFoodCakeBlocks.Chocolate_RED_CANDLE_CAKE, method_46021(class_2246.field_27140));
        method_45988(UsefulFoodCakeBlocks.Chocolate_BLACK_CANDLE_CAKE, method_46021(class_2246.field_27141));

        method_45988(UsefulFoodCakeBlocks.MagicCake, method_45975());
        method_45988(UsefulFoodCakeBlocks.Magic_CANDLE_CAKE, method_46021(class_2246.field_27099));
        method_45988(UsefulFoodCakeBlocks.Magic_WHITE_CANDLE_CAKE, method_46021(class_2246.field_27100));
        method_45988(UsefulFoodCakeBlocks.Magic_ORANGE_CANDLE_CAKE, method_46021(class_2246.field_27101));
        method_45988(UsefulFoodCakeBlocks.Magic_MAGENTA_CANDLE_CAKE, method_46021(class_2246.field_27102));
        method_45988(UsefulFoodCakeBlocks.Magic_LIGHT_BLUE_CANDLE_CAKE, method_46021(class_2246.field_27103));
        method_45988(UsefulFoodCakeBlocks.Magic_YELLOW_CANDLE_CAKE, method_46021(class_2246.field_27104));
        method_45988(UsefulFoodCakeBlocks.Magic_LIME_CANDLE_CAKE, method_46021(class_2246.field_27105));
        method_45988(UsefulFoodCakeBlocks.Magic_PINK_CANDLE_CAKE, method_46021(class_2246.field_27106));
        method_45988(UsefulFoodCakeBlocks.Magic_GRAY_CANDLE_CAKE, method_46021(class_2246.field_27107));
        method_45988(UsefulFoodCakeBlocks.Magic_LIGHT_GRAY_CANDLE_CAKE, method_46021(class_2246.field_27108));
        method_45988(UsefulFoodCakeBlocks.Magic_CYAN_CANDLE_CAKE, method_46021(class_2246.field_27109));
        method_45988(UsefulFoodCakeBlocks.Magic_PURPLE_CANDLE_CAKE, method_46021(class_2246.field_27110));
        method_45988(UsefulFoodCakeBlocks.Magic_BLUE_CANDLE_CAKE, method_46021(class_2246.field_27111));
        method_45988(UsefulFoodCakeBlocks.Magic_BROWN_CANDLE_CAKE, method_46021(class_2246.field_27112));
        method_45988(UsefulFoodCakeBlocks.Magic_GREEN_CANDLE_CAKE, method_46021(class_2246.field_27113));
        method_45988(UsefulFoodCakeBlocks.Magic_RED_CANDLE_CAKE, method_46021(class_2246.field_27140));
        method_45988(UsefulFoodCakeBlocks.Magic_BLACK_CANDLE_CAKE, method_46021(class_2246.field_27141));

        method_45988(UsefulFoodCakeBlocks.CaramelCake, method_45975());
        method_45988(UsefulFoodCakeBlocks.Caramel_CANDLE_CAKE, method_46021(class_2246.field_27099));
        method_45988(UsefulFoodCakeBlocks.Caramel_WHITE_CANDLE_CAKE, method_46021(class_2246.field_27100));
        method_45988(UsefulFoodCakeBlocks.Caramel_ORANGE_CANDLE_CAKE, method_46021(class_2246.field_27101));
        method_45988(UsefulFoodCakeBlocks.Caramel_MAGENTA_CANDLE_CAKE, method_46021(class_2246.field_27102));
        method_45988(UsefulFoodCakeBlocks.Caramel_LIGHT_BLUE_CANDLE_CAKE, method_46021(class_2246.field_27103));
        method_45988(UsefulFoodCakeBlocks.Caramel_YELLOW_CANDLE_CAKE, method_46021(class_2246.field_27104));
        method_45988(UsefulFoodCakeBlocks.Caramel_LIME_CANDLE_CAKE, method_46021(class_2246.field_27105));
        method_45988(UsefulFoodCakeBlocks.Caramel_PINK_CANDLE_CAKE, method_46021(class_2246.field_27106));
        method_45988(UsefulFoodCakeBlocks.Caramel_GRAY_CANDLE_CAKE, method_46021(class_2246.field_27107));
        method_45988(UsefulFoodCakeBlocks.Caramel_LIGHT_GRAY_CANDLE_CAKE, method_46021(class_2246.field_27108));
        method_45988(UsefulFoodCakeBlocks.Caramel_CYAN_CANDLE_CAKE, method_46021(class_2246.field_27109));
        method_45988(UsefulFoodCakeBlocks.Caramel_PURPLE_CANDLE_CAKE, method_46021(class_2246.field_27110));
        method_45988(UsefulFoodCakeBlocks.Caramel_BLUE_CANDLE_CAKE, method_46021(class_2246.field_27111));
        method_45988(UsefulFoodCakeBlocks.Caramel_BROWN_CANDLE_CAKE, method_46021(class_2246.field_27112));
        method_45988(UsefulFoodCakeBlocks.Caramel_GREEN_CANDLE_CAKE, method_46021(class_2246.field_27113));
        method_45988(UsefulFoodCakeBlocks.Caramel_RED_CANDLE_CAKE, method_46021(class_2246.field_27140));
        method_45988(UsefulFoodCakeBlocks.Caramel_BLACK_CANDLE_CAKE, method_46021(class_2246.field_27141));
    }
}
