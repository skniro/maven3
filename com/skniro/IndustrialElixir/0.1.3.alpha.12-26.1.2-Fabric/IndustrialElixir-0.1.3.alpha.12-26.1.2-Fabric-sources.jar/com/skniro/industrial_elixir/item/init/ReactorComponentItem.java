package com.skniro.industrial_elixir.item.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class ReactorComponentItem extends Item {
    public enum ComponentType {
        SEPTRIN_FUEL_ROD,
        DUAL_SEPTRIN_FUEL_ROD,
        QUAD_SEPTRIN_FUEL_ROD,
        COOLANT_CELL,
        HEAT_VENT,
        REACTOR_PLATING,
        NEUTRON_REFLECTOR,
        HEAT_EXCHANGER
    }

    private final ComponentType componentType;

    public ReactorComponentItem(Properties properties, ComponentType componentType) {
        super(properties);
        this.componentType = componentType;
    }

    public ComponentType getComponentType() {
        return componentType;
    }

    public boolean isFuelRod() {
        return componentType == ComponentType.SEPTRIN_FUEL_ROD
                || componentType == ComponentType.DUAL_SEPTRIN_FUEL_ROD
                || componentType == ComponentType.QUAD_SEPTRIN_FUEL_ROD;
    }

    public int getRodCount() {
        return switch (componentType) {
            case DUAL_SEPTRIN_FUEL_ROD -> 2;
            case QUAD_SEPTRIN_FUEL_ROD -> 4;
            case SEPTRIN_FUEL_ROD -> 1;
            default -> 0;
        };
    }

    public int getCoolingPerTick(ItemStack stack) {
        return switch (componentType) {
            case COOLANT_CELL -> 12;
            default -> 0;
        };
    }

    public int getHeatVentCoolingAmount() {
        return componentType == ComponentType.HEAT_VENT ? 6 : 0;
    }

    public int getHeatVentDamagePerUnitCooled() {
        return componentType == ComponentType.HEAT_VENT ? 1 : 0;
    }

    public int getHeatExchangerTransferAmount() {
        return componentType == ComponentType.HEAT_EXCHANGER ? 10 : 0;
    }

    public int getHeatExchangerCoolingAmount() {
        return componentType == ComponentType.HEAT_EXCHANGER ? 5 : 0;
    }

    public int getHeatExchangerDamagePerUnitTransferred() {
        return componentType == ComponentType.HEAT_EXCHANGER ? 1 : 0;
    }

    public int getExtraMaxHeat() {
        return componentType == ComponentType.REACTOR_PLATING ? 1000 : 0;
    }

    public int getNeutronReflectionBonus() {
        return componentType == ComponentType.NEUTRON_REFLECTOR ? 1 : 0;
    }
}
