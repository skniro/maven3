package com.skniro.growable_ores_extension.datagen.recipe;

import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class BaseMachineRecipeGenerator extends FabricRecipeProvider {
    public BaseMachineRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {
                method_62746(class_7800.field_40642, GrowableOresBlocks.COAL_GENERATOR)
                        .method_10434('G', GrowableOresBlocks.Iron_Furnace_Block).method_10434('E', GrowableOresItems.RE_BATTERY).method_10434('S', GrowableOresItems.IRON_PLATE)
                        .method_10439(" E ").method_10439("SSS").method_10439(" G ")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.RE_BATTERY)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.COAL_GENERATOR)
                        .method_10434('G', class_1802.field_8732).method_10434('E', GrowableOresItems.RE_BATTERY).method_10434('S', GeneralBlocks.Machine)
                        .method_10439(" E ").method_10439(" S ").method_10439(" G ")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.RE_BATTERY)).method_36443(this.field_53721,"base_machine_to_coal_generator");

                method_62746(class_7800.field_40642, GrowableOresBlocks.GENERATOR_SolarPanel)
                        .method_10434('G', class_1802.field_8280).method_10434('E', GrowableOresItems.COAL_DUST).method_10434('S', GrowableOresBlocks.COAL_GENERATOR).method_10434('C', GrowableOresItems.Circuit)
                        .method_10439("EGE").method_10439("GEG").method_10439("CSC")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.COAL_GENERATOR)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.GENERATOR_Wind_Mill)
                        .method_10434('G', class_1802.field_8620).method_10434('S', GrowableOresBlocks.COAL_GENERATOR)
                        .method_10439("G G").method_10439(" S ").method_10439("G G")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.COAL_GENERATOR)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.Compressor_Block)
                        .method_10434('G', class_1802.field_20391).method_10434('S', GeneralBlocks.Machine).method_10434('C', GrowableOresItems.Circuit)
                        .method_10439("G G").method_10439("GSG").method_10439("GCG")
                        .method_10429("has_item", this.method_10426(GeneralBlocks.Machine)).method_10431(this.field_53721);

                //临时配方
                method_62746(class_7800.field_40642, GrowableOresBlocks.Extractor_Block)
                        .method_10434('G', GrowableOresItems.Sticky_Resin).method_10434('S', GeneralBlocks.Machine).method_10434('C', GrowableOresItems.Circuit)
                        .method_10439("   ").method_10439("GSG").method_10439("GCG")
                        .method_10429("has_item", this.method_10426(GeneralBlocks.Machine)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.Iron_Furnace_Block)
                        .method_10434('G', GrowableOresItems.IRON_PLATE).method_10434('C', class_1802.field_8732)
                        .method_10439(" G ").method_10439("G G").method_10439("GCG")
                        .method_10429("has_item", this.method_10426(class_1802.field_8732)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.Macerator_Block)
                        .method_10434('G', class_1802.field_20391).method_10434('S', GeneralBlocks.Machine).method_10434('C', GrowableOresItems.Circuit).method_10434('F', class_1802.field_8145)
                        .method_10439("FFF").method_10439("GSG").method_10439(" C ")
                        .method_10429("has_item", this.method_10426(GeneralBlocks.Machine)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.MetalFormerBlock)
                        .method_10434('G', GrowableOresItems.BRONZE_CASING).method_10434('S', GeneralBlocks.Machine).method_10434('C', GrowableOresItems.Circuit).method_10434('F', GrowableOresItems.Coil)
                        .method_10439(" C ").method_10439("GSG").method_10439("FFF")
                        .method_10429("has_item", this.method_10426(GeneralBlocks.Machine)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.ChargePad)
                        .method_10434('G', class_1802.field_8667).method_10434('S', GrowableOresBlocks.EnergyBox).method_10434('C', GrowableOresItems.Circuit).method_10434('F', GrowableOresItems.Rubber)
                        .method_10439("   ").method_10439("CGC").method_10439("FSF")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.EnergyBox)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.CESU_CHARGE_PAD)
                        .method_10434('G', class_1802.field_8667).method_10434('S', GrowableOresBlocks.CESU).method_10434('C', GrowableOresItems.Circuit).method_10434('F', GrowableOresItems.Rubber)
                        .method_10439("   ").method_10439("CGC").method_10439("FSF")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.CESU)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.MFE_CHARGE_PAD)
                        .method_10434('G', class_1802.field_8667).method_10434('S', GrowableOresBlocks.MFE).method_10434('C', GrowableOresItems.Circuit).method_10434('F', GrowableOresItems.Rubber)
                        .method_10439("   ").method_10439("CGC").method_10439("FSF")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.MFE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.MFSU_CHARGE_PAD)
                        .method_10434('G', class_1802.field_8667).method_10434('S', GrowableOresBlocks.MFSU).method_10434('C', GrowableOresItems.Circuit).method_10434('F', GrowableOresItems.Rubber)
                        .method_10439("   ").method_10439("CGC").method_10439("FSF")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.MFSU)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.EnergyBox)
                        .method_10433('G', class_3489.field_15537).method_10434('S', GrowableOresBlocks.INSULATED_TIN_CABLE).method_10434('F', GrowableOresItems.RE_BATTERY)
                        .method_10439("GSG").method_10439("FFF").method_10439("GGG")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.INSULATED_TIN_CABLE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.CESU)
                        .method_10434('G', GrowableOresItems.BRONZE_PLATE).method_10434('S', GrowableOresBlocks.INSULATED_COPPER_CABLE).method_10434('F', GrowableOresItems.ADVANCED_RE_BATTERY)
                        .method_10439("GSG").method_10439("FFF").method_10439("GGG")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.INSULATED_COPPER_CABLE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.MFE)
                        .method_10434('G', GrowableOresItems.ENERGY_CRYSTAL).method_10434('S', GrowableOresBlocks.INSULATED_GOLD_CABLE).method_10434('F', GeneralBlocks.Machine)
                        .method_10439("SGS").method_10439("GFG").method_10439("SGS")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.INSULATED_GOLD_CABLE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.MFSU)
                        .method_10434('G', GrowableOresItems.LAPOTRON_CRYSTAL).method_10434('S', GeneralBlocks.Advanced_Machine).method_10434('F', GrowableOresBlocks.MFE).method_10434('C', GrowableOresItems.Advanced_Circuit)
                        .method_10439("GCG").method_10439("GFG").method_10439("GSG")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.MFE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.LV_TRANSFORMER)
                        .method_10433('G', class_3489.field_15537).method_10434('F', GrowableOresBlocks.INSULATED_TIN_CABLE).method_10434('C', GrowableOresItems.Coil)
                        .method_10439("GFG").method_10439("GCG").method_10439("GFG")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.INSULATED_TIN_CABLE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.MV_TRANSFORMER)
                        .method_10434('G', GeneralBlocks.Machine).method_10434('F', GrowableOresBlocks.INSULATED_COPPER_CABLE)
                        .method_10439(" F ").method_10439(" G ").method_10439(" F ")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.INSULATED_COPPER_CABLE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.HV_TRANSFORMER)
                        .method_10434('G', GrowableOresBlocks.MV_TRANSFORMER).method_10434('F', GrowableOresBlocks.INSULATED_GOLD_CABLE).method_10434('C', GrowableOresItems.Circuit).method_10434('R', GrowableOresItems.ADVANCED_RE_BATTERY)
                        .method_10439(" F ").method_10439("CGR").method_10439(" F ")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.INSULATED_GOLD_CABLE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresBlocks.EV_TRANSFORMER)
                        .method_10434('G', GrowableOresBlocks.HV_TRANSFORMER).method_10434('F', GrowableOresBlocks.INSULATED_HV_CABLE).method_10434('C', GrowableOresItems.Advanced_Circuit).method_10434('R', GrowableOresItems.LAPOTRON_CRYSTAL)
                        .method_10439(" F ").method_10439("CGR").method_10439(" F ")
                        .method_10429("has_item", this.method_10426(GrowableOresBlocks.INSULATED_HV_CABLE)).method_10431(this.field_53721);
            }
        };
    }

    @Override
    public String method_10321() {
        return "BaseMachine";
    }
}