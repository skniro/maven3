package com.skniro.maple.block.init;

import com.skniro.maple.particle.MapleParticleTypes;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2397;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public class MapleSakuraLeavesBlock extends class_2397 {
    public MapleSakuraLeavesBlock(class_2251 settings) {
        super(settings);
    }

    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        super.method_9496(state, world, pos, random);
        if (random.method_43048(10) == 0) {
            class_2338 blockPos = pos.method_10074();
            class_2680 blockState = world.method_8320(blockPos);
            if (!method_9501(blockState.method_26220(world, blockPos), class_2350.field_11036)) {
                spawnParticle(world, pos, random, MapleParticleTypes.SAKURA_LEAVES);
            }
        }
    }

    public static void spawnParticle(class_1937 world, class_2338 pos, class_5819 random, class_2394 effect) {
        double d = (double)pos.method_10263() + random.method_43058();
        double e = (double)pos.method_10264() - 0.05D;
        double f = (double)pos.method_10260() + random.method_43058();
        world.method_8406(effect, d, e, f, 0.0D, 0.0D, 0.0D);
    }
}
