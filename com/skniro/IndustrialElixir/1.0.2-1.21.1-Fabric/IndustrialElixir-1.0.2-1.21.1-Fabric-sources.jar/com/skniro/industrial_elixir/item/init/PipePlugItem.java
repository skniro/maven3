package com.skniro.industrial_elixir.item.init;

import com.skniro.industrial_elixir.block.entity.pipe.PipeBlockEntity;
import com.skniro.industrial_elixir.item.AdvancedItems;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;

public class PipePlugItem extends class_1792 {

    public PipePlugItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2338 pos = context.method_8037();
        class_2350 side = context.method_8038();
        class_1657 player = context.method_8036();

        class_2586 be = world.method_8321(pos);

        if (!(be instanceof PipeBlockEntity pipe)) {
            return class_1269.field_5811;
        }

        if (world.method_8608()) return class_1269.field_5812;

        if (pipe.isBlocked(side)) {

            pipe.setBlocked(side, false);

            if (!player.method_7337()) {
                class_1264.method_5449(world, pos.method_10263(), pos.method_10264(), pos.method_10260(),
                        new class_1799(AdvancedItems.PIPE_PLUG));
            }

        } else {
            pipe.setBlocked(side, true);

            if (!player.method_7337()) {
                context.method_8041().method_7934(1);
            }
        }

        world.method_8652(pos, world.method_8320(pos), class_2248.field_31036);

        return class_1269.field_5812;
    }
}