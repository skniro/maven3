package com.skniro.industrial_elixir.block.entity.pipe;

import net.minecraft.class_2350;
import org.jetbrains.annotations.Nullable;

public interface PipeExtractDirectionController {

    @Nullable
    class_2350 getPreferredExtractDirection();

    boolean setPreferredExtractDirection(@Nullable class_2350 direction);

    default boolean clearPreferredExtractDirection() {
        return setPreferredExtractDirection(null);
    }

    default boolean togglePreferredExtractDirection(class_2350 direction) {
        if (getPreferredExtractDirection() == direction) {
            return clearPreferredExtractDirection();
        }
        return setPreferredExtractDirection(direction);
    }
}
