package com.skniro.blackhold.datagen;

import com.skniro.blackhold.block.*;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;


public class MapleLootTableGenerator extends FabricBlockLootTableProvider {
    public MapleLootTableGenerator(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataGenerator, registryLookup);
    }
    public static final float[] field_40605 = new float[]{0.048F, 0.0425F, 0.062333336F, 0.1F};

    @Override
    public void method_10379() {

        method_46025(FurnitureDrawBlocks.Oak_Allay_Draw);
        method_46025(FurnitureDrawBlocks.Spruce_Allay_Draw);
        method_46025(FurnitureDrawBlocks.Birch_Allay_Draw);
        method_46025(FurnitureDrawBlocks.Jungle_Allay_Draw);
        method_46025(FurnitureDrawBlocks.Acacia_Allay_Draw);
        method_46025(FurnitureDrawBlocks.DarkOak_Allay_Draw);
        method_46025(FurnitureDrawBlocks.Mangrove_Allay_Draw);
        method_46025(FurnitureDrawBlocks.Bamboo_Allay_Draw);
        method_46025(FurnitureDrawBlocks.Cherry_Allay_Draw);
        method_46025(FurnitureDrawBlocks.Crimson_Allay_Draw);
        method_46025(FurnitureDrawBlocks.Warped_Allay_Draw);
        method_46025(FurnitureDrawBlocks.PaleOak_Allay_Draw);
    }
}
