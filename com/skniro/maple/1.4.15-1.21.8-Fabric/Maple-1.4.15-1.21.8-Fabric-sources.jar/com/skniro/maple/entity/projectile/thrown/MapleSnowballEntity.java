package com.skniro.maple.entity.projectile.thrown;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1545;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2392;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_3857;
import net.minecraft.class_3966;
import net.minecraft.class_6024;

public class MapleSnowballEntity
        extends class_3857 {
    public MapleSnowballEntity(class_1299<? extends MapleSnowballEntity> entityType, class_1937 world) {
        super((class_1299<? extends class_3857>)entityType, world);
    }

    public MapleSnowballEntity(class_1937 world, class_1309 owner, class_1799 stack) {
        super(class_1299.field_6068, owner, world, stack);
    }

    public MapleSnowballEntity(class_1937 world, double x, double y, double z, class_1799 stack) {
        super(class_1299.field_6068, x, y, z, world, stack);
    }

    @Override
    protected class_1792 method_16942() {
        return class_1802.field_8543;
    }

    private class_2394 getParticleParameters() {
        class_1799 itemStack = this.method_7495();
        return itemStack.method_7960() ? class_2398.field_11230 : new class_2392(class_2398.field_11218, itemStack);
    }

    @Override
    public void method_5711(byte status) {
        if (status == class_6024.field_30028) {
            class_2394 particleEffect = this.getParticleParameters();
            for (int i = 0; i < 8; ++i) {
                this.method_37908().method_8406(particleEffect, this.method_23317(), this.method_23318(), this.method_23321(), 0.0, 0.0, 0.0);
            }
        }
    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {
        super.method_7454(entityHitResult);
        class_1297 entity = entityHitResult.method_17782();
        int i = entity instanceof class_1545 ? 3 : 0;
        entity.method_64419(this.method_48923().method_48811(this, this.method_24921()), i);
    }

    @Override
    protected void method_7488(class_239 hitResult) {
        super.method_7488(hitResult);
        if (!this.method_37908().field_9236) {
            this.method_37908().method_8421(this, class_6024.field_30028);
            this.method_31472();
        }
    }
}
