package com.skniro.skniro_furniture.block.entity;

import com.skniro.skniro_furniture.block.api.entity.ImplementedInventory;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public class PlateBlockEntity extends class_2586 implements ImplementedInventory {
    private final class_2371<class_1799> inventory = class_2371.method_10213(1, class_1799.field_8037);

    public PlateBlockEntity(class_2338 pos, class_2680 state) {
        super(FurnitureBlockEntityType.Plate_BLOCK_ENTITY, pos, state);
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }

    @Override
    protected void method_11007(class_11372 nbt) {
        super.method_11007(nbt);
        class_1262.method_5426(nbt, inventory);
    }

    @Override
    protected void method_11014(class_11368 nbt) {
        super.method_11014(nbt);
        class_1262.method_5429(nbt, inventory);
    }

    public class_1799 getRenderStack() {
        return this.method_5438(0);
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}