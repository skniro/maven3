package com.skniro.industrial_elixir.mixin;

import com.skniro.industrial_elixir.api.item.EnergyTooltipHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

@Mixin(class_1792.class)
public class ItemTooltipMixin {

    @Inject(method = "appendHoverText", at = @At("HEAD"))
    public void icr$appendEnergyTooltip(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 flag, CallbackInfo ci) {
        EnergyTooltipHelper.appendEnergyTooltip(stack, tooltip::add);
    }
}
