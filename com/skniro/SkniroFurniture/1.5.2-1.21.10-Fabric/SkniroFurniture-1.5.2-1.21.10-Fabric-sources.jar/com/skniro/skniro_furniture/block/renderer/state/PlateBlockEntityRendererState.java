package com.skniro.skniro_furniture.block.renderer.state;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10444;
import net.minecraft.class_11954;
import java.util.Collections;
import java.util.List;

@Environment(EnvType.CLIENT)
public class PlateBlockEntityRendererState extends class_11954 {
    public final class_10444 item = new class_10444();
}