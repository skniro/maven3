package com.skniro.industrial_elixir.item.init;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1301;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3468;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

/**
 * 26.1's {@code BoatItem} is built from an {@link class_1299}; 1.21.1's vanilla {@code BoatItem} is built
 * from a {@code Boat.Type} and always spawns the vanilla boat entities. This item keeps the 26.1
 * behaviour of placing the entity type it was given.
 */
public class ModBoatItem extends class_1792 {
    private static final Predicate<class_1297> ENTITY_PREDICATE = class_1301.field_6155.and(class_1297::method_5863);

    private final class_1299<? extends class_1690> boatType;

    public ModBoatItem(class_1299<? extends class_1690> boatType, class_1792.class_1793 properties) {
        super(properties);
        this.boatType = boatType;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        class_3965 hitResult = method_7872(level, player, class_3959.class_242.field_1347);
        if (hitResult.method_17783() == class_239.class_240.field_1333) {
            return class_1271.method_22430(stack);
        }

        class_243 viewVector = player.method_5828(1.0F);
        double reach = 5.0;
        List<class_1297> nearby = level.method_8333(player, player.method_5829().method_18804(viewVector.method_1021(reach)).method_1014(1.0), ENTITY_PREDICATE);
        if (!nearby.isEmpty()) {
            class_243 eyePosition = player.method_33571();
            for (class_1297 entity : nearby) {
                class_238 boundingBox = entity.method_5829().method_1014((double)entity.method_5871());
                if (boundingBox.method_1006(eyePosition)) {
                    return class_1271.method_22430(stack);
                }
            }
        }

        if (hitResult.method_17783() != class_239.class_240.field_1332) {
            return class_1271.method_22430(stack);
        }

        class_1690 boat = this.createBoat(level, hitResult, stack, player);
        if (boat == null) {
            return class_1271.method_22430(stack);
        }

        if (!level.method_8608()) {
            level.method_8649(boat);
            if (!player.method_31549().field_7477) {
                stack.method_7934(1);
            }
        }

        player.method_7259(class_3468.field_15372.method_14956(this));
        return class_1271.method_29237(stack, level.method_8608());
    }

    private class_1690 createBoat(class_1937 level, class_239 hitResult, class_1799 stack, class_1657 player) {
        class_243 location = hitResult.method_17784();
        class_1690 boat = this.boatType.method_5883(level);
        if (boat == null) {
            return null;
        }

        boat.method_5814(location.field_1352, location.field_1351, location.field_1350);
        boat.method_36456(player.method_36454());
        if (!level.method_8587(boat, boat.method_5829().method_1014(-0.1))) {
            return null;
        }

        if (level instanceof class_3218 serverLevel) {
            class_1299.method_48009(serverLevel, stack, player).accept(boat);
        }

        return boat;
    }
}
