package com.skniro.chunk_loader.datagen;

import com.skniro.chunk_loader.block.GrowableOresBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagsProvider;
import net.minecraft.core.HolderLookup;
import net.minecraft.tags.BlockItemTags;
import net.minecraft.tags.BlockTags;

import java.util.concurrent.CompletableFuture;

import static net.minecraft.tags.BlockItemTags.LOGS_THAT_BURN;
import static net.minecraft.tags.BlockTags.*;

public class ChunkLoaderBlockTagGenerator extends FabricTagsProvider.BlockTagsProvider {
   public ChunkLoaderBlockTagGenerator(FabricPackOutput output, CompletableFuture<HolderLookup.Provider> completableFuture) {
        super(output, completableFuture);
   }
   @Override
   protected void addTags(HolderLookup.Provider arg) {
      builder(MINEABLE_WITH_PICKAXE)
              .add(GrowableOresBlocks.CHUNK_LOADER.builtInRegistryHolder().key())
              .setReplace(false);
      builder(NEEDS_IRON_TOOL)
              .add(GrowableOresBlocks.CHUNK_LOADER.builtInRegistryHolder().key())
              .setReplace(false);
   }
}