package com.skniro.growable_ores_extension.block.entity.machine;

import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import com.skniro.growable_ores_extension.recipe.AlchemyCraftingRecipeInput;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import com.skniro.growable_ores_extension.recipe.machine.AbstractMachineCraftingRecipe;
import com.skniro.growable_ores_extension.recipe.machine.RecyclerCraftingRecipe;
import com.skniro.growable_ores_extension.screen.machine.CompressorScreenHandler;
import com.skniro.growable_ores_extension.screen.machine.RecyclerScreenHandler;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3956;
import net.minecraft.class_8786;

public class RecyclerEntity extends AbstractMachineEntity {

    private static final int INPUT_SLOT = 1;
    private static final int OUTPUT_SLOT = 2;

    public RecyclerEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.Recycler_BLOCK_ENTITY ,pos, state);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Recycler);
    }

    public class_3956<?> getCurrentRecipeType() {
        return AlchemyRecipeType.RECYCLER.type;
    }

    @Override
    protected void craftItem() {
        Optional<class_8786<RecyclerCraftingRecipe>> recipe = getRecyclerRecipe();
        this.method_5434(INPUT_SLOT, 1);
        this.method_5447(OUTPUT_SLOT, new class_1799(recipe.get().comp_1933().output().method_7909(),
                this.method_5438(OUTPUT_SLOT).method_7947() + recipe.get().comp_1933().output().method_7947()));
    }

    protected Optional<class_8786<RecyclerCraftingRecipe>> getRecyclerRecipe() {
        return this.method_10997().method_8503().method_3772()
                .method_8132((class_3956<RecyclerCraftingRecipe>) getCurrentRecipeType(), new AlchemyCraftingRecipeInput(inventory.get(INPUT_SLOT)), this.method_10997());
    }

    @Override
    public boolean hasRecipe() {
        Optional<class_8786<RecyclerCraftingRecipe>> recipe = getRecyclerRecipe();
        if(recipe.isEmpty()) {
            return false;
        }

        class_1799 output = recipe.get().comp_1933().output();
        return canInsertAmountIntoOutputSlot(output.method_7947()) && canInsertItemIntoOutputSlot(output) && hasEnoughEnergyToCraft();
    }


    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new RecyclerScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }
}
