package com.skniro.growableores.client;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

@Environment(EnvType.CLIENT)
public class GrowableOresClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_7923.field_41175.forEach(block -> {
            class_2960 blockId = class_7923.field_41175.method_10221(block);
            if (blockId.method_12836().equals(GrowableOres.MOD_ID)) {
                BlockRenderLayerMap.INSTANCE.putBlock(block, class_1921.method_23581());
            }
        });
    }
}
