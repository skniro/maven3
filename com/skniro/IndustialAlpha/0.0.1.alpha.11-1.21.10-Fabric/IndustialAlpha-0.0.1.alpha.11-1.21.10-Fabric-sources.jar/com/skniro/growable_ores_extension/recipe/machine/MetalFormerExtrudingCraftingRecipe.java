package com.skniro.growable_ores_extension.recipe.machine;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.growable_ores_extension.block.entity.machine.MetalFormerBlockEntity;
import com.skniro.growable_ores_extension.recipe.AlchemyCraftingRecipeInput;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import net.minecraft.class_10355;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class MetalFormerExtrudingCraftingRecipe extends AbstractMachineCraftingRecipe {

    public MetalFormerExtrudingCraftingRecipe(class_1856 ingredients, int requiredCount, class_1799 output) {
        super(ingredients, requiredCount, output);
    }

    @Override
    public class_1865<? extends class_1860<AlchemyCraftingRecipeInput>> method_8119() {
        return AlchemyRecipeType.METALFORMER_EXTRUDING.serializer;
    }

    @Override
    public class_3956<? extends class_1860<AlchemyCraftingRecipeInput>> method_17716() {
        return AlchemyRecipeType.METALFORMER_EXTRUDING.type;
    }

    @Override
    public class_10355 method_64668() {
        return null;
    }

    public static class Serializer implements class_1865<MetalFormerExtrudingCraftingRecipe> {
        public static final MapCodec<MetalFormerExtrudingCraftingRecipe> CODEC =
                RecordCodecBuilder.mapCodec(inst -> inst.group(
                        class_1856.field_46095.fieldOf("ingredient")
                                .forGetter(recipe -> recipe.ingredient),

                        Codec.INT.fieldOf("count")
                                .forGetter(recipe -> recipe.requiredCount),

                        class_1799.field_24671.fieldOf("result")
                                .forGetter(recipe -> recipe.output)

                ).apply(inst, MetalFormerExtrudingCraftingRecipe::new));

        public static final class_9139<class_9129, MetalFormerExtrudingCraftingRecipe> STREAM_CODEC =
                class_9139.method_56436(class_1856.field_48355, AbstractMachineCraftingRecipe::ingredient,
                        class_9135.field_49675, AbstractMachineCraftingRecipe::requiredCount,
                        class_1799.field_48349,AbstractMachineCraftingRecipe::output,
                        MetalFormerExtrudingCraftingRecipe::new);

        public Serializer() {
        }

        public MapCodec<MetalFormerExtrudingCraftingRecipe> method_53736() {
            return CODEC;
        }

        public class_9139<class_9129, MetalFormerExtrudingCraftingRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }
}
