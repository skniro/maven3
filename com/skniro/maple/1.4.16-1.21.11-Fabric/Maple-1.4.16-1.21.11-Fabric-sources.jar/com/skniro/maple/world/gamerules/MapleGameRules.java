package com.skniro.maple.world.gamerules;

import com.skniro.maple.Maple;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleBuilder;
import net.minecraft.class_12279;
import net.minecraft.class_2960;


public class MapleGameRules {
    public static final class_12279<Boolean> HOT_SPRING_SOURCE_CONVERSION =
            GameRuleBuilder.forBoolean(false).buildAndRegister(class_2960.method_60655(Maple.MOD_ID,"hot_spring_source_conversion"));

    public static void maplegamerule() {
    }
}
