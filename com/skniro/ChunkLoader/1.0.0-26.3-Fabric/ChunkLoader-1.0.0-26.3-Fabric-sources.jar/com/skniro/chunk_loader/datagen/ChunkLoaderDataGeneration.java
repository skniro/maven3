package com.skniro.chunk_loader.datagen;

import com.skniro.chunk_loader.datagen.recipe.RecipeDataGeneration;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.core.RegistrySetBuilder;

public class ChunkLoaderDataGeneration implements DataGeneratorEntrypoint {
    @Override
    public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {
        fabricDataGenerator.createPack().addProvider(ChunkLoaderModelProvider::new);
        fabricDataGenerator.createPack().addProvider(ChunkLoaderLootTableGenerator::new);
        fabricDataGenerator.createPack().addProvider(ChunkLoaderEnglishLanguageProvider::new);
        fabricDataGenerator.createPack().addProvider(ChunkLoaderSimplifiedChineseLanguageProvider::new);
        fabricDataGenerator.createPack().addProvider(ChunkLoaderBlockTagGenerator::new);
        fabricDataGenerator.createPack().addProvider(ChunkLoaderItemTagGenerator::new);
        RecipeDataGeneration.onInit(fabricDataGenerator);
    }

    @Override
    public void buildRegistry(RegistrySetBuilder registryBuilder) {
    }
}
