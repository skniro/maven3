package com.skniro.maple.entity.furniture;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2945;

public class ChairEntity extends class_1297 {
    public ChairEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {

    }

    @Override
    protected void method_5749(class_2487 nbt) {

    }

    @Override
    protected void method_5652(class_2487 nbt) {

    }

    @Override
    protected void method_5793(class_1297 passenger) {
        super.method_5793(passenger);
        this.method_5768();
    }
}