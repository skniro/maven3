package com.skniro.industrial_elixir.block.entity.generator;

import com.skniro.industrial_elixir.api.block.ImplementedInventory;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.energy.heat.api.base.SimpleSidedHeatContainer;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.EnergyStorageUtil;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.init.ReactorComponentItem;
import com.skniro.industrial_elixir.screen.handler.generator.SacredGeneratorScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class SacredGeneratorBlockEntity extends NewBaseGeneratorBlockEntity {
    public static final int GRID_WIDTH = 3;
    public static final int GRID_HEIGHT = 3;
    public static final int REACTOR_SLOT_COUNT = GRID_WIDTH * GRID_HEIGHT; // 9

    private final class_2371<class_1799> inventory = class_2371.method_10213(REACTOR_SLOT_COUNT + 5, class_1799.field_8037);
    protected final class_3913 propertyDelegate;

    // Heat storage (client-visible) and generation
    public final SimpleSidedHeatContainer heatContainer;
    private int generation;
    private boolean active;
    private static final int ENERGY_PER_PULSE = 128;
    private static final int ENERGY_TRANSFER_AMOUNT = 320;
    private static final int DURABILITY_TICK_INTERVAL = 40; // 1 durability point per 2 seconds
    private int durabilityTickCounter = 0;

    public SacredGeneratorBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.SACRED_GENERATOR_BE, pos, state);

        this.heatContainer = new SimpleSidedHeatContainer() {
            @Override
            public long getCapacity() {
                return 5000;
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                if (side == null) return 200;
                return 0;
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                return 200;
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(pos, method_11010(), method_11010(), 3);
            }
        };

        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> (int) Math.min(Integer.MAX_VALUE, heatContainer.getSideStorage(null).getAmount());
                    case 1 -> (int) Math.min(Integer.MAX_VALUE, heatContainer.getSideStorage(null).getCapacity());
                    case 2 -> SacredGeneratorBlockEntity.this.generation;
                    case 3 -> (int) Math.min(Integer.MAX_VALUE, SacredGeneratorBlockEntity.this.energyContainer.amount);
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                if (index == 2) {
                    SacredGeneratorBlockEntity.this.generation = value;
                } else if (index == 3) {
                    SacredGeneratorBlockEntity.this.energyContainer.amount = value;
                }
            }

            @Override
            public int method_17389() {
                return 4;
            }
        };
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        class_1262.method_5426(nbt, inventory, registries);
        nbt.method_10544("sacred_generator.energy", energyContainer.amount);
        nbt.method_10544("sacred_generator.heat", heatContainer.amount);
        nbt.method_10544("sacred_generator.max_heat", heatContainer.getSideStorage(null).getCapacity());
        nbt.method_10569("sacred_generator.generation", generation);
        nbt.method_10556("sacred_generator.active", active);
        nbt.method_10569("sacred_generator.durability_tick_counter", durabilityTickCounter);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        class_1262.method_5429(nbt, inventory, registries);
        energyContainer.amount = (nbt.method_10545("sacred_generator.energy") ? nbt.method_10537("sacred_generator.energy") : 0);
        heatContainer.amount = (nbt.method_10545("sacred_generator.heat") ? nbt.method_10537("sacred_generator.heat") : 0);
        generation = (nbt.method_10545("sacred_generator.generation") ? nbt.method_10550("sacred_generator.generation") : 0);
        active = (nbt.method_10545("sacred_generator.active") ? nbt.method_10577("sacred_generator.active") : false);
        durabilityTickCounter = (nbt.method_10545("sacred_generator.durability_tick_counter") ? nbt.method_10550("sacred_generator.durability_tick_counter") : 0);
        super.method_11014(nbt, registries);
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2371<class_1799> getItems() {
        return this.inventory;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.SacredReactor);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new SacredGeneratorScreenHandler(syncId, playerInventory, this, this.propertyDelegate);
    }
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world == null || world.method_8608()) return;

        // charge batteries and push energy out
        discharge(10);
        discharge(11);
        discharge(12);
        discharge(13);
        pushEnergyToNeighbours();

        generation = 0;

        // require redstone signal to run
        boolean powered = world.method_49803(pos);

        // center is the fuel rod (index 4)
        int centerIndex = (GRID_WIDTH * GRID_HEIGHT) / 2;
        class_1799 center = inventory.get(centerIndex);
        if (powered && center.method_7909() instanceof ReactorComponentItem component && component.isFuelRod()) {
            int pulses = component.getRodCount();
            generation += pulses * ENERGY_PER_PULSE;
            long heatGenerated = pulses * 4L;
            try (Transaction tx = Transaction.openOuter()) {
                heatContainer.getSideStorage(null).insert(heatGenerated, tx);
                tx.commit();
            }
            // fuel rod is NOT consumed or damaged
        }

        if (generation > 0) insertGeneratedEnergy(generation);

        // Cooling: outer ring slots provide cooling and take durability
        coolOuterRing();

        active = generation > 0 && powered;

        // update block lit state if present
        class_2248 block = method_11010().method_26204();
        if (block instanceof AbstractMachineblock) {
            boolean lit = active;
            if (state.method_28498(AbstractMachineblock.LIT) && state.method_11654(AbstractMachineblock.LIT) != lit) {
                world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, lit), 3);
            }
        }
        // if heat reached capacity -> explode (100%)
        long heat = heatContainer.getSideStorage(null).getAmount();
        long cap = heatContainer.getSideStorage(null).getCapacity();
        if (heat >= cap && cap > 0) {
            meltdown(world, pos);
            return;
        }

        method_31663(world, pos, state);
    }

    private void meltdown(class_1937 world, class_2338 pos) {
        // drop inventory and explode, similar to NuclearReactor
        class_1264.method_5451(world, pos, this);
        world.method_8650(pos, false);
        world.method_8537(null, pos.method_10263(), pos.method_10264(), pos.method_10260(), 100.0f, true, class_1937.class_7867.field_40889);
        world.method_8537(null, pos.method_10263(), pos.method_10264(), pos.method_10260(), 100.0f, true, class_1937.class_7867.field_40889);
        world.method_8537(null, pos.method_10263(), pos.method_10264(), pos.method_10260(), 100.0f, true, class_1937.class_7867.field_40889);
    }

    public void pushEnergyToNeighbours() {
        if (energyContainer.amount <= 0) return;
        for (class_2350 direction : class_2350.values()) {
            EnergyStorage target = EnergyStorage.SIDED.find(field_11863, field_11867.method_10093(direction), direction.method_10153());
            if (target == null) continue;
            EnergyStorageUtil.move(this.energyContainer.getSideStorage(direction), target, ENERGY_TRANSFER_AMOUNT, null);
        }
    }


    public boolean canInsert(class_1799 stack) {
        return stack.method_7909() instanceof ReactorComponentItem;
    }

    private void fillUpOnEnergy() {
        try (Transaction transaction = Transaction.openOuter()) {
            this.energyContainer.getSideStorage(null).insert(((AbstractMachineblock)method_11010().method_26204()).getEnergyTier().getMaxInput(), transaction);
            transaction.commit();
        }
    }
    private void insertGeneratedEnergy(int amount) {
        try (Transaction transaction = Transaction.openOuter()) {
            energyContainer.getSideStorage(null).insert(amount, transaction);
            transaction.commit();
        }
    }

    private void coolOuterRing() {
        durabilityTickCounter++;

        // Only apply durability damage every DURABILITY_TICK_INTERVAL (40) ticks = 2 seconds
        boolean shouldApplyDamage = durabilityTickCounter >= DURABILITY_TICK_INTERVAL;
        if (shouldApplyDamage) {
            durabilityTickCounter = 0;
        }

        int[] outer = new int[]{0,1,2,3,5,6,7,8};
        for (int slot : outer) {
            class_1799 stack = inventory.get(slot);
            if (!(stack.method_7909() instanceof ReactorComponentItem component)) continue;

            int cooling = 0;

            switch (component.getComponentType()) {
                case COOLANT_CELL, HEAT_VENT, ADVANCED_HEAT_VENT, OVERCLOCKED_HEAT_VENT -> {
                    cooling = component.getCoolingPerTick(stack);
                }
                case HEAT_EXCHANGER -> {
                    cooling = component.getHeatExchangerCoolingAmount();
                }
                default -> {}
            }

            if (cooling > 0 && heatContainer.getSideStorage(null).getAmount() > 0) {
                int actualCooling = (int) Math.min(heatContainer.getSideStorage(null).getAmount(), cooling);
                try (Transaction tx = Transaction.openOuter()) {
                    heatContainer.getSideStorage(null).extract(actualCooling, tx);
                    tx.commit();
                }
                // Apply 1 durability damage only once every 40 ticks
                if (shouldApplyDamage) {
                    switch (component.getComponentType()) {
                        case COOLANT_CELL -> {
                            damageOrConsume(stack, slot,component.getCoolingPerTick(stack));
                        }
                        case  HEAT_VENT, ADVANCED_HEAT_VENT, OVERCLOCKED_HEAT_VENT -> {
                            damageOrConsume(stack, slot,1);
                        }
                        default -> {}
                    }

                }
            }
        }
    }

    public void discharge(int slot) {
        if (this.field_11863 != null) {
            if (!this.field_11863.method_8608()) {
                if (!this.getOptionalInventory().isEmpty()) {
                    class_1263 inventory = this.getOptionalInventory().get();
                    EnergyStorageUtil.move(this.getSideEnergyStorage(null), ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(slot)).find(EnergyStorage.ITEM), Long.MAX_VALUE, null);
                }
            }
        }
    }

    private void damageOrConsume(class_1799 stack, int slot, int amount) {
        if (!stack.method_7963()) return;
        stack.method_7974(stack.method_7919() + amount);
        if (stack.method_7919() >= stack.method_7936()) {
            inventory.set(slot, class_1799.field_8037);
        }
    }

    public int getHeat() {
        return (int) Math.min(Integer.MAX_VALUE, heatContainer.getSideStorage(null).getAmount());
    }

    public long getHeatCapacity() {
        return heatContainer.getSideStorage(null).getCapacity();
    }

    public int getGeneration() {
        return generation;
    }

    public long getFreeSpace() {
        return this.energyContainer.getCapacity() - energyContainer.amount;
    }

    public Optional<ImplementedInventory> getOptionalInventory() {
        if (this instanceof ImplementedInventory inventory) {
            return inventory == null ? Optional.empty() : Optional.of(inventory);
        } else {
            return Optional.empty();
        }
    }


    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}