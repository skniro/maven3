package com.skniro.growable_ores_extension.block.entity;
import java.util.Optional;

import com.skniro.growable_ores_extension.block.Alchemyblock;
import com.skniro.growable_ores_extension.recipe.AlchemyCraftingRecipe;
import com.skniro.growable_ores_extension.recipe.AlchemyCraftingRecipeInput;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import com.skniro.growable_ores_extension.screen.AlchemyBlockScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_11566;
import net.minecraft.class_1262;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;

public class Alchemyblockentity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory, class_11566 {
    private final class_2371<class_1799> inventory = class_2371.method_10213(4, class_1799.field_8037);
    private float rotation = 0;
    private static final int FLUID_ITEM_SLOT = 0;
    private static final int INPUT_SLOT = 1;
    private static final int OUTPUT_SLOT = 2;
    private static final int ENERGY_ITEM_SLOT = 3;

    protected final class_3913 propertyDelegate;
    private int progress = 0;
    private int maxProgress = 72;
    private final int DEFAULT_MAX_PROGRESS = 72;

    public Alchemyblockentity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.ALCHEMY_BLOCK_ENTITY, pos, state);
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> Alchemyblockentity.this.progress;
                    case 1 -> Alchemyblockentity.this.maxProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: Alchemyblockentity.this.progress = value;
                    case 1: Alchemyblockentity.this.maxProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };
    }

    public class_1799 getRenderStack() {
            return this.method_5438(INPUT_SLOT);
    }
    @Override
    public void method_5431() {
        field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        super.method_5431();
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471("gui.growableores.cane_converter");
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new AlchemyBlockScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    @Override
    protected void method_11007(class_11372 nbt) {
        super.method_11007(nbt);
        class_1262.method_5426(nbt, inventory);
        nbt.method_71465("cane_converter.progress", progress);
        nbt.method_71465("cane_converter.max_progress", maxProgress);
    }

    @Override
    protected void method_11014(class_11368 nbt) {
        class_1262.method_5429(nbt, inventory);
        progress = nbt.method_71424("cane_converter.progress", 0);
        maxProgress = nbt.method_71424("cane_converter.max_progress", 72);
        super.method_11014(nbt);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if(world.method_8608()) {
            return;
        }
        if(hasRecipe() && canInsertIntoOutputSlot()) {
            increaseCraftingProgress();
            method_31663(world, pos, state);

            if(hasCraftingFinished()) {
                craftItem();
                resetProgress();
            }
        } else {
            resetProgress();
        }
    }


    private void resetProgress() {
        this.progress = 0;
        this.maxProgress = DEFAULT_MAX_PROGRESS;
    }

    private void craftItem() {
        Optional<class_8786<AlchemyCraftingRecipe>> recipe = getCurrentRecipe();
        this.method_5434(INPUT_SLOT, 1);
        this.method_5447(OUTPUT_SLOT, new class_1799(recipe.get().comp_1933().output().method_7909(),
                this.method_5438(OUTPUT_SLOT).method_7947() + recipe.get().comp_1933().output().method_7947()));
    }

    @Override
    public int[] method_5494(class_2350 direction) {
        if (direction != class_2350.field_11033) {
            return new int[]{INPUT_SLOT};
        } else {
            return new int[]{OUTPUT_SLOT};
        }
    }
    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return slot != OUTPUT_SLOT;
    }

    private boolean hasCraftingFinished() {
        return this.progress >= this.maxProgress;
    }

    private void increaseCraftingProgress() {
        this.progress++;
    }

    private boolean canInsertIntoOutputSlot() {
        return this.method_5438(OUTPUT_SLOT).method_7960() ||
                this.method_5438(OUTPUT_SLOT).method_7947() < this.method_5438(OUTPUT_SLOT).method_7914();
    }

    private boolean hasRecipe() {
        Optional<class_8786<AlchemyCraftingRecipe>> recipe = getCurrentRecipe();
        if(recipe.isEmpty()) {
            return false;
        }

        class_1799 output = recipe.get().comp_1933().output();
        return canInsertAmountIntoOutputSlot(output.method_7947()) && canInsertItemIntoOutputSlot(output);
    }
    private Optional<class_8786<AlchemyCraftingRecipe>> getCurrentRecipe() {
        return this.method_10997().method_8503().method_3772()
                .method_8132(AlchemyRecipeType.Cane_Converter_TYPE, new AlchemyCraftingRecipeInput(inventory.get(INPUT_SLOT)), this.method_10997());
    }

    private boolean canInsertItemIntoOutputSlot(class_1799 output) {
        return this.method_5438(OUTPUT_SLOT).method_7960() || this.method_5438(OUTPUT_SLOT).method_7909() == output.method_7909();
    }

    private boolean canInsertAmountIntoOutputSlot(int count) {
    int maxCount = this.method_5438(OUTPUT_SLOT).method_7960() ? 64 : this.method_5438(OUTPUT_SLOT).method_7914();
    int currentCount = this.method_5438(OUTPUT_SLOT).method_7947();

        return maxCount >= currentCount + count;
}

   @Nullable
   @Override
    public class_2596<class_2602> method_38235() {
    return class_2622.method_38585(this);
}


    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }

    @Override
    public class_1937 method_73183() {
        return this.field_11863;
    }

    @Override
    public class_243 method_73189() {
        return this.method_11016().method_46558();
    }

    @Override
    public float method_73188() {
        return this.method_11010().method_11654(Alchemyblock.FACING).method_10153().method_10164();
    }
}
