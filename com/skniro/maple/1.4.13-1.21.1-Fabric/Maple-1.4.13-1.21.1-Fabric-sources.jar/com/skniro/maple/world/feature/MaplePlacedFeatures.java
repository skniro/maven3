package com.skniro.maple.world.feature;

import com.skniro.maple.Maple;
import com.skniro.maple.block.MapleBlocks;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3003;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5843;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6817;
import net.minecraft.class_6819;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;
import net.minecraft.world.gen.placementmodifier.*;

import java.util.List;



public class MaplePlacedFeatures {
    public static final class_5321<class_6796> Maple_TREE_PLACED = registerKey("maple_tree_placed");
    public static final class_5321<class_6796> Red_Maple_TREE_PLACED = registerKey("red_maple_tree_placed");
    public static final class_5321<class_6796> CHERRY_TREE_PLACED= registerKey("cherry_tree_placed");;
    public static final class_5321<class_6796> SAKURA_TREE_PLACED= registerKey("sakura_tree_placed");;
    public static final class_5321<class_6796> MAGE_SAKURA_TREE_PLACED= registerKey("mage_sakura_tree_placed");;
    public static final class_5321<class_6796> SALT_ORE_PLACED = registerKey("ore_salt_overworld");
    public static final class_5321<class_6796> LAKE_HOT_SPRING_SURFACE = registerKey("lake_hot_spring_surface");
    public static final class_5321<class_6796> Coal_ORE_PLACED_KEY = registerKey("coal_ore_placed");
    public static final class_5321<class_6796> Nether_Copper_PLACED_KEY = registerKey("copper_ore_placed");
    public static final class_5321<class_6796> Nether_Diamond_PLACED_KEY = registerKey("diamond_ore_placed");
    public static final class_5321<class_6796> Nether_Emerald_PLACED_KEY = registerKey("emerald_ore_placed");
    public static final class_5321<class_6796> Nether_Gold_PLACED_KEY = registerKey("gold_ore_placed");
    public static final class_5321<class_6796> Nether_Iron_PLACED_KEY = registerKey("iron_ore_placed");
    public static final class_5321<class_6796> Nether_Lapis_PLACED_KEY = registerKey("lapis_ore_placed");
    public static final class_5321<class_6796> Nether_Redstone_PLACED_KEY = registerKey("redstone_ore_placed");
    public static final class_5321<class_6796> Sakura_carpet_PLACED_KEY = registerKey("sakura_carpet_placed");
    public static final class_5321<class_6796> Maple_carpet_PLACED_KEY = registerKey("maple_carpet_placed");
    public static final class_5321<class_6796> Red_Maple_carpet_PLACED_KEY = registerKey("red_maple_carpet_placed");
    public static final class_5321<class_6796> PATCH_TEA_COMMON = registerKey("patch_tea_common");
    public static final class_5321<class_6796> PATCH_TEA_RARE = registerKey("patch_tea_rare");

    public static void bootstrap(class_7891<class_6796> context) {
        var configuredFeatureRegistryEntryLookup = context.method_46799(class_7924.field_41239);

        class_6880<class_2975<?, ?>> registryEntry1 = configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.LAKE_HOT_SPRING);
        class_6880<class_2975<?, ?>> registryEntry2 = configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.PATCH_TEA);

        register(context, SALT_ORE_PLACED, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.SALT_ORE),
                modifiersWithCount(3, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(-80), class_5843.method_33841(30))));

        register(context, Maple_TREE_PLACED, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.Maple_TREE),
                class_6819.method_39741(class_6817.method_39736(3, 0.1f, 1), MapleBlocks.MAPLE_SAPLING));

        register(context, Red_Maple_TREE_PLACED, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.Red_Maple_TREE),
                class_6819.method_39741(class_6817.method_39736(3, 0.1f, 1), MapleBlocks.MAPLE_SAPLING));

        register(context, CHERRY_TREE_PLACED, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.CHERRY_TREE),
                class_6819.method_39741(class_6817.method_39736(1, 0.1f, 1), MapleBlocks.CHERRY_SAPLING));

        register(context, SAKURA_TREE_PLACED, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.SAKURA_TREE),
                class_6819.method_39741(class_6817.method_39736(1, 0.1f, 1), MapleBlocks.SAKURA_SAPLING));

        register(context, MAGE_SAKURA_TREE_PLACED, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.MAGE_SAKURA_TREE),
                class_6819.method_39741(class_6817.method_39736(1, 0.00001f, 1), MapleBlocks.SAKURA_SAPLING));

        register(context, LAKE_HOT_SPRING_SURFACE, registryEntry1, class_6799.method_39659(100), class_5450.method_39639(), class_6817.field_36078);
        register(context, Coal_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.Nether_Coal_ORE_KEY),
                modifiersWithCount(20, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context,Nether_Copper_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.Nether_Copper_KEY),
                modifiersWithCount(16, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Nether_Diamond_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.Nether_Diamond_KEY),
                modifiersWithCount(8, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Nether_Emerald_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.Nether_Emerald_KEY),
                modifiersWithCount(6, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Nether_Gold_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.Nether_Gold_KEY),
                modifiersWithCount(10, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Nether_Iron_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures. Nether_Iron_KEY),
                modifiersWithCount(16, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Nether_Lapis_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.Nether_Lapis_KEY),
                modifiersWithCount(10, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Nether_Redstone_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.Nether_Redstone_ORE_KEY),
                modifiersWithCount(10, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33841(0), class_5843.method_33841(256))));

        register(context, Sakura_carpet_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.Sakura_Carpet_KEY),
                class_3003.method_39642(-0.8, 4, 8),
                class_5450.method_39639(), class_6817.field_36080, class_6792.method_39614());

        register(context, Maple_carpet_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.Maple_Carpet_KEY),
                class_3003.method_39642(-0.8, 4, 8),
                class_5450.method_39639(), class_6817.field_36080, class_6792.method_39614());

        register(context, Red_Maple_carpet_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(MapleConfiguredFeatures.Red_Maple_Carpet_KEY),
                class_3003.method_39642(-0.8, 4, 8),
                class_5450.method_39639(), class_6817.field_36080, class_6792.method_39614());

        register(context, PATCH_TEA_COMMON, registryEntry2, class_6799.method_39659(32), class_5450.method_39639(), class_6817.field_36080, class_6792.method_39614());
        register(context, PATCH_TEA_RARE, registryEntry2, class_6799.method_39659(384), class_5450.method_39639(), class_6817.field_36080, class_6792.method_39614());
    }

    public static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(Maple.MOD_ID, name));
    }

    private static void register(class_7891<class_6796> context, class_5321<class_6796> key, class_6880<class_2975<?, ?>> configuration,
                                 List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(configuration, List.copyOf(modifiers)));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_6796> context, class_5321<class_6796> key,
                                                                                   class_6880<class_2975<?, ?>> configuration,
                                                                                   class_6797... modifiers) {
        register(context, key, configuration, List.of(modifiers));
    }

    // Used here because the vanilla ones are private
    private static List<class_6797> modifiers(class_6797 countModifier, class_6797 heightModifier) {
        return List.of(countModifier, class_5450.method_39639(), heightModifier, class_6792.method_39614());
    }

    private static List<class_6797> modifiersWithCount(int count, class_6797 heightModifier) {
        return modifiers(class_6793.method_39623(count), heightModifier);
    }

    private static List<class_6797> modifiersWithRarity(int chance, class_6797 heightModifier) {
        return modifiers(class_6799.method_39659(chance), heightModifier);
    }

    public static void registerPlacedFeatures() {
        Maple.LOGGER.debug("Registering the ModPlacedFeatures for " + Maple.MOD_ID);
    }
}
