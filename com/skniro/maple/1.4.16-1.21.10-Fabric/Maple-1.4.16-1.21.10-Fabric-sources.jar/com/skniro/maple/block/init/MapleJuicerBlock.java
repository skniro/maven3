package com.skniro.maple.block.init;


import com.mojang.serialization.MapCodec;
import com.skniro.maple.block.entity.MapleBlockEntityType;
import com.skniro.maple.block.entity.MapleJuicerBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.util.*;
import org.jetbrains.annotations.Nullable;

public class MapleJuicerBlock extends class_2237 {
    public static final MapCodec<MapleJuicerBlock> CODEC = method_54094(MapleJuicerBlock::new);

    public MapleJuicerBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    public static final class_2754<class_2350> FACING = class_2741.field_12481;


    private static class_265 SHAPE = class_2248.method_9541(5, 0, 5, 11, 14, 11);

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }
    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }
    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }
    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }


    /* BLOCK ENTITY */

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public void method_66388(class_2680 state, class_3218 world, class_2338 pos, boolean moved) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof MapleJuicerBlockEntity) {
            class_1264.method_5451(world, pos, (class_1263) blockEntity);
            world.method_8455(pos,this);
        }
        super.method_66388(state, world, pos, moved);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!world.method_8608()) {
            class_3908 screenHandlerFactory = state.method_26196(world, pos);

            if (screenHandlerFactory != null) {
                player.method_17355(screenHandlerFactory);
            }
        }

        return class_1269.field_5812;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new MapleJuicerBlockEntity(pos,state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, MapleBlockEntityType.MAPLE_JUICER_BLOCK_ENTITY_BLOCK_ENTITY_TYPE,
                (world1, pos, state1, blockEntity) -> blockEntity.tick(world1, pos, state1));
    }
}
