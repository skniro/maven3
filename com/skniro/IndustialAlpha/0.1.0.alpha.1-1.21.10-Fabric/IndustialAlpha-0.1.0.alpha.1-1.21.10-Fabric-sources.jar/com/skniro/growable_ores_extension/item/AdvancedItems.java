package com.skniro.growable_ores_extension.item;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import java.util.function.Function;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class AdvancedItems {
    public static final class_1792 IRRADIANT_URANIUM_INGOT = registerItem("irradiant_uranium", class_1792::new, new class_1792.class_1793());
    public static final class_1792 IRRADIANT_GLASS_PANE = registerItem("irradiant_glass_pane", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SUNNARIUM = registerItem("sunnarium", class_1792::new, new class_1792.class_1793());
    public static final class_1792 ENRICHED_SUNNARIUM = registerItem("enriched_sunnarium", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SUNNARIUM_ALLOY = registerItem("sunnarium_alloy", class_1792::new, new class_1792.class_1793());
    public static final class_1792 ENRICHED_SUNNARIUM_ALLOY = registerItem("enriched_sunnarium_alloy", class_1792::new, new class_1792.class_1793());
    public static final class_1792 IRIDIUM_IRON_PLATE = registerItem("iridium_iron_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 REINFORCED_IRIDIUM_IRON_PLATE = registerItem("reinforced_iridiumiron_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 IRRADIANT_REINFORCED_PLATE = registerItem("irradiant_reinforced_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SUNNARIUM_Part = registerItem("sunnarium_part", class_1792::new, new class_1792.class_1793());
    public static final class_1792 Iridium_INGOT = registerItem("iridium_ingot", class_1792::new, new class_1792.class_1793());
    public static final class_1792 Quantum_Core = registerItem("quantum_core", class_1792::new, new class_1792.class_1793());
    public static final class_1792 MT_Core = registerItem("mt_core", class_1792::new, new class_1792.class_1793());

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings.method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name))));
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)), item);
    }

    public static void registerAdvancedItem(){
        GrowableOresExtension.LOGGER.debug("register Advanced Item.");
    }
}
