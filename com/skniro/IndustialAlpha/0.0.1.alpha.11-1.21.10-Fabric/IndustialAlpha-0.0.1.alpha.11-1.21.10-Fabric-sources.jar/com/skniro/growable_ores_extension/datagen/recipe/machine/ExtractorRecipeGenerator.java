package com.skniro.growable_ores_extension.datagen.recipe.machine;

import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.item.AdvancedItems;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class ExtractorRecipeGenerator extends FabricRecipeProvider {
    public ExtractorRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {
                createExtractor(class_1802.field_8696, 4).input(class_1802.field_19060)
                        .method_33530("has_base_item", method_10426(class_1802.field_19060)).method_10431(field_53721);
                createExtractor(class_1802.field_8543, 4).input(class_1802.field_8246)
                        .method_33530("has_base_item", method_10426(class_1802.field_8246)).method_10431(field_53721);
                createExtractor(class_1802.field_8621, 4).input(class_1802.field_20390)
                        .method_33530("has_base_item", method_10426(class_1802.field_20390)).method_10431(field_53721);
                createExtractor(class_1802.field_8729, 4).input(class_1802.field_20398)
                        .method_33530("has_base_item", method_10426(class_1802.field_20398)).method_10431(field_53721);
                createExtractor(GrowableOresItems.Rubber).input(GeneralBlocks.Rubber_LOG)
                        .method_33530("has_base_item", method_10426(GeneralBlocks.Rubber_LOG)).method_10431(field_53721);
                createExtractor(GrowableOresItems.Rubber).input(GeneralBlocks.Rubber_Rubber_LOG)
                        .method_33530("has_base_item", method_10426(GeneralBlocks.Rubber_Rubber_LOG)).method_36443(field_53721,"rubber_log_to_rubber");
                createExtractor(GrowableOresItems.Rubber).input(GeneralBlocks.Rubber_SAPLING)
                        .method_33530("has_base_item", method_10426(GeneralBlocks.Rubber_SAPLING)).method_36443(field_53721,"rubber_sapling_to_rubber");
                createExtractor(GrowableOresItems.Rubber).input(GrowableOresItems.Sticky_Resin)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.Sticky_Resin)).method_36443(field_53721,"sticky_resin_to_rubber");
                createExtractor(GrowableOresItems.SULFUR_DUST).input(class_1802.field_8054)
                        .method_33530("has_base_item", method_10426(class_1802.field_8054)).method_10431(field_53721);
            }
        };
    }

    @Override
    public String method_10321() {
        return "Extractor";
    }
}
