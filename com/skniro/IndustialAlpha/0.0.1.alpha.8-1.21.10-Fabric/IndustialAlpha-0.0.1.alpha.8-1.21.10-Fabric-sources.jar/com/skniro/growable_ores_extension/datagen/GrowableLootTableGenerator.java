package com.skniro.growable_ores_extension.datagen;


import com.skniro.growable_ores_extension.block.MapleSignBlocks;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;


public class GrowableLootTableGenerator extends FabricBlockLootTableProvider {
    protected GrowableLootTableGenerator(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }
    public static final float[] field_40605 = new float[]{0.048F, 0.0425F, 0.062333336F, 0.1F};


    @Override
    public void method_10379() {
        //MAPLE
        method_46025(MapleSignBlocks.Rubber_SIGN);
        method_46025(MapleSignBlocks.Rubber_WALL_SIGN);
        method_46025(MapleSignBlocks.Rubber_HANGING_SIGN);
        method_46025(MapleSignBlocks.Rubber_WALL_HANGING_SIGN);
        method_46025(GeneralBlocks.Rubber_LOG);
        method_46025(GeneralBlocks.Rubber_Rubber_LOG);
        method_46025(GeneralBlocks.Rubber_WOOD);
        method_45988(GeneralBlocks.Rubber_DOOR, method_46022(GeneralBlocks.Rubber_DOOR));
        method_46025(GeneralBlocks.Rubber_SAPLING);
        method_45988(GeneralBlocks.Rubber_LEAVES, method_45986(GeneralBlocks.Rubber_LEAVES, GeneralBlocks.Rubber_SAPLING, field_40605));
        method_46025(GeneralBlocks.Rubber_BUTTON);
        method_46025(GeneralBlocks.Rubber_FENCE);
        method_46025(GeneralBlocks.Rubber_FENCE_GATE);
        method_46025(GeneralBlocks.Rubber_PLANKS);
        method_46025(GeneralBlocks.Rubber_PRESSURE_PLATE);
        method_46025(GeneralBlocks.Rubber_SLAB);
        method_46025(GeneralBlocks.Rubber_STAIRS);
        method_46025(GeneralBlocks.Rubber_TRAPDOOR);
        method_46025(GeneralBlocks.STRIPPED_Rubber_LOG);
        method_46025(GeneralBlocks.STRIPPED_Rubber_WOOD);

    }
}
