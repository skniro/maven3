package com.skniro.industrial_elixir.datagen;

import com.skniro.industrial_elixir.api.Helper;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;


public class IndustrialElixirBiomeTagGeneration extends FabricTagProvider<class_1959> {


    public IndustrialElixirBiomeTagGeneration(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, class_7924.field_41236, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        // generate tags under data/maple/tags/worldgen/biome/has_structure/
        class_6862<class_1959> villageSakura = class_6862.method_40092(class_7924.field_41236, Helper.id("has_structure/industrial_elixir_hot_spring_baths"));
        getOrCreateTagBuilder(villageSakura).method_46835(class_5321.method_29179(class_7924.field_41236, class_2960.method_60655("minecraft", "cherry_grove")));
    }
}
