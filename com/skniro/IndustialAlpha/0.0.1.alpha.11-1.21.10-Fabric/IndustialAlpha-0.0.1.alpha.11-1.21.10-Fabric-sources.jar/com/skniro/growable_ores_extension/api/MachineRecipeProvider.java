package com.skniro.growable_ores_extension.api;

import com.skniro.growable_ores_extension.recipe.machine.AbstractMachineCraftingRecipe;
import net.minecraft.class_3956;

@FunctionalInterface
public interface MachineRecipeProvider {

    class_3956<?> getCurrentRecipeType();

}