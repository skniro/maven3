package com.skniro.growable_ores_extension.compat;

import com.skniro.growable_ores_extension.compat.display.MaceratorDisplay;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import com.skniro.growable_ores_extension.recipe.machine.MaceratorCraftingRecipe;
import me.shedaniel.rei.api.common.display.DisplaySerializerRegistry;
import me.shedaniel.rei.api.common.plugins.REICommonPlugin;
import me.shedaniel.rei.api.common.registry.display.ServerDisplayRegistry;

public class IndustrialModREICommon implements REICommonPlugin {

    @Override
    public String getPluginProviderName() {
        return "IndustrialAlpha";
    }

    @Override
    public void registerDisplays(ServerDisplayRegistry registry) {
        registry.beginRecipeFiller(MaceratorCraftingRecipe.class)
                .filterType(AlchemyRecipeType.MACERATOR.type)
                .fill(MaceratorDisplay::new);
    }

    @Override
    public void registerDisplaySerializer(DisplaySerializerRegistry registry) {
        registry.register(MaceratorCategory.MACERATOR.getIdentifier(), MaceratorDisplay.SERIALIZER);
    }
}