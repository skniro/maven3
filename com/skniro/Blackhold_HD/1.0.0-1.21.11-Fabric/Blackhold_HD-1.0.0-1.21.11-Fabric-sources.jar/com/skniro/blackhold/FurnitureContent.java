package com.skniro.blackhold;


import com.skniro.blackhold.block.*;
import com.skniro.blackhold.item.MapleItems;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;


public class FurnitureContent {


    public static void registerItem(){
        MapleItems.registerModItems();
    }
    public static void registerBlock(){
        FurnitureDrawBlocks.registerDrawBlocks();
    }

    public static void CreativeTab() {
        ItemGroupEvents.modifyEntriesEvent(Furniture.Maple_Group_Furniture).register(content -> {
            content.method_45421(FurnitureDrawBlocks.Oak_Allay_Draw);
            content.method_45421(FurnitureDrawBlocks.Spruce_Allay_Draw);
            content.method_45421(FurnitureDrawBlocks.Birch_Allay_Draw);
            content.method_45421(FurnitureDrawBlocks.Jungle_Allay_Draw);
            content.method_45421(FurnitureDrawBlocks.Acacia_Allay_Draw);
            content.method_45421(FurnitureDrawBlocks.DarkOak_Allay_Draw);
            content.method_45421(FurnitureDrawBlocks.Mangrove_Allay_Draw);
            content.method_45421(FurnitureDrawBlocks.Bamboo_Allay_Draw);
            content.method_45421(FurnitureDrawBlocks.Cherry_Allay_Draw);
            content.method_45421(FurnitureDrawBlocks.Crimson_Allay_Draw);
            content.method_45421(FurnitureDrawBlocks.Warped_Allay_Draw);
            content.method_45421(FurnitureDrawBlocks.PaleOak_Allay_Draw);
        });
    }

}

