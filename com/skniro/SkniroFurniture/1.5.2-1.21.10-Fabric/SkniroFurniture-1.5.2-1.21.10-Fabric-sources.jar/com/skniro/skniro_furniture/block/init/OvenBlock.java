package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import com.skniro.skniro_furniture.block.entity.FurnitureBlockEntityType;
import com.skniro.skniro_furniture.block.entity.OvenBlockEntity;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2363;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3908;
import net.minecraft.class_4970;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class OvenBlock extends class_2363 {
    public static final MapCodec<OvenBlock> CODEC = method_54094(OvenBlock::new);

    public MapCodec<OvenBlock> method_53969() {
        return field_46280;
    }

    public OvenBlock(class_4970.class_2251 settings) {
        super(settings);
    }

    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new OvenBlockEntity(pos, state);
    }

    @Nullable
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31617(world, type, FurnitureBlockEntityType.OVEN_BLOCK_ENTITY);
    }

    protected void method_17025(class_1937 world, class_2338 pos, class_1657 player) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof OvenBlockEntity) {
            player.method_17355((class_3908)blockEntity);
            player.method_7281(class_3468.field_17273);
        }

    }

    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        if ((Boolean)state.method_11654(field_11105)) {
            double d = (double)pos.method_10263() + 0.5;
            double e = (double)pos.method_10264();
            double f = (double)pos.method_10260() + 0.5;
            if (random.method_43058() < 0.1) {
                world.method_8486(d, e, f, class_3417.field_15006, class_3419.field_15245, 1.0F, 1.0F, false);
            }

            class_2350 direction = (class_2350)state.method_11654(field_11104);
            class_2350.class_2351 axis = direction.method_10166();
            double g = 0.52;
            double h = random.method_43058() * 0.6 - 0.3;
            double i = axis == class_2350.class_2351.field_11048 ? (double)direction.method_10148() * 0.52 : h;
            double j = random.method_43058() * 6.0 / 16.0;
            double k = axis == class_2350.class_2351.field_11051 ? (double)direction.method_10165() * 0.52 : h;
        }
    }
}
