package com.skniro.growable_ores_extension.block.init.energybox;


import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.block.entity.energybox.BaseEnergyBoxBlockEntity;
import com.skniro.growable_ores_extension.block.entity.energybox.ChargePadBlockEntity;
import com.skniro.growable_ores_extension.block.entity.energybox.EnergyBoxBlockEntity;
import com.skniro.growable_ores_extension.block.init.machine.AbstractMachineblock;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class ChargePadBlock extends AbstractMachineblock {
    private int capacity;
    public ChargePadBlock(class_2251 settings, int capacity, EnergyTier energyTier) {
        super(settings, energyTier);
        this.capacity = capacity;
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        throw new IllegalStateException("Block does not support getCodec!");
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ChargePadBlockEntity(pos, state, capacity, energyTier);
    }


    @Override
    public void method_66388(class_2680 state, class_3218 world, class_2338 pos, boolean moved) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof BaseEnergyBoxBlockEntity) {
            class_1264.method_5451(world, pos, (class_1263) blockEntity);
            world.method_8455(pos,this);
        }
        super.method_66388(state, world, pos, moved);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, AlchemyBlockEntityType.ChargePad_BLOCK_ENTITY, (world1, pos, state1, blockEntity) -> blockEntity.tick(world1, pos, state1));
    }

}
