package com.skniro.industrial_elixir.datagen.recipe;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.item.MapleFoodComponents;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class BaseMachineRecipeGenerator extends FabricRecipeProvider {
    public BaseMachineRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                shaped(class_7800.field_40642, GrowableOresBlocks.COAL_GENERATOR)
                        .method_10434('G', GrowableOresBlocks.Iron_Furnace_Block).method_10434('E', GrowableOresItems.RE_BATTERY).method_10434('S', GrowableOresItems.IRON_PLATE)
                        .method_10439(" E ").method_10439("SSS").method_10439(" G ")
                        .method_10429("has_item", this.has(GrowableOresItems.RE_BATTERY)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.COAL_GENERATOR)
                        .method_10434('G', class_1802.field_8732).method_10434('E', GrowableOresItems.RE_BATTERY).method_10434('S', GeneralBlocks.Machine)
                        .method_10439(" E ").method_10439(" S ").method_10439(" G ")
                        .method_10429("has_item", this.has(GrowableOresItems.RE_BATTERY)).method_36443(this.output,"base_machine_to_coal_generator");

/*                shaped(RecipeCategory.MISC, GrowableOresBlocks.NUCLEAR_REACTOR)
                        .define('M', GeneralBlocks.Advanced_Machine).define('C', GrowableOresItems.Advanced_Circuit).define('P', GrowableOresItems.REACTOR_PLATING).define('U', GrowableOresItems.SACRED_INGOT)
                        .pattern("PCP").pattern("UMU").pattern("PCP")
                        .unlockedBy("has_item", this.has(GrowableOresItems.SACRED_INGOT)).save(this.output);*/

                shaped(class_7800.field_40642, GrowableOresBlocks.GENERATOR_SolarPanel)
                        .method_10434('G', class_1802.field_8280).method_10434('E', GrowableOresItems.COAL_DUST).method_10434('S', GrowableOresBlocks.COAL_GENERATOR).method_10434('C', GrowableOresItems.Circuit)
                        .method_10439("EGE").method_10439("GEG").method_10439("CSC")
                        .method_10429("has_item", this.has(GrowableOresBlocks.COAL_GENERATOR)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.GENERATOR_Wind_Mill)
                        .method_10434('G', class_1802.field_8620).method_10434('S', GrowableOresBlocks.COAL_GENERATOR)
                        .method_10439("G G").method_10439(" S ").method_10439("G G")
                        .method_10429("has_item", this.has(GrowableOresBlocks.COAL_GENERATOR)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.Compressor_Block)
                        .method_10434('G', class_1802.field_20391).method_10434('S', GeneralBlocks.Machine).method_10434('C', GrowableOresItems.Circuit)
                        .method_10439("G G").method_10439("GSG").method_10439("GCG")
                        .method_10429("has_item", this.has(GeneralBlocks.Machine)).method_10431(this.output);

                //临时配方
                shaped(class_7800.field_40642, GrowableOresBlocks.Extractor_Block)
                        .method_10434('G', GrowableOresItems.Sticky_Resin).method_10434('S', GeneralBlocks.Machine).method_10434('C', GrowableOresItems.Circuit)
                        .method_10439("   ").method_10439("GSG").method_10439("GCG")
                        .method_10429("has_item", this.has(GeneralBlocks.Machine)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.Iron_Furnace_Block)
                        .method_10434('G', GrowableOresItems.IRON_PLATE).method_10434('C', class_1802.field_8732)
                        .method_10439(" G ").method_10439("G G").method_10439("GCG")
                        .method_10429("has_item", this.has(class_1802.field_8732)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.Macerator_Block)
                        .method_10434('G', class_1802.field_20391).method_10434('S', GeneralBlocks.Machine).method_10434('C', GrowableOresItems.Circuit).method_10434('F', class_1802.field_8145)
                        .method_10439("FFF").method_10439("GSG").method_10439(" C ")
                        .method_10429("has_item", this.has(GeneralBlocks.Machine)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.MetalFormerBlock)
                        .method_10434('G', GrowableOresItems.BRONZE_CASING).method_10434('S', GeneralBlocks.Machine).method_10434('C', GrowableOresItems.Circuit).method_10434('F', GrowableOresItems.Coil)
                        .method_10439(" C ").method_10439("GSG").method_10439("FFF")
                        .method_10429("has_item", this.has(GeneralBlocks.Machine)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.ChargePad)
                        .method_10434('G', class_1802.field_8667).method_10434('S', GrowableOresBlocks.EnergyBox).method_10434('C', GrowableOresItems.Circuit).method_10434('F', GrowableOresItems.Rubber)
                        .method_10439("   ").method_10439("CGC").method_10439("FSF")
                        .method_10429("has_item", this.has(GrowableOresBlocks.EnergyBox)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.CESU_CHARGE_PAD)
                        .method_10434('G', class_1802.field_8667).method_10434('S', GrowableOresBlocks.CESU).method_10434('C', GrowableOresItems.Circuit).method_10434('F', GrowableOresItems.Rubber)
                        .method_10439("   ").method_10439("CGC").method_10439("FSF")
                        .method_10429("has_item", this.has(GrowableOresBlocks.CESU)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.MFE_CHARGE_PAD)
                        .method_10434('G', class_1802.field_8667).method_10434('S', GrowableOresBlocks.MFE).method_10434('C', GrowableOresItems.Circuit).method_10434('F', GrowableOresItems.Rubber)
                        .method_10439("   ").method_10439("CGC").method_10439("FSF")
                        .method_10429("has_item", this.has(GrowableOresBlocks.MFE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.MFSU_CHARGE_PAD)
                        .method_10434('G', class_1802.field_8667).method_10434('S', GrowableOresBlocks.MFSU).method_10434('C', GrowableOresItems.Circuit).method_10434('F', GrowableOresItems.Rubber)
                        .method_10439("   ").method_10439("CGC").method_10439("FSF")
                        .method_10429("has_item", this.has(GrowableOresBlocks.MFSU)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.EnergyBox)
                        .method_10433('G', class_3489.field_15537).method_10434('S', GrowableOresBlocks.INSULATED_TIN_CABLE).method_10434('F', GrowableOresItems.RE_BATTERY)
                        .method_10439("GSG").method_10439("FFF").method_10439("GGG")
                        .method_10429("has_item", this.has(GrowableOresBlocks.INSULATED_TIN_CABLE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.CESU)
                        .method_10434('G', GrowableOresItems.BRONZE_PLATE).method_10434('S', GrowableOresBlocks.INSULATED_COPPER_CABLE).method_10434('F', GrowableOresItems.ADVANCED_RE_BATTERY)
                        .method_10439("GSG").method_10439("FFF").method_10439("GGG")
                        .method_10429("has_item", this.has(GrowableOresBlocks.INSULATED_COPPER_CABLE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.MFE)
                        .method_10434('G', GrowableOresItems.ENERGY_CRYSTAL).method_10434('S', GrowableOresBlocks.INSULATED_GOLD_CABLE).method_10434('F', GeneralBlocks.Machine)
                        .method_10439("SGS").method_10439("GFG").method_10439("SGS")
                        .method_10429("has_item", this.has(GrowableOresBlocks.INSULATED_GOLD_CABLE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.MFSU)
                        .method_10434('G', GrowableOresItems.LAPOTRON_CRYSTAL).method_10434('S', GeneralBlocks.Advanced_Machine).method_10434('F', GrowableOresBlocks.MFE).method_10434('C', GrowableOresItems.Advanced_Circuit)
                        .method_10439("GCG").method_10439("GFG").method_10439("GSG")
                        .method_10429("has_item", this.has(GrowableOresBlocks.MFE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.LV_TRANSFORMER)
                        .method_10433('G', class_3489.field_15537).method_10434('F', GrowableOresBlocks.INSULATED_TIN_CABLE).method_10434('C', GrowableOresItems.Coil)
                        .method_10439("GFG").method_10439("GCG").method_10439("GFG")
                        .method_10429("has_item", this.has(GrowableOresBlocks.INSULATED_TIN_CABLE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.MV_TRANSFORMER)
                        .method_10434('G', GeneralBlocks.Machine).method_10434('F', GrowableOresBlocks.INSULATED_COPPER_CABLE)
                        .method_10439(" F ").method_10439(" G ").method_10439(" F ")
                        .method_10429("has_item", this.has(GrowableOresBlocks.INSULATED_COPPER_CABLE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.HV_TRANSFORMER)
                        .method_10434('G', GrowableOresBlocks.MV_TRANSFORMER).method_10434('F', GrowableOresBlocks.INSULATED_GOLD_CABLE).method_10434('C', GrowableOresItems.Circuit).method_10434('R', GrowableOresItems.ADVANCED_RE_BATTERY)
                        .method_10439(" F ").method_10439("CGR").method_10439(" F ")
                        .method_10429("has_item", this.has(GrowableOresBlocks.INSULATED_GOLD_CABLE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.EV_TRANSFORMER)
                        .method_10434('G', GrowableOresBlocks.HV_TRANSFORMER).method_10434('F', GrowableOresBlocks.INSULATED_HV_CABLE).method_10434('C', GrowableOresItems.Advanced_Circuit).method_10434('R', GrowableOresItems.LAPOTRON_CRYSTAL)
                        .method_10439(" F ").method_10439("CGR").method_10439(" F ")
                        .method_10429("has_item", this.has(GrowableOresBlocks.INSULATED_HV_CABLE)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.ElectricFurnace_Block)
                        .method_10434('G', GrowableOresBlocks.Iron_Furnace_Block).method_10434('C', GrowableOresItems.Circuit).method_10434('R', class_1802.field_8725)
                        .method_10439("   ").method_10439(" C ").method_10439("RGR")
                        .method_10429("has_item", this.has(GrowableOresBlocks.Iron_Furnace_Block)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.INDUCTION_FURNACE)
                        .method_10434('E', GrowableOresBlocks.ElectricFurnace_Block).method_10434('A', GrowableOresItems.Advanced_Circuit).method_10434('C', GrowableOresItems.COPPER_PLATE).method_10434('M', GeneralBlocks.Advanced_Machine)
                        .method_10439("CAC").method_10439("EAE").method_10439("CMC")
                        .method_10429("has_item", this.has(GrowableOresBlocks.ElectricFurnace_Block)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.RECYCLER_Block)
                        .method_10434('G', GrowableOresBlocks.Compressor_Block).method_10434('C', class_1802.field_8601).method_10434('R', class_1802.field_8620).method_10433('D', class_3489.field_36269)
                        .method_10439(" C ").method_10439("DGD").method_10439("RDR")
                        .method_10429("has_item", this.has(GrowableOresBlocks.Compressor_Block)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.CUTTING_Block)
                        .method_10434('G', GeneralBlocks.Machine).method_10434('C', GrowableOresItems.Circuit).method_10434('R', GrowableOresItems.Electric_Motor)
                        .method_10439(" C ").method_10439(" G ").method_10439(" R ")
                        .method_10429("has_item", this.has(GrowableOresItems.Circuit)).method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.Ore_Washing_Block)
                        .method_10434('G', GeneralBlocks.Machine).method_10434('I', GrowableOresItems.IRON_PLATE).method_10434('B', class_1802.field_8550).method_10434('C', GrowableOresItems.Circuit).method_10434('R', GrowableOresItems.Electric_Motor)
                        .method_10439("III").method_10439("BGB").method_10439("RCR")
                        .method_10429("has_item", this.has(GrowableOresItems.Circuit))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.Brew_Reactor_BLOCK)
                        .method_10434('G', class_2246.field_10333).method_10434('I', GrowableOresItems.IRON_CASING).method_10434('C', GrowableOresItems.Circuit)
                        .method_10439("III").method_10439("IGI").method_10439("ICI")
                        .method_10429("has_item", this.has(GrowableOresItems.Circuit))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.BLAST_FURNACE_BLOCK)
                        .method_10434('G', GeneralBlocks.Machine).method_10434('I', GrowableOresItems.IRON_CASING).method_10434('C', GrowableOresItems.HEAT_CONDUCTOR)
                        .method_10439("III").method_10439("IGI").method_10439("ICI")
                        .method_10429("has_item", this.has(GrowableOresItems.IRON_CASING))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.HEAT_CENTRIFUGE)
                        .method_10434('G', GeneralBlocks.Advanced_Machine).method_10434('I', class_1802.field_8620).method_10434('L', GrowableOresItems.LAPOTRON_CRYSTAL).method_10434('M', GrowableOresItems.Electric_Motor).method_10434('C', GrowableOresItems.Coil)
                        .method_10439("CLC").method_10439("IGI").method_10439("IMI")
                        .method_10429("has_item", this.has(class_1802.field_8620))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.MATTER_GENERATOR)
                        .method_10434('G', GeneralBlocks.Advanced_Machine)
                        .method_10434('I', class_1802.field_8801)
                        .method_10434('L', GrowableOresItems.LAPOTRON_CRYSTAL)
                        .method_10434('C', GrowableOresItems.Advanced_Circuit)
                        .method_10439("ICI").method_10439("GLG").method_10439("ICI")
                        .method_10429("has_item", this.has(GeneralBlocks.Advanced_Machine))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.Replicator)
                        .method_10434('R', GeneralBlocks.Reinforced_Stone)
                        .method_10434('G', GeneralBlocks.Reinforced_Glass)
                        .method_10434('S', GeneralBlocks.Super_Machine)
                        .method_10434('D', GrowableOresBlocks.MFE)
                        .method_10434('C', GrowableOresBlocks.HV_TRANSFORMER)
                        .method_10439("RGR").method_10439("SSS").method_10439("CDC")
                        .method_10429("has_item", this.has(GeneralBlocks.Super_Machine))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.PATTERN_STORAGE)
                        .method_10434('R', GeneralBlocks.Reinforced_Stone)
                        .method_10434('P', GrowableOresItems.PATTERN_STORAGE_CRYSTAL)
                        .method_10434('M', GeneralBlocks.Advanced_Machine)
                        .method_10434('L', GrowableOresItems.LAPOTRON_CRYSTAL)
                        .method_10434('C', GrowableOresItems.Advanced_Circuit)
                        .method_10439("RRR").method_10439("PMP").method_10439("LCL")
                        .method_10429("has_item", this.has(GeneralBlocks.Advanced_Machine))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.CHUNK_LOADER)
                        .method_10434('E', class_1802.field_8634)
                        .method_10434('T', GrowableOresItems.TIN_PLATE)
                        .method_10434('M', GeneralBlocks.Machine)
                        .method_10434('L', class_1802.field_8759)
                        .method_10434('C', GrowableOresItems.Circuit)
                        .method_10439("TET").method_10439("LML").method_10439("TCT")
                        .method_10429("has_item", this.has(GeneralBlocks.Machine))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.FLUID_GENERATOR)
                        .method_10434('G', class_1802.field_8280)
                        .method_10434('T', GrowableOresItems.EMPTY_CELL)
                        .method_10434('M', GrowableOresBlocks.COAL_GENERATOR)
                        .method_10434('I', GrowableOresItems.IRON_CASING)
                        .method_10439("GTG").method_10439("GTG").method_10439("IMI")
                        .method_10429("has_item", this.has(GrowableOresBlocks.COAL_GENERATOR))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.Electric_Heater_Block)
                        .method_10434('B', GrowableOresItems.RE_BATTERY)
                        .method_10434('I', GrowableOresItems.IRON_CASING)
                        .method_10434('C', GrowableOresItems.Circuit)
                        .method_10434('H', GrowableOresItems.HEAT_CONDUCTOR)
                        .method_10439("IBI").method_10439("ICI").method_10439("IHI")
                        .method_10429("has_item", this.has(GrowableOresItems.RE_BATTERY))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.SOLID_FUEL_HEATER_GENERATOR)
                        .method_10434('I', GrowableOresItems.IRON_PLATE)
                        .method_10434('C', GrowableOresBlocks.Iron_Furnace_Block)
                        .method_10434('H', GrowableOresItems.HEAT_CONDUCTOR)
                        .method_10439(" H ").method_10439("III").method_10439(" C ")
                        .method_10429("has_item", this.has(GrowableOresBlocks.Iron_Furnace_Block))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.Pipe_Stone_Fluid_Block, 8)
                        .method_10434('G', class_1802.field_8280)
                        .method_10434('I', GrowableOresItems.Sticky_Resin)
                        .method_10434('C', class_2246.field_10340)
                        .method_10439("   ").method_10439("CGC").method_10439(" I ")
                        .method_10429("has_item", this.has(class_2246.field_10340))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.Pipe_Wooden_Fluid_Block, 8)
                        .method_10434('G', class_1802.field_8280)
                        .method_10434('I', GrowableOresItems.Sticky_Resin)
                        .method_10433('C', class_3489.field_15537)
                        .method_10439("   ").method_10439("CGC").method_10439(" I ")
                        .method_10429("has_item", this.has(class_2246.field_10340))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.FLUID_TANK_BLOCK)
                        .method_10434('I', GrowableOresItems.IRON_PLATE)
                        .method_10434('E', GrowableOresItems.EMPTY_CELL)
                        .method_10439("IEI").method_10439("E E").method_10439("IEI")
                        .method_10429("has_item", this.has(GrowableOresItems.EMPTY_CELL))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.SACRED_GENERATOR)
                        .method_10434('C', GrowableOresItems.Advanced_Circuit)
                        .method_10434('L', GrowableOresItems.DENSE_LEAD_PLATE)
                        .method_10434('G', GrowableOresBlocks.COAL_GENERATOR)
                        .method_10434('A', GeneralBlocks.Advanced_Machine)
                        .method_10434('M', GeneralBlocks.Machine)
                        .method_10439("LCL").method_10439("MAM").method_10439("LGL")
                        .method_10429("has_item", this.has(GeneralBlocks.Machine))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.CROP_FARM_Block)
                        .method_10434('C', GrowableOresItems.Advanced_Circuit)
                        .method_10434('L', GrowableOresItems.LAPOTRON_CRYSTAL)
                        .method_10434('A', GrowableOresItems.ALLOY_PLATE)
                        .method_10434('S', GeneralBlocks.Super_Machine)
                        .method_10434('M', GeneralBlocks.Advanced_Machine)
                        .method_10439("ACA").method_10439("MSM").method_10439("ALA")
                        .method_10429("has_item", this.has(GeneralBlocks.Super_Machine))
                        .method_10431(this.output);

                shaped(class_7800.field_40642, GrowableOresBlocks.COFFEE_MACHINE_Block)
                        .method_10434('C', MapleFoodComponents.Coffee_Beans)
                        .method_10434('L', GrowableOresItems.RE_BATTERY)
                        .method_10434('A', GrowableOresItems.IRON_CASING)
                        .method_10434('I', GrowableOresItems.IRON_PLATE)
                        .method_10434('M', GeneralBlocks.Machine)
                        .method_10439("ACA").method_10439("IMI").method_10439("ALA")
                        .method_10429("has_item", this.has(GeneralBlocks.Machine))
                        .method_10431(this.output);
            }
        };
    }

    @Override
    public String method_10321() {
        return "BaseMachine";
    }
}
