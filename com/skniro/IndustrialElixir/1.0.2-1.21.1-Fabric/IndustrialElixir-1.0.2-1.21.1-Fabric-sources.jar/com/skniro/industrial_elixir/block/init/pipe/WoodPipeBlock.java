package com.skniro.industrial_elixir.block.init.pipe;

import com.mojang.serialization.MapCodec;
import com.skniro.industrial_elixir.block.entity.pipe.PipeExtractDirectionController;
import com.skniro.industrial_elixir.block.entity.pipe.WoodPipeBlockEntity;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1269;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_5558;

public class WoodPipeBlock extends PipeBlock implements class_3737 {
    public static final class_2746 PULL_EAST = class_2746.method_11825("pull_east");
    public static final class_2746 PULL_WEST = class_2746.method_11825("pull_west");
    public static final class_2746 PULL_NORTH = class_2746.method_11825("pull_north");
    public static final class_2746 PULL_SOUTH = class_2746.method_11825("pull_south");
    public static final class_2746 PULL_UP = class_2746.method_11825("pull_up");
    public static final class_2746 PULL_DOWN = class_2746.method_11825("pull_down");

    public static final Map<class_2350, class_2746> PULL_PROPERTY_MAP = class_156.method_654(new HashMap<>(), map -> {
        map.put(class_2350.field_11034, PULL_EAST);
        map.put(class_2350.field_11039, PULL_WEST);
        map.put(class_2350.field_11043, PULL_NORTH);
        map.put(class_2350.field_11035, PULL_SOUTH);
        map.put(class_2350.field_11036, PULL_UP);
        map.put(class_2350.field_11033, PULL_DOWN);
    });

    public WoodPipeBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.method_9564()
                .method_11657(PULL_EAST, false)
                .method_11657(PULL_WEST, false)
                .method_11657(PULL_NORTH, false)
                .method_11657(PULL_SOUTH, false)
                .method_11657(PULL_UP, false)
                .method_11657(PULL_DOWN, false));
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new WoodPipeBlockEntity(pos, state);
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        class_2586 be = world.method_8321(pos);
        if (!(be instanceof PipeExtractDirectionController controller)) return class_1269.field_5811;

        if (player.method_5715()) {
            controller.clearPreferredExtractDirection();
        } else {
            class_2350 current = controller.getPreferredExtractDirection();
            // 收集所有已连接的方向
            List<class_2350> connected = new ArrayList<>();
            for (class_2350 dir : class_2350.values()) {
                if (state.method_11654(PipeBlock.PROPERTY_MAP.get(dir))) {
                    connected.add(dir);
                }
            }
            if (connected.isEmpty()) return class_1269.field_5812;

            class_2350 next;
            if (current == null || !connected.contains(current)) {
                next = connected.get(0);
            } else {
                int index = connected.indexOf(current);
                next = connected.get((index + 1) % connected.size());
            }
            controller.setPreferredExtractDirection(next);
        }
        return class_1269.field_5812;
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return (world1, pos, state1, blockEntity) ->
                ((WoodPipeBlockEntity) blockEntity).tick(world1, pos, state1);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(PULL_EAST, PULL_WEST, PULL_NORTH, PULL_SOUTH, PULL_UP, PULL_DOWN);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        throw new IllegalStateException("PipeBlock does not support getCodec!");
    }
}
