package com.skniro.growable_ores_extension.block.entity.machine;

import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2609;
import net.minecraft.class_2680;
import net.minecraft.class_3858;
import net.minecraft.class_3956;

public class IronFurnaceBlockEntity extends class_2609 {
    public IronFurnaceBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.Iron_Furnace_BLOCK_ENTITY, pos, state, class_3956.field_17546);
    }

    @Override
    protected class_2561 method_17823() {
        return class_2561.method_43471(FurnitureStrings.MolecularTransformer);
    }

    protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return new class_3858(syncId, playerInventory, this, this.field_17374);
    }
}
