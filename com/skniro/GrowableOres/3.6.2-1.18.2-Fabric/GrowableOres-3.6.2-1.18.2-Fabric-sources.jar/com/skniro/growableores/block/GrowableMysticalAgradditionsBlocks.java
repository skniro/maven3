package com.skniro.growableores.block;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.init.GrowableOreCaneBlock;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3614;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import java.util.logging.Logger;

public class GrowableMysticalAgradditionsBlocks {
    //Mystical Agradditions
    public static final class_2248 MAA_Awakened_Draconium_Essence_Cane = registerBlock("maa_awakened_draconium_essence_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 MAA_Dragon_Egg_Essence_Cane = registerBlock("maa_dragon_egg_essence_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 MAA_Insanium_Essence_Cane = registerBlock("maa_insanium_essence_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 MAA_Insanium_Ingot_Cane = registerBlock("maa_insanium_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 MAA_Nether_Star_Essence_Cane = registerBlock("maa_nether_star_essence_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 MAA_Neutronium_Essence_Cane = registerBlock("maa_neutronium_essence_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 MAA_Nitro_Crystal_Essence_Cane = registerBlock("maa_nitro_crystal_essence_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);

    private static class_2248 registerBlock(String name, class_2248 block, class_1761 tab) {
        registerBlockItem(name, block, tab);
        return class_2378.method_10230(class_2378.field_11146, new class_2960(GrowableOres.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_1761 tab) {
        return class_2378.method_10230(class_2378.field_11142, new class_2960(GrowableOres.MOD_ID, name),
                new class_1747(block, new FabricItemSettings().method_7892(tab)));
    }

    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + GrowableOres.MOD_ID);
    }
}

