package com.skniro.growable_ores_extension.block.entity.cable;

import com.skniro.growable_ores_extension.ModContent;
import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.block.init.CableBlock;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.base.SimpleSidedEnergyContainer;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiCache;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_5558;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class CableBlockEntity extends class_2586 implements class_5558<CableBlockEntity> {
    final SimpleSidedEnergyContainer energyContainer;
    private ModContent.Cables cableType;
    private @Nullable class_2680 cover;
    long lastTick;
    List<CableTarget> targets;
    private final BlockApiCache<EnergyStorage, class_2350>[] adjacentCaches;
    int blockedSides;
    boolean ioBlocked;

    public CableBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.CABLE, pos, state);
        class NamelessClass_1 extends SimpleSidedEnergyContainer {
            public long getCapacity() {
                return (long)CableBlockEntity.this.getCableType().transferRate * 4L;
            }

            public long getMaxInsert(class_2350 side) {
                return CableBlockEntity.this.allowTransfer(side) ? (long)CableBlockEntity.this.getCableType().transferRate : 0L;
            }

            public long getMaxExtract(class_2350 side) {
                return CableBlockEntity.this.allowTransfer(side) ? (long)CableBlockEntity.this.getCableType().transferRate : 0L;
            }
        }

        this.energyContainer = new NamelessClass_1();
        this.cableType = null;
        this.cover = null;
        this.lastTick = 0L;
        this.targets = null;
        this.adjacentCaches = new BlockApiCache[6];
        this.blockedSides = 0;
        this.ioBlocked = false;
    }

    public CableBlockEntity(class_2338 pos, class_2680 state, ModContent.Cables type) {
        super(AlchemyBlockEntityType.CABLE, pos, state);

        this.energyContainer = new SimpleSidedEnergyContainer(){
            public long getCapacity() {
                return (long)CableBlockEntity.this.getCableType().transferRate * 4L;
            }

            public long getMaxInsert(class_2350 side) {
                return CableBlockEntity.this.allowTransfer(side) ? (long)CableBlockEntity.this.getCableType().transferRate : 0L;
            }

            public long getMaxExtract(class_2350 side) {
                return CableBlockEntity.this.allowTransfer(side) ? (long)CableBlockEntity.this.getCableType().transferRate : 0L;
            }
        };
        this.cableType = null;
        this.cover = null;
        this.lastTick = 0L;
        this.targets = null;
        this.adjacentCaches = new BlockApiCache[6];
        this.blockedSides = 0;
        this.ioBlocked = false;
        this.cableType = type;
    }

    ModContent.Cables getCableType() {
        if (this.cableType != null) {
            return this.cableType;
        } else if (this.field_11863 == null) {
            return ModContent.Cables.COPPER;
        } else {
            class_2248 block = this.field_11863.method_8320(this.field_11867).method_26204();
            return block instanceof CableBlock ? ((CableBlock)block).type : ModContent.Cables.COPPER;
        }
    }

    private boolean allowTransfer(class_2350 side) {
        if (side == null) {
            return true;
        } else {
            return !this.ioBlocked && (this.blockedSides & 1 << side.ordinal()) == 0;
        }
    }

    public EnergyStorage getSideEnergyStorage(@Nullable class_2350 side) {
        return this.energyContainer.getSideStorage(side);
    }

    public long getEnergy() {
        return this.energyContainer.amount;
    }

    public void setEnergy(long energy) {
        this.energyContainer.amount = energy;
    }

    private BlockApiCache<EnergyStorage, class_2350> getAdjacentCache(class_2350 direction) {
        if (this.adjacentCaches[direction.method_10146()] == null) {
            this.adjacentCaches[direction.method_10146()] = BlockApiCache.create(EnergyStorage.SIDED, (class_3218)this.field_11863, this.field_11867.method_10093(direction));
        }

        return this.adjacentCaches[direction.method_10146()];
    }

    @Nullable class_2586 getAdjacentBlockEntity(class_2350 direction) {
        return this.getAdjacentCache(direction).getBlockEntity();
    }

    void appendTargets(List<OfferedEnergyStorage> targetStorages) {
        class_3218 serverWorld = (class_3218)this.field_11863;
        if (serverWorld != null) {
            if (this.targets == null) {
                class_2680 newBlockState = this.method_11010();
                this.targets = new ArrayList();

                for(class_2350 direction : class_2350.values()) {
                    boolean foundSomething = false;
                    BlockApiCache<EnergyStorage, class_2350> adjCache = this.getAdjacentCache(direction);
                    class_2586 var11 = adjCache.getBlockEntity();
                    if (var11 instanceof CableBlockEntity) {
                        CableBlockEntity adjCable = (CableBlockEntity)var11;
                        if (adjCable.getCableType().transferRate == this.getCableType().transferRate) {
                            foundSomething = true;
                        }
                    } else if (adjCache.find(direction.method_10153()) != null) {
                        foundSomething = true;
                        this.targets.add(new CableTarget(direction, adjCache));
                    }

                    newBlockState = (class_2680)newBlockState.method_11657((class_2769) CableBlock.PROPERTY_MAP.get(direction), foundSomething);
                }

                serverWorld.method_8501(this.method_11016(), newBlockState);
            }

            for(CableTarget target : this.targets) {
                EnergyStorage storage = target.find();
                if (storage == null) {
                    this.targets = null;
                } else {
                    targetStorages.add(new OfferedEnergyStorage(this, target.directionTo, storage));
                }
            }

            this.blockedSides = 0;
        }
    }

    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return this.method_38244(registryLookup);
    }

    public class_2622 getUpdatePacket() {
        new class_2487();
        return class_2622.method_38585(this);
    }

    public void method_11014(class_11368 view) {
        super.method_11014(view);
        this.energyContainer.amount = view.method_71425("energy", 0L);
        this.cover = (class_2680)view.method_71426("cover", class_2680.field_24734).orElse((class_2680) null);
    }

    public void method_11007(class_11372 view) {
        super.method_11007(view);
        view.method_71466("energy", this.energyContainer.amount);
        if (this.cover != null) {
            view.method_71468("cover", class_2680.field_24734, this.cover);
        }

    }

    public void neighborUpdate() {
        this.targets = null;
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state, CableBlockEntity blockEntity2) {
        if (world != null && !world.method_8608()) {
            CableTickManager.handleCableTick(this);
        }
    }

    public void addInfo(List<class_2561> info, boolean isReal, boolean hasData) {
        info.add(class_2561.method_43471("techreborn.tooltip.transferRate").method_27692(class_124.field_1080).method_27693(": ").method_27693(PowerSystem.getLocalizedPower((double)this.getCableType().transferRate)).method_27692(class_124.field_1065).method_27693("/t"));
        info.add(class_2561.method_43471("techreborn.tooltip.tier").method_27692(class_124.field_1080).method_27693(": ").method_10852(class_2561.method_43470(StringUtils.toFirstCapitalAllLowercase(this.getCableType().tier.toString())).method_27692(class_124.field_1065)));
        if (!this.getCableType().canKill) {
            info.add(class_2561.method_43471("techreborn.tooltip.cable.can_cover").method_27692(class_124.field_1080));
        }

    }

    public class_1799 getToolDrop(class_1657 playerIn) {
        return new class_1799(this.getCableType().getBlock());
    }

    public @Nullable class_2680 getRenderData() {
        return this.cover;
    }

    private static record CableTarget(class_2350 directionTo, BlockApiCache<EnergyStorage, class_2350> cache) {
        @Nullable EnergyStorage find() {
            return this.cache.find(this.directionTo.method_10153());
        }
    }
}
