package com.skniro.industrial_elixir.networking.packet;


import com.skniro.industrial_elixir.IndustrialElixir;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;


public record EnergySyncS2CPayload(long amount, class_2338 blockPos) implements class_8710 {
    public static final class_2960 EnergySync = class_2960.method_60655(IndustrialElixir.MOD_ID,"open_torcherino_screen");
    public static final class_9154<EnergySyncS2CPayload> TYPE = new class_9154<>(EnergySync);
    public static final class_9139<class_9129, EnergySyncS2CPayload> CODEC = class_8710.method_56484(EnergySyncS2CPayload::write, EnergySyncS2CPayload::new);

    public EnergySyncS2CPayload(final class_2540 buf){
        this(
                buf.readLong(),
                buf.method_10811()
                );
    }

    public void write(class_2540 buffer) {
        buffer.method_52974(amount);
        buffer.method_10807(blockPos);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}