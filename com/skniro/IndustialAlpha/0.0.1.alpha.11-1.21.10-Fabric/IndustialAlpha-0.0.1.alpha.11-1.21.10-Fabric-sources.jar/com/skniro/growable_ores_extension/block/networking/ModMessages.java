package com.skniro.growable_ores_extension.block.networking;

import com.skniro.growable_ores_extension.block.networking.packet.MetalFormerStateC2SPayload;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_9129;

public class ModMessages {
    public static void register() {
        registerS2CPackets(PayloadTypeRegistry.playS2C());
        registerC2SPackets(PayloadTypeRegistry.playC2S());
        NetworkUtilsImpl.getInstance().initialize();
    }

    public static void registerC2SPackets(PayloadTypeRegistry<class_9129> registry) {
        registry.register(MetalFormerStateC2SPayload.TYPE, MetalFormerStateC2SPayload.CODEC);
    }

    public static void registerS2CPackets(PayloadTypeRegistry<class_9129> registry) {

    }
}