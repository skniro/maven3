package com.skniro.industrial_elixir.keybind;

import com.skniro.industrial_elixir.networking.packet.BoostJumpC2SPayload;
import com.skniro.industrial_elixir.networking.packet.JetpackInputC2SPayload;
import com.skniro.industrial_elixir.networking.packet.ToggleHoverC2SPayload;
import com.skniro.industrial_elixir.networking.packet.ToggleNightVisionC2SPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_310;

public class ModClientEvents {
    private static boolean lastJumpHeld = false;
    private static boolean lastForwardHeld = false;
    private static float lastStrafe = 0f;

    public static void onEndTick(class_310 client) {
        while (ModKeyMappings.Mode_Switch_Keybind.method_1436()) {
            while (ModKeyMappings.ALT_Keybind.method_1436()) {
                ClientPlayNetworking.send(new ToggleNightVisionC2SPayload());
            }
        }

        // Boost Jump: hold Boost key + press Space
        if (ModKeyMappings.Boost_Keybind.method_1434()
                && client.field_1690.field_1903.method_1436()) {
            ClientPlayNetworking.send(new BoostJumpC2SPayload());
        }

        // Toggle Hover: Mode Switch key + Space (while wearing chestplate)
        if (ModKeyMappings.Mode_Switch_Keybind.method_1434()
                && client.field_1690.field_1903.method_1436()
                && client.field_1724 != null) {
            ClientPlayNetworking.send(new ToggleHoverC2SPayload());
        }

        // Jetpack input: send key state changes to server
        if (client.field_1724 != null) {
            boolean jumpHeld = client.field_1690.field_1903.method_1434();
            boolean forwardHeld = client.field_1690.field_1894.method_1434();
            float strafe = (client.field_1690.field_1913.method_1434() ? -1f : 0f)
                         + (client.field_1690.field_1849.method_1434() ? 1f : 0f);
            if (jumpHeld != lastJumpHeld || forwardHeld != lastForwardHeld || strafe != lastStrafe) {
                lastJumpHeld = jumpHeld;
                lastForwardHeld = forwardHeld;
                lastStrafe = strafe;
                ClientPlayNetworking.send(new JetpackInputC2SPayload(jumpHeld, forwardHeld, strafe));
            }
        }
    }
}
