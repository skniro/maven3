package com.skniro.maple.item;

import com.skniro.maple.Maple;
import java.util.function.Function;
import net.minecraft.class_1754;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class GlassCupItems {
    public static final class_1792 HIGH_GLASS_CUP = registerItem("high_glass_cup", class_1754::new,(
            (new class_1792
                    .class_1793()
            )));


    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings.method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Maple.MOD_ID, name))));
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Maple.MOD_ID, name)), item);
    }

    public static void registerModItems() {
        Maple.LOGGER.info("Registering Glass Items for " + Maple.MOD_ID);
    }

}
