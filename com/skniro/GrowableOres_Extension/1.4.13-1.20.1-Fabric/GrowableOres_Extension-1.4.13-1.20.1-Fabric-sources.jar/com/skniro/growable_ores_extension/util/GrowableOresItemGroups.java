package com.skniro.growable_ores_extension.util;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class GrowableOresItemGroups {
    public static final class_5321<class_1761> Growable_Ores_Group = class_5321.method_29179(class_7924.field_44688, class_2960.method_43902(GrowableOresExtension.MOD_ID, "test_group"));

    public static void vanilla_item() {
        class_2378.method_39197(class_7923.field_44687, Growable_Ores_Group, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(GrowableOresBlocks.GrowableOres_Block))
                .method_47321(class_2561.method_43471("itemGroup.growable_ores.test_group"))
                .method_47324()); // build() no longer registers by itself

    }
}
