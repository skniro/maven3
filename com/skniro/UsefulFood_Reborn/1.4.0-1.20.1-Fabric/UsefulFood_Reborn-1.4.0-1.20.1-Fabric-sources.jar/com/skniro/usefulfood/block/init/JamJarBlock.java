package com.skniro.usefulfood.block.init;

import com.google.common.collect.BiMap;
import com.mojang.serialization.MapCodec;
import com.skniro.usefulfood.block.init.jam.JamType;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4174;

public class JamJarBlock extends class_2248 {
    public static final class_2758 JAM_STAGE = class_2758.method_11867("jam_stage", 1, 3);
    private static final class_265 SHAPE = class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 9.5, 11.0);
    public static final Map<JamType, BiMap<class_1792, class_1792>> JAM_TYPE_MAPS = new HashMap<>();
    public class_1799 JamItem;
    public class_2248 JamBlock;
    public JamType jamType;

    public JamJarBlock(class_2251 settings, class_1799 item, class_2248 JamBlock, JamType jamType) {
        super(settings);
        this.JamItem = item;
        this.JamBlock = JamBlock;
        this.jamType = jamType;
        method_9590(this.field_10647.method_11664().method_11657(JAM_STAGE, 3));
    }

    public JamJarBlock(class_2251 settings) {
        super(settings);
        method_9590(this.field_10647.method_11664().method_11657(JAM_STAGE, 3));
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(JAM_STAGE);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (world.field_9236) return class_1269.field_5812;

        class_1799 heldItem = player.method_5998(hand);
        int stage = state.method_11654(JAM_STAGE);

        if (heldItem.method_31574(JamItem.method_7909()) && stage < 3) {
            world.method_8652(pos, state.method_11657(JAM_STAGE, stage + 1), 3);
            if (!player.method_7337()) heldItem.method_7934(1);
            world.method_8396(null, pos, class_3417.field_14779, class_3419.field_15245, 1.0F, 1.0F);
            return class_1269.field_5812;
        }

        if (heldItem.method_7960() && stage > 0) {
            class_4174 food = JamItem.method_7909().method_19264();
            if (food != null) {
                player.method_7344().method_7585(food.method_19230(), food.method_19231());
            } else {
                player.method_7344().method_7585(2, 0.2F);
            }
            world.method_8396(player, pos, class_3417.field_20614, class_3419.field_15248, 1.0F, 1.0F);

            if (stage > 1) {
                world.method_8652(pos, state.method_11657(JAM_STAGE, stage - 1), 3);
            } else {
                world.method_8652(pos, JamBlock.method_9564(), 3);
                world.method_8396(null, pos, class_3417.field_14843, class_3419.field_15245, 0.5F, 1.2F);
            }
            return class_1269.field_5812;
        }

        BiMap<class_1792, class_1792> conversions = JAM_TYPE_MAPS.get(jamType);
        if (conversions != null && conversions.containsKey(heldItem.method_7909())) {
            class_1792 jamVariant = conversions.get(heldItem.method_7909());
            player.method_6122(hand, new class_1799(jamVariant));
            if (stage > 1) {
                world.method_8652(pos, state.method_11657(JAM_STAGE, stage - 1), 3);
            } else {
                world.method_8652(pos, JamBlock.method_9564(), 3);
                world.method_8396(null, pos, class_3417.field_14843, class_3419.field_15245, 0.5F, 1.2F);
            }
            world.method_8396(null, pos, class_3417.field_14779, class_3419.field_15248, 0.8F, 1.0F);
            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }
}
