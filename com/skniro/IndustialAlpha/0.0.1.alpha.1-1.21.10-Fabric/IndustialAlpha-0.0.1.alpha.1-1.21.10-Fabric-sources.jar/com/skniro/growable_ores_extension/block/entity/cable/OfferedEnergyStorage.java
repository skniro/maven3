package com.skniro.growable_ores_extension.block.entity.cable;

import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import net.minecraft.class_2350;

record OfferedEnergyStorage(CableBlockEntity sourceCable, class_2350 direction, EnergyStorage storage) {
    void afterTransfer() {
        CableBlockEntity var10000 = this.sourceCable;
        var10000.blockedSides |= 1 << this.direction.ordinal();
    }
}