package com.skniro.growable_ores_extension.client;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.joml.Matrix3x2fStack;

public class WindowsWatermarkRenderer {

    private static final class_310 mc = class_310.method_1551();

    public static void render(class_332 context) {

        if (mc == null || mc.field_1772 == null) return;

        Matrix3x2fStack matrices = context.method_51448();
        matrices.pushMatrix();

        matrices.translate(0, 0);

        String line1 = "Unauthorized use or disclosure in any manner";
        String line2 = "may result in disciplinary action";
        String line3 = "and potential civil and criminal liability.";
        String line4 = "Industrial Craft Reborn";
        String line5 = "For testing purposes only.";
        String line6 = "Build " + FabricLoader.getInstance().getModContainer(GrowableOresExtension.MOD_ID).get().getMetadata().getVersion().getFriendlyString();

        String playerName = mc.field_1724 != null ? mc.field_1724.method_5477().getString() : "Player";
        int height = mc.method_22683().method_4502();
        int color = 0x80FFFFFF;
        int x = 5;
        int y = height - 75;
        context.method_51433(mc.field_1772, line1, x, y, color, false);
        context.method_51433(mc.field_1772, line2, x, y + 10, color, false);
        context.method_51433(mc.field_1772, line3, x, y + 20, color, false);
        context.method_51433(mc.field_1772, line4, x, y + 30, color, false);
        context.method_51433(mc.field_1772, line5, x, y + 40, color, false);
        context.method_51433(mc.field_1772, line6, x, y + 50, color, false);
        context.method_51433(mc.field_1772, playerName, x, y + 60, color, false);

        matrices.popMatrix();
    }
}