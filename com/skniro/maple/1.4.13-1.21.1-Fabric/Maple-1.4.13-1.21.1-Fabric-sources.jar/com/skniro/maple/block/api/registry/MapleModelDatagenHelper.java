package com.skniro.maple.block.api.registry;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2741;
import net.minecraft.class_4910;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4935;
import net.minecraft.class_4936;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.data.client.*;

public class MapleModelDatagenHelper {
    private final class_4910 generator;

    public MapleModelDatagenHelper(class_4910 generator) {
        this.generator = generator;
    }

    public void registerModSweetBerryBush(class_1792 fruititem, class_2248 block) {
        generator.method_25537(fruititem);
        generator.field_22830.accept(class_4925.method_25769(block)
                .method_25775(class_4926.method_25783(class_2741.field_12497).method_25795(stage ->
                        class_4935.method_25824().method_25828(class_4936.field_22887,
                                generator.method_25557(block, "_stage" + stage, class_4943.field_22921, class_4944::method_25880)
                        )
                ))
        );
    }
}