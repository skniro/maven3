package com.skniro.industrial_elixir.block.entity;

import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.entity.machine.AbstractMachineEntity;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.screen.AlchemyBlockScreenHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3956;
import org.jetbrains.annotations.Nullable;

public class Alchemyblockentity extends AbstractMachineEntity {

    public Alchemyblockentity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.ALCHEMY_BLOCK_ENTITY, pos, state);
        this.DEFAULT_MAX_PROGRESS = 200;
        this.maxProgress = 200;
    }

    // 40/20 = 2 EU/t
    @Override
    public long getCraftEnergyCost() {
        return 40;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.CaneConverter);
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return AlchemyRecipeType.CANE_CONVERTER.type;
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new AlchemyBlockScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    @Override
    public long getMachineCapacity() {
        long extra = getEnergyStorageUpgrade();
        if(method_11010().method_26204() instanceof AbstractMachineblock machineblock) {
            return energyTier == EnergyTier.INFINITE ? Long.MAX_VALUE : machineblock.getMaxCapacity() + extra + energyTier.getMaxOutput();
        }
        return energyTier == EnergyTier.INFINITE ? Long.MAX_VALUE : 512 + extra + energyTier.getMaxOutput();
    }
}
