package com.skniro.industrial_elixir.screen.ingame.machine;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.renderer.chunk.ChunkMapRenderer;
import com.skniro.industrial_elixir.screen.handler.machine.ChunkLoaderScreenHandler;
import com.skniro.industrial_elixir.util.MouseUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.util.List;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class ChunkLoaderScreen extends class_465<ChunkLoaderScreenHandler> {
    private static final class_2960 TEXTURE =
            class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/machine/chunk_loader.png");
    private final ChunkMapRenderer chunkMapRenderer = new ChunkMapRenderer();
    private static final int GRID_X = 48;
    private static final int GRID_Y = 16;
    private static final int CELL_SIZE = 14;
    private static final int CELL_GAP = 2;
    private static final int CELL_STRIDE = CELL_SIZE + CELL_GAP;

    private static final int ENERGY_BAR_X = 8;
    private static final int ENERGY_BAR_Y = 12;
    private static final int ENERGY_BAR_W = 10;
    private static final int ENERGY_BAR_H = 50;

    public ChunkLoaderScreen(ChunkLoaderScreenHandler menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
        field_25268 = 4;
        field_25269 = 8;
        field_25270 = 72;
    }

    @Override
    protected void method_2388(class_332 graphics, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        graphics.method_51439(field_22793, this.field_22785, this.field_25267, this.field_25268, -12566464, false);

        // Status: Work / Not Work
        int loadedCount = Integer.bitCount(field_2797.blockEntity.getSelectedChunks()) + 1;
        long energy = field_2797.blockEntity.energyContainer.getSideStorage(null).getAmount();
        boolean canWork = energy >= loadedCount;
        int statusColor = canWork ? 0xFF00CC00 : 0xFFCC0000;
        class_2561 statusText = class_2561.method_43470(canWork ? "Work" : "Not Work");
        graphics.method_51439(field_22793, statusText, 128, 64, statusColor, true);

        // Energy tooltip
        if (MouseUtil.isMouseOver(mouseX, mouseY, x + ENERGY_BAR_X, y + ENERGY_BAR_Y, ENERGY_BAR_W, ENERGY_BAR_H)) {
            graphics.method_51437(Screens.getTextRenderer(this),
                    List.of(class_2561.method_43470(field_2797.blockEntity.energyContainer.getSideStorage(null).getAmount()
                            + " / " + field_2797.blockEntity.energyContainer.getSideStorage(null).getCapacity() + " E")),
                    Optional.empty(), mouseX - x, mouseY - y);
        }

        // Chunk grid tooltip
        int mask = field_2797.blockEntity.getSelectedChunks();
        for (int i = 0; i < 25; i++) {
            int row = i / 5;
            int col = i % 5;
            int cx = x + GRID_X + col * CELL_STRIDE;
            int cy = y + GRID_Y + row * CELL_STRIDE;

            if (MouseUtil.isMouseOver(mouseX, mouseY, cx, cy, CELL_SIZE, CELL_SIZE)) {
                int chunkOffX = col - 2;
                int chunkOffZ = row - 2;
                boolean loaded = (mask & (1 << i)) != 0 || i == 12;
                String status = loaded ? "\u00a7aForce Loaded" : "\u00a77Not Loaded";
                if (i == 12) status = "\u00a7aAlways Loaded";
                graphics.method_51437(Screens.getTextRenderer(this),
                        List.of(class_2561.method_43470("Chunk (" + chunkOffX + ", " + chunkOffZ + ") " + status)),
                        Optional.empty(), mouseX - x, mouseY - y);
                break;
            }
        }
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTicks, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        // Background texture
        graphics.method_25290(TEXTURE, x, y, 0, 0, field_2792, field_2779, 256, 256);

        // Energy bar
        int energyHeight = field_2797.getScaledEnergyHeight();
        if (energyHeight > 0) {
            graphics.method_25290(TEXTURE,
                    x + ENERGY_BAR_X, y + ENERGY_BAR_Y + (ENERGY_BAR_H - energyHeight),
                    176, ENERGY_BAR_H - energyHeight, ENERGY_BAR_W, energyHeight, 256, 256);
        }

        // 5x5 chunk map grid
        //renderChunkGrid(graphics, x, y, mouseX, mouseY);
        class_2338 machinePos = field_2797.blockEntity.method_11016();
        class_1923 machineChunk = new class_1923(machinePos.method_10263(), machinePos.method_10260());

        chunkMapRenderer.render(
                graphics,
                field_22787.field_1687,
                field_22787.field_1724.method_31476(),
                x + GRID_X,
                y + GRID_Y,
                field_2797.blockEntity.getSelectedChunks(),
                mouseX,
                mouseY
        );
    }

    private void renderChunkGrid(class_332 graphics, int guiX, int guiY, int mouseX, int mouseY) {
        int mask = field_2797.blockEntity.getSelectedChunks();

        for (int i = 0; i < 25; i++) {
            int row = i / 5;
            int col = i % 5;
            int cx = guiX + GRID_X + col * CELL_STRIDE;
            int cy = guiY + GRID_Y + row * CELL_STRIDE;

            boolean selected = (mask & (1 << i)) != 0 || i == 12;
            boolean isCenter = i == 12;
            boolean hovered = MouseUtil.isMouseOver(mouseX, mouseY, cx, cy, CELL_SIZE, CELL_SIZE);

            if (isCenter) {
                graphics.method_25294(cx, cy, cx + CELL_SIZE, cy + CELL_SIZE, 0xFF226622);
            } else if (selected) {
                graphics.method_25294(cx, cy, cx + CELL_SIZE, cy + CELL_SIZE, 0x8800CC00);
            } else {
                graphics.method_25294(cx, cy, cx + CELL_SIZE, cy + CELL_SIZE, 0x88333333);
            }

            // Border
            int borderColor = hovered ? 0xFFFFFFFF : 0xFF555555;
            graphics.method_25294(cx, cy, cx + CELL_SIZE, cy + 1, borderColor);           // top
            graphics.method_25294(cx, cy + CELL_SIZE - 1, cx + CELL_SIZE, cy + CELL_SIZE, borderColor); // bottom
            graphics.method_25294(cx, cy, cx + 1, cy + CELL_SIZE, borderColor);           // left
            graphics.method_25294(cx + CELL_SIZE - 1, cy, cx + CELL_SIZE, cy + CELL_SIZE, borderColor); // right
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return super.method_25402(mouseX, mouseY, button);
        }

        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        for (int i = 0; i < 25; i++) {
            if (i == 12) continue;

            int row = i / 5;
            int col = i % 5;

            int cx = x + GRID_X + col * CELL_STRIDE;
            int cy = y + GRID_Y + row * CELL_STRIDE;

            if (mouseX >= cx && mouseX < cx + CELL_SIZE
                    && mouseY >= cy && mouseY < cy + CELL_SIZE) {

                field_22787.field_1761.method_2900(field_2797.field_7763, i);
                return true;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }
}
