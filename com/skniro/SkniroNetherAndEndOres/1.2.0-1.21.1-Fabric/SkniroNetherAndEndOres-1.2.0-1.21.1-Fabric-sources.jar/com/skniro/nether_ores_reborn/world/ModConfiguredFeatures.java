package com.skniro.nether_ores_reborn.world;

import com.skniro.nether_ores_reborn.NetherOres;
import com.skniro.nether_ores_reborn.block.NetherOresBlocks;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3124;
import net.minecraft.class_3481;
import net.minecraft.class_3798;
import net.minecraft.class_3819;
import net.minecraft.class_3825;
import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_7924;

public class ModConfiguredFeatures {
    public static final class_5321<class_2975<?, ?>> Nether_Coal_ORE_KEY = registerKey("coal_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Copper_KEY = registerKey("copper_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Diamond_KEY = registerKey("diamond_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Emerald_KEY = registerKey("emerald_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Gold_KEY = registerKey("gold_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Iron_KEY = registerKey("iron_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Lapis_KEY = registerKey("lapis_ore");
    public static final class_5321<class_2975<?, ?>> Nether_Redstone_ORE_KEY = registerKey("redstone_ore");

    public static final class_5321<class_2975<?, ?>> End_Coal_ORE_KEY = registerKey("end_coal_ore");
    public static final class_5321<class_2975<?, ?>> End_Copper_KEY = registerKey("end_copper_ore");
    public static final class_5321<class_2975<?, ?>> End_Diamond_KEY = registerKey("end_diamond_ore");
    public static final class_5321<class_2975<?, ?>> End_Emerald_KEY = registerKey("end_emerald_ore");
    public static final class_5321<class_2975<?, ?>> End_Gold_KEY = registerKey("end_gold_ore");
    public static final class_5321<class_2975<?, ?>> End_Iron_KEY = registerKey("end_iron_ore");
    public static final class_5321<class_2975<?, ?>> End_Lapis_KEY = registerKey("end_lapis_ore");
    public static final class_5321<class_2975<?, ?>> End_Redstone_ORE_KEY = registerKey("end_redstone_ore");

    public static void bootstrap(class_7891<class_2975<?, ?>> context) {
        class_3825 stoneReplaceables = new class_3819(class_2246.field_10515);
        class_3825 deepslateReplaceables = new class_3798(class_3481.field_28993);
        class_3825 endStoneReplaceables = new class_3819(class_2246.field_10471);

        List<class_3124.class_5876> netherCoalOres =
                List.of(class_3124.method_33994(stoneReplaceables, NetherOresBlocks.Nether_Coal_Ore.method_9564()));
        List<class_3124.class_5876> netherCopperOres =
                List.of(class_3124.method_33994(stoneReplaceables, NetherOresBlocks.Nether_Copper_Ore.method_9564()));
        List<class_3124.class_5876> netherDiamondOres =
                List.of(class_3124.method_33994(stoneReplaceables, NetherOresBlocks.Nether_Diamond_Ore.method_9564()));
        List<class_3124.class_5876> netherEmeraldOres =
                List.of(class_3124.method_33994(stoneReplaceables, NetherOresBlocks.Nether_Emerald_Ore.method_9564()));
        List<class_3124.class_5876> netherGoldOres =
                List.of(class_3124.method_33994(stoneReplaceables, NetherOresBlocks.Nether_Gold_Ore.method_9564()));
        List<class_3124.class_5876> netherIronOres =
                List.of(class_3124.method_33994(stoneReplaceables, NetherOresBlocks.Nether_Iron_Ore.method_9564()));
        List<class_3124.class_5876> netherLapisOres =
                List.of(class_3124.method_33994(stoneReplaceables, NetherOresBlocks.Nether_Lapis_Ore.method_9564()));
        List<class_3124.class_5876> netherRedstoneOres =
                List.of(class_3124.method_33994(stoneReplaceables, NetherOresBlocks.Nether_Redstone_Ore.method_9564()));

        register(context, Nether_Coal_ORE_KEY, class_3031.field_13517, new class_3124(netherCoalOres, 10));
        register(context, Nether_Copper_KEY, class_3031.field_13517, new class_3124(netherCopperOres, 8));
        register(context, Nether_Diamond_KEY, class_3031.field_13517, new class_3124(netherDiamondOres, 8));
        register(context, Nether_Emerald_KEY, class_3031.field_13517, new class_3124(netherEmeraldOres, 3));
        register(context, Nether_Gold_KEY, class_3031.field_13517, new class_3124(netherGoldOres, 8));
        register(context, Nether_Iron_KEY, class_3031.field_13517, new class_3124(netherIronOres, 8));
        register(context, Nether_Lapis_KEY, class_3031.field_13517, new class_3124(netherLapisOres, 8));
        register(context, Nether_Redstone_ORE_KEY, class_3031.field_13517, new class_3124(netherRedstoneOres, 8));


        List<class_3124.class_5876> endCoalOres =
                List.of(class_3124.method_33994(endStoneReplaceables, NetherOresBlocks.End_Coal_Ore.method_9564()));
        List<class_3124.class_5876> endCopperOres =
                List.of(class_3124.method_33994(endStoneReplaceables, NetherOresBlocks.End_Copper_Ore.method_9564()));
        List<class_3124.class_5876> endDiamondOres =
                List.of(class_3124.method_33994(endStoneReplaceables, NetherOresBlocks.End_Diamond_Ore.method_9564()));
        List<class_3124.class_5876> endEmeraldOres =
                List.of(class_3124.method_33994(endStoneReplaceables, NetherOresBlocks.End_Emerald_Ore.method_9564()));
        List<class_3124.class_5876> endGoldOres =
                List.of(class_3124.method_33994(endStoneReplaceables, NetherOresBlocks.End_Gold_Ore.method_9564()));
        List<class_3124.class_5876> endIronOres =
                List.of(class_3124.method_33994(endStoneReplaceables, NetherOresBlocks.End_Iron_Ore.method_9564()));
        List<class_3124.class_5876> endLapisOres =
                List.of(class_3124.method_33994(endStoneReplaceables, NetherOresBlocks.End_Lapis_Ore.method_9564()));
        List<class_3124.class_5876> endRedstoneOres =
                List.of(class_3124.method_33994(endStoneReplaceables, NetherOresBlocks.End_Redstone_Ore.method_9564()));

        register(context, End_Coal_ORE_KEY, class_3031.field_13517, new class_3124(endCoalOres, 6));
        register(context, End_Copper_KEY, class_3031.field_13517, new class_3124(endCopperOres, 4));
        register(context, End_Diamond_KEY, class_3031.field_13517, new class_3124(endDiamondOres, 4));
        register(context, End_Emerald_KEY, class_3031.field_13517, new class_3124(endEmeraldOres, 2));
        register(context, End_Gold_KEY, class_3031.field_13517, new class_3124(endGoldOres, 5));
        register(context, End_Iron_KEY, class_3031.field_13517, new class_3124(endIronOres, 5));
        register(context, End_Lapis_KEY, class_3031.field_13517, new class_3124(endLapisOres, 4));
        register(context, End_Redstone_ORE_KEY, class_3031.field_13517, new class_3124(endRedstoneOres, 4));
    }

    public static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, class_2960.method_60655(NetherOres.MOD_ID, name));
    }
    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_2975<?, ?>> context,
                                                                                   class_5321<class_2975<?, ?>> key, F feature, FC configuration) {
        context.method_46838(key, new class_2975<>(feature, configuration));
    }
}

