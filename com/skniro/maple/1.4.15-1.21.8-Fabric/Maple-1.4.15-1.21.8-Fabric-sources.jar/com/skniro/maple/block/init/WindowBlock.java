package com.skniro.maple.block.init;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.block.*;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2750;
import net.minecraft.class_2754;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_8177;
import org.jetbrains.annotations.Nullable;

public class WindowBlock extends class_2383 {
    public static final MapCodec<WindowBlock> CODEC = RecordCodecBuilder.mapCodec((instance) -> {
        return instance.group(method_54096(),class_8177.field_46534.fieldOf("block_set_type").forGetter((block) -> {
            return block.blockSetType;
        })).apply(instance, WindowBlock::new);
    });
    public static final class_2754<class_2350> FACING;
    public static final class_2754<class_2750> HINGE;
    public static final class_2746 OPEN;
    public static final class_2746 POWERED;
    public static final class_265 WEST_OPEN_SHAPE;
    public static final class_265 EAST_OPEN_SHAPE;
    public static final class_265 NORTH_OPEN_SHAPE;
    public static final class_265 SOUTH_OPEN_SHAPE;

    public static final class_265 WEST_CLOSED_SHAPE;
    public static final class_265 EAST_CLOSED_SHAPE;
    public static final class_265 NORTH_CLOSED_SHAPE;
    public static final class_265 SOUTH_CLOSED_SHAPE;
    private final class_8177 blockSetType;

    public WindowBlock(class_2251 settings, class_8177 blockSetType) {
        super(settings.method_9626(blockSetType.comp_1290()));
        this.blockSetType = blockSetType;
        this.method_9590(this.field_10647.method_11664()
                .method_11657(field_11177, class_2350.field_11043)
                .method_11657(OPEN, false)
                .method_11657(HINGE, class_2750.field_12588)
                .method_11657(POWERED, false));
    }


    public class_8177 getBlockSetType() {
        return this.blockSetType;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2350 direction = state.method_11654(field_11177);
        boolean closed = !state.method_11654(OPEN);

        switch (direction) {
            case field_11034:
                return closed ? EAST_CLOSED_SHAPE : EAST_OPEN_SHAPE;
            case field_11035:
                return closed ? SOUTH_CLOSED_SHAPE : SOUTH_OPEN_SHAPE;
            case field_11039:
                return closed ? WEST_CLOSED_SHAPE : WEST_OPEN_SHAPE;
            case field_11043:
            default:
                return closed ? NORTH_CLOSED_SHAPE : NORTH_OPEN_SHAPE;
        }
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2338 blockPos = ctx.method_8037();
        class_1937 world = ctx.method_8045();
        boolean powered = world.method_49803(blockPos);
        return this.method_9564()
                .method_11657(field_11177, ctx.method_8042())
                .method_11657(POWERED, powered)
                .method_11657(OPEN, powered);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!this.blockSetType.comp_1471()) {
            return class_1269.field_5811;
        }

        state = state.method_28493(OPEN);
        world.method_8652(pos, state, 10);
        this.playOpenCloseSound(player, world, pos, state.method_11654(OPEN));
        world.method_33596(player, state.method_11654(OPEN) ? class_5712.field_28168 : class_5712.field_28169, pos);

        return class_1269.field_5812;
    }

    private void playOpenCloseSound(@Nullable class_1297 entity, class_1937 world, class_2338 pos, boolean open) {
        world.method_8396(entity, pos, open ? this.blockSetType.comp_1292() : this.blockSetType.comp_1291(), class_3419.field_15245, 1.0F, world.method_8409().method_43057() * 0.1F + 0.9F);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, OPEN, HINGE, POWERED);
    }

    static {
        field_11177 = class_2383.field_11177;
        OPEN = class_2741.field_12537;
        HINGE = class_2741.field_12520;
        POWERED = class_2741.field_12484;


        WEST_CLOSED_SHAPE = class_2248.method_9541(7.0, 0.0, 0.0, 8.5, 16.0, 16.0);
        EAST_CLOSED_SHAPE = class_2248.method_9541(7.5, 0.0, 0.0, 9.0, 16.0, 16.0);
        NORTH_CLOSED_SHAPE = class_2248.method_9541(0.0, 0.0, 7.0, 16.0, 16.0, 8.5);
        SOUTH_CLOSED_SHAPE = class_2248.method_9541(0.0, 0.0, 7.5, 16.0, 16.0, 9.0);

        WEST_OPEN_SHAPE = class_2248.method_9541(0.0, 0.0, 14.5, 16.0, 16.0, 16.0);
        EAST_OPEN_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 1.5);
        NORTH_OPEN_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 1.5, 16.0, 16.0);
        SOUTH_OPEN_SHAPE = class_2248.method_9541(14.5, 0.0, 0.0, 16.0, 16.0, 16.0);
    }

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }
}

