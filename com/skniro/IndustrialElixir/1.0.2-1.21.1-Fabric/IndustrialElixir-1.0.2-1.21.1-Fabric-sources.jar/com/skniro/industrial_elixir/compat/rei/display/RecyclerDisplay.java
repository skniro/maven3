package com.skniro.industrial_elixir.compat.rei.display;

import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.recipe.machine.RecyclerCraftingRecipe;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RecyclerDisplay extends BasicDisplay {
    private int count;

    public static final CategoryIdentifier<RecyclerDisplay> Recycler =
            CategoryIdentifier.of(IndustrialElixir.MOD_ID, "recycler");

    public static final DisplaySerializer<RecyclerDisplay> SERIALIZER = BasicDisplay.Serializer.<RecyclerDisplay>of(
            (inputs, outputs, location, tag) -> new RecyclerDisplay(outputs, location),
            (display, tag) -> {
            }
    );

    public RecyclerDisplay(RecyclerCraftingRecipe recipe) {
        super(List.of(EntryIngredients.ofItemStacks(getAllItems())),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.output()))));
    }

    public RecyclerDisplay(List<EntryIngredient> outputs, Optional<class_2960> location) {
        super(List.of(EntryIngredients.ofItemStacks(getAllItems())), outputs, location);
    }

    public RecyclerDisplay(class_8786<RecyclerCraftingRecipe> recipe){
        super(List.of(EntryIngredients.ofItemStacks(getAllItems())),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.comp_1933().output()))));
    }

    private static List<class_1799> getAllItems() {
        List<class_1799> list = new ArrayList<>();
        for (class_1792 item : class_7923.field_41178) {
            list.add(new class_1799(item));
        }
        return list;
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return RecyclerDisplay.Recycler;
    }

}