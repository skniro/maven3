package com.skniro.usefulfood.util;

import com.skniro.usefulfood.item.UsefulFoodItems;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.class_1299;
import net.minecraft.class_141;
import net.minecraft.class_219;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;

public class ModLootTableModifiers {

    public static void modifyLootTables() {
        LootTableEvents.MODIFY.register((id, tableBuilder, source) -> {
            if(class_1299.field_6114.method_16351() == id) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(1f)) // Drops 100% of the time
                        .method_351(class_77.method_411(UsefulFoodItems.SquidTentacleRaw))
                        .apply(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)).method_515());
                tableBuilder.method_336(poolBuilder);
            }
                if(class_1299.field_28402.method_16351() == id) {
                    class_55.class_56 poolBuilder = class_55.method_347()
                            .method_352(class_44.method_32448(1))
                            .method_356(class_219.method_932(1f)) // Drops 100% of the time
                            .method_351(class_77.method_411(UsefulFoodItems.SquidTentacleRaw))
                            .apply(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)).method_515());
                    tableBuilder.method_336(poolBuilder);
                }
        });
    }
}