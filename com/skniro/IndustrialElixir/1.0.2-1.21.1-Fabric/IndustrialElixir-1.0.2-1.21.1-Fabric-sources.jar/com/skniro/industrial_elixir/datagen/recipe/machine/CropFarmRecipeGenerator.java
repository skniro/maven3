package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.growableoresir.block.GrowableICOresBlocks;
import com.skniro.industrial_elixir.api.data.recipe.CraftingDataHelper;
import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class CropFarmRecipeGenerator extends CraftingDataHelper {
    public CropFarmRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                // 小麦
                createCropFarm(class_1802.field_8861,3)
                        .input(class_1802.field_8317)
                        .output2(class_1802.field_8317)
                        .processTime(600)
                        .method_33530("has_wheat_seeds", has(class_1802.field_8317))
                        .method_36443(output, "wheat_seeds_to_wheat");


                // 胡萝卜
                createCropFarm(class_1802.field_8179,3)
                        .input(class_1802.field_8179)
                        .processTime(600)
                        .method_33530("has_carrot", has(class_1802.field_8179))
                        .method_36443(output, "carrot_to_carrot");


                // 马铃薯
                createCropFarm(class_1802.field_8567,3)
                        .input(class_1802.field_8567)
                        .processTime(600)
                        .method_33530("has_potato", has(class_1802.field_8567))
                        .method_36443(output, "potato_to_potato");


                // 甜菜根
                createCropFarm(class_1802.field_8186,3)
                        .input(class_1802.field_8309)
                        .output2(class_1802.field_8309)
                        .processTime(600)
                        .method_33530("has_beetroot_seeds", has(class_1802.field_8309))
                        .method_36443(output, "beetroot_seeds_to_beetroot");


                // 甘蔗
                createCropFarm(class_1802.field_17531,2)
                        .input(class_1802.field_17531)
                        .processTime(2400)
                        .method_33530("has_sugar_cane", has(class_1802.field_17531))
                        .method_36443(output, "sugar_cane_to_sugar_cane");


                // 仙人掌
                createCropFarm(class_1802.field_17520)
                        .input(class_1802.field_17520)
                        .processTime(2400)
                        .method_33530("has_cactus", has(class_1802.field_17520))
                        .method_36443(output, "cactus_to_cactus");


                // 竹子
                createCropFarm(class_1802.field_8648,9)
                        .input(class_1802.field_8648)
                        .processTime(1800)
                        .method_33530("has_bamboo", has(class_1802.field_8648))
                        .method_36443(output, "bamboo_to_bamboo");


                // 可可豆
                createCropFarm(class_1802.field_8116,3)
                        .input(class_1802.field_8116)
                        .processTime(800)
                        .method_33530("has_cocoa_beans", has(class_1802.field_8116))
                        .method_36443(output, "cocoa_beans_to_cocoa_beans");


                // 南瓜
                createCropFarm(class_1802.field_17518)
                        .input(class_1802.field_46249)
                        .output2(class_1802.field_46249)
                        .processTime(1200)
                        .method_33530("has_pumpkin_seeds", has(class_1802.field_46249))
                        .method_36443(output, "pumpkin_seeds_to_pumpkin");


                // 西瓜
                createCropFarm(class_1802.field_46250)
                        .input(class_1802.field_46250)
                        .output2(class_1802.field_8497, 9)
                        .processTime(1200)
                        .method_33530("has_melon_seeds", has(class_1802.field_46250))
                        .method_36443(output, "melon_seeds_to_melon_slice");


                // 下界疣
                createCropFarm(class_1802.field_8790, 3)
                        .input(class_1802.field_8790)
                        .processTime(800)
                        .method_33530("has_nether_wart", has(class_1802.field_8790))
                        .method_36443(output, "nether_wart_to_nether_wart");

                createCropFarm(GrowableICOresBlocks.IER_Bronze_Cane)
                        .input(GrowableICOresBlocks.IER_Bronze_Cane)
                        .processTime(2400)
                        .method_33530("has_sugar_cane", has(GrowableICOresBlocks.IER_Bronze_Cane))
                        .method_36443(output, "ier_bronze_ore_cane_to_ier_bronze_ore_cane");

                // Steel Ore Cane
                createCropFarm(GrowableICOresBlocks.IER_steel_Cane)
                        .input(GrowableICOresBlocks.IER_steel_Cane)
                        .processTime(3000)
                        .method_33530("has_steel_ore_cane", has(GrowableICOresBlocks.IER_steel_Cane))
                        .method_36443(output, "ier_steel_ore_cane_to_ier_steel_ore_cane");


                // Silver Ore Cane
                createCropFarm(GrowableICOresBlocks.IER_silver_Cane)
                        .input(GrowableICOresBlocks.IER_silver_Cane)
                        .processTime(2400)
                        .method_33530("has_silver_ore_cane", has(GrowableICOresBlocks.IER_silver_Cane))
                        .method_36443(output, "ier_silver_ore_cane_to_ier_silver_ore_cane");


                // Tin Ore Cane
                createCropFarm(GrowableICOresBlocks.IER_Tin_Cane)
                        .input(GrowableICOresBlocks.IER_Tin_Cane)
                        .processTime(2400)
                        .method_33530("has_tin_ore_cane", has(GrowableICOresBlocks.IER_Tin_Cane))
                        .method_36443(output, "ier_tin_ore_cane_to_ier_tin_ore_cane");


                // Sacred Ore Cane
                createCropFarm(GrowableICOresBlocks.IER_SACRED_Cane)
                        .input(GrowableICOresBlocks.IER_SACRED_Cane)
                        .processTime(2400)
                        .method_33530("has_sacred_ore_cane", has(GrowableICOresBlocks.IER_SACRED_Cane))
                        .method_36443(output, "ier_sacred_ore_cane_to_ier_sacred_ore_cane");


                // Lead Ore Cane
                createCropFarm(GrowableICOresBlocks.IER_LEAD_Cane)
                        .input(GrowableICOresBlocks.IER_LEAD_Cane)
                        .processTime(2400)
                        .method_33530("has_lead_ore_cane", has(GrowableICOresBlocks.IER_LEAD_Cane))
                        .method_36443(output, "ier_lead_ore_cane_to_ier_lead_ore_cane");


               // 橡树
                createCropFarm(class_1802.field_17535)
                        .input(class_1802.field_17535)
                        .output2(class_1802.field_8583, 5)
                        .output3(class_1802.field_8279, 1)
                        .processTime(1600)
                        .method_33530("has_oak_sapling", has(class_1802.field_17535))
                        .method_36443(output, "oak_sapling_to_oak_log");


               // 云杉
                createCropFarm(class_1802.field_17536)
                        .input(class_1802.field_17536)
                        .output2(class_1802.field_8684, 6)
                        .processTime(1600)
                        .method_33530("has_spruce_sapling", has(class_1802.field_17536))
                        .method_36443(output, "spruce_sapling_to_spruce_log");


               // 白桦
                createCropFarm(class_1802.field_17537)
                        .input(class_1802.field_17537)
                        .output2(class_1802.field_8170, 5)
                        .processTime(1600)
                        .method_33530("has_birch_sapling", has(class_1802.field_17537))
                        .method_36443(output, "birch_sapling_to_birch_log");


               // 丛林木
                createCropFarm(class_1802.field_17538)
                        .input(class_1802.field_17538)
                        .output2(class_1802.field_8125, 6)
                        .processTime(1000)
                        .method_33530("has_jungle_sapling", has(class_1802.field_17538))
                        .method_36443(output, "jungle_sapling_to_jungle_log");


               // 金合欢
                createCropFarm(class_1802.field_17539)
                        .input(class_1802.field_17539)
                        .output2(class_1802.field_8820, 5)
                        .processTime(1000)
                        .method_33530("has_acacia_sapling", has(class_1802.field_17539))
                        .method_36443(output, "acacia_sapling_to_acacia_log");


               // 深色橡木
                createCropFarm(class_1802.field_17540,2)
                        .input(class_1802.field_17540)
                        .output2(class_1802.field_8652, 10)
                        .processTime(1000)
                        .method_33530("has_dark_oak_sapling", has(class_1802.field_17540))
                        .method_36443(output, "dark_oak_saplings_to_dark_oak_log");


               // 红树
                createCropFarm(class_1802.field_37508)
                        .input(class_1802.field_37508)
                        .output2(class_1802.field_37512, 6)
                        .processTime(1000)
                        .method_33530("has_mangrove_propagule", has(class_1802.field_37508))
                        .method_36443(output, "mangrove_propagule_to_mangrove_log");


               // 樱花
                createCropFarm(class_1802.field_42688)
                        .input(class_1802.field_42688)
                        .output2(class_1802.field_42692, 6)
                        .processTime(1000)
                        .method_33530("has_cherry_sapling", has(class_1802.field_42688))
                        .method_36443(output, "cherry_sapling_to_cherry_log");

               // 绯红菌树
                createCropFarm(class_1802.field_21987)
                        .input(class_1802.field_21987)
                        .output2(class_1802.field_21981, 8)
                        .processTime(1000)
                        .method_33530("has_crimson_fungus", has(class_1802.field_21987))
                        .method_36443(output, "crimson_fungus_to_crimson_stem");


               // 诡异菌树
                createCropFarm(class_1802.field_21988)
                        .input(class_1802.field_21988)
                        .output2(class_1802.field_21982, 8)
                        .processTime(1000)
                        .method_33530("has_warped_fungus", has(class_1802.field_21988))
                        .method_36443(output, "warped_fungus_to_warped_stem");

                // 紫颂果
                createCropFarm(class_1802.field_8710)
                        .input(class_1802.field_8710)
                        .output2(class_1802.field_8233, 4)
                        .processTime(1200)
                        .method_33530("has_chorus_flower", has(class_1802.field_8710))
                        .method_36443(output, "chorus_flower_to_chorus_fruit");

                // 火把花
                createCropFarm(class_1802.field_42711)
                        .input(class_1802.field_42711)
                        .output2(class_1802.field_42695, 1)
                        .processTime(600)
                        .method_33530("has_torchflower_seeds", has(class_1802.field_42711))
                        .method_36443(output, "torchflower_seeds_to_torchflower");


                // 瓶子草
                createCropFarm(class_1802.field_43195)
                        .input(class_1802.field_43195)
                        .output2(class_1802.field_43192, 1)
                        .processTime(600)
                        .method_33530("has_pitcher_pod", has(class_1802.field_43195))
                        .method_36443(output, "pitcher_pod_to_pitcher_plant");

                createCropFarm(GrowableOresItems.Rubber, 3)
                        .input(GeneralBlocks.Rubber_SAPLING)
                        .output2(GeneralBlocks.Rubber_LOG, 6)
                        .output3(GeneralBlocks.Rubber_SAPLING)
                        .processTime(600)
                        .method_33530("has_rubber_sapling", has(GeneralBlocks.Rubber_SAPLING))
                        .method_36443(output, "rubber_sapling_to_rubber");
            }
        };
    }

    @Override
    public String method_10321() {
        return "CropFarm";
    }
}
