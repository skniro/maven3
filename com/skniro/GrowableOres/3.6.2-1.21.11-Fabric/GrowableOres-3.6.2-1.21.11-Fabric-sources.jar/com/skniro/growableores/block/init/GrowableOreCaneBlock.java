package com.skniro.growableores.block.init;

import com.mojang.serialization.MapCodec;
import java.util.Iterator;

import com.skniro.growableores.conifg.GrowableOresConfig;
import com.skniro.growableores.registry.tag.GrowableBlockTags;
import com.skniro.growableores.registry.tag.GrowableFluidTags;
import net.minecraft.block.*;
import net.minecraft.class_10225;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2353;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5819;


public class GrowableOreCaneBlock extends class_2248 implements class_2256 {
    public static final MapCodec<GrowableOreCaneBlock> CODEC = method_54094(GrowableOreCaneBlock::new);
    public static final class_2758 AGE;
    protected static final float field_31258 = 6.0F;
    protected static final class_265 SHAPE;

    public MapCodec<GrowableOreCaneBlock> method_53969() {
        return field_46280;
    }

    public GrowableOreCaneBlock(class_4970.class_2251 settings) {
        super(settings);
        this.method_9590((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(AGE, 0));
    }

    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    protected void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (!state.method_26184(world, pos)) {
            world.method_22352(pos, true);
        }
    }

    protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (world.method_22347(pos.method_10084())) {
            int i;
            for (i = 1; world.method_8320(pos.method_10087(i)).method_27852(this); ++i) {
            }
            if (i < GrowableOresConfig.Ore_Cane_Max_Height) {
                int j = (Integer) state.method_11654(AGE);
                if (j == 15) {
                    world.method_8501(pos.method_10084(), this.method_9564());
                    world.method_8652(pos, (class_2680) state.method_11657(AGE, 0), 4);
                } else {
                    world.method_8652(pos, (class_2680) state.method_11657(AGE, j + 1), 4);
                }
            }
        }
    }

    protected class_2680 method_9559(class_2680 state, class_4538 world, class_10225 tickView, class_2338 pos, class_2350 direction, class_2338 neighborPos, class_2680 neighborState, class_5819 random) {
        if (!state.method_26184(world, pos)) {
            tickView.method_64310(pos, this, 1);
        }

        return super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    protected boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2680 blockState = world.method_8320(pos.method_10074());
        if (blockState.method_27852(this)) {
            return true;
        } else {
            if (blockState.method_26164(class_3481.field_29822) || blockState.method_26164(class_3481.field_15466) || blockState.method_26164(GrowableBlockTags.GrowBlock)) {
                class_2338 blockPos = pos.method_10074();
                Iterator var6 = class_2353.field_11062.iterator();

                while(var6.hasNext()) {
                    class_2350 direction = (class_2350)var6.next();
                    class_2680 blockState2 = world.method_8320(blockPos.method_10093(direction));
                    class_3610 fluidState = world.method_8316(blockPos.method_10093(direction));
                    if (fluidState.method_15767(class_3486.field_15517) || blockState2.method_27852(class_2246.field_10110) || (fluidState.method_15767(GrowableFluidTags.GrowFluid))) {
                        return true;
                    }
                }
            }

            return false;
        }
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{AGE});
    }

    protected class_2758 getAgeProperty() {
        return AGE;
    }

    public int getAge(class_2680 state) {
        return state.method_11654(this.getAgeProperty());
    }

    @Override
    public boolean method_9651(class_4538 levelReader, class_2338 pos, class_2680 state) {
        if(GrowableOresConfig.Ore_Cane_Bonemeal){
            return this.getAge(state) < 15;
        }
        return false;
    }

    @Override
    public boolean method_9650(class_1937 level, class_5819 random, class_2338 pos, class_2680 state) {
        if(GrowableOresConfig.Ore_Cane_Bonemeal) {
            return true;
        }
        return false;
    }

    @Override
    public void method_9652(class_3218 level, class_5819 randomSource, class_2338 pos, class_2680 state) {
        if (GrowableOresConfig.Ore_Cane_Bonemeal) {
            for (int y = pos.method_10264(); y <= level.method_31605(); y++) {
                class_2338 uppos = new class_2338(pos.method_10263(), y, pos.method_10260());
                class_2248 block = level.method_8320(uppos).method_26204();
                if (block != this) {
                    if (block.equals(class_2246.field_10124)) {
                        level.method_8501(uppos, this.method_9564());
                        level.method_20290(2005, uppos, 0);
                        level.method_20290(2005, uppos.method_10084(), 0);
                    }
                    break;
                }
            }
        }
    }


    static {
        AGE = class_2741.field_12498;
        SHAPE = class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 16.0, 14.0);
    }
}