package com.skniro.growable_ores_extension.datagen.recipe.machine;

import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.item.AdvancedItems;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class CompressorRecipeGenerator extends FabricRecipeProvider {
    public CompressorRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {
                createCompressor(class_1802.field_8773).input(class_1802.field_8620, 9)
                        .method_33530("has_base_item", method_10426(class_1802.field_8620)).method_10431(field_53721);
                createCompressor(GrowableOresItems.IRON_PLATE).input(GrowableOresItems.IRON_DUST, 1)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.IRON_DUST)).method_10431(field_53721);
                createCompressor(GrowableOresItems.DENSE_IRON_PLATE).input(GrowableOresItems.IRON_PLATE, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.IRON_PLATE)).method_10431(field_53721);
                createCompressor(GrowableOresItems.IRON_DUST).input(GrowableOresItems.SMALL_IRON_DUST, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.SMALL_IRON_DUST)).method_10431(field_53721);

                createCompressor(GeneralBlocks.Tin_Block).input(GrowableOresItems.TIN_INGOT, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.TIN_INGOT)).method_10431(field_53721);
                createCompressor(GrowableOresItems.TIN_PLATE).input(GrowableOresItems.TIN_DUST, 1)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.TIN_DUST)).method_10431(field_53721);
                createCompressor(GrowableOresItems.DENSE_TIN_PLATE).input(GrowableOresItems.TIN_PLATE, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.TIN_PLATE)).method_10431(field_53721);
                createCompressor(GrowableOresItems.TIN_DUST).input(GrowableOresItems.SMALL_TIN_DUST, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.SMALL_TIN_DUST)).method_10431(field_53721);

                createCompressor(class_1802.field_27071).input(class_1802.field_27022, 9)
                        .method_33530("has_base_item", method_10426(class_1802.field_27022)).method_10431(field_53721);
                createCompressor(GrowableOresItems.COPPER_PLATE).input(GrowableOresItems.COPPER_DUST, 1)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.COPPER_DUST)).method_10431(field_53721);
                createCompressor(GrowableOresItems.DENSE_COPPER_PLATE).input(GrowableOresItems.COPPER_PLATE, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.COPPER_PLATE)).method_10431(field_53721);
                createCompressor(GrowableOresItems.COPPER_DUST).input(GrowableOresItems.SMALL_COPPER_DUST, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.SMALL_COPPER_DUST)).method_10431(field_53721);

                createCompressor(class_1802.field_8494).input(class_1802.field_8695, 9)
                        .method_33530("has_base_item", method_10426(class_1802.field_8695)).method_10431(field_53721);
                createCompressor(GrowableOresItems.GOLD_PLATE).input(GrowableOresItems.GOLD_DUST, 1)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.GOLD_DUST)).method_10431(field_53721);
                createCompressor(GrowableOresItems.DENSE_GOLD_PLATE).input(GrowableOresItems.GOLD_PLATE, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.GOLD_PLATE)).method_10431(field_53721);
                createCompressor(GrowableOresItems.GOLD_DUST).input(GrowableOresItems.SMALL_GOLD_DUST, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.SMALL_GOLD_DUST)).method_10431(field_53721);

                createCompressor(GeneralBlocks.Silver_Block).input(GrowableOresItems.SILVER_INGOT, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.SILVER_INGOT)).method_10431(field_53721);
                createCompressor(GrowableOresItems.SILVER_DUST).input(GrowableOresItems.SMALL_SILVER_DUST, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.SMALL_SILVER_DUST)).method_10431(field_53721);

                createCompressor(GeneralBlocks.Lead_Block).input(GrowableOresItems.LEAD_INGOT, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.LEAD_INGOT)).method_10431(field_53721);
                createCompressor(GrowableOresItems.LEAD_PLATE).input(GrowableOresItems.LEAD_DUST, 1)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.LEAD_DUST)).method_10431(field_53721);
                createCompressor(GrowableOresItems.DENSE_LEAD_PLATE).input(GrowableOresItems.LEAD_PLATE, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.LEAD_PLATE)).method_10431(field_53721);
                createCompressor(GrowableOresItems.LEAD_DUST).input(GrowableOresItems.SMALL_LEAD_DUST, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.SMALL_LEAD_DUST)).method_10431(field_53721);

                createCompressor(GeneralBlocks.Bronze_Block).input(GrowableOresItems.BRONZE_INGOT, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.BRONZE_INGOT)).method_10431(field_53721);
                createCompressor(GrowableOresItems.BRONZE_PLATE).input(GrowableOresItems.BRONZE_DUST, 1)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.BRONZE_DUST)).method_10431(field_53721);
                createCompressor(GrowableOresItems.DENSE_BRONZE_PLATE).input(GrowableOresItems.BRONZE_PLATE, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.BRONZE_PLATE)).method_10431(field_53721);
                createCompressor(GrowableOresItems.BRONZE_DUST).input(GrowableOresItems.SMALL_BRONZE_DUST, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.SMALL_BRONZE_DUST)).method_10431(field_53721);

                createCompressor(GeneralBlocks.Steel_Block).input(GrowableOresItems.STEEL_INGOT, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.STEEL_INGOT)).method_10431(field_53721);
                createCompressor(GrowableOresItems.DENSE_STEEL_PLATE).input(GrowableOresItems.STEEL_PLATE, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.STEEL_PLATE)).method_10431(field_53721);

                createCompressor(class_1802.field_8793).input(class_1802.field_8725, 9)
                        .method_33530("has_base_item", method_10426(class_1802.field_8725)).method_10431(field_53721);

                createCompressor(class_1802.field_8055).input(class_1802.field_8759, 9)
                        .method_33530("has_base_item", method_10426(class_1802.field_8759)).method_10431(field_53721);
                createCompressor(GrowableOresItems.LAPIS_PLATE).input(GrowableOresItems.LAPIS_DUST, 1)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.LAPIS_DUST)).method_10431(field_53721);
                createCompressor(GrowableOresItems.DENSE_LAPIS_PLATE).input(GrowableOresItems.LAPIS_PLATE, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.LAPIS_PLATE)).method_10431(field_53721);
                createCompressor(GrowableOresItems.LAPIS_DUST).input(GrowableOresItems.SMALL_LAPIS_DUST, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.SMALL_LAPIS_DUST)).method_10431(field_53721);

                createCompressor(GrowableOresItems.ALLOY_PLATE).input(GrowableOresItems.ALLOY_INGOT, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.ALLOY_INGOT)).method_10431(field_53721);

                createCompressor(GrowableOresItems.ENERGY_CRYSTAL).input(GrowableOresItems.ENERGIUM_DUST, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.ENERGIUM_DUST)).method_10431(field_53721);
                createCompressor(GrowableOresItems.COAL_BLOCK).input(GrowableOresItems.COAL_BALL)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.COAL_BALL)).method_10431(field_53721);
                createCompressor(GrowableOresItems.CARBON_PLATE).input(GrowableOresItems.CARBON_MESH)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.CARBON_MESH)).method_10431(field_53721);


                createCompressor(class_1802.field_20398).input(class_1802.field_8729, 4)
                        .method_33530("has_base_item", method_10426(class_1802.field_8729)).method_10431(field_53721);
                createCompressor(GrowableOresItems.OBSIDIAN_DUST).input(GrowableOresItems.SMALL_OBSIDIAN_DUST, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.SMALL_OBSIDIAN_DUST)).method_10431(field_53721);
                createCompressor(GrowableOresItems.OBSIDIAN_PLATE).input(GrowableOresItems.OBSIDIAN_DUST)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.OBSIDIAN_DUST)).method_10431(field_53721);
                createCompressor(GrowableOresItems.DENSE_OBSIDIAN_PLATE).input(GrowableOresItems.OBSIDIAN_PLATE, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.OBSIDIAN_PLATE)).method_10431(field_53721);
                createCompressor(class_1802.field_20390).input(class_1802.field_8621, 4)
                        .method_33530("has_base_item", method_10426(class_1802.field_8729)).method_10431(field_53721);
                createCompressor(class_1802.field_20384).input(class_1802.field_8858, 4)
                        .method_33530("has_base_item", method_10426(class_1802.field_8858)).method_10431(field_53721);
                createCompressor(class_1802.field_8894).input(class_1802.field_8183, 5)
                        .method_33530("has_base_item", method_10426(class_1802.field_8183)).method_10431(field_53721);
                createCompressor(class_1802.field_8801).input(class_1802.field_8601, 4)
                        .method_33530("has_base_item", method_10426(class_1802.field_8601)).method_10431(field_53721);
                createCompressor(class_1802.field_8246).input(class_1802.field_8543, 4)
                        .method_33530("has_base_item", method_10426(class_1802.field_8543)).method_10431(field_53721);
                createCompressor(class_1802.field_8477).input(GrowableOresItems.COAL_CHUNK)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.COAL_CHUNK)).method_10431(field_53721);
                createCompressor(class_1802.field_8426).input(class_1802.field_8246)
                        .method_33530("has_base_item", method_10426(class_1802.field_8246)).method_10431(field_53721);
                createCompressor(class_1802.field_8081).input(class_1802.field_8426,2)
                        .method_33530("has_base_item", method_10426(class_1802.field_8426)).method_10431(field_53721);
                createCompressor(class_1802.field_19060).input(class_1802.field_8696,4)
                        .method_33530("has_base_item", method_10426(class_1802.field_8696)).method_10431(field_53721);

                createCompressor(GrowableOresItems.IRIDIUM_ORE).input(GrowableOresItems.IRIDIUM_SHARD, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.IRIDIUM_SHARD)).method_10431(field_53721);
                createCompressor(AdvancedItems.Iridium_INGOT).input(GrowableOresItems.IRIDIUM_ORE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.IRIDIUM_ORE)).method_10431(field_53721);

                createCompressor(GrowableOresItems.LITHIUM_DUST).input(GrowableOresItems.SMALL_LITHIUM_DUST, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.SMALL_LITHIUM_DUST)).method_10431(field_53721);

                createCompressor(GrowableOresItems.SULFUR_DUST).input(GrowableOresItems.SMALL_SULFUR_DUST, 9)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.SMALL_SULFUR_DUST)).method_10431(field_53721);

                createCompressor(GrowableOresItems.URANIUM_INGOT).input(GrowableOresItems.CRUSHED_URANIUM)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.CRUSHED_URANIUM)).method_10431(field_53721);
                createCompressor(GrowableOresItems.URANIUM_INGOT).input(GrowableOresItems.CRUSHED_URANIUM)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.CRUSHED_URANIUM)).method_36443(field_53721,"crushed_uranium_to_uranium_ingot");
            }
        };
    }

    @Override
    public String method_10321() {
        return "Compressor";
    }
}
