package com.skniro.growable_ores_extension.datagen.recipe.material;

import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.item.MapleArmorItems;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class MaterialRecipeGenerator extends FabricRecipeProvider {
    public MaterialRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {
                method_62746(class_7800.field_40642, GrowableOresItems.ENERGIUM_DUST)
                        .method_10434('R', class_1802.field_8725).method_10434('D', GrowableOresItems.DIAMOND_DUST)
                        .method_10439("RDR").method_10439("DRD").method_10439("RDR")
                        .method_10429("has_item", this.method_10426(class_1802.field_8725)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresItems.BRONZE_DUST)
                        .method_10449(GrowableOresItems.SMALL_BRONZE_DUST,9)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.SMALL_BRONZE_DUST)).method_36443(this.field_53721,"small_bronze_dust_to_bronze_dust");

                method_62749(class_7800.field_40642, GrowableOresItems.COPPER_DUST)
                        .method_10449(GrowableOresItems.SMALL_COPPER_DUST,9)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.SMALL_BRONZE_DUST)).method_10431(this.field_53721);

                method_62747(class_7800.field_40642, GrowableOresItems.BRONZE_DUST, 4)
                        .method_10433('R', ModItemTags.DUST_TIN).method_10433('D', ModItemTags.DUST_COPPER)
                        .method_10439("RD ").method_10439("DD ").method_10439("   ")
                        .method_10429("has_item_tags", this.method_10420(ModItemTags.DUST_COPPER)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresItems.GOLD_DUST)
                        .method_10449(GrowableOresItems.SMALL_GOLD_DUST,9)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.SMALL_GOLD_DUST)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresItems.IRON_DUST)
                        .method_10449(GrowableOresItems.SMALL_IRON_DUST,9)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.SMALL_IRON_DUST)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresItems.LAPIS_DUST)
                        .method_10449(GrowableOresItems.SMALL_LAPIS_DUST,9)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.SMALL_LAPIS_DUST)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresItems.LEAD_DUST)
                        .method_10449(GrowableOresItems.SMALL_LEAD_DUST,9)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.SMALL_LEAD_DUST)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresItems.LITHIUM_DUST)
                        .method_10449(GrowableOresItems.SMALL_LITHIUM_DUST,9)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.SMALL_LITHIUM_DUST)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresItems.OBSIDIAN_DUST)
                        .method_10449(GrowableOresItems.SMALL_OBSIDIAN_DUST,9)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.SMALL_OBSIDIAN_DUST)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresItems.SILVER_DUST)
                        .method_10449(GrowableOresItems.SMALL_SILVER_DUST,9)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.SMALL_SILVER_DUST)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresItems.SULFUR_DUST)
                        .method_10449(GrowableOresItems.SMALL_SULFUR_DUST,9)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.SMALL_SULFUR_DUST)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresItems.TIN_DUST)
                        .method_10449(GrowableOresItems.SMALL_TIN_DUST,9)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.SMALL_TIN_DUST)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.ALLOY_INGOT)
                        .method_10434('I', GrowableOresItems.IRON_PLATE).method_10434('B', GrowableOresItems.BRONZE_PLATE).method_10434('T', GrowableOresItems.TIN_PLATE)
                        .method_10439("III").method_10439("BBB").method_10439("TTT")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.BRONZE_PLATE)).method_10431(this.field_53721);

                method_62750(class_7800.field_40642, GrowableOresItems.BRONZE_INGOT, 9)
                        .method_10454(GeneralBlocks.Bronze_Block)
                        .method_10442("has_item", this.method_10426(GeneralBlocks.Bronze_Block)).method_10431(this.field_53721);

                method_62750(class_7800.field_40642, GrowableOresItems.LEAD_INGOT, 9)
                        .method_10454(GeneralBlocks.Lead_Block)
                        .method_10442("has_item", this.method_10426(GeneralBlocks.Lead_Block)).method_10431(this.field_53721);

                method_62750(class_7800.field_40642, GrowableOresItems.SILVER_INGOT, 9)
                        .method_10454(GeneralBlocks.Silver_Block)
                        .method_10442("has_item", this.method_10426(GeneralBlocks.Silver_Block)).method_10431(this.field_53721);

                method_62750(class_7800.field_40642, GrowableOresItems.STEEL_INGOT, 9)
                        .method_10454(GeneralBlocks.Steel_Block)
                        .method_10442("has_item", this.method_10426(GeneralBlocks.Steel_Block)).method_10431(this.field_53721);

                method_62750(class_7800.field_40642, GrowableOresItems.URANIUM_INGOT, 9)
                        .method_10454(GeneralBlocks.Uranium_Block)
                        .method_10442("has_item", this.method_10426(GeneralBlocks.Uranium_Block)).method_10431(this.field_53721);

                method_62750(class_7800.field_40642, GrowableOresItems.TIN_INGOT, 9)
                        .method_10454(GeneralBlocks.Tin_Block)
                        .method_10442("has_item", this.method_10426(GeneralBlocks.Tin_Block)).method_10431(this.field_53721);

                method_36233(List.of(GrowableOresItems.Sticky_Resin), class_7800.field_40640, GrowableOresItems.Rubber, 0.45F, 300, "sticky_resin");

                method_62746(class_7800.field_40642, GrowableOresItems.Circuit)
                        .method_10434('I', GrowableOresItems.IRON_PLATE).method_10434('B', GrowableOresBlocks.INSULATED_COPPER_CABLE).method_10434('T', class_1802.field_8725)
                        .method_10439("BBB").method_10439("TIT").method_10439("BBB")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.IRON_PLATE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.Advanced_Circuit)
                        .method_10434('I', GrowableOresItems.Circuit).method_10434('B', class_1802.field_8601).method_10434('T', class_1802.field_8725).method_10434('L', class_1802.field_8759)
                        .method_10439("TBT").method_10439("LIL").method_10439("TBT")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.Circuit)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.IRIDIUM_PLATE)
                        .method_10434('I', class_1802.field_8477).method_10434('B', GrowableOresItems.ALLOY_PLATE).method_10434('T', GrowableOresItems.IRIDIUM_ORE)
                        .method_10439("TBT").method_10439("BIB").method_10439("TBT")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.ALLOY_PLATE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.CARBON_FIBRE)
                        .method_10434('I', GrowableOresItems.COAL_DUST)
                        .method_10439("II ").method_10439("II ").method_10439("   ")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.COAL_DUST)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.CARBON_MESH)
                        .method_10434('I', GrowableOresItems.CARBON_FIBRE)
                        .method_10439("II ").method_10439("   ").method_10439("   ")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.CARBON_FIBRE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.COAL_BALL)
                        .method_10434('I', GrowableOresItems.COAL_DUST).method_10434('B', class_1802.field_8145)
                        .method_10439("III").method_10439("IBI").method_10439("III")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.COAL_DUST)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.COAL_CHUNK)
                        .method_10434('I', GrowableOresItems.COAL_BALL).method_10434('B', class_1802.field_8773)
                        .method_10439("III").method_10439("IBI").method_10439("III")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.COAL_BALL)).method_10431(this.field_53721);


                method_62746(class_7800.field_40642, GrowableOresItems.RE_BATTERY)
                        .method_10434('T', GrowableOresBlocks.INSULATED_TIN_CABLE).method_10434('I', GrowableOresItems.IRON_CASING).method_10434('B', class_1802.field_8725)
                        .method_10439(" T ").method_10439("IBI").method_10439("IBI")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.IRON_CASING)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.ADVANCED_RE_BATTERY)
                        .method_10434('T', GrowableOresBlocks.INSULATED_COPPER_CABLE).method_10434('I', GrowableOresItems.BRONZE_CASING).method_10434('B', GrowableOresItems.SULFUR_DUST).method_10434('C', GrowableOresItems.LEAD_DUST)
                        .method_10439("TIT").method_10439("IBI").method_10439("ICI")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.BRONZE_CASING)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.LAPOTRON_CRYSTAL)
                        .method_10434('T', GrowableOresItems.Advanced_Circuit).method_10434('I', GrowableOresItems.LAPIS_DUST).method_10434('B', GrowableOresItems.ENERGY_CRYSTAL)
                        .method_10439("ITI").method_10439("IBI").method_10439("ITI")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.ENERGY_CRYSTAL)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, MapleArmorItems.ROLLING)
                        .method_10434('T', class_1802.field_8620).method_10434('I', class_1802.field_8600)
                        .method_10439("TT ").method_10439("TII").method_10439("TT ")
                        .method_10429("has_item", this.method_10426(class_1802.field_8620)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, MapleArmorItems.ROLLING)
                        .method_10434('T', class_1802.field_8620).method_10434('I', class_1802.field_8600)
                        .method_10439(" TT").method_10439("IIT").method_10439(" TT")
                        .method_10429("has_item", this.method_10426(class_1802.field_8620)).method_36443(this.field_53721, "right_side_tool_rolling");

                method_62746(class_7800.field_40642, MapleArmorItems.CUTTING)
                        .method_10434('T', class_1802.field_8620).method_10434('I', GrowableOresItems.IRON_PLATE)
                        .method_10439("I I").method_10439(" I ").method_10439("T T")
                        .method_10429("has_item", this.method_10426(class_1802.field_8620)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.Coil)
                        .method_10434('T', class_1802.field_8620).method_10434('I', GrowableOresBlocks.COPPER_CABLE)
                        .method_10439("III").method_10439("ITI").method_10439("III")
                        .method_10429("has_item", this.method_10426(class_1802.field_8620)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GeneralBlocks.Machine)
                        .method_10434('I', GrowableOresItems.IRON_PLATE)
                        .method_10439("III").method_10439("I I").method_10439("III")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.IRON_PLATE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GeneralBlocks.Advanced_Machine)
                        .method_10434('I', GrowableOresItems.STEEL_PLATE).method_10434('M', GeneralBlocks.Machine).method_10434('C', GrowableOresItems.CARBON_PLATE).method_10434('A', GrowableOresItems.ALLOY_PLATE)
                        .method_10439("ICI").method_10439("AMA").method_10439("ICI")
                        .method_10429("has_item", this.method_10426(GrowableOresItems.IRON_PLATE)).method_10431(this.field_53721);

                method_62746(class_7800.field_40642, GrowableOresItems.Electric_Motor)
                        .method_10434('I', GrowableOresItems.Coil).method_10434('C', GrowableOresItems.IRON_CASING).method_10434('M', class_1802.field_8620)
                        .method_10439(" C ").method_10439("IMI").method_10439(" C ")
                        .method_10429("has_item", this.method_10426(class_1802.field_8620)).method_10431(this.field_53721);

                method_62749(class_7800.field_40642, GrowableOresItems.Scrap_box)
                        .method_10449(GrowableOresItems.Scrap,9)
                        .method_10442("has_item", this.method_10426(GrowableOresItems.Scrap)).method_10431(this.field_53721);
            }
        };
    }

    @Override
    public String method_10321() {
        return "Material";
    }
}