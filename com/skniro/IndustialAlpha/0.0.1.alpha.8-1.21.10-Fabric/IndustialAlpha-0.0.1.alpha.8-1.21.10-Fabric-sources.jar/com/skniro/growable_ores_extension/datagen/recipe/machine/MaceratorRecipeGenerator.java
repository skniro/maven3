package com.skniro.growable_ores_extension.datagen.recipe.machine;

import com.skniro.growable_ores_extension.api.data.recipe.ModRecipeGenerator;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.minecraft.class_1802;
import net.minecraft.class_1865;
import net.minecraft.class_1935;
import net.minecraft.class_3862;
import net.minecraft.class_3920;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class MaceratorRecipeGenerator extends FabricRecipeProvider {
    public MaceratorRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
    protected ModRecipeGenerator method_62766(class_7225.class_7874 wrapperLookup, class_8790 exporter) {
        return new ModRecipeGenerator(wrapperLookup, exporter) {
            @Override
            public void method_10419() {

                createMacerator(class_1802.field_8276, 2).input(class_1802.field_19044)
                        .method_33530("has_base_item", method_10426(class_1802.field_19044)).method_10431(field_53721);
                createMacerator(GrowableOresItems.COAL_DUST).input(class_1802.field_8713)
                        .method_33530("has_base_item", method_10426(class_1802.field_8713)).method_10431(field_53721);
                createMacerator(GrowableOresItems.COAL_DUST,9).input(class_1802.field_8797)
                        .method_33530("has_base_item", method_10426(class_1802.field_8797)).method_36443(field_53721,"coal_block_to_coal_dust");
                createMacerator(class_1802.field_8725,9).input(class_1802.field_8793)
                        .method_33530("has_base_item", method_10426(class_1802.field_8793)).method_10431(field_53721);

                createMacerator(class_1802.field_8145).input(class_1802.field_8110)
                        .method_33530("has_base_item", method_10426(class_1802.field_8110)).method_10431(field_53721);

                createMacerator(class_1802.field_8601, 9).input(class_1802.field_8801)
                        .method_33530("has_base_item", method_10426(class_1802.field_8801)).method_10431(field_53721);

                createMacerator(class_1802.field_8155, 4).input(class_1802.field_20402)
                        .method_33530("has_base_item", method_10426(class_1802.field_20402)).method_10431(field_53721);

                createMacerator(class_1802.field_8543, 1).input(class_1802.field_8426)
                        .method_33530("has_base_item", method_10426(class_1802.field_8426)).method_10431(field_53721);

                createMacerator(class_1802.field_8324, 4).input(class_1802.field_8606)
                        .method_33530("has_base_item", method_10426(class_1802.field_8606)).method_10431(field_53721);

                createMacerator(GrowableOresItems.CLAY_DUST, 2).input(class_1802.field_19060)
                        .method_33530("has_base_item", method_10426(class_1802.field_19060)).method_10431(field_53721);

                createMacerator(GrowableOresItems.IRON_DUST, 2).input(GrowableOresItems.STEEL_INGOT)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.STEEL_INGOT)).method_36443(field_53721,"steel_ingot_to_iron_dust");

                createMacerator(class_1802.field_8858, 2).input(class_1802.field_20384)
                        .method_33530("has_base_item", method_10426(class_1802.field_20384)).method_10431(field_53721);

                createMacerator(class_1802.field_8858, 2).input(class_1802.field_20412)
                        .method_33530("has_base_item", method_10426(class_1802.field_20391)).method_36443(field_53721,"stone_to_sand");

                createMacerator(class_1802.field_20412, 2).input(class_1802.field_20391)
                        .method_33530("has_base_item", method_10426(class_1802.field_20391)).method_10431(field_53721);

                createMacerator(class_1802.field_8183, 5).input(class_1802.field_8894)
                        .method_33530("has_base_item", method_10426(class_1802.field_8894)).method_10431(field_53721);

       /*         createMacerator(GrowableOresItems.ENERGIUM_DUST, 2).input(Items.ENDER_EYE)
                        .criterion("has_base_item", conditionsFromItem(Items.SANDSTONE)).offerTo(exporter,"steel_ingot_to_iron_dust");
*/
                createMacerator(GrowableOresItems.CRUSHED_IRON,2).input(class_1802.field_33400)
                        .method_33530("has_base_item", method_10426(class_1802.field_33400)).method_36443(field_53721,"raw_iron_to_crushed_iron");
                createMacerator(GrowableOresItems.CRUSHED_IRON,2).input(ConventionalItemTags.IRON_ORES)
                        .method_33530("has_base_item", method_10420(ConventionalItemTags.IRON_ORES)).method_10431(field_53721);
                createMacerator(GrowableOresItems.IRON_DUST,9).input(GrowableOresItems.DENSE_IRON_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.DENSE_IRON_PLATE)).method_36443(field_53721,"dense_iron_plate_to_iron_dust");
                createMacerator(GrowableOresItems.IRON_DUST).input(GrowableOresItems.IRON_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.IRON_PLATE)).method_36443(field_53721,"iron_plate_to_iron_dust");
                createMacerator(GrowableOresItems.IRON_DUST).input(GrowableOresItems.PURIFIED_IRON)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.PURIFIED_IRON)).method_36443(field_53721,"purified_iron_to_iron_dust");
                createMacerator(GrowableOresItems.IRON_DUST).input(GrowableOresItems.CRUSHED_IRON)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.CRUSHED_IRON)).method_36443(field_53721,"crushed_iron_to_iron_dust");
                createMacerator(GrowableOresItems.IRON_DUST).input(class_1802.field_8620)
                        .method_33530("has_base_item", method_10426(class_1802.field_8620)).method_36443(field_53721,"iron_ingot_to_iron_dust");

                createMacerator(GrowableOresItems.CRUSHED_GOLD,2).input(class_1802.field_33402)
                        .method_33530("has_base_item", method_10426(class_1802.field_33402)).method_36443(field_53721,"raw_gold_to_crushed_gold");
                createMacerator(GrowableOresItems.CRUSHED_GOLD,2).input(ConventionalItemTags.GOLD_ORES)
                        .method_33530("has_base_item", method_10420(ConventionalItemTags.GOLD_ORES)).method_10431(field_53721);
                createMacerator(GrowableOresItems.GOLD_DUST,9).input(GrowableOresItems.DENSE_GOLD_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.DENSE_GOLD_PLATE)).method_36443(field_53721,"dense_gold_plate_to_gold_dust");
                createMacerator(GrowableOresItems.GOLD_DUST).input(GrowableOresItems.GOLD_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.GOLD_PLATE)).method_36443(field_53721,"gold_plate_to_gold_dust");
                createMacerator(GrowableOresItems.GOLD_DUST).input(GrowableOresItems.PURIFIED_GOLD)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.PURIFIED_GOLD)).method_36443(field_53721,"purified_gold_to_gold_dust");
                createMacerator(GrowableOresItems.GOLD_DUST).input(GrowableOresItems.CRUSHED_GOLD)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.CRUSHED_GOLD)).method_36443(field_53721,"crushed_gold_to_gold_dust");
                createMacerator(GrowableOresItems.GOLD_DUST).input(class_1802.field_8695)
                        .method_33530("has_base_item", method_10426(class_1802.field_8695)).method_36443(field_53721,"gold_ingot_to_gold_dust");

                createMacerator(GrowableOresItems.BRONZE_DUST,9).input(GrowableOresItems.DENSE_BRONZE_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.DENSE_BRONZE_PLATE)).method_36443(field_53721,"dense_bronze_plate_to_bronze_dust");
                createMacerator(GrowableOresItems.BRONZE_DUST).input(GrowableOresItems.BRONZE_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.BRONZE_PLATE)).method_36443(field_53721,"bronze_plate_to_bronze_dust");
                createMacerator(GrowableOresItems.BRONZE_DUST).input(GrowableOresItems.BRONZE_INGOT)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.BRONZE_INGOT)).method_36443(field_53721,"bronze_ingot_to_bronze_dust");

                createMacerator(GrowableOresItems.DIAMOND_DUST).input(class_1802.field_8477)
                        .method_33530("has_base_item", method_10426(class_1802.field_8477)).method_36443(field_53721,"bronze_ingot_to_diamond_dust");

                createMacerator(GrowableOresItems.CRUSHED_COPPER,2).input(class_1802.field_33401)
                        .method_33530("has_base_item", method_10426(class_1802.field_33401)).method_36443(field_53721,"raw_copper_to_crushed_copper");
                createMacerator(GrowableOresItems.CRUSHED_COPPER,2).input(ConventionalItemTags.COPPER_ORES)
                        .method_33530("has_base_item", method_10420(ConventionalItemTags.COPPER_ORES)).method_10431(field_53721);
                createMacerator(GrowableOresItems.COPPER_DUST,9).input(GrowableOresItems.DENSE_COPPER_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.DENSE_COPPER_PLATE)).method_36443(field_53721,"dense_copper_plate_to_copper_dust");
                createMacerator(GrowableOresItems.COPPER_DUST).input(GrowableOresItems.COPPER_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.COPPER_PLATE)).method_36443(field_53721,"copper_plate_to_copper_dust");
                createMacerator(GrowableOresItems.COPPER_DUST).input(GrowableOresItems.PURIFIED_COPPER)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.PURIFIED_COPPER)).method_36443(field_53721,"purified_copper_to_copper_dust");
                createMacerator(GrowableOresItems.COPPER_DUST).input(GrowableOresItems.CRUSHED_COPPER)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.CRUSHED_COPPER)).method_36443(field_53721,"crushed_copper_to_copper_dust");
                createMacerator(GrowableOresItems.COPPER_DUST).input(class_1802.field_27022)
                        .method_33530("has_base_item", method_10426(class_1802.field_27022)).method_36443(field_53721,"copper_ingot_to_copper_dust");

                createMacerator(GrowableOresItems.CRUSHED_URANIUM,2).input(GrowableOresItems.Raw_Uranium)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.Raw_Uranium)).method_36443(field_53721,"raw_uranium_to_crushed_uranium");
                createMacerator(GrowableOresItems.CRUSHED_URANIUM,2).input(ModItemTags.URANIUM_ORES)
                        .method_33530("has_base_item", method_10420(ModItemTags.URANIUM_ORES)).method_10431(field_53721);

                createMacerator(GrowableOresItems.CRUSHED_LEAD,2).input(GrowableOresItems.Raw_Lead)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.Raw_Lead)).method_36443(field_53721,"raw_lead_to_crushed_lead");
                createMacerator(GrowableOresItems.CRUSHED_LEAD,2).input(ModItemTags.LEAD_ORES)
                        .method_33530("has_base_item", method_10420(ModItemTags.LEAD_ORES)).method_10431(field_53721);
                createMacerator(GrowableOresItems.LEAD_DUST,9).input(GrowableOresItems.DENSE_LEAD_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.DENSE_LEAD_PLATE)).method_36443(field_53721,"dense_lead_plate_to_lead_dust");
                createMacerator(GrowableOresItems.LEAD_DUST).input(GrowableOresItems.LEAD_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.LEAD_PLATE)).method_36443(field_53721,"lead_plate_to_lead_dust");
                createMacerator(GrowableOresItems.LEAD_DUST).input(GrowableOresItems.PURIFIED_LEAD)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.PURIFIED_LEAD)).method_36443(field_53721,"purified_lead_to_lead_dust");
                createMacerator(GrowableOresItems.LEAD_DUST).input(GrowableOresItems.CRUSHED_LEAD)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.CRUSHED_LEAD)).method_36443(field_53721,"crushed_lead_to_lead_dust");
                createMacerator(GrowableOresItems.LEAD_DUST).input(GrowableOresItems.LEAD_INGOT)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.LEAD_INGOT)).method_36443(field_53721,"lead_ingot_to_lead_dust");

                createMacerator(GrowableOresItems.CRUSHED_TIN,2).input(GrowableOresItems.Raw_Tin)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.Raw_Tin)).method_36443(field_53721,"raw_tin_to_crushed_tin");
                createMacerator(GrowableOresItems.CRUSHED_TIN,2).input(ModItemTags.TIN_ORES)
                        .method_33530("has_base_item", method_10420(ModItemTags.TIN_ORES)).method_10431(field_53721);
                createMacerator(GrowableOresItems.TIN_DUST,9).input(GrowableOresItems.DENSE_TIN_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.DENSE_TIN_PLATE)).method_36443(field_53721,"dense_tin_plate_to_tin_dust");
                createMacerator(GrowableOresItems.TIN_DUST).input(GrowableOresItems.TIN_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.TIN_PLATE)).method_36443(field_53721,"tin_plate_to_tin_dust");
                createMacerator(GrowableOresItems.TIN_DUST).input(GrowableOresItems.PURIFIED_TIN)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.PURIFIED_TIN)).method_36443(field_53721,"purified_tin_to_tin_dust");
                createMacerator(GrowableOresItems.TIN_DUST).input(GrowableOresItems.CRUSHED_TIN)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.CRUSHED_TIN)).method_36443(field_53721,"crushed_tin_to_tin_dust");
                createMacerator(GrowableOresItems.TIN_DUST).input(GrowableOresItems.TIN_INGOT)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.TIN_INGOT)).method_36443(field_53721,"tin_ingot_to_tin_dust");

                createMacerator(GrowableOresItems.LAPIS_DUST).input(class_1802.field_8759)
                        .method_33530("has_base_item", method_10426(class_1802.field_8759)).method_36443(field_53721,"lapis_to_lapis_dust");
                createMacerator(GrowableOresItems.LAPIS_DUST, 9).input(class_1802.field_8055)
                        .method_33530("has_base_item", method_10426(class_1802.field_8055)).method_36443(field_53721,"lapis_block_to_lapis_dust");

                createMacerator(GrowableOresItems.OBSIDIAN_DUST).input(class_1802.field_8281)
                        .method_33530("has_base_item", method_10426(class_1802.field_8281)).method_36443(field_53721,"obsidian_to_obsidian_dust");
                createMacerator(GrowableOresItems.OBSIDIAN_DUST).input(GrowableOresItems.OBSIDIAN_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.OBSIDIAN_PLATE)).method_36443(field_53721,"obsidian_plate_to_obsidian_dust");
                createMacerator(GrowableOresItems.OBSIDIAN_DUST,9).input(GrowableOresItems.DENSE_OBSIDIAN_PLATE)
                        .method_33530("has_base_item", method_10426(GrowableOresItems.OBSIDIAN_PLATE)).method_36443(field_53721,"dense_obsidian_plate_to_obsidian_dust");
            }



            public void offerCampfireCooking(List<class_1935> inputs, class_7800 category, class_1935 output, float experience, int cookingTime, String group) {
                this.method_36232(class_1865.field_17347, class_3920::new, inputs, category, output, experience, cookingTime, group, "_from_campfire_cooking");
            }

            public void offerSmoking(List<class_1935> inputs, class_7800 category, class_1935 output, float experience, int cookingTime, String group) {
                this.method_36232(class_1865.field_17085, class_3862::new, inputs, category, output, experience, cookingTime, group, "_from_smoking");
            }

        };
    }

    @Override
    public String method_10321() {
        return "Macerator";
    }
}
