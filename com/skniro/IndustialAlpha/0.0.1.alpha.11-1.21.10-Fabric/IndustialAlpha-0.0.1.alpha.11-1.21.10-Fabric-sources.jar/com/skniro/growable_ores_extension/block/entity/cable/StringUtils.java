package com.skniro.growable_ores_extension.block.entity.cable;

import java.util.Locale;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class StringUtils {
    public static String toFirstCapital(String input) {
        if (input != null && input.length() != 0) {
            String var10000 = input.substring(0, 1).toUpperCase();
            return var10000 + input.substring(1);
        } else {
            return input;
        }
    }

    public static String toFirstCapitalAllLowercase(String input) {
        if (input != null && input.length() != 0) {
            String output = input.toLowerCase(Locale.ROOT);
            String var10000 = output.substring(0, 1).toUpperCase();
            return var10000 + output.substring(1);
        } else {
            return input;
        }
    }

    public static class_124 getPercentageColour(int percentage) {
        if (percentage <= 10) {
            return class_124.field_1061;
        } else {
            return percentage >= 75 ? class_124.field_1060 : class_124.field_1054;
        }
    }

    public static class_5250 getPercentageText(int percentage) {
        return class_2561.method_43470(String.valueOf(percentage)).method_27692(getPercentageColour(percentage)).method_27693("%");
    }
}