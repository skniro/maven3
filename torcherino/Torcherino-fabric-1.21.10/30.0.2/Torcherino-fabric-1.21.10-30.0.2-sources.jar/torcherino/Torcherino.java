package torcherino;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_687;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import torcherino.api.TorcherinoAPI;
import torcherino.api.entrypoints.TorcherinoInitializer;
import torcherino.blocks.ModBlocks;
import torcherino.config.Config;
import torcherino.platform.NetworkUtilsImpl;
import torcherino.platform.Packets;

public final class Torcherino implements ModInitializer, TorcherinoInitializer {
    public static final String MOD_ID = "torcherino";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public static class_2960 resloc(String path) {
        return class_2960.method_60655(Torcherino.MOD_ID, path);
    }

    public static class_5321<class_2248> KeyofBlock(String path) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(Torcherino.MOD_ID, path));
    }

    public static class_5321<class_1792> KeyofItem(String path) {
        return class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Torcherino.MOD_ID, path));
    }

    @Override
    public void onInitialize() {
        Config.initialize();
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            TorcherinoAPI.INSTANCE.getTiers().forEach((id, tier) -> {
                if (!id.method_12836().equals(MOD_ID)) {
                    return;
                }
                String path = id.method_12832() + "_flame";
                if (path.equals("normal_flame")) {
                    path = "flame";
                }
                this.registerTorchParticle(path);
            });
        }
        ModBlocks.INSTANCE.initialize();
        FabricLoader.getInstance().getEntrypoints("torcherinoInitializer", TorcherinoInitializer.class).forEach(TorcherinoInitializer::onTorcherinoInitialize);
        NetworkUtilsImpl.getInstance().initialize();
    }

    @Environment(EnvType.CLIENT)
    private void registerTorchParticle(String tier) {
        ParticleFactoryRegistry.getInstance().register(class_2378.method_10230(class_7923.field_41180, Torcherino.resloc(tier), FabricParticleTypes.simple()),
                class_687.class_688::new);
    }

    @Override
    public void onTorcherinoInitialize() {
        TorcherinoAPI.INSTANCE.blacklistBlock(class_2246.field_10382);
        TorcherinoAPI.INSTANCE.blacklistBlock(class_2246.field_10164);
        TorcherinoAPI.INSTANCE.blacklistBlock(class_2246.field_10124);
        TorcherinoAPI.INSTANCE.blacklistBlock(class_2246.field_10543);
        TorcherinoAPI.INSTANCE.blacklistBlock(class_2246.field_10243);
        if (FabricLoader.getInstance().isModLoaded("computercraft")) {
            TorcherinoAPI.INSTANCE.blacklistBlockEntity(class_2960.method_60655("computercraft", "turtle_normal"));
            TorcherinoAPI.INSTANCE.blacklistBlockEntity(class_2960.method_60655("computercraft", "turtle_advanced"));
        }
        Packets.register();
    }
}
