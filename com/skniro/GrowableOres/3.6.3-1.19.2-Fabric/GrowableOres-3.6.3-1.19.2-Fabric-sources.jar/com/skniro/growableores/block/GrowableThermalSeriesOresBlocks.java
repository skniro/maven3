package com.skniro.growableores.block;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.init.GrowableOreCaneBlock;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3614;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import java.util.logging.Logger;

public class GrowableThermalSeriesOresBlocks {
    //Thermal Series
    public static final class_2248 TF_Apatite_Cane =registerBlock("tf_apatite_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 TF_Cinnabar_Cane =registerBlock("tf_cinnabar_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 TF_Copper_Cane =registerBlock("tf_copper_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 TF_Lead_Cane =registerBlock("tf_lead_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 TF_Nickel_Cane =registerBlock("tf_nickel_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 TF_Niter_Cane =registerBlock("tf_niter_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 TF_Ruby_Cane =registerBlock("tf_ruby_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 TF_Sapphire_Cane =registerBlock("tf_sapphire_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 TF_Silver_Cane =registerBlock("tf_silver_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 TF_Sulfur_Cane =registerBlock("tf_sulfur_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);
    public static final class_2248 TF_Tin_Cane =registerBlock("tf_tin_ore_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637(class_3614.field_15935).method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11535)),GrowableOres.Growable_Ores_Group);



    private static class_2248 registerBlock(String name, class_2248 block, class_1761 tab) {
        registerBlockItem(name, block, tab);
        return class_2378.method_10230(class_2378.field_11146, new class_2960(GrowableOres.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_1761 tab) {
        return class_2378.method_10230(class_2378.field_11142, new class_2960(GrowableOres.MOD_ID, name),
                new class_1747(block, new FabricItemSettings().method_7892(tab)));
    }
    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + GrowableOres.MOD_ID);
    }
}

