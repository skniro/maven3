package com.skniro.usefulfood;


import com.skniro.usefulfood.block.UsefulFoodJamBlocks;
import com.skniro.usefulfood.block.UsefulFoodCakeBlocks;
import com.skniro.usefulfood.item.UsefulFoodItems;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;


public class ModContent {


    public static void registerItem(){
        UsefulFoodItems.registerUsefulFoodItem();
    }
    public static void registerBlock(){
        UsefulFoodCakeBlocks.registerModBlocks();
        UsefulFoodJamBlocks.registerModBlocks();

    }

    public static void CreativeTab() {
        ItemGroupEvents.modifyEntriesEvent(UsefulFood.UsefulFood_Group).register(content -> {
            content.method_45421(UsefulFoodItems.MilkBottle);
            content.method_45421(UsefulFoodItems.ChocolateMilkBottle);
            content.method_45421(UsefulFoodItems.Cheese);
            content.method_45421(UsefulFoodItems.ChocolateCandy);
            content.method_45421(UsefulFoodItems.FruitSalad);
            content.method_45421(UsefulFoodItems.MagicFruitSalad );
            content.method_45421(UsefulFoodItems.SugarCube);
            content.method_45421(UsefulFoodItems.caramel);
            content.method_45421(UsefulFoodItems.caramelapple );
            content.method_45421(UsefulFoodItems.RoastedSeeds);
            content.method_45421(UsefulFoodItems.FriedEgg);
            content.method_45421(UsefulFoodItems.PumpkinSoup);
            content.method_45421(UsefulFoodItems.Salad);
            content.method_45421(UsefulFoodItems.Oatmeal);
            content.method_45421(UsefulFoodItems.Jelly);
            content.method_45421(UsefulFoodItems.Marshmallow);
            content.method_45421(UsefulFoodItems.CookMarshmallow);
            content.method_45421(UsefulFoodItems.VanillaIceCream);
            content.method_45421(UsefulFoodItems.BreadSlice);
            content.method_45421(UsefulFoodItems.PorkWich);
            content.method_45421(UsefulFoodItems.Steakwich);
            content.method_45421(UsefulFoodItems.Fishwich);
            content.method_45421(UsefulFoodItems.Chickenwich);
            content.method_45421(UsefulFoodItems.Eggwich);
            content.method_45421(UsefulFoodItems.Biscuit);
            content.method_45421(UsefulFoodItems.Trailmix);
            content.method_45421(UsefulFoodItems.MuttonSandwich);
            content.method_45421(UsefulFoodItems.SquidTentacleRaw);
            content.method_45421(UsefulFoodItems.SquidTentacleCooked);
            content.method_45421(UsefulFoodItems.SquidSandwich);
            content.method_45421(UsefulFoodItems.MagicAppleJuice);
            content.method_45421(UsefulFoodItems.MelonJuice);
            content.method_45421(UsefulFoodItems.AppleJuice);
            content.method_45421(UsefulFoodItems.CarrotJuice);
            content.method_45421(UsefulFoodItems.CarrotSoup);
            content.method_45421(UsefulFoodItems.PumpkinBread);
            content.method_45421(UsefulFoodItems.FishnChips);
            content.method_45421(UsefulFoodItems.SugarBiscuit);
            content.method_45421(UsefulFoodItems.AppleJamBiscuit);
            content.method_45421(UsefulFoodItems.ChocoBiscuit);
            content.method_45421(UsefulFoodItems.CarrotPie);
            content.method_45421(UsefulFoodItems.hotchocolatebottle );
            content.method_45421(UsefulFoodItems.chocolateicecream);
            content.method_45421(UsefulFoodItems.MagicIceCream);
            content.method_45421(UsefulFoodItems.SquidSushi);
            content.method_45421(UsefulFoodItems.Baked_Sushi);
            content.method_45421(UsefulFoodItems.Salmon_Sushi);
            content.method_45421(UsefulFoodItems.Cod_Roe_Sushi);
            content.method_45421(UsefulFoodItems.CactusJuice);
            content.method_45421(UsefulFoodItems.Spaghetti);
            content.method_45421(UsefulFoodItems.AppleIceCream);
            content.method_45421(UsefulFoodItems.MelonIceCream);
            content.method_45421(UsefulFoodItems.ChocolateApple );
            content.method_45421(UsefulFoodItems.CaramelBiscuit);
            content.method_45421(UsefulFoodItems.FishSoup);
            content.method_45421(UsefulFoodItems.Tea);
            content.method_45421(UsefulFoodItems.HotMilkBottle);
            content.method_45421(UsefulFoodItems.CheeseSandwich);
            content.method_45421(UsefulFoodItems.CaramelIceCream);
            content.method_45421(UsefulFoodItems.Cereal);
            content.method_45421(UsefulFoodItems.ChocolateCereal);
            content.method_45421(UsefulFoodItems.FrenchFries);
            content.method_45421(UsefulFoodItems.AppleJelly);
            content.method_45421(UsefulFoodItems.MelonJelly);
            content.method_45421(UsefulFoodItems.Donut);
            content.method_45421(UsefulFoodItems.Oreo);
            content.method_45421(UsefulFoodItems.CaramelToast);
            content.method_45421(UsefulFoodItems.ChocolateToast);
            content.method_45421(UsefulFoodItems.SugarToast);
            content.method_45421(UsefulFoodItems.SugarPancake);
            content.method_45421(UsefulFoodItems.AppleJamPanCake);
            content.method_45421(UsefulFoodItems.AppleJamToast);
            content.method_45421(UsefulFoodItems.AppleJam);
            content.method_45421(UsefulFoodItems.CaramelPanCake);
            content.method_45421(UsefulFoodItems.ChocolatePanCake);
            content.method_45421(UsefulFoodItems.MelonJamPanCake);
            content.method_45421(UsefulFoodItems.MelonJamToast);
            content.method_45421(UsefulFoodItems.MelonJamBiscuit);
            content.method_45421(UsefulFoodItems.MelonJam);
            content.method_45421(UsefulFoodItems.PanCakeDough);
            content.method_45421(UsefulFoodItems.PanCake);
            content.method_45421(UsefulFoodCakeBlocks.AppleCake);
            content.method_45421(UsefulFoodCakeBlocks.CaramelCake);
            content.method_45421(UsefulFoodCakeBlocks.ChocolateCake);
            content.method_45421(UsefulFoodCakeBlocks.MagicCake);

            content.method_45421(UsefulFoodItems.Chorus_Juice);
            content.method_45421(UsefulFoodItems.Glow_Berries_Juice);
            content.method_45421(UsefulFoodItems.Sweet_Berries_Juice);
            content.method_45421(UsefulFoodItems.Chorus_Jelly);
            content.method_45421(UsefulFoodItems.Glow_Berries_Jelly);
            content.method_45421(UsefulFoodItems.Sweet_Berries_Jelly);
            content.method_45421(UsefulFoodItems.Chorus_Ice_Cream);
            content.method_45421(UsefulFoodItems.Glow_Berries_Ice_Cream);
            content.method_45421(UsefulFoodItems.Sweet_Berries_Ice_Cream);
            content.method_45421(UsefulFoodItems.Glow_Berries_JamPanCake);
            content.method_45421(UsefulFoodItems.Glow_Berries_JamToast);
            content.method_45421(UsefulFoodItems.Glow_Berries_JamBiscuit);
            content.method_45421(UsefulFoodItems.Glow_Berries_Jam);
            content.method_45421(UsefulFoodItems.Sweet_Berries_JamPanCake);
            content.method_45421(UsefulFoodItems.Sweet_Berries_JamToast);
            content.method_45421(UsefulFoodItems.Sweet_Berries_JamBiscuit);
            content.method_45421(UsefulFoodItems.Sweet_Berries_Jam);
            content.method_45421(UsefulFoodItems.Chorus_JamPanCake);
            content.method_45421(UsefulFoodItems.Chorus_JamToast);
            content.method_45421(UsefulFoodItems.Chorus_JamBiscuit);
            content.method_45421(UsefulFoodItems.Chorus_Jam);

            content.method_45421(UsefulFoodItems.Waffle);
            content.method_45421(UsefulFoodItems.Waffle_Vanilla_IceCream);
            content.method_45421(UsefulFoodItems.Waffle_Chorus_Ice_Cream);
            content.method_45421(UsefulFoodItems.Waffle_Glow_Berries_Ice_Cream);
            content.method_45421(UsefulFoodItems.Waffle_Sweet_Berries_Ice_Cream);
            content.method_45421(UsefulFoodItems.Waffle_chocolate_icecream);
            content.method_45421(UsefulFoodItems.Waffle_Magic_IceCream);
            content.method_45421(UsefulFoodItems.Waffle_Apple_IceCream);
            content.method_45421(UsefulFoodItems.Waffle_Melon_IceCream);
            content.method_45421(UsefulFoodItems.Waffle_Caramel_IceCream);

            content.method_45421(UsefulFoodJamBlocks.GLASS_JAR);
            content.method_45421(UsefulFoodJamBlocks.Apple_JAM_JAR);
            content.method_45421(UsefulFoodJamBlocks.Melon_JAM_JAR);
            content.method_45421(UsefulFoodJamBlocks.Chorus_JAM_JAR);
            content.method_45421(UsefulFoodJamBlocks.Sweet_Berries_JAM_JAR);
            content.method_45421(UsefulFoodJamBlocks.Glow_Berries_JAM_JAR);

        });
    }
}
