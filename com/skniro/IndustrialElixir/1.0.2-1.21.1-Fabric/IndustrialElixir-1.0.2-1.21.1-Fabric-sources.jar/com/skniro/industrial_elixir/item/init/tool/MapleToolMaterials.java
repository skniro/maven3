package com.skniro.industrial_elixir.item.init.tool;


import com.skniro.industrial_elixir.registry.tag.ModItemTags;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_6862;

/**
 * 26.1's {@code ToolMaterial} record has no 1.21.1 counterpart; 1.21.1 uses the {@link class_1832}
 * interface instead, so the same values are supplied through an anonymous implementation.
 */
public class MapleToolMaterials {
    public static final class_1832 BRONZE = new class_1832() {
        @Override
        public int method_8025() {
            return 340;
        }

        @Override
        public float method_8027() {
            return 6.0F;
        }

        @Override
        public float method_8028() {
            return 2.0F;
        }

        @Override
        public class_6862<class_2248> method_58419() {
            return class_3481.field_49927;
        }

        @Override
        public int method_8026() {
            return 14;
        }

        @Override
        public class_1856 method_8023() {
            return class_1856.method_8106(ModItemTags.BRONZE_TOOL_MATERIALS);
        }
    };
}
