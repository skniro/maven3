package com.skniro.growable_ores_extension.block.entity.energybox;

import com.skniro.growable_ores_extension.api.ImplementedInventory;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.api.item.TieredEnergyItem;
import com.skniro.growable_ores_extension.block.entity.generator.CoalGeneratorBlockEntity;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.EnergyStorageUtil;
import com.skniro.growable_ores_extension.energy.api.base.SimpleSidedEnergyContainer;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2383;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3913;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;


public abstract class BaseEnergyBoxBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory {

    private long capacity;
    protected final EnergyTier energyTier;
    public SimpleSidedEnergyContainer energyContainer;
    protected final class_3913 propertyDelegate;

    public BaseEnergyBoxBlockEntity(class_2591<?> blockEntityType, class_2338 pos, class_2680 state, long capacity, EnergyTier energyTier) {
        super(blockEntityType, pos, state);
        this.capacity = capacity;
        this.energyTier = energyTier;
        energyContainer = new SimpleSidedEnergyContainer() {

            @Override
            public long getCapacity() {
                return capacity;
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                if (side == null) return energyTier.getMaxInput();
                class_2350 front = method_11010().method_11654(class_2383.field_11177);
                if (side == front) return energyTier.getMaxInput();
                return 0;
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                if (side == null) return energyTier.getMaxOutput();
                class_2350 front = method_11010().method_11654(class_2383.field_11177);
                if (side == front) {
                    return 0;
                }
                return energyTier.getMaxOutput();
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(pos, method_11010(), method_11010(), 3);
            }
        };

        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return 0;
            }

            @Override
            public void method_17391(int index, int value) {
            }

            @Override
            public int method_17389() {
                return 0;
            }
        };
    }

    public EnergyStorage getSideEnergyStorage(@Nullable class_2350 side) {
        return this.energyContainer.getSideStorage(side);
    }

    public void pushEnergyToNeighbours() {
        if (energyContainer.amount <= 0) return;
        for (class_2350 direction : class_2350.values()) {
            EnergyStorage target = EnergyStorage.SIDED.find(field_11863, field_11867.method_10093(direction), direction.method_10153());
            if (target == null) continue;
            EnergyStorageUtil.move(this.energyContainer.getSideStorage(direction), target, energyTier.getMaxOutput(), null);
        }
    }

    public void discharge(int slot) {
        if (this.field_11863 != null) {
            if (!this.field_11863.method_8608()) {
                if (!this.getOptionalInventory().isEmpty()) {
                    class_1263 inventory = this.getOptionalInventory().get();
                    EnergyStorageUtil.move(this.getSideEnergyStorage(null), ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(slot)).find(EnergyStorage.ITEM), Long.MAX_VALUE, null);
                }
            }
        }
    }

    public void charge(int slot) {
        if (this.field_11863 != null) {
            if (!this.field_11863.method_8608()) {
                long chargeEnergy = Math.min(this.getFreeSpace(), energyTier.getMaxInput());
                if (chargeEnergy > 0L) {
                    if (!this.getOptionalInventory().isEmpty()) {
                        class_1263 inventory = this.getOptionalInventory().get();
                        EnergyStorageUtil.move(ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(slot)).find(EnergyStorage.ITEM), this.getSideEnergyStorage(null), Long.MAX_VALUE, null);
                    }
                }
            }
        }
    }

    public void chargePlayersAbove() {

        if (energyContainer.amount <= 0) return;

        class_238 box = new class_238(field_11867.method_10263(), field_11867.method_10264() + 1, field_11867.method_10260(), field_11867.method_10263() + 1, field_11867.method_10264() + 2, field_11867.method_10260() + 1);
        List<class_1657> players = field_11863.method_8390(class_1657.class, box, p -> true);

        for (class_1657 player : players) {
            for (class_1799 stack : player.method_31548().method_67533()) {
                chargeItem(stack);
            }
        }
    }

    private void chargeItem(class_1799 stack) {
        if (stack.method_7960()) return;
        EnergyStorage storage = ContainerItemContext.withConstant(stack).find(EnergyStorage.ITEM);
        if (storage == null) return;
        if (storage instanceof TieredEnergyItem tiered) {
            if (tiered.getEnergyTier().ordinal() < this.energyTier.ordinal()) return;
            EnergyStorageUtil.move(this.energyContainer.getSideStorage(null), storage, energyTier.getMaxOutput(), null);
        }
    }

    public long getFreeSpace() {
        return this.energyContainer.getCapacity() - energyContainer.amount;
    }

    public Optional<ImplementedInventory> getOptionalInventory() {
        if (this instanceof ImplementedInventory inventory) {
            return inventory == null ? Optional.empty() : Optional.of(inventory);
        } else {
            return Optional.empty();
        }
    }

    public boolean canInsert(class_1799 stack) {
        return stack.method_31573(ModItemTags.BATTERY);
    }

    public EnergyTier getEnergyTier(){
        return energyTier;
    }
}