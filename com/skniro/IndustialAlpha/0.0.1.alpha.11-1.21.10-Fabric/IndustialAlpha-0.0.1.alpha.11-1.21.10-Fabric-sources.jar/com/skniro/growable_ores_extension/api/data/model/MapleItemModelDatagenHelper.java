package com.skniro.growable_ores_extension.api.data.model;

import net.minecraft.class_10410;
import net.minecraft.class_10439;
import net.minecraft.class_10479;
import net.minecraft.class_1792;
import net.minecraft.class_4915;
import net.minecraft.class_4943;
import net.minecraft.client.data.*;

public class MapleItemModelDatagenHelper {
    private final class_4915 generator;;

    public MapleItemModelDatagenHelper(class_4915 generator) {
        this.generator = generator;
    }

    public final void registerDurabilityItem(class_1792 item) {
        class_10439.class_10441 low0   = class_10410.method_65481(generator.method_65438(item, "_0", class_4943.field_22938));
        class_10439.class_10441 low25  = class_10410.method_65481(generator.method_65438(item, "_1", class_4943.field_22938));
        class_10439.class_10441 low50  = class_10410.method_65481(generator.method_65438(item, "_2", class_4943.field_22938));
        class_10439.class_10441 low75  = class_10410.method_65481(generator.method_65438(item, "_3", class_4943.field_22938));
        class_10439.class_10441 low100 = class_10410.method_65481(generator.method_65438(item, "_4", class_4943.field_22938));
        class_10439.class_10441 dispatched = class_10410.method_65487(class_10410.method_65479(), class_10410.method_65488(new class_10479(false), 0.0F, low0, class_10410.method_65486(low25, 0.25F), class_10410.method_65486(low50, 0.50F), class_10410.method_65486(low75, 0.75F), class_10410.method_65486(low100, 1.0F)), low0);
        generator.field_55245.method_65460(item, dispatched);
    }

}