package com.skniro.maple.world.gen;

import com.skniro.maple.world.feature.MaplePlacedFeatures;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_2893;

public class MapleOreGeneration {
    public static void generateOres() {
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, MaplePlacedFeatures.SALT_ORE_PLACED);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, MaplePlacedFeatures.Coal_ORE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, MaplePlacedFeatures.Nether_Copper_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, MaplePlacedFeatures.Nether_Diamond_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, MaplePlacedFeatures.Nether_Emerald_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, MaplePlacedFeatures.Nether_Gold_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, MaplePlacedFeatures.Nether_Iron_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, MaplePlacedFeatures.Nether_Lapis_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176, MaplePlacedFeatures.Nether_Redstone_PLACED_KEY);

    }
}