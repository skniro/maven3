package com.skniro.nether_ores_reborn.datagen;

import com.skniro.nether_ores_reborn.block.NetherOresBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;


public class NetherOresLootTableGenerator extends FabricBlockLootTableProvider {
    public NetherOresLootTableGenerator(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataGenerator, registryLookup);
    }

    @Override
    public void method_10379() {
        method_45988(NetherOresBlocks.Nether_Coal_Ore, method_45981(NetherOresBlocks.Nether_Coal_Ore,class_1802.field_8713));
        method_45988(NetherOresBlocks.Nether_Copper_Ore, method_46010(NetherOresBlocks.Nether_Copper_Ore));
        method_45988(NetherOresBlocks.Nether_Diamond_Ore, method_45981(NetherOresBlocks.Nether_Diamond_Ore,class_1802.field_8477));
        method_45988(NetherOresBlocks.Nether_Emerald_Ore, method_45981(NetherOresBlocks.Nether_Emerald_Ore,class_1802.field_8687));
        method_45988(NetherOresBlocks.Nether_Gold_Ore, method_45981(NetherOresBlocks.Nether_Gold_Ore,class_1802.field_33402));
        method_45988(NetherOresBlocks.Nether_Iron_Ore, method_45981(NetherOresBlocks.Nether_Iron_Ore,class_1802.field_33400));
        method_45988(NetherOresBlocks.Nether_Lapis_Ore, method_46011(NetherOresBlocks.Nether_Lapis_Ore));
        method_45988(NetherOresBlocks.Nether_Redstone_Ore,method_46012(NetherOresBlocks.Nether_Redstone_Ore));
        method_45988(NetherOresBlocks.Nether_Coal_Ore, method_45981(NetherOresBlocks.Nether_Coal_Ore,class_1802.field_8713));

        method_45988(NetherOresBlocks.End_Coal_Ore, method_45981(NetherOresBlocks.End_Coal_Ore, class_1802.field_8713));
        method_45988(NetherOresBlocks.End_Copper_Ore, method_46010(NetherOresBlocks.End_Copper_Ore));
        method_45988(NetherOresBlocks.End_Diamond_Ore, method_45981(NetherOresBlocks.End_Diamond_Ore, class_1802.field_8477));
        method_45988(NetherOresBlocks.End_Emerald_Ore, method_45981(NetherOresBlocks.End_Emerald_Ore, class_1802.field_8687));
        method_45988(NetherOresBlocks.End_Gold_Ore, method_45981(NetherOresBlocks.End_Gold_Ore, class_1802.field_33402));
        method_45988(NetherOresBlocks.End_Iron_Ore, method_45981(NetherOresBlocks.End_Iron_Ore, class_1802.field_33400));
        method_45988(NetherOresBlocks.End_Lapis_Ore, method_46011(NetherOresBlocks.End_Lapis_Ore));
        method_45988(NetherOresBlocks.End_Redstone_Ore, method_46012(NetherOresBlocks.End_Redstone_Ore));
        method_45988(NetherOresBlocks.End_Coal_Ore, method_45981(NetherOresBlocks.End_Coal_Ore, class_1802.field_8713));

    }


}
