package com.skniro.industrial_elixir.fluid;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.fluid.init.MapleHotSpringFluidBlock;
import java.util.function.Function;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class IndustrialElixirFluidBlocks {

    public static final class_2248 Hot_Spring_BLOCK = registerBlockWithoutItem( "hot_spring_block",
                                                         (settings)-> new MapleHotSpringFluidBlock(IndustrialElixirFluids.STILL_Hot_Spring, settings), class_4970.class_2251.method_9630(class_2246.field_10382).method_9631((state)->{return 7;}));

    public static final class_2248 Fluid_UU_BLOCK = registerBlockWithoutItem( "fluid_uu_block",
            (settings)-> new MapleHotSpringFluidBlock(IndustrialElixirFluids.STILL_Fluid_UU, settings), class_4970.class_2251.method_9630(class_2246.field_10382));

    private static class_2248 registerBlockWithoutItem(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings);
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }

    private static class_5321<class_2248> keyOf(String name) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(IndustrialElixir.MOD_ID, name));
    }

    public static void registerFluidBlocks() {
        IndustrialElixir.LOGGER.info("Registering Industrial Elixir Fluid Blocks for " + IndustrialElixir.MOD_ID);
    }
}
