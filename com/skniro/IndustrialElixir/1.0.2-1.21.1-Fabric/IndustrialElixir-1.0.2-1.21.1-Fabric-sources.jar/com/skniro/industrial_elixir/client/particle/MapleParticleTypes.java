package com.skniro.industrial_elixir.client.particle;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.Helper;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_7923;


public class MapleParticleTypes {
    public static final class_2400 HOT_SPRING = FabricParticleTypes.simple();

    static {
        class_2378.method_10230(class_7923.field_41180, Helper.id("hot_spring"), HOT_SPRING);
    }

    public static void registerParticleTypes() {
        IndustrialElixir.LOGGER.info("register Industrial Elixir Particle Types for"+ IndustrialElixir.MOD_ID );
    }
}
