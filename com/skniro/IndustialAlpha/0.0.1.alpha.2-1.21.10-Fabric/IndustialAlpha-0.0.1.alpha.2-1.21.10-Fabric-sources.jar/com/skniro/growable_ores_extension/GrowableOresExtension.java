package com.skniro.growable_ores_extension;

import com.skniro.growable_ores_extension.block.networking.ModMessages;

import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.base.SimpleEnergyItem;
import com.skniro.growable_ores_extension.energy.impl.EnergyImpl;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.item.init.BatteryItem;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import static com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType.ALCHEMY_BLOCK_ENTITY;
import static com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType.COAL_GENERATOR_BE;


public class GrowableOresExtension implements ModInitializer {
    public static final String MOD_ID = "growable_ores_extension";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModContent.registerItem();
        ModContent.registerBlock();
        ModContent.registerEntity();
        ModContent.CreativeTab();
        ModContent.WorldGen();

        EnergyImpl.init();
        //ModMessages.register();
    }
}
