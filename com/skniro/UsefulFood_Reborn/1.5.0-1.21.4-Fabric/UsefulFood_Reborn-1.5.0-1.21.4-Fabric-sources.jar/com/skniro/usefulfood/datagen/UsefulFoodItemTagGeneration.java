package com.skniro.usefulfood.datagen;

import com.skniro.usefulfood.item.UsefulFoodItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;


public class UsefulFoodItemTagGeneration extends FabricTagProvider.ItemTagProvider {
    public UsefulFoodItemTagGeneration(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(dataGenerator, completableFuture);
    }

    public static class ModItemTags {
        public static final class_6862<class_1792> C_Lily_Pads = class_6862.method_40092(class_7924.field_41197, class_2960.method_60654("c/lily_pads/lily_pads"));
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        method_10512(ConventionalItemTags.MILK_DRINKS)
                .add(UsefulFoodItems.MilkBottle)
                .setReplace(false);
        method_10512(ConventionalItemTags.MILK_BUCKETS)
                .add(UsefulFoodItems.MilkBottle)
                .setReplace(false);;
        method_10512(ModItemTags.C_Lily_Pads)
                .add(class_1802.field_17524)
                .setReplace(false);;

    }


}
