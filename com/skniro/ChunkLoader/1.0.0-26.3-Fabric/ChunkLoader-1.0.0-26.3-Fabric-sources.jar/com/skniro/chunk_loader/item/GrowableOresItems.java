package com.skniro.chunk_loader.item;

import com.skniro.chunk_loader.SkniroChunkLoader;

import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;

public class GrowableOresItems {

    private static Item registerItem(String name, Function<Item.Properties, Item> factory, Item.Properties settings) {
        Item item = factory.apply(settings.setId(ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(SkniroChunkLoader.MOD_ID, name))));
        return Registry.register(BuiltInRegistries.ITEM, ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(SkniroChunkLoader.MOD_ID, name)), item);
    }

    public static void shield_item(){
      SkniroChunkLoader.LOGGER.debug("register shield item.");
    }
}
