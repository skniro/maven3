package com.skniro.industrial_elixir.block.entity.machine;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.screen.handler.machine.MaceratorScreenHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public class MaceratorEntity extends AbstractMachineEntity {

    public MaceratorEntity(BlockPos pos, BlockState state) {
        super(AlchemyBlockEntityType.Macerator_BLOCK_ENTITY ,pos, state);
        this.DEFAULT_MAX_PROGRESS = 400;
        this.maxProgress = 400;
    }

    // 40/20 = 2 EU/t
    @Override
    public long getCraftEnergyCost() {
        return 40;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable(FurnitureStrings.Macerator);
    }

    public RecipeType<?> getCurrentRecipeType() {
        return AlchemyRecipeType.MACERATOR.type;
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int syncId, Inventory playerInventory, Player player) {
        return new MaceratorScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }
}
