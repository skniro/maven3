package com.skniro.industrial_elixir.util;

import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.item.MapleArmorItems;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.class_141;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;

public class ModLootTableModifiers {
    private static final class_2960 IGLOO_STRUCTURE_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/igloo_chest");
    private static final class_2960 Mineshaft_STRUCTURE_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/abandoned_mineshaft");
    private static final class_2960 Ancient_City_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/ancient_city");
    private static final class_2960 Bastion_Bridge_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/bastion_bridge");
    private static final class_2960 Bastion_Hoglin_Stable_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/bastion_hoglin_stable");
    private static final class_2960 Bastion_Other_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/bastion_other");
    private static final class_2960 Bastion_Treasure_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/bastion_treasure");
    private static final class_2960 Buried_Treasure_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/buried_treasure");
    private static final class_2960 End_City_Treasure_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/end_city_treasure");
    private static final class_2960 Desert_Pyramid_ID
            = class_2960.method_60655("minecraft", "chests/desert_pyramid");
    private static final class_2960 Jungle_Temple_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/jungle_temple");
    private static final class_2960 Jungle_Temple_Dispenser_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/jungle_temple_dispenser");
    private static final class_2960 Underwater_Ruin_Small_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/underwater_ruin_small");
    private static final class_2960 Underwater_Ruin_Big_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/underwater_ruin_big");
    private static final class_2960 Stronghold_Corridor_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/stronghold_corridor");
    private static final class_2960 Stronghold_Crossing_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/stronghold_crossing");
    private static final class_2960 Pillager_Outpost_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/pillager_outpost");
    private static final class_2960 Ruined_Portal_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/ruined_portal");
    private static final class_2960 Woodland_Mansion_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/woodland_mansion");
    private static final class_2960 Simple_Dungeon_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/simple_dungeon");
    private static final class_2960 Nether_Bridge_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/nether_bridge");
    private static final class_2960 Shipwreck_Map_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/shipwreck_map");
    private static final class_2960 Shipwreck_Supply_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/shipwreck_supply");
    private static final class_2960 Shipwreck_Treasure_CHEST_ID
            = class_2960.method_60655("minecraft", "chests/shipwreck_treasure");

    private static class_55.class_56 bronzeArmorPool(float chance, float minCount, float maxCount) {
        return class_55.method_347()
                .method_352(class_44.method_32448(1))
                .method_356(class_219.method_932(chance))
                .method_351(class_77.method_411(MapleArmorItems.BRONZE_HELMET))
                .method_351(class_77.method_411(MapleArmorItems.BRONZE_CHESTPLATE))
                .method_351(class_77.method_411(MapleArmorItems.BRONZE_LEGGINGS))
                .method_351(class_77.method_411(MapleArmorItems.BRONZE_BOOTS))
                .apply(class_141.method_621(class_5662.method_32462(minCount, maxCount)).method_515());
    }

    private static class_55.class_56 powderPool(float chance, float minCount, float maxCount) {
        return class_55.method_347()
                .method_352(class_44.method_32448(1))
                .method_356(class_219.method_932(chance))
                .method_351(class_77.method_411(GrowableOresItems.BRONZE_DUST))
                .method_351(class_77.method_411(GrowableOresItems.CLAY_DUST))
                .method_351(class_77.method_411(GrowableOresItems.COAL_DUST))
                .method_351(class_77.method_411(GrowableOresItems.COPPER_DUST))
                .method_351(class_77.method_411(GrowableOresItems.DIAMOND_DUST))
                .method_351(class_77.method_411(GrowableOresItems.ENERGIUM_DUST))
                .method_351(class_77.method_411(GrowableOresItems.GOLD_DUST))
                .method_351(class_77.method_411(GrowableOresItems.IRON_DUST))
                .method_351(class_77.method_411(GrowableOresItems.LAPIS_DUST))
                .method_351(class_77.method_411(GrowableOresItems.LEAD_DUST))
                .method_351(class_77.method_411(GrowableOresItems.LITHIUM_DUST))
                .method_351(class_77.method_411(GrowableOresItems.OBSIDIAN_DUST))
                .method_351(class_77.method_411(GrowableOresItems.SILICON_DIOXIDE_DUST))
                .method_351(class_77.method_411(GrowableOresItems.SILVER_DUST))
                .method_351(class_77.method_411(GrowableOresItems.STONE_DUST))
                .method_351(class_77.method_411(GrowableOresItems.SULFUR_DUST))
                .method_351(class_77.method_411(GrowableOresItems.TIN_DUST))
                .apply(class_141.method_621(class_5662.method_32462(minCount, maxCount)).method_515());
    }

    private static class_55.class_56 iridiumOrePool(float chance, float minCount, float maxCount) {
        return class_55.method_347()
                .method_352(class_44.method_32448(1))
                .method_356(class_219.method_932(chance))
                .method_351(class_77.method_411(GrowableOresItems.IRIDIUM_ORE))
                .apply(class_141.method_621(class_5662.method_32462(minCount, maxCount)).method_515());
    }

    private static class_55.class_56 iridiumShardPool(float chance, float minCount, float maxCount) {
        return class_55.method_347()
                .method_352(class_44.method_32448(1))
                .method_356(class_219.method_932(chance))
                .method_351(class_77.method_411(GrowableOresItems.IRIDIUM_SHARD))
                .apply(class_141.method_621(class_5662.method_32462(minCount, maxCount)).method_515());
    }

    public static void modifyLootTables() {
        LootTableEvents.MODIFY.register((id, tableBuilder, source, registries) -> {
            // ========== Tier 3: High-value chests ==========
            if(Ancient_City_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.35f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.55f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.10f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.05f, 1.0f, 1.0f).method_355());
            }
            if(Bastion_Treasure_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.35f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.55f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.10f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.05f, 1.0f, 1.0f).method_355());
            }
            if(End_City_Treasure_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.35f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.55f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.10f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.05f, 1.0f, 1.0f).method_355());
            }

            // ========== Tier 2.5: Upper-mid chests ==========
            if(Bastion_Bridge_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.20f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.35f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.06f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.03f, 1.0f, 1.0f).method_355());
            }
            if(Bastion_Other_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.20f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.35f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.06f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.03f, 1.0f, 1.0f).method_355());
            }
            if(Woodland_Mansion_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.25f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.35f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.06f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.03f, 1.0f, 1.0f).method_355());
            }
            if(Nether_Bridge_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.20f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.35f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.06f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.03f, 1.0f, 1.0f).method_355());
            }

            // ========== Tier 2: Mid chests ==========
            if(Bastion_Hoglin_Stable_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.18f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.30f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.05f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.02f, 1.0f, 1.0f).method_355());
            }
            if(Stronghold_Corridor_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.18f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.30f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.05f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.02f, 1.0f, 1.0f).method_355());
            }
            if(Stronghold_Crossing_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.18f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.30f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.05f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.02f, 1.0f, 1.0f).method_355());
            }

            // ========== Tier 1.5: Lower-mid chests ==========
            if(Desert_Pyramid_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.12f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.25f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.04f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.02f, 1.0f, 1.0f).method_355());
            }
            if(Jungle_Temple_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.12f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.25f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.04f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.02f, 1.0f, 1.0f).method_355());
            }
            if(Jungle_Temple_Dispenser_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.12f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.25f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.04f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.02f, 1.0f, 1.0f).method_355());
            }
            if(Pillager_Outpost_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.12f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.25f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.04f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.02f, 1.0f, 1.0f).method_355());
            }
            if(Ruined_Portal_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.12f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.25f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.04f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.02f, 1.0f, 1.0f).method_355());
            }
            if(Simple_Dungeon_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.12f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.25f, 1.0f, 2.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.04f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.02f, 1.0f, 1.0f).method_355());
            }

            // ========== Tier 1: Low-tier chests ==========
            if(IGLOO_STRUCTURE_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.08f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.18f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.03f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.01f, 1.0f, 1.0f).method_355());
            }
            if(Mineshaft_STRUCTURE_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.08f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.18f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.03f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.01f, 1.0f, 1.0f).method_355());
            }
            if(Buried_Treasure_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.08f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.18f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.03f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.01f, 1.0f, 1.0f).method_355());
            }
            if(Underwater_Ruin_Small_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.08f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.18f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.03f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.01f, 1.0f, 1.0f).method_355());
            }
            if(Underwater_Ruin_Big_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.08f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.18f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.03f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.01f, 1.0f, 1.0f).method_355());
            }
            if(Shipwreck_Map_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.08f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.18f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.03f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.01f, 1.0f, 1.0f).method_355());
            }
            if(Shipwreck_Supply_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.08f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.18f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.03f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.01f, 1.0f, 1.0f).method_355());
            }
            if(Shipwreck_Treasure_CHEST_ID.equals(id.method_29177())) {
                tableBuilder.pool(bronzeArmorPool(0.08f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(powderPool(0.18f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumOrePool(0.03f, 1.0f, 1.0f).method_355());
                tableBuilder.pool(iridiumShardPool(0.01f, 1.0f, 1.0f).method_355());
            }
        });
    }
}