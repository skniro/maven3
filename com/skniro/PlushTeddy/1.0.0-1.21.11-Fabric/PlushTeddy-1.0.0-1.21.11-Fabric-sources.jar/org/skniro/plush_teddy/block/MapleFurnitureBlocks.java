package org.skniro.plush_teddy.block;

import org.skniro.plush_teddy.PlushTeddy;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.skniro.plush_teddy.block.init.*;

import java.util.function.Function;

public class MapleFurnitureBlocks {
    public static final class_2248 TEDDY_BEAR_NORMAL = registerBlock("teddy_bear_normal", BaseTeddyBearBlock::new, class_4970.class_2251.method_9630(class_2246.field_10113).method_22488().method_9634().method_9632(1.0F).method_50013());

    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(keyOf(name)));
        registerBlockItem(name, block);
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }


    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(PlushTeddy.MOD_ID, name)),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(PlushTeddy.MOD_ID, name)))));
    }

    private static class_2248 registerBlockWithoutItem(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(keyOf(name)));
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }

    private static class_5321<class_2248> keyOf(String name) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(PlushTeddy.MOD_ID, name));
    }

    public static void registerCushionBlocks() {
        PlushTeddy.LOGGER.debug("Registering Cushion Blocks for " + PlushTeddy.MOD_ID);
    }
}
