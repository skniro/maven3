package com.skniro.maple.world.feature;

import com.skniro.maple.Maple;
import net.minecraft.class_2893;
import net.minecraft.class_5485;

public class MapleBiomeFeatures {
    public static void addMapleGroveFeatures(class_5485.class_5495 builder) {
        builder.method_30992(class_2893.class_2895.field_13178, MaplePlacedFeatures.Maple_TREE_PLACED);
        builder.method_30992(class_2893.class_2895.field_13178, MaplePlacedFeatures.Red_Maple_TREE_PLACED);
    }

    public static void addSakuraFeatures(class_5485.class_5495 builder) {
        builder.method_30992(class_2893.class_2895.field_13178, MaplePlacedFeatures.SAKURA_TREE_PLACED);
    }

    public static void addTeaSnowy(class_5485.class_5495 builder) {
        builder.method_30992(class_2893.class_2895.field_13178, MaplePlacedFeatures.PATCH_TEA_RARE);
    }

    public static void addTea(class_5485.class_5495 builder) {
        builder.method_30992(class_2893.class_2895.field_13178, MaplePlacedFeatures.PATCH_TEA_COMMON);
    }

    public static void registerBiomesFeatures() {
        Maple.LOGGER.debug("Registering the ModBiomesFeatures for " + Maple.MOD_ID);
    }
}
