package com.skniro.maple.datagen;

import com.skniro.maple.block.MapleBlocks;
import com.skniro.maple.block.MapleNetherOresBlocks;
import com.skniro.maple.block.MapleOreBlocks;
import com.skniro.maple.block.MapleSignBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

import static com.skniro.maple.datagen.MapleBlockTagGeneration.ModBlockTags.*;
import static net.minecraft.class_3481.*;


public class MapleBlockTagGeneration extends FabricTagProvider.BlockTagProvider {
    public MapleBlockTagGeneration(FabricDataOutput dataGenerator,CompletableFuture<class_7225.class_7874> completableFuture) {
        super(dataGenerator, completableFuture);
    }


    public static class ModBlockTags {
        public static final class_6862<class_2248> C_SAPLING = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "saplings"));
        public static final class_6862<class_2248> C_MAPLE_LOGS = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "maple_logs"));
        public static final class_6862<class_2248> C_CHERRY_LOGS = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "cherry_logs"));
        public static final class_6862<class_2248> C_PLASTER = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "plaster"));

    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        valueLookupBuilder(field_15462)
                .method_71554(MapleBlocks.MAPLE_SAPLING)
                .method_71554(MapleBlocks.CHERRY_SAPLING);
        valueLookupBuilder(C_SAPLING)
                .method_71554(MapleBlocks.MAPLE_SAPLING)
                .method_71554(MapleBlocks.CHERRY_SAPLING);
        valueLookupBuilder(C_MAPLE_LOGS)
                .method_71554(MapleBlocks.MAPLE_LOG);
        valueLookupBuilder(C_CHERRY_LOGS)
                .method_71554(MapleBlocks.CHERRY_LOG);
        valueLookupBuilder(field_16584)
                .method_71554(MapleBlocks.MAPLE_FENCE)
                .method_71554(MapleBlocks.CHERRY_FENCE)
                .method_71554(MapleBlocks.BAMBOO_FENCE);
        valueLookupBuilder(C_PLASTER)
                .method_71554(MapleBlocks.GREEN_PLASTER)
                .method_71554(MapleBlocks.PLASTER)
                .method_71554(MapleBlocks.ORANGE_PLASTER)
                .method_71554(MapleBlocks.MAGENTA_PLASTER)
                .method_71554(MapleBlocks.LIGHT_BLUE_PLASTER)
                .method_71554(MapleBlocks.YELLOW_PLASTER)
                .method_71554(MapleBlocks.LIME_PLASTER)
                .method_71554(MapleBlocks.PINK_PLASTER)
                .method_71554(MapleBlocks.GRAY_PLASTER)
                .method_71554(MapleBlocks.LIGHT_GRAY_PLASTER)
                .method_71554(MapleBlocks.CYAN_PLASTER)
                .method_71554(MapleBlocks.PURPLE_PLASTER)
                .method_71554(MapleBlocks.BLUE_PLASTER)
                .method_71554(MapleBlocks.BROWN_PLASTER)
                .method_71554(MapleBlocks.RED_PLASTER);
        valueLookupBuilder(field_33715)
                .method_71554(MapleBlocks.GREEN_PLASTER)
                .method_71554(MapleBlocks.PLASTER)
                .method_71554(MapleBlocks.ORANGE_PLASTER)
                .method_71554(MapleBlocks.MAGENTA_PLASTER)
                .method_71554(MapleBlocks.LIGHT_BLUE_PLASTER)
                .method_71554(MapleBlocks.YELLOW_PLASTER)
                .method_71554(MapleBlocks.LIME_PLASTER)
                .method_71554(MapleBlocks.PINK_PLASTER)
                .method_71554(MapleBlocks.GRAY_PLASTER)
                .method_71554(MapleBlocks.LIGHT_GRAY_PLASTER)
                .method_71554(MapleBlocks.CYAN_PLASTER)
                .method_71554(MapleBlocks.PURPLE_PLASTER)
                .method_71554(MapleBlocks.BLUE_PLASTER)
                .method_71554(MapleBlocks.BROWN_PLASTER)
                .method_71554(MapleBlocks.RED_PLASTER)
                .method_71554(MapleOreBlocks.Salt_Ore)
                .method_71554(MapleOreBlocks.DEEPSLATE_Salt_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Coal_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Diamond_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Copper_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Emerald_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Iron_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Gold_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Lapis_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Redstone_Ore)
                .setReplace(false);
        valueLookupBuilder(field_40103)
                .method_71554(MapleSignBlocks.Maple_HANGING_SIGN)
                .method_71554(MapleSignBlocks.GINKGO_HANGING_SIGN);
        valueLookupBuilder(field_40104)
                .method_71554(MapleSignBlocks.Maple_WALL_HANGING_SIGN)
                .method_71554(MapleSignBlocks.GINKGO_WALL_HANGING_SIGN);
        // minecraft:block/needs_stone_tool -> add mod ores that require stone
        valueLookupBuilder(field_33719)
                .method_71554(MapleNetherOresBlocks.Nether_Iron_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Lapis_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Copper_Ore);
        // minecraft:block/needs_stone_tool -> add mod ores that require stone
        valueLookupBuilder(field_33719)
                .method_71554(MapleNetherOresBlocks.Nether_Iron_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Lapis_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Copper_Ore);
        // minecraft:block/needs_iron_tool -> add mod ores that require iron
        valueLookupBuilder(field_33718)
                .method_71554(MapleOreBlocks.DEEPSLATE_Salt_Ore)
                .method_71554(MapleOreBlocks.Salt_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Diamond_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Emerald_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Gold_Ore)
                .method_71554(MapleNetherOresBlocks.Nether_Redstone_Ore)
                .setReplace(false);
        // minecraft:block/logs_that_burn -> maple/ginkgo logs
        valueLookupBuilder(field_23210)
                .method_71554(MapleBlocks.MAPLE_LOG)
                .method_71554(MapleBlocks.MAPLE_WOOD)
                .method_71554(MapleBlocks.STRIPPED_MAPLE_LOG)
                .method_71554(MapleBlocks.STRIPPED_MAPLE_WOOD)
                .method_71554(MapleBlocks.GINKGO_LOG)
                .method_71554(MapleBlocks.GINKGO_WOOD)
                .method_71554(MapleBlocks.STRIPPED_GINKGO_LOG)
                .method_71554(MapleBlocks.STRIPPED_GINKGO_WOOD)
                .setReplace(false);
        // minecraft:block/crops -> maples rice plant
        valueLookupBuilder(field_20341)
                .method_71554(MapleBlocks.RICE)
                .setReplace(false);
    }
}
