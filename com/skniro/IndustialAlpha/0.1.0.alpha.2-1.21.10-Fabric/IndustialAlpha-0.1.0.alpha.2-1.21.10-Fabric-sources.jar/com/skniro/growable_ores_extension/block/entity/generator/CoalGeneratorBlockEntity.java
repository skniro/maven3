package com.skniro.growable_ores_extension.block.entity.generator;

import com.skniro.growable_ores_extension.api.ImplementedInventory;
import com.skniro.growable_ores_extension.api.item.ModFuelRegistry;
import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.block.init.generator.CoalGeneratorBlock;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.EnergyStorageUtil;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import com.skniro.growable_ores_extension.screen.generator.CoalGeneratorScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;


public class CoalGeneratorBlockEntity extends BaseGeneratorBlockEntity {
    private final class_2371<class_1799> inventory = class_2371.method_10213(2, class_1799.field_8037);


    private static final int INPUT_SLOT = 0;
    private static final int Battery_SLOT = 1;

    protected final class_3913 propertyDelegate;
    private int burnProgress;
    private int maxBurnProgress;
    private boolean isBurning = false;
    private static final int ENERGY_TRANSFER_AMOUNT = 320;

    public CoalGeneratorBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.COAL_GENERATOR_BE, pos, state, 40000, EnergyTier.TIER1);
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> CoalGeneratorBlockEntity.this.burnProgress;
                    case 1 -> CoalGeneratorBlockEntity.this.maxBurnProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: CoalGeneratorBlockEntity.this.burnProgress = value;
                    case 1: CoalGeneratorBlockEntity.this.maxBurnProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };
    }

    @Override
    protected void method_11007(class_11372 nbt) {
        super.method_11007(nbt);
        class_1262.method_5426(nbt, inventory);
        nbt.method_71466(("coal_generator.energy"), energyContainer.amount);
        nbt.method_71465(("coal_generator.burn_progress"), burnProgress);
        nbt.method_71465(("coal_generator.max_burn_progress"), maxBurnProgress);
    }

    @Override
    protected void method_11014(class_11368 nbt) {
        class_1262.method_5429(nbt, inventory);
        energyContainer.amount = nbt.method_71425("coal_generator.energy", 0);
        burnProgress = nbt.method_71424("coal_generator.burn_progress", 0);
        maxBurnProgress = nbt.method_71424("coal_generator.max_burn_progress", 0);
        super.method_11014(nbt);
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2371<class_1799> getItems() {
        return this.inventory;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.CoalGenerator);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new CoalGeneratorScreenHandler(syncId, playerInventory, this, this.propertyDelegate);
    }

    private int getFuelTime(class_1799 stack) {
        if (stack.method_7960()) return 0;

        Integer custom = ModFuelRegistry.getModFuel().get(stack.method_7909());
        if (custom != null) return custom;

        for (var entry : ModFuelRegistry.getModFuelTags().entrySet()) {
            if (stack.method_31573(entry.getKey())) {
                return entry.getValue();
            }
        }

        if (this.field_11863 != null) {
            return this.field_11863.method_61269().method_61755(stack) / 2;
        }

        return 0;
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world != null && !world.method_8608()) {

            discharge(Battery_SLOT);

            pushEnergyToNeighbours();

            if (isBurning) {
                if (energyContainer.amount < energyContainer.getCapacity()) {
                    increaseBurnTimer();
                    fillUpOnEnergy();
                }

                if (currentFuelDoneBurning()) {
                    resetBurning();
                }

                world.method_8652(pos, state.method_11657(CoalGeneratorBlock.LIT, isBurning), class_2248.field_31036);
            }

            if (!isBurning && hasFuelItemInSlot() && energyContainer.amount < energyContainer.getCapacity()) {
                startBurning();
            }
        }
    }

    private void pushEnergyToNeighbours() {
        if (energyContainer.amount <= 0) return;

        for (class_2350 direction : class_2350.values()) {
            EnergyStorage target = EnergyStorage.SIDED.find(
                    field_11863,
                    field_11867.method_10093(direction),
                    direction.method_10153()
            );

            if (target == null) continue;

            EnergyStorageUtil.move(
                    this.energyContainer.getSideStorage(direction),
                    target,
                    ENERGY_TRANSFER_AMOUNT,
                    null
            );
        }
    }


    public boolean canInsert(class_1799 stack) {
        return stack.method_31573(ModItemTags.BATTERY);
    }

    private void fillUpOnEnergy() {
        try (Transaction transaction = Transaction.openOuter()) {
            this.energyContainer.getSideStorage(null).insert(energyTier.getMaxInput(), transaction);
            transaction.commit();
        }
    }

    private boolean hasFuelItemInSlot() {
        class_1799 stack = this.method_5438(INPUT_SLOT);
        return getFuelTime(stack) > 0;
    }

    private boolean isBurningFuel() {
        return isBurning;
    }

    private void startBurning() {
        class_1799 stack = this.method_5438(INPUT_SLOT);

        int burnTime = getFuelTime(stack);
        if (burnTime <= 0) return;

        this.method_5434(INPUT_SLOT, 1);

        this.burnProgress = burnTime;
        this.maxBurnProgress = this.burnProgress;
        this.isBurning = true;
    }

    private void increaseBurnTimer() {
        --this.burnProgress;
    }

    private boolean currentFuelDoneBurning() {
        return this.burnProgress <= 0;
    }

    private void resetBurning() {
        isBurning = false;
    }

    public void discharge(int slot) {
        if (this.field_11863 != null) {
            if (!this.field_11863.method_8608()) {
                if (!this.getOptionalInventory().isEmpty()) {
                    class_1263 inventory = this.getOptionalInventory().get();
                    EnergyStorageUtil.move(this.getSideEnergyStorage(null), ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(slot)).find(EnergyStorage.ITEM), Long.MAX_VALUE, null);
                }
            }
        }
    }

    public long getFreeSpace() {
        return this.energyContainer.getCapacity() - energyContainer.amount;
    }

    public Optional<ImplementedInventory> getOptionalInventory() {
        if (this instanceof ImplementedInventory inventory) {
            return inventory == null ? Optional.empty() : Optional.of(inventory);
        } else {
            return Optional.empty();
        }
    }


    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}