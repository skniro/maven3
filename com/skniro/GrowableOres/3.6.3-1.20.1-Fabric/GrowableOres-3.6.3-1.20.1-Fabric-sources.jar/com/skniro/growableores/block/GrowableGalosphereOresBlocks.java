package com.skniro.growableores.block;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.init.GrowableOreCaneBlock;
import com.skniro.growableores.util.GrowableOresItemGroups;
import java.util.logging.Logger;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public class GrowableGalosphereOresBlocks {
    //Galosphere
    public static final class_2248 Galo_Allurite_Shard_Cane = registerBlock("galo_allurite_shard_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11537).method_50012(class_3619.field_15971)), GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Galo_Lumiere_Shard_Cane = registerBlock("galo_lumiere_shard_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11537).method_50012(class_3619.field_15971)), GrowableOresItemGroups.Growable_Ores_Group);
    public static final class_2248 Galo_Silver_Ingot_Cane = registerBlock("galo_silver_ingot_cane", new GrowableOreCaneBlock(class_4970.class_2251.method_9637().method_31710(class_3620.field_16004).method_9634().method_9640().method_9618().method_9626(class_2498.field_11537).method_50012(class_3619.field_15971)), GrowableOresItemGroups.Growable_Ores_Group);


    private static class_2248 registerBlock(String name, class_2248 block, class_5321<class_1761> tab) {
        registerBlockItem(name, block, tab);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_43902(GrowableOres.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block, class_5321<class_1761> tab) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_43902(GrowableOres.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
    }
    public static void registerModBlocks(){
        Logger.getLogger("register mod blocks" + GrowableOres.MOD_ID);
    }
}

