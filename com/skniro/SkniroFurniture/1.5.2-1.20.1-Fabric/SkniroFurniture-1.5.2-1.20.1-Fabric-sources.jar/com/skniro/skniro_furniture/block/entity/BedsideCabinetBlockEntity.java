package com.skniro.skniro_furniture.block.entity;

import com.skniro.skniro_furniture.init.FurnitureStrings;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;

public class BedsideCabinetBlockEntity extends AbstractFurnitureContainerBlockEntity {


    public BedsideCabinetBlockEntity(class_2338 pos, class_2680 state) {
        super(FurnitureBlockEntityType.Bedside_Cabinet_BLOCK_ENTITY, pos, state,27);
    }

    protected class_2561 method_17823() {
        return class_2561.method_43471(FurnitureStrings.Bedside_Cabinet);
    }

    protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return class_1707.method_19245(syncId, playerInventory, this);
    }
}
