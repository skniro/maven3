package org.skniro.plush_teddy.datagen;

import org.skniro.plush_teddy.block.*;
import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_4910;
import net.minecraft.class_4915;

public class MapleModelProvider extends FabricModelProvider {
    public MapleModelProvider(FabricDataOutput dataGenerator){
        super(dataGenerator);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator){

        blockStateModelGenerator.method_25708(MapleFurnitureBlocks.TEDDY_BEAR_NORMAL);

    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {

    }
}
