package com.skniro.maple.block.entity;

import com.mojang.datafixers.types.Type;
import com.skniro.maple.Maple;
import com.skniro.maple.block.MapleBlocks;
import net.minecraft.class_1208;
import net.minecraft.class_156;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;


public class MapleBlockEntityType {

    public static final class_2591<MapleJuicerBlockEntity> MAPLE_JUICER_BLOCK_ENTITY_BLOCK_ENTITY_TYPE = create("maple_juicer_block_entity", class_2591.class_2592.method_20528(MapleJuicerBlockEntity::new, MapleBlocks.Maple_Juicer_Block));

    private static <T extends class_2586> class_2591<T> create(String id, class_2591.class_2592<T> builder) {
        Type<?> type = class_156.method_29187(class_1208.field_5727, id);
        return (class_2591) class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(Maple.MOD_ID,id), builder.method_11034(type));
    }

    static {
    }

    public static void registerMapleBlockEntityType() {
        Maple.LOGGER.debug("Registering MapleBlockEntityType for " + Maple.MOD_ID);
    }

}
