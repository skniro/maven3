package org.skniro.plush_teddy.block.init;


import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

public class BaseTeddyBearBlock extends class_2383 {
    public static final MapCodec<BaseTeddyBearBlock> CODEC = method_54094(BaseTeddyBearBlock::new);
    private static final class_265 NORTH_SHAPE;
    private static final class_265 SOUTH_SHAPE;
    private static final class_265 EAST_SHAPE;
    private static final class_265 WEST_SHAPE;

    public BaseTeddyBearBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends BaseTeddyBearBlock> method_53969() {
        return field_46280;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2350 direction = state.method_11654(field_11177);
        switch (direction){
            case field_11034:
                return EAST_SHAPE;
            case field_11035:
                return SOUTH_SHAPE;
            case field_11039:
                return WEST_SHAPE;
            case field_11043:
            default:
                return NORTH_SHAPE;
        }
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(field_11177, ctx.method_8042().method_10153());
    }
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }

    static {
        NORTH_SHAPE = class_2248.method_9541(5.0, 0.0, 6.0, 11.0, 12.0, 10.6);
        SOUTH_SHAPE = class_2248.method_9541(5.0, 0.0, 5.4, 11.0, 12.0, 10.0);
        EAST_SHAPE = class_2248.method_9541(5.4, 0.0, 5.0, 10.0, 12.0, 11.0);
        WEST_SHAPE = class_2248.method_9541(6.0, 0.0, 5.0, 10.6, 12.0, 11.0);
    }
}
