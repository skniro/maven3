package com.skniro.growable_ores_extension.screen;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.screen.generator.CoalGeneratorScreenHandler;
import com.skniro.growable_ores_extension.screen.generator.GeneratorSolarPanelScreenHandler;
import com.skniro.growable_ores_extension.screen.generator.GeneratorWindMillScreenHandler;
import com.skniro.growable_ores_extension.screen.machine.CompressorScreenHandler;
import com.skniro.growable_ores_extension.screen.machine.MaceratorScreenHandler;
import com.skniro.growable_ores_extension.screen.machine.MetalFormerScreenHandler;
import com.skniro.growable_ores_extension.screen.machine.MolecularTransformerScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class AlchemyScreenHandlerType <T extends class_1703>{
    public static final class_3917<AlchemyBlockScreenHandler> ALCHEMY =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "cane_converter_screen_handler"),
                    new ExtendedScreenHandlerType<>(AlchemyBlockScreenHandler::new, class_2338.field_48404));

    public static final class_3917<CoalGeneratorScreenHandler> COAL_GENERATOR_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "coal_generator_screen_handler"),
                    new ExtendedScreenHandlerType<>(CoalGeneratorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<GeneratorWindMillScreenHandler> GENERATOR_Wind_Mill_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "generator_wind_mill_screen_handler"),
                    new ExtendedScreenHandlerType<>(GeneratorWindMillScreenHandler::new, class_2338.field_48404));

    public static final class_3917<GeneratorSolarPanelScreenHandler> GENERATOR_Solar_Panel_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "generator_solar_panel_screen_handler"),
                    new ExtendedScreenHandlerType<>(GeneratorSolarPanelScreenHandler::new, class_2338.field_48404));

    public static final class_3917<MaceratorScreenHandler> Macerator =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "macerator_screen_handler"),
                    new ExtendedScreenHandlerType<>(MaceratorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<CompressorScreenHandler> Compressor =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "compressor_screen_handler"),
                    new ExtendedScreenHandlerType<>(CompressorScreenHandler::new, class_2338.field_48404));

    public static final class_3917<MetalFormerScreenHandler> MetalFormer =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "metal_former_screen_handler"),
                    new ExtendedScreenHandlerType<>(MetalFormerScreenHandler::new, class_2338.field_48404));

    public static final class_3917<EnergyBoxScreenHandler> EnergyBox =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "energy_box_screen_handler"),
                    new ExtendedScreenHandlerType<>(EnergyBoxScreenHandler::new, class_2338.field_48404));

    public static final class_3917<ChargePadScreenHandler> ChargePad =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "charge_pad_screen_handler"),
                    new ExtendedScreenHandlerType<>(ChargePadScreenHandler::new, class_2338.field_48404));

    public static final class_3917<MolecularTransformerScreenHandler> MolecularTransformer =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(GrowableOresExtension.MOD_ID, "molecular_transformer_screen_handler"),
                    new ExtendedScreenHandlerType<>(MolecularTransformerScreenHandler::new, class_2338.field_48404));

    public static void registeralchemyscreenhandlertype() {

    }
}
