package com.skniro.industrial_elixir.screen.ingame.generator;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.screen.handler.generator.CoalGeneratorScreenHandler;
import com.skniro.industrial_elixir.util.MouseUtil;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_465;
import java.util.List;
import java.util.Optional;

public class CoalGeneratorScreen extends class_465<CoalGeneratorScreenHandler> {
    private static final class_2960 GUI_TEXTURE =
            class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/guichargepadblock.png");
    private static final class_2960 LIT_PROGRESS_TEXTURE = class_2960.method_60654("container/furnace/lit_progress");

    public CoalGeneratorScreen(CoalGeneratorScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        // Center title
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
    }

    public List<class_2561> getTooltips() {
        return List.of(class_2561.method_43470(field_2797.blockEntity.energyContainer.getSideStorage(null).getAmount()+" / "+ field_2797.blockEntity.energyContainer.getSideStorage(null).getCapacity()+" EP"));
    }

    private void renderEnergyAreaTooltips(class_332 context, int pMouseX, int pMouseY, int x, int y) {
        if(isMouseAboveArea(pMouseX, pMouseY, x, y, 76, 36, 31, 16)) {
            context.method_51437(Screens.getTextRenderer(this), getTooltips(),
                    Optional.empty(), pMouseX, pMouseY);
        }
    }

    private void renderEnergyArea(class_332 context, int x, int y) {
        context.method_25290(GUI_TEXTURE, x + 76, y + 34, 176, 14, getScaledEnergyHeight(), 16,256,256);
    }

    public int getScaledEnergyHeight() {
        long energy = field_2797.blockEntity.energyContainer.amount;
        long capacity = field_2797.blockEntity.energyContainer.getCapacity();
        int energyBarSize = 31;

        return Math.toIntExact(capacity != 0 && energy != 0 ? energy * energyBarSize / capacity : 0);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        context.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, -12566464, false);
        context.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, -12566464, false);
        renderEnergyAreaTooltips(context, mouseX, mouseY, field_2776, field_2800);
    }

    @Override
       protected void method_2389(class_332 context, float partialTicks, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        context.method_25290(GUI_TEXTURE, x, y, 0, 0, field_2792, field_2779,256,256);

        renderBurnProgress(context, x, y);
        renderEnergyArea(context, x, y);
    }

    private void renderBurnProgress(class_332 context, int x, int y) {
        if(field_2797.isBurning()) {
            int l = class_3532.method_15386(this.field_2797.getFuelProgress() * 13.0f) + 1;
            context.method_52708(LIT_PROGRESS_TEXTURE, 14, 14, 0, 14 - l, x + 80, y + 18 + 14 - l, 14, l);
        }
    }

    @Override
   public void method_25394(class_332 context , int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }

    private boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, int width, int height) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, width, height);
    }
}