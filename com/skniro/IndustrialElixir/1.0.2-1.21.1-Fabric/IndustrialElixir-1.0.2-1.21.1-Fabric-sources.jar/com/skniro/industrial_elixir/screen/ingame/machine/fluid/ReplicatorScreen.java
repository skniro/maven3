package com.skniro.industrial_elixir.screen.ingame.machine.fluid;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.renderer.GuiFluidTankRenderer;
import com.skniro.industrial_elixir.block.entity.machine.fluid.ReplicatorBlockEntity;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.ReplicatorScreenHandler;
import com.skniro.industrial_elixir.screen.ingame.widgets.ReplicatorModeButton;
import com.skniro.industrial_elixir.util.MouseUtil;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

public class ReplicatorScreen extends class_465<ReplicatorScreenHandler> {
    private static final class_2960 TEXTURE =
            class_2960.method_60655(IndustrialElixir.MOD_ID, "textures/gui/container/machine/replicator.png");
    private GuiFluidTankRenderer fluidRenderer;

    public ReplicatorScreen(ReplicatorScreenHandler menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25269 = 45;
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
        field_25268 = 4;
        assignFluidRenderer();
        addModeButtons();
    }

    private void assignFluidRenderer() {
        fluidRenderer = new GuiFluidTankRenderer(field_2797.blockEntity.fluidContainer.getCapacity(), true, 16, 50);
    }

    private void addModeButtons() {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        ReplicatorBlockEntity be = this.field_2797.blockEntity;

        this.method_37063(new ReplicatorModeButton(
                x + 56, y + 52, 18, 18,
                ReplicatorBlockEntity.Mode.STOP,
                be.getMode() == ReplicatorBlockEntity.Mode.STOP,
                class_1802.field_8077.method_7854(),
                class_2561.method_43471("gui.industrial_elixir.replicator.stop"),
                (b) -> onModeButton(ReplicatorScreenHandler.BUTTON_STOP)));

        this.method_37063(new ReplicatorModeButton(
                x + 76, y + 52, 18, 18,
                ReplicatorBlockEntity.Mode.SINGLE,
                be.getMode() == ReplicatorBlockEntity.Mode.SINGLE,
                class_1802.field_8407.method_7854(),
                class_2561.method_43471("gui.industrial_elixir.replicator.single"),
                (b) -> onModeButton(ReplicatorScreenHandler.BUTTON_SINGLE)));

        this.method_37063(new ReplicatorModeButton(
                x + 96, y + 52, 18, 18,
                ReplicatorBlockEntity.Mode.LOOP,
                be.getMode() == ReplicatorBlockEntity.Mode.LOOP,
                class_1802.field_8619.method_7854(),
                class_2561.method_43471("gui.industrial_elixir.replicator.loop"),
                (b) -> onModeButton(ReplicatorScreenHandler.BUTTON_LOOP)));
    }

    private void onModeButton(int buttonId) {
        if (this.field_22787 != null && this.field_22787.field_1761 != null) {
            this.field_22787.field_1761.method_2900(this.field_2797.field_7763, buttonId);
        }
    }

    public List<class_2561> getTooltips() {
        return List.of(class_2561.method_43470(
                NumberFormat.getNumberInstance(Locale.US).format(field_2797.blockEntity.energyContainer.amount)
                + " / "
                + NumberFormat.getNumberInstance(Locale.US).format(field_2797.blockEntity.energyContainer.getCapacity())
                + " EP"));
    }

    private void renderEnergyArea(class_332 context, int x, int y) {
        context.method_25290(TEXTURE, x + 129, y + 45, 176, 0, 13, field_2797.getScaledEnergyHeight(), 256, 256);
    }

    private void renderEnergyAreaTooltips(class_332 context, int pMouseX, int pMouseY, int x, int y) {
        if (isMouseAboveArea(pMouseX, pMouseY, x, y, 131, 45, 13, 14)) {
            context.method_51437(Screens.getTextRenderer(this), getTooltips(),
                    Optional.empty(), pMouseX, pMouseY);
        }
    }

    private void renderFluidTooltipArea(class_332 guiGraphics, int pMouseX, int pMouseY, int x, int y) {
        if (isMouseAboveArea(pMouseX, pMouseY, x, y, 8, 7, fluidRenderer)) {
            guiGraphics.method_51437(this.field_22793,
                    fluidRenderer.getTooltip(field_2797.blockEntity.fluidContainer), Optional.empty(), pMouseX - x, pMouseY - y);
        }
    }

    @Override
    protected void method_2388(class_332 graphics, int xm, int ym) {
        super.method_2388(graphics, xm, ym);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        renderEnergyAreaTooltips(graphics, xm, ym, x, y);
        renderFluidTooltipArea(graphics, xm, ym, x, y);

        // Progress text
        ReplicatorBlockEntity be = this.field_2797.blockEntity;
        if (be.getMode() != ReplicatorBlockEntity.Mode.STOP && (be.getReplicatingEnergyCost() > 0 || be.getReplicatingUUCost() > 0)) {
            int pct = be.getOverallProgressPercent();
            graphics.method_51433(field_22793, pct + "%", 77, 41, -12566464, false);
        }

        graphics.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, -12566464, false);
        graphics.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, -12566464, false);
    }

    @Override
    protected void method_2389(class_332 graphics, float a, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        graphics.method_25290(TEXTURE, x, y, 0, 0, field_2792, field_2779, 256, 256);

        renderEnergyArea(graphics, x, y);
        fluidRenderer.render(graphics, x + 8, y + 5, field_2797.blockEntity.fluidContainer);
        renderProgressArrow(graphics, x, y);
    }

    private void renderProgressArrow(class_332 guiGraphics, int x, int y) {
        if (field_2797.isCrafting()) {
            guiGraphics.method_25290(TEXTURE, x + 72, y + 22, 189, 0, field_2797.getScaledProgress(), 16, 256, 256);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }

    public static boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, GuiFluidTankRenderer renderer) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, renderer.getWidth(), renderer.getHeight());
    }

    public static boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, int width, int height) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, width, height);
    }
}
