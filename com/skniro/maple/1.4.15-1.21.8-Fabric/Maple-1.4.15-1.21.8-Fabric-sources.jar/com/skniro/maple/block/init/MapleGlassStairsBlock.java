package com.skniro.maple.block.init;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2510;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;

public class MapleGlassStairsBlock extends class_2510 {
    public MapleGlassStairsBlock(class_2680 baseBlockState, class_2251 settings) {
        super(baseBlockState, settings);
    }

    @Override
    public class_265 method_26159(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return class_259.method_1073();
    }

    public float method_9575(class_2680 state, class_1922 world, class_2338 pos) {
        return 1.0F;
    }

    public boolean isTransparent(class_2680 state, class_1922 world, class_2338 pos) {
        return true;
    }
}
