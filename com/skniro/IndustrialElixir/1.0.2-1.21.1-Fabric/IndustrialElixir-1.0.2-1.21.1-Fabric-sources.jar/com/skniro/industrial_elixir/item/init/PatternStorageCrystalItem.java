package com.skniro.industrial_elixir.item.init;

import com.skniro.industrial_elixir.block.entity.machine.PatternStorageBlockEntity;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

public class PatternStorageCrystalItem extends class_1792 {

    public PatternStorageCrystalItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> textConsumer, class_1836 flag) {
        if (PatternStorageBlockEntity.hasPatternData(stack)) {
            var itemId = PatternStorageBlockEntity.getPatternItem(stack);
            int uuCost = PatternStorageBlockEntity.getPatternUUCost(stack);
            int energyCost = PatternStorageBlockEntity.getPatternEnergyCost(stack);

            if (itemId != null) {
                var item = class_7923.field_41178.method_10223(itemId);
                class_1799 stack1 = new class_1799(item);
                if (item != null) {
                    textConsumer.add(class_2561.method_43471("tooltip.industrial_elixir.pattern_storage.stored_item")
                            .method_27693(": ")
                            .method_10852(class_2561.method_43471(stack1.method_7964().getString()))
                            .method_27692(class_124.field_1065));
                }
            }

            textConsumer.add(class_2561.method_43471("tooltip.industrial_elixir.pattern_storage.energy_cost")
                    .method_27693(": ")
                    .method_27693(NumberFormat.getNumberInstance(Locale.US).format(energyCost))
                    .method_27693(" E")
                    .method_27692(class_124.field_1061));

            textConsumer.add(class_2561.method_43471("tooltip.industrial_elixir.pattern_storage.uu_cost")
                    .method_27693(": ")
                    .method_27693(String.valueOf(uuCost))
                    .method_27693(" mB")
                    .method_27692(class_124.field_1075));
        }
    }
}
