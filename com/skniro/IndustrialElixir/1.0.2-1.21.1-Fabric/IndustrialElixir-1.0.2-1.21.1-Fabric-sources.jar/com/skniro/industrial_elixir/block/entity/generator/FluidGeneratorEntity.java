package com.skniro.industrial_elixir.block.entity.generator;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.block.ImplementedInventory;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.entity.machine.fluid.AbstractFluidMachineEntity;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.energy.api.EnergyStorage;
import com.skniro.industrial_elixir.energy.api.EnergyStorageUtil;
import com.skniro.industrial_elixir.energy.api.base.SimpleSidedEnergyContainer;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluids;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.screen.handler.generator.fluid.FluidGeneratorScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3612;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class FluidGeneratorEntity extends AbstractFluidMachineEntity {
    // Lava: 1000mB per 25s = 40mB/s = 2mB/t, generates 20EU/t
    // Water: 20mB/s = 1mB/t, generates 1EU/t
    // Internal unit: FluidConstants.BUCKET / 81 = 1000 mB per bucket
    private static final long LAVA_CONSUME_PER_TICK = (FluidConstants.BUCKET / 81) / 500;  // 2mB
    private static final long WATER_CONSUME_PER_TICK = (FluidConstants.BUCKET / 81) / 1000; // 1mB
    private static final long LAVA_EU_PER_TICK = 20;
    private static final long WATER_EU_PER_TICK = 1;

    public FluidGeneratorEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.FLUID_GENERATOR_BE, pos, state);
        energyContainer = new SimpleSidedEnergyContainer() {
            @Override
            public long getCapacity() {
                return 10000;
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                // Output-only: accept energy internally (cable buffer bookkeeping) but never
                // from neighbouring blocks.
                return side == null ? getEffectiveTier().getMaxInput() : 0;
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                return getEffectiveTier().getMaxOutput();
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(pos, method_11010(), method_11010(), 3);
            }
        };
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Fluid_Generator);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new FluidGeneratorScreenHandler(syncId, playerInventory, field_11867);
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return null;
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world == null || world.method_8608()) return;

        // Output energy to batteries
        discharge(ENERGY_ITEM_SLOT);

        // Push energy to adjacent machines
        pushEnergyToNeighbours();

        // Fill from fluid containers
        if (hasFluidStackInFluidSlot()) {
            fillUpFluidTank();
        }

        boolean working = false;

        // Only work if internal storage is not full
        if (energyContainer.amount < energyContainer.getCapacity()) {
            FluidVariant fluid = fluidContainer.getResource();

            // Try lava first (priority)
            if (!fluid.isBlank() && fluid.getFluid() == class_3612.field_15908) {
                if (fluidContainer.getAmount() >= LAVA_CONSUME_PER_TICK) {
                    try (Transaction tx = Transaction.openOuter()) {
                        long extracted = fluidContainer.extract(fluid, LAVA_CONSUME_PER_TICK, tx);
                        if (extracted == LAVA_CONSUME_PER_TICK) {
                            energyContainer.getSideStorage(null).insert(LAVA_EU_PER_TICK, tx);
                            tx.commit();
                            working = true;
                        }
                    }
                }
            }

            // If lava didn't work, try water
            if (!working && !fluid.isBlank() && fluid.getFluid() == class_3612.field_15910) {
                if (fluidContainer.getAmount() >= WATER_CONSUME_PER_TICK) {
                    try (Transaction tx = Transaction.openOuter()) {
                        long extracted = fluidContainer.extract(fluid, WATER_CONSUME_PER_TICK, tx);
                        if (extracted == WATER_CONSUME_PER_TICK) {
                            energyContainer.getSideStorage(null).insert(WATER_EU_PER_TICK, tx);
                            tx.commit();
                            working = true;
                        }
                    }
                }
            }

            if (!working && !fluid.isBlank() && fluid.getFluid() == IndustrialElixirFluids.STILL_Hot_Spring) {
                if (fluidContainer.getAmount() >= WATER_CONSUME_PER_TICK) {
                    try (Transaction tx = Transaction.openOuter()) {
                        long extracted = fluidContainer.extract(fluid, WATER_CONSUME_PER_TICK, tx);
                        if (extracted == WATER_CONSUME_PER_TICK) {
                            energyContainer.getSideStorage(null).insert(WATER_EU_PER_TICK, tx);
                            tx.commit();
                            working = true;
                        }
                    }
                }
            }
        }

        if (state.method_11654(AbstractMachineblock.LIT) != working) {
            world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, working), 3);
        }

        method_31663(world, pos, state);
    }

    public void discharge(int slot) {
        if (this.field_11863 != null && !this.field_11863.method_8608()) {
            if (!this.getOptionalInventory().isEmpty()) {
                class_1263 inventory = this.getOptionalInventory().get();
                EnergyStorageUtil.move(
                        energyContainer.getSideStorage(null),
                        ContainerItemContext.ofSingleSlot(InventoryStorage.of(inventory, null).getSlots().get(slot)).find(EnergyStorage.ITEM),
                        Long.MAX_VALUE,
                        null
                );
            }
        }
    }

    public Optional<ImplementedInventory> getOptionalInventory() {
        if (this instanceof ImplementedInventory inventory) {
            return inventory == null ? Optional.empty() : Optional.of(inventory);
        } else {
            return Optional.empty();
        }
    }

    @Override
    protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        SingleVariantStorage.writeNbt(fluidContainer, FluidVariant.CODEC, output, registries);
    }

    @Override
    protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        super.method_11014(input, registries);
        SingleVariantStorage.readNbt(fluidContainer, FluidVariant.CODEC, FluidVariant::blank, input, registries);
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_58692(registryLookup);
    }
}
