package com.skniro.growable_ores_extension.screen.slot;

import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.api.item.TieredEnergyItem;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.registry.tag.ModItemTags;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class BatteryChargeSlot extends class_1735 {
    final EnergyTier energyTier;
    public BatteryChargeSlot(class_1263 inventory, int index, int x, int y, EnergyTier energyTier) {
        super(inventory, index, x, y);
        this.energyTier = energyTier;
    }

    public boolean method_7680(class_1799 stack) {
        if (stack.method_7909() instanceof TieredEnergyItem tiered) {return tiered.getEnergyTier().ordinal() >= this.energyTier.ordinal();
        }
        return false;
    }

    public int method_7676(class_1799 stack) {
        return isBucket(stack) ? 1 : super.method_7676(stack);
    }

    public static boolean isBucket(class_1799 stack) {
        return stack.method_31574(class_1802.field_8550);
    }
}
