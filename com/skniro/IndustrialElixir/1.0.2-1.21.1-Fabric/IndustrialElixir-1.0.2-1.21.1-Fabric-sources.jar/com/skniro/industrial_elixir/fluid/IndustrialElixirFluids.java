package com.skniro.industrial_elixir.fluid;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.Helper;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_7923;

    public class IndustrialElixirFluids {
        public static class_3609 STILL_Fluid_UU;
        public static class_3609 FLOWING_Fluid_UU;
        public static class_3609 STILL_Fluid_AIR;
        public static class_3609 FLOWING_Fluid_AIR;
        public static class_3609 STILL_Hot_Spring;
        public static class_3609 FLOWING_Hot_Spring;


        public static void registerFluids() {
            STILL_Fluid_UU = class_2378.method_10230(class_7923.field_41173,
                    class_2960.method_60655(IndustrialElixir.MOD_ID, "fluid_uu"), new IndustrialElixirFluidUUFluid.Still());

            FLOWING_Fluid_UU = class_2378.method_10230(class_7923.field_41173,
                    class_2960.method_60655(IndustrialElixir.MOD_ID, "flowing_fluid_uu"), new IndustrialElixirFluidUUFluid.Flowing());

            STILL_Fluid_AIR = class_2378.method_10230(class_7923.field_41173,
                    class_2960.method_60655(IndustrialElixir.MOD_ID, "fluid_air"), new IndustrialElixirFluidAIRFluid.Still());

            FLOWING_Fluid_AIR = class_2378.method_10230(class_7923.field_41173,
                    class_2960.method_60655(IndustrialElixir.MOD_ID, "flowing_fluid_air"), new IndustrialElixirFluidAIRFluid.Flowing());

            STILL_Hot_Spring = class_2378.method_10230(class_7923.field_41173,
                    Helper.id("hot_spring"), new MapleHotSpringFluid.Still());

            FLOWING_Hot_Spring = class_2378.method_10230(class_7923.field_41173,
                    Helper.id( "flowing_hot_spring_water"), new MapleHotSpringFluid.Flowing());
        }
    }

