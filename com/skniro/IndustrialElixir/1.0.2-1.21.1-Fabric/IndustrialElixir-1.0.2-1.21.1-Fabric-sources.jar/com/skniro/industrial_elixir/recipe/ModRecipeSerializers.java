package com.skniro.industrial_elixir.recipe;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Builds a 1.21.1 {@link class_1865} out of a codec pair. 26.1 had a
 * {@code RecipeSerializer} record that could simply be constructed; 1.21.1 has
 * it as an interface instead.
 */
public final class ModRecipeSerializers {
    private ModRecipeSerializers() {
    }

    public static <R extends class_1860<?>> class_1865<R> of(MapCodec<R> codec,
                                                              class_9139<class_9129, R> streamCodec) {
        return new class_1865<R>() {
            @Override
            public MapCodec<R> method_53736() {
                return codec;
            }

            @Override
            public class_9139<class_9129, R> method_56104() {
                return streamCodec;
            }
        };
    }
}
