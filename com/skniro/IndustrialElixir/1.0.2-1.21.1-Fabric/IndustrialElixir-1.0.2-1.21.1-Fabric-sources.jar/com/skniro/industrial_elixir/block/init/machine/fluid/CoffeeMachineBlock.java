package com.skniro.industrial_elixir.block.init.machine.fluid;

import com.mojang.serialization.MapCodec;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.entity.machine.fluid.CoffeeMachineBlockEntity;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class CoffeeMachineBlock extends AbstractMachineblock {
    public static final MapCodec<CoffeeMachineBlock> CODEC = method_54094(CoffeeMachineBlock::new);

    public CoffeeMachineBlock(class_2251 settings) {
        super(settings, EnergyTier.TIER1);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new CoffeeMachineBlockEntity(pos, state);
    }

    @Override
    public void method_9556(class_1937 level, class_1657 player, class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity, net.minecraft.class_1799 destroyedWith) {
        if (level.method_8321(pos) instanceof CoffeeMachineBlockEntity machine) {
            machine.drops();
        }
        super.method_9556(level, player, pos, state, blockEntity, destroyedWith);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos,
                                               class_1657 player, class_3965 hitResult) {
        if (!level.method_8608()) {
            class_2586 entity = level.method_8321(pos);
            if (entity instanceof CoffeeMachineBlockEntity machine) {
                player.method_17355(machine);
            }
        }
        return class_1269.field_5812;
    }

    @Override
    public @Nullable <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state,
                                                                            class_2591<T> type) {
        if (level.method_8608()) {
            return null;
        }

        return method_31618(type, AlchemyBlockEntityType.COFFEE_MACHINE_BLOCK_ENTITY_BLOCK_ENTITY_TYPE,
                (level1, pos, state1, entity) -> entity.tick(level1, pos, state1));
    }
}
