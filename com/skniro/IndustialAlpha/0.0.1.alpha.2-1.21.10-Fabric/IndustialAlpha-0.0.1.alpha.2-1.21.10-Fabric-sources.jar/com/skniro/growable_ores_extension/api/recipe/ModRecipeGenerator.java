package com.skniro.growable_ores_extension.api.recipe;

import static net.minecraft.class_5797.method_36442;

import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_2446;
import net.minecraft.class_2447;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_7871;
import net.minecraft.class_7924;
import net.minecraft.class_8790;

public class ModRecipeGenerator extends class_2446 {
    private final class_7871<class_1792> itemLookup;

    protected ModRecipeGenerator(class_7225.class_7874 registries, class_8790 exporter) {
        super(registries, exporter);
        this.itemLookup = registries.method_46762(class_7924.field_41197);
    }

    @Override
    public void method_10419() {
    }

    public MaceratorRecipeJsonBuilder createMacerator(class_1935 output, int count) {
        return MaceratorRecipeJsonBuilder.create(this.itemLookup, output, count);
    }

    public MaceratorRecipeJsonBuilder createMacerator(class_1935 output) {
        return MaceratorRecipeJsonBuilder.create(this.itemLookup, output);
    }

    public class_2447 method_62747(class_7800 category, class_1935 output, int count) {
        return class_2447.method_10436(this.itemLookup, category, output, count);
    }
}