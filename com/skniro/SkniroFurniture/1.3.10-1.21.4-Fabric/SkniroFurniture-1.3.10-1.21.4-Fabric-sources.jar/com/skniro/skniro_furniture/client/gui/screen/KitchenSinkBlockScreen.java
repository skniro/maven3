package com.skniro.skniro_furniture.client.gui.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import com.skniro.skniro_furniture.Furniture;
import com.skniro.skniro_furniture.screen.KitchenSinkBlockScreenHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

@Environment(EnvType.CLIENT)
public class KitchenSinkBlockScreen extends class_465<KitchenSinkBlockScreenHandler> {
    private static final class_2960 TEXTURE = class_2960.method_60655(Furniture.MOD_ID, "textures/gui/container/kitchen_sink.png");

    public KitchenSinkBlockScreen(KitchenSinkBlockScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, TEXTURE);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        context.method_25290(class_1921::method_62277, TEXTURE, x, y, 0, 0, field_2792, field_2779,256,256);

        renderProgressArrow(context, x, y);
    }

    private void renderProgressArrow(class_332 context, int x, int y) {
        if(field_2797.isCrafting()) {
            context.method_25290(class_1921::method_62277, TEXTURE, x + 73, y + 34, 176, 12, field_2797.getScaledProgress(),45,256,256);
        }
    }

    @Override
    public void method_25394(class_332 context , int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }
}

