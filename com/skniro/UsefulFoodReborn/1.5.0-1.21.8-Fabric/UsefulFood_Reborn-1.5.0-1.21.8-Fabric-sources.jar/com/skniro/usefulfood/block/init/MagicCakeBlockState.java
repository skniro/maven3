package com.skniro.usefulfood.block.init;

import com.skniro.usefulfood.block.init.candle.CandleMagicCakeBlock;
import net.minecraft.block.*;
import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2272;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2758;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3489;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5544;
import net.minecraft.class_5712;
import net.minecraft.class_5819;

public class MagicCakeBlockState extends SpecialCake {
    public static final int MAX_BITES = 6;
    public static final class_2758 BITES = class_2741.field_12505;
    public static final int DEFAULT_COMPARATOR_OUTPUT = class_2272.method_31627(0);
    protected static final float field_31047 = 1.0f;
    protected static final float field_31048 = 2.0f;
    protected static final class_265[] BITES_TO_SHAPE = new class_265[]{method_9541(1.0, 0.0, 1.0, 15.0, 8.0, 15.0), method_9541(3.0, 0.0, 1.0, 15.0, 8.0, 15.0), method_9541(5.0, 0.0, 1.0, 15.0, 8.0, 15.0), method_9541(7.0, 0.0, 1.0, 15.0, 8.0, 15.0), method_9541(9.0, 0.0, 1.0, 15.0, 8.0, 15.0), method_9541(11.0, 0.0, 1.0, 15.0, 8.0, 15.0), method_9541(13.0, 0.0, 1.0, 15.0, 8.0, 15.0)};

    public MagicCakeBlockState(class_2251 settings, int foodlevel, float saturation) {
        super(settings, foodlevel, saturation);
        this.method_9590((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(BITES, 0));
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return BITES_TO_SHAPE[state.method_11654(BITES)];
    }

    @Override
    public class_1269 method_55765(class_1799 itemStack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_2248 block;
        class_1792 item = itemStack.method_7909();
        if (itemStack.method_31573(class_3489.field_26989) && state.method_11654(BITES) == 0 && (block = class_2248.method_9503(item)) instanceof class_5544) {
            if (!player.method_68878()) {
                itemStack.method_7934(1);
            }
            world.method_8396(null, pos, class_3417.field_26947, class_3419.field_15245, 1.0f, 1.0f);
            world.method_8501(pos, CandleMagicCakeBlock.getCandleCakeFromCandle(block));
            world.method_33596((class_1297)player, class_5712.field_28733, pos);
            player.method_7259(class_3468.field_15372.method_14956(item));
            return class_1269.field_5812;
        } else {
            return class_1269.field_52423;
        }
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world.field_9236) {
            if (tryEat(world, pos, state, player).method_23665()) {
                return class_1269.field_5812;
            }
            if (player.method_5998(class_1268.field_5808).method_7960()) {
                return class_1269.field_21466;
            }
        }
        return tryEat(world, pos, state, player);
    }

    public static class_1269 tryEat(class_1936 world, class_2338 pos, class_2680 state, class_1657 player) {
        if (!player.method_7332(false)) {
            return class_1269.field_5811;
        }
        player.method_7281(class_3468.field_15369);
        player.method_7344().method_7585(foodlevel, saturation);
        player.method_6092(new class_1293(class_1294.field_5924,200,3));
        player.method_6092(new class_1293(class_1294.field_5907,2000,0));
        int i = state.method_11654(BITES);
        world.method_33596((class_1297)player, class_5712.field_28735, pos);
        if (i < 6) {
            world.method_8652(pos, (class_2680)state.method_11657(BITES, i + 1), field_31036);
        } else {
            world.method_8650(pos, false);
            world.method_33596((class_1297)player, class_5712.field_28165, pos);
        }
        return class_1269.field_5812;
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_4538 world, class_10225 tickView, class_2338 pos, class_2350 direction, class_2338 neighborPos, class_2680 neighborState, class_5819 random) {
        if (direction == class_2350.field_11033 && !state.method_26184(world, pos)) {
            return class_2246.field_10124.method_9564();
        }
        return super.method_9559(state ,world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        return world.method_8320(pos.method_10074()).method_51367();
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(BITES);
    }

    @Override
    public int method_9572(class_2680 state, class_1937 world, class_2338 pos) {
        return class_2272.method_31627(state.method_11654(BITES));
    }

    public static int getComparatorOutput(int bites) {
        return (7 - bites) * 2;
    }

    @Override
    public boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    public boolean method_9516(class_2680 state, class_10 type) {
        return false;
    }
}
