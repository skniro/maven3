package com.skniro.growable_ores_extension;


import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.MapleSignBlocks;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.entity.AlchemyBlockEntityType;
import com.skniro.growable_ores_extension.entity.MapleEntityType;
import com.skniro.growable_ores_extension.item.AdvancedItems;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.item.MapleArmorItems;
import com.skniro.growable_ores_extension.item.ModCreativeTab;
import com.skniro.growable_ores_extension.item.init.equipment.MapleEquipmentAssetKeys;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import com.skniro.growable_ores_extension.screen.AlchemyScreenHandlerType;
import com.skniro.growable_ores_extension.util.ModFuel;
import com.skniro.growable_ores_extension.world.gen.ModOreGeneration;
import com.skniro.growable_ores_extension.world.gen.ModTreeGeneration;

import java.util.Locale;


public class ModContent {


    public static void registerItem() {
        GrowableOresItems.shield_item();
        AdvancedItems.registerAdvancedItem();
        MapleArmorItems.registerMapleArmorItems();
        MapleEquipmentAssetKeys.registerMapleArmorAssetsKeys();
        ModFuel.registerFuel();
    }

    public static void registerBlock() {
        GrowableOresBlocks.registerGrowableOresBlocks();
        AlchemyRecipeType.registerRecipes();
        AlchemyBlockEntityType.registerMapleBlockEntityType();
        AlchemyBlockEntityType.registerMachineEnergyEntity();
        AlchemyScreenHandlerType.registeralchemyscreenhandlertype();
        GeneralBlocks.registerNetherOresBlock();
        MapleSignBlocks.registerMapleSignBlocks();
    }

    public static void CreativeTab() {
        ModCreativeTab.CreativeTab();
        ModCreativeTab.CreativeTabItem();
    }

    public static void registerEntity() {
        MapleEntityType.registerMapleEntityType();
    }

    public static void WorldGen() {
        ModOreGeneration.generateOres();
        ModTreeGeneration.generateTrees();
    }


    public enum Cables {
        COPPER(128, 12.0F, true, EnergyTier.TIER2),
        TIN(32, 12.0F, true, EnergyTier.TIER1),
        GOLD(512, 12.0F, true, EnergyTier.TIER3),
        HV(2048, 12.0F, true, EnergyTier.TIER4),
        GLASSFIBER(8192, 12.0F, false, EnergyTier.TIER5),
        INSULATED_TIN(32, 12.0F, false, EnergyTier.TIER1),
        INSULATED_COPPER(128, 10.0F, false, EnergyTier.TIER2),
        INSULATED_GOLD(512, 10.0F, false, EnergyTier.TIER3),
        INSULATED_HV(2048, 10.0F, false, EnergyTier.TIER4),
        SUPERCONDUCTOR(536870911, 10.0F, false, EnergyTier.INFINITE);

        public final String name;
        public final int transferRate;
        public final int defaultTransferRate;
        public final double cableThickness;
        public final boolean canKill;
        public final boolean defaultCanKill;
        public final EnergyTier tier;

        private Cables(int transferRate, double cableThickness, boolean canKill, EnergyTier tier) {
            this.name = this.toString().toLowerCase(Locale.ROOT);
            this.transferRate = transferRate;
            this.defaultTransferRate = transferRate;
            this.cableThickness = cableThickness / 2.0 / 16.0;
            this.canKill = canKill;
            this.defaultCanKill = canKill;
            this.tier = tier;
        }
    }
}
