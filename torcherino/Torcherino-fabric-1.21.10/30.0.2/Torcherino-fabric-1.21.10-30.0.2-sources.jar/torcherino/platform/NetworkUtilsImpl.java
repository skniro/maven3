package torcherino.platform;

import com.google.common.base.Suppliers;
import com.google.common.collect.ImmutableMap;
import io.netty.buffer.Unpooled;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import torcherino.Torcherino;
import torcherino.TorcherinoImpl;
import torcherino.api.Tier;
import torcherino.api.TorcherinoAPI;
import torcherino.block.entity.TorcherinoBlockEntity;
import torcherino.client.screen.TorcherinoScreen;
import torcherino.config.Config;
import torcherino.platform.payload.OpenTorchrinoScreenPayload;
import torcherino.platform.payload.TorchrinoTierPayload;
import torcherino.platform.payload.UpdateTorchrinoPayload;

import java.util.HashSet;
import java.util.function.Supplier;

public class NetworkUtilsImpl implements NetworkUtils {
    private static final Supplier<NetworkUtilsImpl> instance = Suppliers.memoize(NetworkUtilsImpl::new);

    private final HashSet<String> allowedUuids = new HashSet<>();

    public static NetworkUtilsImpl getInstance() {
        return instance.get();
    }

    @Override
    public void c2s_updateTorcherinoValues(class_2338 pos, int xRange, int zRange, int yRange, int speed, int redstoneMode) {
        if (ClientPlayNetworking.canSend(UpdateTorchrinoPayload.TYPE)) {
            ClientPlayNetworking.send(new UpdateTorchrinoPayload(pos, xRange, zRange, yRange, speed, redstoneMode));
        }
    }

    @Override
    public void s2c_openTorcherinoScreen(class_3222 player, class_2338 pos, class_2561 name, int xRange, int zRange, int yRange, int speed, int redstoneMode) {
        if (ServerPlayNetworking.canSend(player, OpenTorchrinoScreenPayload.TYPE)) {
            class_2540 buffer = new class_2540(Unpooled.buffer());
            ServerPlayNetworking.send(player, new OpenTorchrinoScreenPayload(pos, name.getString(), xRange, zRange, yRange, speed, redstoneMode, buffer));
        }
    }


    public void initialize() {
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            ClientNetworking.initialize();
        }
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.field_14140;
            allowedUuids.add(player.method_5845());
            ImmutableMap<class_2960, Tier> tiers = TorcherinoAPI.INSTANCE.getTiers();
            sender.sendPacket(new TorchrinoTierPayload(tiers));
            Torcherino.LOGGER.info(tiers);
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            if (Config.INSTANCE.online_mode.equals("ONLINE")) {
                allowedUuids.remove(handler.field_14140.method_5845());
            }
        });

        ServerPlayConnectionEvents.INIT.register((handler, server) -> {
            ServerPlayNetworking.registerReceiver(handler, UpdateTorchrinoPayload.TYPE, (payload, context) -> {
                class_1937 level = context.player().method_51469();
                context.server().execute(() -> {
                    if (level.method_8321(payload.blockPos()) instanceof TorcherinoBlockEntity blockEntity) {
                        if(!blockEntity.readClientData(payload.xRange(), payload.zRange(), payload.yRange(), payload.speed(), payload.redstoneMode())) {
                            Torcherino.LOGGER.error("Data received from " + context.player().method_5477().getString() + "(" + context.player().method_5845() + ") is invalid.");
                        }
                    }
                });
            });
        });
    }

    @Override
    public boolean s_isPlayerOnline(String uuid) {
        return allowedUuids.contains(uuid);
    }

    private static class ClientNetworking {
        private static void initialize() {
            ClientPlayConnectionEvents.INIT.register((handler, client) -> {
                ClientPlayNetworking.registerReceiver(OpenTorchrinoScreenPayload.TYPE, (payload, context) -> {
                    class_1937 world = class_310.method_1551().field_1687;
                    class_2338 pos = payload.blockPos();
                    String title = payload.title();
                    int xRange = payload.xRange();
                    int zRange = payload.zRange();
                    int yRange = payload.yRange();
                    int speed = payload.speed();
                    int redstoneMode = payload.redstoneMode();
                    payload.retain();
                    context.client().execute(() -> {
                        if (world.method_8321(pos) instanceof TorcherinoBlockEntity blockEntity) {
                            Torcherino.LOGGER.info(blockEntity.getTier());
                            class_310.method_1551().method_1507(new TorcherinoScreen(class_2561.method_43471(title), xRange, zRange, yRange, speed, redstoneMode, pos, blockEntity.getTier()));
                        }
                        payload.release();
                    });
                });

                ClientPlayNetworking.registerReceiver(TorchrinoTierPayload.TYPE, (payload, context) -> {
                    context.client().execute(() -> ((TorcherinoImpl) TorcherinoAPI.INSTANCE).setRemoteTiers(payload.tiers()));
                });
            });
        }
    }
}
