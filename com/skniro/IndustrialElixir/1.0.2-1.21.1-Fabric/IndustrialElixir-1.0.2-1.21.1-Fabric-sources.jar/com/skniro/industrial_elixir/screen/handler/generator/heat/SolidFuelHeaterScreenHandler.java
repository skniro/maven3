package com.skniro.industrial_elixir.screen.handler.generator.heat;

import com.skniro.industrial_elixir.block.entity.generator.heat.SolidFuelHeaterEntity;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.screen.AlchemyScreenHandlerType;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1719;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_3532;
import net.minecraft.class_3913;
import net.minecraft.class_3919;
import net.minecraft.world.inventory.*;

public class SolidFuelHeaterScreenHandler extends class_1703 {
    private final class_1263 inventory;
    public final SolidFuelHeaterEntity blockEntity;
    final class_3913 propertyDelegate;

    public SolidFuelHeaterScreenHandler(int syncId, class_1661 playerInventory, class_2338 pos) {
        this(syncId, playerInventory, playerInventory.field_7546.method_37908().method_8321(pos), new class_3919(2));
    }

    public SolidFuelHeaterScreenHandler(int syncId, class_1661 playerInventory, class_2586 entity, class_3913 delegate) {
        super(AlchemyScreenHandlerType.SolidFuelHeater, syncId);
        blockEntity = (SolidFuelHeaterEntity) entity;
        method_17359(blockEntity, 12);
        this.propertyDelegate = delegate;
        this.inventory = blockEntity;
        inventory.method_5435(playerInventory.field_7546);

        // Fuel slot
        this.method_7621(new class_1735(inventory, 1, 80, 35));
        // Ash output slot
        this.method_7621(new class_1719(playerInventory.field_7546, inventory, 2, 117, 35));

        addPlayerInventory(playerInventory);
        addPlayerHotbar(playerInventory);
        method_17360(propertyDelegate);
    }

    public float getFuelProgress() {
        int i = this.propertyDelegate.method_17390(1);
        if (i == 0) {
            i = 200;
        }
        return class_3532.method_15363((float)this.propertyDelegate.method_17390(0) / (float)i, 0.0f, 1.0f);
    }

    public class_2561 getHeatTooltips() {
        return class_2561.method_43470(blockEntity.heatContainer.amount + " / " + blockEntity.getHeatCapacity() + " H");
    }

    public boolean isBurning() {
        return propertyDelegate.method_17390(0) > 0;
    }

    public int getScaledBurnProgress() {
        int burnTime = propertyDelegate.method_17390(0);
        int burnDuration = propertyDelegate.method_17390(1);
        if (burnDuration == 0) return 0;
        return burnTime * 13 / burnDuration;
    }

    public int getScaledHeatHeight() {
        long heat = blockEntity.heatContainer.amount;
        long capacity = blockEntity.getHeatCapacity();
        int barHeight = 50;
        return Math.toIntExact(heat != 0 ? heat * barHeight / capacity : 0);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int invSlot) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(invSlot);
        if (slot != null && slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();
            if (invSlot < this.inventory.method_5439()) {
                if (!this.method_7616(originalStack, this.inventory.method_5439(), this.field_7761.size(), true)) {
                    return class_1799.field_8037;
                }
            } else if (!this.method_7616(originalStack, 0, this.inventory.method_5439(), false)) {
                return class_1799.field_8037;
            }
            if (originalStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }
        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return this.inventory.method_5443(player);
    }

    private void addPlayerInventory(class_1661 playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.method_7621(new class_1735(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }
    }

    private void addPlayerHotbar(class_1661 playerInventory) {
        for (int i = 0; i < 9; ++i) {
            this.method_7621(new class_1735(playerInventory, i, 8 + i * 18, 142));
        }
    }
}
