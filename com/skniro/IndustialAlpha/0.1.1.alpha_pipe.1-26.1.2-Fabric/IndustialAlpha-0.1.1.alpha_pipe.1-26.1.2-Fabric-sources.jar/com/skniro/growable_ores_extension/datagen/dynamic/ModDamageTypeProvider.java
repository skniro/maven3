package com.skniro.growable_ores_extension.datagen.dynamic;

import com.skniro.growable_ores_extension.init.ModDamageTypes;
import net.fabricmc.fabric.api.datagen.v1.FabricPackOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.world.damagesource.DamageEffects;
import net.minecraft.world.damagesource.DamageType;
import java.util.concurrent.CompletableFuture;

public class ModDamageTypeProvider{

    public static void damageTypes(BootstrapContext<DamageType> context) {
        context.register(ModDamageTypes.ELECTRIC_SHOCK, new DamageType("electric_shock", 0.1F, DamageEffects.BURNING));
        context.register(ModDamageTypes.FUSION, new DamageType("fusion", 0.1F, DamageEffects.BURNING));
    }
}