package com.skniro.industrial_elixir.api;

import com.skniro.industrial_elixir.IndustrialElixir;
import net.minecraft.class_2960;

public class Helper {

    public static class_2960 id(String path) {
        return class_2960.method_60655(IndustrialElixir.MOD_ID, path);
    }
}
