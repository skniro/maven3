package com.skniro.maple.block;

import com.skniro.maple.Maple;
import com.skniro.maple.block.entity.MapleSignTypes;
import com.skniro.maple.block.init.*;
import com.skniro.maple.world.Tree.*;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2362;
import net.minecraft.class_2378;
import net.minecraft.class_2380;
import net.minecraft.class_2397;
import net.minecraft.class_2440;
import net.minecraft.class_2465;
import net.minecraft.class_2473;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4719;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7714;
import net.minecraft.class_7923;
import net.minecraft.class_8167;
import net.minecraft.class_8169;
import net.minecraft.class_8177;

public class MapleBlocks {
    //LOG_Block
    public static final class_2248 MAPLE_LOG = registerBlock("maple_log",new class_2465(FabricBlockSettings.method_9630(class_2246.field_10431).method_31710(class_3620.field_15977)), Maple.Maple_Group);
    public static final class_2248 STRIPPED_MAPLE_LOG = registerBlock("stripped_maple_log",
            new class_2465(FabricBlockSettings.method_9630(class_2246.field_10519).method_31710(class_3620.field_15977)), Maple.Maple_Group);
    public static final class_2248 STRIPPED_MAPLE_WOOD = registerBlock("stripped_maple_wood",
            new class_2465(FabricBlockSettings.method_9630(class_2246.field_10250).method_31710(class_3620.field_15977)), Maple.Maple_Group);
    public static final class_2248 MAPLE_WOOD = registerBlock("maple_wood",
            new class_2465(FabricBlockSettings.method_9630(class_2246.field_10126).method_31710(class_3620.field_15977)), Maple.Maple_Group);

    public static final class_2248 GINKGO_LOG = registerBlock("ginkgo_log",new class_2465(FabricBlockSettings.method_9630(class_2246.field_10431).method_31710(class_3620.field_15986)), Maple.Maple_Group);
    public static final class_2248 STRIPPED_GINKGO_LOG = registerBlock("stripped_ginkgo_log",
            new class_2465(FabricBlockSettings.method_9630(class_2246.field_10519).method_31710(class_3620.field_15986)), Maple.Maple_Group);
    public static final class_2248 STRIPPED_GINKGO_WOOD = registerBlock("stripped_ginkgo_wood",
            new class_2465(FabricBlockSettings.method_9630(class_2246.field_10250).method_31710(class_3620.field_15986)), Maple.Maple_Group);
    public static final class_2248 GINKGO_WOOD = registerBlock("ginkgo_wood",
            new class_2465(FabricBlockSettings.method_9630(class_2246.field_10126).method_31710(class_3620.field_15986)), Maple.Maple_Group);


    public static final class_2248 CHERRY_LOG = registerBlock("cherry_log",new class_2465(FabricBlockSettings.method_9630(class_2246.field_10431)), Maple.Maple_Group);
    public static final class_2248 CHERRY_WOOD = registerBlock("cherry_wood",
            new class_2465(FabricBlockSettings.method_9630(class_2246.field_10126)), Maple.Maple_Group);
    public static final class_2248 STRIPPED_CHERRY_LOG = registerBlock("stripped_cherry_log",
            new class_2465(FabricBlockSettings.method_9630(class_2246.field_10519)), Maple.Maple_Group);
    public static final class_2248 STRIPPED_CHERRY_WOOD = registerBlock("stripped_cherry_wood",
            new class_2465(FabricBlockSettings.method_9630(class_2246.field_10250)), Maple.Maple_Group);

    public static final class_2248 BAMBOO_BLOCK = registerBlock("bamboo_block", createBambooBlock(class_3620.field_16010, class_3620.field_16004, class_2498.field_11547), Maple.Maple_Group);
    public static final class_2248 STRIPPED_BAMBOO_BLOCK = registerBlock("stripped_bamboo_block", createBambooBlock(class_3620.field_16010, class_3620.field_16010, class_2498.field_11547), Maple.Maple_Group);




    //SAPLING Block
    public static final class_2248 MAPLE_SAPLING = registerBlock("maple_sapling",new class_2473(MapleSaplingGenerator.MapleSapling,FabricBlockSettings.copyOf(class_2246.field_10394)), Maple.Maple_Group);
    public static final class_2248 RED_MAPLE_SAPLING = registerBlock("red_maple_sapling",new class_2473(RedMapleSaplingGenerator.RedMapleSapling,FabricBlockSettings.copyOf(class_2246.field_10394)), Maple.Maple_Group);
    public static final class_2248 GINKGO_SAPLING = registerBlock("ginkgo_sapling",new class_2473(GinkgoSaplingGenerator.GinkgoSapling,FabricBlockSettings.copyOf(class_2246.field_10394)), Maple.Maple_Group);
    public static final class_2248 CHERRY_SAPLING = registerBlock("cherry_sapling",new class_2473(CherrySaplingGenerator.CherrySapling,FabricBlockSettings.copyOf(class_2246.field_10394)), Maple.Maple_Group);
    public static final class_2248 SAKURA_SAPLING = registerBlock("sakura_sapling",new class_2473(SakuraSaplingGenerator.SakuraSapling,FabricBlockSettings.copyOf(class_2246.field_10394)), Maple.Maple_Group);

    //LEAVES Block
    public static final class_2248 MAPLE_LEAVES = registerBlock("maple_leaves",
            new class_2397(FabricBlockSettings.method_9630(class_2246.field_10503).method_31710(class_3620.field_16013)), Maple.Maple_Group);
    public static final class_2248 RED_MAPLE_LEAVES = registerBlock("red_maple_leaves",
            new class_2397(FabricBlockSettings.method_9630(class_2246.field_10503).method_31710(class_3620.field_16020)), Maple.Maple_Group);

    public static final class_2248 GINKGO_LEAVES = registerBlock("ginkgo_leaves",
            new class_2397(FabricBlockSettings.method_9630(class_2246.field_10503).method_31710(class_3620.field_16013)), Maple.Maple_Group);
    public static final class_2248 CHERRY_LEAVES = registerBlock("cherry_leaves",
            new class_8167(FabricBlockSettings.method_9630(class_2246.field_10503).method_31710(class_3620.field_16030)), Maple.Maple_Group);
    public static final class_2248 SAKURA_LEAVES = registerBlock("sakura_leaves",
            new MapleSakuraLeavesBlock(FabricBlockSettings.method_9630(class_2246.field_10503).method_31710(class_3620.field_16030).method_9631((state) -> 8)), Maple.Maple_Group);

    //PLANKS Block
    public static final class_2248 MAPLE_PLANKS = registerBlock("maple_planks",
            new class_2248(FabricBlockSettings.method_9630(class_2246.field_10161).method_31710(class_3620.field_15977)), Maple.Maple_Group);
    public static final class_2248 CHERRY_PLANKS = registerBlock("cherry_planks",
            new class_2248(FabricBlockSettings.method_9630(class_2246.field_10161).method_31710(class_3620.field_16030)), Maple.Maple_Group);
    public static final class_2248 GINKGO_PLANKS = registerBlock("ginkgo_planks",
            new class_2248(FabricBlockSettings.method_9630(class_2246.field_10161).method_31710(class_3620.field_16013)), Maple.Maple_Group);
    public static final class_2248 BAMBOO_PLANKS = registerBlock("bamboo_planks",
            new class_2248(class_4970.class_2251.method_9637().method_31710(class_3620.field_16010).method_9629(2.0f, 3.0f).method_9626(class_2498.field_11547)),Maple.Maple_Group);
    public static final class_2248 BAMBOO_MOSAIC = registerBlock("bamboo_mosaic",
            new class_2248(class_4970.class_2251.method_9637().method_31710(class_3620.field_16010).method_9629(2.0f, 3.0f).method_9626(class_2498.field_11547)),Maple.Maple_Group);

    //Potted
    public static final class_2248 POTTED_GINKGO_SAPLING = registerBlockWithoutItem("potted_ginkgo_sapling",
            new class_2362(GINKGO_SAPLING, class_4970.class_2251.method_9637().method_9618().method_22488()));
    public static final class_2248 POTTED_CHERRY_SAPLING = registerBlockWithoutItem("potted_cherry_sapling",
            new class_2362(CHERRY_SAPLING, class_4970.class_2251.method_9637().method_9618().method_22488()));
    public static final class_2248 POTTED_MAPLE_SAPLING = registerBlockWithoutItem("potted_maple_sapling",
            new class_2362(MAPLE_SAPLING, class_4970.class_2251.method_9637().method_9618().method_22488()));

    public static final class_2248 POTTED_RED_MAPLE_SAPLING = registerBlockWithoutItem("potted_red_maple_sapling",
            new class_2362(RED_MAPLE_SAPLING, class_4970.class_2251.method_9637().method_9618().method_22488()));
    public static final class_2248 POTTED_SAKURA_SAPLING = registerBlockWithoutItem("potted_sakura_sapling",
            new class_2362(SAKURA_SAPLING, class_4970.class_2251.method_9637().method_9618().method_22488()));


    //BUTTON
    public static final class_2248 GINKGO_BUTTON = registerBlock("ginkgo_button",
            class_2246.method_45451(MapleBlockSetType.GINKGO), Maple.Maple_Group);
    public static final class_2248 CHERRY_BUTTON = registerBlock("cherry_button",
            class_2246.method_45451(class_8177.field_42827), Maple.Maple_Group);
    public static final class_2248 MAPLE_BUTTON = registerBlock("maple_button",
            class_2246.method_45451(MapleBlockSetType.MAPLE), Maple.Maple_Group);
    public static final class_2248 BAMBOO_BUTTON = registerBlock("bamboo_button",
            class_2246.method_45451(class_8177.field_42833), Maple.Maple_Group);


    //STAIRS
    public static final class_2248 GINKGO_STAIRS = registerBlock("ginkgo_stairs",
            new class_2510(GINKGO_PLANKS.method_9564(), class_4970.class_2251.method_9630(GINKGO_PLANKS)), Maple.Maple_Group);
    public static final class_2248 CHERRY_STAIRS = registerBlock("cherry_stairs",
            new class_2510(CHERRY_PLANKS.method_9564(), class_4970.class_2251.method_9630(CHERRY_PLANKS)), Maple.Maple_Group);
    public static final class_2248 MAPLE_STAIRS = registerBlock("maple_stairs",
            new class_2510(CHERRY_PLANKS.method_9564(), class_4970.class_2251.method_9630(CHERRY_PLANKS)), Maple.Maple_Group);
    public static final class_2248 BAMBOO_STAIRS = registerBlock("bamboo_stairs",
            new class_2510(BAMBOO_PLANKS.method_9564(), class_4970.class_2251.method_9630(BAMBOO_PLANKS)), Maple.Maple_Group);
    public static final class_2248 BAMBOO_MOSAIC_STAIRS = registerBlock("bamboo_mosaic_stairs",
            new class_2510(BAMBOO_MOSAIC.method_9564(), class_4970.class_2251.method_9630(BAMBOO_MOSAIC)), Maple.Maple_Group);


   //SLAB
   public static final class_2248 GINKGO_SLAB = registerBlock("ginkgo_slab",
           new class_2482(class_4970.class_2251.method_9637().method_31710(class_3620.field_16013).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547)), Maple.Maple_Group);
    public static final class_2248 CHERRY_SLAB = registerBlock("cherry_slab",
            new class_2482(class_4970.class_2251.method_9637().method_31710(class_3620.field_15989).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547)), Maple.Maple_Group);
    public static final class_2248 MAPLE_SLAB = registerBlock("maple_slab",
            new class_2482(class_4970.class_2251.method_9637().method_31710(class_3620.field_15992).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547)), Maple.Maple_Group);
    public static final class_2248 BAMBOO_SLAB = registerBlock("bamboo_slab",
            new class_2482(class_4970.class_2251.method_9637().method_31710(class_3620.field_16010).method_9629(2.0f, 3.0f).method_9626(class_2498.field_11547)), Maple.Maple_Group);
    public static final class_2248 BAMBOO_MOSAIC_SLAB = registerBlock("bamboo_mosaic_slab",
            new class_2482(class_4970.class_2251.method_9637().method_31710(class_3620.field_16010).method_9629(2.0f, 3.0f).method_9626(class_2498.field_11547)), Maple.Maple_Group);

    //FENCE
    public static final class_2248 GINKGO_FENCE_GATE = registerBlock("ginkgo_fence_gate",
            new class_2349(MapleSignTypes.GINKGO, class_4970.class_2251.method_9637().method_31710(GINKGO_PLANKS.method_26403()).method_9629(2.0F, 3.0F)), Maple.Maple_Group);
    public static final class_2248 GINKGO_FENCE = registerBlock("ginkgo_fence",
            new class_2354(class_4970.class_2251.method_9637().method_31710(GINKGO_PLANKS.method_26403()).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547)), Maple.Maple_Group);
    public static final class_2248 CHERRY_FENCE_GATE = registerBlock("cherry_fence_gate",
            new class_2349(class_4719.field_42837, class_4970.class_2251.method_9637().method_31710(CHERRY_PLANKS.method_26403()).method_9629(2.0F, 3.0F)), Maple.Maple_Group);
    public static final class_2248 CHERRY_FENCE = registerBlock("cherry_fence",
            new class_2354(class_4970.class_2251.method_9637().method_31710(CHERRY_PLANKS.method_26403()).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547)), Maple.Maple_Group);
    public static final class_2248 MAPLE_FENCE_GATE = registerBlock("maple_fence_gate",
            new class_2349(MapleSignTypes.MAPLE, class_4970.class_2251.method_9637().method_31710(MAPLE_PLANKS.method_26403()).method_9629(2.0F, 3.0F)), Maple.Maple_Group);
    public static final class_2248 MAPLE_FENCE = registerBlock("maple_fence",
            new class_2354(class_4970.class_2251.method_9637().method_31710(MAPLE_PLANKS.method_26403()).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547)), Maple.Maple_Group);
    public static final class_2248 BAMBOO_FENCE_GATE = registerBlock("bamboo_fence_gate",
            new class_2349(class_4719.field_40350, class_4970.class_2251.method_9637().method_31710(BAMBOO_PLANKS.method_26403()).method_9629(2.0f, 3.0f)), Maple.Maple_Group);
    public static final class_2248 BAMBOO_FENCE = registerBlock("bamboo_fence",
            new class_2354(class_4970.class_2251.method_9637().method_31710(BAMBOO_PLANKS.method_26403()).method_9629(2.0f, 3.0f).method_9626(class_2498.field_11547)), Maple.Maple_Group);


    //Door
    public static final class_2248 GINKGO_DOOR = registerBlockWithoutItem("ginkgo_door",
            new class_2323(MapleBlockSetType.GINKGO, class_4970.class_2251.method_9637().method_31710(GINKGO_PLANKS.method_26403()).method_9632(3.0f).method_9626(class_2498.field_11547).method_22488()));
    public static final class_2248 MAPLE_DOOR = registerBlockWithoutItem("maple_door",
            new class_2323(class_8177.field_42827, class_4970.class_2251.method_9637().method_31710(MAPLE_PLANKS.method_26403()).method_9632(3.0f).method_9626(class_2498.field_11547).method_22488()));
    public static final class_2248 CHERRY_DOOR = registerBlockWithoutItem("cherry_door",
            new class_2323(MapleBlockSetType.MAPLE, class_4970.class_2251.method_9637().method_31710(CHERRY_PLANKS.method_26403()).method_9632(3.0f).method_9626(class_2498.field_11547).method_22488()));
    public static final class_2248 BAMBOO_DOOR = registerBlockWithoutItem("bamboo_door",
            new class_2323(class_8177.field_42833, class_4970.class_2251.method_9637().method_31710(BAMBOO_PLANKS.method_26403()).method_9632(3.0f).method_9626(class_2498.field_11547).method_22488()));

    //TRAPDOOR
    public static final class_2248 GINKGO_TRAPDOOR = registerBlock("ginkgo_trapdoor",
            new class_2533(MapleBlockSetType.GINKGO, class_4970.class_2251.method_9637().method_31710(class_3620.field_16013).method_9632(3.0F).method_22488()), Maple.Maple_Group);
    public static final class_2248 CHERRY_TRAPDOOR = registerBlock("cherry_trapdoor",
            new class_2533(class_8177.field_42827, class_4970.class_2251.method_9637().method_31710(class_3620.field_15989).method_9632(3.0F).method_22488()), Maple.Maple_Group);
    public static final class_2248 MAPLE_TRAPDOOR = registerBlock("maple_trapdoor",
            new class_2533(MapleBlockSetType.MAPLE, class_4970.class_2251.method_9637().method_31710(class_3620.field_15992).method_9632(3.0F).method_22488()), Maple.Maple_Group);
    public static final class_2248 BAMBOO_TRAPDOOR = registerBlock("bamboo_trapdoor",
            new class_2533(class_8177.field_42833, class_4970.class_2251.method_9637().method_31710(class_3620.field_16010).method_9632(3.0f).method_22488()), Maple.Maple_Group);


    //PRESSURE_PLATE
    public static final class_2248 GINKGO_PRESSURE_PLATE = registerBlock("ginkgo_pressure_plate",
            new class_2440(MapleBlockSetType.GINKGO, class_4970.class_2251.method_9637().method_31710(MapleBlocks.GINKGO_PLANKS.method_26403()).method_9634().method_9632(0.5F).method_50013().method_51368(class_2766.field_12651).method_50012(class_3619.field_15971)), Maple.Maple_Group);
    public static final class_2248 CHERRY_PRESSURE_PLATE = registerBlock("cherry_pressure_plate",
            new class_2440(class_8177.field_42827, class_4970.class_2251.method_9637().method_31710(MapleBlocks.CHERRY_PLANKS.method_26403()).method_9634().method_9632(0.5F).method_50013().method_51368(class_2766.field_12651).method_50012(class_3619.field_15971)), Maple.Maple_Group);
    public static final class_2248 MAPLE_PRESSURE_PLATE = registerBlock("maple_pressure_plate",
            new class_2440(MapleBlockSetType.MAPLE, class_4970.class_2251.method_9637().method_31710(MapleBlocks.MAPLE_PLANKS.method_26403()).method_9634().method_9632(0.5F).method_50013().method_51368(class_2766.field_12651).method_50012(class_3619.field_15971)), Maple.Maple_Group);
    public static final class_2248 BAMBOO_PRESSURE_PLATE = registerBlock("bamboo_pressure_plate",
            new class_2440(class_8177.field_42833, class_4970.class_2251.method_9637().method_31710(MapleBlocks.BAMBOO_PLANKS.method_26403()).method_9634().method_9632(0.5f).method_50013().method_51368(class_2766.field_12651).method_50012(class_3619.field_15971)), Maple.Maple_Group);
    //Plants Block
    public static final class_2248 RICE = registerBlockWithoutItem("rice_plant",new RiceBlock(class_4970.class_2251.method_9637().method_9634().method_9640().method_9618().method_9626(class_2498.field_17580)));

    //FlowerBlock
    public static final class_2248 PINK_PETALS = registerBlock("pink_petals", new class_8169(class_4970.class_2251.method_9637().method_31710(class_3620.field_16030).method_9634().method_9626(class_2498.field_11535)),Maple.Maple_Group);


    public static final class_2248 CHISELED_BOOKSHELF = registerBlock("chiseled_bookshelf", new class_7714(class_4970.class_2251.method_9637().method_31710(class_3620.field_15996).method_9632(1.5F).method_9626(class_2498.field_11547)),Maple.Maple_Group);

    public static final class_2248 SAKURA_CARPET = registerBlock("sakura_carpet", new MapleCarpetBlock(class_4970.class_2251.method_9630(class_2246.field_42750).method_31710(class_3620.field_16030)),Maple.Maple_Group);
    public static final class_2248 Maple_CARPET = registerBlock("maple_carpet", new MapleCarpetBlock(class_4970.class_2251.method_9630(class_2246.field_42750).method_31710(class_3620.field_16013)),Maple.Maple_Group);
    public static final class_2248 RED_MAPLE_CARPET = registerBlock("red_maple_carpet",new MapleCarpetBlock(class_4970.class_2251.method_9630(class_2246.field_42750).method_31710(class_3620.field_16020)),Maple.Maple_Group);
    public static final class_2248 GINKGO_CARPET= registerBlock("ginkgo_carpet",new MapleCarpetBlock(class_4970.class_2251.method_9630(class_2246.field_42750).method_31710(class_3620.field_16013)),Maple.Maple_Group);

    //Glass Blocks
    public static final class_2248 WHITE_STAINED_GLASS_SLAB = registerBlock("white_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10087)), Maple.Maple_Group);
    public static final class_2248 WHITE_STAINED_GLASS_STAIRS = registerBlock("white_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10087.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10087)), Maple.Maple_Group);
    public static final class_2248 ORANGE_STAINED_GLASS_SLAB = registerBlock("orange_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10227)), Maple.Maple_Group);
    public static final class_2248 ORANGE_STAINED_GLASS_STAIRS = registerBlock("orange_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10227.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10227)), Maple.Maple_Group);
    public static final class_2248 MAGENTA_STAINED_GLASS_SLAB = registerBlock("magenta_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10574)), Maple.Maple_Group);
    public static final class_2248 MAGENTA_STAINED_GLASS_STAIRS = registerBlock("magenta_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10574.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10574)), Maple.Maple_Group);
    public static final class_2248 LIGHT_BLUE_STAINED_GLASS_SLAB = registerBlock("light_blue_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10271)), Maple.Maple_Group);
    public static final class_2248 LIGHT_BLUE_STAINED_GLASS_STAIRS = registerBlock("light_blue_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10271.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10271)), Maple.Maple_Group);
    public static final class_2248 YELLOW_STAINED_GLASS_SLAB = registerBlock("yellow_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10049)), Maple.Maple_Group);
    public static final class_2248 YELLOW_STAINED_GLASS_STAIRS = registerBlock("yellow_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10049.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10049)), Maple.Maple_Group);
    public static final class_2248 LIME_STAINED_GLASS_SLAB = registerBlock("lime_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10157)), Maple.Maple_Group);
    public static final class_2248 LIME_STAINED_GLASS_STAIRS = registerBlock("lime_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10157.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10157)), Maple.Maple_Group);
    public static final class_2248 PINK_STAINED_GLASS_SLAB = registerBlock("pink_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10317)), Maple.Maple_Group);
    public static final class_2248 PINK_STAINED_GLASS_STAIRS = registerBlock("pink_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10317.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10317)), Maple.Maple_Group);
    public static final class_2248 GRAY_STAINED_GLASS_SLAB = registerBlock("gray_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10555)), Maple.Maple_Group);
    public static final class_2248 GRAY_STAINED_GLASS_STAIRS = registerBlock("gray_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10555.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10555)), Maple.Maple_Group);
    public static final class_2248 LIGHT_GRAY_STAINED_GLASS_SLAB = registerBlock("light_gray_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_9996)), Maple.Maple_Group);
    public static final class_2248 LIGHT_GRAY_STAINED_GLASS_STAIRS = registerBlock("light_gray_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_9996.method_9564(), class_4970.class_2251.method_9630(class_2246.field_9996)), Maple.Maple_Group);
    public static final class_2248 CYAN_STAINED_GLASS_SLAB = registerBlock("cyan_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10248)), Maple.Maple_Group);
    public static final class_2248 CYAN_STAINED_GLASS_STAIRS = registerBlock("cyan_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10248.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10248)), Maple.Maple_Group);
    public static final class_2248 PURPLE_STAINED_GLASS_SLAB = registerBlock("purple_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10399)), Maple.Maple_Group);
    public static final class_2248 PURPLE_STAINED_GLASS_STAIRS = registerBlock("purple_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10399.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10399)), Maple.Maple_Group);
    public static final class_2248 BLUE_STAINED_GLASS_SLAB = registerBlock("blue_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10060)), Maple.Maple_Group);
    public static final class_2248 BLUE_STAINED_GLASS_STAIRS = registerBlock("blue_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10060.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10060)), Maple.Maple_Group);
    public static final class_2248 BROWN_STAINED_GLASS_SLAB = registerBlock("brown_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10073)), Maple.Maple_Group);
    public static final class_2248 BROWN_STAINED_GLASS_STAIRS = registerBlock("brown_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10073.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10073)), Maple.Maple_Group);
    public static final class_2248 GREEN_STAINED_GLASS_SLAB = registerBlock("green_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10357)), Maple.Maple_Group);
    public static final class_2248 GREEN_STAINED_GLASS_STAIRS = registerBlock("green_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10357.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10357)), Maple.Maple_Group);
    public static final class_2248 RED_STAINED_GLASS_SLAB = registerBlock("red_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10272)), Maple.Maple_Group);
    public static final class_2248 RED_STAINED_GLASS_STAIRS = registerBlock("red_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_10272.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10272)), Maple.Maple_Group);
    public static final class_2248 BLACK_STAINED_GLASS_SLAB = registerBlock("black_stained_glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_9997)), Maple.Maple_Group);
    public static final class_2248 BLACK_STAINED_GLASS_STAIRS = registerBlock("black_stained_glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_9997.method_9564(), class_4970.class_2251.method_9630(class_2246.field_9997)), Maple.Maple_Group);
    public static final class_2248 GLASS_SLAB = registerBlock("glass_slab",
            new MapleGlassSlabBlock(class_4970.class_2251.method_9630(class_2246.field_10033)), Maple.Maple_Group);
    public static final class_2248 GLASS_STAIRS = registerBlock("glass_stairs",
            new MapleGlassStairsBlock(class_2246.field_9997.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10033)), Maple.Maple_Group);


    public static final class_2248 TATAMI =registerBlock("tatami",
            new class_2380(class_4970.class_2251.method_9630(class_2246.field_10359).method_31710(class_3620.field_15995)),Maple.Maple_Group);
    public static final class_2248 TATAMI_SLAB = registerBlock("tatami_slab",
            new class_2482(class_4970.class_2251.method_9630(MapleBlocks.TATAMI).method_31710(class_3620.field_15995)), Maple.Maple_Group);

    //PLASTER
    public static final class_2248 GREEN_PLASTER =registerBlock("green_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10367).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 PLASTER =registerBlock("plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10107).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 ORANGE_PLASTER =registerBlock("orange_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10210).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 MAGENTA_PLASTER =registerBlock("magenta_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10585).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 LIGHT_BLUE_PLASTER =registerBlock("light_blue_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10242).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 YELLOW_PLASTER =registerBlock("yellow_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10542).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 LIME_PLASTER =registerBlock("lime_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10421).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 PINK_PLASTER =registerBlock("pink_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10434).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 GRAY_PLASTER =registerBlock("gray_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10038).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 LIGHT_GRAY_PLASTER =registerBlock("light_gray_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10172).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 CYAN_PLASTER =registerBlock("cyan_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10308).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 PURPLE_PLASTER =registerBlock("purple_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10206).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 BLUE_PLASTER =registerBlock("blue_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10011).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 BROWN_PLASTER =registerBlock("brown_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10439).method_29292().method_9632(1.8F)),Maple.Maple_Group);
    public static final class_2248 RED_PLASTER =registerBlock("red_plaster",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10058).method_29292().method_9632(1.8F)),Maple.Maple_Group);

    //Sea Lantern
    public static final class_2248 Iron_Sea_Lantern =registerBlock("iron_sea_lantern",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10174)),Maple.Maple_Group);
    public static final class_2248 Gold_Sea_Lantern =registerBlock("gold_sea_lantern",
            new class_2248(class_4970.class_2251.method_9630(class_2246.field_10174)),Maple.Maple_Group);

    //Concrete
    public static final class_2248 WHITE_CONCRETE_STAIRS = registerBlock("white_concrete_stairs",
            new class_2510(class_2246.field_10107.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10107)), Maple.Maple_Group);
    public static final class_2248 WHITE_CONCRETE_SLAB = registerBlock("white_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10107)), Maple.Maple_Group);

    public static final class_2248 ORANGE_CONCRETE_STAIRS = registerBlock("orange_concrete_stairs",
            new class_2510(class_2246.field_10210.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10210)), Maple.Maple_Group);
    public static final class_2248 ORANGE_CONCRETE_SLAB = registerBlock("orange_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10210)), Maple.Maple_Group);

    public static final class_2248 MAGENTA_CONCRETE_STAIRS = registerBlock("magenta_concrete_stairs",
            new class_2510(class_2246.field_10585.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10585)), Maple.Maple_Group);
    public static final class_2248 MAGENTA_CONCRETE_SLAB = registerBlock("magenta_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10585)), Maple.Maple_Group);

    public static final class_2248 LIGHT_BLUE_CONCRETE_STAIRS = registerBlock("light_blue_concrete_stairs",
            new class_2510(class_2246.field_10585.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10585)), Maple.Maple_Group);
    public static final class_2248 LIGHT_BLUE_CONCRETE_SLAB = registerBlock("light_blue_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10585)), Maple.Maple_Group);

    public static final class_2248 YELLOW_CONCRETE_STAIRS = registerBlock("yellow_concrete_stairs",
            new class_2510(class_2246.field_10542.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10542)), Maple.Maple_Group);
    public static final class_2248 YELLOW_CONCRETE_SLAB = registerBlock("yellow_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10542)), Maple.Maple_Group);

    public static final class_2248 LIME_CONCRETE_STAIRS = registerBlock("lime_concrete_stairs",
            new class_2510(class_2246.field_10421.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10421)), Maple.Maple_Group);
    public static final class_2248 LIME_CONCRETE_SLAB = registerBlock("lime_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10421)), Maple.Maple_Group);

    public static final class_2248 PINK_CONCRETE_STAIRS = registerBlock("pink_concrete_stairs",
            new class_2510(class_2246.field_10434.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10434)), Maple.Maple_Group);
    public static final class_2248 PINK_CONCRETE_SLAB = registerBlock("pink_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10434)), Maple.Maple_Group);

    public static final class_2248 GRAY_CONCRETE_STAIRS = registerBlock("gray_concrete_stairs",
            new class_2510(class_2246.field_10038.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10038)), Maple.Maple_Group);
    public static final class_2248 GRAY_CONCRETE_SLAB = registerBlock("gray_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10038)), Maple.Maple_Group);

    public static final class_2248 LIGHT_GRAY_CONCRETE_STAIRS = registerBlock("light_gray_concrete_stairs",
            new class_2510(class_2246.field_10172.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10172)), Maple.Maple_Group);
    public static final class_2248 LIGHT_GRAY_CONCRETE_SLAB = registerBlock("light_gray_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10172)), Maple.Maple_Group);

    public static final class_2248 CYAN_CONCRETE_STAIRS = registerBlock("cyan_concrete_stairs",
            new class_2510(class_2246.field_10308.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10308)), Maple.Maple_Group);
    public static final class_2248 CYAN_CONCRETE_SLAB = registerBlock("cyan_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10308)), Maple.Maple_Group);

    public static final class_2248 PURPLE_CONCRETE_STAIRS = registerBlock("purple_concrete_stairs",
            new class_2510(class_2246.field_10206.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10206)), Maple.Maple_Group);
    public static final class_2248 PURPLE_CONCRETE_SLAB = registerBlock("purple_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10206)), Maple.Maple_Group);

    public static final class_2248 BLUE_CONCRETE_STAIRS = registerBlock("blue_concrete_stairs",
            new class_2510(class_2246.field_10011.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10011)), Maple.Maple_Group);
    public static final class_2248 BLUE_CONCRETE_SLAB = registerBlock("blue_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10011)), Maple.Maple_Group);

    public static final class_2248 BROWN_CONCRETE_STAIRS = registerBlock("brown_concrete_stairs",
            new class_2510(class_2246.field_10439.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10439)), Maple.Maple_Group);
    public static final class_2248 BROWN_CONCRETE_SLAB = registerBlock("brown_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10439)), Maple.Maple_Group);

    public static final class_2248 GREEN_CONCRETE_STAIRS = registerBlock("green_concrete_stairs",
            new class_2510(class_2246.field_10367.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10367)), Maple.Maple_Group);
    public static final class_2248 GREEN_CONCRETE_SLAB = registerBlock("green_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10367)), Maple.Maple_Group);

    public static final class_2248 RED_CONCRETE_STAIRS = registerBlock("red_concrete_stairs",
            new class_2510(class_2246.field_10058.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10058)), Maple.Maple_Group);
    public static final class_2248 RED_CONCRETE_SLAB = registerBlock("red_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10058)), Maple.Maple_Group);

    public static final class_2248 BLACK_CONCRETE_STAIRS = registerBlock("black_concrete_stairs",
            new class_2510(class_2246.field_10458.method_9564(), class_4970.class_2251.method_9630(class_2246.field_10458)), Maple.Maple_Group);
    public static final class_2248 BLACK_CONCRETE_SLAB = registerBlock("black_concrete_slab",
            new class_2482(class_4970.class_2251.method_9630(class_2246.field_10458)), Maple.Maple_Group);

    //MapleJuicer
    public static final class_2248 Maple_Juicer_Block =registerBlock("maple_juicer_block",new MapleJuicerBlock(class_4970.class_2251.method_9637().method_22488().method_29292().method_9629(3.0F, 3.0F)), Maple.Maple_Group);

    //Tea
    public static final class_2248 Tea_Block =registerBlock("tea_block",new MapleTeaBlock(class_4970.class_2251.method_9637().method_22488().method_29292().method_9629(3.0F, 3.0F)), Maple.Maple_Group);




    private static class_2248 registerBlockWithoutItem(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(Maple.MOD_ID, name), block);
    }
    private static class_2248 registerBlock(String name, class_2248 block, class_5321<class_1761> tab) {
        registerBlockItem(name, block, tab);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(Maple.MOD_ID, name), block);
    }
    private static class_1792 registerBlockItem(String name, class_2248 block, class_5321<class_1761> tab) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(Maple.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
    }

    private static class_2465 createBambooBlock(class_3620 topMapColor, class_3620 sideMapColor, class_2498 soundGroup) {
        return new class_2465(class_4970.class_2251.method_9637().method_31710(sideMapColor).method_9632(2.0f).method_9626(soundGroup));
    }

    public static void registerMapleBlocks() {
        Maple.LOGGER.debug("Registering ModBlocks for " + Maple.MOD_ID);
    }

}
