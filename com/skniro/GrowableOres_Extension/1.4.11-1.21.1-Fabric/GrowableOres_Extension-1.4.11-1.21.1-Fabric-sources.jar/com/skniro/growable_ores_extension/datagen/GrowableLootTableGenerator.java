package com.skniro.growable_ores_extension.datagen;


import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;


public class GrowableLootTableGenerator extends FabricBlockLootTableProvider {
    protected GrowableLootTableGenerator(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void method_10379() {
         method_45988(GrowableOresBlocks.GrowableOres_Block, method_45976(GrowableOresBlocks.GrowableOres_Block));

    }
}
