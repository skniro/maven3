package com.skniro.blackhold.block;

import com.skniro.blackhold.Furniture;
import com.skniro.blackhold.block.init.DrawBlock;
import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class FurnitureDrawBlocks {
    public static final class_2248 Oak_Allay_Draw = registerBlock("oak_blackhold_draw", DrawBlock::new, class_4970.class_2251.method_9637().method_31710(class_2246.field_10161.method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));
    public static final class_2248 Spruce_Allay_Draw = registerBlock("spruce_blackhold_draw", DrawBlock::new, class_4970.class_2251.method_9637().method_31710(class_2246.field_9975.method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));
    public static final class_2248 Birch_Allay_Draw = registerBlock("birch_blackhold_draw", (settings) -> new DrawBlock( settings), class_4970.class_2251.method_9637().method_31710(class_2246.field_10148.method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));
    public static final class_2248 Jungle_Allay_Draw = registerBlock("jungle_blackhold_draw", DrawBlock::new, class_4970.class_2251.method_9637().method_31710(class_2246.field_10334.method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));
    public static final class_2248 Acacia_Allay_Draw = registerBlock("acacia_blackhold_draw", DrawBlock::new, class_4970.class_2251.method_9637().method_31710(class_2246.field_10218.method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));
    public static final class_2248 DarkOak_Allay_Draw = registerBlock("dark_oak_blackhold_draw", DrawBlock::new, class_4970.class_2251.method_9637().method_31710(class_2246.field_10075.method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));
    public static final class_2248 Mangrove_Allay_Draw = registerBlock("mangrove_blackhold_draw", DrawBlock::new, class_4970.class_2251.method_9637().method_31710(class_2246.field_37577.method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));
    public static final class_2248 Bamboo_Allay_Draw = registerBlock("bamboo_blackhold_draw", DrawBlock::new, class_4970.class_2251.method_9637().method_31710(class_2246.field_40294.method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));
    public static final class_2248 Cherry_Allay_Draw = registerBlock("cherry_blackhold_draw", DrawBlock::new, class_4970.class_2251.method_9637().method_31710(class_2246.field_42751.method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));
    public static final class_2248 Crimson_Allay_Draw = registerBlock("crimson_blackhold_draw", DrawBlock::new, class_4970.class_2251.method_9637().method_31710(class_2246.field_22126.method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));
    public static final class_2248 Warped_Allay_Draw = registerBlock("warped_blackhold_draw", DrawBlock::new, class_4970.class_2251.method_9637().method_31710(class_2246.field_22127.method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));
    public static final class_2248 PaleOak_Allay_Draw = registerBlock("pale_oak_blackhold_draw", DrawBlock::new, class_4970.class_2251.method_9637().method_31710(class_2246.field_54735.method_26403()).method_51368(class_2766.field_12651).method_9632(3.0F).method_22488().method_50013().method_50012(class_3619.field_15971));

    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(keyOf(name)));
        registerBlockItem(name, block);
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }


    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Furniture.MOD_ID, name)),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Furniture.MOD_ID, name)))));
    }

    private static class_2248 registerBlockWithoutItem(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(keyOf(name)));
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }

    private static class_5321<class_2248> keyOf(String name) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(Furniture.MOD_ID, name));
    }

    public static void registerDrawBlocks() {
        Furniture.LOGGER.debug("Registering Kitchen Blocks for " + Furniture.MOD_ID);
    }
}
