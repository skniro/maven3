package com.skniro.industrial_elixir.block.init;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import org.jetbrains.annotations.Nullable;

public class CupBlock extends class_2383 {
    public static final MapCodec<CupBlock> CODEC = method_54094(CupBlock::new);
    private static final class_265 NORTH_SHAPE;
    private static final class_265 SOUTH_SHAPE;
    private static final class_265 EAST_SHAPE;
    private static final class_265 WEST_SHAPE;

    public CupBlock(class_4970.class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends CupBlock> method_53969() {
        return field_46280;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2350 direction = state.method_11654(field_11177);
        switch (direction) {
            case field_11034:
                return EAST_SHAPE;
            case field_11035:
                return SOUTH_SHAPE;
            case field_11039:
                return WEST_SHAPE;
            case field_11043:
            default:
                return NORTH_SHAPE;
        }
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(field_11177, ctx.method_8042().method_10153());
    }

    @Override
    protected void method_9515(class_2689.class_2690<net.minecraft.class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }

    private static class_265 buildCupShape(class_2350 facing) {
        // Element data from coffee.json model (north-facing base orientation)
        double[][] from = {
                {7, 0, 3}, {6.5, 0, 6}, {9, 0, 6}, {9, 0, 3.5}, {6.5, 0, 3.5},
                {6, 0, 4}, {9.5, 0, 4}, {7, 0, 3}, {6.9, 0, 6.5},
                {4.8, 1.5, 4.6}, {4.8, 2, 4.6}, {4.8, 3.2, 4.6},
                {6.51, 4, 3.51}
        };
        double[][] to = {
                {9, 1, 7}, {7, 5, 6.5}, {9.5, 5, 6.5}, {9.5, 5, 4}, {7, 5, 4},
                {6.5, 5, 6}, {10, 5, 6}, {9, 5, 3.5}, {9, 5, 7},
                {6, 2, 5.2}, {5.3, 3.2, 5.2}, {6, 3.7, 5.2},
                {9.49, 4, 6.49}
        };

        class_265 shape = class_259.method_1073();
        for (int i = 0; i < from.length; i++) {
            double[] f = rotatePoint(from[i][0], from[i][1], from[i][2], facing);
            double[] t = rotatePoint(to[i][0], to[i][1], to[i][2], facing);
            shape = class_259.method_1084(shape, method_9541(
                    Math.min(f[0], t[0]), Math.min(f[1], t[1]), Math.min(f[2], t[2]),
                    Math.max(f[0], t[0]), Math.max(f[1], t[1]), Math.max(f[2], t[2])
            ));
        }
        return shape;
    }

    private static double[] rotatePoint(double x, double y, double z, class_2350 facing) {
        return switch (facing) {
            case field_11043 -> new double[]{x, y, z};
            case field_11035 -> new double[]{16 - x, y, 16 - z};
            case field_11034 -> new double[]{16 - z, y, x};
            case field_11039 -> new double[]{z, y, 16 - x};
            default -> new double[]{x, y, z};
        };
    }

    static {
        NORTH_SHAPE = buildCupShape(class_2350.field_11043);
        SOUTH_SHAPE = buildCupShape(class_2350.field_11035);
        EAST_SHAPE = buildCupShape(class_2350.field_11034);
        WEST_SHAPE = buildCupShape(class_2350.field_11039);
    }
}
