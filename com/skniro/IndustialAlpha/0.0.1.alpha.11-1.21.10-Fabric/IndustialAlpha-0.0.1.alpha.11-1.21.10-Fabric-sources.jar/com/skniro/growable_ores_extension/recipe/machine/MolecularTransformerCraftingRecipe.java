package com.skniro.growable_ores_extension.recipe.machine;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.growable_ores_extension.recipe.AlchemyCraftingRecipeInput;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import net.minecraft.class_10355;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class MolecularTransformerCraftingRecipe extends AbstractMachineCraftingRecipe {

    private final long energyRequired;

    public MolecularTransformerCraftingRecipe(class_1856 ingredients, class_1799 output, long energyRequired) {
        super(ingredients, output);
        this.energyRequired = energyRequired;
    }

    public long getEnergyRequired() {
        return this.energyRequired;
    }

    @Override
    public class_1865<? extends class_1860<AlchemyCraftingRecipeInput>> method_8119() {
        return AlchemyRecipeType.MOLECULAR_TRANSFORMER.serializer;
    }

    @Override
    public class_3956<? extends class_1860<AlchemyCraftingRecipeInput>> method_17716() {
        return AlchemyRecipeType.MOLECULAR_TRANSFORMER.type;
    }

    @Override
    public class_10355 method_64668() {
        return null;
    }

    public static class Serializer implements class_1865<MolecularTransformerCraftingRecipe> {

        public static final MapCodec<MolecularTransformerCraftingRecipe> CODEC = RecordCodecBuilder.mapCodec(inst ->
                inst.group(
                        class_1856.field_46095.fieldOf("ingredient").forGetter(recipe -> recipe.ingredient),
                        class_1799.field_24671.fieldOf("result").forGetter(recipe -> recipe.output),
                        Codec.LONG.fieldOf("energy").forGetter(recipe -> recipe.energyRequired)
                ).apply(inst, MolecularTransformerCraftingRecipe::new)
        );

        public static final class_9139<class_9129, MolecularTransformerCraftingRecipe> STREAM_CODEC =
                class_9139.method_56436(
                        class_1856.field_48355, MolecularTransformerCraftingRecipe::ingredient,
                        class_1799.field_48349, MolecularTransformerCraftingRecipe::output,
                        class_9135.field_54505, MolecularTransformerCraftingRecipe::getEnergyRequired,
                        MolecularTransformerCraftingRecipe::new
                );

        public Serializer() {}

        public MapCodec<MolecularTransformerCraftingRecipe> method_53736() {
            return CODEC;
        }

        public class_9139<class_9129, MolecularTransformerCraftingRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }
}