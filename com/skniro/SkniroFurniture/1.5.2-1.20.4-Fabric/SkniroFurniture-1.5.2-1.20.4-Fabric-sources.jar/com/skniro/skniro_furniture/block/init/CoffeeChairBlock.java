package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import com.skniro.skniro_furniture.entity.MapleEntityType;
import com.skniro.skniro_furniture.entity.furniture.ChairEntity;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2383;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3730;
import net.minecraft.class_3965;

public class CoffeeChairBlock extends class_2383 {
    private static final class_265 SHAPE = class_2248.method_9541(2.0, 0.0, 2.0, 14.0, 8.0, 14.0);
    public static final MapCodec<CoffeeChairBlock> CODEC = method_54094(CoffeeChairBlock::new);
    public CoffeeChairBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }


    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if(!level.method_8608()) {
            class_1297 entity = null;
            List<ChairEntity> entities = level.method_18023(MapleEntityType.CHAIR_ENTITY, new class_238(pos), chair -> true);
            if(entities.isEmpty()) {
                entity = MapleEntityType.CHAIR_ENTITY.method_47821(((class_3218) level), pos, class_3730.field_16461);
            } else {
                entity = entities.get(0);
            }
            player.method_5804(entity);
        }
        return class_1269.field_5812;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(field_11177, ctx.method_8042().method_10153());
    }
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }
}