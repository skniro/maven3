package com.skniro.growable_ores_extension;

import com.skniro.growable_ores_extension.networking.ModMessages;

import com.skniro.growable_ores_extension.energy.impl.EnergyImpl;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.time.LocalDate;


public class GrowableOresExtension implements ModInitializer {
    public static final String MOD_ID = "growable_ores_extension";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static boolean DISABLED = false;

    @Override
    public void onInitialize() {
        checkExpiration();
        if(!DISABLED){
            ModContent.registerItem();
            ModContent.registerBlock();
            ModContent.registerEntity();
            ModContent.CreativeTab();
            ModContent.WorldGen();

            EnergyImpl.init();
            ModMessages.register();
        }
    }

    public static void checkExpiration() {
        String version = FabricLoader.getInstance()
                .getModContainer(MOD_ID)
                .map(mod -> mod.getMetadata().getVersion().getFriendlyString())
                .orElse("");

        boolean isDev = version.contains("alpha") || version.contains("beta");

        LocalDate expireDate = LocalDate.of(2099, 5, 1);

        if (isDev && LocalDate.now().isAfter(expireDate)) {
            DISABLED = true;

            LOGGER.error("====================================");
            LOGGER.error(" This mod version has expired!");
            LOGGER.error(" Please update to a newer version.");
            LOGGER.error("====================================");
        }
    }
}
