package torcherino.platform;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_9129;
import torcherino.platform.payload.OpenTorchrinoScreenPayload;
import torcherino.platform.payload.TorchrinoTierPayload;
import torcherino.platform.payload.UpdateTorchrinoPayload;


public class Packets {
	public static void register() {
		clientbound(PayloadTypeRegistry.playS2C());
		serverbound(PayloadTypeRegistry.playC2S());
	}

	private static void clientbound(PayloadTypeRegistry<class_9129> registry) {
        registry.register(TorchrinoTierPayload.TYPE, TorchrinoTierPayload.CODEC);
        registry.register(OpenTorchrinoScreenPayload.TYPE, OpenTorchrinoScreenPayload.CODEC);
	}

	private static void serverbound(PayloadTypeRegistry<class_9129> registry) {
        registry.register(UpdateTorchrinoPayload.TYPE, UpdateTorchrinoPayload.CODEC);
	}

}
