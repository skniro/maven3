package com.skniro.growable_ores_extension.screen;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1703;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class AlchemyScreenHandlerType <T extends class_1703>{
    public static final class_3917<AlchemyBlockScreenHandler> ALCHEMY =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_43902(GrowableOresExtension.MOD_ID, "cane_converter_screen_handler"),
                    new ExtendedScreenHandlerType<>(AlchemyBlockScreenHandler::new));

    public static void registeralchemyscreenhandlertype () {

    }
}
