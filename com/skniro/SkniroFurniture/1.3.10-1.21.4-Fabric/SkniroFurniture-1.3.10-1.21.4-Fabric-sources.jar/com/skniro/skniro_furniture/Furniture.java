package com.skniro.skniro_furniture;

import com.skniro.skniro_furniture.block.FurnitureBedroomBlocks;
import com.skniro.skniro_furniture.block.FurnitureKitchenBlocks;
import com.skniro.skniro_furniture.block.FurnitureLivingroomBlocks;
import com.skniro.skniro_furniture.block.MapleFurnitureBlocks;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Furniture implements ModInitializer {
    public static final String MOD_ID = "skniro_furniture";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final ModContainer MOD_CONTAINER = FabricLoader.getInstance().getModContainer(MOD_ID).orElseThrow();

    public static final class_5321<class_1761> Maple_Group_Furniture = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(MOD_ID, "maple_group_furniture"));
    public static final class_5321<class_1761> Furniture_Group_Kitchen_Furniture = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(MOD_ID, "furniture_kitchen_group_furniture"));
    public static final class_5321<class_1761> Furniture_Group_Bedroom_Furniture = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(MOD_ID, "furniture_bedroom_group_furniture"));
    public static final class_5321<class_1761> Furniture_Group_Livingroom_Furniture = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(MOD_ID, "furniture_livingroom_group_furniture"));

    @Override
    public void onInitialize() {
        class_2378.method_39197(class_7923.field_44687, Maple_Group_Furniture, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(MapleFurnitureBlocks.OAK_PLANKS_Glass_Four_Grid_Cabinet))
                .method_47321(class_2561.method_43471("itemGroup.skniro_furniture.maple_group_furniture"))
                .method_47324());
        class_2378.method_39197(class_7923.field_44687, Furniture_Group_Kitchen_Furniture, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(FurnitureKitchenBlocks.OAK_PLANKS_OVEN))
                .method_47321(class_2561.method_43471("itemGroup.skniro_furniture.furniture_kitchen_group_furniture"))
                .method_47324());
        class_2378.method_39197(class_7923.field_44687, Furniture_Group_Bedroom_Furniture, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(FurnitureBedroomBlocks.OAK_PLANKS_BEDSIDE_CABINET))
                .method_47321(class_2561.method_43471("itemGroup.skniro_furniture.furniture_bedroom_group_furniture"))
                .method_47324());
        class_2378.method_39197(class_7923.field_44687, Furniture_Group_Livingroom_Furniture, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(FurnitureLivingroomBlocks.OAK_PLANKS_TV_STAND))
                .method_47321(class_2561.method_43471("itemGroup.skniro_furniture.furniture_livingroom_group_furniture"))
                .method_47324());
        FurnitureContent.registerItem();
        FurnitureContent.registerBlock();
        FurnitureContent.registerFluid();
        FurnitureContent.CreativeTab();
        FurnitureContent.generateWorldGen();
        FurnitureContent.registerOthers();
        FurnitureContent.registerCommand();
        FurnitureContent.registerMapleLootTable();
        FurnitureContent.registerMapleCompostableItems();
        FurnitureContent.registerScreenType();
        FurnitureContent.registerRecipeType();
        FurnitureContent.registerFurnitureEvent();
    }

    public static class_2960 asResource(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }

}
