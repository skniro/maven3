package com.skniro.industrial_elixir.recipe.machine;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import com.skniro.industrial_elixir.recipe.ModRecipeSerializers;

public class CoffeeMachineCraftingRecipe extends AbstractMachineCraftingRecipe {

    private final Optional<class_1856> ingredient2;
    private final Optional<class_1856> ingredient3;
    private final class_2960 requiredFluid;
    private final int requiredFluidAmount;

    public CoffeeMachineCraftingRecipe(class_1856 ingredient, Optional<class_1856> ingredient2,
                                       Optional<class_1856> ingredient3, int requiredCount,
                                       class_1799 output, class_2960 requiredFluid, int requiredFluidAmount) {
        super(ingredient, requiredCount, output);
        this.ingredient2 = ingredient2;
        this.ingredient3 = ingredient3;
        this.requiredFluid = requiredFluid;
        this.requiredFluidAmount = requiredFluidAmount;
    }

    @Override
    public class_1865<? extends class_1860<AlchemyCraftingRecipeInput>> method_8119() {
        return AlchemyRecipeType.COFFEE_MACHINE.serializer;
    }

    @Override
    public class_3956<? extends class_1860<AlchemyCraftingRecipeInput>> method_17716() {
        return AlchemyRecipeType.COFFEE_MACHINE.type;
    }


    public Optional<class_1856> ingredient2() {
        return ingredient2;
    }

    public Optional<class_1856> ingredient3() {
        return ingredient3;
    }

    public class_2960 requiredFluid() {
        return requiredFluid;
    }

    public int requiredFluidAmount() {
        return requiredFluidAmount;
    }

    public static final MapCodec<CoffeeMachineCraftingRecipe> CODEC =
            RecordCodecBuilder.mapCodec(inst -> inst.group(
                    class_1856.field_46095.fieldOf("ingredient").forGetter(recipe -> recipe.ingredient),
                    class_1856.field_46095.optionalFieldOf("ingredient2").forGetter(recipe -> recipe.ingredient2),
                    class_1856.field_46095.optionalFieldOf("ingredient3").forGetter(recipe -> recipe.ingredient3),
                    Codec.INT.fieldOf("count").forGetter(recipe -> recipe.requiredCount),
                    class_1799.field_24671.fieldOf("result").forGetter(recipe -> recipe.output),
                    class_2960.field_25139.fieldOf("fluid").forGetter(recipe -> recipe.requiredFluid),
                    Codec.INT.fieldOf("fluid_amount").forGetter(recipe -> recipe.requiredFluidAmount)
            ).apply(inst, CoffeeMachineCraftingRecipe::new));

    /**
     * 1.21.1's {@link class_9139#method_56434} only goes up to six components, so the
     * first six fields are packed into a small carrier record and the fluid amount
     * is appended afterwards.
     */
    private record Base(class_1856 ingredient, Optional<class_1856> ingredient2,
                        Optional<class_1856> ingredient3, int requiredCount,
                        class_1799 output, class_2960 requiredFluid) {
    }

    private static final class_9139<class_9129, Base> BASE_STREAM_CODEC =
            class_9139.method_58025(
                    class_1856.field_48355, Base::ingredient,
                    class_9135.method_56382(class_1856.field_48355), Base::ingredient2,
                    class_9135.method_56382(class_1856.field_48355), Base::ingredient3,
                    class_9135.field_49675, Base::requiredCount,
                    class_1799.field_48349, Base::output,
                    class_2960.field_48267, Base::requiredFluid,
                    Base::new);

    public static final class_9139<class_9129, CoffeeMachineCraftingRecipe> field_48356 =
            class_9139.method_56435(
                    BASE_STREAM_CODEC,
                    recipe -> new Base(recipe.ingredient, recipe.ingredient2, recipe.ingredient3,
                            recipe.requiredCount, recipe.output, recipe.requiredFluid),
                    class_9135.field_49675, CoffeeMachineCraftingRecipe::requiredFluidAmount,
                    (base, amount) -> new CoffeeMachineCraftingRecipe(base.ingredient(), base.ingredient2(),
                            base.ingredient3(), base.requiredCount(), base.output(),
                            base.requiredFluid(), amount));

    public static final class_1865<CoffeeMachineCraftingRecipe> SERIALIZER =
            ModRecipeSerializers.of(CODEC, field_48356);

    @Override
    public boolean matches(AlchemyCraftingRecipeInput input, net.minecraft.class_1937 world) {
        if (world.method_8608()) {
            return false;
        }

        net.minecraft.class_1799 stackA = input.method_59984(0);
        net.minecraft.class_1799 stackB = input.method_59983() > 1 ? input.method_59984(1) : net.minecraft.class_1799.field_8037;
        net.minecraft.class_1799 stackC = input.method_59983() > 2 ? input.method_59984(2) : net.minecraft.class_1799.field_8037;

        boolean firstMatches = ingredient.method_8093(stackA) && stackA.method_7947() >= requiredCount;
        if (!firstMatches) return false;

        if (ingredient2 != null && ingredient2.isPresent()) {
            if (!ingredient2.get().method_8093(stackB)) return false;
        }

        if (ingredient3 != null && ingredient3.isPresent()) {
            if (!ingredient3.get().method_8093(stackC)) return false;
        }

        return true;
    }
}
