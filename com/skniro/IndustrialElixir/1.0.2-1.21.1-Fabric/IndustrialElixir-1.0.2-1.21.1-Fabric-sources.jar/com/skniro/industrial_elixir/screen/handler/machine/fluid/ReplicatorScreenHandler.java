package com.skniro.industrial_elixir.screen.handler.machine.fluid;

import com.skniro.industrial_elixir.block.entity.machine.fluid.ReplicatorBlockEntity;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.screen.AlchemyScreenHandlerType;
import com.skniro.industrial_elixir.screen.slot.BatteryFuelSlot;
import com.skniro.industrial_elixir.screen.slot.UpgradeSlot;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1719;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3913;
import net.minecraft.class_3919;
import net.minecraft.world.inventory.*;

public class ReplicatorScreenHandler extends class_1703 {
    private final class_1263 inventory;
    public final ReplicatorBlockEntity blockEntity;
    final class_3913 propertyDelegate;

    public static final int BUTTON_STOP = 0;
    public static final int BUTTON_SINGLE = 1;
    public static final int BUTTON_LOOP = 2;

    public ReplicatorScreenHandler(int syncId, class_1661 playerInventory, class_2338 pos) {
        this(syncId, playerInventory, playerInventory.field_7546.method_37908().method_8321(pos), new class_3919(2));
    }

    public ReplicatorScreenHandler(int syncId, class_1661 playerInventory, class_2586 entity, class_3913 delegate) {
        super(AlchemyScreenHandlerType.Replicator, syncId);
        blockEntity = (ReplicatorBlockEntity) entity;
        method_17359(blockEntity, 12);
        this.propertyDelegate = delegate;
        this.inventory = blockEntity;
        inventory.method_5435(playerInventory.field_7546);

        // Same layout as BrewReactor, but slot 1 = crystal, removing slot 9 second input

        // Slot 0: Fluid container input (bucket/cell with UU matter)
        this.method_7621(new class_1735(inventory, 0, 8, 58));

        // Slot 1: Pattern Storage Crystal (replaces BrewReactor's material input)
        this.method_7621(new class_1735(inventory, 1, 53, 21) {
            @Override
            public boolean method_7680(class_1799 stack) {
                return stack.method_31574(GrowableOresItems.PATTERN_STORAGE_CRYSTAL);
            }
            @Override
            public int method_7675() {
                return 1;
            }
        });

        // Slot 2: Output (replicated item)
        this.method_7621(new class_1719(playerInventory.field_7546, inventory, 2, 107, 22));

        // Slot 3: Battery / Energy
        this.method_7621(new BatteryFuelSlot(inventory, 3, 131, 63, this.blockEntity.getEnergyTier()));

        // Slot 8: Empty fluid container return (like BrewReactor)
        this.method_7621(new class_1735(inventory, 8, 26, 58));

        addBasic(inventory, playerInventory, delegate);
    }

    private void addBasic(class_1263 inventory, class_1661 playerInventory, class_3913 propertyDelegate) {
        addUpgradeSlot(inventory);
        addPlayerInventory(playerInventory);
        addPlayerHotbar(playerInventory);
        method_17360(propertyDelegate);
    }

    private void addUpgradeSlot(class_1263 inventory) {
        this.method_7621(new UpgradeSlot(inventory, 4, 151, 9));
        this.method_7621(new UpgradeSlot(inventory, 5, 151, 27));
        this.method_7621(new UpgradeSlot(inventory, 6, 151, 45));
        this.method_7621(new UpgradeSlot(inventory, 7, 151, 63));
    }

    public boolean isCrafting() {
        return blockEntity.getMode() != ReplicatorBlockEntity.Mode.STOP && (blockEntity.getEnergyProgress() > 0 || blockEntity.getFluidProgress() > 0);
    }

    public int getScaledProgress() {
        int percent = blockEntity.getOverallProgressPercent();
        return percent * 11 / 100; // 11px wide arrow (same as BrewReactor)
    }

    public int getScaledEnergyHeight() {
        long energy = blockEntity.energyContainer.amount;
        long capacity = blockEntity.energyContainer.getCapacity();
        int energyBarSize = 16; // Same as BrewReactor
        return Math.toIntExact(capacity != 0 && energy != 0 ? energy * energyBarSize / capacity : 0);
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (!player.method_37908().method_8608()) {
            switch (id) {
                case BUTTON_STOP -> this.blockEntity.setMode(ReplicatorBlockEntity.Mode.STOP);
                case BUTTON_SINGLE -> this.blockEntity.setMode(ReplicatorBlockEntity.Mode.SINGLE);
                case BUTTON_LOOP -> this.blockEntity.setMode(ReplicatorBlockEntity.Mode.LOOP);
            }
        }
        return true;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int invSlot) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(invSlot);
        if (slot != null && slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();
            if (invSlot < this.inventory.method_5439()) {
                if (!this.method_7616(originalStack, this.inventory.method_5439(), this.field_7761.size(), true)) {
                    return class_1799.field_8037;
                }
            } else if (!this.method_7616(originalStack, 0, this.inventory.method_5439(), false)) {
                return class_1799.field_8037;
            }
            if (originalStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }
        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return this.inventory.method_5443(player);
    }

    private void addPlayerInventory(class_1661 playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.method_7621(new class_1735(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }
    }

    private void addPlayerHotbar(class_1661 playerInventory) {
        for (int i = 0; i < 9; ++i) {
            this.method_7621(new class_1735(playerInventory, i, 8 + i * 18, 142));
        }
    }
}
