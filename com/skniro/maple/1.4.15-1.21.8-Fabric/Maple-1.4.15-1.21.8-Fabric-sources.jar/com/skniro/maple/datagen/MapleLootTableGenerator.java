package com.skniro.maple.datagen;

import com.skniro.maple.block.MapleBlocks;
import com.skniro.maple.block.MapleNetherOresBlocks;
import com.skniro.maple.block.MapleOreBlocks;
import com.skniro.maple.block.MapleSignBlocks;
import com.skniro.maple.item.MapleItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_141;
import net.minecraft.class_1802;
import net.minecraft.class_212;
import net.minecraft.class_2302;
import net.minecraft.class_5662;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import java.util.concurrent.CompletableFuture;


public class MapleLootTableGenerator extends FabricBlockLootTableProvider {
    public MapleLootTableGenerator(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataGenerator, registryLookup);
    }
    public static final float[] field_40605 = new float[]{0.048F, 0.0425F, 0.062333336F, 0.1F};

    @Override
    public void method_10379() {
        //CHERRY
        method_46025(MapleSignBlocks.CHERRY_SIGN);
        method_46025(MapleSignBlocks.CHERRY_WALL_SIGN);
        method_46025(MapleBlocks.CHERRY_LOG);
        method_46025(MapleBlocks.CHERRY_WOOD);
        method_45988(MapleBlocks.CHERRY_DOOR,method_46022(MapleBlocks.CHERRY_DOOR));
        method_46025(MapleBlocks.CHERRY_SAPLING);
        method_45988(MapleBlocks.CHERRY_LEAVES,method_45986(MapleBlocks.CHERRY_LEAVES,MapleBlocks.CHERRY_SAPLING,field_40605));
        method_46025(MapleBlocks.CHERRY_BUTTON);
        method_46025(MapleBlocks.CHERRY_FENCE);
        method_46025(MapleBlocks.CHERRY_FENCE_GATE);
        method_46025(MapleBlocks.CHERRY_PLANKS);
        method_46025(MapleBlocks.CHERRY_PRESSURE_PLATE);
        method_46025(MapleBlocks.CHERRY_SLAB);
        method_46025(MapleBlocks.CHERRY_STAIRS);
        method_46025(MapleBlocks.CHERRY_TRAPDOOR);
        method_46025(MapleBlocks.STRIPPED_CHERRY_LOG);
        method_46025(MapleBlocks.STRIPPED_CHERRY_WOOD);

        //MAPLE
        method_46025(MapleSignBlocks.Maple_SIGN);
        method_46025(MapleSignBlocks.Maple_WALL_SIGN);
        method_46025(MapleSignBlocks.Maple_HANGING_SIGN);
        method_46025(MapleSignBlocks.Maple_WALL_HANGING_SIGN);
        method_46025(MapleBlocks.MAPLE_LOG);
        method_46025(MapleBlocks.MAPLE_WOOD);
        method_45988(MapleBlocks.MAPLE_DOOR,method_46022(MapleBlocks.MAPLE_DOOR));
        method_46025(MapleBlocks.MAPLE_SAPLING);
        method_46025(MapleBlocks.RED_MAPLE_SAPLING);
        method_45988(MapleBlocks.MAPLE_LEAVES,method_45986(MapleBlocks.MAPLE_LEAVES,MapleBlocks.MAPLE_SAPLING,field_40605));
        method_45988(MapleBlocks.RED_MAPLE_LEAVES,method_45986(MapleBlocks.RED_MAPLE_LEAVES,MapleBlocks.RED_MAPLE_SAPLING,field_40605));
        method_46025(MapleBlocks.MAPLE_BUTTON);
        method_46025(MapleBlocks.MAPLE_FENCE);
        method_46025(MapleBlocks.MAPLE_FENCE_GATE);
        method_46025(MapleBlocks.MAPLE_PLANKS);
        method_46025(MapleBlocks.MAPLE_PRESSURE_PLATE);
        method_46025(MapleBlocks.MAPLE_SLAB);
        method_46025(MapleBlocks.MAPLE_STAIRS);
        method_46025(MapleBlocks.MAPLE_TRAPDOOR);
        method_46025(MapleBlocks.STRIPPED_MAPLE_LOG);
        method_46025(MapleBlocks.STRIPPED_MAPLE_WOOD);

        //GINKGO
        method_46025(MapleSignBlocks.GINKGO_SIGN);
        method_46025(MapleSignBlocks.GINKGO_WALL_SIGN);
        method_46025(MapleSignBlocks.GINKGO_HANGING_SIGN);
        method_46025(MapleSignBlocks.GINKGO_WALL_HANGING_SIGN);
        method_46025(MapleBlocks.GINKGO_LOG);
        method_46025(MapleBlocks.GINKGO_WOOD);
        method_45988(MapleBlocks.GINKGO_DOOR,method_46022(MapleBlocks.GINKGO_DOOR));
        method_45988(MapleBlocks.GINKGO_LEAVES,method_45986(MapleBlocks.GINKGO_LEAVES,MapleBlocks.GINKGO_SAPLING,field_40605));
        method_46025(MapleBlocks.GINKGO_BUTTON);
        method_46025(MapleBlocks.GINKGO_FENCE);
        method_46025(MapleBlocks.GINKGO_FENCE_GATE);
        method_46025(MapleBlocks.GINKGO_PLANKS);
        method_46025(MapleBlocks.GINKGO_PRESSURE_PLATE);
        method_46025(MapleBlocks.GINKGO_SLAB);
        method_46025(MapleBlocks.GINKGO_STAIRS);
        method_46025(MapleBlocks.GINKGO_TRAPDOOR);
        method_46025(MapleBlocks.GINKGO_SAPLING);
        method_46025(MapleBlocks.STRIPPED_GINKGO_LOG);
        method_46025(MapleBlocks.STRIPPED_GINKGO_WOOD);




        //BAMBOO
        method_46025(MapleBlocks.BAMBOO_BLOCK);
        method_46025(MapleSignBlocks.BAMBOO_SIGN);
        method_46025(MapleSignBlocks.BAMBOO_WALL_SIGN);
        method_46025(MapleBlocks.BAMBOO_MOSAIC);
        method_45988(MapleBlocks.BAMBOO_DOOR,method_46022(MapleBlocks.BAMBOO_DOOR));
        method_46025(MapleBlocks.BAMBOO_BUTTON);
        method_46025(MapleBlocks.BAMBOO_FENCE);
        method_46025(MapleBlocks.BAMBOO_FENCE_GATE);
        method_46025(MapleBlocks.BAMBOO_PLANKS);
        method_46025(MapleBlocks.BAMBOO_PRESSURE_PLATE);
        method_46025(MapleBlocks.BAMBOO_SLAB);
        method_46025(MapleBlocks.BAMBOO_STAIRS);
        method_46025(MapleBlocks.BAMBOO_MOSAIC_SLAB);
        method_46025(MapleBlocks.BAMBOO_MOSAIC_STAIRS);
        method_46025(MapleBlocks.BAMBOO_TRAPDOOR);
        method_46025(MapleBlocks.STRIPPED_BAMBOO_BLOCK);

        //SAKURA
        method_46025(MapleBlocks.SAKURA_SAPLING);
        method_45988(MapleBlocks.SAKURA_LEAVES, method_45986(MapleBlocks.SAKURA_LEAVES,MapleBlocks.SAKURA_SAPLING, field_40605));

        //Crop
        net.minecraft.class_5341.class_210 builder = class_212.method_900(MapleBlocks.RICE).method_22584(net.minecraft.class_4559.class_4560.method_22523().method_22524(class_2302.field_10835, 7));
        method_45988(MapleBlocks.RICE, method_45982(MapleBlocks.RICE, MapleItems.SOYBEAN,MapleItems.Rice,builder));

        //Glass Block
        method_46024(MapleBlocks.WHITE_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.WHITE_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.ORANGE_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.ORANGE_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.MAGENTA_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.MAGENTA_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.LIGHT_BLUE_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.LIGHT_BLUE_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.YELLOW_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.YELLOW_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.LIME_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.LIME_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.PINK_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.PINK_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.GRAY_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.GRAY_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.LIGHT_GRAY_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.LIGHT_GRAY_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.CYAN_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.CYAN_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.PURPLE_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.PURPLE_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.BLUE_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.BLUE_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.BROWN_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.BROWN_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.GREEN_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.GREEN_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.RED_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.RED_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.BLACK_STAINED_GLASS_SLAB);
        method_46024(MapleBlocks.BLACK_STAINED_GLASS_STAIRS);
        method_46024(MapleBlocks.GLASS_SLAB);
        method_46024(MapleBlocks.GLASS_STAIRS);

        method_46025(MapleBlocks.TATAMI);
        method_46025(MapleBlocks.TATAMI_SLAB);

        method_45988(MapleNetherOresBlocks.Nether_Coal_Ore, method_45981(MapleNetherOresBlocks.Nether_Coal_Ore, class_1802.field_8713));
        method_45988(MapleNetherOresBlocks.Nether_Copper_Ore, method_46010(MapleNetherOresBlocks.Nether_Copper_Ore));
        method_45988(MapleNetherOresBlocks.Nether_Diamond_Ore, method_45981(MapleNetherOresBlocks.Nether_Diamond_Ore,class_1802.field_8477));
        method_45988(MapleNetherOresBlocks.Nether_Emerald_Ore, method_45981(MapleNetherOresBlocks.Nether_Emerald_Ore,class_1802.field_8687));
        method_45988(MapleNetherOresBlocks.Nether_Gold_Ore, method_45981(MapleNetherOresBlocks.Nether_Gold_Ore,class_1802.field_33402));
        method_45988(MapleNetherOresBlocks.Nether_Iron_Ore, method_45981(MapleNetherOresBlocks.Nether_Iron_Ore,class_1802.field_33400));
        method_45988(MapleNetherOresBlocks.Nether_Lapis_Ore, method_46011(MapleNetherOresBlocks.Nether_Lapis_Ore));
        method_45988(MapleNetherOresBlocks.Nether_Redstone_Ore,method_46012(MapleNetherOresBlocks.Nether_Redstone_Ore));
        method_45988(MapleNetherOresBlocks.Nether_Coal_Ore, method_45981(MapleNetherOresBlocks.Nether_Coal_Ore,class_1802.field_8713));
        method_45988(MapleOreBlocks.Salt_Ore, method_45989(MapleOreBlocks.Salt_Ore, this.method_45977(MapleOreBlocks.Salt_Ore, class_77.method_411(MapleItems.Salt).method_438(class_141.method_621(class_5662.method_32462(1.0F,1.0F))))));
        method_45988(MapleOreBlocks.DEEPSLATE_Salt_Ore, method_45989(MapleOreBlocks.DEEPSLATE_Salt_Ore, this.method_45977(MapleOreBlocks.DEEPSLATE_Salt_Ore, class_77.method_411(MapleItems.Salt).method_438(class_141.method_621(class_5662.method_32462(2.0F, 5.0F))))));

        method_46025(MapleBlocks.RED_MAPLE_CARPET);
        method_46025(MapleBlocks.Maple_CARPET);
        method_46025(MapleBlocks.GINKGO_CARPET);
        method_46025(MapleBlocks.SAKURA_CARPET);

        //PLASTER
        method_46025(MapleBlocks.GREEN_PLASTER);
        method_46025(MapleBlocks.PLASTER);
        method_46025(MapleBlocks.ORANGE_PLASTER);
        method_46025(MapleBlocks.MAGENTA_PLASTER);
        method_46025(MapleBlocks.LIGHT_BLUE_PLASTER);
        method_46025(MapleBlocks.YELLOW_PLASTER);
        method_46025(MapleBlocks.LIME_PLASTER);
        method_46025(MapleBlocks.PINK_PLASTER);
        method_46025(MapleBlocks.GRAY_PLASTER);
        method_46025(MapleBlocks.LIGHT_GRAY_PLASTER);
        method_46025(MapleBlocks.CYAN_PLASTER);
        method_46025(MapleBlocks.PURPLE_PLASTER);
        method_46025(MapleBlocks.BLUE_PLASTER);
        method_46025(MapleBlocks.BROWN_PLASTER);
        method_46025(MapleBlocks.RED_PLASTER);

        //Sea Lantern
        method_46025(MapleBlocks.Iron_Sea_Lantern);
        method_46025(MapleBlocks.Gold_Sea_Lantern);

        //Potted
        method_46023(MapleBlocks.POTTED_SAKURA_SAPLING);
        method_46023(MapleBlocks.POTTED_RED_MAPLE_SAPLING);
        method_46023(MapleBlocks.POTTED_CHERRY_SAPLING);
        method_46023(MapleBlocks.POTTED_GINKGO_SAPLING);
        method_46023(MapleBlocks.POTTED_MAPLE_SAPLING);
    }
}
