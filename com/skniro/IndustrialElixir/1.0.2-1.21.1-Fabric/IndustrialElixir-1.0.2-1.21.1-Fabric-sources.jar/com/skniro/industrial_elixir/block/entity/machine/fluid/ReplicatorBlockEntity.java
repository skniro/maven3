package com.skniro.industrial_elixir.block.entity.machine.fluid;

import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.block.entity.machine.PatternStorageBlockEntity;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluids;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.screen.handler.machine.fluid.ReplicatorScreenHandler;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1264;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

public class ReplicatorBlockEntity extends AbstractFluidMachineEntity {
    public enum Mode {
        STOP,
        SINGLE,
        LOOP
    }

    private Mode mode = Mode.STOP;

    // Synthesis progress
    private long energyProgress = 0;
    private int fluidProgress = 0;

    // Pattern data from crystal
    @Nullable private class_2960 replicatingItemId;
    private long replicatingEnergyCost = 0;
    private int replicatingUUCost = 0;

    // Cooldown to prevent continuous rapid checks
    private int tickCounter = 0;

    public ReplicatorBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.REPLICATOR_BE, pos, state);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Replicator);
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return null; // No recipe - uses crystal pattern data
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new ReplicatorScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    // ---- Mode switching (called from networking) ----
    public void setMode(Mode mode) {
        this.mode = mode;
        if (mode == Mode.STOP) {
            // Reset progress when stopping
            this.energyProgress = 0;
            this.fluidProgress = 0;
        }
        method_5431();
    }

    public Mode getMode() {
        return mode;
    }

    // ---- Read pattern from crystal ----
    private void updatePatternFromCrystal() {
        class_1799 crystal = inventory.get(INPUT_SLOT);
        if (crystal.method_7960() || !crystal.method_31574(GrowableOresItems.PATTERN_STORAGE_CRYSTAL)) {
            this.replicatingItemId = null;
            return;
        }
        if (!PatternStorageBlockEntity.hasPatternData(crystal)) {
            this.replicatingItemId = null;
            return;
        }
        class_2960 itemId = PatternStorageBlockEntity.getPatternItem(crystal);
        int uuCost = PatternStorageBlockEntity.getPatternUUCost(crystal);
        int energyCost = PatternStorageBlockEntity.getPatternEnergyCost(crystal);
        if (itemId != null) {
            this.replicatingItemId = itemId;
            this.replicatingUUCost = uuCost;
            this.replicatingEnergyCost = energyCost;
        }
    }

    private boolean canProduceOutput() {
        class_1799 outputSlot = inventory.get(OUTPUT_SLOT);
        if (replicatingItemId == null) return false;
        class_1792 targetItem = class_7923.field_41178.method_17966(replicatingItemId).orElse(null);
        if (targetItem == null) return false;
        if (outputSlot.method_7960()) return true;
        if (!outputSlot.method_31574(targetItem)) return false;
        return outputSlot.method_7947() < outputSlot.method_7914();
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) return;

        tickCounter++;

        // Charge battery in energy slot
        charge(ENERGY_ITEM_SLOT);

        // Fill fluid tank from fluid containers
        if (hasFluidStackInFluidSlot()) {
            fillUpFluidTank();
        }

        // Update pattern data from crystal periodically
        if (tickCounter % 20 == 0) {
            updatePatternFromCrystal();
        }

        boolean working = false;

        if (mode != Mode.STOP && replicatingItemId != null && canProduceOutput()) {
            // Pull energy continuously
            if (energyProgress < replicatingEnergyCost) {
                long needed = replicatingEnergyCost - energyProgress;
                long toExtract = Math.min(energyContainer.amount, needed);
                toExtract = Math.min(toExtract, getEffectiveTier().getMaxInput());
                if (toExtract > 0) {
                    try (Transaction tx = Transaction.openOuter()) {
                        long extracted = energyContainer.getSideStorage(null).extract(toExtract, tx);
                        if (extracted > 0) {
                            tx.commit();
                            energyProgress += extracted;
                            working = true;
                        }
                    }
                }
            }

            // Pull UU fluid continuously (rate-limited by tier)
            if (fluidProgress < replicatingUUCost) {
                int needed = replicatingUUCost - fluidProgress;
                int toExtract = Math.min(needed, 5);
                try (Transaction tx = Transaction.openOuter()) {
                    long extracted = fluidContainer.extract(
                            FluidVariant.of(IndustrialElixirFluids.STILL_Fluid_UU), toExtract, tx);
                    if (extracted > 0) {
                        tx.commit();
                        fluidProgress += (int) extracted;
                        working = true;
                    }
                }
            }

            // Check if synthesis is complete
            if (energyProgress >= replicatingEnergyCost
                    && fluidProgress >= replicatingUUCost) {

                if (produceReplicatedItem()) {

                    if (mode == Mode.SINGLE) {
                        mode = Mode.STOP;
                    }

                    // LOOP continues automatically
                    // because progress was reset
                }
            }
        }

        if (state.method_11654(AbstractMachineblock.LIT) != working) {
            world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, working), 3);
        }

        if (tickCounter % 10 == 0) {
            method_31663(world, pos, state);
        }
    }

    private boolean produceReplicatedItem() {
        if (replicatingItemId == null) {
            return false;
        }

        class_1792 targetItem = class_7923.field_41178
                .method_17966(replicatingItemId)
                .orElse(null);

        if (targetItem == null) {
            return false;
        }

        class_1799 output = inventory.get(OUTPUT_SLOT);

        if (output.method_7960()) {
            inventory.set(
                    OUTPUT_SLOT,
                    new class_1799(targetItem, 1)
            );
        } else {
            if (!output.method_31574(targetItem)) {
                return false;
            }

            if (output.method_7947() >= output.method_7914()) {
                return false;
            }

            output.method_7933(1);
        }

        energyProgress = 0;
        fluidProgress = 0;

        method_5431();

        return true;
    }

    // ---- Getters for display ----
    public long getEnergyProgress() { return energyProgress; }
    public long getReplicatingEnergyCost() { return replicatingEnergyCost; }
    public int getFluidProgress() { return fluidProgress; }
    public int getReplicatingUUCost() { return replicatingUUCost; }
    @Nullable public class_2960 getReplicatingItemId() { return replicatingItemId; }

    public int getOverallProgressPercent() {
        if (replicatingEnergyCost == 0 && replicatingUUCost == 0) return 0;
        int ep = replicatingEnergyCost == 0 ? 100 : (int) (energyProgress * 100 / replicatingEnergyCost);
        int fp = replicatingUUCost == 0 ? 100 : fluidProgress * 100 / replicatingUUCost;
        return Math.min(ep, fp);
    }

    // ---- Save/Load ----
    @Override
    protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        output.method_10569("replicator.mode", mode.ordinal());
        output.method_10544("replicator.energy_progress", energyProgress);
        output.method_10569("replicator.fluid_progress", fluidProgress);
        if (replicatingItemId != null) {
            output.method_10582("replicator.item_id", replicatingItemId.toString());
        }
        output.method_10544("replicator.energy_cost", replicatingEnergyCost);
        output.method_10569("replicator.uu_cost", replicatingUUCost);
        SingleVariantStorage.writeNbt(fluidContainer, FluidVariant.CODEC, output, registries);
    }

    @Override
    protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        super.method_11014(input, registries);
        int modeOrdinal = (input.method_10545("replicator.mode") ? input.method_10550("replicator.mode") : 0);
        this.mode = Mode.values()[Math.min(modeOrdinal, Mode.values().length - 1)];
        energyProgress = (input.method_10545("replicator.energy_progress") ? input.method_10537("replicator.energy_progress") : 0);
        fluidProgress = (input.method_10545("replicator.fluid_progress") ? input.method_10550("replicator.fluid_progress") : 0);
        String itemId = (input.method_10545("replicator.item_id") ? input.method_10558("replicator.item_id") : null);
        this.replicatingItemId = itemId != null ? class_2960.method_60654(itemId) : null;
        replicatingEnergyCost = (input.method_10545("replicator.energy_cost") ? input.method_10537("replicator.energy_cost") : 0);
        replicatingUUCost = (input.method_10545("replicator.uu_cost") ? input.method_10550("replicator.uu_cost") : 0);
        SingleVariantStorage.readNbt(fluidContainer, FluidVariant.CODEC, FluidVariant::blank, input, registries);
    }

    public void drops() {
        class_1264.method_17349(this.field_11863, this.field_11867, inventory);
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        if (slot == INPUT_SLOT) return stack.method_31574(GrowableOresItems.PATTERN_STORAGE_CRYSTAL);
        if (slot == FLUID_ITEM_SLOT) return true; // Fluid containers (UU matter)
        if (slot == ENERGY_ITEM_SLOT) return true;
        return slot >= UPGRADE_START && slot <= UPGRADE_END;
    }

    @Override
    public int[] method_5494(net.minecraft.class_2350 direction) {
        if (direction != net.minecraft.class_2350.field_11033) {
            return new int[]{INPUT_SLOT, FLUID_ITEM_SLOT};
        } else {
            return new int[]{OUTPUT_SLOT, EMPTY_FLUID_ITEM_SLOT};
        }
    }
}
