package com.skniro.industrial_elixir.compat.rei.category;

import com.skniro.industrial_elixir.api.Helper;
import com.skniro.industrial_elixir.api.renderer.GuiFluidTankRenderer;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.compat.rei.display.CoffeeMachineDisplay;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import me.shedaniel.math.Point;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.gui.Renderer;
import me.shedaniel.rei.api.client.gui.widgets.Widget;
import me.shedaniel.rei.api.client.gui.widgets.Widgets;
import me.shedaniel.rei.api.client.registry.display.DisplayCategory;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;

public class CoffeeMachineCategory implements DisplayCategory<CoffeeMachineDisplay> {
    public static final class_2960 TEXTURE = Helper.id("textures/gui/container/machine/coffee_machine.png");

    private final GuiFluidTankRenderer fluidRenderer = new GuiFluidTankRenderer(1000, true, 16, 50);

    @Override
    public CategoryIdentifier<? extends CoffeeMachineDisplay> getCategoryIdentifier() {
        return CoffeeMachineDisplay.COFFEE_MACHINE;
    }

    @Override
    public class_2561 getTitle() {
        return class_2561.method_43471(FurnitureStrings.CoffeeMachine);
    }

    @Override
    public Renderer getIcon() {
        return EntryStacks.of(new class_1799(GrowableOresBlocks.COFFEE_MACHINE_Block));
    }

    @Override
    public List<Widget> setupDisplay(CoffeeMachineDisplay display, Rectangle bounds) {
        Point startPoint = new Point(bounds.getCenterX() - 87, bounds.getCenterY() - 35);
        List<Widget> widgets = new ArrayList<>();

        widgets.add(Widgets.createTexturedWidget(TEXTURE, new Rectangle(startPoint.x, startPoint.y, 175, 82), 0, 0));

        widgets.add(Widgets.createTexturedWidget(TEXTURE,
                new Rectangle(startPoint.x + 129, startPoint.y + 45, 13, 16),
                176, 0));

        widgets.add(Widgets.createSlot(new Point(startPoint.x + 52, startPoint.y + 15))
                .entries(display.getInputEntries().get(0)).markInput());

        if (display.getInputEntries().size() > 1) {
            widgets.add(Widgets.createSlot(new Point(startPoint.x + 52, startPoint.y + 33))
                    .entries(display.getInputEntries().get(1)).markInput());
        }

        if (display.getInputEntries().size() > 2) {
            widgets.add(Widgets.createSlot(new Point(startPoint.x + 52, startPoint.y + 51))
                    .entries(display.getInputEntries().get(2)).markInput());
        }

        widgets.add(Widgets.createSlot(new Point(startPoint.x + 104, startPoint.y + 34))
                .entries(display.getOutputEntries().get(0)).disableBackground().markOutput());

        widgets.add(Widgets.createDrawableWidget((context, mouseX, mouseY, delta) -> {
            long tick = System.currentTimeMillis() / 50;
            int progress = (int) ((tick % 72) * 24 / 72);
            context.method_25290(TEXTURE, startPoint.x + 70, startPoint.y + 34, 189, 0, progress, 16, 256, 256);

            var storage = getFluid(display);
            fluidRenderer.render(context, startPoint.x + 8, startPoint.y + 5, storage);

            int count = display.getCount();
            if (count > 1) {
                class_327 font = class_310.method_1551().field_1772;
                String text = String.valueOf(count);
                context.method_51433(font, text, startPoint.x + 52 + 16 - font.method_1727(text) - 1, startPoint.y + 15 + 16 - 8 - 1, 0xFFFFFFFF, true);
            }
        }));

        return widgets;
    }

    private SingleVariantStorage<FluidVariant> getFluid(CoffeeMachineDisplay display) {
        class_2960 fluidId = display.getFluid();
        int amount = display.getFluidAmount();
        class_3611 fluid = class_7923.field_41173.method_17966(fluidId).orElse(class_3612.field_15906);

        return new SingleVariantStorage<>() {
            @Override
            protected FluidVariant getBlankVariant() {
                return FluidVariant.blank();
            }

            @Override
            protected long getCapacity(FluidVariant variant) {
                return 1000;
            }

            {
                this.variant = FluidVariant.of(fluid);
                this.amount = amount;
            }
        };
    }

    @Override
    public int getDisplayHeight() {
        return 90;
    }
}
