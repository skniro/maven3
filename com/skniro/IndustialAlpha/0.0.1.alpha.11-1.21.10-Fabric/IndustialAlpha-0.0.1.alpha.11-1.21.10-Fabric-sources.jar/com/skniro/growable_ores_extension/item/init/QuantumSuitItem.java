package com.skniro.growable_ores_extension.item.init;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.api.item.TieredEnergyItem;
import com.skniro.growable_ores_extension.energy.api.EnergyStorage;
import com.skniro.growable_ores_extension.energy.api.base.SimpleEnergyItem;
import org.jetbrains.annotations.Nullable;

import javax.management.Attribute;
import net.minecraft.class_10712;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3902;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_8051;
import net.minecraft.class_9334;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

public class QuantumSuitItem extends class_1792 implements SimpleEnergyItem, TieredEnergyItem {

    public static final long CAPACITY = 10_000_000;
    private class_8051 slotType;
    private EnergyTier energyTier;

    private final ImmutableMultimap<class_6880<class_1320>, class_1322> noPowerAttributes;
    private final ImmutableMultimap<class_6880<class_1320>, class_1322> hasPowerAttributes;
    private final ImmutableMultimap<class_6880<class_1320>, class_1322> fullSuitAttributes;

    public QuantumSuitItem(class_1792.class_1793 settings,class_1741 material, class_8051 slotType, EnergyTier energyTier) {
        super(settings.method_7889(1).method_66332(material, slotType).method_57349(class_9334.field_49630, class_3902.field_17274).method_57349(class_9334.field_56400, UNBREAKABLE_HIDE));
        this.energyTier = energyTier;
        this.slotType = slotType;
        switch (slotType) {
            case field_41934, field_41937 -> {
                noPowerAttributes = createAttrs(0, 0, 0, 0);
                hasPowerAttributes = createAttrs(3, 3, 0.05, 0);
                fullSuitAttributes = createAttrs(5, 5, 0.1, 0);
            }
            case field_41935 -> {
                noPowerAttributes = createAttrs(0, 0, 0, 0);
                hasPowerAttributes = createAttrs(6, 3, 0.1, 0);
                fullSuitAttributes = createAttrs(10, 5, 0.15, 0);
            }
            case field_41936 -> {
                noPowerAttributes = createAttrs(0, 0, 0, 0);
                hasPowerAttributes = createAttrs(8, 3, 0.05, 0.15);
                fullSuitAttributes = createAttrs(10, 5, 0.1, 0.15);
            }
            default -> throw new IllegalArgumentException("Invalid slot type");
        }

        EnergyStorage.ITEM.registerForItems((stack, context) -> SimpleEnergyItem.createStorage(context, this.getEnergyCapacity(stack), this.getEnergyMaxInput(stack), this.getEnergyMaxOutput(stack)), this);
    }

    private static ImmutableMultimap<class_6880<class_1320>, class_1322> createAttrs(
            double armor, double toughness, double knockback, double speed
    ) {
        ImmutableMultimap.Builder<class_6880<class_1320>, class_1322> builder = ImmutableMultimap.builder();

        if (armor > 0) {
            builder.put(class_5134.field_23724,
                    new class_1322(class_2960.method_60655(GrowableOresExtension.MOD_ID, "armor"), armor, class_1322.class_1323.field_6328));
        }
        if (toughness > 0) {
            builder.put(class_5134.field_23725,
                    new class_1322(class_2960.method_60655(GrowableOresExtension.MOD_ID, "toughness"), toughness, class_1322.class_1323.field_6328));
        }
        if (knockback > 0) {
            builder.put(class_5134.field_23718,
                    new class_1322(class_2960.method_60655(GrowableOresExtension.MOD_ID, "knockback"), knockback, class_1322.class_1323.field_6328));
        }
        if (speed > 0) {
            builder.put(class_5134.field_23719,
                    new class_1322(class_2960.method_60655(GrowableOresExtension.MOD_ID,"speed"), speed, class_1322.class_1323.field_6328));
        }

        return builder.build();
    }

    @Override
    public long getEnergyCapacity(class_1799 stack) {
        return CAPACITY;
    }

    @Override
    public long getEnergyMaxInput(class_1799 stack) {
        return energyTier.getMaxInput();
    }

    @Override
    public long getEnergyMaxOutput(class_1799 stack) {
        return 0;
    }

    @Override
    public int method_31569(class_1799 stack) {
        return getPowerForDurabilityBar(stack);
    }

    public boolean method_31567(class_1799 stack) {
        return true;
    }

    public static int getPowerForDurabilityBar(class_1799 stack) {
        class_1792 var2 = stack.method_7909();
        if (var2 instanceof QuantumSuitItem energyItem) {
            return Math.round((float)energyItem.getStoredEnergy(stack) * 100.0F / (float)energyItem.getEnergyCapacity(stack) * 13.0F) / 100;
        } else {
            throw new UnsupportedOperationException();
        }
    }

    public static int getColorForDurabilityBar(class_1799 stack) {
        return 16744454;
    }

    @Override
    public int method_31571(class_1799 stack) {
        return 0x00FFFF;
    }

    public void method_7888(class_1799 stack, class_3218 world, class_1297 entity, @Nullable class_1304 slot) {
        if(entity instanceof class_1657 player) {
            if (stack.method_7909() instanceof SimpleEnergyItem storage) {
                boolean powered = storage != null && storage.getStoredEnergy(stack) > 0;

                if (slot == class_1304.field_6169) {
                    if (player.method_5869() && powered) {
                        player.method_6092(new class_1293(class_1294.field_5923, 5, 1));
                    }
                    if (powered) {
                        player.method_6092(new class_1293(class_1294.field_5925, 220, 1, false, false));
                    } else {
                        player.method_6016(class_1294.field_5925);
                    }
                }

                if (slot == class_1304.field_6174) {
                    player.method_31549().field_7478 = powered;
                    if (player.method_5809() && powered) player.method_6012();
                }

                if (slot == class_1304.field_6172 && powered && player.method_5624() && storage != null) {
                    //storage.extract(10);
                }

                if (slot == class_1304.field_6172 && powered && player.method_5681()) {
                    player.method_6092(new class_1293(class_1294.field_5900, 5, 1, true, false));
                }

            }
        }
    }

    public void onUnequip(class_1657 player) {
        class_8051 slot = slotType;

        if (slot == class_8051.field_41935) player.method_31549().field_7478 = false;
        if (slot == class_8051.field_41934) player.method_6016(class_1294.field_5925);
    }

    @Override
    public EnergyTier getEnergyTier() {
        return energyTier;
    }

    public static class_10712 UNBREAKABLE_HIDE = new class_10712(
            false, new LinkedHashSet<>(Set.of(class_9334.field_49630))
    );
}