package com.skniro.growable_ores_extension.api.data.family;

import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.MapleSignBlocks;
import net.minecraft.class_5794;

public class GrowableOresBlockFamilies {

    public static final class_5794 RUBBER_PLANKS = new class_5794.class_5795(GeneralBlocks.Rubber_PLANKS)
            .method_33482(GeneralBlocks.Rubber_BUTTON)
            .method_33490(GeneralBlocks.Rubber_FENCE)
            .method_33491(GeneralBlocks.Rubber_FENCE_GATE)
            .method_33494(GeneralBlocks.Rubber_PRESSURE_PLATE)
            .method_33483(MapleSignBlocks.Rubber_SIGN, MapleSignBlocks.Rubber_WALL_SIGN)
            .method_33492(GeneralBlocks.Rubber_SLAB)
            .method_33493(GeneralBlocks.Rubber_STAIRS)
            .method_33489(GeneralBlocks.Rubber_DOOR)
            .method_33496(GeneralBlocks.Rubber_TRAPDOOR)
            .method_33481();
}