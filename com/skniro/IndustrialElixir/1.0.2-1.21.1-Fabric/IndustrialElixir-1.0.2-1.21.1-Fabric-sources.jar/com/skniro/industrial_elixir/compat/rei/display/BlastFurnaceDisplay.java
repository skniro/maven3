package com.skniro.industrial_elixir.compat.rei.display;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.recipe.machine.ModBlastFurnaceCraftingRecipe;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2960;
import net.minecraft.class_8786;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BlastFurnaceDisplay extends BasicDisplay {
    private final int count;
    private final class_2960 fluid;
    private final int fluidAmount;

    public static final CategoryIdentifier<BlastFurnaceDisplay> BLAST_FURNACE =
            CategoryIdentifier.of(IndustrialElixir.MOD_ID, "blast_furnace");

    public static final DisplaySerializer<BlastFurnaceDisplay> SERIALIZER = BasicDisplay.Serializer.<BlastFurnaceDisplay>of(
            (inputs, outputs, location, tag) -> new BlastFurnaceDisplay(inputs, outputs, location, tag.method_10550("count"),
                    class_2960.method_60654(tag.method_10558("fluid")), tag.method_10550("fluid_amount")),
            (display, tag) -> {
                tag.method_10569("count", display.getCount());
                tag.method_10582("fluid", display.getFluid().toString());
                tag.method_10569("fluid_amount", display.getFluidAmount());
            }
    );

    public BlastFurnaceDisplay(ModBlastFurnaceCraftingRecipe recipe) {
        this(
                List.of(EntryIngredients.ofIngredient(recipe.ingredient())),
                buildOutputs(recipe),
                Optional.empty(),
                recipe.requiredCount(),
                recipe.requiredFluid(),
                recipe.requiredFluidAmount()
        );
    }

    public BlastFurnaceDisplay(class_8786<ModBlastFurnaceCraftingRecipe> recipe) {
        super(
                List.of(EntryIngredients.ofIngredient(recipe.comp_1933().ingredient())),
                buildOutputs(recipe.comp_1933()));
        this.count = recipe.comp_1933().requiredCount();
        this.fluid = recipe.comp_1933().requiredFluid();
        this.fluidAmount = recipe.comp_1933().requiredFluidAmount();
    }

    public BlastFurnaceDisplay(List<EntryIngredient> inputs, List<EntryIngredient> outputs, Optional<class_2960> location, int count, class_2960 fluid, int fluidAmount) {
        super(inputs, outputs, location);
        this.count = count;
        this.fluid = fluid;
        this.fluidAmount = fluidAmount;
    }

    private static List<EntryIngredient> buildOutputs(ModBlastFurnaceCraftingRecipe recipe) {
        List<EntryIngredient> outputs = new ArrayList<>();
        outputs.add(EntryIngredient.of(EntryStacks.of(recipe.output())));
        recipe.output2().ifPresent(o -> outputs.add(EntryIngredient.of(EntryStacks.of(o))));
        return outputs;
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return BLAST_FURNACE;
    }


    public int getCount() {
        return count;
    }

    public class_2960 getFluid() {
        return fluid;
    }

    public int getFluidAmount() {
        return fluidAmount;
    }
}
