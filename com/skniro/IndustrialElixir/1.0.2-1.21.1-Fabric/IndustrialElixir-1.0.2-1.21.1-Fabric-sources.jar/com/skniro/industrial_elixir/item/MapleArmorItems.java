package com.skniro.industrial_elixir.item;

import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.MapleSignBlocks;
import com.skniro.industrial_elixir.item.init.QuantumSuitItem;
import com.skniro.industrial_elixir.item.init.ElectricJetpackItem;
import com.skniro.industrial_elixir.item.init.RollingCuttingToolItem;
import com.skniro.industrial_elixir.item.init.equipment.MapleArmorMaterials;
import com.skniro.industrial_elixir.item.init.tool.MapleToolMaterials;
import java.util.function.Function;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1822;
import net.minecraft.class_1829;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7707;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class MapleArmorItems {
    //Durability multipliers for the custom armour sets (equivalent to the values 26.1 stored on ArmorMaterial).
    private static final int QUANTUM_DURABILITY = 37;
    private static final int BRONZE_DURABILITY = 15;
    private static final int ELECTRIC_JETPACK_DURABILITY = 12;

    //Tool
    public static final class_1792 BRONZE_HELMET = registerItem("bronze_helmet", (settings) -> new class_1738(MapleArmorMaterials.BRONZE, class_1738.class_8051.field_41934, settings), (new class_1792.class_1793()).method_7895(class_1738.class_8051.field_41934.method_56690(BRONZE_DURABILITY)));
    public static final class_1792 BRONZE_CHESTPLATE = registerItem("bronze_chestplate", (settings) -> new class_1738(MapleArmorMaterials.BRONZE, class_1738.class_8051.field_41935, settings), (new class_1792.class_1793()).method_7895(class_1738.class_8051.field_41935.method_56690(BRONZE_DURABILITY)));
    public static final class_1792 BRONZE_LEGGINGS = registerItem("bronze_leggings", (settings) -> new class_1738(MapleArmorMaterials.BRONZE, class_1738.class_8051.field_41936, settings), (new class_1792.class_1793()).method_7895(class_1738.class_8051.field_41936.method_56690(BRONZE_DURABILITY)));
    public static final class_1792 BRONZE_BOOTS = registerItem("bronze_boots", (settings) -> new class_1738(MapleArmorMaterials.BRONZE, class_1738.class_8051.field_41937, settings), (new class_1792.class_1793()).method_7895(class_1738.class_8051.field_41937.method_56690(BRONZE_DURABILITY)));

    public static final class_1792 BRONZE_SWORD = registerItem("bronze_sword", (settings) -> new class_1829(MapleToolMaterials.BRONZE, settings), new class_1792.class_1793());
    public static final class_1792 BRONZE_SHOVEL = registerItem("bronze_shovel", (settings) -> new class_1821(MapleToolMaterials.BRONZE, settings), new class_1792.class_1793());
    public static final class_1792 BRONZE_PICKAXE = registerItem("bronze_pickaxe", (settings) -> new class_1810(MapleToolMaterials.BRONZE, settings), new class_1792.class_1793());
    public static final class_1792 BRONZE_AXE = registerItem("bronze_axe", (settings) -> new class_1743(MapleToolMaterials.BRONZE, settings), new class_1792.class_1793());
    public static final class_1792 BRONZE_HOE = registerItem("bronze_hoe", (settings) -> new class_1794(MapleToolMaterials.BRONZE, settings), new class_1792.class_1793());

    public static final class_1792 Rubber_SIGN = registerItem("rubber_sign",
            (settings)-> new class_1822(settings, MapleSignBlocks.Rubber_SIGN, MapleSignBlocks.Rubber_WALL_SIGN), new class_1792.class_1793().method_7889(16));

    public static final class_1792 Rubber_HANGING_SIGN = registerItem("rubber_hanging_sign", (settings)-> new class_7707(
            MapleSignBlocks.Rubber_HANGING_SIGN, MapleSignBlocks.Rubber_WALL_HANGING_SIGN, settings), new class_1792.class_1793().method_7889(16));

    public static final class_1792 ROLLING = registerItem("tool_rolling", RollingCuttingToolItem::new, new class_1792.class_1793());
    public static final class_1792 CUTTING = registerItem("tool_cutting", RollingCuttingToolItem::new, new class_1792.class_1793());

    //Armor
    public static final class_1792 Quantum_HELMET = registerItem("quantum_helmet", (settings)-> new QuantumSuitItem(settings, MapleArmorMaterials.QUANTUM, class_1738.class_8051.field_41934, EnergyTier.TIER5), new class_1792.class_1793().method_7895(class_1738.class_8051.field_41934.method_56690(QUANTUM_DURABILITY)));
    public static final class_1792 Quantum_CHESTPLATE = registerItem("quantum_chestplate", (settings)-> new QuantumSuitItem(settings, MapleArmorMaterials.QUANTUM, class_1738.class_8051.field_41935, EnergyTier.TIER5), new class_1792.class_1793().method_7895(class_1738.class_8051.field_41935.method_56690(QUANTUM_DURABILITY)));
    public static final class_1792 Quantum_LEGGINGS = registerItem("quantum_leggings", (settings)-> new QuantumSuitItem(settings, MapleArmorMaterials.QUANTUM, class_1738.class_8051.field_41936, EnergyTier.TIER5), new class_1792.class_1793().method_7895(class_1738.class_8051.field_41936.method_56690(QUANTUM_DURABILITY)));
    public static final class_1792 Quantum_BOOTS = registerItem("quantum_boots", (settings)-> new QuantumSuitItem(settings, MapleArmorMaterials.QUANTUM, class_1738.class_8051.field_41937, EnergyTier.TIER5), new class_1792.class_1793().method_7895(class_1738.class_8051.field_41937.method_56690(QUANTUM_DURABILITY)));

    public static final class_1792 Electric_Jetpack = registerItem("electric_jetpack", (settings)-> new ElectricJetpackItem(settings, MapleArmorMaterials.ELECTRIC_JETPACK, class_1738.class_8051.field_41935, EnergyTier.TIER3), new class_1792.class_1793().method_7895(class_1738.class_8051.field_41935.method_56690(ELECTRIC_JETPACK_DURABILITY)));

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings);
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(IndustrialElixir.MOD_ID, name)), item);
    }

    public static void registerMapleArmorItems() {
        IndustrialElixir.LOGGER.info("Registering Maple armor items for " + IndustrialElixir.MOD_ID);
    }
}
