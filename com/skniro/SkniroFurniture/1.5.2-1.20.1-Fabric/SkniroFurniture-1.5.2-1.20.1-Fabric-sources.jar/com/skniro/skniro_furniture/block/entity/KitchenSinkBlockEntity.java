package com.skniro.skniro_furniture.block.entity;

import com.skniro.skniro_furniture.block.api.entity.ImplementedInventory;
import com.skniro.skniro_furniture.init.FurnitureStrings;
import com.skniro.skniro_furniture.recipe.FurnitureRecipeType;
import com.skniro.skniro_furniture.recipe.KitchenSinkRecipe;
import com.skniro.skniro_furniture.screen.KitchenSinkBlockScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1262;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class KitchenSinkBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory, ImplementedInventory {
    private final class_2371<class_1799> inventory = class_2371.method_10213(4, class_1799.field_8037);
    private float rotation = 0;
    private static final int INPUT_SLOT = 0;
    private static final int OUTPUT_SLOT = 1;

    protected final class_3913 propertyDelegate;
    private int progress = 0;
    private int maxProgress = 72;
    private final int DEFAULT_MAX_PROGRESS = 72;

    public KitchenSinkBlockEntity(class_2338 pos, class_2680 state) {
        super(FurnitureBlockEntityType.Kitchen_Sink_BLOCK_ENTITY, pos, state);
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> KitchenSinkBlockEntity.this.progress;
                    case 1 -> KitchenSinkBlockEntity.this.maxProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: KitchenSinkBlockEntity.this.progress = value;
                    case 1: KitchenSinkBlockEntity.this.maxProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };
    }

    public class_1799 getRenderStack() {
        if (this.method_5438(INPUT_SLOT).method_7960()){
            return this.method_5438(OUTPUT_SLOT);
        } else {
            return this.method_5438(INPUT_SLOT);
        }
    }

    @Override
    public void method_5431() {
        field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        super.method_5431();
    }

    @Override
    public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
        buf.method_10807(this.field_11867);
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Kitchen_Sink);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new KitchenSinkBlockScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        super.method_11007(nbt);
        class_1262.method_5426(nbt, inventory);
        nbt.method_10569("kitchen_sink.progress", progress);
        nbt.method_10569("kitchen_sink.max_progress", maxProgress);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        class_1262.method_5429(nbt, inventory);
        progress = nbt.method_10550("kitchen_sink.progress");
        maxProgress = nbt.method_10550("kitchen_sink.max_progress");
        super.method_11014(nbt);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if(world.method_8608()) {
            return;
        }
        if(hasRecipe() && canInsertIntoOutputSlot()) {
            increaseCraftingProgress();
            method_31663(world, pos, state);

            if(hasCraftingFinished()) {
                craftItem();
                resetProgress();
            }
        } else {
            resetProgress();
        }
    }


    private void resetProgress() {
        this.progress = 0;
        this.maxProgress = DEFAULT_MAX_PROGRESS;
    }

    private void craftItem() {
        Optional<KitchenSinkRecipe> recipe = getCurrentRecipe();
        this.method_5434(INPUT_SLOT, 1);
        this.method_5447(OUTPUT_SLOT, new class_1799(recipe.get().method_8110(null).method_7909(),
                this.method_5438(OUTPUT_SLOT).method_7947() + recipe.get().method_8110(null).method_7947()));
    }

    @Override
    public int[] method_5494(class_2350 direction) {
        if (direction != class_2350.field_11033) {
            return new int[]{INPUT_SLOT};
        } else {
            return new int[]{OUTPUT_SLOT};
        }
    }
    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return slot != OUTPUT_SLOT;
    }

    private boolean hasCraftingFinished() {
        return this.progress >= this.maxProgress;
    }

    private void increaseCraftingProgress() {
        this.progress++;
    }

    private boolean canInsertIntoOutputSlot() {
        return this.method_5438(OUTPUT_SLOT).method_7960() ||
                this.method_5438(OUTPUT_SLOT).method_7947() < this.method_5438(OUTPUT_SLOT).method_7914();
    }

    private boolean hasRecipe() {
        Optional<KitchenSinkRecipe> recipe = getCurrentRecipe();
        if(recipe.isEmpty()) {
            return false;
        }

        class_1799 output = recipe.get().method_8110(null);
        return canInsertAmountIntoOutputSlot(output.method_7947()) && canInsertItemIntoOutputSlot(output);
    }

    private Optional<KitchenSinkRecipe> getCurrentRecipe() {
        class_1277 inv = new class_1277(this.method_5439());
        for(int i = 0; i < this.method_5439(); i++) {
            inv.method_5447(i, this.method_5438(i));
        }
        return this.method_10997().method_8433()
                .method_8132(FurnitureRecipeType.Kitchen_Sink_TYPE, inv, this.method_10997());
    }

    private boolean canInsertItemIntoOutputSlot(class_1799 output) {
        return this.method_5438(OUTPUT_SLOT).method_7960() || this.method_5438(OUTPUT_SLOT).method_7909() == output.method_7909();
    }

    private boolean canInsertAmountIntoOutputSlot(int count) {
    int maxCount = this.method_5438(OUTPUT_SLOT).method_7960() ? 64 : this.method_5438(OUTPUT_SLOT).method_7914();
    int currentCount = this.method_5438(OUTPUT_SLOT).method_7947();

        return maxCount >= currentCount + count;
}

   @Nullable
   @Override
    public class_2596<class_2602> method_38235() {
    return class_2622.method_38585(this);
}


    @Override
    public class_2487 method_16887() {
        return method_38244();
    }
}
