package com.skniro.growable_ores_extension.block;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.block.entity.MapleSignTypes;
import com.skniro.growable_ores_extension.block.init.LogCropBlock;
import com.skniro.growable_ores_extension.block.init.MapleBlockSetType;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.world.Tree.RubberSaplingGenerator;
import net.minecraft.block.*;
import net.minecraft.class_10716;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2362;
import net.minecraft.class_2378;
import net.minecraft.class_2431;
import net.minecraft.class_2440;
import net.minecraft.class_2465;
import net.minecraft.class_2473;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_6019;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8177;
import java.util.function.Function;

public class NetherOresBlocks {
    public static final class_2248 Lead_Ore = registerBlock("lead_ore", (settings)-> new class_2431(class_6019.method_35017(2, 4), settings),class_4970.class_2251.method_9630(class_2246.field_10418));
    public static final class_2248 Tin_Ore = registerBlock("tin_ore", (settings)-> new class_2431(class_6019.method_35017(2, 4), settings),class_4970.class_2251.method_9630(class_2246.field_10418));
    public static final class_2248 Uranium_Ore = registerBlock("uranium_ore", (settings)-> new class_2431(class_6019.method_35017(2, 4), settings),class_4970.class_2251.method_9630(class_2246.field_10418));
    public static final class_2248 Deepslate_Lead_Ore = registerBlock("deepslate_lead_ore", (settings)-> new class_2431(class_6019.method_35017(2, 4), settings),class_4970.class_2251.method_9630(class_2246.field_10418));
    public static final class_2248 Deepslate_Tin_Ore = registerBlock("deepslate_tin_ore", (settings)-> new class_2431(class_6019.method_35017(2, 4), settings),class_4970.class_2251.method_9630(class_2246.field_10418));
    public static final class_2248 Deepslate_Uranium_Ore = registerBlock("deepslate_uranium_ore", (settings)-> new class_2431(class_6019.method_35017(2, 4), settings),class_4970.class_2251.method_9630(class_2246.field_10418));
    public static final class_2248 Raw_Lead_Block = registerBlock("raw_lead_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Raw_Tin_Block = registerBlock("raw_tin_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Raw_Uranium_Block = registerBlock("raw_uranium_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Lead_Block = registerBlock("lead_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Tin_Block = registerBlock("tin_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Uranium_Block = registerBlock("uranium_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Sliver_Block = registerBlock("sliver_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));
    public static final class_2248 Bronze_Block = registerBlock("bronze_block", class_2248::new, class_4970.class_2251.method_9637().method_31710(class_3620.field_15994).method_51368(class_2766.field_12653).method_29292().method_9629(5.0F, 6.0F));


    public static final class_2248 Rubber_SAPLING = registerBlock("rubber_sapling",
            (settings)-> new class_2473(RubberSaplingGenerator.RubberSapling, settings), class_4970.class_2251.method_55226(class_2246.field_10394));

    public static final class_2248 POTTED_Rubber_SAPLING = registerBlockWithoutItem("potted_rubber_sapling",
            (settings)-> new class_2362(Rubber_SAPLING, settings), class_4970.class_2251.method_9637().method_9618().method_22488());

    public static final class_2248 Rubber_LEAVES =registerBlock("rubber_leaves",
            (settings)-> new class_10716(0.1f, settings), (class_4970.class_2251.method_9630(class_2246.field_10503).method_31710(class_3620.field_16028)));

    public static final class_2248 Rubber_Rubber_LOG =registerBlock("rubber_rubber_log",
            (settings)-> new LogCropBlock(settings, GrowableOresItems.Rubber), class_4970.class_2251.method_9637().method_22488().method_31710(class_3620.field_16012));

    public static final class_2248 Rubber_LOG = registerBlock("rubber_log",class_2465::new, (class_4970.class_2251.method_9630(class_2246.field_10431).method_31710(class_3620.field_15977)));
    public static final class_2248 STRIPPED_Rubber_LOG = registerBlock("stripped_rubber_log",
            class_2465::new, (class_4970.class_2251.method_9630(class_2246.field_10519).method_31710(class_3620.field_15977)));
    public static final class_2248 STRIPPED_Rubber_WOOD = registerBlock("stripped_rubber_wood",
            class_2465::new, (class_4970.class_2251.method_9630(class_2246.field_10250).method_31710(class_3620.field_15977)));
    public static final class_2248 Rubber_WOOD = registerBlock("rubber_wood",
            class_2465::new, (class_4970.class_2251.method_9630(class_2246.field_10126).method_31710(class_3620.field_15977)));

    public static final class_2248 Rubber_PLANKS = registerBlock("rubber_planks",
            class_2248::new, (class_4970.class_2251.method_9630(class_2246.field_10161).method_31710(class_3620.field_15977)));
    public static final class_2248 Rubber_BUTTON = registerBlock("rubber_button",
            (settings)-> new class_2269(MapleBlockSetType.Rubber,30, settings), class_2246.method_63117());
    public static final class_2248 Rubber_STAIRS = registerBlock("rubber_stairs",
            (settings)-> new class_2510(class_2246.field_10161.method_9564(), settings), class_4970.class_2251.method_9630(class_2246.field_10161));
    public static final class_2248 Rubber_SLAB = registerBlock("rubber_slab",
            class_2482::new, (class_4970.class_2251.method_9637().method_31710(class_3620.field_15992).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547)));
    public static final class_2248 Rubber_FENCE_GATE = registerBlock("rubber_fence_gate",
            (settings)-> new class_2349(MapleSignTypes.Rubber, settings),  class_4970.class_2251.method_9637().method_31710(Rubber_PLANKS.method_26403()).method_9629(2.0F, 3.0F));
    public static final class_2248 Rubber_FENCE = registerBlock("rubber_fence",
            class_2354::new, (class_4970.class_2251.method_9637().method_31710(Rubber_PLANKS.method_26403()).method_9629(2.0F, 3.0F).method_9626(class_2498.field_11547)));
    public static final class_2248 Rubber_DOOR = registerBlock("rubber_door",
            (settings)-> new class_2323(class_8177.field_42827, settings), class_4970.class_2251.method_9637().method_31710(Rubber_PLANKS.method_26403()).method_9632(3.0f).method_9626(class_2498.field_11547).method_22488());
    public static final class_2248 Rubber_TRAPDOOR = registerBlock("rubber_trapdoor",
            (settings)-> new class_2533(MapleBlockSetType.Rubber, settings),class_4970.class_2251.method_9637().method_31710(class_3620.field_15992).method_9632(3.0F).method_22488());
    public static final class_2248 Rubber_PRESSURE_PLATE = registerBlock("rubber_pressure_plate",
            (settings)-> new class_2440(MapleBlockSetType.Rubber, settings), class_4970.class_2251.method_9637().method_31710(
                    Rubber_PLANKS.method_26403()).method_9634().method_9632(0.5F).method_50013().method_51368(class_2766.field_12651).method_50012(class_3619.field_15971));

    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GrowableOresExtension.MOD_ID, name))));
        registerBlockItem(name, block);
        return class_2378.method_39197(class_7923.field_41175, class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block) {
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)))));
    }

    private static class_2248 registerBlockWithoutItem(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(keyOf(name)));
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }

    private static class_5321<class_2248> keyOf(String name) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(GrowableOresExtension.MOD_ID, name));
    }

    public static void registerNetherOresBlock() {
        GrowableOresExtension.LOGGER.info("register Mod Nether Ores Blocks"+ GrowableOresExtension.MOD_ID);
    }
}
