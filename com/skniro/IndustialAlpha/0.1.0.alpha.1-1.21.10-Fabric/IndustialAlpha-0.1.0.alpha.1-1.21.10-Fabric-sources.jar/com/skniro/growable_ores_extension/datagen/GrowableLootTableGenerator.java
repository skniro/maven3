package com.skniro.growable_ores_extension.datagen;


import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.MapleSignBlocks;
import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growableoresir.block.GrowableICOresBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;


public class GrowableLootTableGenerator extends FabricBlockLootTableProvider {
    protected GrowableLootTableGenerator(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }
    public static final float[] field_40605 = new float[]{0.048F, 0.0425F, 0.062333336F, 0.1F};


    @Override
    public void method_10379() {
        //MAPLE
        method_46025(MapleSignBlocks.Rubber_SIGN);
        method_46025(MapleSignBlocks.Rubber_WALL_SIGN);
        method_46025(MapleSignBlocks.Rubber_HANGING_SIGN);
        method_46025(MapleSignBlocks.Rubber_WALL_HANGING_SIGN);
        method_46025(GeneralBlocks.Rubber_LOG);
        method_46025(GeneralBlocks.Rubber_Rubber_LOG);
        method_46025(GeneralBlocks.Rubber_WOOD);
        method_45988(GeneralBlocks.Rubber_DOOR, method_46022(GeneralBlocks.Rubber_DOOR));
        method_46025(GeneralBlocks.Rubber_SAPLING);
        method_45988(GeneralBlocks.Rubber_LEAVES, method_45986(GeneralBlocks.Rubber_LEAVES, GeneralBlocks.Rubber_SAPLING, field_40605));
        method_46025(GeneralBlocks.Rubber_BUTTON);
        method_46025(GeneralBlocks.Rubber_FENCE);
        method_46025(GeneralBlocks.Rubber_FENCE_GATE);
        method_46025(GeneralBlocks.Rubber_PLANKS);
        method_46025(GeneralBlocks.Rubber_PRESSURE_PLATE);
        method_46025(GeneralBlocks.Rubber_SLAB);
        method_46025(GeneralBlocks.Rubber_STAIRS);
        method_46025(GeneralBlocks.Rubber_TRAPDOOR);
        method_46025(GeneralBlocks.STRIPPED_Rubber_LOG);
        method_46025(GeneralBlocks.STRIPPED_Rubber_WOOD);
        method_46025(GeneralBlocks.Rubber_SHELF);

        method_46025(GeneralBlocks.Raw_Lead_Block);
        method_46025(GeneralBlocks.Raw_Tin_Block);
        method_46025(GeneralBlocks.Raw_Uranium_Block);

        method_46025(GeneralBlocks.Lead_Block);
        method_46025(GeneralBlocks.Tin_Block);
        method_46025(GeneralBlocks.Uranium_Block);

        method_46025(GeneralBlocks.Silver_Block);
        method_46025(GeneralBlocks.Bronze_Block);
        method_46025(GeneralBlocks.Steel_Block);

        method_46025(GeneralBlocks.Advanced_Machine);
        method_46025(GeneralBlocks.Machine);

        method_46025(GrowableOresBlocks.GrowableOres_Block);
        method_46025(GrowableOresBlocks.GrowableBox_Block);

        method_46025(GrowableOresBlocks.Macerator_Block);
        method_46025(GrowableOresBlocks.Compressor_Block);
        method_46025(GrowableOresBlocks.MetalFormerBlock);
        method_46025(GrowableOresBlocks.ElectricFurnace_Block);
        method_46025(GrowableOresBlocks.RECYCLER_Block);
        method_46025(GrowableOresBlocks.CUTTING_Block);

        method_46025(GrowableOresBlocks.COPPER_CABLE);
        method_46025(GrowableOresBlocks.TIN_CABLE);
        method_46025(GrowableOresBlocks.GOLD_CABLE);
        method_46025(GrowableOresBlocks.HV_CABLE);
        method_46025(GrowableOresBlocks.GLASSFIBER_CABLE);

        method_46025(GrowableOresBlocks.INSULATED_TIN_CABLE);
        method_46025(GrowableOresBlocks.INSULATED_COPPER_CABLE);
        method_46025(GrowableOresBlocks.INSULATED_GOLD_CABLE);
        method_46025(GrowableOresBlocks.INSULATED_HV_CABLE);

        method_46025(GrowableOresBlocks.COAL_GENERATOR);
        method_46025(GrowableOresBlocks.GENERATOR_Wind_Mill);

        method_46025(GrowableOresBlocks.EnergyBox);
        method_46025(GrowableOresBlocks.ChargePad);

        method_46025(GrowableOresBlocks.CESU);
        method_46025(GrowableOresBlocks.MFE);
        method_46025(GrowableOresBlocks.MFSU);

        method_46025(GrowableOresBlocks.CESU_CHARGE_PAD);
        method_46025(GrowableOresBlocks.MFE_CHARGE_PAD);
        method_46025(GrowableOresBlocks.MFSU_CHARGE_PAD);

        method_46025(GrowableOresBlocks.MolecularTransformerBlock);

        method_46025(GrowableOresBlocks.GENERATOR_SolarPanel);
        method_46025(GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL);
        method_46025(GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL);
        method_46025(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL);
        method_46025(GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL);

        method_46025(GrowableOresBlocks.Extractor_Block);

        method_46025(GrowableOresBlocks.EV_TRANSFORMER);
        method_46025(GrowableOresBlocks.HV_TRANSFORMER);
        method_46025(GrowableOresBlocks.MV_TRANSFORMER);
        method_46025(GrowableOresBlocks.LV_TRANSFORMER);

        method_46025(GrowableOresBlocks.Iron_Furnace_Block);

        method_45988(GeneralBlocks.Lead_Ore,
                method_45981(GeneralBlocks.Lead_Ore, GrowableOresItems.Raw_Lead));
        method_45988(GeneralBlocks.Tin_Ore,
                method_45981(GeneralBlocks.Tin_Ore, GrowableOresItems.Raw_Tin));
        method_45988(GeneralBlocks.Uranium_Ore,
                method_45981(GeneralBlocks.Uranium_Ore, GrowableOresItems.Raw_Uranium));
        method_45988(GeneralBlocks.Deepslate_Lead_Ore,
                method_45981(GeneralBlocks.Deepslate_Lead_Ore, GrowableOresItems.Raw_Lead));
        method_45988(GeneralBlocks.Deepslate_Tin_Ore,
                method_45981(GeneralBlocks.Deepslate_Tin_Ore, GrowableOresItems.Raw_Tin));
        method_45988(GeneralBlocks.Deepslate_Uranium_Ore,
                method_45981(GeneralBlocks.Deepslate_Uranium_Ore, GrowableOresItems.Raw_Uranium));






        method_46025(GrowableICOresBlocks.IC2_Bronze_Cane);
        method_46025(GrowableICOresBlocks.IC2_silver_Cane);
        method_46025(GrowableICOresBlocks.IC2_Tin_Cane);
        method_46025(GrowableICOresBlocks.IC2_Uranium_Cane);
        method_46025(GrowableICOresBlocks.IC2_steel_Cane);
        method_46025(GrowableICOresBlocks.IC2_LEAD_Cane);

    }
}
