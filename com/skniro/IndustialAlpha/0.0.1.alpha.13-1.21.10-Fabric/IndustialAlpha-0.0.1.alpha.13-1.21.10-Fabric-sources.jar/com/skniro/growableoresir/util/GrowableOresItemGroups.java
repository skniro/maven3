package com.skniro.growableoresir.util;

import com.skniro.growable_ores_extension.item.ModCreativeTab;
import com.skniro.growableoresir.block.GrowableICOresBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

public class GrowableOresItemGroups {
    public static void ic_item() {
        ItemGroupEvents.modifyEntriesEvent(ModCreativeTab.Materials).register(content -> {
            content.method_45421(GrowableICOresBlocks.IC2_Bronze_Cane);
            content.method_45421(GrowableICOresBlocks.IC2_silver_Cane);
            content.method_45421(GrowableICOresBlocks.IC2_Tin_Cane);
            content.method_45421(GrowableICOresBlocks.IC2_Uranium_Cane);
            content.method_45421(GrowableICOresBlocks.IC2_steel_Cane);
            content.method_45421(GrowableICOresBlocks.IC2_LEAD_Cane);
        });
    }
}
