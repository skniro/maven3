package com.skniro.industrial_elixir.compat.rei.display;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.recipe.machine.CoffeeMachineCraftingRecipe;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_2960;
import net.minecraft.class_8786;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CoffeeMachineDisplay extends BasicDisplay {
    private final int count;
    private final class_2960 fluid;
    private final int fluidAmount;

    public static final CategoryIdentifier<CoffeeMachineDisplay> COFFEE_MACHINE =
            CategoryIdentifier.of(IndustrialElixir.MOD_ID, "coffee_machine");

    public static final DisplaySerializer<CoffeeMachineDisplay> SERIALIZER = BasicDisplay.Serializer.<CoffeeMachineDisplay>of(
            (inputs, outputs, location, tag) -> new CoffeeMachineDisplay(inputs, outputs, location, tag.method_10550("count"),
                    class_2960.method_60654(tag.method_10558("fluid")), tag.method_10550("fluid_amount")),
            (display, tag) -> {
                tag.method_10569("count", display.getCount());
                tag.method_10582("fluid", display.getFluid().toString());
                tag.method_10569("fluid_amount", display.getFluidAmount());
            }
    );

    public CoffeeMachineDisplay(CoffeeMachineCraftingRecipe recipe) {
        this(
                buildInputs(recipe),
                List.of(EntryIngredients.of(recipe.output())),
                Optional.empty(),
                recipe.requiredCount(),
                recipe.requiredFluid(),
                recipe.requiredFluidAmount()
        );
    }

    public CoffeeMachineDisplay(class_8786<CoffeeMachineCraftingRecipe> recipe) {
        super(
                buildInputs(recipe.comp_1933()),
                List.of(EntryIngredient.of(EntryStacks.of(recipe.comp_1933().output()))));
        this.count = recipe.comp_1933().requiredCount();
        this.fluid = recipe.comp_1933().requiredFluid();
        this.fluidAmount = recipe.comp_1933().requiredFluidAmount();
    }

    public CoffeeMachineDisplay(List<EntryIngredient> inputs, List<EntryIngredient> outputs,
                                 Optional<class_2960> location, int count, class_2960 fluid, int fluidAmount) {
        super(inputs, outputs, location);
        this.count = count;
        this.fluid = fluid;
        this.fluidAmount = fluidAmount;
    }

    private static List<EntryIngredient> buildInputs(CoffeeMachineCraftingRecipe recipe) {
        List<EntryIngredient> inputs = new ArrayList<>();
        inputs.add(EntryIngredients.ofIngredient(recipe.ingredient()));
        recipe.ingredient2().ifPresent(i -> inputs.add(EntryIngredients.ofIngredient(i)));
        recipe.ingredient3().ifPresent(i -> inputs.add(EntryIngredients.ofIngredient(i)));
        return inputs;
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return COFFEE_MACHINE;
    }


    public int getCount() {
        return count;
    }

    public class_2960 getFluid() {
        return fluid;
    }

    public int getFluidAmount() {
        return fluidAmount;
    }
}
