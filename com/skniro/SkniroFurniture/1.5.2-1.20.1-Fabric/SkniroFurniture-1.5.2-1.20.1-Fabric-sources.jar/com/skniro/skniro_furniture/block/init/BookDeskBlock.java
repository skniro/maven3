package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import com.skniro.skniro_furniture.block.entity.BookDeskBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3489;
import net.minecraft.class_3726;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.util.*;
import org.jetbrains.annotations.Nullable;


public class BookDeskBlock extends class_2237 {
    private static final class_265 SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0);
    public static final class_2754<class_2350> FACING;
    public static final class_2746 HAS_BOOK;

    public BookDeskBlock(class_2251 settings) {
        super(settings);
        this.method_9590(((this.field_10647.method_11664()).method_11657(FACING, class_2350.field_11043)).method_11657(HAS_BOOK, false));
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return (class_2680) state.method_11657(FACING, rotation.method_10503((class_2350) state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345((class_2350) state.method_11654(FACING)));
    }

    @Override
    public boolean method_9526(class_2680 state) {
        return true;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_1937 world = ctx.method_8045();
        class_1799 itemStack = ctx.method_8041();
        class_1657 playerEntity = ctx.method_8036();
        boolean bl = false;
        if (!world.field_9236 && playerEntity != null && playerEntity.method_7338()) {
            class_2487 nbtCompound = class_1747.method_38072(itemStack);
            if (nbtCompound != null && nbtCompound.method_10545("Book")) {
                bl = true;
            }
        }

        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153()).method_11657(HAS_BOOK, bl);
    }


    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new BookDeskBlockEntity(pos, state);
    }

    public static boolean putBookIfAbsent(@Nullable class_1309 user, class_1937 world, class_2338 pos, class_2680 state, class_1799 stack) {
        if (!(Boolean) state.method_11654(HAS_BOOK)) {
            if (!world.method_8608()) {
                putBook(user, world, pos, state, stack);
            }

            return true;
        } else {
            return false;
        }
    }

    private static void putBook(@Nullable class_1309 user, class_1937 world, class_2338 pos, class_2680 state, class_1799 stack) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof BookDeskBlockEntity bookDeskBlockEntity) {
            bookDeskBlockEntity.setBook(stack.method_7971(1));
            setHasBook(user, world, pos, state, true);
            world.method_8396(null, pos, class_3417.field_17482, class_3419.field_15245, 1.0F, 1.0F);
        }

    }

    public static void setHasBook(@Nullable class_1297 user, class_1937 world, class_2338 pos, class_2680 state, boolean hasBook) {
        class_2680 blockState = state.method_11657(HAS_BOOK, hasBook);
        world.method_8652(pos, blockState, 3);
        world.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43286(user, blockState));
    }

    @Override
    public boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    public int method_9572(class_2680 state, class_1937 world, class_2338 pos) {
        if (state.method_11654(HAS_BOOK)) {
            class_2586 blockEntity = world.method_8321(pos);
            if (blockEntity instanceof BookDeskBlockEntity) {
                return ((BookDeskBlockEntity) blockEntity).getComparatorOutput();
            }
        }

        return 0;
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_1799 itemStack = player.method_5998(hand);
        if (state.method_11654(HAS_BOOK)) {
            if (!world.field_9236) {
                this.openScreen(world, pos, player);
            }

            return class_1269.method_29236(world.field_9236);
        }
        if (itemStack.method_31573(class_3489.field_21465)) {
            return putBookIfAbsent(player, world, pos, state, itemStack) ? class_1269.method_29236(world.field_9236) : class_1269.field_5811;
        }
        return itemStack.method_7960() ? class_1269.field_5811 : class_1269.field_21466;
    }

    @Override
    public @Nullable class_3908 method_17454(class_2680 state, class_1937 world, class_2338 pos) {
        return !(Boolean)state.method_11654(HAS_BOOK) ? null : super.method_17454(state, world, pos);
    }

    private void openScreen(class_1937 world, class_2338 pos, class_1657 player) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof BookDeskBlockEntity) {
            player.method_17355((BookDeskBlockEntity)blockEntity);
            player.method_7281(class_3468.field_17485);
        }

    }

    @Override
    public boolean method_9516(class_2680 state, class_1922 world, class_2338 pos, class_10 type) {
        return false;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, HAS_BOOK);
    }


    static {
        FACING = class_2741.field_12481;
        HAS_BOOK = class_2741.field_17393;
    }
}
