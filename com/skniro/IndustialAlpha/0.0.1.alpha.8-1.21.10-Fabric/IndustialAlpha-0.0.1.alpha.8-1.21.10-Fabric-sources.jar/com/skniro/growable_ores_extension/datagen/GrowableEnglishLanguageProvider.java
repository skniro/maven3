package com.skniro.growable_ores_extension.datagen;

import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class GrowableEnglishLanguageProvider extends FabricLanguageProvider {
    public GrowableEnglishLanguageProvider(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> registryLookup){
        super(dataGenerator,"en_us",registryLookup);
    }

    @Override
    public void generateTranslations(class_7225.class_7874 registryLookup, TranslationBuilder translationBuilder) {
        translationBuilder.add(FurnitureStrings.Macerator, "Macerator");
        translationBuilder.add(FurnitureStrings.CaneConverter, "Cane Converter");
        translationBuilder.add(FurnitureStrings.Compressor, "Compressor");
        translationBuilder.add(FurnitureStrings.MetalFormer, "Metal Former");
        translationBuilder.add(FurnitureStrings.GeneratorWindMill, "Wind Mill");
        translationBuilder.add(GrowableOresBlocks.GrowableOres_Block,"Cane Converter");
        translationBuilder.add(GrowableOresBlocks.GENERATOR_Wind_Mill,"Wind Mill");
    }
}
