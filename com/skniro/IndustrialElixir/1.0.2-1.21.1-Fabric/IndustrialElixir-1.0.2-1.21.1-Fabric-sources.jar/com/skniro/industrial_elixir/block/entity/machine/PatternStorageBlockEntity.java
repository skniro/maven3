package com.skniro.industrial_elixir.block.entity.machine;

import com.skniro.industrial_elixir.api.item.replicator.ReplicatorCost;
import com.skniro.industrial_elixir.api.item.replicator.ReplicatorValueMap;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import com.skniro.industrial_elixir.screen.handler.machine.PatternStorageScreenHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;

public class PatternStorageBlockEntity extends AbstractMachineEntity {
    private static final int SCAN_ENERGY_PER_TICK = 64;
    private static final int SCAN_MAX_PROGRESS = 120;

    // Scanned pattern data
    @Nullable
    private class_2960 scannedItemId;
    private int uuCost = 0;
    private int energyCost = 0;

    // Copy cooldown to prevent rapid clicks
    private int copyCooldown = 0;

    public PatternStorageBlockEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.PATTERN_STORAGE_BE, pos, state);
        this.maxProgress = SCAN_MAX_PROGRESS;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Pattern_Storage);
    }

    @Override
    public class_3956<?> getCurrentRecipeType() {
        return null;
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new PatternStorageScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }

    // Check if slot 1 contains a blank crystal (no pattern data)
    private boolean hasBlankCrystalInSlot() {
        class_1799 stack = inventory.get(INPUT_SLOT);
        if (!stack.method_31574(GrowableOresItems.PATTERN_STORAGE_CRYSTAL)) return false;
        return !hasPatternData(stack);
    }

    // Check if a crystal has pattern data stored
    public static boolean hasPatternData(class_1799 stack) {
        class_9279 data = stack.method_57825(class_9334.field_49628, class_9279.field_49302);
        return data.method_57461().method_10545("pattern_item");
    }

    // Read pattern data from a crystal
    @Nullable
    public static class_2960 getPatternItem(class_1799 stack) {
        class_2487 tag = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461();

        String id = tag.method_10558("pattern_item");
        return id.isEmpty() ? null : class_2960.method_12829(id);
    }

    // Read UU cost from a crystal
    public static int getPatternUUCost(class_1799 stack) {
        class_2487 custom = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461();;
        if (custom.method_10545("uu_cost")) {
            return custom.method_10550("uu_cost");
        }
        return 0;
    }

    // Read energy cost from a crystal
    public static int getPatternEnergyCost(class_1799 stack) {
        class_2487 custom = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461();;
        if (custom.method_10545("energy_cost")) {
            return custom.method_10550("energy_cost");
        }
        return 0;
    }

    public static void writePatternData(class_1799 stack, class_2960 itemId, int uu, int energy) {
        stack.method_57368(
                class_9334.field_49628,
                class_9279.field_49302,
                customData -> {
                    class_2487 tag = customData.method_57461();

                    tag.method_10582("pattern_item", itemId.toString());
                    tag.method_10569("uu_cost", uu);
                    tag.method_10569("energy_cost", energy);

                    return class_9279.method_57456(tag);
                }
        );
    }

    // Calculate matter costs - first check the ReplicatorValueMap, fallback to stack-size-based formula
    private void calculateCosts(class_1799 scannedItem) {
        class_1792 item = scannedItem.method_7909();

        ReplicatorCost registered = ReplicatorValueMap.get(item);
        if (registered != null) {
            this.uuCost = registered.uuCost();
            this.energyCost = (int) registered.energyCost();
        }
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if (world.method_8608()) return;

        charge(ENERGY_ITEM_SLOT);

        // Update scanned item from crystal in slot 1 for display
        class_1799 crystalSlot = inventory.get(INPUT_SLOT);
        if (!crystalSlot.method_7960() && hasPatternData(crystalSlot)) {
            class_2960 stored = getPatternItem(crystalSlot);
            if (stored != null && !stored.equals(this.scannedItemId)) {
                this.scannedItemId = stored;
                this.uuCost = getPatternUUCost(crystalSlot);
                this.energyCost = getPatternEnergyCost(crystalSlot);
            }
        }

        // Handle scanning process
        class_1799 scanItem = inventory.get(SECOND_INPUT_SLOT);
        boolean canScan = hasBlankCrystalInSlot()
                && !scanItem.method_7960()
                && !scanItem.method_31574(GrowableOresItems.PATTERN_STORAGE_CRYSTAL)
                && hasEnoughEnergyToCraft();

        if (canScan) {
            increaseCraftingProgress();
            useScanEnergy();
            method_31663(world, pos, state);

            if (hasCraftingFinished()) {
                // Complete the scan
                class_2960 itemId = class_7923.field_41178.method_10221(scanItem.method_7909());
                calculateCosts(scanItem);
                writePatternData(crystalSlot, itemId, uuCost, energyCost);
                this.scannedItemId = itemId;

                // Consume scanned item
                scanItem.method_7934(1);
                resetProgress();
            }
        } else if (!canScan && progress > 0) {
            resetProgress();
        }

        // Update copy cooldown
        if (copyCooldown > 0) {
            copyCooldown--;
        }

        boolean isWorking = progress > 0 && canScan;
        if (state.method_11654(AbstractMachineblock.LIT) != isWorking) {
            world.method_8652(pos, state.method_11657(AbstractMachineblock.LIT, isWorking), 3);
        }

        method_31663(world, pos, state);
    }

    // Called from screen handler when copy button is pressed
    public void copyPattern() {
        if (copyCooldown > 0) return;

        class_1799 sourceCrystal = inventory.get(INPUT_SLOT);
        class_1799 targetCrystal = inventory.get(OUTPUT_SLOT_2);

        if (sourceCrystal.method_7960() || !hasPatternData(sourceCrystal)) return;
        if (targetCrystal.method_7960() || !targetCrystal.method_31574(GrowableOresItems.PATTERN_STORAGE_CRYSTAL)) return;
        if (hasPatternData(targetCrystal)) return; // Target already has data

        class_2960 patternItem = getPatternItem(sourceCrystal);
        int uu = getPatternUUCost(sourceCrystal);
        int energy = getPatternEnergyCost(sourceCrystal);

        if (patternItem != null) {
            writePatternData(targetCrystal, patternItem, uu, energy);
            copyCooldown = 10;
            method_5431();
        }
    }

    private void useScanEnergy() {
        try (net.fabricmc.fabric.api.transfer.v1.transaction.Transaction tx =
                     net.fabricmc.fabric.api.transfer.v1.transaction.Transaction.openOuter()) {
            long effectiveUse = (long) (SCAN_ENERGY_PER_TICK * getScanEnergyMultiplier());
            energyContainer.getSideStorage(null).extract(effectiveUse, tx);
            tx.commit();
        }
    }

    private double getScanEnergyMultiplier() {
        double multiplier = 1.0;
        for (int i = UPGRADE_START; i <= UPGRADE_END; i++) {
            class_1799 stack = inventory.get(i);
            if (!stack.method_7960() && stack.method_7909() instanceof com.skniro.industrial_elixir.item.init.ItemUpgradeModule u) {
                multiplier = u.getEnergyDemandMultiplier(stack);
            }
        }
        return multiplier;
    }

    // ---- Getters for display ----
    @Nullable
    public class_2960 getScannedItemId() {
        return scannedItemId;
    }

    public int getUUCost() {
        return uuCost;
    }

    public int getEnergyCost() {
        return energyCost;
    }

    // ---- Save/Load ----
    @Override
    protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        if (scannedItemId != null) {
            output.method_10582("pattern.scanned_item", scannedItemId.toString());
        }
        output.method_10569("pattern.uu_cost", uuCost);
        output.method_10569("pattern.energy_cost", energyCost);
    }

    @Override
    protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        super.method_11014(input, registries);
        String id = (input.method_10545("pattern.scanned_item") ? input.method_10558("pattern.scanned_item") : null);
        this.scannedItemId = id != null ? class_2960.method_60654(id) : null;
        this.uuCost = (input.method_10545("pattern.uu_cost") ? input.method_10550("pattern.uu_cost") : 0);
        this.energyCost = (input.method_10545("pattern.energy_cost") ? input.method_10550("pattern.energy_cost") : 0);
    }

    // ---- Sided I/O ----
    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        if (slot == INPUT_SLOT) return stack.method_31574(GrowableOresItems.PATTERN_STORAGE_CRYSTAL);
        if (slot == SECOND_INPUT_SLOT) return !stack.method_31574(GrowableOresItems.PATTERN_STORAGE_CRYSTAL);
        if (slot == OUTPUT_SLOT_2) return stack.method_31574(GrowableOresItems.PATTERN_STORAGE_CRYSTAL);
        if (slot == ENERGY_ITEM_SLOT) return true;
        return slot >= UPGRADE_START && slot <= UPGRADE_END;
    }

    @Override
    public boolean method_5493(int slot, class_1799 stack, class_2350 side) {
        if (slot == INPUT_SLOT && hasPatternData(stack)) {
            // Allow pulling patterned crystals from the input slot
            return true;
        }
        return super.method_5493(slot, stack, side);
    }

    @Override
    public int[] method_5494(class_2350 direction) {
        if (direction != class_2350.field_11033) {
            return new int[]{INPUT_SLOT, SECOND_INPUT_SLOT, OUTPUT_SLOT_2};
        } else {
            return new int[]{INPUT_SLOT};
        }
    }
}
