package torcherino.block.entity;

import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1275;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3738;
import net.minecraft.class_5558;
import net.minecraft.class_7923;
import net.minecraft.class_8824;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import torcherino.api.Tier;
import torcherino.api.TierSupplier;
import torcherino.api.TorcherinoAPI;
import torcherino.config.Config;
import torcherino.platform.NetworkUtils;

public class TorcherinoBlockEntity extends class_2586 implements class_1275, TierSupplier {
    public static int randomTicks;
    private class_2561 customName;
    private int xRange, yRange, zRange, speed, redstoneMode;
    private Iterable<class_2338> area;
    private boolean active;
    private class_2960 tierID;
    private String uuid = "";

    public TorcherinoBlockEntity(class_2338 pos, class_2680 state) {
        super(class_7923.field_41181.method_10223(class_2960.method_60655("torcherino", "torcherino")).get().comp_349(), pos, state);
    }

    public static void tick(class_1937 level, class_2338 pos, class_2680 state, TorcherinoBlockEntity entity) {
        if (!entity.active || entity.speed == 0 || (entity.xRange == 0 && entity.yRange == 0 && entity.zRange == 0)) {
            return;
        }
        if (!Config.INSTANCE.online_mode.equals("") && !NetworkUtils.getInstance().s_isPlayerOnline(entity.getOwner())) {
            return;
        }
        // todo: get on load and then when updated
        if (level instanceof class_3218 serverlevel) {
            randomTicks = serverlevel.method_64395().method_8356(class_1928.field_19399);
        }
        entity.area.forEach(entity::tickBlock);
    }

    @Override
    public boolean method_16914() {
        return customName != null;
    }

    @Override
    public class_2561 method_5797() {
        return customName;
    }

    public class_2561 method_5476() {
        return this.method_5477();
    }

    public void setCustomName(class_2561 name) {
        customName = name;
    }

    public String getOwner() {
        return uuid;
    }

    public void setOwner(String s) {
        uuid = s;
    }

    @Override
    public @NotNull class_2561 method_5477() {
        return method_16914() ? customName : class_2561.method_43471(method_11010().method_26204().method_63499());
    }

    @Override
    public void method_31662(@NotNull class_1937 level) {
        super.method_31662(level);
        if (!level.method_8608()) {
            level.method_8503().method_63588(new class_3738(level.method_8503().method_3780(), () -> method_11010().method_26181(level, field_11867, null, null, false)));
        }
    }

    private void tickBlock(class_2338 pos) {
        class_2680 blockState = field_11863.method_8320(pos);
        class_2248 block = blockState.method_26204();
        if (TorcherinoAPI.INSTANCE.isBlockBlacklisted(block)) {
            return;
        }
        if (field_11863 instanceof class_3218 && blockState.method_26229() && field_11863.method_54719().method_54751() &&
                field_11863.method_8409().method_43048(class_3532.method_15340(4096 / (speed * Config.INSTANCE.random_tick_rate), 1, 4096)) < randomTicks) {
            blockState.method_26199((class_3218) field_11863, pos, field_11863.method_8409());
        }
        if (!(block instanceof class_2343 entityBlock)) {
            return;
        }
        class_2586 blockEntity = field_11863.method_8321(pos);
        if (blockEntity != null) {
            //noinspection unchecked
            class_5558<class_2586> ticker = (class_5558<class_2586>) entityBlock.method_31645(field_11863, blockState, blockEntity.method_11017());
            if (blockEntity.method_11015() || TorcherinoAPI.INSTANCE.isBlockEntityBlacklisted(blockEntity.method_11017()) || ticker == null) {
                return;
            }
            for (int i = 0; i < speed; i++) {
                if (blockEntity.method_11015()) {
                    break;
                }
                ticker.tick(field_11863, pos, blockState, blockEntity);
            }
        }
    }

    public boolean readClientData(int xRange, int zRange, int yRange, int speed, int redstoneMode) {
        Tier tier = TorcherinoAPI.INSTANCE.getTiers().get(getTier());
        if (this.valueInRange(xRange, 0, tier.xzRange()) &&
                this.valueInRange(zRange, 0, tier.xzRange()) &&
                this.valueInRange(yRange, 0, tier.yRange()) &&
                this.valueInRange(speed, 0, tier.maxSpeed()) &&
                this.valueInRange(redstoneMode, 0, 3)) {
            this.xRange = xRange;
            this.zRange = zRange;
            this.yRange = yRange;
            this.speed = speed;
            this.redstoneMode = redstoneMode;
            area = class_2338.method_10094(field_11867.method_10263() - xRange, field_11867.method_10264() - yRange, field_11867.method_10260() - zRange,
                    field_11867.method_10263() + xRange, field_11867.method_10264() + yRange, field_11867.method_10260() + zRange);
            this.method_11010().method_26181(field_11863, field_11867, null, null, false);
            return true;
        }
        return false;
    }

    private boolean valueInRange(int value, int min, int max) {
        return value >= min && value <= max;
    }

    @Override
    public class_2960 getTier() {
        if (tierID == null) {
            class_2248 block = this.method_11010().method_26204();
            if (block instanceof TierSupplier supplier) {
                tierID = supplier.getTier();
            }
        }
        return tierID;
    }

    public void setPoweredByRedstone(boolean powered) {
        switch (redstoneMode) {
            case 0 -> active = !powered;
            case 1 -> active = powered;
            case 2 -> active = true;
            case 3 -> active = false;
        }
    }

    @Override
    public void method_11007(class_11372 tag) {
        super.method_11007(tag);
        if (this.method_16914()) {
            class_2561 customName = this.method_5797();
            JsonElement json = class_8824.field_46597.encodeStart(JsonOps.INSTANCE, customName)
                                                           .getOrThrow(error -> {
                                                               throw new IllegalStateException("Failed to serialize component: " + error);
                                                           });
            tag.method_71469("CustomName", json.toString());
        }
        tag.method_71465("XRange", xRange);
        tag.method_71465("ZRange", zRange);
        tag.method_71465("YRange", yRange);
        tag.method_71465("Speed", speed);
        tag.method_71465("RedstoneMode", redstoneMode);
        tag.method_71472("Active", active);
        tag.method_71469("Owner", getOwner() == null ? "" : getOwner());
    }

    @Override
    public void method_11014(class_11368 tag) {
        super.method_11014(tag);
        if (tag.equals("CustomName")) {
            String jsonString = String.valueOf(tag.method_71441("CustomName"));
            class_2561 name = class_8824.field_46597.parse(JsonOps.INSTANCE, com.google.gson.JsonParser.parseString(jsonString))
                                                         .getOrThrow( error -> {
                                                             throw new IllegalStateException("Failed to deserialize component: " + error);
                                                         });
            this.setCustomName(name);
        }
        xRange = tag.method_71439("XRange").orElse(0);
        zRange = tag.method_71439("ZRange").orElse(0);
        yRange = tag.method_71439("YRange").orElse(0);
        speed = tag.method_71439("Speed").orElse(1);
        redstoneMode = tag.method_71439("RedstoneMode").orElse(0);
        active = tag.method_71433("Active", false);
        uuid = String.valueOf(tag.method_71441("Owner"));

        area = class_2338.method_10094(field_11867.method_10263() - xRange, field_11867.method_10264() - yRange, field_11867.method_10260() - zRange,
                field_11867.method_10263() + xRange, field_11867.method_10264() + yRange, field_11867.method_10260() + zRange);
    }

    public void openTorcherinoScreen(class_3222 player) {
        NetworkUtils.getInstance().s2c_openTorcherinoScreen(player, field_11867, this.method_5477(), xRange, zRange, yRange, speed, redstoneMode);
    }

    public static class Data {
        public final class_2561 customName;
        public final int xRange, yRange, zRange, speed, redstoneMode;
        public final boolean active;
        public final String uuid;

        private Data(class_2561 customName, int xRange, int yRange, int zRange,
                     int speed, int redstoneMode, boolean active, String uuid) {
            this.customName = customName;
            this.xRange = xRange;
            this.yRange = yRange;
            this.zRange = zRange;
            this.speed = speed;
            this.redstoneMode = redstoneMode;
            this.active = active;
            this.uuid = uuid;
        }

        public static Data from(TorcherinoBlockEntity be) {
            return new Data(be.method_5797(), be.xRange, be.yRange, be.zRange,
                    be.speed, be.redstoneMode, be.active, be.getOwner());
        }
    }

    public void restore(Data data) {
        if (data.customName != null) {
            this.setCustomName(data.customName);
        }
        this.readClientData(data.xRange, data.zRange, data.yRange, data.speed, data.redstoneMode);
        this.active = data.active;
        this.setOwner(data.uuid);
    }


    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

}
