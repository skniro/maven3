package com.skniro.industrial_elixir.networking.packet;

import com.skniro.industrial_elixir.IndustrialElixir;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1914;
import net.minecraft.class_1916;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9306;

public record VendorMachineSynPayload(List<OfferData> offers) implements class_8710 {
    public static final class_2960 ID = class_2960.method_60655(IndustrialElixir.MOD_ID, "vendor_machine_sync");
    public static final class_9154<VendorMachineSynPayload> TYPE = new class_9154<>(ID);

    public record OfferData(class_1799 costA, Optional<class_1799> costB, class_1799 result,
                            int maxUses, int xp, float priceMultiplier) {
        public static final class_9139<class_9129, OfferData> STREAM_CODEC = class_9139.method_58025(
                class_1799.field_48349, OfferData::costA,
                class_9135.method_56382(class_1799.field_48349), OfferData::costB,
                class_1799.field_48349, OfferData::result,
                class_9135.field_49675, OfferData::maxUses,
                class_9135.field_49675, OfferData::xp,
                class_9135.field_48552, OfferData::priceMultiplier,
                OfferData::new
        );

        public class_1914 toOffer() {
            return new class_1914(
                    new class_9306(costA.method_7909(), costA.method_7947()),
                    costB.map(s -> new class_9306(s.method_7909(), s.method_7947())),
                    result,
                    maxUses, xp, priceMultiplier
            );
        }

        public static OfferData fromOffer(class_1914 o) {
            return new OfferData(
                    o.method_57556().comp_2427(),
                    o.method_57557().map(class_9306::comp_2427),
                    o.method_8250(),
                    o.method_8248(), o.method_19279(), o.method_19278()
            );
        }
    }

    public static final class_9139<class_9129, VendorMachineSynPayload> CODEC =
            class_9139.method_56434(
                    OfferData.STREAM_CODEC.method_56433(class_9135.method_56363()),
                    VendorMachineSynPayload::offers,
                    VendorMachineSynPayload::new
            );

    public static VendorMachineSynPayload fromMerchantOffers(class_1916 offers) {
        return new VendorMachineSynPayload(
                offers.stream().map(OfferData::fromOffer).toList()
        );
    }

    public class_1916 toMerchantOffers() {
        class_1916 result = new class_1916();
        offers.forEach(o -> result.add(o.toOffer()));
        return result;
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
