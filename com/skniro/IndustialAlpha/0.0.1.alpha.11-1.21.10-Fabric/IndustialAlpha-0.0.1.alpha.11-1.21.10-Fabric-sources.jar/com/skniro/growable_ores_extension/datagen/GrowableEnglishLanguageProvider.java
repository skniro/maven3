package com.skniro.growable_ores_extension.datagen;

import com.skniro.growable_ores_extension.block.GeneralBlocks;
import com.skniro.growable_ores_extension.block.GrowableOresBlocks;
import com.skniro.growable_ores_extension.block.MapleSignBlocks;
import com.skniro.growable_ores_extension.init.FurnitureStrings;
import com.skniro.growable_ores_extension.item.AdvancedItems;
import com.skniro.growable_ores_extension.item.GrowableOresItems;
import com.skniro.growable_ores_extension.item.MapleArmorItems;
import com.skniro.growable_ores_extension.item.ModCreativeTab;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class GrowableEnglishLanguageProvider extends FabricLanguageProvider {
    public GrowableEnglishLanguageProvider(FabricDataOutput dataGenerator, CompletableFuture<class_7225.class_7874> registryLookup){
        super(dataGenerator,"en_us",registryLookup);
    }

    @Override
    public void generateTranslations(class_7225.class_7874 registryLookup, TranslationBuilder translationBuilder) {
        translationBuilder.add(FurnitureStrings.Macerator, "Macerator");
        translationBuilder.add(FurnitureStrings.CaneConverter, "Cane Converter");
        translationBuilder.add(FurnitureStrings.Compressor, "Compressor");
        translationBuilder.add(FurnitureStrings.MetalFormer, "Metal Former");
        translationBuilder.add(FurnitureStrings.GeneratorWindMill, "Wind Mill Generator");
        translationBuilder.add(FurnitureStrings.CoalGenerator, "Coal Generator");
        translationBuilder.add(FurnitureStrings.Extractor, "Extractor");
        translationBuilder.add(FurnitureStrings.ROLLING, "Rolling");
        translationBuilder.add(FurnitureStrings.CUTTING, "Cutting");
        translationBuilder.add(FurnitureStrings.EXTRUDING, "Extruding");
        translationBuilder.add(FurnitureStrings.ERROR, "Invalid Mode");
        translationBuilder.add(GrowableOresBlocks.GrowableOres_Block,"Cane Converter");

        translationBuilder.add(GeneralBlocks.Lead_Ore, "Lead Ore");
        translationBuilder.add(GeneralBlocks.Tin_Ore, "Tin Ore");
        translationBuilder.add(GeneralBlocks.Uranium_Ore, "Uranium Ore");
        translationBuilder.add(GeneralBlocks.Deepslate_Lead_Ore, "Deepslate Lead Ore");
        translationBuilder.add(GeneralBlocks.Deepslate_Tin_Ore, "Deepslate Tin Ore");
        translationBuilder.add(GeneralBlocks.Deepslate_Uranium_Ore, "Deepslate Uranium Ore");

        translationBuilder.add(GeneralBlocks.Raw_Lead_Block, "Block of Raw Lead");
        translationBuilder.add(GeneralBlocks.Raw_Tin_Block, "Block of Raw Tin");
        translationBuilder.add(GeneralBlocks.Raw_Uranium_Block, "Block of Raw Uranium");

        translationBuilder.add(GeneralBlocks.Lead_Block, "Lead Block");
        translationBuilder.add(GeneralBlocks.Tin_Block, "Tin Block");
        translationBuilder.add(GeneralBlocks.Uranium_Block, "Uranium Block");

        translationBuilder.add(GeneralBlocks.Silver_Block, "Silver Block");
        translationBuilder.add(GeneralBlocks.Bronze_Block, "Bronze Block");
        translationBuilder.add(GeneralBlocks.Steel_Block, "Steel Block");

        translationBuilder.add(GeneralBlocks.Advanced_Machine, "Advanced Machine");
        translationBuilder.add(GeneralBlocks.Machine, "Machine");

        translationBuilder.add(GeneralBlocks.Rubber_SAPLING, "Rubber Sapling");
        translationBuilder.add(GeneralBlocks.POTTED_Rubber_SAPLING, "Potted Rubber Sapling");
        translationBuilder.add(GeneralBlocks.Rubber_LEAVES, "Rubber Leaves");

        translationBuilder.add(GeneralBlocks.Rubber_Rubber_LOG, "Resin Rubber Log");

        translationBuilder.add(GeneralBlocks.Rubber_LOG, "Rubber Log");
        translationBuilder.add(GeneralBlocks.STRIPPED_Rubber_LOG, "Stripped Rubber Log");
        translationBuilder.add(GeneralBlocks.STRIPPED_Rubber_WOOD, "Stripped Rubber Wood");
        translationBuilder.add(GeneralBlocks.Rubber_WOOD, "Rubber Wood");

        translationBuilder.add(GeneralBlocks.Rubber_PLANKS, "Rubber Planks");
        translationBuilder.add(GeneralBlocks.Rubber_BUTTON, "Rubber Button");
        translationBuilder.add(GeneralBlocks.Rubber_STAIRS, "Rubber Stairs");
        translationBuilder.add(GeneralBlocks.Rubber_SLAB, "Rubber Slab");
        translationBuilder.add(GeneralBlocks.Rubber_FENCE_GATE, "Rubber Fence Gate");
        translationBuilder.add(GeneralBlocks.Rubber_FENCE, "Rubber Fence");
        translationBuilder.add(GeneralBlocks.Rubber_DOOR, "Rubber Door");
        translationBuilder.add(GeneralBlocks.Rubber_TRAPDOOR, "Rubber Trapdoor");
        translationBuilder.add(GeneralBlocks.Rubber_PRESSURE_PLATE, "Rubber Pressure Plate");

        translationBuilder.add(GrowableOresBlocks.Macerator_Block, "Macerator");
        translationBuilder.add(GrowableOresBlocks.Compressor_Block, "Compressor");
        translationBuilder.add(GrowableOresBlocks.MetalFormerBlock, "Metal Former");

        translationBuilder.add(GrowableOresBlocks.COPPER_CABLE, "Copper Cable");
        translationBuilder.add(GrowableOresBlocks.TIN_CABLE, "Tin Cable");
        translationBuilder.add(GrowableOresBlocks.GOLD_CABLE, "Gold Cable");
        translationBuilder.add(GrowableOresBlocks.HV_CABLE, "HV Cable");
        translationBuilder.add(GrowableOresBlocks.GLASSFIBER_CABLE, "Glass Fiber Cable");

        translationBuilder.add(GrowableOresBlocks.INSULATED_TIN_CABLE, "Insulated Tin Cable");
        translationBuilder.add(GrowableOresBlocks.INSULATED_COPPER_CABLE, "Insulated Copper Cable");
        translationBuilder.add(GrowableOresBlocks.INSULATED_GOLD_CABLE, "Insulated Gold Cable");
        translationBuilder.add(GrowableOresBlocks.INSULATED_HV_CABLE, "Insulated HV Cable");

        translationBuilder.add(GrowableOresBlocks.COAL_GENERATOR, "Coal Generator");
        translationBuilder.add(GrowableOresBlocks.GENERATOR_Wind_Mill, "Wind Mill");

        translationBuilder.add(GrowableOresBlocks.EnergyBox, "Energy Box");
        translationBuilder.add(GrowableOresBlocks.ChargePad, "Charge Pad");

        translationBuilder.add(GrowableOresBlocks.CESU, "CESU");
        translationBuilder.add(GrowableOresBlocks.MFE, "MFE");
        translationBuilder.add(GrowableOresBlocks.MFSU, "MFSU");

        translationBuilder.add(GrowableOresBlocks.CESU_CHARGE_PAD, "CESU Charge Pad");
        translationBuilder.add(GrowableOresBlocks.MFE_CHARGE_PAD, "MFE Charge Pad");
        translationBuilder.add(GrowableOresBlocks.MFSU_CHARGE_PAD, "MFSU Charge Pad");

        translationBuilder.add(GrowableOresBlocks.MolecularTransformerBlock, "Molecular Transformer");

        translationBuilder.add(GrowableOresBlocks.GENERATOR_SolarPanel, "Solar Panel");
        translationBuilder.add(GrowableOresBlocks.GENERATOR_ADVANCED_SOLAR_PANEL, "Advanced Solar Panel");
        translationBuilder.add(GrowableOresBlocks.GENERATOR_HYBRID_SOLAR_PANEL, "Hybrid Solar Panel");
        translationBuilder.add(GrowableOresBlocks.GENERATOR_ULTIMATE_SOLAR_PANEL, "Ultimate Solar Panel");
        translationBuilder.add(GrowableOresBlocks.GENERATOR_QUANTUM_SOLAR_PANEL, "Quantum Solar Panel");

        translationBuilder.add(GrowableOresBlocks.Extractor_Block, "Extractor");

        translationBuilder.add(GrowableOresBlocks.EV_TRANSFORMER, "EV Transformer");
        translationBuilder.add(GrowableOresBlocks.HV_TRANSFORMER, "HV Transformer");
        translationBuilder.add(GrowableOresBlocks.MV_TRANSFORMER, "MV Transformer");
        translationBuilder.add(GrowableOresBlocks.LV_TRANSFORMER, "LV Transformer");

        translationBuilder.add(GrowableOresBlocks.Iron_Furnace_Block, "Iron Furnace");

        translationBuilder.add(MapleSignBlocks.Rubber_SIGN, "Rubber Sign");
        translationBuilder.add(MapleSignBlocks.Rubber_WALL_SIGN, "Rubber Wall Sign");
        translationBuilder.add(MapleSignBlocks.Rubber_HANGING_SIGN, "Rubber Hanging Sign");
        translationBuilder.add(MapleSignBlocks.Rubber_WALL_HANGING_SIGN, "Rubber Wall Hanging Sign");

        translationBuilder.add(AdvancedItems.IRRADIANT_URANIUM_INGOT, "Irradiant Uranium Ingot");
        translationBuilder.add(AdvancedItems.IRRADIANT_GLASS_PANE, "Irradiant Glass Pane");
        translationBuilder.add(AdvancedItems.SUNNARIUM, "Sunnarium");
        translationBuilder.add(AdvancedItems.ENRICHED_SUNNARIUM, "Enriched Sunnarium");
        translationBuilder.add(AdvancedItems.SUNNARIUM_ALLOY, "Sunnarium Alloy");
        translationBuilder.add(AdvancedItems.ENRICHED_SUNNARIUM_ALLOY, "Enriched Sunnarium Alloy");
        translationBuilder.add(AdvancedItems.IRIDIUM_IRON_PLATE, "Iridium Iron Plate");
        translationBuilder.add(AdvancedItems.REINFORCED_IRIDIUM_IRON_PLATE, "Reinforced Iridium Iron Plate");
        translationBuilder.add(AdvancedItems.IRRADIANT_REINFORCED_PLATE, "Irradiant Reinforced Plate");
        translationBuilder.add(AdvancedItems.SUNNARIUM_Part, "Sunnarium Component");
        translationBuilder.add(AdvancedItems.Iridium_INGOT, "Iridium Ingot");
        translationBuilder.add(AdvancedItems.Quantum_Core, "Quantum Core");
        translationBuilder.add(AdvancedItems.MT_Core, "Molecular Transformer Core");

        translationBuilder.add(GrowableOresItems.RE_BATTERY, "RE Battery");
        translationBuilder.add(GrowableOresItems.ADVANCED_RE_BATTERY, "Advanced RE Battery");
        translationBuilder.add(GrowableOresItems.ENERGY_CRYSTAL, "Energy Crystal");
        translationBuilder.add(GrowableOresItems.LAPOTRON_CRYSTAL, "Lapotron Crystal");

        translationBuilder.add(GrowableOresItems.Rubber, "Rubber");
        translationBuilder.add(GrowableOresItems.RUBBER_BOAT, "Rubber Boat");
        translationBuilder.add(GrowableOresItems.RUBBER_CHEST_BOAT, "Rubber Chest Boat");

        translationBuilder.add(GrowableOresItems.OVERCLOCKER, "Overclocker Upgrade");
        translationBuilder.add(GrowableOresItems.ENERGY_STORAGE, "Energy Storage Upgrade");
        translationBuilder.add(GrowableOresItems.TRANSFORMER, "Transformer Upgrade");
        translationBuilder.add(GrowableOresItems.REDSTONE_INVERTER, "Redstone Inverter Upgrade");

        translationBuilder.add(GrowableOresItems.Raw_Lead, "Raw Lead");
        translationBuilder.add(GrowableOresItems.Raw_Tin, "Raw Tin");
        translationBuilder.add(GrowableOresItems.Raw_Uranium, "Raw Uranium");

        translationBuilder.add(GrowableOresItems.CRUSHED_COPPER, "Crushed Copper Ore");
        translationBuilder.add(GrowableOresItems.CRUSHED_GOLD, "Crushed Gold Ore");
        translationBuilder.add(GrowableOresItems.CRUSHED_IRON, "Crushed Iron Ore");
        translationBuilder.add(GrowableOresItems.CRUSHED_LEAD, "Crushed Lead Ore");
        translationBuilder.add(GrowableOresItems.CRUSHED_SILVER, "Crushed Silver Ore");
        translationBuilder.add(GrowableOresItems.CRUSHED_TIN, "Crushed Tin Ore");
        translationBuilder.add(GrowableOresItems.CRUSHED_URANIUM, "Crushed Uranium Ore");

        translationBuilder.add(GrowableOresItems.PURIFIED_COPPER, "Purified Copper Ore");
        translationBuilder.add(GrowableOresItems.PURIFIED_GOLD, "Purified Gold Ore");
        translationBuilder.add(GrowableOresItems.PURIFIED_IRON, "Purified Iron Ore");
        translationBuilder.add(GrowableOresItems.PURIFIED_LEAD, "Purified Lead Ore");
        translationBuilder.add(GrowableOresItems.PURIFIED_SILVER, "Purified Silver Ore");
        translationBuilder.add(GrowableOresItems.PURIFIED_TIN, "Purified Tin Ore");
        translationBuilder.add(GrowableOresItems.PURIFIED_URANIUM, "Purified Uranium Ore");

        translationBuilder.add(GrowableOresItems.BRONZE_INGOT, "Bronze Ingot");
        translationBuilder.add(GrowableOresItems.LEAD_INGOT, "Lead Ingot");
        translationBuilder.add(GrowableOresItems.SILVER_INGOT, "Silver Ingot");
        translationBuilder.add(GrowableOresItems.STEEL_INGOT, "Steel Ingot");
        translationBuilder.add(GrowableOresItems.TIN_INGOT, "Tin Ingot");
        translationBuilder.add(GrowableOresItems.REFINED_IRON_INGOT, "Refined Iron Ingot");
        translationBuilder.add(GrowableOresItems.URANIUM_INGOT, "Uranium Ingot");

        translationBuilder.add(GrowableOresItems.CARBON_FIBRE, "Carbon Fibre");
        translationBuilder.add(GrowableOresItems.CARBON_MESH, "Carbon Mesh");
        translationBuilder.add(GrowableOresItems.CARBON_PLATE, "Carbon Plate");
        translationBuilder.add(GrowableOresItems.COAL_BALL, "Coal Ball");
        translationBuilder.add(GrowableOresItems.COAL_CHUNK, "Coal Chunk");
        translationBuilder.add(GrowableOresItems.INDUSTRIAL_DIAMOND, "Industrial Diamond");

        translationBuilder.add(GrowableOresItems.Circuit, "Circuit");
        translationBuilder.add(GrowableOresItems.Advanced_Circuit, "Advanced Circuit");
        translationBuilder.add(GrowableOresItems.Coil, "Coil");

        translationBuilder.add(GrowableOresItems.IRIDIUM_SHARD, "Iridium Shard");
        translationBuilder.add(GrowableOresItems.IRIDIUM_ORE, "Iridium Ore");
        translationBuilder.add(GrowableOresItems.IRIDIUM_PLATE, "Iridium Plate");

        translationBuilder.add(GrowableOresItems.ALLOY_INGOT, "Alloy Ingot");
        translationBuilder.add(GrowableOresItems.ALLOY_PLATE, "Alloy Plate");

        translationBuilder.add(GrowableOresItems.Sticky_Resin, "Sticky Resin");

        translationBuilder.add(MapleArmorItems.ROLLING, "Hammer");
        translationBuilder.add(MapleArmorItems.CUTTING, "Cutter");

        translationBuilder.add(MapleArmorItems.Quantum_HELMET, "Quantum Helmet");
        translationBuilder.add(MapleArmorItems.Quantum_CHESTPLATE, "Quantum Chestplate");
        translationBuilder.add(MapleArmorItems.Quantum_LEGGINGS, "Quantum Leggings");
        translationBuilder.add(MapleArmorItems.Quantum_BOOTS, "Quantum Boots");

        translationBuilder.add(GrowableOresItems.BRONZE_DUST, "Bronze Dust");
        translationBuilder.add(GrowableOresItems.CLAY_DUST, "Clay Dust");
        translationBuilder.add(GrowableOresItems.COAL_DUST, "Coal Dust");
        translationBuilder.add(GrowableOresItems.COAL_FUEL_DUST, "Fuel Coal Dust");
        translationBuilder.add(GrowableOresItems.COPPER_DUST, "Copper Dust");
        translationBuilder.add(GrowableOresItems.DIAMOND_DUST, "Diamond Dust");
        translationBuilder.add(GrowableOresItems.ENERGIUM_DUST, "Energium Dust");
        translationBuilder.add(GrowableOresItems.GOLD_DUST, "Gold Dust");
        translationBuilder.add(GrowableOresItems.IRON_DUST, "Iron Dust");
        translationBuilder.add(GrowableOresItems.LAPIS_DUST, "Lapis Dust");
        translationBuilder.add(GrowableOresItems.LEAD_DUST, "Lead Dust");
        translationBuilder.add(GrowableOresItems.LITHIUM_DUST, "Lithium Dust");
        translationBuilder.add(GrowableOresItems.OBSIDIAN_DUST, "Obsidian Dust");
        translationBuilder.add(GrowableOresItems.SILICON_DIOXIDE_DUST, "Silicon Dioxide Dust");
        translationBuilder.add(GrowableOresItems.SILVER_DUST, "Silver Dust");
        translationBuilder.add(GrowableOresItems.STONE_DUST, "Stone Dust");
        translationBuilder.add(GrowableOresItems.SULFUR_DUST, "Sulfur Dust");
        translationBuilder.add(GrowableOresItems.TIN_DUST, "Tin Dust");

        translationBuilder.add(GrowableOresItems.SMALL_BRONZE_DUST, "Small Bronze Dust");
        translationBuilder.add(GrowableOresItems.SMALL_COPPER_DUST, "Small Copper Dust");
        translationBuilder.add(GrowableOresItems.SMALL_GOLD_DUST, "Small Gold Dust");
        translationBuilder.add(GrowableOresItems.SMALL_IRON_DUST, "Small Iron Dust");
        translationBuilder.add(GrowableOresItems.SMALL_LAPIS_DUST, "Small Lapis Dust");
        translationBuilder.add(GrowableOresItems.SMALL_LEAD_DUST, "Small Lead Dust");
        translationBuilder.add(GrowableOresItems.SMALL_LITHIUM_DUST, "Small Lithium Dust");
        translationBuilder.add(GrowableOresItems.SMALL_OBSIDIAN_DUST, "Small Obsidian Dust");
        translationBuilder.add(GrowableOresItems.SMALL_SILVER_DUST, "Small Silver Dust");
        translationBuilder.add(GrowableOresItems.SMALL_SULFUR_DUST, "Small Sulfur Dust");
        translationBuilder.add(GrowableOresItems.SMALL_TIN_DUST, "Small Tin Dust");

        translationBuilder.add(GrowableOresItems.BRONZE_PLATE, "Bronze Plate");
        translationBuilder.add(GrowableOresItems.COPPER_PLATE, "Copper Plate");
        translationBuilder.add(GrowableOresItems.GOLD_PLATE, "Gold Plate");
        translationBuilder.add(GrowableOresItems.IRON_PLATE, "Iron Plate");
        translationBuilder.add(GrowableOresItems.LAPIS_PLATE, "Lapis Plate");
        translationBuilder.add(GrowableOresItems.LEAD_PLATE, "Lead Plate");
        translationBuilder.add(GrowableOresItems.OBSIDIAN_PLATE, "Obsidian Plate");
        translationBuilder.add(GrowableOresItems.STEEL_PLATE, "Steel Plate");
        translationBuilder.add(GrowableOresItems.TIN_PLATE, "Tin Plate");

        translationBuilder.add(GrowableOresItems.DENSE_BRONZE_PLATE, "Dense Bronze Plate");
        translationBuilder.add(GrowableOresItems.DENSE_COPPER_PLATE, "Dense Copper Plate");
        translationBuilder.add(GrowableOresItems.DENSE_GOLD_PLATE, "Dense Gold Plate");
        translationBuilder.add(GrowableOresItems.DENSE_IRON_PLATE, "Dense Iron Plate");
        translationBuilder.add(GrowableOresItems.DENSE_LAPIS_PLATE, "Dense Lapis Plate");
        translationBuilder.add(GrowableOresItems.DENSE_LEAD_PLATE, "Dense Lead Plate");
        translationBuilder.add(GrowableOresItems.DENSE_OBSIDIAN_PLATE, "Dense Obsidian Plate");
        translationBuilder.add(GrowableOresItems.DENSE_STEEL_PLATE, "Dense Steel Plate");
        translationBuilder.add(GrowableOresItems.DENSE_TIN_PLATE, "Dense Tin Plate");

        translationBuilder.add(GrowableOresItems.BRONZE_CASING, "Bronze Casing");
        translationBuilder.add(GrowableOresItems.COPPER_CASING, "Copper Casing");
        translationBuilder.add(GrowableOresItems.GOLD_CASING, "Gold Casing");
        translationBuilder.add(GrowableOresItems.IRON_CASING, "Iron Casing");
        translationBuilder.add(GrowableOresItems.LEAD_CASING, "Lead Casing");
        translationBuilder.add(GrowableOresItems.STEEL_CASING, "Steel Casing");
        translationBuilder.add(GrowableOresItems.TIN_CASING, "Tin Casing");

        translationBuilder.add(ModCreativeTab.General, "General");
        translationBuilder.add(ModCreativeTab.Generators_And_Wiring, "Generators & Wiring");
        translationBuilder.add(ModCreativeTab.Reactor, "Reactor");
        translationBuilder.add(ModCreativeTab.Machine, "Machines");
        translationBuilder.add(ModCreativeTab.Tool_And_Utilities, "Tools & Utilities");
        translationBuilder.add(ModCreativeTab.Combat, "Combat");
        translationBuilder.add(ModCreativeTab.Materials, "Materials");

    }
}
