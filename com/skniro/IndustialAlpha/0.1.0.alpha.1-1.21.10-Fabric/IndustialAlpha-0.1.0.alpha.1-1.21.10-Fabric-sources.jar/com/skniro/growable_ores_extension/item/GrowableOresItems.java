package com.skniro.growable_ores_extension.item;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.api.energytier.EnergyTier;
import com.skniro.growable_ores_extension.entity.MapleEntityType;
import com.skniro.growable_ores_extension.item.init.BatteryItem;
import com.skniro.growable_ores_extension.item.init.ItemUpgradeModule;
import com.skniro.growable_ores_extension.item.init.ScrapboxItem;
import java.util.function.Function;
import net.minecraft.class_1749;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class GrowableOresItems {

    public static final class_1792 RE_BATTERY = registerItem("re_battery",       s -> new BatteryItem(s, EnergyTier.TIER1, 10000), new class_1792.class_1793().method_7889(1));
    public static final class_1792 ADVANCED_RE_BATTERY = registerItem("advanced_re_battery",    s -> new BatteryItem(s, EnergyTier.TIER2, 100000), new class_1792.class_1793().method_7889(1));
    public static final class_1792 ENERGY_CRYSTAL = registerItem("energy_crystal",         s -> new BatteryItem(s, EnergyTier.TIER3, 1000000), new class_1792.class_1793().method_7889(1));
    public static final class_1792 LAPOTRON_CRYSTAL = registerItem("lapotron_crystal",       s -> new BatteryItem(s, EnergyTier.TIER4, 10000000), new class_1792.class_1793().method_7889(1));

    public static final class_1792 Rubber = registerItem("rubber", class_1792::new, new class_1792.class_1793());


    public static final class_1792 RUBBER_BOAT = registerItem("rubber_boat", (settings) -> new class_1749(MapleEntityType.RUBBER_BOAT, settings), new class_1792.class_1793().method_7889(1));

    public static final class_1792 RUBBER_CHEST_BOAT = registerItem("rubber_chest_boat", (settings) -> new class_1749(MapleEntityType.RUBBER_CHEST_BOAT, settings), new class_1792.class_1793().method_7889(1));

    public static final class_1792 OVERCLOCKER = registerItem("overclocker", (settings) -> new ItemUpgradeModule(settings, ItemUpgradeModule.UpgradeType.OVERCLOCKER), new class_1792.class_1793());
    public static final class_1792 ENERGY_STORAGE = registerItem("energy_storage", (settings) -> new ItemUpgradeModule(settings, ItemUpgradeModule.UpgradeType.ENERGY_STORAGE), new class_1792.class_1793());
    public static final class_1792 TRANSFORMER = registerItem("transformer", (settings) -> new ItemUpgradeModule(settings, ItemUpgradeModule.UpgradeType.TRANSFORMER), new class_1792.class_1793());
    public static final class_1792 REDSTONE_INVERTER = registerItem("redstone_inverter", (settings) -> new ItemUpgradeModule(settings, ItemUpgradeModule.UpgradeType.REDSTONE_INVERTER), new class_1792.class_1793());

    public static final class_1792 Raw_Lead = registerItem("raw_lead", class_1792::new, new class_1792.class_1793());
    public static final class_1792 Raw_Tin = registerItem("raw_tin", class_1792::new, new class_1792.class_1793());
    public static final class_1792 Raw_Uranium = registerItem("raw_uranium", class_1792::new, new class_1792.class_1793());

    public static final class_1792 CRUSHED_COPPER = registerItem("crushed_copper", class_1792::new, new class_1792.class_1793());
    public static final class_1792 CRUSHED_GOLD = registerItem("crushed_gold", class_1792::new, new class_1792.class_1793());
    public static final class_1792 CRUSHED_IRON = registerItem("crushed_iron", class_1792::new, new class_1792.class_1793());
    public static final class_1792 CRUSHED_LEAD = registerItem("crushed_lead", class_1792::new, new class_1792.class_1793());
    public static final class_1792 CRUSHED_SILVER = registerItem("crushed_silver", class_1792::new, new class_1792.class_1793());
    public static final class_1792 CRUSHED_TIN = registerItem("crushed_tin", class_1792::new, new class_1792.class_1793());
    public static final class_1792 CRUSHED_URANIUM = registerItem("crushed_uranium", class_1792::new, new class_1792.class_1793());

    public static final class_1792 PURIFIED_COPPER = registerItem("purified_copper", class_1792::new, new class_1792.class_1793());
    public static final class_1792 PURIFIED_GOLD = registerItem("purified_gold", class_1792::new, new class_1792.class_1793());
    public static final class_1792 PURIFIED_IRON = registerItem("purified_iron", class_1792::new, new class_1792.class_1793());
    public static final class_1792 PURIFIED_LEAD = registerItem("purified_lead", class_1792::new, new class_1792.class_1793());
    public static final class_1792 PURIFIED_SILVER = registerItem("purified_silver", class_1792::new, new class_1792.class_1793());
    public static final class_1792 PURIFIED_TIN = registerItem("purified_tin", class_1792::new, new class_1792.class_1793());
    public static final class_1792 PURIFIED_URANIUM = registerItem("purified_uranium", class_1792::new, new class_1792.class_1793());

    public static final class_1792 BRONZE_DUST = registerItem("bronze_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 CLAY_DUST = registerItem("clay_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 COAL_DUST = registerItem("coal_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 COAL_FUEL_DUST = registerItem("coal_fuel_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 COPPER_DUST = registerItem("copper_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 DIAMOND_DUST = registerItem("diamond_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 ENERGIUM_DUST = registerItem("energium_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 GOLD_DUST = registerItem("gold_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 IRON_DUST = registerItem("iron_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 LAPIS_DUST = registerItem("lapis_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 LEAD_DUST = registerItem("lead_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 LITHIUM_DUST = registerItem("lithium_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 OBSIDIAN_DUST = registerItem("obsidian_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SILICON_DIOXIDE_DUST = registerItem("silicon_dioxide_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SILVER_DUST = registerItem("silver_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 STONE_DUST = registerItem("stone_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SULFUR_DUST = registerItem("sulfur_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 TIN_DUST = registerItem("tin_dust", class_1792::new, new class_1792.class_1793());

    public static final class_1792 SMALL_BRONZE_DUST = registerItem("small_bronze_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SMALL_COPPER_DUST = registerItem("small_copper_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SMALL_GOLD_DUST = registerItem("small_gold_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SMALL_IRON_DUST = registerItem("small_iron_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SMALL_LAPIS_DUST = registerItem("small_lapis_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SMALL_LEAD_DUST = registerItem("small_lead_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SMALL_LITHIUM_DUST = registerItem("small_lithium_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SMALL_OBSIDIAN_DUST = registerItem("small_obsidian_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SMALL_SILVER_DUST = registerItem("small_silver_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SMALL_SULFUR_DUST = registerItem("small_sulfur_dust", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SMALL_TIN_DUST = registerItem("small_tin_dust", class_1792::new, new class_1792.class_1793());

    public static final class_1792 BRONZE_INGOT = registerItem("bronze_ingot", class_1792::new, new class_1792.class_1793());
    public static final class_1792 LEAD_INGOT = registerItem("lead_ingot", class_1792::new, new class_1792.class_1793());
    public static final class_1792 SILVER_INGOT = registerItem("silver_ingot", class_1792::new, new class_1792.class_1793());
    public static final class_1792 STEEL_INGOT = registerItem("steel_ingot", class_1792::new, new class_1792.class_1793());
    public static final class_1792 TIN_INGOT = registerItem("tin_ingot", class_1792::new, new class_1792.class_1793());
    public static final class_1792 REFINED_IRON_INGOT = registerItem("refined_iron_ingot", class_1792::new, new class_1792.class_1793());
    public static final class_1792 URANIUM_INGOT = registerItem("uranium_ingot", class_1792::new, new class_1792.class_1793());

    public static final class_1792 BRONZE_PLATE = registerItem("bronze_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 COPPER_PLATE = registerItem("copper_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 GOLD_PLATE = registerItem("gold_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 IRON_PLATE = registerItem("iron_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 LAPIS_PLATE = registerItem("lapis_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 LEAD_PLATE = registerItem("lead_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 OBSIDIAN_PLATE = registerItem("obsidian_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 STEEL_PLATE = registerItem("steel_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 TIN_PLATE = registerItem("tin_plate", class_1792::new, new class_1792.class_1793());

    public static final class_1792 DENSE_BRONZE_PLATE = registerItem("dense_bronze_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 DENSE_COPPER_PLATE = registerItem("dense_copper_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 DENSE_GOLD_PLATE = registerItem("dense_gold_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 DENSE_IRON_PLATE = registerItem("dense_iron_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 DENSE_LAPIS_PLATE = registerItem("dense_lapis_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 DENSE_LEAD_PLATE = registerItem("dense_lead_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 DENSE_OBSIDIAN_PLATE = registerItem("dense_obsidian_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 DENSE_STEEL_PLATE = registerItem("dense_steel_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 DENSE_TIN_PLATE = registerItem("dense_tin_plate", class_1792::new, new class_1792.class_1793());

    public static final class_1792 BRONZE_CASING = registerItem("bronze_casing", class_1792::new, new class_1792.class_1793());
    public static final class_1792 COPPER_CASING = registerItem("copper_casing", class_1792::new, new class_1792.class_1793());
    public static final class_1792 GOLD_CASING = registerItem("gold_casing", class_1792::new, new class_1792.class_1793());
    public static final class_1792 IRON_CASING = registerItem("iron_casing", class_1792::new, new class_1792.class_1793());
    public static final class_1792 LEAD_CASING = registerItem("lead_casing", class_1792::new, new class_1792.class_1793());
    public static final class_1792 STEEL_CASING = registerItem("steel_casing", class_1792::new, new class_1792.class_1793());
    public static final class_1792 TIN_CASING = registerItem("tin_casing", class_1792::new, new class_1792.class_1793());

    public static final class_1792 CARBON_FIBRE = registerItem("carbon_fibre", class_1792::new, new class_1792.class_1793());
    public static final class_1792 CARBON_MESH = registerItem("carbon_mesh", class_1792::new, new class_1792.class_1793());
    public static final class_1792 CARBON_PLATE = registerItem("carbon_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 COAL_BALL = registerItem("coal_ball", class_1792::new, new class_1792.class_1793());
    public static final class_1792 COAL_BLOCK = registerItem("coal_block", class_1792::new, new class_1792.class_1793());
    public static final class_1792 COAL_CHUNK = registerItem("coal_chunk", class_1792::new, new class_1792.class_1793());
    public static final class_1792 INDUSTRIAL_DIAMOND = registerItem("industrial_diamond", class_1792::new, new class_1792.class_1793());

    public static final class_1792 IRIDIUM_SHARD = registerItem("iridium_shard", class_1792::new, new class_1792.class_1793().method_7894(class_1814.field_8903));
    public static final class_1792 IRIDIUM_ORE = registerItem("iridium_ore", class_1792::new, new class_1792.class_1793().method_7894(class_1814.field_8907));
    public static final class_1792 IRIDIUM_PLATE = registerItem("iridium_plate", class_1792::new, new class_1792.class_1793().method_7894(class_1814.field_8907));
    public static final class_1792 ALLOY_INGOT = registerItem("alloy_ingot", class_1792::new, new class_1792.class_1793());
    public static final class_1792 ALLOY_PLATE = registerItem("alloy_plate", class_1792::new, new class_1792.class_1793());
    public static final class_1792 Sticky_Resin = registerItem("sticky_resin", class_1792::new, new class_1792.class_1793());

    public static final class_1792 Circuit = registerItem("circuit", class_1792::new, new class_1792.class_1793());
    public static final class_1792 Advanced_Circuit = registerItem("advanced_circuit", class_1792::new, new class_1792.class_1793());

    public static final class_1792 Coil = registerItem("coil", class_1792::new, new class_1792.class_1793());
    public static final class_1792 Electric_Motor = registerItem("electric_motor", class_1792::new, new class_1792.class_1793());
    public static final class_1792 Scrap = registerItem("scrap", class_1792::new, new class_1792.class_1793());
    public static final class_1792 Scrap_box = registerItem("scrap_box", ScrapboxItem::new, new class_1792.class_1793());

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings.method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name))));
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(GrowableOresExtension.MOD_ID, name)), item);
    }

    public static void shield_item(){
      GrowableOresExtension.LOGGER.debug("register shield item.");
    }
}