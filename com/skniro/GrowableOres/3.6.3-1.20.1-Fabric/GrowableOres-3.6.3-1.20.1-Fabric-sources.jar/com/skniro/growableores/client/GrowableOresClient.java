package com.skniro.growableores.client;

import com.skniro.growableores.GrowableOres;
import com.skniro.growableores.block.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

@Environment(EnvType.CLIENT)
public class GrowableOresClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_7923.field_41175.forEach(block -> {
            class_2960 blockId = class_7923.field_41175.method_10221(block);
            if (blockId.method_12836().equals(GrowableOres.MOD_ID)) {
                BlockRenderLayerMap.INSTANCE.putBlock(block, class_1921.method_23581());
            }
        });
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Coal_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Iron_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Diamond_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Copper_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Emerald_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Gold_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Lapis_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Nether_Quartz_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Redstone_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Blaze_Rod_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Ender_Pearl_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Netherite_Ingot_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Clay_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Slime_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Nether_Star_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Glowstone_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Bone_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Egg_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Wool_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Feather_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableVanillaOresBlocks.Gunpowder_Cane, class_1921.method_23581());

        //ae2
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableAEOresBlocks.certus_quartz_crystal_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableAEOresBlocks.fluix_crystal_Cane, class_1921.method_23581());

        //Tech Reborn
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.cinnabar_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.galena_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.iridium_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.lead_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.peridot_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.pyrite_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.ruby_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.sapphire_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.sheldonite_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.silver_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.sphalerite_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.tin_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.tungsten_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.sodalite_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableTechRebornOresBlocks.bauxite_Cane, class_1921.method_23581());


        //BetterEnd
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableBetterEndOresBlocks.amber_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableBetterEndOresBlocks.ender_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableBetterEndOresBlocks.thallasium_Cane, class_1921.method_23581());


        //Maple
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableMapleOresBlocks.Salt_Cane, class_1921.method_23581());

        //Powah Rearchitected and Powah
        BlockRenderLayerMap.INSTANCE.putBlock(GrowablePowahOresBlocks.Steel_Energized_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowablePowahOresBlocks.Uraninite_Ore_Dense_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowablePowahOresBlocks.Ender_Core_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowablePowahOresBlocks.Crystal_Spirited_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowablePowahOresBlocks.Crystal_Nitro_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowablePowahOresBlocks.Crystal_Niotic_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowablePowahOresBlocks.Crystal_Blazing_Cane, class_1921.method_23581());

        //Industrial Revolution
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableIndustrialRevolutionOresBlocks.IR_Lead_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableIndustrialRevolutionOresBlocks.IR_nikolite_Cane , class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableIndustrialRevolutionOresBlocks.IR_silver_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableIndustrialRevolutionOresBlocks.IR_tin_ore_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableIndustrialRevolutionOresBlocks.IR_tungsten_Cane, class_1921.method_23581());

        //Modern Industrialization
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_antimony_Cane , class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_bauxite_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_iridium_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_lead_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_lignite_coal_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_monazite_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_nickel_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_platinum_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_quartz_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_salt_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_tin_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_titanium_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_tungsten_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableModernIndustrializationOresBlocks.MI_uranium_Cane, class_1921.method_23581());

        //ic2 and ic2c
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableICOresBlocks.IC2_Aluminium_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableICOresBlocks.IC2_silver_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableICOresBlocks.IC2_Tin_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableICOresBlocks.IC2_Uranium_Cane, class_1921.method_23581());

        //Ad Astra!
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableAdAstraOresBlocks.AD_Ostrum_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableAdAstraOresBlocks.AD_Ice_Shard_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableAdAstraOresBlocks.AD_Cheese_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableAdAstraOresBlocks.AD_Desh_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableAdAstraOresBlocks.AD_Calorite_Cane, class_1921.method_23581());

        //Create
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableCreateOresBlocks.C_Andesite_Alloy_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableCreateOresBlocks.C_Brass_Ingot_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableCreateOresBlocks.C_Polished_Rose_Quartz_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableCreateOresBlocks.C_Zinc_Cane, class_1921.method_23581());

        //Thermal Series
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableThermalSeriesOresBlocks.TF_Apatite_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableThermalSeriesOresBlocks.TF_Cinnabar_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableThermalSeriesOresBlocks.TF_Copper_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableThermalSeriesOresBlocks.TF_Lead_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableThermalSeriesOresBlocks.TF_Nickel_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableThermalSeriesOresBlocks.TF_Niter_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableThermalSeriesOresBlocks.TF_Ruby_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableThermalSeriesOresBlocks.TF_Sapphire_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableThermalSeriesOresBlocks.TF_Silver_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableThermalSeriesOresBlocks.TF_Sulfur_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableThermalSeriesOresBlocks.TF_Tin_Cane, class_1921.method_23581());

        //Mekanism
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableMekanismOresBlocks.MEK_Fluorite_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableMekanismOresBlocks.MEK_Lead_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableMekanismOresBlocks.MEK_Osmium_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableMekanismOresBlocks.MEK_Tin_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableMekanismOresBlocks.MEK_Uranium_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableMekanismOresBlocks.MEK_Steel_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableMekanismOresBlocks.MEK_Refined_Obsidian_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableMekanismOresBlocks.MEK_Refined_Glowstone_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableMekanismOresBlocks.MEK_Bronze_Cane, class_1921.method_23581());

        //BetterNether
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableBetterNetherOresBlocks.BN_Cincinnasite_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableBetterNetherOresBlocks.BN_Nether_Ruby_Cane, class_1921.method_23581());

        //EnergizedPower
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableEnergizedPowerOresBlocks.EP_Advanced_Alloy_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableEnergizedPowerOresBlocks.EP_Energized_Copper_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableEnergizedPowerOresBlocks.EP_Energized_Gold_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableEnergizedPowerOresBlocks.EP_Redstone_Alloy_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableEnergizedPowerOresBlocks.EP_Steel_Cane, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(GrowableEnergizedPowerOresBlocks.EP_Tin_Cane, class_1921.method_23581());


    }
}
