package com.skniro.growable_ores_extension.client.gui.screen.ingame.machine;

import com.skniro.growable_ores_extension.GrowableOresExtension;
import com.skniro.growable_ores_extension.block.entity.machine.MetalFormerBlockEntity;
import com.skniro.growable_ores_extension.block.networking.packet.MetalFormerStateC2SPayload;
import com.skniro.growable_ores_extension.client.gui.screen.ingame.widgets.StateButtonWidget;
import com.skniro.growable_ores_extension.screen.MaceratorScreenHandler;
import com.skniro.growable_ores_extension.screen.MetalFormerScreenHandler;
import com.skniro.growable_ores_extension.util.MouseUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_10799;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.util.List;
import java.util.Optional;

import static com.skniro.growable_ores_extension.block.entity.machine.MetalFormerBlockEntity.MetalFormerState.*;

@Environment(EnvType.CLIENT)
public class MetalFormerBlockScreen extends class_465<MetalFormerScreenHandler> {
    private static final class_2960 TEXTURE = class_2960.method_60655(GrowableOresExtension.MOD_ID, "textures/gui/container/machine/metal_former.png");
    MetalFormerBlockEntity.MetalFormerState state = field_2797.blockEntity.getState();

    public MetalFormerBlockScreen(MetalFormerScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;

        this.method_37063(new StateButtonWidget(this, field_2776 + 71, field_2800 + 53, field_22793) {
            class_1799 buttonIcon;


            @Override
            protected void initialize() {
                this.setButtonMessage();
                this.setButtonIcon();
            }

            private void setButtonMessage() {
                String translationKey = switch (state) {
                    case ROLLING -> "gui.metal_former.mode.rolling";
                    case CUTTING -> "gui.metal_former.mode.cutting";
                    case EXTRUDING -> "gui.metal_former.mode.extruding";
                    default -> "gui.metal_former.mode.error";
                };

                this.setNarrationMessage(class_2561.method_43471(translationKey));
            }
            private void setButtonIcon() {
                switch (state) {
                    case ROLLING -> this.buttonIcon = new class_1799(class_1802.field_8725);
                    case CUTTING -> this.buttonIcon = new class_1799(class_1802.field_8530);
                    case EXTRUDING -> this.buttonIcon = new class_1799(class_1802.field_8054);
                    default -> this.buttonIcon = new class_1799(class_1802.field_8732);
                }
            }

            @Override
            protected void nextState() {
                MetalFormerBlockScreen.this.state = MetalFormerBlockEntity.MetalFormerState.values()[(state.ordinal() + 1) % MetalFormerBlockEntity.MetalFormerState.values().length];
                ClientPlayNetworking.send(new MetalFormerStateC2SPayload(field_2797.blockEntity.method_11016(), state.ordinal()));
                this.initialize();
            }

            @Override
            protected class_1799 getButtonIcon() {
                return buttonIcon;
            }
        });
    }

    public List<class_2561> getTooltips() {
        return List.of(class_2561.method_43470(field_2797.blockEntity.energyContainer.getSideStorage(null).getAmount()+" / "+ field_2797.blockEntity.energyContainer.getSideStorage(null).getCapacity()+" E"));
    }

    private void renderEnergyAreaTooltips(class_332 context, int pMouseX, int pMouseY, int x, int y) {
        if(isMouseAboveArea(pMouseX, pMouseY, x, y, 23, 32, 15, 12)) {
            context.method_64038(Screens.getTextRenderer(this), getTooltips(),
                    Optional.empty(), pMouseX - x, pMouseY - y);
        }
    }

    private void renderEnergyArea(class_332 context, int x, int y) {
        if(field_2797.isCrafting()) {
            context.method_25290(class_10799.field_56883, TEXTURE, x + 54, y + 37, 190, 0, 46, field_2797.getScaledEnergyHeight(),256,256);
        }
    }



    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        renderEnergyAreaTooltips(context, mouseX, mouseY, x, y);

        context.method_51439(this.field_22793, this.field_22785, this.field_25267, this.field_25268, -12566464, false);
        context.method_51439(this.field_22793, this.field_29347, this.field_25269, this.field_25270, -12566464, false);
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        context.method_25290(class_10799.field_56883, TEXTURE, x, y, 0, 0, field_2792, field_2779,256,256);
        renderProgressArrow(context, x, y);
        renderEnergyArea(context, x, y);
    }

    private void renderProgressArrow(class_332 context, int x, int y) {
        if(field_2797.isCrafting()) {
            context.method_25290(class_10799.field_56883, TEXTURE, x + 54, y + 37, 190, 0, field_2797.getScaledProgress(),12,256,256);
        }
    }

    @Override
    public void method_25394(class_332 context , int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }

    private boolean isMouseAboveArea(int pMouseX, int pMouseY, int x, int y, int offsetX, int offsetY, int width, int height) {
        return MouseUtil.isMouseOver(pMouseX, pMouseY, x + offsetX, y + offsetY, width, height);
    }
}

