package com.skniro.industrial_elixir.energy.heat.impl;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.skniro.industrial_elixir.IndustrialElixir;
import com.skniro.industrial_elixir.energy.heat.api.HeatStorage;
import com.skniro.industrial_elixir.energy.heat.api.base.SimpleHeatItem;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9135;
import net.minecraft.class_9331;
import org.jetbrains.annotations.ApiStatus;

// CREDIT: https://github.com/TechReborn/energy
// Under MIT-License: https://github.com/TechReborn/Energy/blob/master/LICENSE
@ApiStatus.Internal
public class HeatImpl {
	public static final class_9331<Long> Heat_COMPONENT = class_9331.<Long>method_57873()
			.method_57881(nonNegativeLong())
			.method_57882(class_9135.field_48551)
			.method_57880();

	public static void init() {
		class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(IndustrialElixir.MOD_ID, "heat"), Heat_COMPONENT);
		HeatStorage.ITEM.registerFallback((stack, ctx) -> {
			if (stack.method_7909() instanceof SimpleHeatItem HeatItem) {
				return SimpleHeatItem.createStorage(ctx, HeatItem.getHeatCapacity(stack), HeatItem.getHeatMaxInput(stack), HeatItem.getHeatMaxOutput(stack));
			} else {
				return null;
			}
		});
	}

	private static Codec<Long> nonNegativeLong() {
		return Codec.LONG.validate((Long value) -> {
			if (value >= 0) {
				return DataResult.success(value);
			}

			return DataResult.error(() -> "heat value must be non-negative: " + value);
		});
	}
}
