package com.skniro.growable_ores_extension.block.entity;

import com.skniro.growable_ores_extension.init.FurnitureStrings;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import com.skniro.growable_ores_extension.screen.AlchemyBlockScreenHandler;
import com.skniro.growable_ores_extension.screen.MaceratorScreenHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public class MaceratorEntity extends AbstractMachineEntity {

    public MaceratorEntity(class_2338 pos, class_2680 state) {
        super(AlchemyBlockEntityType.Macerator_BLOCK_ENTITY ,pos, state, AlchemyRecipeType.MACERATOR.type);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(FurnitureStrings.Macerator);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new MaceratorScreenHandler(syncId, playerInventory, this, propertyDelegate);
    }
}
