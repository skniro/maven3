package com.skniro.growable_ores_extension.recipe.machine;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.skniro.growable_ores_extension.recipe.AlchemyCraftingRecipeInput;
import com.skniro.growable_ores_extension.recipe.AlchemyRecipeType;
import net.minecraft.class_10355;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9887;
import net.minecraft.recipe.*;

public class RecyclerCraftingRecipe implements class_1860<AlchemyCraftingRecipeInput> {
    private final class_1799 output;

    public RecyclerCraftingRecipe(class_1799 output) {
        this.output = output;
    }

    public class_1799 output() {
        return output;
    }

    @Override
    public boolean matches(AlchemyCraftingRecipeInput input, class_1937 world) {
        if (world.method_8608()) {
            return false;
        }
        class_1799 stack = input.method_59984(1);
        return !stack.method_7960();
    }

    @Override
    public class_1799 craft(AlchemyCraftingRecipeInput input, class_7225.class_7874 registries) {
        return output.method_7972();
    }

    @Override
    public class_1865<? extends class_1860<AlchemyCraftingRecipeInput>> method_8119() {
        return AlchemyRecipeType.RECYCLER.serializer;
    }

    @Override
    public class_3956<? extends class_1860<AlchemyCraftingRecipeInput>> method_17716() {
        return AlchemyRecipeType.RECYCLER.type;
    }

    @Override
    public class_9887 method_61671() {
        return class_9887.field_52597;
    }

    @Override
    public class_10355 method_64668() {
        return null;
    }

    public static class Serializer implements class_1865<RecyclerCraftingRecipe> {
        public static final MapCodec<RecyclerCraftingRecipe> CODEC =
                RecordCodecBuilder.mapCodec(inst -> inst.group(
                        class_1799.field_24671.fieldOf("result")
                                .forGetter(RecyclerCraftingRecipe::output)
                ).apply(inst, RecyclerCraftingRecipe::new));

        public static final class_9139<class_9129, RecyclerCraftingRecipe> STREAM_CODEC =
                class_9139.method_56434(
                        class_1799.field_48349,
                        RecyclerCraftingRecipe::output,
                        RecyclerCraftingRecipe::new
                );


        public Serializer() {
        }

        public MapCodec<RecyclerCraftingRecipe> method_53736() {
            return CODEC;
        }

        public class_9139<class_9129, RecyclerCraftingRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }
}
