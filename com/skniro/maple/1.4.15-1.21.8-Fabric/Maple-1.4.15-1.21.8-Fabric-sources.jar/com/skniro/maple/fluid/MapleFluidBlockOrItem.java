package com.skniro.maple.fluid;

import com.skniro.maple.Maple;
import com.skniro.maple.fluid.init.MapleHotSpringFluidBlock;
import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.item.*;
import java.util.function.Function;

public class MapleFluidBlockOrItem {
    public static class_2248 Hot_Spring_BLOCK;
    public static class_1792 Hot_Spring_BUCKET;

    public static void registerFluidBlocks() {
        Hot_Spring_BLOCK = registerBlockWithoutItem( "hot_spring_block",
                (settings)-> new MapleHotSpringFluidBlock(MapleFluids.STILL_Hot_Spring, settings), class_4970.class_2251.method_9630(class_2246.field_10382).method_9631((state)->{return 7;}));
    }
    public static void registerFluidItems() {
        Hot_Spring_BUCKET = registerItem("hot_spring_bucket",
                (settings)->  new class_1755(MapleFluids.STILL_Hot_Spring, settings), new class_1792.class_1793().method_7896(class_1802.field_8550).method_7889(1));
    }

    private static class_2248 registerBlockWithoutItem(String name, Function<class_4970.class_2251, class_2248> factory, class_4970.class_2251 settings) {
        class_2248 block = (class_2248)factory.apply(settings.method_63500(keyOf(name)));
        return class_2378.method_39197(class_7923.field_41175, keyOf(name), block);
    }

    private static class_5321<class_2248> keyOf(String name) {
        return class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(Maple.MOD_ID, name));
    }

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings.method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Maple.MOD_ID, name))));
        return class_2378.method_39197(class_7923.field_41178, class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Maple.MOD_ID, name)), item);
    }
}
