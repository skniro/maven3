package com.skniro.industrial_elixir.compat.jei.category;

import com.skniro.industrial_elixir.api.Helper;
import com.skniro.industrial_elixir.api.renderer.GuiFluidTankRenderer;
import com.skniro.industrial_elixir.block.GrowableOresBlocks;
import com.skniro.industrial_elixir.init.FurnitureStrings;
import com.skniro.industrial_elixir.recipe.AlchemyRecipeType;
import com.skniro.industrial_elixir.recipe.machine.CoffeeMachineCraftingRecipe;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableAnimated;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.recipe.RecipeType;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_7923;
import net.minecraft.class_8786;

public class CoffeeMachineCategory implements IRecipeCategory<class_8786<CoffeeMachineCraftingRecipe>> {
    public static final RecipeType<class_8786<CoffeeMachineCraftingRecipe>> TYPE =
            RecipeType.createFromVanilla(AlchemyRecipeType.COFFEE_MACHINE.type);

    private final IDrawable background;
    private final IDrawable icon;
    private final IDrawable energyBar;
    private final IDrawableAnimated arrow;
    private final GuiFluidTankRenderer fluidRenderer;

    public CoffeeMachineCategory(IGuiHelper helper) {
        class_2960 texture = Helper.id("textures/gui/container/machine/coffee_machine.png");
        background = helper.createDrawable(texture, 0, 0, 175, 82);
        icon = helper.createDrawableIngredient(VanillaTypes.ITEM_STACK, new class_1799(GrowableOresBlocks.COFFEE_MACHINE_Block));
        energyBar = helper.createDrawable(texture, 176, 0, 13, 16);
        this.arrow = helper.drawableBuilder(Helper.id("textures/gui/container/machine/coffee_machine.png"),
                189, 0, 24, 16).buildAnimated(72, IDrawableAnimated.StartDirection.LEFT, false);
        this.fluidRenderer = new GuiFluidTankRenderer(1000, true, 16, 50);
    }

    @Override
    public RecipeType<class_8786<CoffeeMachineCraftingRecipe>> getRecipeType() {
        return TYPE;
    }

    @Override
    public class_2561 getTitle() {
        return class_2561.method_43471(FurnitureStrings.CoffeeMachine);
    }

    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public int getWidth() {
        return background.getWidth();
    }

    @Override
    public int getHeight() {
        return background.getHeight();
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, class_8786<CoffeeMachineCraftingRecipe> recipe, IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 52, 15)
                .addIngredients(recipe.comp_1933().ingredient());

        recipe.comp_1933().ingredient2().ifPresent(ing ->
                builder.addSlot(RecipeIngredientRole.INPUT, 52, 33).addIngredients(ing));

        recipe.comp_1933().ingredient3().ifPresent(ing ->
                builder.addSlot(RecipeIngredientRole.INPUT, 52, 51).addIngredients(ing));

        builder.addSlot(RecipeIngredientRole.OUTPUT, 104, 34)
                .addItemStack(recipe.comp_1933().output());

        try {
            class_2960 fluidId = recipe.comp_1933().requiredFluid();
            class_2960 cellId = class_2960.method_60655(fluidId.method_12836(), fluidId.method_12832() + "_cell");
            class_1792 cell = class_7923.field_41178.method_17966(cellId).orElse(null);
            if (cell != null && cell != class_1802.field_8162) {
                builder.addSlot(RecipeIngredientRole.INPUT, 8, 5).addItemStack(new class_1799(cell));
            }
        } catch (Throwable ignored) {
        }
    }

    private SingleVariantStorage<FluidVariant> getRecipeFluidStorage(class_8786<CoffeeMachineCraftingRecipe> recipe) {
        class_2960 fluidId = recipe.comp_1933().requiredFluid();
        int amount = recipe.comp_1933().requiredFluidAmount();
        class_3611 fluid = class_7923.field_41173.method_17966(fluidId).orElse(class_3612.field_15906);
        return new SingleVariantStorage<>() {
            @Override
            protected FluidVariant getBlankVariant() {
                return FluidVariant.blank();
            }

            @Override
            protected long getCapacity(FluidVariant variant) {
                return 1000;
            }

            {
                this.variant = FluidVariant.of(fluid);
                this.amount = amount;
            }
        };
    }

    @Override
    public void draw(class_8786<CoffeeMachineCraftingRecipe> recipe, IRecipeSlotsView slots, class_332 guiGraphics, double mouseX, double mouseY) {
        background.draw(guiGraphics);
        energyBar.draw(guiGraphics, 129, 45);
        arrow.draw(guiGraphics, 70, 34);

        SingleVariantStorage<FluidVariant> storage = getRecipeFluidStorage(recipe);
        fluidRenderer.render(guiGraphics, 8, 5, storage);

        int fx = 8;
        int fy = 5;
        int fw = fluidRenderer.getWidth();
        int fh = fluidRenderer.getHeight();
        if (mouseX >= fx && mouseX <= fx + fw && mouseY >= fy && mouseY <= fy + fh) {
            guiGraphics.method_51434(class_310.method_1551().field_1772, fluidRenderer.getTooltip(storage), (int) mouseX, (int) mouseY);
        }

        int count = recipe.comp_1933().requiredCount();
        if (count > 1) {
            class_327 font = class_310.method_1551().field_1772;
            String text = String.valueOf(count);
            int x = 52 + 16 - font.method_1727(text) - 1;
            int y = 15 + 16 - 8 - 1;
            guiGraphics.method_51433(font, text, x, y, 0xFFFFFFFF, true);
        }
    }
}
