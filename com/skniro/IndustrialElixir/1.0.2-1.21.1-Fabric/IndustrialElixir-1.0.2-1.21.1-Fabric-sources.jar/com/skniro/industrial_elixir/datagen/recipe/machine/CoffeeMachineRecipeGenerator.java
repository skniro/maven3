package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.industrial_elixir.api.data.recipe.CraftingDataHelper;
import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.item.MapleFoodComponents;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_1802;
import net.minecraft.class_3612;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class CoffeeMachineRecipeGenerator extends CraftingDataHelper {
    public CoffeeMachineRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                createCoffeeMachine(MapleFoodComponents.Coffee_Black)
                        .fluid(class_3612.field_15910, 1000)
                        .input(MapleFoodComponents.Coffee_Beans, 1)
                        .method_33530("has_coffee_beans", has(MapleFoodComponents.Coffee_Beans))
                        .method_36443(output, "coffee_beans_to_coffee_black");

                createCoffeeMachine(MapleFoodComponents.Cappuccino)
                        .fluid(class_3612.field_15910, 1000)
                        .input(class_1802.field_8103, 1)
                        .input(MapleFoodComponents.Coffee_Beans, 1)
                        .input(class_1802.field_8479, 1)
                        .method_33530("has_coffee_beans", has(MapleFoodComponents.Coffee_Beans))
                        .method_36443(output, "coffee_cappuccino");

                createCoffeeMachine(MapleFoodComponents.Latte)
                        .fluid(class_3612.field_15910, 1000)
                        .input(class_1802.field_8103, 1)
                        .input(MapleFoodComponents.Coffee_Beans, 1)
                        .method_33530("has_coffee_beans", has(MapleFoodComponents.Coffee_Beans))
                        .method_36443(output, "coffee_latte");

                createCoffeeMachine(MapleFoodComponents.Mocha)
                        .fluid(class_3612.field_15910, 1000)
                        .input(MapleFoodComponents.Coffee_Beans, 1)
                        .input(class_1802.field_8116, 1)
                        .input(class_1802.field_8103, 1)
                        .method_33530("has_coffee_beans", has(MapleFoodComponents.Coffee_Beans))
                        .method_36443(output, "coffee_mocha");

                createCoffeeMachine(MapleFoodComponents.Hot_Cocoa)
                        .fluid(class_3612.field_15910, 1000)
                        .input(class_1802.field_8116, 1)
                        .method_33530("has_cocoa_beans", has(class_1802.field_8116))
                        .method_36443(output, "cocoa_to_hot_cocoa");
            }
        };
    }

    @Override
    public String method_10321() {
        return "CoffeeMachine";
    }
}
