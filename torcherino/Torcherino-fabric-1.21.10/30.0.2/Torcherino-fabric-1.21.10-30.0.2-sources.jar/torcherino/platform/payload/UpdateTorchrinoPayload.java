package torcherino.platform.payload;

import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import torcherino.Torcherino;

public record UpdateTorchrinoPayload(class_2338 blockPos, int xRange, int zRange, int yRange, int speed, int redstoneMode) implements class_8710 {
    private static final class_2960 UPDATE_TORCHERINO_VALUES = Torcherino.resloc("update_torcherino_values");
    public static final class_9154<UpdateTorchrinoPayload> TYPE = new class_9154<>(UPDATE_TORCHERINO_VALUES);
    public static final class_9139<class_9129, UpdateTorchrinoPayload> CODEC = class_8710.method_56484(UpdateTorchrinoPayload::write, UpdateTorchrinoPayload::new);

    public UpdateTorchrinoPayload(final class_2540 buf){
        this(buf.method_10811(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt());
    }

    public void write(class_2540 buffer) {
        buffer.method_10807(blockPos);
        buffer.method_53002(xRange);
        buffer.method_53002(zRange);
        buffer.method_53002(yRange);
        buffer.method_53002(speed);
        buffer.method_53002(redstoneMode);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
