package com.skniro.growable_ores_extension.api.block;

import com.skniro.growable_ores_extension.api.energytier.EnergyTier;

public interface TieredEnergyBlock {
    EnergyTier getEnergyTier();

    long getMaxCapacity();
}