package com.skniro.skniro_furniture.block.init;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;

public class DeskLampBlock extends AbstractLampBlock{
    public static final MapCodec<DeskLampBlock> CODEC = method_54094(DeskLampBlock::new);
    private static final class_265 SHAPE = class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 12.5, 11.0);

    public DeskLampBlock(class_2251 settings) {
        super(settings);
    }

    public MapCodec<DeskLampBlock> method_53969() {
        return field_46280;
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }
}
