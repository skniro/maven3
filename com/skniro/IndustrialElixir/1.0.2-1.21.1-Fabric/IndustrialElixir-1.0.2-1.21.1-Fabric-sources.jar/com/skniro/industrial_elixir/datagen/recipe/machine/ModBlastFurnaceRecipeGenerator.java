package com.skniro.industrial_elixir.datagen.recipe.machine;

import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.fluid.IndustrialElixirFluids;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class ModBlastFurnaceRecipeGenerator extends FabricRecipeProvider {
    public ModBlastFurnaceRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                blastFurnace(class_1802.field_8620, GrowableOresItems.STEEL_INGOT, GrowableOresItems.SLAG, "iron_ingot_to_stell_ingot");
                blastFurnace(class_1802.field_8141, GrowableOresItems.EMPTY_VESSEL, null, "glass_pane_to_empty_vessel");
            }

            private void blastFurnace(class_1935 input, class_1935 primaryOutput, class_1792 secondaryOutput, String name) {
                var builder = createBlastFurnace(primaryOutput).fluid(IndustrialElixirFluids.STILL_Fluid_AIR, 1000)
                        .input(input).method_33530("has_base_item", has(input));

                if (secondaryOutput != null) {
                    builder.output2(secondaryOutput);
                }
                builder.method_36443(output, name);
            }
        };
    }

    @Override
    public String method_10321() {
        return "BlastFurnace";
    }
}
