package com.skniro.growable_ores_extension.screen.handler.container.fluid;

import com.skniro.growable_ores_extension.block.entity.container.fluid.FluidTankBlockEntity;
import com.skniro.growable_ores_extension.screen.AlchemyScreenHandlerType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

public class FluidTankScreenHandler extends AbstractContainerMenu {
    private final Container inventory;
    public final FluidTankBlockEntity blockEntity;
    private final ContainerData data;

    public FluidTankScreenHandler(int pContainerId, Inventory inv, BlockPos blockPos) {
        this(pContainerId, inv, inv.player.level().getBlockEntity(blockPos), new SimpleContainerData(2));
    }

    public FluidTankScreenHandler(int pContainerId, Inventory inv, BlockEntity entity, ContainerData data) {
        super(AlchemyScreenHandlerType.FluidTank, pContainerId);
        blockEntity = ((FluidTankBlockEntity) entity);
        this.data = data;
        this.inventory = (FluidTankBlockEntity) blockEntity;

        addPlayerInventory(inv);
        addPlayerHotbar(inv);

        this.addSlot(new Slot(inventory,0, 8, 62));
    }

    @Override
    public ItemStack quickMoveStack(Player player, int invSlot) {
        ItemStack newStack = ItemStack.EMPTY;
        Slot slot = this.slots.get(invSlot);
        if (slot != null && slot.hasItem()) {
            ItemStack originalStack = slot.getItem();
            newStack = originalStack.copy();
            if (invSlot < this.inventory.getContainerSize()) {
                if (!this.moveItemStackTo(originalStack, this.inventory.getContainerSize(), this.slots.size(), true)) {
                    return ItemStack.EMPTY;
                }
            } else if (!this.moveItemStackTo(originalStack, 0, this.inventory.getContainerSize(), false)) {
                return ItemStack.EMPTY;
            }

            if (originalStack.isEmpty()) {
                slot.setByPlayer(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        return newStack;
    }

    @Override
    public boolean stillValid(Player pPlayer) {
        return this.inventory.stillValid(pPlayer);
    }

    private void addPlayerInventory(Inventory playerInventory) {
        for (int i = 0; i < 3; ++i) {
            for (int l = 0; l < 9; ++l) {
                this.addSlot(new Slot(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
            }
        }
    }

    private void addPlayerHotbar(Inventory playerInventory) {
        for (int i = 0; i < 9; ++i) {
            this.addSlot(new Slot(playerInventory, i, 8 + i * 18, 142));
        }
    }
}