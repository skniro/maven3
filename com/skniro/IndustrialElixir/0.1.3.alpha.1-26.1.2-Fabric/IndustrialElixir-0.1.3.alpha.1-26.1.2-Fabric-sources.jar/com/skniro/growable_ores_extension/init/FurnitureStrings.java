package com.skniro.growable_ores_extension.init;

import com.skniro.growable_ores_extension.api.energytier.EnergyTier;

public class FurnitureStrings {
    public static final String Macerator = "gui.growable_ores_extension.macerator";
    public static final String CaneConverter = "gui.growableores.cane_converter";
    public static final String GeneratorWindMill = "gui.growable_ores_extension.generator_wind_mill";
    public static final String Compressor = "gui.growable_ores_extension.compressor";
    public static final String MetalFormer = "gui.growable_ores_extension.metal_former";
    public static final String Extractor = "gui.growable_ores_extension.extractor";
    public static final String Charge_Pad = "gui.growable_ores_extension.charge_pad";
    public static final String Charge_Pad_CESU = "gui.growable_ores_extension.charge_pad_cesu";
    public static final String Charge_Pad_MFE = "gui.growable_ores_extension.charge_pad_mfe";
    public static final String Charge_Pad_MFSU = "gui.growable_ores_extension.charge_pad_mfsu";
    public static final String Energy_Box = "gui.growable_ores_extension.energy_box";
    public static final String Energy_Box_CESU = "gui.growable_ores_extension.energy_box_cesu";
    public static final String Energy_Box_MFE = "gui.growable_ores_extension.energy_box_mfe";
    public static final String Energy_Box_MFSU = "gui.growable_ores_extension.energy_box_mfsu";

    public static final String GENERATOR_SolarPanel = "gui.growable_ores_extension.generator_solar_panel";
    public static final String GENERATOR_ADVANCED_SOLAR_PANEL = "gui.growable_ores_extension.generator_advanced_solar_panel";
    public static final String GENERATOR_HYBRID_SOLAR_PANEL = "gui.growable_ores_extension.generator_hybrid_solar_panel";
    public static final String GENERATOR_ULTIMATE_SOLAR_PANEL = "gui.growable_ores_extension.generator_ultimate_solar_panel";
    public static final String GENERATOR_QUANTUM_SOLAR_PANEL = "gui.growable_ores_extension.generator_quantum_solar_panel";

    public static final String CoalGenerator = "gui.growable_ores_extension.coal_generator";
    public static final String ROLLING = "gui.metal_former.mode.rolling";
    public static final String CUTTING = "gui.metal_former.mode.cutting";
    public static final String EXTRUDING = "gui.metal_former.mode.extruding";
    public static final String ERROR = "gui.metal_former.mode.error";

    public static final String IRON_FURNACE = "gui.growable_ores_extension.iron_furnace";
    public static final String MolecularTransformer = "gui.growable_ores_extension.molecular_transformer";
    public static final String ElectricFurnace = "gui.growable_ores_extension.electric_furnace";
    public static final String Block_Cutter = "gui.growable_ores_extension.block_cutter";
    public static final String Recycler = "gui.growable_ores_extension.recycler";

    public static final String Fluid_Tank = "gui.growable_ores_extension.fluid_tank";
    public static final String BrewReactor = "gui.growable_ores_extension.brew_reactor";
}
