package com.skniro.industrial_elixir.datagen.recipe.material;

import com.skniro.industrial_elixir.api.data.family.GrowableOresBlockFamilies;
import com.skniro.industrial_elixir.api.data.recipe.ModRecipeGenerator;
import com.skniro.industrial_elixir.block.GeneralBlocks;
import com.skniro.industrial_elixir.block.MapleSignBlocks;
import com.skniro.industrial_elixir.item.GrowableOresItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1935;
import net.minecraft.class_7225;
import net.minecraft.class_7701;
import net.minecraft.class_7800;
import net.minecraft.class_7923;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class TreeBlockRecipeGenerator extends FabricRecipeProvider {
    public TreeBlockRecipeGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }


    @Override
        public void method_10419(class_8790 exporter) {
        createRecipeProvider(exporter).buildRecipes();
    }

    protected ModRecipeGenerator createRecipeProvider(class_8790 exporter) {
        return new ModRecipeGenerator(class_7923.field_41178.method_46771(), exporter) {
            @Override
            public void buildRecipes() {
                this.offerPlanksRecipe(GeneralBlocks.Rubber_PLANKS, GeneralBlocks.Rubber_LOG, 4);
                this.woodFromLogs(GeneralBlocks.Rubber_WOOD, GeneralBlocks.Rubber_LOG);
                this.woodFromLogs(GeneralBlocks.STRIPPED_Rubber_WOOD, GeneralBlocks.STRIPPED_Rubber_LOG);
                this.woodenBoat(GrowableOresItems.RUBBER_BOAT, GeneralBlocks.Rubber_PLANKS);
                this.chestBoat(GrowableOresItems.RUBBER_CHEST_BOAT, GrowableOresItems.RUBBER_BOAT);
                this.hangingSign(MapleSignBlocks.Rubber_HANGING_SIGN, GeneralBlocks.STRIPPED_Rubber_LOG);
                generateRecipes(GrowableOresBlockFamilies.RUBBER_PLANKS, class_7701.field_40182);

                shapeless(class_7800.field_40642, GeneralBlocks.Bronze_Block)
                        .method_10449(GrowableOresItems.BRONZE_INGOT,9)
                        .method_10442("has_item", this.has(GrowableOresItems.BRONZE_INGOT)).method_10431(this.output);

                shapeless(class_7800.field_40642, GeneralBlocks.Tin_Block)
                        .method_10449(GrowableOresItems.TIN_INGOT,9)
                        .method_10442("has_item", this.has(GrowableOresItems.TIN_INGOT)).method_10431(this.output);

                shapeless(class_7800.field_40642, GeneralBlocks.Lead_Block)
                        .method_10449(GrowableOresItems.LEAD_INGOT,9)
                        .method_10442("has_item", this.has(GrowableOresItems.LEAD_INGOT)).method_10431(this.output);

                shapeless(class_7800.field_40642, GeneralBlocks.Steel_Block)
                        .method_10449(GrowableOresItems.STEEL_INGOT,9)
                        .method_10442("has_item", this.has(GrowableOresItems.STEEL_INGOT)).method_10431(this.output);

                shapeless(class_7800.field_40642, GeneralBlocks.SACRED_Block)
                        .method_10449(GrowableOresItems.SACRED_INGOT,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SACRED_INGOT)).method_10431(this.output);

                shapeless(class_7800.field_40642, GeneralBlocks.Silver_Block)
                        .method_10449(GrowableOresItems.SILVER_INGOT,9)
                        .method_10442("has_item", this.has(GrowableOresItems.SILVER_INGOT)).method_10431(this.output);
            }

            public void offerPlanksRecipe(class_1935 output, class_1935 logTag, int count) {
                this.shapeless(class_7800.field_40634, output, count).method_10454(logTag).method_10452("planks").method_10442("has_logs", this.has(logTag)).method_10431(this.output);
            }
        };
    }


    @Override
    public String method_10321() {
        return "TreeBlock";
    }
}