package com.skniro.growable_ores_extension.mixin;

import net.minecraft.class_4719;
import net.minecraft.class_8177;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4719.class)
public interface SignTypeAccessor {
    @Invoker("<init>")
    static class_4719 newSignType(String name, class_8177 setType) {
        throw new AssertionError();
    }

    @Invoker("register")
    static class_4719 registerNew(class_4719 type) {
        throw new AssertionError();
    }
}
