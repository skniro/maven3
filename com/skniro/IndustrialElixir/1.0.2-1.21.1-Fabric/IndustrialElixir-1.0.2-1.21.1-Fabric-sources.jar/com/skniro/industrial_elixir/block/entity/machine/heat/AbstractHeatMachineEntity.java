package com.skniro.industrial_elixir.block.entity.machine.heat;

import com.skniro.industrial_elixir.api.block.ImplementedInventory;
import com.skniro.industrial_elixir.api.block.MachineRecipeProvider;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import com.skniro.industrial_elixir.energy.heat.api.HeatStorage;
import com.skniro.industrial_elixir.energy.heat.api.base.SimpleHeatStorage;
import com.skniro.industrial_elixir.energy.heat.api.base.SimpleSidedHeatContainer;
import com.skniro.industrial_elixir.recipe.machine.AbstractMachineCraftingRecipe;
import com.skniro.industrial_elixir.recipe.AlchemyCraftingRecipeInput;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1262;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public abstract class AbstractHeatMachineEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory, MachineRecipeProvider {
    public class_2371<class_1799> inventory = class_2371.method_10213(10, class_1799.field_8037);
    private float rotation = 0;
    protected static final int FLUID_ITEM_SLOT = 0;
    protected static final int INPUT_SLOT = 1;
    protected static final int OUTPUT_SLOT = 2;
    protected static final int OUTPUT_SLOT_2 = 10;
    protected static final int heat_ITEM_SLOT = 3;
    protected static final int UPGRADE_START = 4;
    protected static final int UPGRADE_END = 7;
    protected static final int EMPTY_FLUID_ITEM_SLOT = 8;
    protected static final int SECOND_INPUT_SLOT = 9;
    protected static final int heat_CRAFTING_AMOUNT = 32;
    protected static final int heat_TRANSFER_AMOUNT = 32;

    public SimpleSidedHeatContainer heatContainer;

    protected final class_3913 propertyDelegate;
    public int progress = 0;
    public int maxProgress = 72;
    private final int DEFAULT_MAX_PROGRESS = 72;
    public boolean receivingHeat;

    public AbstractHeatMachineEntity(class_2591 entityType, class_2338 pos, class_2680 state) {
        super(entityType, pos, state);

        heatContainer = new SimpleSidedHeatContainer() {
            @Override
            public long getCapacity() {
                return 50000;
            }

            @Override
            public long getMaxInsert(@Nullable class_2350 side) {
                return 300;
            }

            @Override
            public long getMaxExtract(@Nullable class_2350 side) {
                return 300;
            }

            @Override
            protected void onFinalCommit() {
                method_5431();
                method_10997().method_8413(pos, method_11010(), method_11010(), 3);

/*            if(!world.isClient()) {
                for(ServerPlayerEntity player : PlayerLookup.tracking((ServerWorld) world, getPos())) {
                    ServerPlayNetworking.send(player, new heatSyncS2CPayload(amount, getPos()));
                }
            }*/
            }
        };
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> AbstractHeatMachineEntity.this.progress;
                    case 1 -> AbstractHeatMachineEntity.this.maxProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: AbstractHeatMachineEntity.this.progress = value;
                    case 1: AbstractHeatMachineEntity.this.maxProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };
    }


    @Override
    public boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 side) {
        class_2350 localDir = this.method_10997().method_8320(field_11867).method_11654(AbstractMachineblock.FACING);

        if(side == null) {
            return false;
        }

        if(side == class_2350.field_11033) {
            return false;
        }

        if(side == class_2350.field_11036) {
            return slot == INPUT_SLOT;
        }

        return switch (localDir) {
            default -> //NORTH
                    side == class_2350.field_11043 && slot == INPUT_SLOT ||
                            side == class_2350.field_11034 && slot == INPUT_SLOT ||
                            side == class_2350.field_11039 && slot == INPUT_SLOT;
            case field_11034 ->
                    side.method_10160() == class_2350.field_11043 && slot == INPUT_SLOT ||
                            side.method_10160() == class_2350.field_11034 && slot == INPUT_SLOT ||
                            side.method_10160() == class_2350.field_11039 && slot == INPUT_SLOT;
            case field_11035 ->
                    side.method_10153() == class_2350.field_11043 && slot == INPUT_SLOT ||
                            side.method_10153()  == class_2350.field_11034 && slot == INPUT_SLOT ||
                            side.method_10153()  == class_2350.field_11039 && slot == INPUT_SLOT;
            case field_11039 ->
                    side.method_10170() == class_2350.field_11043 && slot == INPUT_SLOT ||
                            side.method_10170() == class_2350.field_11034 && slot == INPUT_SLOT ||
                            side.method_10170() == class_2350.field_11039 && slot == INPUT_SLOT;
        };
    }

    @Override
    public boolean method_5493(int slot, class_1799 stack, class_2350 side) {
        class_2350 localDir = this.method_10997().method_8320(this.field_11867).method_11654(AbstractMachineblock.FACING);

        if(side == class_2350.field_11036) {
            return false;
        }

        // Down extract
        if(side == class_2350.field_11033) {
            return slot == OUTPUT_SLOT;
        }

        // backside extract
        // right extract
        return switch (localDir) {
            default ->  side == class_2350.field_11035 && slot == OUTPUT_SLOT ||
                    side == class_2350.field_11034 && slot == OUTPUT_SLOT;

            case field_11034 -> side.method_10160() == class_2350.field_11035 && slot == OUTPUT_SLOT ||
                    side.method_10160() == class_2350.field_11034 && slot == OUTPUT_SLOT;

            case field_11035 ->  side.method_10153() == class_2350.field_11035 && slot == OUTPUT_SLOT ||
                    side.method_10153() == class_2350.field_11034 && slot == OUTPUT_SLOT;

            case field_11039 -> side.method_10170() == class_2350.field_11035 && slot == OUTPUT_SLOT ||
                    side.method_10170() == class_2350.field_11034 && slot == OUTPUT_SLOT;
        };
    }

    public class_1799 getRenderStack() {
            return this.method_5438(INPUT_SLOT);
    }
    @Override
    public void method_5431() {
        field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        super.method_5431();
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        class_1262.method_5426(nbt, inventory, registries);
        nbt.method_10569("abstract_machine.progress", progress);
        nbt.method_10569("abstract_machine.max_progress", maxProgress);
        nbt.method_10544("abstract_machine.heat", heatContainer.amount);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        class_1262.method_5429(nbt, inventory, registries);
        progress = (nbt.method_10545("abstract_machine.progress") ? nbt.method_10550("abstract_machine.progress") : 0);
        maxProgress = (nbt.method_10545("abstract_machine.max_progress") ? nbt.method_10550("abstract_machine.max_progress") : maxProgress);
        heatContainer.amount = (nbt.method_10545("abstract_machine.heat") ? nbt.method_10537("abstract_machine.heat") : 300);
        super.method_11014(nbt, registries);
    }

    public void updateHeatInput() {
        receivingHeat = false;

        for (class_2350 dir : class_2350.values()) {
            HeatStorage input = SimpleHeatStorage.SIDED.find(field_11863, field_11867.method_10093(dir), dir.method_10153());
            if (input == null) continue;

            try (Transaction tx = Transaction.openOuter()) {
                long moved = input.extract(1, tx);

                if (moved > 0) {
                    heatContainer.getSideStorage(null).insert(moved, tx);
                    receivingHeat = true;
                    tx.commit();
                }
            }
        }
    }

    public long getFreeSpace() {
        return this.heatContainer.getCapacity() - heatContainer.amount;
    }

    public Optional<ImplementedInventory> getOptionalInventory() {
        if (this instanceof ImplementedInventory inventory) {
            return inventory == null ? Optional.empty() : Optional.of(inventory);
        } else {
            return Optional.empty();
        }
    }

    public HeatStorage getSideheatStorage(@Nullable class_2350 side) {
        return this.heatContainer.getSideStorage(side);
    }


    public void resetProgress() {
        this.progress = 0;
        this.maxProgress = DEFAULT_MAX_PROGRESS;
    }

    protected void craftItem() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> recipe = getCurrentRecipe();
        class_1799 output = recipe.get().comp_1933().output().method_7972();
        this.method_5434(INPUT_SLOT, recipe.get().comp_1933().requiredCount());
        if (this.method_5438(OUTPUT_SLOT).method_7960()) {
            this.method_5447(OUTPUT_SLOT, output.method_7972());
        } else {
            this.method_5438(OUTPUT_SLOT).method_7933(output.method_7947());
        }
    }

    @Override
    public int[] method_5494(class_2350 direction) {
        if (direction != class_2350.field_11033) {
            return new int[]{INPUT_SLOT};
        } else {
            return new int[]{OUTPUT_SLOT};
        }
    }
    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return slot != OUTPUT_SLOT;
    }

    public boolean hasCraftingFinished() {
        return this.progress >= this.maxProgress;
    }

    public void increaseCraftingProgress() {
        this.progress++;
    }

    protected boolean canInsertIntoOutputSlot() {
        return this.method_5438(OUTPUT_SLOT).method_7960() ||
                this.method_5438(OUTPUT_SLOT).method_7947() < this.method_5438(OUTPUT_SLOT).method_7914();
    }

    public boolean hasRecipe() {
        Optional<class_8786<AbstractMachineCraftingRecipe>> recipe = getCurrentRecipe();
        if(recipe.isEmpty()) {
            return false;
        }

        class_1799 output = recipe.get().comp_1933().output().method_7972();
        return canInsertAmountIntoOutputSlot(output.method_7947()) && canInsertItemIntoOutputSlot(output) && hasEnoughheatToCraft();
    }

    protected boolean hasEnoughheatToCraft() {
        return this.heatContainer.amount >= (long) (heat_CRAFTING_AMOUNT/ 20) * maxProgress;
    }

    protected Optional<class_8786<AbstractMachineCraftingRecipe>> getCurrentRecipe() {
        return this.method_10997().method_8503().method_3772()
                .method_8132((class_3956<AbstractMachineCraftingRecipe>) getCurrentRecipeType(), new AlchemyCraftingRecipeInput(inventory.get(INPUT_SLOT)), this.method_10997());
    }

    protected boolean canInsertItemIntoOutputSlot(class_1799 output) {
        return this.method_5438(OUTPUT_SLOT).method_7960() || class_1799.method_31577(this.method_5438(OUTPUT_SLOT), output);
    }

    protected boolean canInsertAmountIntoOutputSlot(int count) {
        int maxCount = this.method_5438(OUTPUT_SLOT).method_7960() ? 64 : this.method_5438(OUTPUT_SLOT).method_7914();
        int currentCount = this.method_5438(OUTPUT_SLOT).method_7947();

        return maxCount >= currentCount + count;
    }


   @Nullable
   @Override
    public class_2596<class_2602> method_38235() {
    return class_2622.method_38585(this);
}

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_58692(registryLookup);
    }

    public class_1937 level() {
        return this.field_11863;
    }

    public class_243 position() {
        return this.method_11016().method_46558();
    }

    public float getVisualRotationYInDegrees() {
        return this.method_11010().method_11654(AbstractMachineblock.FACING).method_10153().method_10164();
    }

}
