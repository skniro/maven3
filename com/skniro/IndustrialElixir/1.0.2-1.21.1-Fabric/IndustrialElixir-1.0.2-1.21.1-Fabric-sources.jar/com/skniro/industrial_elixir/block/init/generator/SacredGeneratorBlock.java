package com.skniro.industrial_elixir.block.init.generator;

import com.mojang.serialization.MapCodec;
import com.skniro.industrial_elixir.api.energytier.EnergyTier;
import com.skniro.industrial_elixir.block.entity.AlchemyBlockEntityType;
import com.skniro.industrial_elixir.block.entity.generator.SacredGeneratorBlockEntity;
import com.skniro.industrial_elixir.block.init.machine.AbstractMachineblock;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_5558;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

public class SacredGeneratorBlock extends AbstractMachineblock {
    public static final class_2754<class_2350> FACING = class_2383.field_11177;
    public static final class_2746 LIT = class_2741.field_12548;

    public SacredGeneratorBlock(class_2251 settings, EnergyTier energyTier, long capacity) {
        super(settings, energyTier, capacity);
        }

        @Override
        protected MapCodec<? extends class_2237> method_53969() {
            throw new IllegalStateException("Block does not support getCodec!");
        }

        @Nullable
        @Override
        public class_2586 method_10123(class_2338 pos, class_2680 state) {
                    return new SacredGeneratorBlockEntity(pos, state);
        }


        @Nullable
        @Override
        public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
                    return method_31618(type, AlchemyBlockEntityType.SACRED_GENERATOR_BE, (world1, pos, state1, blockEntity) -> blockEntity.tick(world1, pos, state1));
        }

}