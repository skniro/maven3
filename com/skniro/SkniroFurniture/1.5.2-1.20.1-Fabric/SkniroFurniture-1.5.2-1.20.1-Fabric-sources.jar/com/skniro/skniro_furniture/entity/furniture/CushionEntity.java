package com.skniro.skniro_furniture.entity.furniture;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_5712;
import org.joml.Vector3f;

public class CushionEntity extends class_1297 {
    public CushionEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Override
    protected void method_5693() {

    }

    @Override
    public double method_5621() {
        return 0.005;
    }


    @Override
    protected void method_5749(class_2487 nbt) {

    }

    @Override
    protected void method_5652(class_2487 nbt) {

    }

    @Override
    public void method_5768(){
        this.method_5650(class_1297.class_5529.field_26998);
        this.method_32876(class_5712.field_37676);
    }

    @Override
    protected void method_5793(class_1297 passenger) {
        super.method_5793(passenger);
        this.method_5768();
    }
}